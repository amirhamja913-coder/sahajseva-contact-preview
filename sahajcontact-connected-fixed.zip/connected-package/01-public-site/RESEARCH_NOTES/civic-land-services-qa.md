# নাগরিক ও ভূমি সেবা — QA notes

- The new folder is placed after the existing নিরাপত্তা ও আইন folder in `UtilityAndExpatriateSections.tsx`.
- Desktop full-page capture confirmed the homepage renders the new folder using the established utility/security card design.
- Narrow mobile capture at 390px confirmed the section remains within the single-column mobile layout, with wrapped Bengali labels and no visible horizontal overflow or overlapping card actions.
- All six cards use the shared `ExternalLinkWithFallback` component, which opens links in a new tab with `noopener noreferrer`.
- The trade-license destination was verified as the Local Government Division, Bangladesh e-Trade License portal at `https://www.etradelicense.gov.bd/DefaultEng`.
- The bottom safety disclaimer states that these are official government links and that any fee should be paid only on the government portal.
- Validation completed: 104 Vitest tests passed; TypeScript check passed; production build passed.

Recorded before the release checkpoint.

