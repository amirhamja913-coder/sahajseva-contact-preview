# Location-search QA

On 2026-08-14, the homepage rendered successfully at the desktop and 375px mobile breakpoints. The mobile header, hero, and full-page flow did not show horizontal overflow or overlapping controls. The location panel now stacks district, upazila, union/ward input, reset action, explanatory note, and the official union-directory link in a single-column touch-friendly layout. A desktop capture showed an existing AI-help modal overlay at first load; it did not indicate a location-panel error, and the narrow mobile capture rendered the homepage without that overlay.

The union/ward text field is intentionally contextual rather than a fabricated local dataset. It activates only after district and upazila selection; the official National Portal directory remains the source of truth for exact union names and office details.
