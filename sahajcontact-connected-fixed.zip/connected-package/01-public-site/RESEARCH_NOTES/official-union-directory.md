# Official union directory source

- Source: https://bangladesh.gov.bd/views/union-list
- Title: ইউনিয়নসমূহ | বাংলাদেশ জাতীয় তথ্য বাতায়ন
- Verified: 2026-08-14
- Key facts observed: the official National Portal exposes a union directory with division selection and reports ৪৫৯৯ ইউনিয়ন; it also links to the ৬৪ জেলা and ৪৯৯ উপজেলা directories.
- Scope warning shown by the source: the National Portal says its list includes government offices within the National Portal framework and some independently developed government sites, and that not all government institutions/offices may be included.
- Product implication: SahajSeva should not fabricate a local union dataset. It should provide a clear union/ward search handoff to the official union directory, keep the selected district/upazila context visible, and state that exact local office availability must be verified on the official portal.
