# Responsive QA — 2026-08-15

The desktop homepage at 1280×720 has a balanced two-column hero and readable header navigation. The existing floating callback and service-finder controls overlap the lower-left hero CTA area, but remain reachable. The mobile homepage at 390×844 has a compact header and readable hero text, but the hero image region is visibly broken or missing (its alt text is exposed), and the floating callback/service-finder controls sit over the image area. The bottom-right phone and AI assistant buttons remain touch-sized. The next fix should prioritize the missing mobile hero visual/fallback and keep floating controls clear of primary hero content without changing service destinations.

