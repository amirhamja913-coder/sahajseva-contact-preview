# Service branding QA — 15 August 2026

The homepage was captured at a 390×844 mobile viewport in both viewport and full-page modes after the service-row branding update. The header, hero, and initial content remain within the viewport without horizontal overflow or visible layout shift. The full-page capture confirms the page continues to render through the civic directory and footer after the HMR update.

The service-row implementation now renders a short visual identifier badge, a readable department/source name, the service title, tag, description, and existing official-link action. The badge is explicitly an identifier rather than a claimed official logo; the department name and official destination remain the authoritative source cues. Accent colors are scoped per service through CSS custom properties so the service destination behavior is unchanged.

Automated validation completed successfully before this visual pass: Vitest, TypeScript check, and production build all exited successfully. The production build retained only the pre-existing large-chunk advisory and the pre-existing runtime storage-image warning.

Follow-up before release: complete the final desktop visual capture and save a checkpoint after reviewing todo.md.

---

## Desktop capture update

A desktop homepage capture should be completed before release to verify the three-column service-row composition and ensure that long Bengali department names wrap naturally without pushing the official-link action off-canvas.
