# About Bangladesh visual verification

## Mobile

The section renders after the hero and before the service content. The green Bangladesh-inspired surface remains readable on a narrow viewport, the image stays within its rounded frame, and the share/link content stacks vertically without clipping. The diaspora reach strip continues below the new section.

## Desktop

The section renders as a two-column composition with the Bangladesh image on the left and Bengali content on the right. The green gradient, blue title, green share action, official links, and diaspora reach strip maintain clear hierarchy and spacing. Existing service sections remain visible below the new block.

## Automated checks

Vitest, TypeScript validation, and the production build completed successfully before visual verification.
