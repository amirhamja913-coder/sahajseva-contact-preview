# Bangladesh museum gallery replacement source

## Selected source
- File: [DG 91 - 09 NATIONAL MUSEUM DHAKA IMG 3171.jpg](https://commons.wikimedia.org/wiki/File:DG_91_-_09_NATIONAL_MUSEUM_DHAKA_IMG_3171.jpg)
- Subject: Bangladesh National Museum, Dhaka
- Author: Babul abdul malek
- Source statement: Own work
- License: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
- Available original resolution: 3,840 x 2,560 pixels
- Intended gallery credit: `ছবি: Babul abdul malek / Wikimedia Commons · CC BY-SA 4.0`

## Alternative reviewed
- File: [Bangladesh Liberation War Museum.jpg](https://commons.wikimedia.org/wiki/File:Bangladesh_Liberation_War_Museum.jpg)
- Author: tayloranddayumi
- License: Creative Commons Attribution 2.0 Generic
- Available original resolution: 3,264 x 2,448 pixels
- Not selected because the requested card replacement is best served by a neutral national-museum exterior image rather than a war-museum-specific image.
