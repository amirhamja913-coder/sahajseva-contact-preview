# Hill tract gallery replacement source

The selected Wikimedia Commons source page is:
https://commons.wikimedia.org/wiki/File:Adivasi_(Indigenous)_Schoolgirls_-_Rangamati_-_Chittagong_Hill_Tracts_-_Bangladesh_(13241186474).jpg

Verified metadata from the source page:
- Subject: Indigenous schoolgirls in Rangamati, Chittagong Hill Tracts, Bangladesh.
- Author: Adam Jones, Ph.D. / Global Photo Archive.
- Original Flickr source: https://flickr.com/photos/41000732@N04/13241186474
- License: Creative Commons Attribution-ShareAlike 2.0 Generic (CC BY-SA 2.0).
- Reuse requirements: provide attribution, link to the license, and indicate changes if made; share adaptations under the same or compatible license.

Planned gallery use: replace the political-figure image with a neutral, respectful development theme focused on indigenous/hill tract education and opportunity. The website card will include Bengali and English captions plus visible source credit and a clickable source URL.
