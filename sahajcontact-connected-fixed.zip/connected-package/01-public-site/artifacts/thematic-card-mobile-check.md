# Thematic Card Mobile Visual Check

Date: 2026-08-15

The mobile full-page capture completed successfully at 375x812, and the focused capture at 390x844 also completed successfully. The dev server reported running with no TypeScript or LSP errors. The focused hash capture remained at the homepage hero rather than automatically scrolling to the lower utility section, so the three target cards still require a direct in-page scroll/anchor verification before final delivery. The generated artwork URLs and thematic styles are wired into the source and the production build completed successfully.

Additional verification: The live page contains the exact agriculture thematic summary with class `thematic-summary-agriculture` inside a `details.utility-folder`. The details panel was opened programmatically and scrolled to the top successfully, confirming the target section is present and directly addressable for a focused screenshot. The earlier hash navigation did not auto-scroll, so direct section opening was used for reliable inspection.

Focused mobile check: The agriculture card is present in the opened utility folder with the Green Fields treatment and right-side farmer artwork visible in the preview. The page exposes distinct selectors for all three redesigned summaries: `.thematic-summary-agriculture`, `.thematic-summary-probashi`, and `.thematic-summary-citizen`. The expatriate heading includes the Bangladesh flag marker, and the three summaries remain separately addressable for focused checks.

Expatriate mobile check: The opened card renders a distinct light-blue Global Blue summary with airplane icon, Bangladesh flag marker, royal-blue title/button treatment, and a right-aligned family/flag/plane illustration. The text remains on the left and the supporting panels appear below without breaking the utility-folder layout.

Court/citizen mobile check: The opened card renders a distinct Justice Navy treatment with the justice-scale icon, formal court-and-gavel illustration on the right, navy heading/button accents, and readable dark text on the light background. Its linked service grid remains visible below and the next section begins cleanly without overlap.
