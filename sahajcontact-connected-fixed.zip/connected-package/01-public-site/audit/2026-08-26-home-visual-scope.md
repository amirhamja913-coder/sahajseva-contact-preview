# Public Home visual scope — 26 August 2026

The current public Home page was reviewed at desktop width before implementing the requested visual adjustment. The request is limited to keeping the existing Karnaphuli Tunnel feature visible as the primary scene, reducing only any decorative card clutter that obscures it, and placing a small responsive Royal Bengal Tiger visual beneath the visible Khulna label on the Bangladesh map.

Source search confirms that the visible `খুলনা` map label is declared in `client/src/components/BangladeshMapInteractive.tsx`. No unrelated Home section, gallery data, owner-only route, authentication behaviour, external integration, or data record is in scope for this change.
