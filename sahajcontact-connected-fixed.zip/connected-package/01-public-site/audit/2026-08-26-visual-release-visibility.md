# Home visual visibility investigation — 2026-08-26

## Development evidence

- The active development workspace renders the requested clean Karnaphuli Tunnel, the small Royal Bengal Tiger below the Bangladesh map, and the compact white tourism entry-card.
- The public tourism route is `/bangladesh`; it rendered in development. No route rewrite was needed.
- The service-worker cache version was advanced with the visual release so a refreshed client can obtain the new bundle.

## Published read-back

- On 2026-08-26, a sandbox-browser read-back of `https://sahajcontact-8xyxsefc.manus.space/?release=3a778892` rendered the project offline fallback (`আপনি এখন অফলাইনে আছেন`) rather than the Home page. This prevents visual confirmation of the published Home release from that browser session.
- The live response and deployment availability must be checked independently before claiming that the phone sees this release.

## Follow-up release read-back

- Version `995cf1f6` was checkpointed and auto-published after the signed-out Admin loading fallback and Home visual/PWA delivery repair passed focused and full local validation.
- Fresh text extraction from the published Home and `/admin/dashboard` routes returned public HTML rather than an upstream server error. The sandbox browser remained unable to maintain a stable rendered page, so it is not used as proof of the owner’s device-level visual state.
- The signed-out Admin verification remains limited to public routing and official-login fallback behavior; no authenticated owner content was opened.
- A second fresh sandbox-browser Home request with `?release=995cf1f6&verify=home` again rendered the offline fallback even though `navigator.onLine` was `true`. That browser held an active same-origin `sw.js` controller and only the current `sahajseva-pwa-v10-home-visuals` cache. This points to an interaction between the browser's PWA navigation handling and its network session, not proof that the public origin itself is unavailable.
- To separate PWA behaviour from delivery, the sandbox's local service-worker registration was removed and the same public Home URL was loaded again. The raw browser request then failed with `ERR_SSL_PROTOCOL_ERROR`. This is a browser/network transport failure in the sandbox rather than an authenticated-page issue; it confirms that the offline fallback had been masking that failure. It still does not establish the owner device's state.
- A no-cache public text extraction made after the raw-browser test returned the Home content containing `সুন্দরবনের রয়েল বেঙ্গল টাইগার` and `খুলনা • সুন্দরবন`, plus the signed-out `/admin/dashboard` page containing `Official account দিয়ে sign in করুন` and its same-origin official OAuth start link. This is current public transport proof for the requested tiger markup and unauthenticated Admin entry, but not device-level rendering proof.
- A fresh 375px development review showed the clean Karnaphuli Tunnel scene without company-name cards, the map-below Khulna–Sundarbans tiger accent, and the compact white Bangladesh-flag/plus tourism entry. This verifies the current source-rendered mobile layout only; it does not override the published-browser transport limitation above.
- The current owner-reported visual revision places the tiger in a dedicated lower slot inside the Bangladesh map card (rather than after the full Hero), makes the Karnaphuli Tunnel label legible on the clean tunnel background, restores the Bangladesh-flag and plus folder cue on the compact tourism entry, and limits the public open-gallery folder to a compact single-screen-height surface. Focused contracts, the full single-worker regression suite, TypeScript, production build, and diff integrity passed; desktop and 375px mobile development review were completed before publication.

## Safety boundary

No protected Admin content, owner session, analytics, payment, DNS, backup, or external account was accessed during this investigation.
