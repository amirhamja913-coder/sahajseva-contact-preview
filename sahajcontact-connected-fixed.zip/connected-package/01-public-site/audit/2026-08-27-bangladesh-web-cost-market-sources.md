# বাংলাদেশ web portal cost market sources — 27 August 2026

এই note-টি vendor-এর public pricing page ও explanatory article থেকে সংগৃহীত market-reference মাত্র। কোনো quote, commitment, invoice, service-level agreement বা নির্দিষ্ট supplier recommendation নয়। চূড়ান্ত খরচ scope, service level, security review, content volume, integrations, ownership এবং contract terms অনুযায়ী বদলাবে।

| Source | Published detail used as a market reference | Use and limitation |
| --- | --- | --- |
| [ARN TECH — Bangladesh website cost breakdown](https://arntechbd.com/blog/how-much-time-and-money-is-needed-for-website-design/) | The article (14 August 2026) lists a professional-help range of ৳43,000–৳2,600,000 upfront; managed hosting ৳1,700–৳5,000/month; and notes that a complex custom site can take months. | Useful as a broad upper/lower market signal, but it is a vendor-authored article and has inconsistent labels in places; it is not a quote for this programme. |
| [Techabyte — Website design cost guide](https://www.techabyte.xyz/how-much-does-website-design-cost-in-bangladesh-a-complete-guide/) | The guide (updated 5 April 2026) describes basic business sites at roughly ৳15,000–৳30,000, more advanced custom sites at roughly ৳50,000–৳150,000, and larger custom portals from roughly ৳200,000; it says maintenance is usually priced separately. | Useful to distinguish simple brochure work from custom portal work. It is an explanatory publisher article, not a binding market survey. |
| [ZAMAN IT — public packages](https://zaman-it.com/) | The visible public packages list ৳14,990 for a starter site, ৳29,990 for a business site, and ৳49,990 for a corporate e-commerce-oriented offer; separately listed domain and hosting are ৳3,000/year each. | Useful as a low-complexity packaged-site floor only. It does not include a three-site, custom, owner-only control programme of this scope. |

## Interpretation boundary

The requested programme is not comparable to a five-page packaged website. It includes public content, a responsive owner-only workspace, database-backed workflows, official OAuth, content governance, search/SEO, PWA behavior, security boundaries, and a separate-control-project boundary. The budget model will therefore use transparent work packages and ranges, not multiply a basic website package price.
