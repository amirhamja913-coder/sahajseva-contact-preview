# Published Business Directory claim read-back — 27 August 2026

## Scope and boundary

This is a signed-out, read-only browser check of `https://sahajcontact-8xyxsefc.manus.space/business-directory` after checkpoint `ae3c73e0`. It does not submit any form, open protected Admin content, select an account, or access applicant data.

## First viewport and page-read findings

The public route loaded with the Business Directory title and the existing honest no-published-listing state. The normal public listing-review request form remained visible. The page extraction showed no applicant contact values, no published business record, and no claimed/verified or government-approval indicator.

The first content read did not include the lower claim-request component because it lies below the initial viewport/content segment. A later signed-out DOM check confirmed that the claim-request region is present in the published page. Full-page public screenshots at desktop (1280px) and mobile (375px) showed the unavailable state, explaining that a claim/correction review is possible only after a real Directory record is published and that the current Directory has no eligible record. No arbitrary listing-ID input, public claim/verified badge, requester contact value, or fabricated listing appeared.

The cache version is now `sahajseva-pwa-v12-directory-claims`. This intentionally refreshes the public service-worker cache for returning installed visitors after the claim release; it does not change the existing `/api/`, `/oauth/`, or `/admin` network bypasses.

## Interpretation

The public checks provide public-route availability, empty-state, claim-unavailable-copy, and responsive layout evidence only. They do not evidence any owner-only panel, Admin authorization, claim submission, listing publication, or the presence of personal data. The protected owner workspace was intentionally not opened.

## Related Home delivery observation after cache refresh

On 27 August, a separate signed-out navigation to the published root route initially displayed the site loading shell. Its text extractor returned the current SahajContact title but mixed in stale gallery-style content, including an externally hosted tunnel image, and did not expose the lower tiger accent in extracted text. This is insufficient evidence of the final Home visual state and must not be treated as a regression confirmation. A subsequent settled rendering check is required before changing the outstanding mobile-delivery TODO. No interaction, submission, login, or protected route was performed.

The subsequent settled signed-out browser view rendered the published Home normally. Its extracted content included the map-card tiger’s Bengali alt text and the caption `খুলনা • সুন্দরবন নদীপাড়`; its visual view showed the tiger in the lower map-card slot and the clean tunnel hero. This confirms the settled desktop public route after the cache refresh. It does not independently confirm the owner’s installed Android PWA/mobile cache state, so the related owner-device delivery TODO remains pending.
