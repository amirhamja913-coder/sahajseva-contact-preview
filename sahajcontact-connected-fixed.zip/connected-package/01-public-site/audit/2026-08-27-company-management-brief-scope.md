# SahajContact Company-Management Brief — Scope Record

## Source and intent

This record summarizes the owner-provided final development brief from `SahajContact_Final_SidePanel_Master_Prompt.txt` and `pasted_content.txt`, received on 27 August 2026. It is a planning record, not a statement that each requested capability is already enabled.

## Non-negotiable constraints

- Preserve the existing public Home design, Hero, service cards, links, branding, footer, and working functionality.
- Organize new public navigation in a responsive drawer/side panel, rather than adding commercial and operational modules to Home.
- Keep three layers distinct: public SahajContact Citizen & Business Portal; authorized SahajContact Control Center; owner-only Executive Control Room.
- Retain official OAuth and server-side authorization. Do not collect NID, passport, passwords, PINs, OTPs, biometric data, recovery codes, or unnecessary sensitive data.
- Do not invent traffic, users, reviews, business listings, partner claims, verification status, sponsorships, government endorsements, or analytics values.
- Present government links as official only when the source is verified; make sponsored/featured commercial content visibly distinct.
- Preserve existing data and routes, and run regression, responsive, and production validations before publishing.

## Requested functional direction

The requested public drawer includes civic-service discovery, institution/business discovery, partner/sponsorship pathways, insights, legal/about links, account controls, and authorized-only entry points. The proposed Admin Control Center uses a desktop sidebar and responsive mobile navigation for existing content, operations, analytics, verification, security, and backup surfaces. The supplied visual reference calls for a clean, technical civic-tech dashboard with restrained status colours, small analytics cards, clear sections, touch-friendly mobile controls, and no public Home redesign.

## Scope separation and dependencies

The current project already exposes public routes, an owner-only `/admin/dashboard` entry, and an owner-only `/admin/site-builder` route. A separate SahajControl/Executive project remains a distinct source-access blocker and must not be folded into this public project or given a parallel login path. Any new business-directory, claim, partner, sponsorship, reporting, backup, or role-management capability requires schema/API/permission auditing before it can be represented as operational rather than as navigation to an existing working feature.

## Budget modelling boundary

The requested budget will estimate market-based implementation and recurring operating costs for the three-site program. It will separate one-time build effort, hosting/operations, and optional third-party services. It will use assumptions and cost ranges rather than assert vendor commitments, seek payment access, or initiate purchases.

## Approved safe dashboard-shell implementation

The in-site owner workspace now uses a light, responsive information architecture inspired by the supplied reference: searchable grouped navigation, a compact mobile menu, and an overview layer that routes to existing content, partnership, analytics, security, and operation controls. It intentionally displays no invented dashboard totals, reviews, alerts, user records, claims, or business data. Official OAuth, server-side owner authorization, and public/Admin separation remain unchanged. Source contracts, TypeScript, the complete single-worker regression suite, production build, and diff-integrity validation passed. A protected-session visual walkthrough was intentionally not performed.

## Public side-panel integration

The existing public drawer now groups actual portal links for business, partner and sponsorship information, public insights and policies, plus a separated authorised-entry route. It does not expose private control functions, initiate third-party sign-in, or invent content. The same source contract and TypeScript validation passed; a signed-out public mobile Home review confirmed the surrounding Home presentation remains intact.

## 27 August 2026 pre-publication visual and PWA verification

The final Home visual contract uses `/manus-storage/sahajcontact-sundarbans-tiger-river-waterlily-map-accent_37915533.png` in the dedicated lower slot of the Bangladesh map card, with the caption `খুলনা • সুন্দরবন নদীপাড়`. No Home hero `চট্টগ্রাম/কর্ণফুলী টানেল` overlay is present, and the normal gallery title/caption below its image remains separate from the removed image overlay. The PWA cache is advanced to `sahajseva-pwa-v11-map-nature` and precaches both the clean tunnel scene and the new nature accent, so installed clients can receive the asset update.

On the signed-out development public routes, the 1280px desktop Home hero displayed the preserved header, map presentation, its lower attached tiger river-and-water-lily card, and no unwanted Karnaphuli overlay. At 375px mobile width, the same compact tiger card remained immediately below the map artwork without covering its labels; the clean tunnel scene rendered below the unchanged hero content. At both desktop and mobile widths, the `/bangladesh` route displayed the compact white Bangladesh-flag folder entry and plus cue. Focused source tests and the full single-worker suite passed (124 files / 412 tests; one pre-existing skipped file with four skipped tests), as did TypeScript, production build, and diff-integrity checking. After version `45323b47` auto-published, a no-cache, read-only production extraction of the Home page returned the Sundarbans Royal Bengal Tiger label and its Khulna–Sundarbans caption. The signed-out production `/admin/dashboard` route returned the official sign-in handoff and its explicit no-site-password/OTP/biometric statement. This is public transport/source evidence, not owner-device installed-PWA confirmation. This record does not claim a protected Admin walkthrough, owner-device confirmation, external account selection, analytics access, or any private-data action.

## Business Directory foundation — safe first implementation

The first data-backed Company-Management capability is a review-first Business Directory. Migration `0047_dusty_doomsday.sql` adds a non-destructive `business_directory_submissions` table and was applied after review. Each public request begins in `pending` status, stores requester contact information privately for owner review, and requires affirmative consent. Public list reads select only explicitly published directory fields; no request automatically becomes a listing, rating, endorsement, licence result, government approval, partnership, or payment obligation.

The public `/business-directory` route starts with an honest empty state until the owner publishes a real reviewed record. Its submission form asks only for a business name, category, district, optional public website, public description, contact name, email, phone, and consent. It explicitly excludes financial information, government ID, passwords, OTPs, biometrics, and payment collection. The owner-only review panel is inside the already protected Admin workspace and calls server procedures guarded by the existing server-side owner authorization; it can review, publish, decline, archive, or return an item to pending. No public read exposes applicant contact details.

Focused Business Directory tests passed (4 tests). The complete single-worker suite, TypeScript check, production build, and diff-integrity check passed after the implementation; only the established large-chunk build advisories remain. Signed-out 1280px and 375px responsive public checks showed the empty state, disclosure copy, form, and footer without horizontal overflow. After version `61f9fcba` auto-published, the signed-out production browser route rendered the empty state, non-endorsement disclosure, private-review consent statement, form, and public footer. The initial text-only extractor response was temporarily stale, while the directly loaded public browser received the current application after its normal loading state. The review panel was not opened because it is protected owner content; this audit does not claim any private Admin data access or an end-to-end owner workflow.

## Business Directory discovery coverage — pre-publication evidence

The review-first Business Directory now has a purpose-specific public title, description, canonical route, sitemap entry, and internal-search destination. Its search-facing wording identifies it as an owner-reviewed information directory and does not imply verified status, endorsement, official government information, paid placement, available listings, or approval. At signed-out development widths of 1280px and 375px, the public route showed the honest no-listings empty state, private-review disclosure, consent-based form, and public footer without visible horizontal overflow. The owner-only review panel was not opened. The final production read-back remains a separate post-publication evidence step.

## Ownership/correction claim review — safe implementation evidence

Migration `0048_bright_gamma_corps.sql` adds only the non-destructive `business_directory_claim_requests` table. Its limited private fields are the published listing ID, claimant name, stated relationship, email, phone, short request explanation, affirmative consent, review status, private owner note, and created/updated timestamps. It does not collect or store NID, trade-licence image or number, bank/payment information, passwords, OTPs, biometrics, uploaded identity documents, or secrets. The schema defaults every request to `pending`; its allowed review states are `pending`, `reviewed`, `declined`, and `archived`.

The server rechecks that the target ID exists in `business_directory_submissions` and has `published` status immediately before it inserts a private request. A non-existent, pending, declined, or archived listing is rejected. No request edits a listing, transfers ownership, changes a public status, or produces a public claim/verification signal. Public claimability reads reuse the existing minimal published-listing projection only; claimant email, phone, owner note, and review request details are returned solely through server-side owner-authorized procedures in the existing protected Admin workspace.

The signed-out public page presents a selector only when real published listings exist. Because no owner-published listing exists in the current database, the public surface renders an explanatory unavailable state rather than an arbitrary listing-ID field. It states that a claim is not ownership proof, a licence or government verification, endorsement, partnership, claimed/verified badge, payment product, or guarantee. It explicitly instructs visitors not to provide sensitive identity, financial, payment, or security information. The protected owner panel has a private status/note update path and records the request’s updated timestamp; it was intentionally not opened during public verification.

Focused claim and existing Directory tests passed (8 assertions across 2 files). The complete single-worker suite passed with 126 files / 420 tests, with 1 pre-existing skipped file / 4 skipped tests. TypeScript, production build, and `git diff --check` passed; only the existing large-chunk build advisories remain. Signed-out development screenshots at 1280px and 375px showed the honest empty state, claim-unavailable explanation, original separate listing-review form, and footer without a public claim form or a fabricated listing. No protected Admin data, owner account, browser account selection, applicant submission, analytics, payment, DNS, backup, external credential, or separate SahajControl project was opened or changed.
