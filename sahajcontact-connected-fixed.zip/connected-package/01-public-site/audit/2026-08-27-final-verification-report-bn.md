# SahajContact — Final Verification Report

> **তারিখ:** ২৭ আগস্ট ২০২৬  
> **Scope:** বর্তমান `sahajseva-contact-preview` source, lockfile, automated validation, signed-out public preview এবং non-sensitive audit documentation।  
> **সীমা:** এই কাজের সময় কোনো private owner account, Admin record, real contact submission, Analytics, DNS, domain, payment, external backup destination, production restore অথবা পৃথক Executive Control Room project খোলা বা পরিবর্তন করা হয়নি।

## বর্তমান অবস্থার সংক্ষিপ্ত সিদ্ধান্ত

SahajContact-এর বর্তমান source **public-safe stability/security এবং controlled migration-preparation অবস্থায় আছে**। বর্তমান public design—বিশেষ করে Home-এর নদী–ব্রিজ, মানচিত্র, বাঘ–শাপলা accent, Tourism Spot entry-card, logo/branding, URL structure এবং public feature—ইচ্ছাকৃতভাবে redesign করা হয়নি। তবে এটি **Manus-independent production**, **independently backed up**, **disaster-recovery verified**, **externally monitored** বা **10,000+ ব্যবহারকারী capacity-certified** বলে দাবি করার মতো evidence এখনও নেই।

| রিপোর্টের শব্দ | অর্থ |
|---|---|
| **Verified** | source, automated test, build বা signed-out public preview দিয়ে বাস্তবে পরীক্ষা করা হয়েছে |
| **Partially done** | source/code/documentation অংশ প্রস্তুত; কিন্তু owner-controlled account, target infrastructure অথবা বাস্তব operational evidence অনুপস্থিত |
| **Not done** | কাজটি শুরু হয়নি অথবা কোনো বাস্তব evidence নেই |
| **Owner action required** | আপনার account/control/approval ছাড়া নিরাপদে করা উচিত নয় |

---

## ✅ DONE — সম্পন্ন ও বাস্তবে যাচাই করা কাজ

| কাজ | কী করা হয়েছে | কীভাবে verify করা হয়েছে | ফলাফল | আর কিছু প্রয়োজন কি না |
|---|---|---|---|---|
| Home map visual protection | Original নদী–ব্রিজ illustration অপরিবর্তিত রেখে transparent Royal Bengal Tiger–শাপলা accent মানচিত্রের river scene-এর ভিতরেই রাখা হয়েছে | Signed-out current-source screenshot: `/` at **1280×720** এবং **375×812**; checkpoint `4ca8c6cd`-এর পরে signed-out production Home read-back | Preview ও live Home-এ বাঘ–শাপলা পৃথক card/duplicate landscape হিসেবে দেখা যায়নি; map label দৃশ্যমান ছিল | নতুন visual change প্রয়োজন নেই, যদি না বাস্তব display defect দেখা যায় |
| Tourism Spot entry-card | Compact white entry-card-এ Bangladesh flag এবং folder/+ cue রাখা হয়েছে | Signed-out `/bangladesh` desktop ও 375px mobile screenshot; checkpoint `4ca8c6cd`-এর পরে signed-out production Tourism read-back | Live page-এ flag, folder/+ cue ও closed-entry behaviour দৃশ্যমান ছিল | বর্তমান public visual ঠিক আছে |
| Land-arrival guidance | Visible Tourism wording, Home teaser, public search ও route SEO Bangladesh-এ স্থলপথে **আসার** সতর্ক guidance হিসেবে রাখা হয়েছে | Current-source route rendering, existing regression coverage এবং post-checkpoint signed-out production Tourism read-back | Live wording official source যাচাই করতে বলে; SahajContact eligibility নির্ধারণ করে না এবং entry, route বা transport নিশ্চয়তা দেয় না | Official information পুনরায় যাচাই করার নির্দেশনা বজায় থাকবে |
| Public Contact privacy boundary | Consent ছাড়া enquiry submit হয় না; সীমিত field, optional email, sensitive credential/financial/NID content rejection এবং write-only public flow রাখা হয়েছে | Existing server contract tests ও source audit | Public lead-read route নেই; owner review আগের official OAuth + server-side owner boundary-তেই আছে | Real public form submit করে test করা হয়নি, যাতে fake record না তৈরি হয় |
| Official Admin sign-in boundary | Existing official Manus OAuth ও server-side owner authorization বজায় রাখা হয়েছে; custom password, PIN, OTP, biometric বা parallel login যোগ করা হয়নি | OAuth/protected procedure source review এবং earlier public owner-gate evidence | Admin boundary redesign হয়নি এবং insecure alternate sign-in তৈরি হয়নি | Migration হলে নতুন identity provider-এ আলাদা security review দরকার |
| Owner/editor media upload hardening | তিনটি reviewed upload path-এ shared server-side MIME allowlist, strict Base64 validation ও **20 MiB** pre-/post-decode limit যোগ হয়েছে | Focused `mediaUploadValidation` tests | Unallowlisted type, data-URL MIME mismatch, malformed/empty Base64 ও oversized payload storage write-এর আগে reject হয়; valid image, PDF ও common video management contract বজায় থাকে | File-signature scan, anti-virus বা malware quarantine এখনও নেই |
| Dependency risk reduction | Source-used direct packages update: Axios `1.20.0`, Nanoid `5.1.16`, Streamdown `1.6.11`, Drizzle ORM `0.45.2` | `pnpm audit --prod --json` before/after scan | Scan result **0 critical / 19 high / 47 moderate / 8 low** থেকে **0 / 4 / 4 / 2** হয়েছে | অবশিষ্ট advisory আলাদা security backlog হিসেবে আছে |
| Regression and release-build verification | Full tests, type check, production build ও diff integrity run করা হয়েছে | `pnpm test -- --pool=forks --poolOptions.forks.singleFork=true`; `pnpm check`; `pnpm build`; `git diff --check`; checkpoint `4ca8c6cd`-এর পরে signed-out production Home ও Tourism read-back | **128 test files / 432 tests passed**; 1 pre-existing skipped file ও 4 skipped tests; type check ও build pass; only existing chunk-size advisory; public Home/Tourism production rendering read-back সম্পন্ন | Private/admin, backup, analytics, load বা external monitoring verification এই public smoke check-এর অংশ নয় |
| Manus dependency and migration documentation | Source-grounded dependency matrix, external-host runbook, backup/recovery boundary, load/monitoring plan এবং handover checklist লেখা/হালনাগাদ হয়েছে | Source audit এবং documentation cross-check | কোন dependency কী কাজে লাগে, fail হলে কী impact এবং provider-neutral replacement কী—স্পষ্টভাবে নথিভুক্ত | Documentation নিজে migration বা backup execution নয় |

---

## ⚠️ PARTIALLY DONE — আংশিক সম্পন্ন বা external configuration-নির্ভর কাজ

| কাজ | কী করা হয়েছে | কীভাবে verify করা হয়েছে | ফলাফল | আর কী প্রয়োজন |
|---|---|---|---|---|
| Security posture | Public-safe source audit, upload validation এবং focused dependency updates হয়েছে | Source review, focused tests, full regression এবং production dependency scan | গুরুত্বপূর্ণ কয়েকটি reducible risk কমেছে; তবে “100% secure” বলা হচ্ছে না | Residual package upgrades, file-signature/malware strategy, operational log/incident policy প্রয়োজন |
| Backup architecture | Backup layers, retention/RPO/RTO, encrypted export, restore drill এবং off-platform copy-এর runbook লেখা হয়েছে | Current source ও existing snapshot/restore scope review | Current in-app selected public-content snapshot পূর্ণ backup নয় | Authorised database dump, media export, secret rotation এবং restore evidence দরকার |
| Disaster recovery | Incident-first and isolated restore sequence নথিভুক্ত হয়েছে | Runbook/source review | Safe procedure আছে, কিন্তু কোনো clean-environment restore চালানো হয়নি | Owner-authorised isolated restore drill ও measured RTO/RPO evidence দরকার |
| Independent hosting preparation | Render/Railway/VPS-compatible Node deployment, migration steps, environment manifest, route/redirect ও rollback preparation লেখা হয়েছে | Source/build/dependency review | Source portability প্রস্তুত; active deployment এখনও Manus-managed | Target host, MySQL-compatible DB, object storage, secret manager, OAuth provider ও staging deploy দরকার |
| Manus dependency inventory | OAuth, Forge storage, managed database, scheduler, deployment/subdomain ও notification/control coupling চিহ্নিত হয়েছে | `server/_core`, storage, env boundary ও manifest review | Provider coupling নথিভুক্ত হয়েছে | Target provider selection ও code conversion বাস্তবায়ন দরকার |
| Monitoring and link health | Managed uptime service এবং external low-frequency scheduled checker—দুইটি provider-neutral option, trade-off ও acceptance requirements নথিভুক্ত হয়েছে | Architecture review | কোনো fake status, alert, uptime, traffic বা broken-link result তৈরি হয়নি | Owner-approved monitor account/host, allowlist, cadence, recipient, retention ও incident owner দরকার |
| Scalability planning | Load/stress-test plan, required metrics ও stop conditions নথিভুক্ত হয়েছে | Architecture review | কোন metric মাপতে হবে নির্ধারিত, কিন্তু capacity measured নয় | Authorised staging, realistic sanitized dataset এবং target infrastructure দরকার |
| Admin/Control Room continuity | বর্তমান public project-এর boundary ও separate-system dependency স্পষ্ট করা হয়েছে | Source/scope review | Existing Admin public project-এ নিরাপদে অপরিবর্তিত; separate Executive Control Room এই milestone-এর scope-এর বাইরে | পৃথক project source, authorised deployment access ও dedicated verification দরকার |

> **Residual dependency note:** `xlsx 0.18.5`, Express 4-এর `path-to-regexp` chain এবং Recharts 2-এর Lodash chain-এর কারণে **4 high / 4 moderate / 2 low** advisory রয়ে গেছে। এগুলোর upgrade/replacement major compatibility review ছাড়া জোর করে করা হয়নি, যাতে public design ও working feature ক্ষতিগ্রস্ত না হয়।

---

## ❌ NOT DONE — করা হয়নি বা evidence নেই

| কাজ | কেন করা হয়নি | বর্তমান ফলাফল | পরবর্তীতে কীভাবে করা যাবে |
|---|---|---|---|
| Independent external backup | কোনো owner-authorised target storage/database destination দেওয়া বা খোলা হয়নি | Backup completed বলা যাচ্ছে না | Encrypted DB export, media inventory/export ও off-platform checksum copy করে evidence রাখতে হবে |
| Verified disaster recovery restore | Restore destructive হতে পারে; written approval ও isolated target ছাড়া করা নিরাপদ নয় | Disaster recovery verified বলা যাচ্ছে না | Disposable staging database/environment-এ approved restore drill চালাতে হবে |
| External migration completion | Target host, DB, storage, secrets, OAuth ও DNS integration করা হয়নি | Migration completed বলা যাচ্ছে না | Controlled staging migration → acceptance → reversible cutover চালাতে হবে |
| Production DNS/domain cutover | Owner-controlled DNS/domain access নেই | বর্তমান URL অপরিবর্তিত আছে | DNS TTL, TLS, redirect এবং rollback plan নিয়ে owner-controlled reversible cutover দরকার |
| Real GA4/traffic verification | Private Analytics property/data খোলা হয়নি | কোনো traffic, country user, advertiser metric বা analytics result দাবি করা হচ্ছে না | Owner-approved read-only GA4 evidence নিয়ে পৃথক verification করতে হবে |
| Operating monitoring/alerts/link-health data | কোনো schedule বা third-party monitor enable করা হয়নি | Uptime, alert, link-status বা health score নেই | Approved option নির্বাচন করে low-frequency monitor চালু ও evidence collect করতে হবে |
| Authorised load/stress test | Production traffic সৃষ্টি বা fake user/contact record করা হয়নি | Capacity, concurrent-user limit, latency বা 10,000+ support verified নয় | Staging-এ documented workload/stop conditions সহ test চালিয়ে p50/p95/p99 ও error metrics সংরক্ষণ করতে হবে |
| Full malware/content scan for uploads | Current change bounded MIME/Base64 validation; AV/quarantine infrastructure নেই | Upload safety complete বলা যাচ্ছে না | Provider-side scanning/quarantine, file-signature checks ও retention policy নির্বাচন দরকার |
| Separate Executive Control Room repair/deployment | এটি আলাদা project/system boundary; source/access এই milestone-এ ছিল না | এর operational status যাচাই করা হয়নি | আলাদা source, authorised deployment control ও test plan প্রয়োজন |

---

## 👤 OWNER ACTION REQUIRED — আপনার account/control/approval দিয়ে করতে হবে

| আপনার প্রয়োজনীয় কাজ | কেন আপনার action দরকার | নিরাপদ পরবর্তী পদক্ষেপ | Completion evidence |
|---|---|---|---|
| External hosting target নির্বাচন | Hosting account ও commercial/service decision owner-controlled | Target Node host, managed MySQL/TiDB-compatible DB ও object storage নির্বাচন করুন | Approved target architecture ও access delegation record |
| Independent backup destination/policy নির্বাচন | Backup location, retention ও lawful export authority private | RPO/RTO, retention, encryption/key ownership ও off-platform destination approve করুন | Encrypted export checksum, retention record, restore-drill log |
| New identity/OAuth provider নির্বাচন | বর্তমান Admin identity Manus OAuth-bound | Auth.js/Keycloak/Supabase/other OIDC-এর মধ্যে provider নির্বাচন ও new callback/origin approve করুন | Non-owner denial এবং owner sign-in staging test |
| DNS/custom domain control | DNS/TLS/cutover external owner control | Existing domain/Cloudflare/DNS control থেকে reversible cutover plan approve করুন; বর্তমান Manus URL rollback window পর্যন্ত চালু রাখুন | DNS/TLS/redirect/rollback verification |
| Real analytics verification | Analytics property private | প্রয়োজন হলে read-only evidence দিয়ে GA4 property/select metrics যাচাই করতে অনুমতি দিন | Date range, property ID (reportে masked), filters এবং exported evidence |
| Monitoring option ও incident recipient অনুমোদন | Alert recipient, privacy/retention ও service cost owner decision | Managed monitoring বা secured external scheduler-এর মধ্যে একটি option approve করুন | Health endpoint result, alert receipt, retention policy |
| Recovery and load-test approval | Restore/load can alter isolated infra/cost | Sanitized staging, test window, concurrency profile ও stop conditions approve করুন | Signed test report, p95/p99/error/resource/recovery results |
| Separate Control Room access/scope | এটি public SahajContact থেকে পৃথক | Separate project source/deployment boundary ও authorised scope দিন | Separate project acceptance record |

> কোনো password, PIN, OTP, biometric, recovery code বা secret এই report-এর জন্য নেওয়া/চাওয়া হয়নি এবং প্রয়োজনও নেই। Secret migration হলে owner-controlled secret manager-এ **fresh least-privilege value** তৈরি/rotate করতে হবে; real value source code বা documentation-এ রাখা যাবে না।

---

## Manus unavailable হলে বাস্তব করণীয়

প্রথমে DNS পরিবর্তন করবেন না। Incident owner নির্ধারণ, stakeholder communication এবং known-good source/database/media point সংরক্ষণ করুন। এরপর isolated target-এ source build, authorised database import, authorised media copy, fresh secrets এবং replacement OAuth configuration দিয়ে restore করুন। Public ও Admin acceptance, security regression, performance/load test এবং rollback procedure evidence পাওয়ার পরে তবেই reversible DNS cutover করুন।

বর্তমান source code একা দিয়ে Manus-hosted database data, Forge object bytes, OAuth identity, secret value বা external provider configuration পুনর্গঠন করা সম্ভব নয় যদি সেগুলোর independent authorised copy আগে থেকে না থাকে।

## পরবর্তী বাস্তবসম্মত ধাপ

1. এই milestone-এর checkpoint `4ca8c6cd` প্রকাশের পরে signed-out production Home smoke read-back সংরক্ষিত হয়েছে; production Tourism route-এর একই non-invasive smoke read-back পরের public verification হিসেবে রাখা হয়েছে।
2. Owner target host, DB, media storage, identity provider এবং backup retention/RPO/RTO approve করুন।
3. Authorised export নিয়ে encrypted off-platform source/database/media copies তৈরি করুন।
4. Staging-এ OAuth/storage/scheduler conversion, clean restore drill ও load test চালান; কোনো fake public record তৈরি করবেন না।
5. Evidence review-এর পরে existing Manus endpoint রেখে reversible DNS cutover পরিকল্পনা করুন।

## Final readiness status

**বর্তমান SahajContact public portal স্থিতিশীলতা, design protection, focused server-side upload hardening, dependency-risk reduction এবং migration documentation-এর দিক থেকে প্রস্তুত।** কিন্তু independent production hosting, verified backup/restore, operational monitoring ও certified capacity-এর জন্য উপরের owner-controlled external steps এখনও আবশ্যক। অতএব বর্তমান সঠিক status হলো **“migration-prepared / partially operationally ready”**, **“fully independent” নয়**।

## Evidence references

[1]: ./2026-08-27-security-backup-migration-verification.md "Security, Backup, Migration ও Verification Audit"
[2]: ../INDEPENDENT_HOSTING_AND_BACKUP_GUIDE_BN.md "Independent hosting and backup guide"
[3]: ./2026-08-27-final-brief-reconciliation.md "Earlier brief reconciliation"
[4]: ../../server/mediaUploadValidation.ts "Server-side media upload validation"
[5]: ../../server/mediaUploadValidation.test.ts "Focused validation tests"
