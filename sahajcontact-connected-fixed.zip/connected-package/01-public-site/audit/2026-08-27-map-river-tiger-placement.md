# Bangladesh map river-panel tiger placement — 27 August 2026

## Owner-requested correction

The compact Sundarbans image previously occupied a lower grid slot beneath the map canvas and then became a second wide river-and-bridge scene inside the map card. It is now replaced by one **borderless wildlife cutout** on the right side of the established Bangladesh map artwork. The current managed asset, `/manus-storage/sahajcontact-map-tiger-waterlily-alpha-overlay-verified_5ad7e1cf.png`, contains a recognisable Royal Bengal Tiger, blooming white/pale-pink water lilies, and restrained low foliage only. It introduces no second river, bridge, map, panel, text, border, shadow, or caption in the component markup.

On the owner’s follow-up clarification, the original river-and-bridge composition shown in `/manus-storage/sahajcontact-map-river-tiger-waterlily-integrated_93ec711f.png` remains the visual base. The transparent wildlife cutout is a restrained accent within that artwork, so it does not remove, redraw, or introduce a second river-and-bridge composition.

## Preserved scope

The managed cutout is intentionally small enough to preserve the single existing river-and-bridge scene. It is non-interactive at map-layer z-index 1, below the map artwork, labels, and hotspots, with no standalone border, shadow, caption, or mini-card in source. Its actual alpha channel was pixel-verified before upload. The public service-worker cache is prepared as `sahajseva-pwa-v19-map-verified-alpha` and precaches the verified cutout; its API, official OAuth, and Admin network-bypass rules remain unchanged. The Bangladesh map, flag colouring, labels, hotspot behaviour, Home header, clean Karnaphuli Tunnel, other service content, navigation, footer, and all Admin/security functionality were not changed by this correction.

## Validation evidence

The complete single-worker Vitest suite passed with 127 files / 427 tests; one existing skipped file and four existing skipped tests remain. TypeScript, production build, and `git diff --check` passed. The production build showed only its existing chunk-size advisories.

The current-source 1280px desktop and 375px mobile public screenshots were captured after the cutout, Tourism entry-card, inbound Bangladesh wording, Contact workflow, and PWA source updates. They render the public Home and `/bangladesh` routes without opening any protected area. The source contract confirms that the wildlife cutout is inside the map canvas, non-interactive, and below map labels and hotspots. The compact closed Tourism entry surface retains its visible green/red Bangladesh flag plus folder-and-plus cue at both widths, and the visible public wording is framed as arriving in Bangladesh by land.

The first supplied cutout was rejected after a later 375px review revealed a visible pale rounded matte around the tiger. Although a follow-up v2 asset was described as alpha-only, the signed-out published read-back still revealed its white rectangle. It was therefore replaced by the current pixel-verified RGBA asset above, created by converting only border-connected near-white matte pixels to transparency while preserving the tiger, flowers, and foliage. The subsequent 375px current-source capture shows the tiger and water lilies directly over the original river panel, with no pale rectangle or standalone mini-card; the bridge, map geography, labels, and hotspots remain visible. The single-scene visual acceptance is met in the reviewed development source; production proof remains pending the replacement checkpoint. No Admin workspace, owner session, external account, analytics, payment, DNS, or private data was opened.

## Final development evidence — 27 August 2026

The final current-source 375px Home capture confirms that the Royal Bengal Tiger and water lilies remain visible inside the original river-and-bridge map card rather than below or beside it; no second landscape, white matte, standalone card, or horizontal overflow appears. A current-source 1280px capture confirms the unchanged map-card composition and independently shows the compact white Tourism Spot entry surface with the green/red Bangladesh flag, prominent folder icon, and green `+` badge on the closed surface. The Tourism heading now presents **বাংলাদেশে স্থলপথে আগমন** and frames information as official-source verification guidance rather than a promise about border operation, visa eligibility, or transport.

After the verified-alpha visual correction, the full single-fork Vitest suite passed (127 files; 427 tests passed; 1 pre-existing skipped file / 4 skipped tests), along with TypeScript checking, production build, and `git diff --check`. The established build output contains only bundle-size advisories. The published v18 read-back correctly exposed the matte defect; this v19 replacement is still current-source evidence until the next replacement checkpoint is published and read back.

## Published read-back note — 27 August 2026

The replacement checkpoint was auto-published. An immediate signed-out public Home navigation initially returned the normal loading skeleton, then a blank viewport with no browser-console message. As neither state rendered the map card, this transient read-back is **not** counted as confirmation of the current visual release. It must be retried after deployment propagation; no protected route, login, form submission, or private data was accessed during this check.

Follow-up signed-out diagnostics confirm that the published root DOM has mounted public Home content, has normal visible/opaque layout boxes, and requested the pixel-verified wildlife asset; no browser-console error was emitted. The browser capture surface nevertheless remained blank, so this is evidence of public bundle/asset loading only—not a substitute for a successful visual read-back of the map card.

## Successful production visual read-back — 27 August 2026

A subsequent signed-out production capture successfully rendered the Home map card. It shows the transparent Royal Bengal Tiger and water-lily accent within the established right-side river-and-bridge illustration, beside—not beneath or outside—the Bangladesh geography. No pale rectangular matte, standalone wildlife card, second landscape, or obscured map label/hotspot is visible. This confirms the pixel-verified alpha asset is publicly served in the current release; no Admin route, sign-in, form submission, or private record was accessed.
