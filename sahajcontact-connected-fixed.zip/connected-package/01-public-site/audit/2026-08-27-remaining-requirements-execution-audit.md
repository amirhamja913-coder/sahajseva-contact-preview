# অবশিষ্ট Requirement বাস্তবায়নযোগ্যতা Audit

**তারিখ:** ২৭ আগস্ট ২০২৬  
**প্রকল্প:** SahajContact public portal  
**উদ্দেশ্য:** বর্তমান checklist-এ থাকা বাকি কাজগুলোকে বাস্তবায়ন-সীমা অনুযায়ী আলাদা করা। এটি কোনো কাজ সম্পন্ন হওয়ার দাবি নয়।

## সিদ্ধান্ত

বর্তমান SahajContact workspace-এ নিরাপদে করার মতো অবশিষ্ট runtime/code কাজ পাওয়া যায়নি। বাকি কাজগুলো হয় **আলাদা SahajControl বা Recovery Admin project**-এর source/deployment চায়, নয়তো **owner-controlled domain, official account, private device, GA4 property evidence, বা নির্দিষ্ট স্বাভাবিক scheduled run**-এর ওপর নির্ভরশীল। এগুলো অনুকরণ, fabricated data, private login, custom credential flow, অথবা অনুমানভিত্তিক configuration দিয়ে সম্পন্ন করা নিরাপদ বা সত্যনিষ্ঠ হবে না।

| Requirement group | TODO line(s) | বর্তমান অবস্থা | নিরাপদ পরবর্তী শর্ত |
|---|---:|---|---|
| পৃথক SahajControl owner-entry, Command Center, OAuth callback ও mobile handoff | 7–21 | বর্তমান public portal থেকে পৃথক source/deployment দরকার | অনুমোদিত `sahajcontrol-private` source/deployment attachment এবং signed-out regression scope |
| Emergency DNS / health-aware failover | 2854, 2858–2859, 2946 | Owner-controlled domain ও Cloudflare zone নেই | Owner domain name, provider connection ও কাটওভার অনুমোদন |
| Task Data Backup / restoration eligibility | 2929–2933 | Official restoration status ও owner-shared read-only session দরকার | Owner-approved official affected-status evidence; restore-এর আগে পৃথক confirmation |
| GA4/SEO report, property reconciliation ও natural Heartbeat evidence | 2969, 3005–3006, 3087–3089, 3107, 3111–3112, 3115 | বাস্তব stored snapshot, read-only property evidence ও natural scheduled execution দরকার | Owner-provided read-only evidence এবং পরবর্তী natural run; schedule manually চালানো/পরিবর্তন নয় |
| পৃথক Recovery Admin sign-in ও mobile blank-screen repairs | 3027–3035 | SahajContact-এর source নয়; owner device/session behaviour যাচাইও প্রয়োজন | অনুমোদিত separate-project source/deployment এবং owner device থেকে error evidence |
| Public named identity / third-party organization disclosure | 3040, 3052 | প্রকাশের অনুমতি ও source basis অনিশ্চিত | Owner-এর সীমিত, non-sensitive public-disclosure confirmation |
| Official owner Admin data-status verification | 3122 | Official owner account-এর private session প্রয়োজন | Owner-initiated/approved read-only session; কোনো edit, publish, credential, DNS বা control action নয় |

## বর্তমান public portal-এ ইতিমধ্যে যাচাইকৃত সীমিত কাজ

বর্তমান release-এ Home map-এর wildlife overlay pixel-verified alpha asset হিসেবে map card-এর বিদ্যমান river-and-bridge artwork-এর মধ্যে আছে। `/bangladesh` entry-card-এ closed white surface-এই বাংলাদেশ পতাকা ও folder/+ cue দৃশ্যমান, এবং public copy/metadata Bangladesh arrival guidance-এ সংশোধিত। Public Contact form consent-ভিত্তিক private lead storage-এ যুক্ত; owner review বিদ্যমান official OAuth ও server-side owner authorization-এর পিছনে থাকে।

এই release থেকে **কোনো traffic figure, GA4 result, sponsor/partner record, listing, owner data, backup outcome, DNS status, private Admin status, বা separate-project repair** দাবি করা হয় না।

## নিরাপত্তা সীমা

কোনো custom password, PIN, OTP, biometric, recovery code, client-side role bypass, private account access, personal-browser session, payment action, restore action বা control-room mutation ব্যবহার/তৈরি করা হয়নি। আলাদা project বা owner-controlled service-এর কাজ কেবল অনুমোদিত source/session ও প্রয়োজনীয় বাস্তব evidence পেলে করা যাবে।
