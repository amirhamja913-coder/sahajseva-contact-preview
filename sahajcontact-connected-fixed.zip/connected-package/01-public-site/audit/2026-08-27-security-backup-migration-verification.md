# SahajContact — Security, Backup, Migration ও Verification Audit

> **তারিখ:** ২৭ আগস্ট ২০২৬  
> **Scope:** বর্তমান `sahajseva-contact-preview` source, lockfile, public-safe validation evidence এবং non-sensitive documentation। এই report কোনো private owner account, Admin data, Analytics, DNS, payment account, external backup destination, production restore, or separate Control Room project খোলেনি।

## ১. Audit verdict

বর্তমান project-টি **migration-prepared এবং public-safe stability/security validation-এর জন্য প্রস্তুত**, কিন্তু **Manus-independent production, independently backed up, disaster-recovery verified, monitored, or capacity-certified নয়**। এই পার্থক্যটি গুরুত্বপূর্ণ: source repository, schema/migration, tests, public designs এবং runbook থাকার অর্থ external provider, database export, object-storage copy, OAuth replacement, verified restore drill, monitoring alert বা DNS cutover সম্পন্ন হওয়া নয়।

| বিষয় | Audit result | Evidence / সীমা |
|---|---|---|
| Existing public design protection | Current-source signed-out visual check passed | 1280px ও 375px desktop/mobile Home capture-এ original river/bridge map design, transparent tiger–water-lily accent এবং unobscured labels দেখা গেছে; `/bangladesh` capture-এ compact white entry-card-এর Bangladesh flag ও folder/+ cue, এবং cautious Bangladesh-arrival wording দেখা গেছে |
| Official Admin security boundary | Present | Official Manus OAuth + server-side owner authorization; no custom password/PIN/OTP/biometric/parallel login introduced |
| Public Contact privacy | Present | Consent-required write-only enquiry path, limited fields, optional email, sensitive credential/financial/NID content rejection, no public lead-read route |
| Owner/editor media upload hardening | Implemented and tested | Three upload mutations share server MIME allowlist, strict Base64 validation, and 20 MiB pre-/post-decode bound |
| Dependency posture | Improved, not clean | Production scan moved from `0 critical / 19 high / 47 moderate / 8 low` to `0 / 4 / 4 / 2`; residual chains are documented below |
| Independent backups / restore | Not verified | No external destination, database/media export, retention evidence, or clean-environment recovery drill was accessed or run |
| Monitoring / link health | Designed, not operating | No schedule, monitor account, health result, alert, or traffic metric has been fabricated or enabled |
| Capacity / 10,000+ users | Not verified | No authorised staging load test, target infrastructure, measured performance metric, or capacity certification exists |

## ২. Audit method and reproducible evidence

The audit followed **Audit → Fix → Test → Verify → Document**. Relevant code paths were read without inspecting secret values. The full regression command was `pnpm test -- --pool=forks --poolOptions.forks.singleFork=true`, which completed as **128 passed test files, 432 passed tests; 1 pre-existing skipped file and 4 skipped tests**. The focused media validation tests cover allowed bounded PNG data, MIME override rejection, PDF/common-video allowance for the broader owner-management path, malformed Base64, and oversized input handling. `pnpm check` and `pnpm build` completed after the helper/dependency update; build produced only the pre-existing chunk-size advisories. `git diff --check` passed after the documentation formatting repair.

Signed-out current-source screenshots were captured at 1280×720 and 375×812 for both `/` and `/bangladesh`. The Home capture shows the tiger and water lilies composited within the existing map card’s river-and-bridge scene—not as a separate card or duplicate landscape—while district labels remain readable. The Tourism capture shows the Bangladesh flag plus folder/+ cue on the closed white entry surface and its visible wording describes land arrival **into Bangladesh** with official-source verification language. These are current-source preview checks, not a claim that a new production checkpoint has already been published.

After publication of checkpoint `4ca8c6cd`, a signed-out production Home read-back at `https://sahajcontact-8xyxsefc.manus.space/` completed after hydration. The live viewport showed the existing river-and-small-bridge map composition, its transparent tiger/water-lily accent inside that composition, and visible district labels; no separate wildlife card or duplicate landscape was observed. This is visual public evidence only and does not access an Admin session, submit a contact form, or verify any external service.

A signed-out production read-back of `https://sahajcontact-8xyxsefc.manus.space/bangladesh` also completed after hydration. The live compact white Tourism entry surface visibly showed the green/red Bangladesh flag together with the folder icon and green `+` cue. The rendered page title and guidance stated that visitors should verify labelled official sources before travelling by land **into Bangladesh**, and expressly stated that SahajContact does not determine eligibility or guarantee entry, routes or transport. Public tourism cards loaded in the page; no protected dashboard, third-party account or form submission was opened.

The dependency scans were `pnpm audit --prod --json` against the installed production tree. These are time-sensitive registry advisories, not penetration tests. The before/after result is a measured scan result, but it does not mean exploitable reachability was tested in this application.

## ৩. Implemented safe improvement

The concrete source fix is `server/mediaUploadValidation.ts`. It is used by `premiumGallery.uploadAsset`, `personalGallery.upload`, and `gallery.uploadBase64`. The helper rejects an unallowlisted MIME type even when a Base64 data URL attempts to override the declared type; requires structurally valid Base64; rejects an empty payload; and checks size before decoding and after decoding. Image-only owner/editor flows remain restricted to JPEG, PNG, WebP and GIF. The broader gallery-management flow keeps its already-supported PDF and common video types (`MP4`, `WebM`, `QuickTime`) while applying the same structural/size guard.

> **What this does not establish:** file-signature validation, malware scanning, anti-virus quarantine, image re-encoding, content moderation, storage retention policy, or a guarantee against every denial-of-service/security issue. Those need separately selected infrastructure and policy.

| Area | Before | Change | Testable outcome |
|---|---|---|---|
| Data-URL MIME mismatch | Client-side declared type could be contradicted by a data URL reaching storage path | Server compares effective data-URL/declared MIME against a path-specific allowlist | Unsafe `image/svg+xml` mismatch is rejected |
| Malformed Base64 | No common strict decode contract across the reviewed upload mutations | Strict Base64 shape/length validation | Invalid payload returns a controlled validation error before storage write |
| Excessive payload allocation | Existing Zod fields did not provide one shared post-decode byte-size enforcement point | 20 MiB Base64-character and decoded-byte cap | Oversized payload is rejected before it is passed to object storage |
| Dependency advisories | 19 high / 47 moderate / 8 low in initial scan | Direct, source-used packages updated: Axios `1.20.0`, Nanoid `5.1.16`, Streamdown `1.6.11`, Drizzle ORM `0.45.2` | Re-scan: 4 high / 4 moderate / 2 low; 0 critical throughout |

## ৪. Residual dependency risk—no false “all fixed” statement

The remaining four high advisories are not silently patched because each requires a compatibility decision beyond a drop-in patch. `xlsx 0.18.5` is a direct dependency whose advisory feed did not offer a compatible registry target in the audit action list; it should be treated as untrusted-input sensitive and be replaced or upgraded only after its used import/export paths are reviewed. Express `4.21.2` retains `path-to-regexp 0.1.12`; resolving it normally requires an Express/framework migration review. Recharts `2.15.4` retains `lodash 4.17.21`; the current installed branch is deprecated and needs a visual/charting regression plan before a v3 migration. Therefore the residual result is an explicit security backlog, not a reason to invent a clean scan.

## ৫. Manus dependency and failure-impact matrix

| Current source/runtime dependency | Current role | If Manus service is unavailable | Provider-neutral replacement / prerequisite |
|---|---|---|---|
| Manus OAuth (`VITE_APP_ID`, OAuth server/portal configuration) | Current Admin sign-in callback, account identity and owner gate | Admin sign-in/identity flow can stop; public pages may still render | Select Auth.js/Keycloak/Supabase/other OIDC; rewrite callback/session integration; migrate approved owner identity and test non-owner denial |
| Manus Forge storage and `/manus-storage/*` | Managed public visual/media asset delivery and storage helper | Forge-hosted visual/media URLs may fail even on another web host | Export authorised media, checksum inventory, move to S3/R2/B2, update database/URL references and cache rules |
| Manus-managed database / `DATABASE_URL` | Application data and current internal content snapshots | Data access and write paths may fail | Managed MySQL/TiDB-compatible destination, least-privilege app user, encrypted export/import and restore drill |
| Manus scheduler/heartbeat | Existing scheduled feature trigger boundary | Scheduled reports/snapshots may not run | Managed cron/CI/VPS timer with signed, idempotent endpoint and separate execution/log ownership |
| Manus deployment/checkpoint/subdomain | Current build/publish and default public URL | Current Manus URL/deploy workflow unavailable | Target Node host, custom domain/DNS ownership, TLS, rollback release artifact and verified health checks |
| Forge notification/control helpers | Some server integration boundaries | Related notification/control features may be degraded | Select an independent notification provider or local queue/webhook and apply privacy/retention policy |

This matrix identifies code-level coupling only. It does not prove any external account, export permission, contract or DNS ability.

## ৬. Backup and disaster-recovery status

The source includes a database-resident, selected **public-content snapshot** routine and a corresponding restore routine. It captures certain public configuration/content and media metadata, not a full database, private lead data, account/session data, object bytes, secrets, provider configuration or external analytics. The restore routine replaces selected table contents in a transaction. Because it can delete/replace content, no restore was invoked for this audit.

| Required recovery layer | Current evidence | Status | Next responsible action |
|---|---|---|---|
| Source release | Git-managed source, lockfile, schema/migrations, tests and documentation exist | Partially prepared | Owner stores encrypted source archive/private repository copy and checksum off-platform |
| Database | Current application schema/migrations; no independent database dump or point-in-time recovery evidence inspected | Not verified | Owner selects destination/backup policy, exports through authorised provider, encrypts, records RPO/RTO, runs restore to isolated test DB |
| Media | Current asset URLs are Forge-hosted; no independent asset inventory/export verified | Not verified | Owner-authorised export to independent object storage plus URL/reference migration test |
| Secrets | Environment-variable names documented; values intentionally never read/exported | Not transferable by source alone | Owner creates fresh least-privilege secrets in target secret manager; rotate according to migration plan |
| OAuth identity | Current login is Manus-bound | Not independent | Owner chooses replacement identity provider and registers new callback/origin after security review |
| Recovery drill | No clean-environment restore executed | Not done | Execute scripted isolated restore with written approval, capture evidence and only then label verified |

For a real disaster, do not start by changing DNS. First establish the incident owner and status communication, preserve evidence, select a known-good source/database/media restore point, restore into an isolated environment, run the acceptance checklist, and only then make a reversible traffic decision. If current Manus service is unreachable and no external database/media/OAuth copy exists, this source code alone cannot recreate those provider-hosted assets or identities.

## ৭. Performance, scalability, monitoring and link-health plan

No performance capacity or availability value is asserted. Compression and input-bounds source features are not load-test results. A properly authorised staging plan should define functional traffic mix, database size, geography, target availability, peak concurrency and stop conditions before any test. Test metrics must include p50/p95/p99 latency, request/error rate, database connection/use, slow-query data, memory/CPU, cache hit rate, object-store behaviour and recovery time. Tests must avoid real users, real contact leads and public production load.

Monitoring has two approved-before-implementation patterns: a managed external uptime/link-health service, or a provider-neutral scheduled checker in a separately secured always-on/CI environment. Each needs a bounded allowlisted URL set, low-frequency cadence, timeout and redirect rules, signed callback/alert secret, recipient, retention window, incident owner and privacy policy. Neither is currently enabled; no alert, health record, uptime percentage, broken-link list or traffic number exists as audit evidence.

## ৮. Handover and cutover gate

The migration package should contain a checksummed source archive, private repository/tag, `pnpm-lock.yaml`, schema/migrations, non-secret environment manifest, media inventory, database export procedure, secret-rotation worksheet, OAuth conversion design, route/redirect manifest, deployment/rollback guide, restore drill log, load-test report and DNS cutover/rollback plan. Current source has the first group and documentation only. It lacks the owner-controlled target accounts, independent exports, replacement secrets/identity, staging evidence, operational measurements and DNS proof.

> **Readiness statement:** SahajContact is ready for a controlled external-migration preparation phase, not for a claim of completed independent hosting. The decisive gate is a successfully documented owner-authorised restore into an isolated target, followed by acceptance/security/load evidence and a reversible DNS plan.

## ৯. Non-sensitive next actions

1. Owner chooses a target host, managed database, object storage, identity provider and backup retention/RPO/RTO policy.
2. Owner authorises lawful database/media export and stores encrypted copies in independently controlled locations.
3. Engineering converts Manus OAuth/storage/scheduler hooks, installs fresh secrets, and runs source/database/media restore into staging.
4. Owner and engineering jointly execute Admin/public acceptance, performance/load and recovery drills without creating fake public records.
5. Only after evidence review should the owner schedule reversible DNS cutover and retain the existing Manus endpoint during rollback window.

## References

[1]: ../INDEPENDENT_HOSTING_AND_BACKUP_GUIDE_BN.md "SahajContact independent hosting and backup guide"
[2]: ./2026-08-27-final-brief-reconciliation.md "SahajContact final brief reconciliation"
[3]: ../../server/mediaUploadValidation.ts "Server media upload validation helper"
[4]: ../../server/db.ts "Content snapshot and restore implementation"
[5]: ../../package.json "Build, test and dependency manifest"
