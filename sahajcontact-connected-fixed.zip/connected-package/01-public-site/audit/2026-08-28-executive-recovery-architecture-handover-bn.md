# SahajContact — পৃথক Executive Owner Control Room ও Emergency Recovery & Operations Room: Architecture Handover

**তারিখ:** ২৮ আগস্ট ২০২৬
**লেখক:** Manus AI
**Scope:** Final Master Prompt Design PDF, বর্তমান SahajContact source code, এবং বিদ্যমান migration/backup audit থেকে প্রস্তুত একটি **design handover**। এটি কোনো নতুন private site, login, monitoring, backup destination, restore operation বা deployment তৈরি/চালু করে না।

> **মূল সিদ্ধান্ত:** Public Portal, বর্তমান Main Admin Control Center, ভবিষ্যৎ Executive Owner Control Room এবং ভবিষ্যৎ Emergency Recovery & Operations Room চারটি আলাদা trust boundary হবে। Executive বা Recovery room কখনো public portal-এর database, object storage, secrets, owner-browser session, OAuth cookie অথবা private lead data-তে সরাসরি access পাবে না।

## ১. Evidence basis ও বর্তমান অবস্থার সৎ সীমা

বর্তমান source-এ একটি protected Main Admin route এবং একটিমাত্র সীমিত signed server-to-server Control Room bridge পাওয়া যায়। Main Admin-এর owner authorisation server-side; OAuth session বা role browser থেকে বিশ্বাস করা হয় না। বর্তমান bridge-টি `siteId`, HMAC-SHA-256 signature, দুই মিনিটের timestamp window এবং strict patch parsing ব্যবহার করে। তবে source-এ কোনো আলাদা Executive owner site, Emergency Recovery site, external monitor, external backup destination, clean-environment restore drill, DNS failover বা independent deployment পাওয়া যায়নি। [1] [2] [3]

| বিষয় | বর্তমান evidence | সঠিক status | এই handover কী করে | কী দাবি করে না |
|---|---|---|---|---|
| Main Admin | `/admin/dashboard` ও server-side owner-only procedures আছে | Source-এ present; owner-side use unverified | Existing Admin boundary preserve করে | Owner session দিয়ে পরীক্ষা হয়েছে |
| Control Room bridge | Signed `GET` status ও signed `POST` site-controls route আছে | Narrow bridge only | Minimum integration baseline নির্ধারণ করে | আলাদা owner portal live/connected |
| Scheduled snapshot | Selected public-content JSON একই managed DB-তে রাখা হয় | Limited snapshot only | Full DR-এর gap স্পষ্ট করে | Full DB/media/secret backup |
| Restore helper | Selected table delete/replace transaction আছে | Destructive; not exercised | Future approval gate নির্ধারণ করে | Recovery verified বা safe-to-run |
| Executive/Recovery systems | আলাদা source/repository/deployment দেওয়া হয়নি | Not configured / not verified | Future project handover দেয় | Existing public project-এ গোপনে তৈরি হয়েছে |

এই সীমা ইচ্ছাকৃত। PDF-এর OCR-অস্পষ্ট label বা mockup-কে live system-এর প্রমাণ ধরা হয়নি। Public Home, নদী–ব্রিজ/map visual, Tourism UI, branding, URL, official OAuth, database এবং আলাদা Executive/Recovery ধারণা এই নথির মাধ্যমে পরিবর্তন করা হচ্ছে না। [4]

## ২. চার-সিস্টেম boundary ও data-flow design

প্রস্তাবিত architecture-এ Public Portal নিজ নিজ application database ও object storage ব্যবহার করবে। Main Admin একই portal-এর authorised content operation চালাবে; এটি Executive-এর বিকল্প নয়। Executive Owner Control Room হবে আলাদা private project/repository, যেখানে default access read-only aggregated operational status। Emergency Recovery & Operations Room-ও আলাদা private project/repository হবে এবং কেবল owner-authorised incident process, immutable evidence এবং external backup/restore readiness পরিচালনা করবে।

```mermaid
flowchart LR
  P[Public Portal\nSahajContact] -->|Public HTTPS only| V[Visitors]
  A[Main Admin Control Center\nexisting protected route] -->|Official OAuth + server-side permission| P
  E[Executive Owner Control Room\nfuture separate project] -->|Signed, allowlisted read-only status| B[Portal status adapter]
  E -. approved two-person action only .-> C[Future control-command adapter]
  R[Emergency Recovery & Operations Room\nfuture separate project] -->|Read-only incident / evidence status| I[External backup & incident inventory]
  R -. approved restore orchestration .-> S[Isolated staging restore target]
  B --> P
  C -. no direct database / storage / secret access .-> P
  I -. owner-controlled evidence only .-> R
```

| Boundary | Allowed communication | Explicitly prohibited | Reason |
|---|---|---|---|
| Public Portal → Executive | Minimised, signed operational status labels | Browser cookies, raw user rows, private leads, DB credentials, storage credentials | Separate blast radius and privacy minimisation |
| Executive → Portal | Future allowlisted signed command through a dedicated adapter after approval | Direct SQL, direct object deletion, secret read/write, arbitrary API proxying | Control room must not become a privileged bypass |
| Recovery → backups | Owner-authorised inventory/checksum/restore-evidence references | Rendering or storing secret values, automatic production restore, unapproved data export | Recovery evidence must not create a second secret/data leak |
| Recovery → staging | Explicit owner-approved isolated restore workflow | Production database replacement, DNS switch, account takeover | A restore is destructive and needs test isolation |
| Main Admin ↔ Executive/Recovery | No implicit shared login or session | Copying OAuth session, adding PIN/password/OTP/biometric/recovery-code login | Official authentication and server-side permission boundary remains intact |

## ৩. Future Executive Owner Control Room — architecture choice

Executive room-এর প্রধান কাজ হবে owner-কে বিভ্রান্তিকর dashboard সংখ্যা ছাড়া একটি conservative operational view দেওয়া। প্রথম release-এ এটি private, mobile-friendly এবং default read-only হওয়া উচিত। UI-তে **Not configured**, **Not connected**, **Not verified** এবং **Owner action required** আলাদা state হিসেবে দেখা যাবে; এগুলো কোনো real uptime, backup health বা traffic metric বোঝাবে না, যতক্ষণ না timestamped evidence পাওয়া যায়।

| Design area | Required future choice | Initial safe design | Must not do |
|---|---|---|---|
| Project boundary | Distinct repository/project and distinct deployment record | Public project থেকে আলাদা source, release history ও access policy | Existing `/admin` route-কে গোপনে Executive বানানো |
| Identity | Provider-neutral identity migration plan selected by owner | Future OIDC-compatible identity; least-privilege roles and owner approver | New custom password/PIN/OTP/biometric/recovery-code flow |
| Portal integration | Signed status adapter with fixed response schema | Read-only `GET` with service-level HMAC or short-lived mTLS/OIDC credential; replay protection | Browser OAuth cookie forwarding or frontend-held secret |
| Status content | Non-sensitive aggregated labels only | `serviceState`, `observedAt`, `evidenceClass`, `maintenanceMode`, selected feature booleans | Private lead/user data, raw stack traces, secret names/values |
| Command capability | Delayed until threat model + two-person approval is accepted | No write command in initial release | SQL, delete, restore, DNS, secret, OAuth or arbitrary feature access |
| Auditability | Immutable append-only events | Each view, decision and approved action has actor/when/why/evidence hash | Editable activity history without provenance |
| Availability view | Explicit source-of-truth and expiry policy | “Not verified” when adapter or monitor evidence is absent/stale | Green/healthy badge based on no data |

### ৩.১ বর্তমান signed bridge: compatible baseline, not a complete Executive room

বর্তমান `GET /api/control-room/v1/status` এবং `POST /api/control-room/v1/site-controls` route browser cookie নেয় না; signed server-to-server request ছাড়া এগুলো 401/503 দেয়। Status response-এ বর্তমানে site id, maintenance mode/message, চারটি boolean feature flag, last update time ও update source থাকে। Write patch শুধু `maintenanceMode`, সর্বোচ্চ 280-character maintenance message এবং `sms`, `signup`, `payment`, `login` boolean নেয়; save হওয়ার পরে operational log লেখা হয়। [1] [2]

এটি একটি useful bounded integration pattern, কিন্তু Executive Control Room নয়। এই bridge-এ identity lifecycle, role delegation, independent private UI, owner approval workflow, external uptime verification, secret rotation workflow, backup inventory, restore drill, command rollback, rate policy বা deployment evidence নেই। বর্তমান `POST` route এই handover-এর অংশ হিসেবে call করা হয়নি এবং করা যাবে না।

### ৩.২ Minimum read-only status contract

Future Executive release প্রথমে এই ধরনের narrow, versioned response-এ সীমাবদ্ধ থাকবে। সব field-ই non-secret এবং false health এড়াতে evidence-aware:

```json
{
  "contractVersion": "1",
  "serviceId": "sahajcontact",
  "observedAt": "2026-08-28T00:00:00.000Z",
  "serviceState": "unknown",
  "evidenceClass": "not_verified",
  "maintenance": { "declared": false, "messagePresent": false },
  "capabilities": {
    "statusRead": true,
    "commandWrite": "not_enabled",
    "externalBackup": "not_connected",
    "externalMonitor": "not_configured"
  },
  "evidenceRef": null
}
```

| Field | Permitted value / meaning | Privacy and truth rule |
|---|---|---|
| `serviceState` | `unknown`, `maintenance_declared`, `degraded_reported`, `available_observed` | `available_observed` only with timestamped authorised evidence; it is not a capacity promise |
| `evidenceClass` | `not_configured`, `not_connected`, `not_verified`, `owner_action_required`, `observed` | No `healthy` synonym without evidence source, time and expiry |
| `observedAt` | ISO UTC time for the actual source observation | Omit/`null` when nothing was observed; never synthesize now-time |
| `maintenance` | Declared configuration state, not a physical availability probe | Do not expose free-text config or secrets |
| `capabilities` | Capability state, not credential state | Never report secret presence/value or database reachability details |
| `evidenceRef` | Opaque audit event ID or approved document checksum | No URL/token containing private details |

## ৪. Future Emergency Recovery & Operations Room — architecture choice

Recovery room-এর role operational recovery evidence দেখানো এবং owner-approved staged restore পরিচালনা করা। এটি public system-এর backup data warehouse নয়, direct database console নয় এবং one-click production restore button নয়। Authoritative backup storage, encryption/key ownership, retention policy এবং alert destination owner-controlled external environment-এ নির্ধারিত না হওয়া পর্যন্ত recovery state হবে **Not configured** অথবা **Owner action required**।

| Design area | Required future choice | Initial safe design | Must not do |
|---|---|---|---|
| Project boundary | Executive থেকেও পৃথক private repository/project | Separate incident UI and audit store; no shared privileged browser session | Current public portal/database-এর ভিতরে recovery console বসানো |
| Authoritative backup | Owner-selected external source, DB, media and configuration inventory | Only inventory metadata/checksum/time/retention state | Same managed DB snapshot-কে independent full backup বলা |
| Data scope | Source, database, media/object bytes, configuration manifest and integration recovery plan | Per-component coverage status with evidence reference | Secrets or raw private data Recovery UI-তে দেখানো |
| Restore target | Isolated staging environment before any controlled cutover | Disposable staging DB/storage and allowlisted test account | Direct production overwrite or automatic DNS change |
| Incident modes | Declared operational modes with approval records | `normal`, `maintenance_declared`, `read_only_declared`, `emergency_assessment`, `restore_staging`, `cutover_pending` | Mode label দেখে access control bypass করা |
| Production action | Explicit owner confirmation after staged acceptance | Two-person, time-bound, recorded approval | Single-click restore, recovery-code bypass or automated live restore |
| Recovery verification | Timestamped restore drill and acceptance evidence | `not_verified` until a real isolated drill passes | RPO/RTO, full DR or backup completeness claim without evidence |

### ৪.১ বর্তমান snapshot-এর বাস্তব সীমা

বর্তমান helper selected public settings, quick links, announcement, blog posts, media-file metadata, folders এবং Tourism-related structured records JSON-এ নেয়। দৈনিক scheduled snapshot একই managed database-এ লেখা হয়। বর্তমান restore helper settings update এবং selected content tables delete/replace করে; helper-এ `mediaFiles` snapshot-এ দেখা গেলেও visible restore flow raw object bytes বা full database restore করে না। [3] [5]

অতএব বর্তমান snapshot-এ private contact leads, users/sessions, operational/audit/security records, uploaded asset bytes, external/provider configuration, secrets এবং third-party state পূর্ণভাবে অন্তর্ভুক্ত—এমন evidence নেই। একই managed database-এ থাকা এই content snapshot-এর restore destructive। এই handover-এ কোনো snapshot তৈরি, schedule পরিবর্তন, export, restore, database write বা production recovery চালানো হয়নি। [3] [5]

## ৫. Immutable audit-event model (proposed, not implemented)

Executive ও Recovery দুইটি system-ই আলাদা append-only audit-event store ব্যবহার করবে। Operational event নিজে source of truth নয়; বরং কে কখন কী evidence দেখে কী সিদ্ধান্ত নিয়েছে তার tamper-evident record। Event update/delete নিষিদ্ধ; correction হলে `supersedesEventId`-সহ নতুন event হবে। Hash chaining বা WORM-capable storage owner-selected design stage-এ মূল্যায়ন হবে।

| Field | Purpose | Data-minimisation rule |
|---|---|---|
| `eventId` | Immutable opaque identifier | Sequential public ID বা email নয় |
| `occurredAt` | UTC event time | Server-generated only |
| `system` | `executive` / `recovery` / `portal-adapter` | Fixed enum |
| `eventType` | `status_observed`, `incident_opened`, `approval_requested`, `approval_granted`, `restore_staging_started`, `acceptance_recorded`, `cutover_cancelled` | Fixed allowlist; no arbitrary unreviewed action label |
| `actorRef` | Pseudonymous authorised actor reference | No password, OTP, device fingerprint or raw external identity in UI |
| `authorizationRef` | Role/approval policy version and opaque decision ID | No session cookie or credential material |
| `targetRef` | Service/component/backup manifest opaque ID | No database URL, bucket name or secret path |
| `evidenceDigest` | SHA-256 or equivalent digest of approved report/manifest | Raw sensitive export never embedded |
| `outcome` | `recorded`, `rejected`, `awaiting_owner`, `staged_passed`, `staged_failed` | Never infer success from missing evidence |
| `supersedesEventId` | Correction chain | Only a new append event may link it |

## ৬. Recovery state model: labels are policy, not fabricated telemetry

নিচের state-গুলো future UI-র wording contract। এগুলো এখনকার live dashboard data নয় এবং কোনো “green” status তৈরি করে না।

| State | Permitted display meaning | Required evidence before advancing | Forbidden interpretation |
|---|---|---|---|
| `not_configured` | Owner এখনো provider/policy/target নির্ধারণ করেননি | Written architecture choice | Backup failed or backup exists |
| `not_connected` | Approved provider chosen হলেও integration credentials/allowlist connect হয়নি | Connection evidence without exposing secret | External service is unsafe |
| `not_verified` | A record/setting exists, but no accepted test evidence | Timestamped drill/monitor result | Healthy, complete, recoverable |
| `owner_action_required` | Approval, account action, destination or data-export authority দরকার | Named owner decision/approval | AI may proceed unilaterally |
| `maintenance_declared` | Maintenance flag/notice was intentionally declared | Signed configuration evidence | Physical availability confirmed |
| `read_only_declared` | Write operations are intentionally paused by approved policy | Policy and adapter evidence | Database is immutable or backed up |
| `emergency_assessment` | Incident is being evaluated | Incident event and owner approver | Restore has started |
| `restore_staging` | Isolated test restore is in progress | Approved scope + staging target | Production data has been restored |
| `cutover_pending` | Staging acceptance passed; owner decision remains | Acceptance evidence + rollback plan | DNS/provider switch happened |

## ৭. Security controls before any write-capable integration

Write access, if ever approved, must be a separate milestone from the read-only Executive release. The integration will need fixed allowed actions, detached/short-lived credentials, replay defence, payload validation, idempotency key, rate limit, allowlisted target service, dual approval, independent audit event, safe rollback procedure and a documented emergency stop. Every privileged command must fail closed when signature, timestamp, role, approval or target scope is absent.

| Control | Required implementation evidence | Current source relationship |
|---|---|---|
| Server-to-server authentication | Signed or workload identity request with bounded validity and replay control | Current bridge has HMAC + two-minute timestamp window [1] |
| Command allowlist | Versioned finite action schema; no arbitrary request body | Current bridge has a four-flag plus maintenance patch only [1] |
| Least privilege | Dedicated adapter can only perform its one approved action set | Current bridge writes selected content settings, not direct SQL from external caller [1] |
| Dual approval | Initiator and independent owner approver both recorded | Not implemented / not verified |
| Safe defaults | Read-only by default; emergency action starts disabled | This handover proposes it; it does not change live controls |
| Audit integrity | Append-only event and evidence digest | Current portal operational log is useful but not an independent immutable audit store [1] |
| Secret hygiene | Secret manager only; browser/UI never receives raw secret; rotation plan | Existing source resolves bridge secret server-side and avoids return in API response [2] |

## ৮. Non-goals and implementation prohibition for this milestone

এই document milestone-এ কোনো separate Executive/Recovery repository, private URL, deployment, custom authentication, user table, schema migration, database write, webhook, monitor, scheduler, backup export, restore action, DNS change, analytics connection, payment change বা Control Room POST তৈরি/ব্যবহৃত হয়নি। কোনো owner credential, secret, account, Admin record বা private lead খোলা হয়নি।

পরবর্তী implementation কেবল তখনই শুরু করা যাবে যখন এই নথির পরের gate-এ তালিকাভুক্ত owner-authorised input, separate source/deployment decision এবং test environment পাওয়া যাবে। তখনও প্রথম implementation হবে read-only, evidence-labelled এবং least-privilege; public portal বা Main Admin redesign নয়।

## ৯. Minimum authorised inputs: implementation gate

নিচের প্রতিটি input বাস্তবে owner-authorised না হওয়া পর্যন্ত Executive বা Recovery system implement/connect করার কাজ **বন্ধ থাকবে**। এটি দেরি নয়; private credential, public site, backup data ও owner authority সুরক্ষার জন্য প্রয়োজনীয় gate। Password, PIN, OTP, biometric, recovery code, database URL, raw secret, browser cookie বা personal login কখনো chat-এ পাঠাবেন না। প্রয়োজনে owner-controlled secret manager, approved project setting বা provider console ব্যবহার করতে হবে।

| প্রয়োজনীয় input / সিদ্ধান্ত | কে দেবেন বা অনুমোদন করবেন | এখনকার status | নিরাপদ evidence format | না থাকলে কী হবে |
|---|---|---|---|---|
| Executive-এর পৃথক repository/project attachment বা approved empty project | Owner | Not provided | Repository reference, project attachment বা written boundary approval | নতুন private portal তৈরি করা হবে না |
| Recovery-এর পৃথক repository/project attachment বা approved empty project | Owner | Not provided | Repository reference, project attachment বা written boundary approval | Recovery UI/source তৈরি করা হবে না |
| Target hosting ownership ও environment boundary | Owner | Not selected | Provider name, environment labels, operator roles; secret values নয় | Deployment/hosting claim করা হবে না |
| Future identity provider | Owner | Not selected | OIDC/provider choice, callback ownership, roles | Custom password/PIN/OTP shortcut করা হবে না |
| Signed adapter identity and action scope | Owner + security approver | Not approved | Allowlisted status fields and fixed command list | Read-only status beyond current narrow bridge connect করা হবে না |
| External backup destination and retention | Owner | Not selected | Destination category, retention, encryption/key-owner policy | Full-backup/DR status `not_configured` থাকবে |
| Authorised DB export process and media export process | Owner + data custodian | Not authorised | Export runbook, manifest, checksum evidence | Data/media export বা restore চালানো হবে না |
| Isolated staging restore environment | Owner + hosting operator | Not provided | Staging endpoint, disposable DB/storage classification | Restore drill বা production cutover করা হবে না |
| Named incident approver and deputy | Owner | Not named | Role label and approval policy; personal secret নয় | Emergency change/restore decision নেওয়া হবে না |
| DNS/cutover and rollback owner | Owner | Not assigned | Named operator role + rollback authority | DNS/failover/cutover হবে না |
| Allowed status fields and privacy policy | Owner + privacy/security approver | Not approved | Field allowlist and retention rule | Executive UI-তে status data publish হবে না |
| Monitoring recipients, retention and escalation window | Owner | Not selected | Recipient roles/address mechanism without credentials | Monitor/schedule/alert চালু হবে না |
| RPO/RTO policy and accepted service level | Owner + business approver | Not accepted | Written target ranges and business priority | Recovery promise বা capacity target বলা হবে না |

### ৯.১ Authorisation record: minimum form

প্রতিটি owner decision-এর জন্য একটিমাত্র non-secret record যথেষ্ট: decision ID, scope, approver role, approval time (UTC), expiry/review date, permitted target and rollback owner। Record-এ password, token, backup archive URL, database address, individual private email content বা real customer data থাকবে না। কোনো ambiguous “সব কিছুর access” approval scope হিসেবে গ্রহণ করা যাবে না।

| Decision ID | Scope | Approver role | Expiry / review | Required constrained wording |
|---|---|---|---|---|
| `EXEC-READ-001` | Executive read-only status adapter | Owner + security approver | ≤ 90 days or policy cycle | “Only enumerated non-sensitive status fields” |
| `REC-DRILL-001` | Isolated staging restore drill | Owner + data custodian | One drill window | “No production overwrite; test data isolation required” |
| `REC-CUTOVER-001` | Production cutover evaluation | Owner + designated deputy | Single incident/release | “Only after staged acceptance and rollback readiness” |

## ১০. Monitoring and scheduled checking: two owner-selectable options

এই repository-তে নতুন monitor, external provider, recurring schedule বা high-frequency polling চালু করা হয়নি। Current scheduled endpoints থাকলেও এগুলো Executive/Recovery health monitor নয়। Future monitoring-এর জন্য অন্তত নিচের দুইটি user-facing option owner বেছে নেবেন। কোনো option এখন নির্বাচন, connect বা bill করা হয়নি। [2] [5] [6]

| Option | কীভাবে চলবে | সুবিধা | trade-off / setup | Cost posture | Minimum accepted configuration |
|---|---|---|---|---|---|
| **A. Managed external uptime/link monitor** | Owner-selected external provider থেকে public homepage, allowlisted critical routes, TLS expiry এবং approved links low-frequency check | Public app/provider outage হলেও আলাদা signal পাওয়ার সুযোগ; কম engineering maintenance | Owner account, monitored route list, alert recipient, privacy/retention policy ও provider settings দরকার; external service trust যোগ হয় | Provider policy অনুযায়ী free/paid tier হতে পারে; commit করার আগে owner plan approve করবেন | Interval, timeout, redirect policy, failure threshold, maintenance suppression, alert recipient role, retention and escalation owner |
| **B. Separately hosted low-frequency checker** | Separate owner-controlled WebDev/Reserved, VM, CI or equivalent scheduler থেকে allowlisted HTTP/TLS checks এবং signed alert webhook | Control ও provider-neutral migration path বেশি; custom evidence/audit policy সম্ভব | Runtime, scheduler, secret manager, allowlisted egress, logs, rate-limit, on-call and patching responsibility দরকার | Existing service বা additional hosting/scheduler cost হতে পারে; target নির্বাচনের আগে cost review দরকার | Signed target list, idempotent jobs, conservative interval, alert policy, log retention, disaster stop switch and ownership |

দুই option-ই **low-frequency, allowlisted এবং privacy-minimised** হতে হবে। Monitor response body থেকে private record, HTML form value, cookie, secret বা user data সংগ্রহ/সংরক্ষণ করা যাবে না। Monitor failure নিজে outage proof নয়; তা `degraded_reported` evidence হতে পারে এবং independent confirmation প্রয়োজন। Scheduled work লিখতে বা চালু করতে হলে owner-approved interval, monitoring policy, retention, budget/plan এবং recipient role লিখিত থাকতে হবে। [5] [6]

## ১১. Authoritative backup and recovery evidence inventory

Full recovery বলতে source, database, media/object bytes, configuration manifest, identity/integration recovery plan এবং tested restore evidence-এর একটি consistent authorised set বোঝায়। বর্তমান selected public-content snapshot এই set-এর substitute নয়। Current guide-ও একটি independent destination, fresh least-privilege secrets এবং clean staged restore drill ছাড়া migration/DR claim না করার নির্দেশ দেয়। [3] [5]

| Component | Authoritative future evidence | Presently evidenced in this project | Current readiness label | Required owner action before DR claim |
|---|---|---|---|---|
| Source code | Private repository commit/tag, release archive checksum, lockfile | Current source and lockfile exist | `not_verified` for independent recovery | Approve repository/backup retention and test checkout |
| Database | Authorised encrypted external backup, retention and restore manifest | Managed DB use and limited selected-content snapshot only | `not_configured` as full external DB backup | Choose target, authorise export, retain manifest and run staging restore |
| Media/object bytes | Export manifest, checksum, object inventory, restore test | Some media metadata are in selected snapshot; raw bytes not evidenced | `not_configured` | Choose object backup destination and authorised export method |
| Non-secret configuration | Versioned environment-variable manifest, route/DNS/callback inventory | Some source-level dependency documentation exists | `not_verified` | Approve target configuration inventory; do not disclose secret values |
| Secrets and keys | External secret-manager recovery policy, access/rotation owner | Existing server-side secret usage only | `owner_action_required` | Select secret manager and emergency rotation policy; never export values in chat |
| Identity/OAuth | Provider-neutral migration and callback/session test plan | Existing official OAuth boundary only | `not_configured` for independent identity | Owner chooses identity provider and stages test account policy |
| External integrations | Per-service restore/disable/rotation runbook | No external owner accounts inspected | `owner_action_required` | Authorise inventory and accountable operator, not credentials in chat |
| DNS / traffic cutover | Record inventory, TTL plan, reversible rollback instruction | No DNS access/evidence | `owner_action_required` | Assign DNS operator and approve cutover/rollback window |
| Recovery drill | Timestamped staging report plus public/admin acceptance evidence | No drill executed | `not_verified` | Provide isolated staging target and authorise a bounded drill |

## ১২. Restore workflow and hard approval gate

Restore workflow একটিমাত্র controlled sequence। কোনো step skip করা যাবে না এবং `cutover_pending` কখনো automatic live change trigger করবে না। বর্তমান helper selected tables delete/replace করতে পারে বলে, current portal-এর restore function-ও only explicit evidence and owner confirmation-এর পরে separate reviewed execution হিসেবে বিবেচ্য; এই handover সেটি চালায়নি। [3] [5]

| ক্রম | Stage | Required evidence / owner approval | Output | Stop / rollback condition |
|---|---|---|---|---|
| ১ | **Scope** | Incident ID, affected components, data sensitivity classification, named owner approver | Approved recovery scope | Missing or ambiguous scope → stop |
| ২ | **Integrity** | Backup manifest, checksum/signature, retention and source-time review | Validity result marked observed/failed | Manifest missing/mismatch/stale beyond policy → stop |
| ৩ | **Owner confirmation** | Time-bound explicit authorisation for *staging only* | Approval event | No approval, expired approval or wrong target → stop |
| ৪ | **Isolated staging restore** | Disposable staging DB/storage, no production DNS, restricted test account | Restore event and technical logs | Write reaches production or isolation fails → stop and preserve evidence |
| ৫ | **Health and acceptance** | Public route, protected Admin access-control, media, data integrity, security and rollback checks | Signed acceptance matrix | Any critical failure or missing evidence → no cutover |
| ৬ | **Controlled cutover decision** | Two-person approval, user communication plan, DNS/traffic rollback owner, monitoring window | `cutover_pending` decision only | DNS/traffic action has not happened yet |
| ৭ | **Controlled cutover** | Owner executes/presides; observe agreed metrics | Timestamped cutover record | Threshold breach → execute documented rollback |
| ৮ | **Post-incident review** | Immutable event review, retention review, action items | Closed incident only after owner acceptance | Gaps remain → retain `not_verified` for affected capability |

## ১৩. Acceptance matrix for a future authorised implementation

No Executive or Recovery system should be presented as “ready”, “connected”, “healthy”, “recovered” or “full backup enabled” until its relevant row below has timestamped evidence. This matrix is deliberately stricter than a UI screenshot; it requires security, behaviour and recovery proof.

| Area | Acceptance test | Minimum pass evidence | Status before test |
|---|---|---|---|
| Separate boundary | Executive/Recovery are different project/repository/deployment records from Public Portal/Main Admin | Repository and deployment identifiers; no shared browser session or secret exposure | Not started |
| Identity | Non-owner denied; approved owner role is least-privilege; logout/session expiry works | Controlled test report; server-side enforcement evidence | Not started |
| Read-only adapter | Only enumerated non-sensitive status fields return; invalid signature/replay/unknown fields fail closed | Automated contract tests and authorised environment log | Not started |
| No bypass | UI has no DB console, storage browser, raw secret viewer or arbitrary request proxy | Source review and negative tests | Not started |
| Audit model | Each event append-only, actor/approval/evidence links retained; correction does not mutate original | Audit-store test report | Not started |
| Monitoring | Owner-selected option checks only allowlisted targets at approved rate; alert recipient receives test alert | Provider/runtime configuration and test evidence | Not selected |
| Backup coverage | Source/DB/media/config/identity/integration inventory all have authoritative evidence | Approved manifest with component coverage status | Not configured |
| Staging restore | Isolated restore completes; data/media/config acceptance passes | Timestamped drill report and checksum comparison | Not verified |
| Public acceptance | Existing Home map/river–bridge, Tourism, branding and URLs remain intact after affected releases | Signed-out desktop/mobile public test evidence | Not started for separate deployment |
| Admin acceptance | Official auth and server-side owner permission still guard Main Admin; no cross-system login shortcut | Owner-authorised test evidence | Not started |
| Cutover safety | DNS/traffic change is reversible and owner-operated; rollback rehearsed | Written rollback plan and exercise evidence | Not started |

## ১৪. Recommended implementation sequence after the gate passes

First build only the **separate read-only Executive status surface** with the status contract, identity choice and audit model approved. Next establish Recovery as evidence/inventory management, not restore execution. Only after an external authoritative backup exists and an isolated staging drill passes may a limited restore orchestration capability be designed. A future write-capable control command requires a new threat model, separate approval and independent tests; it must not be bundled with the initial dashboard.

This sequence preserves the user’s instruction to keep the existing SahajContact design, river–bridge/map visual, Tourism experience, branding, URLs, official OAuth Admin boundary, database and public functionality stable. It also keeps all owner-controlled external decisions visibly unresolved rather than manufacturing a live status.

## References

[1]: ../server/controlRoomBridge.ts "Current signed Control Room bridge source"
[2]: ../server/_core/index.ts "Current signed routes and scheduled snapshot endpoint source"
[3]: ../server/db.ts "Current public-content snapshot and destructive restore helper source"
[4]: 2026-08-28-final-master-prompt-design-reconciliation.md "Final Master Prompt PDF reconciliation"
[5]: ../INDEPENDENT_HOSTING_AND_BACKUP_GUIDE_BN.md "Provider-neutral hosting, backup and monitoring handover guide"
[6]: ../../skills/automation-and-scheduling/SKILL.md "Automation and scheduled-work safeguards"
