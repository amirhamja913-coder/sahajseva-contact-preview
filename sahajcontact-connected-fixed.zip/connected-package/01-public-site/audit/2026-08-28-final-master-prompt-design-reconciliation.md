# SahajContact Final Master Prompt Design — Current-Project Reconciliation

**Source reviewed:** `/home/ubuntu/upload/SahajContact_Final_Master_Prompt_Design.pdf` (6 pages), current synced project source, and signed-out public preview.  
**Scope:** This record treats the PDF as an **ecosystem design brief**. It does not treat mockup labels, inaccessible private panels, or OCR-corrupted text as proof that a feature exists or is live.

## 1. Evidence basis and preservation decision

The PDF’s readable intent is a public website plus three control surfaces: **Main Admin Control Center**, **Executive Owner Control Room**, and **Emergency Recovery & Operations Control Room**. It also calls for mobile-first operation, a universal Back pattern, regression testing, no fabricated live metrics, and a controlled disaster-recovery process.

The current source has a public site, `/admin/dashboard`, and `/admin/site-builder` routes. The dashboard imports content, gallery, appearance, theme, SEO, lead, analytics, health, log and backup-related panels. The signed-out browser was used only to check the public Home and Tourism pages; it was **not** used to access an owner session or private data. The public production verification record remains at checkpoint `515d2f09`; a later, separately released Stage A same-page Main Admin return control is recorded at checkpoint `b41b0f2c`.

> **Preservation decision:** No Home, river–bridge map, tiger–water-lily overlay, Tourism entry-card, logo, branding, public URL, Login/Profile, Admin, data model, or API behaviour is redesigned or deleted under this reconciliation. The PDF is not a reason to replace the verified public experience.

| Current public evidence | Verification method | Result |
|---|---|---|
| Home river–bridge map and tiger–water-lily placement | Signed-out desktop and 375px source preview; earlier signed-out live read-back recorded in checkpoint `515d2f09` | The wildlife remains composited inside the existing map card rather than appearing as a separate visual surface; public map labels remain visible. |
| Tourism entry and guidance | Signed-out desktop and 375px source preview; earlier signed-out live read-back recorded in checkpoint `515d2f09` | Compact white entry surface retains Bangladesh flag plus folder/+ cue. Visitor wording remains cautious guidance for land arrival **into Bangladesh**. |
| Login / owner boundary | Current routing and previous source audit only | Public routing keeps Admin as an existing protected surface. No custom password, PIN, OTP, biometric or recovery-code path is proposed or added. |

## 2. PDF requirements against current evidence

| PDF design requirement | Current-source evidence | Evidence-based status | Safe conclusion / next boundary |
|---|---|---|---|
| Public Website retained separately | Public routes and current components remain in the app; signed-out preview validated primary public pages | **Partially evidenced** | Public site is present and its protected visual elements are preserved. Full page-by-page owner workflow was not re-run in this sync pass. |
| Main Admin Control Center | `/admin/dashboard` and `/admin/site-builder` exist; `AdminAnalyticsDashboard` imports multiple management panels | **Present in current source; private operation unverified** | The existing Admin surface should be refined in place, not duplicated. Owner-only UI and data were not opened. |
| Executive Owner Control Room | Current source exposes a signed Control Room bridge, but no separately deployed Executive Owner project/source was available | **Not verified as a separate system; architecture handover prepared** | The handover defines a separate repository/project, provider-neutral future identity, signed read-only status, no DB/storage/secret bypass and immutable audit evidence. It is not a live independent owner room. |
| Emergency Recovery & Operations Room | Current server has limited status/maintenance and scheduled recovery-snapshot paths; current bridge can set maintenance and feature flags through a signed request | **Partial source capability; architecture handover prepared** | Existing snapshot scope is not a complete database/media/configuration backup or an independently verified recovery room. The handover defines external backup inventory and an isolated, owner-approved restore gate; neither is connected or tested. |
| Universal Back Button | The public app has normal browser navigation and a Back-to-Top component. Main Admin navigation now has a scoped same-page `ড্যাশবোর্ডে ফিরুন` control which calls the established section-scroll helper to return to `#admin-overview`. | **Partially implemented in Main Admin; owner-side use unverified** | This release is not a universal browser-history Back control across all dashboard/list/detail/edit/settings/report/gallery flows. It has not changed URL, OAuth, permissions or owner access. |
| Content / Tourist / Gallery live operations | Dashboard source includes relevant query and management components; public Tourism is verified | **Partial; owner-side CRUD unverified** | Do not claim Add/Edit/Delete/Hide/Show/Reorder/Public Sync completed until authorised owner-side test evidence exists. |
| Users, roles and security | Official OAuth + server-side authorization and owner-only procedures are current boundaries; dashboard source includes member/role queries | **Partial; privileged operation unverified** | Retain current authentication boundary. No secondary personal credential flow may be created. |
| Analytics, system/backup/security status | Components and queries may exist, but no authorised GA4, hosting, backup destination, alerting or monitoring account was opened | **Not verified** | Use “Not Connected”, “Not Verified” or “Owner Action Required”, never fabricated metrics/status. |
| Backup and full system recovery | Existing documents provide a provider-neutral plan; no external backup destination, restore test or external hosting cutover was authorised | **Prepared only** | The recovery runbook is documentation, not completed recovery. Owner-controlled storage, database export, media export, checksum/retention policy, isolated restore drill and acceptance evidence are required. |
| Mobile-first and regression testing | Signed-out desktop/375px public preview completed; prior full test/type/build results are documented in the security milestone | **Partial** | Public scope received evidence. Owner-only desktop/mobile flows still need authorised testing. |

## 3. Current Control Room boundary

The project contains a signed bridge with a site identifier, an HMAC request signature, a two-minute timestamp window, strict patch parsing, and a short maintenance-message bound. Its currently declared control surface is limited to maintenance mode plus SMS, signup, payment and login feature flags. The server records changes as a Control Room update.

This is **not** proof that a separate Executive or Emergency site is deployed, connected, staffed, continuously monitored, or able to restore the entire service. The corresponding shared secret and external counterpart are owner-controlled and were neither viewed nor modified. The Emergency/Recovery mockup in the PDF must therefore remain a separate, staged delivery rather than an implicit change to this public project.

## 4. Required design compatibility decisions

The PDF has a dark, teal-accent control-room visual direction. That direction can be limited to future **separate private control surfaces** or carefully scoped existing Admin panels. It must not trigger an unrequested global redesign of the public “নদীর পথ” public experience.

The PDF visibly contains the legacy phrase “Transport & India Guide”. It does not override the currently verified public tourism safety language. Any future internal manager rename must preserve existing stored data and public routes, while public copy continues to describe cautious land arrival into Bangladesh and asks visitors to confirm live official information.

| Boundary | Permitted in a later scoped implementation | Not permitted without independent evidence/authorisation |
|---|---|---|
| Main Admin | Usability inventory, responsive navigation audit, non-destructive Back-button proposal, source-backed panel mapping | Opening private data or changing owner access based on assumptions |
| Executive Owner Room | Separate architecture/repository plan with signed, least-privilege integration contract | Pretending the current bridge is a deployed independent owner system |
| Emergency / Recovery | Read-only status schema, recovery-runbook UI design, immutable audit-event model, staging restore acceptance checklist | Performing a restore, exposing secrets, live server access, or claiming recovery is verified |
| Public portal | Preserve verified visual/UI behaviour; public source-based testing | Replacing the map/Tourism design or changing official OAuth to meet a mockup |

## 5. Stage A and separate-system handover update

**Stage A is now implemented narrowly in the existing Main Admin:** checkpoint `b41b0f2c` adds the accessible same-page `ড্যাশবোর্ডে ফিরুন` control in `AdminWorkspaceNavigation`. The focused source-contract test and full release validation are recorded with that checkpoint. This does not establish owner-session acceptance because the protected owner Admin account was not opened; it also is not a new login, route or cross-system navigation mechanism.

The detailed follow-on design is now preserved in [Executive and Recovery Architecture Handover (Bengali)](2026-08-28-executive-recovery-architecture-handover-bn.md). It records the future-system trust boundaries, narrow status contract, immutable audit-event proposal, no-direct-access rule, monitoring choices, authoritative-backup inventory, staged restore flow, and owner-authorised inputs/acceptance evidence. It deliberately classifies the separate systems as **not configured / not connected / not verified** where no external evidence exists.

## 6. Recommended staged next work

1. **Stage A follow-up — owner-side acceptance:** with an authorised owner session only, check the implemented same-page return control and the remaining nested private flows. It must retain official OAuth and server-side permissions.
2. **Stage B — Separate Executive read-only implementation:** owner supplies or approves a separate project/repository, identity choice and non-sensitive status allowlist; build only the signed, least-privilege read-only contract first. It must not share the public Admin’s private credentials or become a direct database bypass.
3. **Stage C — Recovery evidence foundation:** owner selects backup storage and target hosting, sets retention/encryption/key ownership, authorises source/database/media/config inventory and provides an isolated staging target. The first acceptance work is a controlled staging drill, not production restore.
4. **Stage D — Operational verification:** after authorisation, conduct private CRUD/permission/mobile-desktop tests, immutable audit checks, chosen monitoring alert tests and recovery acceptance. Connect real analytics/monitoring only with owner-selected external configuration and label unavailable sources honestly until then.

## 7. Reconciliation result

The PDF is **compatible with a staged SahajContact ecosystem**, but its three-control-room and full-recovery target is broader than the current public project. The safe current-project work now includes the narrowly scoped Stage A Main Admin return control and the source-backed Executive/Recovery handover. Public design remains preserved and no protected or external system was altered. The Executive Owner and Emergency Recovery rooms are **not implemented, connected, deployed or independently verified** by this reconciliation or the handover document.
