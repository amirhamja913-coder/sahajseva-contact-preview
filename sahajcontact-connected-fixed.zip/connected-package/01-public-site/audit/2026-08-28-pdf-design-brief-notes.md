# SahajContact Final Master Prompt Design PDF — Working Notes

Source file: `/home/ubuntu/upload/SahajContact_Final_Master_Prompt_Design.pdf`

## Reading quality note

PDF-এর screenshot preview-এ বহু লাইন OCR-corrupted/garbled দেখা গেছে। তাই নিচের নোটগুলো শুধুমাত্র দৃশ্যমান, তুলনামূলকভাবে স্পষ্ট অংশ এবং page-level layout reading-এর ওপর ভিত্তি করে লেখা হয়েছে। অস্পষ্ট text future reconciliation-এ **unverified** হিসেবে ধরা হবে।

## Clearly visible high-level intent

Document title: **“SahajContact — Final Master Prompt & Admin Ecosystem Design”**.

Subtitle-level visible intent: **Public Website + 3 Control Rooms + Universal Back Button + Full Disaster Recovery**.

The preview imagery depicts four surfaces:

1. Public Website / prompt overview panel
2. Main Admin Control Center
3. Executive Owner Control Room
4. Emergency Recovery & Operations Room

The document visually emphasizes an ecosystem architecture rather than a single public-page redesign.

## Clearly visible structure/themes from pages 1–5

Visible recurring requirement themes include:

- Existing design, routing, authentication, database, API/server logic, and branding should be preserved.
- Public Website should remain separate from the admin/control surfaces.
- A **Main Admin Control Center** is expected for content/site operations.
- A separate **Executive Owner Control Room** is expected for higher-level overview/control.
- A separate **Emergency Recovery & Operations Room** is expected for service health, backup/recovery, and incident handling.
- A **Universal Back Button** pattern is explicitly mentioned.
- **Full Disaster Recovery** and **Backup Architecture** are repeatedly referenced.
- **Mobile-first** and responsive behavior are explicitly mentioned.
- **Regression Testing**, **Final Verification Matrix**, and **Final Report** are explicitly mentioned.

## Clearly visible feature keywords from readable sections

Across the readable lines, the PDF appears to reference these categories:

- Dashboard
- List / Detail / Add / Edit / Settings / Report / Gallery
- Restore point / recovery procedure / incident notes
- Homepage & site control
- Tourist Spot & Gallery
- Transport / India Guide (legacy wording appears in PDF text, but this must be reconciled with the already-corrected Bangladesh-arrival public wording)
- Users / Roles / Security
- Analytics
- API / Database / Add / Edit / Delete / Hide / Show / Public Sync
- Unit test / Integration test / API test / CRUD test / Permission test / Navigation-Back test / Mobile test / Desktop test / Type check / Production build

## Visual design references that are clearly visible

- The composite cover uses dark control-room/dashboard mockups with green/teal brand accents.
- A small palette row is visible with green/teal plus several accent colors.
- Logo reference panels are visible at the bottom.
- Typography reference is visible but detailed font names are not reliably legible in the OCR-corrupted pages.

## Immediate reconciliation constraints for current project

Based on prior verified boundaries and the visible PDF intent:

1. The current public SahajContact project can safely preserve and verify the **existing public site**.
2. Separate **Executive Owner Control Room** and **Emergency Recovery Room** remain potentially separate-project or owner-controlled scopes unless present in the current source and safely testable.
3. Backup, recovery, analytics, and monitoring requirements cannot be claimed complete without real external evidence and authorized access.
4. Any visible legacy “India Guide” wording in the PDF must not override the already-corrected public Bangladesh-arrival wording unless current source verification justifies a safe rename/internal reconciliation only.
5. The PDF’s ecosystem vision is broader than the currently verified public-safe milestone, so requirement-by-requirement reconciliation is necessary before any implementation claim.

## Next reconciliation questions

- Which of the PDF’s control-room requirements already exist in the current source versus only in concept/mockup form?
- Which items are owner-only, external-account, DNS, analytics, backup-destination, or separate-project dependent?
- Which public-safe items, if any, can be implemented without altering the verified Home map, Tourism card, branding, routing, or auth boundaries?
