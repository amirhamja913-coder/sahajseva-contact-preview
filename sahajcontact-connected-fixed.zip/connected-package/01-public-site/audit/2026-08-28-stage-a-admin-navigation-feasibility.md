# Stage A — Main Admin Navigation ও Back-control Feasibility

**তারিখ:** ২৮ আগস্ট ২০২৬  
**Scope:** SahajContact-এর বর্তমান source code থেকে Main Admin navigation পরীক্ষা। কোনো owner session, Admin data, OAuth account chooser, private analytics, Control Room, Recovery site অথবা external infrastructure খোলা হয়নি।

## উদ্দেশ্য ও সিদ্ধান্ত

সংযুক্ত Final Master Prompt Design PDF-তে থাকা Main Admin-এর সহজ navigation এবং ফিরে-যাওয়ার control-ধারণাটি বর্তমান public project-এ **non-destructive** ভাবে বসানো সম্ভব কি না যাচাই করা হয়েছে। Source evidence অনুযায়ী বর্তমান `/admin/dashboard` একটি official Manus OAuth ও server-side owner verification-সুরক্ষিত route; তাই এই Stage A-তে authentication, role, route permission, credential, data query অথবা Executive/Recovery architecture পরিবর্তনের কোনো প্রস্তাব নেই।

> **Finding:** বর্তমান Main Admin-এ ইতিমধ্যেই search-সহ section navigation আছে। সবচেয়ে কম-risk উন্নতি হবে browser-history-based “Back” নয়, বরং একই protected page-এর `admin-overview` anchor-এ smooth scroll করা একটি স্পষ্ট **“ড্যাশবোর্ডে ফিরুন”** control।

| Source evidence | বর্তমান আচরণ | Stage A interpretation |
|---|---|---|
| `client/src/App.tsx` | `/admin/dashboard` route আলাদা Admin shell-এ যায় | Back control নতুন URL, alternate login বা public Admin route তৈরি করবে না |
| `client/src/pages/AdminAnalyticsDashboard.tsx` | বড় `details`-ভিত্তিক section এবং `id="admin-overview"` overview target আছে | একই page-এ ফিরে যাওয়া সম্ভব; nested content delete বা redesign প্রয়োজন নেই |
| `client/src/components/AdminWorkspaceNavigation.tsx` | প্রতিটি menu target-এ scroll করে; target একটি `HTMLDetailsElement` হলে সেটি open করে; URL fragment `replaceState`-এ update করে | বিদ্যমান navigation model re-use করা যায়; duplicate routing architecture দরকার নেই |
| `server/_core/oauth.ts` ও owner-only server procedures | Official sign-in এবং server-side permission boundary বিদ্যমান | কোনো client-only role bypass, PIN, password, OTP বা second-login যোগ করা যাবে না |

## বর্তমান navigation inventory

বর্তমান `AdminWorkspaceNavigation` component-এ desktop sticky sidebar ও mobile collapsible menu আছে। এতে Dashboard/overview, homepage/banner, content/services, gallery/media, mobile media, NGO/institution, Business Directory, ownership review, analytics এবং system/settings target আছে। Search field বাংলা ও English keyword দিয়ে target খুঁজে দেয় এবং menu click করলে relevant section-এ scroll করে। এটি existing workflow-এর সঙ্গে সামঞ্জস্যপূর্ণ এবং বর্তমান Main Admin navigation-এর ভিত্তি হিসেবে রাখা উচিত।

Dashboard page-এ বৃহৎ content areas `details` element-এ বিভক্ত। বর্তমান navigation helper destination element খুঁজে `details` হলে সেটি খুলে, smooth scroll করে, তারপর fragment update করে। তাই এতে back-control যোগ করলে তার কাজ কেবল owner-কে known overview-তে ফিরিয়ে দেওয়া হবে; browser history-এর অপ্রত্যাশিত external page navigation ঘটবে না।

| Candidate control | নিরাপদ আচরণ | কেন browser-history back নয় |
|---|---|---|
| “ড্যাশবোর্ডে ফিরুন” button | `admin-overview`-এ focus-safe smooth scroll; প্রয়োজন হলে sidebar search clear | browser history আগের OAuth/account page বা external URL-এ নিতে পারে; সেটি workflow ও security expectation-এর জন্য অনির্দিষ্ট |
| Existing sidebar “ড্যাশবোর্ড” menu item | বর্তমান helper re-use করে overview-তে যায় | একই page, একই protected context এবং existing pattern |
| Per-section secondary control | দীর্ঘ panel শেষে একই overview target-এ scroll করে | নতুন route, modal, credentials বা privileged action ছাড়া orientation উন্নত করে |

## Permitted implementation boundary

একটি পরবর্তী safe implementation চাইলে সেটি শুধু protected Admin page render হওয়ার পরে দৃশ্যমান হবে এবং existing `AdminWorkspaceNavigation` scroll helper বা shared, unit-testable equivalent ব্যবহার করবে। Button-টি keyboard reachable, visible focus style-সহ, `type="button"` হবে; এটি কোনো data mutation, authentication state change, API request, page reload বা login handoff করবে না। Existing Home, river–bridge map, Tourism design, public routes, logo/branding এবং public functionality এই scope-এর বাইরে থাকবে।

Feasibility review-এর পরে একটি narrowly scoped UI improvement বাস্তবায়ন করা হয়েছে: `AdminWorkspaceNavigation`-এ existing section-scroll helper ব্যবহার করে keyboard-accessible, `type="button"` **“ড্যাশবোর্ডে ফিরুন”** control যোগ হয়েছে। Control-টি কেবল `admin-overview` target-এ in-page smooth scroll করে এবং বর্তমান navigation-এর মতো fragment `replaceState` update করে। এতে নতুন URL, alternate login, browser-history navigation, data query/mutation, API call, reload, credential handling বা owner-authorization change নেই।

Private owner session ছাড়া বাস্তব long-panel workflow এবং label placement যাচাই করা যায় না। তাই implementation সম্পন্ন হলেও owner-side protected-route regression confirmation এখনও প্রয়োজন।

## Required verification if implementation is approved

| Test | কী verify করবে | বর্তমান status |
|---|---|---|
| Focused unit test | `admin-overview` target resolution, absent-target no-op, button semantics এবং no auth/data mutation contract | Passed for the new `AdminWorkspaceNavigation` control |
| Full regression, TypeScript + production build | Admin component import/type safety, protected/public source contracts এবং bundle compilation | Passed after the implementation; production build has only the established chunk-size advisory |
| Owner-side protected Admin check | desktop/mobile navigation, keyboard focus, long-panel return, login/logout boundary | Required; this review did not open any owner session |
| Signed-out public regression check | Home/Tourism public paths unaffected by Admin-only change | Passed at desktop and 375px mobile; public Home river–bridge map and Tourism entry/guidance remained rendered |

## Excluded and still separate scope

PDF-তে উল্লিখিত Executive Control, Recovery Admin, emergency access, independent hosting, backup/restore, domain/DNS, external monitoring, GA4, payment, owner credentials এবং any cross-site control এই public project-এর current-source Stage A scope নয়। এগুলোর জন্য distinct project/source, authorised owner configuration, real provider evidence এবং separately approved threat-model/test plan প্রয়োজন। এই audit কোনোটি enabled, connected, operational বা verified বলে দাবি করে না.

## Readiness

বর্তমান Main Admin navigation-এর ভিত্তিতে **same-page overview return control** safe, narrowly scoped ভাবে বাস্তবায়িত ও automated regression-এ covered হয়েছে। তবে Stage A readiness কেবল এই bounded Admin navigation improvement পর্যন্ত: owner-session verification এবং any Executive/Recovery system completion এই document-এ সম্পন্ন হয়নি।
