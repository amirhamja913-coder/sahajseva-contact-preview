# Live customer-view verification — desktop homepage

**Source:** https://sahajcontact-8xyxsefc.manus.space/

**Observed:** The live page rendered after waiting for the app to finish loading. The document title is `সাহজসেবা — সহজে সরকারি সেবা খুঁজুন`. The customer-visible header contains the SahajContact logo, Home, Services, About, Contact, Service Tools, Login/Profile, and a call CTA for 01965177538. The hero contains service search, feedback, PWA install (`অ্যাপ হিসেবে নিন`), share, and a clearly visible River Path illustration. The AI help board, paid assistance section, WhatsApp chat CTA, payment/Transaction ID controls, service categories, and external service links are present in the extracted customer DOM.

**Important observed limitation:** The first browser screenshot was blank while the SPA was still rendering; a subsequent browser view showed the full page and visible interactive elements. This indicates load timing, not a confirmed customer-facing permanent blank state. The public page exposes a `Made with Manus` badge in the lower-right preview/browser capture; whether that is platform chrome or customer production UI should be checked separately.

**Key customer paths detected:** `/`, `/#services`, `/about`, `/contact`, `/tools`, `tel:01965177538`, WhatsApp chat at `https://wa.me/8801965177538`, and the PWA install control. The homepage extracted 40+ civic-service/customer action elements and paid-assistance order/payment controls.

## Footer and interaction inspection

The live footer view shows a security block with SSL/data protection language and an OTP/PIN/password warning, a contact block with 01965177538 and Chattogram, Bangladesh, a large green WhatsApp CTA, partner links with a non-affiliation disclaimer, a Live Chat CTA, the government-fee/service-charge disclaimer, and a small circular phone control. A delayed help popup is visible with the Bengali support message and WhatsApp CTA.

The browser's click attempt on the header login control while the page was scrolled did not visibly open a dialog in that state, so login needs a focused retest from the top of the page or via direct DOM/event inspection. This is recorded as a follow-up verification item rather than a confirmed failure.

## Login/profile entry retest

From the top of the live homepage, clicking “লগইন / প্রোফাইল” successfully opens the centered login dialog. The customer sees a Bengali mobile-number label, a `01XXXXXXXXX` telephone input, an “OTP পাঠান” button, a close control, and the explanatory WhatsApp OTP instruction below the button. The page remains visible behind a dimmed overlay and the control is keyboard/browser-visible.

## Responsive screenshot verification

The 375×812 mobile captures show the header logo, profile and call buttons, hamburger menu, Bengali hero, service search CTA, share/install controls, and the 10-second help popup rendered within the viewport without horizontal overflow. The About, Contact, and Tools routes also render with Bengali headings and visible contact/help affordances. The 1280×720 desktop captures show the full navigation, profile and call actions, River Path hero artwork, About/Contact/Tools/Profile route shells, floating contact controls, and the help popup. Existing customer-facing elements remain present; no destructive layout regression was observed in the captured viewport.
