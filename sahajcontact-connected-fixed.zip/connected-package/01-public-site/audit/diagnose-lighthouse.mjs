import fs from "node:fs";

const report = JSON.parse(fs.readFileSync(new URL("./lighthouse-mobile-current.json", import.meta.url), "utf8"));
const audits = report.audits ?? {};
const pick = id => {
  const audit = audits[id];
  if (!audit) return null;
  return {
    id,
    title: audit.title,
    score: audit.score,
    displayValue: audit.displayValue ?? null,
    numericValue: audit.numericValue ?? null,
    details: audit.details ?? null,
  };
};

const requests = audits["network-requests"]?.details?.items ?? [];
const largestRequests = requests
  .map(item => ({
    url: item.url,
    resourceType: item.resourceType,
    transferSize: item.transferSize,
    resourceSize: item.resourceSize,
    startTime: item.startTime,
    endTime: item.endTime,
    statusCode: item.statusCode,
    mimeType: item.mimeType,
  }))
  .sort((a, b) => (b.transferSize ?? 0) - (a.transferSize ?? 0))
  .slice(0, 15);

const result = {
  lcpElement: pick("largest-contentful-paint-element"),
  lcpBreakdown: pick("lcp-breakdown"),
  renderBlocking: pick("render-blocking-resources"),
  documentLatency: pick("server-response-time"),
  mainThread: pick("mainthread-work-breakdown"),
  jsExecution: pick("bootup-time"),
  thirdParties: pick("third-party-summary"),
  totalBytes: pick("total-byte-weight"),
  cache: pick("uses-long-cache-ttl"),
  fontDisplay: pick("font-display"),
  largestRequests,
};

console.log(JSON.stringify(result, null, 2));
fs.writeFileSync(new URL("./lighthouse-mobile-diagnostics.json", import.meta.url), JSON.stringify(result, null, 2) + "\n");
