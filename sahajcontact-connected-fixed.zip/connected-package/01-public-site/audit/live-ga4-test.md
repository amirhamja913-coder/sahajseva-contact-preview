# Live Footer WhatsApp GA4 Test Evidence

Test date: 2026-08-13
Live URL: https://sahajcontact-8xyxsefc.manus.space/

## Observed live configuration

- The live page loads the GA4 script with Measurement ID `G-EJQEKS80NH` in `client/index.html`.
- The footer contains a visible large green button labeled `WhatsApp এ কথা বলুন`.
- The live footer shows the helpline `01965177538` and address `চট্টগ্রাম, বাংলাদেশ`.
- The footer WhatsApp CTA is placed in the contact block below the security information and above the partner-tools area.
- The footer text found on the live page includes `সহায়তা ও যোগাযোগ`, `হেল্পলাইন: 01965177538 (সকাল ৯টা থেকে রাত ৯টা)`, `ঠিকানা: চট্টগ্রাম, বাংলাদেশ`, and `WhatsApp এ কথা বলুন`.

## Analytics implementation evidence

`client/src/lib/analytics.ts` calls `window.gtag?.("event", name, properties)` when gtag is available and also sends a first-party analytics fallback payload when configured.

The live page is therefore configured to accept the footer event through GA4's gtag bootstrap. A browser click test still needs to capture the runtime network/console evidence and confirm whether GA4 Realtime received the event. A local browser click alone cannot prove the event is visible in the owner's GA4 property unless the GA4 Realtime/DebugView is checked.

## Important interpretation

A click that opens `https://wa.me/8801965177538` may navigate away from the page quickly. The handler must send `whatsapp_click` with `{ button_location: "footer" }` before navigation; `navigator.sendBeacon` or gtag's transport/keepalive behavior should be used to reduce event loss.

## Runtime click test result

At 2026-08-13 14:35 UTC-equivalent browser test time, the visible footer CTA was found and clicked programmatically with navigation prevented only for the test. The click produced the exact captured gtag call:

```text
["event", "whatsapp_click", {"button_location": "footer"}]
```

The CTA href was:

```text
https://wa.me/8801965177538?text=আমাদের সহায়তা প্রয়োজন
```

The live `dataLayer` tail contained:

```text
["config", "G-EJQEKS80NH"]
["event", "page_view", {"page":"home"}]
["event", "whatsapp_click", {"button_location":"footer"}]
```

The browser also loaded `https://www.googletagmanager.com/gtag/js?id=G-EJQEKS80NH`.

## Conclusion

The deployed page's click handler is firing the requested GA4 event with the requested parameter, and the event is entering the GA4 dataLayer for measurement ID `G-EJQEKS80NH`. The browser test did not establish that the event is visible in the owner's GA4 Realtime dashboard; that final confirmation requires checking the connected GA4 property's Realtime or DebugView. The event is valid and correctly structured for reporting.

## Stability re-test

A fresh live-site test was run after the user's request to defer domain/MFA work. The visible footer CTA label was `WhatsApp এ কথা বলুন`. Its resolved href was `https://wa.me/8801965177538?text=...`, confirming the destination number `01965177538` in international format. The click test captured:

```text
["event", "whatsapp_click", {"button_location":"footer"}]
```

The dataLayer tail included the GA4 config for `G-EJQEKS80NH` and the same `whatsapp_click` event. Navigation was prevented only during the test so the payload could be inspected; the real CTA remains a normal WhatsApp link.

A mobile screenshot was captured at 390x844 pixels. The header collapses to icon controls, the hero text wraps without clipping, primary actions remain readable, and the floating contact controls remain visible. Screenshot file: `/home/ubuntu/screenshots/webdev-preview-root-1786632133241022942-5806.png`.

No domain or MFA changes were made.
