# SahajSeva Optimized Assets

Generated and uploaded on 2026-08-14.

| Asset | Original source | Optimized storage path | Original size | Optimized size | Reduction |
|---|---|---|---:|---:|---:|
| Hero | 1920×1080 WebP served from the legacy storage URL | `/manus-storage/sahajseva-hero-optimized_17a686f3.webp` | 386,338 bytes | 65,168 bytes | 83.1% |
| Paper texture | 1920×1440 WebP served from the legacy storage URL | `/manus-storage/sahajseva-paper-optimized_342b9d44.webp` | 358,154 bytes | 16,264 bytes | 95.5% |
| Logo | Legacy WebP logo | `/manus-storage/sahajseva-logo-optimized_3ff0d912.webp` | 102,418 bytes | 2,682 bytes | 97.4% |

The optimized files are persistent project-managed assets and should be referenced using the exact storage paths above. Visual dimensions and the River Path design are preserved; hero is resized to 1280×720, texture to a 1280px-wide repeatable surface, and logo to a 256px square source for display at small sizes.
