import fs from "node:fs";

const report = JSON.parse(fs.readFileSync(new URL("./lighthouse-mobile-current.json", import.meta.url), "utf8"));
const audits = report.audits ?? {};
const metric = id => audits[id]?.displayValue ?? "n/a";
const score = report.categories?.performance?.score;
const opportunities = [
  "unused-javascript",
  "unused-css-rules",
  "uses-long-cache-ttl",
  "modern-image-formats",
  "uses-responsive-images",
  "render-blocking-resources",
  "total-byte-weight",
  "mainthread-work-breakdown",
].map(id => ({
  id,
  title: audits[id]?.title ?? id,
  score: audits[id]?.score ?? null,
  displayValue: audits[id]?.displayValue ?? null,
  details: audits[id]?.details?.overallSavingsBytes ?? null,
}));

const result = {
  fetchTime: report.fetchTime,
  finalUrl: report.finalUrl,
  performanceScore: score == null ? null : Math.round(score * 100),
  metrics: {
    fcp: metric("first-contentful-paint"),
    lcp: metric("largest-contentful-paint"),
    speedIndex: metric("speed-index"),
    tbt: metric("total-blocking-time"),
    cls: metric("cumulative-layout-shift"),
    tti: metric("interactive"),
  },
  opportunities,
  network: {
    totalBytes: audits["total-byte-weight"]?.numericValue ?? null,
    requestCount: audits["network-requests"]?.details?.items?.length ?? null,
  },
};

console.log(JSON.stringify(result, null, 2));
fs.writeFileSync(new URL("./lighthouse-mobile-summary.json", import.meta.url), JSON.stringify(result, null, 2) + "\n");
