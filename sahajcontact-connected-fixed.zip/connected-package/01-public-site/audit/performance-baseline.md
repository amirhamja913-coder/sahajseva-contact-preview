# SahajSeva Performance Baseline

**Audit date:** 2026-08-14
**Target:** https://sahajcontact-8xyxsefc.manus.space/
**Viewport checked:** Desktop browser preview; mobile PageSpeed request was attempted but the public PageSpeed endpoint returned HTTP 429, so no authoritative baseline score is claimed.

## Current payload observations

The current production build generated the following principal browser payloads:

| Asset | Size | Observation |
|---|---:|---|
| `dist/public/assets/index-DYMGNsDq.js` | 1,248,375 bytes | Large initial JavaScript bundle; all routes and shared widgets are eagerly imported. |
| `dist/public/assets/index-DumdgVjy.css` | 228,953 bytes | Large global CSS bundle; Tailwind output includes broad UI/component styles. |
| `dist/public/index.html` | 371,701 bytes | Large transformed HTML output, primarily due to the client template and injected runtime metadata. |
| `client/public/__manus__/debug-collector.js` | 25,168 bytes | Preview/debug support asset; not a hand-authored application dependency. |

The build also reported that the paper texture storage URL remains unresolved at build time and is intentionally preserved for runtime resolution. Vite reported a chunk-size warning because the initial JavaScript chunk exceeds 500 kB.

## Image observations

The homepage uses one hero image and one small logo image. The logo URL is reused in several sections and can be served once from browser cache. The hero image is above the fold and should remain eager/high priority; repeated section-mark logos are below the fold and should use lazy loading and asynchronous decoding. Existing storage URLs are retained to comply with the project asset-storage rules.

## Code observations

`client/src/App.tsx` eagerly imports all route pages, including policy, dashboard, tools, profile, and campaign pages that are not needed for the homepage's first render. Shared AI/chat and customer-growth widgets are also mounted globally. This is the clearest JavaScript reduction opportunity: route-level dynamic imports can reduce the homepage's initial execution cost while preserving navigation behavior.

`client/index.html` currently loads Google Fonts with four font families/weights in one stylesheet request. The page uses Bengali-first typography, so the optimization should retain the required Bengali families but reduce unnecessary weights and add font-display behavior through the stylesheet URL.

`client/public/robots.txt`, `sitemap.xml`, `manifest.webmanifest`, and `sw.js` are present. The production server currently uses Express static serving without explicit immutable cache headers or response compression middleware; this is the main delivery-layer optimization opportunity.

## Limitations

The external PageSpeed Insights API request returned HTTP 429 during this audit. A reproducible local Lighthouse/PageSpeed-style report will therefore be generated after optimization, and any result will be labeled as a local/preview measurement rather than a Google-hosted score. Actual Google PageSpeed scores can vary by network, device emulation, cache state, and deployment edge.
