# New service link validation

The first two user-provided destinations were opened for passive verification before implementation.

| Requested service | Destination | Result |
|---|---|---|
| জন্ম-মৃত্যু নিবন্ধন | https://everify.bdris.gov.bd | Loaded successfully. Page title: “Birth and Death Verification”. The page identifies the Office of the Registrar General, Birth and Death Registration, Local Government Division, and provides birth/death record verification forms. |
| ট্রেড লাইসেন্স | https://www.ccc.gov.bd | Loaded successfully. The page identifies the Chattogram City Corporation official site and displays current municipal information. |

These links are treated as user-supplied destinations; the site will display them as external official-portal links and will not claim affiliation with the external authorities.

## Land-records hostname note

The user-supplied `https://eporcha.gov.bd` could not be resolved by the live browser environment (`ERR_NAME_NOT_RESOLVED`). Search results identified the Bangladesh government land information portal at `https://land.gov.bd/` and the Digital Land Record Management System at `https://dlrms.land.gov.bd/`. Because the user explicitly supplied `eporcha.gov.bd`, it should not be silently replaced without confirmation; the implementation will retain the supplied URL unless the user requests the canonical replacement.
