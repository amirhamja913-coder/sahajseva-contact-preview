const CACHE_VERSION = "sahajseva-pwa-v19-map-verified-alpha";
const APP_SHELL = [
  "/",
  "/offline.html",
  "/manifest.webmanifest",
  "/admin-manifest.webmanifest",
  "/manus-storage/sahajseva-logo-optimized_3ff0d912.webp",
  "/manus-storage/sahajcontact-karnafuli-tunnel-clean_6b8249ee.png",
  "/manus-storage/sahajcontact-map-tiger-waterlily-alpha-overlay-verified_5ad7e1cf.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_VERSION).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});

const shouldBypassPwaHandling = (url) =>
  url.origin === self.location.origin
  && (url.pathname.startsWith("/api/") || url.pathname.startsWith("/oauth/") || url.pathname.startsWith("/admin"));

const isCacheableAsset = (request, url) => {
  if (request.method !== "GET" || shouldBypassPwaHandling(url)) return false;
  return /\.(?:js|css|png|jpe?g|webp|svg|ico|woff2?|webmanifest|json)$/i.test(url.pathname)
    || url.pathname.startsWith("/manus-storage/");
};

const cacheResponse = async (request, response) => {
  if (!response || !response.ok || response.type === "opaque") return response;
  const cache = await caches.open(CACHE_VERSION);
  await cache.put(request, response.clone());
  return response;
};

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);

  // OAuth/API requests must retain the browser's native network and redirect
  // behavior. Do not let offline navigation fallback consume a 302 to the
  // official account-selection page, especially in Android WebViews/PWAs.
  if (shouldBypassPwaHandling(url)) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          void cacheResponse(request, response.clone());
          return response;
        })
        .catch(async () => {
          const offlinePage = await caches.match("/offline.html");
          const cachedPage = await caches.match(request);
          return offlinePage || cachedPage || caches.match("/");
        }),
    );
    return;
  }

  if (!isCacheableAsset(request, url)) return;

  // Stale-While-Revalidate for cached assets to eliminate buffering and ensure instant response
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request)
        .then((networkResponse) => {
          void cacheResponse(request, networkResponse.clone());
          return networkResponse;
        })
        .catch(() => cachedResponse);

      return cachedResponse || fetchPromise;
    }),
  );
});
