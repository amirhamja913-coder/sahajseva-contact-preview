import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import SahajPageSkeleton from "./components/SahajPageSkeleton";
import { lazy, Suspense, useEffect, type CSSProperties, type ReactNode } from "react";
import { useBuildRefresh } from "./hooks/useBuildRefresh";
import BackToTopButton from "./components/BackToTopButton";
import DeferredMount from "./components/DeferredMount";
import SahajSplashScreen from "./components/SahajSplashScreen";
import { installOutboundUtmTracking } from "./lib/analytics";
import { trpc } from "./lib/trpc";
import ExternalLinkSecurityPolicy from "./components/ExternalLinkSecurityPolicy";
import { getPublicRouteSeo } from "./lib/publicSeo";
import { parsePublicThemeOverrides, resolvePublicThemeScope } from "@shared/publicTheme";

const Home = lazy(() => import("./pages/Home"));
const Contact = lazy(() => import("./pages/Contact"));
const SponsorUs = lazy(() => import("./pages/SponsorUs"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const Dashboard = lazy(() => import("@/pages/Dashboard"));
const SecurityPolicy = lazy(() => import("@/pages/SecurityPolicy"));
const PrivacyPolicy = lazy(() => import("@/pages/PrivacyPolicy"));
const CopyrightSecurityPolicy = lazy(() => import("@/pages/CopyrightSecurityPolicy"));
const AdvertisingPolicy = lazy(() => import("@/pages/AdvertisingPolicy"));
const FundingGuidancePage = lazy(() => import("@/pages/FundingGuidancePage"));
const NgoPartnershipPage = lazy(() => import("@/pages/NgoPartnershipPage"));
const BusinessDirectoryPage = lazy(() => import("@/pages/BusinessDirectoryPage"));
const ExpatriateGuidePage = lazy(() => import("@/pages/ExpatriateGuidePage"));
const Tools = lazy(() => import("@/pages/Tools"));
const InvestBangladesh = lazy(() => import("@/pages/InvestBangladesh"));
const AdvertiseWithUs = lazy(() => import("@/pages/AdvertiseWithUs"));
const InvestorsPage = lazy(() => import("@/pages/InvestorsPage"));
const BlogNews = lazy(() => import("@/pages/BlogNews"));
const BangladeshTouristPlannerPage = lazy(() => import("@/pages/BangladeshTouristPlannerPage"));
const MediaDirectoryPage = lazy(() => import("@/pages/MediaDirectoryPage"));
const AdminAnalyticsDashboard = lazy(() => import("@/pages/AdminAnalyticsDashboard"));
const SiteBuilder = lazy(() => import("@/pages/SiteBuilder"));
const Profile = lazy(() => import("@/pages/Profile"));
const FooterInfoPage = lazy(() => import("@/pages/FooterInfoPage"));
const AboutProblem = lazy(() => import("@/pages/AboutPages").then(module => ({ default: module.AboutProblem })));
const AboutSolution = lazy(() => import("@/pages/AboutPages").then(module => ({ default: module.AboutSolution })));
const AboutImpact = lazy(() => import("@/pages/AboutPages").then(module => ({ default: module.AboutImpact })));
const AboutPartnership = lazy(() => import("@/pages/AboutPages").then(module => ({ default: module.AboutPartnership })));

function RouteFallback() {
  return <SahajPageSkeleton />;
}

/** Preserves shared legacy links while keeping one public report surface on Home. */
function LegacyAugust2026ReportRedirect() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    setLocation("/#public-seo-report", { replace: true });
  }, [setLocation]);

  return <RouteFallback />;
}

/** Retires the ambiguous legacy user-workspace URL in favour of the official owner-only Admin route. */
function LegacyDashboardRedirect() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    setLocation("/admin/dashboard", { replace: true });
  }, [setLocation]);

  return <RouteFallback />;
}

function RemoteMaintenanceGate({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const isOwnerRoute = location === "/admin" || location.startsWith("/admin/") || location === "/dashboard";
  const publicContent = trpc.siteManagement.getPublicContent.useQuery(
    { language: "bn" },
    { enabled: !isOwnerRoute, refetchInterval: 30_000, staleTime: 10_000 },
  );
  const settings = publicContent.data?.settings;

  if (!isOwnerRoute && settings?.remoteMaintenanceMode === 1) {
    return (
      <main className="min-h-screen bg-slate-950 px-5 py-20 text-white">
        <section className="mx-auto max-w-xl rounded-3xl border border-amber-300/40 bg-slate-900 p-8 text-center shadow-2xl">
          <p className="text-xs font-black tracking-[0.24em] text-amber-300">SAHAJCONTACT · MAINTENANCE</p>
          <h1 className="mt-3 text-3xl font-black">সেবা সাময়িকভাবে বন্ধ আছে</h1>
          <p className="mt-4 leading-7 text-slate-300">{settings.remoteMaintenanceMessage || "নির্ধারিত রক্ষণাবেক্ষণ চলছে। অনুগ্রহ করে কিছুক্ষণ পরে আবার চেষ্টা করুন।"}</p>
          <p className="mt-6 text-sm text-slate-400">পাবলিক সেবা পুনরায় চালু হলে এই পেজ স্বয়ংক্রিয়ভাবে আপডেট হবে।</p>
        </section>
      </main>
    );
  }

  return <>{children}</>;
}

/** Public scope resolver deliberately returns null for Admin, dashboard and unknown routes. */
function PublicThemeBackground({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const scopeKey = resolvePublicThemeScope(location);
  const publicContent = trpc.siteManagement.getPublicContent.useQuery(
    { language: "bn" },
    { enabled: Boolean(scopeKey), refetchInterval: 30_000, staleTime: 10_000 },
  );
  const settings = publicContent.data?.settings;
  const overrides = parsePublicThemeOverrides(settings?.themeBackgroundOverridesJson);
  const scopedTheme = scopeKey ? overrides[scopeKey] : undefined;
  const backgroundImageUrl = scopedTheme?.backgroundImageUrl ?? (settings?.pageBackgroundImageUrl?.startsWith("/manus-storage/") ? settings.pageBackgroundImageUrl : "");
  const backgroundColor = scopedTheme?.backgroundColor ?? settings?.pageBackgroundColor ?? "#f3faf6";
  const overlayOpacity = scopedTheme?.overlayOpacity ?? 0.84;

  if (!scopeKey) return <>{children}</>;
  return <div
    className="public-theme-background"
    style={{
      "--public-theme-background-image": backgroundImageUrl ? `url(${backgroundImageUrl})` : "none",
      "--public-theme-background-color": backgroundColor,
      "--public-theme-overlay-opacity": String(overlayOpacity),
    } as CSSProperties}
  >{children}</div>;
}

function syncPwaMetadata(location: string) {
  const isAdminPwa = location === "/admin" || location.startsWith("/admin/dashboard") || location === "/dashboard";
  const publicSeo = getPublicRouteSeo(location);
  const manifestHref = isAdminPwa ? "/admin-manifest.webmanifest" : "/manifest.webmanifest";
  const manifestLink = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
  if (manifestLink) manifestLink.href = manifestHref;
  document.documentElement.dataset.pwaApp = isAdminPwa ? "admin" : "public";

  const title = isAdminPwa ? "SahajContact Admin | GA4 ও গ্যালারি ব্যবস্থাপনা" : publicSeo.title;
  document.title = title;

  const setMeta = (selector: string, attribute: "name" | "property", content: string) => {
    const meta = document.querySelector<HTMLMetaElement>(`meta[${attribute}="${selector}"]`);
    if (meta) meta.content = content;
  };
  setMeta("application-name", "name", isAdminPwa ? "SahajContact Admin" : "SahajContact");
  setMeta("apple-mobile-web-app-title", "name", isAdminPwa ? "SahajContact Admin" : "SahajContact");
  setMeta("theme-color", "name", isAdminPwa ? "#059669" : "#0f766e");
  if (!isAdminPwa) {
    setMeta("description", "name", publicSeo.description);
    setMeta("og:title", "property", publicSeo.title);
    setMeta("og:description", "property", publicSeo.description);
    setMeta("og:url", "property", publicSeo.canonical);
    setMeta("twitter:title", "name", publicSeo.title);
    setMeta("twitter:description", "name", publicSeo.description);
    const canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (canonical) canonical.href = publicSeo.canonical;
  }
}

function Router() {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/contact" component={Contact} />
        <Route path="/sponsor" component={SponsorUs} />
        <Route path="/advertise" component={AdvertiseWithUs} />
        <Route path="/investors" component={InvestorsPage} />
        <Route path="/blog" component={BlogNews} />
        <Route path="/invest-bangladesh" component={InvestBangladesh} />
        <Route path="/bangladesh" component={BangladeshTouristPlannerPage} />
        <Route path="/tv-channels" component={() => <MediaDirectoryPage view="tv" />} />
        <Route path="/newspapers" component={() => <MediaDirectoryPage view="newspapers" />} />
        <Route path="/reports/august-2026" component={LegacyAugust2026ReportRedirect} />
        <Route path="/admin" component={LegacyDashboardRedirect} />
        <Route path="/admin/dashboard" component={AdminAnalyticsDashboard} />
        <Route path="/admin/site-builder" component={SiteBuilder} />
        <Route path="/dashboard" component={LegacyDashboardRedirect} />
        <Route path="/future-plan" component={() => <FooterInfoPage pageKey="future-plan" />} />
        <Route path="/public-guidance" component={() => <FooterInfoPage pageKey="public-guidance" />} />
        <Route path="/security-policy" component={SecurityPolicy} />
        <Route path="/privacy-policy" component={PrivacyPolicy} />
        <Route path="/copyright-security" component={CopyrightSecurityPolicy} />
        <Route path="/advertising-policy" component={AdvertisingPolicy} />
        <Route path="/funding-guidance" component={FundingGuidancePage} />
        <Route path="/ngo-partnership" component={NgoPartnershipPage} />
        <Route path="/business-directory" component={BusinessDirectoryPage} />
        <Route path="/expatriate-guide" component={ExpatriateGuidePage} />
        <Route path="/expatriate" component={ExpatriateGuidePage} />
        <Route path="/tools" component={Tools} />
        <Route path="/profile" component={Profile} />
        <Route path="/campaign" component={() => <FooterInfoPage pageKey="campaign" />} />
        <Route path="/help" component={() => <FooterInfoPage pageKey="help" />} />
        <Route path="/complaint" component={() => <FooterInfoPage pageKey="complaint" />} />
        <Route path="/about" component={() => <FooterInfoPage pageKey="about" />} />
        <Route path="/careers" component={() => <FooterInfoPage pageKey="careers" />} />
        <Route path="/supplier" component={() => <FooterInfoPage pageKey="supplier" />} />
        <Route path="/merchant" component={() => <FooterInfoPage pageKey="merchant" />} />
        <Route path="/about-problem" component={AboutProblem} />
        <Route path="/about-solution" component={AboutSolution} />
        <Route path="/about-impact" component={AboutImpact} />
        <Route path="/about-partnership" component={AboutPartnership} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

export default function App() {
  const [location] = useLocation();
  useBuildRefresh();
  useEffect(() => installOutboundUtmTracking(), []);
  useEffect(() => syncPwaMetadata(location), [location]);
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable={true} /* switchable> */>
        <LanguageProvider>
          <TooltipProvider>
            <RemoteMaintenanceGate><PublicThemeBackground><Router /></PublicThemeBackground></RemoteMaintenanceGate>
            <ExternalLinkSecurityPolicy />
            <BackToTopButton />
            <DeferredMount delay={1200}>
              <SahajSplashScreen />
            </DeferredMount>
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
