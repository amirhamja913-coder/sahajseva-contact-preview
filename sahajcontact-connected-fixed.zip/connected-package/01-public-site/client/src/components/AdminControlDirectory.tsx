import {
  BarChart3,
  BookOpen,
  GalleryHorizontal,
  Home,
  ImageIcon,
  Landmark,
  Menu,
  Palette,
  Route,
  Settings2,
  SlidersHorizontal,
  type LucideIcon,
} from "lucide-react";

type ControlDirectoryItem = {
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  targetId: string;
  publicHref: string;
  publicLabelBn: string;
  icon: LucideIcon;
  tone: string;
};

const controls: ControlDirectoryItem[] = [
  {
    titleBn: "হোমপেজ, লেখা ও প্রধান CTA",
    titleEn: "Homepage copy & primary CTA",
    descriptionBn: "Hero, notice, contact, quick link ও মূল section নিয়ন্ত্রণ করুন।",
    targetId: "cms-homepage-builder",
    publicHref: "/",
    publicLabelBn: "Main Page দেখুন",
    icon: Home,
    tone: "from-emerald-500/20 to-teal-500/5 border-emerald-400/30 text-emerald-200",
  },
  {
    titleBn: "Transport ও India তথ্য",
    titleEn: "Transport & India guidance",
    descriptionBn: "Border port, অফিসিয়াল source, travel/transport guide, icon ও visibility পরিচালনা করুন।",
    targetId: "cms-transport-india",
    publicHref: "/bangladesh",
    publicLabelBn: "Travel Page দেখুন",
    icon: Route,
    tone: "from-sky-500/20 to-cyan-500/5 border-sky-400/30 text-sky-200",
  },
  {
    titleBn: "Main Page Category ও Icon",
    titleEn: "Homepage categories & icons",
    descriptionBn: "Education, Financial Service ও Media Hub-এর লেখা, link, order, icon ও show/hide ঠিক করুন।",
    targetId: "cms-main-content",
    publicHref: "/",
    publicLabelBn: "Main Page দেখুন",
    icon: SlidersHorizontal,
    tone: "from-violet-500/20 to-fuchsia-500/5 border-violet-400/30 text-violet-200",
  },
  {
    titleBn: "Theme, Logo ও Appearance",
    titleEn: "Theme, logo & appearance",
    descriptionBn: "Site logo, রং, background, font scale ও layout density পরিবর্তন করুন।",
    targetId: "cms-appearance-controls",
    publicHref: "/",
    publicLabelBn: "Main Page দেখুন",
    icon: Palette,
    tone: "from-amber-500/20 to-orange-500/5 border-amber-400/30 text-amber-200",
  },
  {
    titleBn: "পেজ/মেনু ব্যাকগ্রাউন্ড থিম",
    titleEn: "Page & menu backgrounds",
    descriptionBn: "হোম, ভ্রমণ, মিডিয়া ও অনুমোদিত public menu group-এর জন্য নিরাপদ ছবি, রঙ ও readable overlay নিয়ন্ত্রণ করুন।",
    targetId: "cms-theme-background-manager",
    publicHref: "/bangladesh",
    publicLabelBn: "উদাহরণ পেজ দেখুন",
    icon: Palette,
    tone: "from-emerald-500/20 to-teal-500/5 border-emerald-400/30 text-emerald-200",
  },
  {
    titleBn: "Service Card Icon ও Link",
    titleEn: "Service cards",
    descriptionBn: "Service card-এর ছবি-icon, নাম, description ও link update করুন।",
    targetId: "cms-service-card-assets",
    publicHref: "/",
    publicLabelBn: "Service দেখুন",
    icon: ImageIcon,
    tone: "from-rose-500/20 to-pink-500/5 border-rose-400/30 text-rose-200",
  },
  {
    titleBn: "Header, Menu ও Announcement",
    titleEn: "Header, menu & announcement",
    descriptionBn: "Navigation menu, label, URL, order, header identity ও announcement bar edit করুন।",
    targetId: "cms-menu-header-manager",
    publicHref: "/",
    publicLabelBn: "Header দেখুন",
    icon: Menu,
    tone: "from-indigo-500/20 to-blue-500/5 border-indigo-400/30 text-indigo-200",
  },
  {
    titleBn: "Tourist Spot ও Gallery",
    titleEn: "Tourist spots & galleries",
    descriptionBn: "বাংলাদেশের tourist spot, cover photo, gallery, map, location ও visibility সম্পাদনা করুন।",
    targetId: "cms-tourist-spots",
    publicHref: "/bangladesh",
    publicLabelBn: "Tourist Page দেখুন",
    icon: Landmark,
    tone: "from-lime-500/20 to-green-500/5 border-lime-400/30 text-lime-200",
  },
  {
    titleBn: "উন্মুক্ত Public Gallery",
    titleEn: "Public & personal galleries",
    descriptionBn: "উন্মুক্ত Gallery-র ছবি upload, serial order, public/hidden status, download ও delete নিয়ন্ত্রণ করুন।",
    targetId: "cms-photo-galleries",
    publicHref: "/",
    publicLabelBn: "Gallery দেখুন",
    icon: GalleryHorizontal,
    tone: "from-pink-500/20 to-purple-500/5 border-pink-400/30 text-pink-200",
  },
  {
    titleBn: "Blog, Notice, SEO ও Backup",
    titleEn: "Site management",
    descriptionBn: "Blog, notice, SEO, lead, backup/restore, system health ও operations review করুন।",
    targetId: "cms-site-management",
    publicHref: "/blog",
    publicLabelBn: "Blog দেখুন",
    icon: Settings2,
    tone: "from-slate-500/25 to-slate-700/10 border-slate-400/30 text-slate-100",
  },
  {
    titleBn: "Analytics ও Security",
    titleEn: "Analytics & security",
    descriptionBn: "GA4 report, export, login history, alert এবং owner activity review করুন।",
    targetId: "cms-analytics-security",
    publicHref: "/",
    publicLabelBn: "Public Site দেখুন",
    icon: BarChart3,
    tone: "from-cyan-500/20 to-blue-500/5 border-cyan-400/30 text-cyan-100",
  },
];

function openPublicPage(href: string) {
  window.open(href, "_blank", "noopener,noreferrer");
}

export function AdminControlDirectory() {
  return (
    <section id="cms-control-directory" className="rounded-2xl border border-emerald-400/30 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/35 p-5 shadow-xl sm:p-6">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="mb-1 text-xs font-bold uppercase tracking-[0.16em] text-emerald-300">Owner control directory</p>
          <h2 className="text-xl font-black text-white">কোন কাজ কোথা থেকে Edit করবেন</h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">
            নিচের প্রতিটি card থেকে সংশ্লিষ্ট Admin section-এ সরাসরি যান। Save করার পর public page refresh করলে পরিবর্তন দেখা যাবে।
          </p>
        </div>
        <div className="rounded-xl border border-emerald-400/25 bg-emerald-950/45 px-3 py-2 text-xs leading-5 text-emerald-100">
          প্রতিটি control আপনার official owner account দ্বারা সুরক্ষিত।
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {controls.map((control) => {
          const Icon = control.icon;
          return (
            <article key={control.targetId} className={`rounded-2xl border bg-gradient-to-br p-4 shadow-sm ${control.tone}`}>
              <div className="mb-3 flex items-start gap-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-current/25 bg-slate-950/30">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-white">{control.titleBn}</h3>
                  <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-wide text-slate-300">{control.titleEn}</p>
                </div>
              </div>
              <p className="min-h-12 text-xs leading-5 text-slate-200">{control.descriptionBn}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => document.getElementById(control.targetId)?.scrollIntoView({ behavior: "smooth", block: "start" })}
                  className="rounded-lg bg-white/12 px-3 py-2 text-xs font-bold text-white transition hover:bg-white/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  Edit Section-এ যান
                </button>
                <button
                  type="button"
                  onClick={() => openPublicPage(control.publicHref)}
                  className="rounded-lg border border-white/25 bg-slate-950/15 px-3 py-2 text-xs font-semibold text-white transition hover:bg-slate-950/35 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  {control.publicLabelBn}
                </button>
              </div>
            </article>
          );
        })}
      </div>
      <div className="mt-4 flex items-center gap-2 text-xs text-slate-400"><BookOpen className="h-3.5 w-3.5" aria-hidden="true" /> কোনো item না পেলে আগে এই directory থেকে সংশ্লিষ্ট panel খুলুন; account sign-in ও owner permission এই panel থেকে পরিবর্তন করা যায় না।</div>
    </section>
  );
}
