import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
const projectRoot = resolve(process.cwd());
const readComponent = () => readFileSync(resolve(projectRoot, "client/src/components/AdminSecurityGate.tsx"), "utf8");
const readDashboard = () => readFileSync(resolve(projectRoot, "client/src/pages/AdminAnalyticsDashboard.tsx"), "utf8");
describe("Admin local-password authentication gate", () => {
  it("renders a same-origin password form and has no official OAuth button", () => {
    const component = readComponent();
    expect(component).toContain('fetch("/api/local-auth/login"');
    expect(component).toContain('type="password"');
    expect(component).toContain("পাসওয়ার্ড দিয়ে প্রবেশ");
    expect(component).toContain("credentials: \"include\"");
    expect(component).not.toContain("/api/oauth/start");
    expect(component).not.toContain("Official sign in");
  });
  it("keeps the server-side owner authorization check around the workspace", () => {
    const component = readComponent();
    const dashboard = readDashboard();
    expect(component).toContain("trpc.auth.canAccessOwnerPanel.useQuery");
    expect(component).toContain("enabled: isAuthenticated");
    expect(component).toContain("if (ownerAccess.data !== true)");
    expect(component).toContain('id="owner-admin-session-bar"');
    expect(component).toContain("লোকাল পাসওয়ার্ড সেশন সক্রিয়");
    expect(dashboard).toContain("<AdminSecurityGate>");
    expect(dashboard).not.toContain("passwordSessionQuery");
  });
});
