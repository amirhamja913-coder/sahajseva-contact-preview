import { KeyRound, LogOut, ShieldCheck } from "lucide-react";
import { useState, type FormEvent, type ReactNode } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

type AdminSecurityGateProps = {
  children: ReactNode;
};

/** Owner-only entry boundary using the site's own server-verified password session. */
export default function AdminSecurityGate({ children }: AdminSecurityGateProps) {
  const { isAuthenticated, loading, logout, refresh } = useAuth();
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const ownerAccess = trpc.auth.canAccessOwnerPanel.useQuery(undefined, {
    enabled: isAuthenticated,
    retry: false,
    refetchOnWindowFocus: false,
  });

  const submitPassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoginError("");
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/local-auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ password }),
      });
      const payload = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) throw new Error(payload.error || "লগইন করা যায়নি।");
      setPassword("");
      await refresh();
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "লগইন করা যায়নি। আবার চেষ্টা করুন।");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading || (isAuthenticated && ownerAccess.isLoading)) {
    return (
      <main className="min-h-screen bg-slate-950 px-4 py-16 text-slate-100">
        <section className="mx-auto max-w-md rounded-3xl border border-white/10 bg-slate-900/80 p-8 text-center shadow-2xl">
          <ShieldCheck className="mx-auto mb-4 h-10 w-10 animate-pulse text-teal-300" aria-hidden="true" />
          <h1 className="text-xl font-bold">অ্যাডমিন প্রবেশ যাচাই হচ্ছে</h1>
          <p className="mt-3 text-sm leading-6 text-slate-300">সাইটের নিরাপদ লোকাল সেশন প্রস্তুত হচ্ছে।</p>
        </section>
      </main>
    );
  }

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-slate-950 px-4 py-16 text-slate-100">
        <section className="mx-auto max-w-md rounded-3xl border border-white/10 bg-slate-900/90 p-8 shadow-2xl">
          <div className="text-center">
            <ShieldCheck className="mx-auto mb-4 h-10 w-10 text-teal-300" aria-hidden="true" />
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-teal-200">SahajContact Admin</p>
            <h1 className="mt-3 text-2xl font-bold">অ্যাডমিন লগইন</h1>
            <p className="mt-3 text-sm leading-6 text-slate-300">সাইটের নির্ধারিত অ্যাডমিন পাসওয়ার্ড দিয়ে ড্যাশবোর্ডে প্রবেশ করুন। কোনো OAuth, Manus account বা billing service প্রয়োজন নেই।</p>
          </div>
          <form onSubmit={submitPassword} className="mt-6 space-y-4" noValidate>
            <label className="block text-sm font-semibold text-slate-200" htmlFor="admin-local-password">
              অ্যাডমিন পাসওয়ার্ড
              <input
                id="admin-local-password"
                name="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                className="mt-2 min-h-12 w-full rounded-xl border border-slate-600 bg-slate-950 px-4 text-base text-white outline-none transition focus:border-teal-400 focus:ring-2 focus:ring-teal-400/30"
                placeholder="পাসওয়ার্ড লিখুন"
                required
              />
            </label>
            {loginError ? <p className="rounded-xl border border-rose-400/30 bg-rose-950/40 px-3 py-2 text-sm text-rose-200" role="alert">{loginError}</p> : null}
            <button type="submit" disabled={isSubmitting || password.length === 0} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-teal-500 px-4 py-3 font-semibold text-slate-950 transition hover:bg-teal-400 disabled:cursor-not-allowed disabled:opacity-50">
              <KeyRound className="h-4 w-4" aria-hidden="true" />
              {isSubmitting ? "যাচাই হচ্ছে…" : "পাসওয়ার্ড দিয়ে প্রবেশ"}
            </button>
          </form>
          <p className="mt-5 text-center text-xs leading-5 text-slate-400">পাসওয়ার্ড deployment-এর secure environment variable থেকে যাচাই হয় এবং browser storage-এ রাখা হয় না।</p>
        </section>
      </main>
    );
  }

  if (ownerAccess.data !== true) {
    return (
      <main className="min-h-screen bg-slate-950 px-4 py-16 text-slate-100">
        <section className="mx-auto max-w-md rounded-3xl border border-white/10 bg-slate-900/80 p-8 text-center shadow-2xl">
          <ShieldCheck className="mx-auto mb-4 h-10 w-10 text-amber-300" aria-hidden="true" />
          <h1 className="text-xl font-bold">অ্যাডমিন অনুমতি পাওয়া যায়নি</h1>
          <p className="mt-3 text-sm leading-6 text-slate-300">এই সেশন owner dashboard-এর জন্য অনুমোদিত নয়।</p>
          <button type="button" onClick={() => void logout()} className="mt-6 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg border border-slate-600 px-4 py-3 font-semibold text-slate-100 transition hover:bg-slate-800">
            <LogOut className="h-4 w-4" aria-hidden="true" />
            লগআউট
          </button>
        </section>
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <header id="owner-admin-session-bar" className="sticky top-0 z-50 border-b border-slate-800/90 bg-slate-950/95 px-4 py-2.5 shadow-lg backdrop-blur">
        <div className="mx-auto flex max-w-[1680px] items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-slate-100">SahajContact Owner Admin</p>
            <p className="text-xs text-slate-400">লোকাল পাসওয়ার্ড সেশন সক্রিয়</p>
          </div>
          <button type="button" onClick={() => void logout()} className="inline-flex min-h-10 shrink-0 items-center justify-center gap-2 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm font-semibold text-slate-100 transition hover:border-slate-400 hover:bg-slate-800">
            <LogOut className="h-4 w-4" aria-hidden="true" />
            লগআউট
          </button>
        </div>
      </header>
      {children}
    </div>
  );
}
