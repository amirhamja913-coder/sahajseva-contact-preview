import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const componentSource = readFileSync(
  resolve(import.meta.dirname, "AdminWorkspaceNavigation.tsx"),
  "utf8"
);

describe("AdminWorkspaceNavigation dashboard return control", () => {
  it("uses the existing same-page overview anchor instead of introducing an authentication or route change", () => {
    expect(componentSource).toContain('aria-label="ড্যাশবোর্ডের শুরুতে ফিরুন"');
    expect(componentSource).toContain("ড্যাশবোর্ডে ফিরুন");
    expect(componentSource).toContain('scrollToWorkspaceSection("admin-overview")');
    expect(componentSource).toContain("setIsMobileMenuOpen(false)");
    expect(componentSource).not.toMatch(/startLogin|logout|window\.location|navigate\(/);
  });
});
