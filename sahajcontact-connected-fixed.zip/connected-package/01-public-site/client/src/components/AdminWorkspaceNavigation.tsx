import { useMemo, useState } from "react";
import {
  BarChart3,
  ChevronDown,
  CornerUpLeft,
  FilePenLine,
  Handshake,
  Home,
  Image,
  Building2,
  LayoutDashboard,
  Menu,
  Search,
  Settings2,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";

type WorkspaceSection = {
  id: string;
  label: string;
  hint: string;
  keywords: string[];
  icon: LucideIcon;
  group: "overview" | "content" | "partnership" | "operations";
};

const workspaceSections: WorkspaceSection[] = [
  { id: "admin-overview", label: "ড্যাশবোর্ড", hint: "দ্রুত পথনির্দেশ", keywords: ["home", "overview", "quick", "dashboard"], icon: LayoutDashboard, group: "overview" },
  { id: "cms-homepage-builder", label: "হোমপেজ ও ব্যানার", hint: "Hero, headline, প্রকাশ", keywords: ["homepage", "hero", "banner", "home", "শিরোনাম"], icon: Home, group: "content" },
  { id: "cms-main-content", label: "কনটেন্ট ও সেবা", hint: "মূল লেখা ও সার্ভিস", keywords: ["content", "service", "সেবা", "লেখা", "main"], icon: FilePenLine, group: "content" },
  { id: "cms-photo-galleries", label: "গ্যালারি ও মিডিয়া", hint: "ছবি, ফোল্ডার, visual", keywords: ["gallery", "media", "photo", "image", "ফাইল", "ছবি"], icon: Image, group: "content" },
  { id: "cms-mobile-media", label: "মোবাইল ফাইল ম্যানেজার", hint: "Upload, replace ও folder", keywords: ["upload", "replace", "folder", "mobile", "ফাইল", "আপলোড"], icon: Image, group: "content" },
  { id: "cms-ngo-partnership", label: "NGO ও প্রতিষ্ঠান", hint: "Review-first enquiries", keywords: ["ngo", "partnership", "institution", "প্রতিষ্ঠান", "আবেদন"], icon: Handshake, group: "partnership" },
  { id: "business-directory-review", label: "Business Directory", hint: "Private review ও public publication", keywords: ["business", "directory", "listing", "review", "ব্যবসা", "তথ্যভান্ডার"], icon: Building2, group: "partnership" },
  { id: "business-directory-claim-review", label: "Ownership review", hint: "Private claim ও correction request", keywords: ["ownership", "claim", "correction", "business", "review", "মালিকানা", "সংশোধন"], icon: ShieldCheck, group: "partnership" },
  { id: "cms-analytics-security", label: "রিপোর্ট ও অ্যানালিটিক্স", hint: "GA4 ও SEO অবস্থান", keywords: ["analytics", "ga4", "seo", "report", "রিপোর্ট"], icon: BarChart3, group: "operations" },
  { id: "cms-operations", label: "সিস্টেম ও সেটিংস", hint: "পরিচালনা, সদস্য, export", keywords: ["system", "settings", "members", "backup", "সেটিংস", "অ্যাডমিন"], icon: Settings2, group: "operations" },
];

const groupLabels: Record<WorkspaceSection["group"], string> = {
  overview: "OVERVIEW",
  content: "কনটেন্ট পরিচালনা",
  partnership: "অংশীদারিত্ব",
  operations: "সিস্টেম ও পর্যবেক্ষণ",
};

function scrollToWorkspaceSection(id: string) {
  const destination = document.getElementById(id);
  if (!destination) return;
  if (destination instanceof HTMLDetailsElement) destination.open = true;
  destination.scrollIntoView({ behavior: "smooth", block: "start" });
  window.history.replaceState(null, "", `#${id}`);
}

export function AdminWorkspaceNavigation() {
  const [query, setQuery] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const normalizedQuery = query.trim().toLocaleLowerCase();
  const matches = useMemo(() => {
    if (!normalizedQuery) return workspaceSections;
    return workspaceSections.filter((section) =>
      [section.label, section.hint, ...section.keywords]
        .join(" ")
        .toLocaleLowerCase()
        .includes(normalizedQuery)
    );
  }, [normalizedQuery]);

  return (
    <aside className="lg:sticky lg:top-24 lg:self-start">
      <div className="rounded-[1.4rem] border border-slate-200 bg-white/95 p-3 shadow-[0_20px_55px_-28px_rgba(15,23,42,0.36)] lg:max-h-[calc(100vh-7rem)] lg:overflow-y-auto">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm">
            <Menu className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-sm font-bold text-slate-950">SahajContact Control</h2>
            <p className="mt-0.5 text-xs leading-5 text-slate-500">Owner workspace · নিরাপদ পরিচালনা</p>
          </div>
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen((current) => !current)}
            aria-expanded={isMobileMenuOpen}
            aria-controls="admin-workspace-menu"
            className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700 transition hover:border-blue-300 hover:text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400/60 lg:hidden"
          >
            {isMobileMenuOpen ? "বন্ধ করুন" : "খুলুন"}
            <ChevronDown className={`h-3.5 w-3.5 transition ${isMobileMenuOpen ? "rotate-180" : ""}`} />
          </button>
        </div>

        <div id="admin-workspace-menu" className={isMobileMenuOpen ? "mt-4 lg:mt-4" : "hidden lg:mt-4 lg:block"}>
          <button
            type="button"
            onClick={() => {
              scrollToWorkspaceSection("admin-overview");
              setIsMobileMenuOpen(false);
            }}
            aria-label="ড্যাশবোর্ডের শুরুতে ফিরুন"
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-blue-200 bg-blue-50 px-3 py-2.5 text-sm font-semibold text-blue-800 transition hover:border-blue-300 hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-400/60"
          >
            <CornerUpLeft className="h-4 w-4" aria-hidden="true" />
            ড্যাশবোর্ডে ফিরুন
          </button>
          <label className="relative block" htmlFor="admin-workspace-search">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              id="admin-workspace-search"
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="কাজ খুঁজুন: gallery, রিপোর্ট…"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-9 pr-3 text-sm text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />
          </label>

          <nav className="mt-4 grid gap-4" aria-label="Admin কাজের বিভাগ">
            {(Object.keys(groupLabels) as WorkspaceSection["group"][]).map((group) => {
              const groupedSections = matches.filter((section) => section.group === group);
              if (!groupedSections.length) return null;
              return <div key={group}>
                <p className="px-2 pb-1.5 text-[10px] font-bold tracking-[0.13em] text-slate-400">{groupLabels[group]}</p>
                <div className="grid gap-1">
                  {groupedSections.map((section) => {
              const Icon = section.icon;
              return (
                <button
                  key={section.id}
                  type="button"
                  onClick={() => {
                    scrollToWorkspaceSection(section.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className="group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-400/60"
                >
                  <Icon className="h-4 w-4 shrink-0 text-slate-400 transition group-hover:text-blue-600" />
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold text-slate-800 group-hover:text-blue-700">{section.label}</span>
                    <span className="block truncate text-xs text-slate-500">{section.hint}</span>
                  </span>
                </button>
              );
                  })}
                </div>
              </div>;
            })}
          </nav>

          {matches.length === 0 && (
            <p className="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-xs leading-5 text-slate-500">এই নামে কোনো কাজ পাওয়া যায়নি। “ছবি”, “রিপোর্ট”, “হোমপেজ” বা “সেটিংস” লিখে চেষ্টা করুন।</p>
          )}

          <div className="mt-4 flex gap-2 border-t border-slate-100 pt-3 text-xs leading-5 text-slate-500"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" /><p>এখানে কোনো সংখ্যা বানিয়ে দেখানো হয় না। প্রতিটি মেনু বিদ্যমান owner control-এ নিয়ে যায়।</p></div>
        </div>
      </div>
    </aside>
  );
}
