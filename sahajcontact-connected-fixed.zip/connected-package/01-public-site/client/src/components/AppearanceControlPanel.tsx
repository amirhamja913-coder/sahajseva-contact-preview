import { useEffect, useState } from "react";
import { ImagePlus, Palette, Save, SlidersHorizontal } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

type AppearanceSettings = {
  brandAccentColor: string;
  brandHighlightColor: string;
  pageBackgroundColor: string;
  pageBackgroundImageUrl: string | null;
  siteTextColor: string;
  fontScale: "small" | "standard" | "large";
  layoutDensity: "compact" | "standard" | "relaxed";
};

const defaults: AppearanceSettings = {
  brandAccentColor: "#0d5c56",
  brandHighlightColor: "#f2b84b",
  pageBackgroundColor: "#f3faf6",
  pageBackgroundImageUrl: null,
  siteTextColor: "#173b32",
  fontScale: "standard",
  layoutDensity: "standard",
};

const inputClass = "mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none transition focus:border-emerald-400";

async function fileToDataUrl(file: File) {
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি।"));
    reader.readAsDataURL(file);
  });
}

export function AppearanceControlPanel({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const workspace = trpc.siteManagement.getOwnerWorkspace.useQuery(undefined, { enabled: isOwner, retry: false });
  const utils = trpc.useUtils();
  const upload = trpc.gallery.uploadBase64.useMutation();
  const [settings, setSettings] = useState<AppearanceSettings>(defaults);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (workspace.data?.settings) {
      const saved = workspace.data.settings as Partial<AppearanceSettings>;
      setSettings({ ...defaults, ...saved });
    }
  }, [workspace.data?.settings]);

  const save = trpc.siteManagement.saveAppearanceSettings.useMutation({
    onSuccess: async () => {
      await Promise.all([workspace.refetch(), utils.siteManagement.getPublicContent.invalidate()]);
      setMessage(language === "EN" ? "Visual appearance saved and published." : "ভিজ্যুয়াল সেটিংস সেভ হয়েছে এবং পাবলিক সাইটে প্রকাশ হয়েছে।");
    },
    onError: (error) => setMessage(error.message),
  });

  const uploadBackground = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      setMessage(language === "EN" ? "Please choose an image file." : "শুধু ছবি ফাইল দিন।");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setMessage(language === "EN" ? "Maximum image size is 10 MB." : "ছবির সর্বোচ্চ সাইজ ১০ MB।");
      return;
    }
    try {
      const result = await upload.mutateAsync({
        base64Data: await fileToDataUrl(file),
        fileName: `cms/appearance-background-${Date.now()}-${file.name.replace(/[^a-z0-9._-]/gi, "-")}`,
        contentType: file.type,
      });
      setSettings((current) => ({ ...current, pageBackgroundImageUrl: result.url }));
      setMessage(language === "EN" ? "Image uploaded. Save to publish it." : "ছবি আপলোড হয়েছে। প্রকাশ করতে Save চাপুন।");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Upload failed");
    }
  };

  const update = <K extends keyof AppearanceSettings>(key: K, value: AppearanceSettings[K]) => {
    setSettings((current) => ({ ...current, [key]: value }));
  };

  if (!isOwner) return null;

  return <section className="rounded-2xl border border-violet-500/25 bg-slate-900 p-5 shadow-xl sm:p-6">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div><h2 className="flex items-center gap-2 text-xl font-bold text-white"><Palette className="h-5 w-5 text-violet-300" /> {language === "EN" ? "Site Appearance Control" : "সাইটের ভিজ্যুয়াল কন্ট্রোল"}</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-slate-400">{language === "EN" ? "Safely control the public site palette, page background, text tone, readable scale and spacing. Site structure, security and system code remain protected." : "পাবলিক সাইটের রঙ, ব্যাকগ্রাউন্ড, টেক্সট টোন, ফন্ট সাইজ ও ফাঁকা জায়গা নিরাপদভাবে নিয়ন্ত্রণ করুন। সাইটের কাঠামো, নিরাপত্তা ও সিস্টেম কোড সুরক্ষিত থাকবে।"}</p></div>
    </div>
    {message && <p className="mt-4 rounded-xl border border-violet-400/25 bg-violet-950/30 px-4 py-3 text-sm text-violet-100" role="status">{message}</p>}
    <div className="mt-5 grid gap-4 rounded-2xl border border-slate-800 bg-slate-950/45 p-4 sm:grid-cols-2">
      <label className="text-xs text-slate-300">{language === "EN" ? "Primary theme color" : "মূল থিম রঙ"}<span className="mt-1 flex items-center gap-2"><input type="color" className="h-10 w-12 cursor-pointer rounded-lg border border-slate-700 bg-slate-950 p-1" value={settings.brandAccentColor} onChange={(event) => update("brandAccentColor", event.target.value)} /><input className={inputClass} value={settings.brandAccentColor} onChange={(event) => update("brandAccentColor", event.target.value)} maxLength={7} /></span></label>
      <label className="text-xs text-slate-300">{language === "EN" ? "Highlight / button color" : "হাইলাইট ও বাটনের রঙ"}<span className="mt-1 flex items-center gap-2"><input type="color" className="h-10 w-12 cursor-pointer rounded-lg border border-slate-700 bg-slate-950 p-1" value={settings.brandHighlightColor} onChange={(event) => update("brandHighlightColor", event.target.value)} /><input className={inputClass} value={settings.brandHighlightColor} onChange={(event) => update("brandHighlightColor", event.target.value)} maxLength={7} /></span></label>
      <label className="text-xs text-slate-300">{language === "EN" ? "Page background color" : "পেজ ব্যাকগ্রাউন্ড রঙ"}<span className="mt-1 flex items-center gap-2"><input type="color" className="h-10 w-12 cursor-pointer rounded-lg border border-slate-700 bg-slate-950 p-1" value={settings.pageBackgroundColor} onChange={(event) => update("pageBackgroundColor", event.target.value)} /><input className={inputClass} value={settings.pageBackgroundColor} onChange={(event) => update("pageBackgroundColor", event.target.value)} maxLength={7} /></span></label>
      <label className="text-xs text-slate-300">{language === "EN" ? "Main text color" : "মূল লেখার রঙ"}<span className="mt-1 flex items-center gap-2"><input type="color" className="h-10 w-12 cursor-pointer rounded-lg border border-slate-700 bg-slate-950 p-1" value={settings.siteTextColor} onChange={(event) => update("siteTextColor", event.target.value)} /><input className={inputClass} value={settings.siteTextColor} onChange={(event) => update("siteTextColor", event.target.value)} maxLength={7} /></span></label>
      <label className="text-xs text-slate-300">{language === "EN" ? "Font size" : "ফন্ট সাইজ"}<select className={inputClass} value={settings.fontScale} onChange={(event) => update("fontScale", event.target.value as AppearanceSettings["fontScale"])}><option value="small">{language === "EN" ? "Small" : "ছোট"}</option><option value="standard">{language === "EN" ? "Standard" : "স্বাভাবিক"}</option><option value="large">{language === "EN" ? "Large" : "বড়"}</option></select></label>
      <label className="text-xs text-slate-300">{language === "EN" ? "Layout spacing" : "লেআউট ফাঁকা জায়গা"}<select className={inputClass} value={settings.layoutDensity} onChange={(event) => update("layoutDensity", event.target.value as AppearanceSettings["layoutDensity"])}><option value="compact">{language === "EN" ? "Compact" : "কম"}</option><option value="standard">{language === "EN" ? "Standard" : "স্বাভাবিক"}</option><option value="relaxed">{language === "EN" ? "Relaxed" : "বেশি"}</option></select></label>
      <div className="sm:col-span-2 rounded-xl border border-slate-800 bg-slate-900/70 p-3"><div className="flex flex-col gap-3 sm:flex-row sm:items-end"><label className="min-w-0 flex-1 text-xs text-slate-300">{language === "EN" ? "Page background image (optional)" : "পেজ ব্যাকগ্রাউন্ড ছবি (ঐচ্ছিক)"}<input className={inputClass} value={settings.pageBackgroundImageUrl ?? ""} onChange={(event) => update("pageBackgroundImageUrl", event.target.value.trim() || null)} placeholder="/manus-storage/..." /></label><label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-slate-700 px-3 py-2.5 text-sm text-slate-200 hover:border-violet-400"><ImagePlus className="h-4 w-4" />{language === "EN" ? "Upload image" : "ছবি আপলোড"}<input type="file" accept="image/*" className="sr-only" onChange={(event) => event.target.files?.[0] && void uploadBackground(event.target.files[0])} /></label>{settings.pageBackgroundImageUrl && <button type="button" className="rounded-xl border border-rose-400/40 px-3 py-2.5 text-sm text-rose-200" onClick={() => update("pageBackgroundImageUrl", null)}>{language === "EN" ? "Remove image" : "ছবি সরান"}</button>}</div>{settings.pageBackgroundImageUrl && <img src={settings.pageBackgroundImageUrl} alt="" className="mt-3 h-24 w-full rounded-lg object-cover" />}</div>
      <div className="sm:col-span-2 flex flex-col gap-3 border-t border-slate-800 pt-4 sm:flex-row sm:items-center sm:justify-between"><p className="flex items-start gap-2 text-xs leading-5 text-slate-400"><SlidersHorizontal className="mt-0.5 h-4 w-4 shrink-0 text-violet-300" />{language === "EN" ? "Choose colors with good contrast so visitors can read public information comfortably." : "পাবলিক তথ্য স্বাচ্ছন্দ্যে পড়া যায়—এমন কনট্রাস্টসহ রঙ নির্বাচন করুন।"}</p><button type="button" onClick={() => save.mutate(settings)} disabled={save.isPending} className="inline-flex items-center justify-center gap-2 rounded-xl bg-violet-500 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-violet-400 disabled:cursor-not-allowed disabled:opacity-60"><Save className="h-4 w-4" />{save.isPending ? (language === "EN" ? "Saving…" : "সেভ হচ্ছে…") : (language === "EN" ? "Save appearance" : "ভিজ্যুয়াল সেটিংস সেভ")}</button></div>
    </div>
  </section>;
}
