import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { BACK_TO_TOP_THRESHOLD } from "./BackToTopButton";

const buttonSource = readFileSync(new URL("./BackToTopButton.tsx", import.meta.url), "utf8");
const stylesheetSource = readFileSync(new URL("../index.css", import.meta.url), "utf8");

describe("BackToTopButton", () => {
  it("uses a meaningful mobile scroll threshold and accessible control label", () => {
    expect(BACK_TO_TOP_THRESHOLD).toBe(320);
    expect(buttonSource).toContain('aria-label="উপরে যান"');
    expect(buttonSource).toContain('data-testid="back-to-top"');
    expect(buttonSource).toContain("window.addEventListener(\"scroll\", handleScroll, { passive: true })");
    expect(buttonSource).toContain('aria-label="পাদলেখে যান"');
    expect(buttonSource).toContain('data-testid="scroll-to-bottom"');
  });

  it("returns to the top with reduced-motion support", () => {
    expect(buttonSource).toContain("window.scrollTo({");
    expect(buttonSource).toContain('behavior: shouldReduceMotion() ? "auto" : "smooth"');
    expect(buttonSource).toContain("window.removeEventListener(\"scroll\", handleScroll)");
    expect(buttonSource).toContain("document.documentElement.scrollHeight");
  });

  it("reserves a collision-safe fixed position above mobile controls", () => {
    expect(stylesheetSource).toContain(".back-to-top-button");
    expect(stylesheetSource).toContain("6.25rem");
    expect(stylesheetSource).toContain("env(safe-area-inset-bottom)");
  });
});
