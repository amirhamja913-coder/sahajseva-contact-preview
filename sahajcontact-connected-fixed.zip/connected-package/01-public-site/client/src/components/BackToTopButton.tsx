import { ArrowDown, ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";

export const BACK_TO_TOP_THRESHOLD = 320;

function shouldReduceMotion() {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export default function BackToTopButton() {
  const [isVisible, setIsVisible] = useState(false);
  const [canScrollDown, setCanScrollDown] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight;
      const hasMoreBelow = scrollHeight > window.innerHeight + 40 && window.scrollY + window.innerHeight < scrollHeight - 40;
      setIsVisible(window.scrollY > BACK_TO_TOP_THRESHOLD);
      setCanScrollDown(hasMoreBelow);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: shouldReduceMotion() ? "auto" : "smooth",
    });
  };

  const scrollToBottom = () => {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      behavior: shouldReduceMotion() ? "auto" : "smooth",
    });
  };

  if (!isVisible && !canScrollDown) return null;

  return (
    <nav className="back-to-top-button fixed z-40 flex flex-col gap-2" aria-label="পাতা স্ক্রল নিয়ন্ত্রণ">
      {isVisible ? <button
        type="button"
        className="inline-flex size-11 items-center justify-center rounded-full border border-[#b9e5db] bg-[#fbfaf5] text-[#0f766e] shadow-[0_10px_28px_rgba(16,63,67,0.2)] transition hover:-translate-y-0.5 hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f2b84b] focus-visible:ring-offset-2 active:scale-95"
        aria-label="উপরে যান"
        title="উপরে যান"
        data-testid="back-to-top"
        onClick={scrollToTop}
      >
        <ArrowUp className="size-5" aria-hidden="true" />
      </button> : null}
      {canScrollDown ? <button
        type="button"
        className="inline-flex size-11 items-center justify-center rounded-full border border-[#b9e5db] bg-[#fbfaf5] text-[#0f766e] shadow-[0_10px_28px_rgba(16,63,67,0.2)] transition hover:translate-y-0.5 hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f2b84b] focus-visible:ring-offset-2 active:scale-95"
        aria-label="পাদলেখে যান"
        title="পাদলেখে যান"
        data-testid="scroll-to-bottom"
        onClick={scrollToBottom}
      >
        <ArrowDown className="size-5" aria-hidden="true" />
      </button> : null}
    </nav>
  );
}
