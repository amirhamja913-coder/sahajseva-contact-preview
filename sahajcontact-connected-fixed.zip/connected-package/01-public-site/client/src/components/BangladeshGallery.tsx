import React, { useState } from "react";
import { BANGLADESH_GALLERY_ITEMS, GalleryItem } from "../data/bangladeshGallery";
import { Sparkles, X, ZoomIn, Image as ImageIcon } from "lucide-react";

interface BangladeshGalleryProps {
  language?: "BN" | "EN";
}

function getResponsiveGalleryImageProps(imageUrl: string) {
  if (!imageUrl.startsWith("https://images.unsplash.com/")) {
    return { src: imageUrl };
  }

  const buildVariant = (width: number) => {
    const url = new URL(imageUrl);
    url.searchParams.set("auto", "format");
    url.searchParams.set("fit", "crop");
    url.searchParams.set("w", String(width));
    url.searchParams.set("q", "72");
    return url.toString();
  };

  return {
    src: buildVariant(1200),
    srcSet: [480, 768, 1200].map((width) => `${buildVariant(width)} ${width}w`).join(", "),
    sizes: "(max-width: 640px) calc(100vw - 2rem), (max-width: 1024px) calc(50vw - 2rem), 33vw",
  };
}

export const BangladeshGallery: React.FC<BangladeshGalleryProps> = ({ language = "BN" }) => {
  const [activeTab, setActiveTab] = useState<"all" | "development" | "nature" | "culture">("all");
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);
  const [failedImageIds, setFailedImageIds] = useState<Record<string, true>>({});

  const markImageFailed = (id: string) => {
    setFailedImageIds((current) => current[id] ? current : { ...current, [id]: true });
  };

  const filteredItems = activeTab === "all" 
    ? BANGLADESH_GALLERY_ITEMS 
    : BANGLADESH_GALLERY_ITEMS.filter(item => item.category === activeTab);

  return (
    <section id="bangladesh-still-images" className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#f8f9fa] to-[#e8f5e9]/40 relative overflow-hidden">
      {/* Background Decorative Accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full pointer-events-none opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(#006a4e_1px,transparent_1px)] [background-size:24px_24px]"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#006a4e]/10 text-[#006a4e] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles size={14} />
            {language === "EN" ? "Visual Showcase" : "দৃশ্যমান বাংলাদেশ"}
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0d47a1] tracking-tight mb-4">
            {language === "EN" ? "Bangladesh in Still Images" : "বাংলাদেশের কিছু স্থিরচিত্র"}
          </h2>
          <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
            {language === "EN" 
              ? "Explore the vibrant soul of Bangladesh through high-definition moments of infrastructure development, breathtaking nature, and rich cultural heritage."
              : "উন্নয়নের গতিধারা, প্রকৃতির অপার সৌন্দর্য এবং হাজার বছরের সমৃদ্ধ সংস্কৃতির ফ্রেমে বাঁধা বাংলাদেশের কিছু মনোমুগ্ধকর স্থিরচিত্র।"
            }
          </p>

          {/* Category Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            <button
              type="button"
              onClick={() => setActiveTab("all")}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
                activeTab === "all"
                  ? "bg-[#006a4e] text-white shadow-md shadow-[#006a4e]/20"
                  : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              {language === "EN" ? "All Photos" : "সকল স্থিরচিত্র"}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("development")}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
                activeTab === "development"
                  ? "bg-[#006a4e] text-white shadow-md shadow-[#006a4e]/20"
                  : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              {language === "EN" ? "1. Development" : "১. উন্নয়ন"}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("nature")}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
                activeTab === "nature"
                  ? "bg-[#006a4e] text-white shadow-md shadow-[#006a4e]/20"
                  : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              {language === "EN" ? "2. Nature" : "২. প্রকৃতি"}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("culture")}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
                activeTab === "culture"
                  ? "bg-[#006a4e] text-white shadow-md shadow-[#006a4e]/20"
                  : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
              }`}
            >
              {language === "EN" ? "3. Culture" : "৩. সংস্কৃতি"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedImage(item)}
              className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col cursor-pointer transform hover:-translate-y-1"
            >
              {/* Image Container */}
              <div className="relative aspect-[16/10] overflow-hidden bg-gray-100">
                {failedImageIds[item.id] ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-[#e6f4ef] via-[#f8fbfa] to-[#e9f1fb] text-[#006a4e]" aria-hidden="true">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[#006a4e]/20 bg-white/90 shadow-sm"><ImageIcon size={24} /></span>
                    <span className="text-[11px] font-bold tracking-wide">{language === "EN" ? "Photo archive" : "ছবি আর্কাইভ"}</span>
                  </div>
                ) : (
                  <img
                    {...getResponsiveGalleryImageProps(item.imageUrl)}
                    alt={language === "EN" ? item.titleEn : item.titleBn}
                    width={1200}
                    height={750}
                    sizes="(max-width: 640px) calc(100vw - 2rem), (max-width: 1024px) calc(50vw - 2rem), 33vw"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                    fetchPriority="low"
                    decoding="async"
                    onError={() => markImageFailed(item.id)}
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-between p-4">
                  <span className="text-white text-xs font-medium flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full">
                    <ZoomIn size={14} />
                    {language === "EN" ? "Click to Expand" : "বড় করে দেখুন"}
                  </span>
                </div>
                <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase bg-white/90 backdrop-blur-md text-[#006a4e] shadow-sm">
                  {language === "EN" ? item.categoryLabelEn : item.categoryLabelBn}
                </span>
              </div>

              {/* Content / Caption */}
              <div className="p-5 flex flex-col flex-grow justify-between bg-white">
                <div>
                  <h3 className="text-lg font-bold text-gray-900 group-hover:text-[#006a4e] transition-colors mb-2">
                    {language === "EN" ? item.titleEn : item.titleBn}
                  </h3>
                  <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
                    {language === "EN" ? item.captionEn : item.captionBn}
                  </p>
                  {item.creditUrl && (
                    <a
                      href={item.creditUrl}
                      target="_blank"
                      rel="noreferrer"
                      onClick={(event) => event.stopPropagation()}
                      className="mt-3 inline-flex text-[10px] leading-tight text-gray-400 underline underline-offset-2 hover:text-[#006a4e]"
                    >
                      {language === "EN" ? item.creditEn : item.creditBn}
                    </a>
                  )}
                </div>
                <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400 font-medium">
                  <span className="flex items-center gap-1">
                    <ImageIcon size={13} className="text-[#006a4e]" />
                    {language === "EN" ? "SahajContact Archive" : "SahajContact আর্কাইভ"}
                  </span>
                  <span className="text-[#006a4e] font-bold group-hover:translate-x-1 transition-transform">
                    {language === "EN" ? "View →" : "বিস্তারিত →"}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {selectedImage && (
          <div 
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-fade-in"
            onClick={() => setSelectedImage(null)}
          >
            <div 
              className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl relative transform transition-all animate-scale-in"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black transition-colors"
                aria-label="Close modal"
              >
                <X size={20} />
              </button>

              <div className="relative aspect-[16/10] bg-black">
                {failedImageIds[selectedImage.id] ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-gradient-to-br from-[#123d42] to-[#006a4e] text-white" aria-hidden="true">
                    <span className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/30 bg-white/10"><ImageIcon size={30} /></span>
                    <span className="text-xs font-bold">{language === "EN" ? "Photo preview unavailable" : "ছবির প্রিভিউ পাওয়া যাচ্ছে না"}</span>
                  </div>
                ) : (
                  <img
                    {...getResponsiveGalleryImageProps(selectedImage.imageUrl)}
                    alt={language === "EN" ? selectedImage.titleEn : selectedImage.titleBn}
                    width={1200}
                    height={750}
                    className="w-full h-full object-contain"
                    loading="eager"
                    fetchPriority="high"
                    decoding="async"
                    onError={() => markImageFailed(selectedImage.id)}
                  />
                )}
              </div>

              <div className="p-6 sm:p-8 bg-white">
                <div className="inline-block px-3 py-1 rounded-full bg-[#006a4e]/10 text-[#006a4e] text-xs font-bold uppercase tracking-wider mb-2">
                  {language === "EN" ? selectedImage.categoryLabelEn : selectedImage.categoryLabelBn}
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-3">
                  {language === "EN" ? selectedImage.titleEn : selectedImage.titleBn}
                </h3>
                <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
                  {language === "EN" ? selectedImage.captionEn : selectedImage.captionBn}
                </p>
                {selectedImage.creditUrl && (
                  <a
                    href={selectedImage.creditUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex text-xs text-gray-400 underline underline-offset-2 hover:text-[#006a4e]"
                  >
                    {language === "EN" ? selectedImage.creditEn : selectedImage.creditBn}
                  </a>
                )}
                <div className="mt-6 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setSelectedImage(null)}
                    className="px-5 py-2.5 rounded-xl bg-[#006a4e] text-white text-sm font-bold hover:bg-[#00523d] transition-colors"
                  >
                    {language === "EN" ? "Close" : "বন্ধ করুন"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
