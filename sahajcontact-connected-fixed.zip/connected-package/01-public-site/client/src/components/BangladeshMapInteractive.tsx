import { useState } from "react";
import { MapPinned } from "lucide-react";
import { bangladeshMapDivisions, getBangladeshMapDivision } from "../lib/bangladeshMapData";
import "./HomeVisualAccents.css";

const DEFAULT_DIVISION_ID = "dhaka";

const heroMapDistrictLabels = [
  { name: "রংপুর", x: 31, y: 17, mobileHidden: false },
  { name: "রাজশাহী", x: 22, y: 39, mobileHidden: false },
  { name: "ময়মনসিংহ", x: 65, y: 28, mobileHidden: true },
  { name: "সিলেট", x: 85, y: 34, mobileHidden: false },
  { name: "ঢাকা", x: 54, y: 47, mobileHidden: false },
  { name: "ব্রাহ্মণবাড়িয়া", x: 72, y: 55, mobileHidden: false },
  { name: "ফরিদপুর", x: 42, y: 61, mobileHidden: true },
  { name: "কুমিল্লা", x: 71, y: 63, mobileHidden: true },
  { name: "খুলনা", x: 27, y: 69, mobileHidden: false },
  { name: "বরিশাল", x: 54, y: 75, mobileHidden: true },
  { name: "চট্টগ্রাম", x: 80, y: 70, mobileHidden: false },
] as const;

export default function BangladeshMapInteractive() {
  const [activeDivisionId, setActiveDivisionId] = useState(DEFAULT_DIVISION_ID);
  const [mapArtworkAvailable, setMapArtworkAvailable] = useState(true);
  const activeDivision = getBangladeshMapDivision(activeDivisionId) ?? bangladeshMapDivisions[0];

  return (
    <div
      className="hero-map-interactive"
      aria-label="বাংলাদেশের বিভাগভিত্তিক সরকারি সেবা মানচিত্র"
    >
      <div className="hero-map-canvas">
        {mapArtworkAvailable ? (
          <img
            className="hero-map-interactive-image"
            src="/manus-storage/sahajcontact-bangladesh-map-flag-overlay-transparent_955298a2.png"
            alt="বাংলাদেশের বিভাগ ও নির্বাচিত জেলার সবুজ-লাল পতাকা-প্রাণিত মানচিত্র"
            width={600}
            height={600}
            loading="eager"
            decoding="async"
            onError={() => setMapArtworkAvailable(false)}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(circle_at_50%_46%,#dff4ef_0%,#f8fbfa_48%,#e5edf5_100%)] text-[#0d5c56]" aria-hidden="true">
            <span className="flex h-24 w-24 items-center justify-center rounded-[2rem] border border-[#0d5c56]/20 bg-white/80 shadow-[0_18px_40px_rgba(13,92,86,0.16)]"><MapPinned size={44} strokeWidth={1.7} /></span>
          </div>
        )}
        <div className="hero-map-district-labels" role="list" aria-label="নির্বাচিত বিভাগ ও জেলার নাম">
          {heroMapDistrictLabels.map((district) => (
            <span
              key={district.name}
              role="listitem"
              className="hero-map-district-label"
              data-mobile-hidden={district.mobileHidden ? "true" : undefined}
              style={{ left: `${district.x}%`, top: `${district.y}%` }}
            >
              {district.name}
            </span>
          ))}
        </div>
        <div className="hero-map-hotspots" role="group" aria-label="বিভাগ নির্বাচন করুন">
          {bangladeshMapDivisions.map((division) => {
            const isActive = division.id === activeDivision.id;
            const detailLabel = `${division.name}: ${division.summary}`;

            return (
              <button
                key={division.id}
                type="button"
                className={`hero-map-hotspot${isActive ? " is-active" : ""}`}
                style={{ left: `${division.x}%`, top: `${division.y}%` }}
                aria-label={`${detailLabel} — সরকারি পোর্টাল দেখুন`}
                aria-pressed={isActive}
                onMouseEnter={() => setActiveDivisionId(division.id)}
                onFocus={() => setActiveDivisionId(division.id)}
                onClick={() => setActiveDivisionId(division.id)}
              >
                <span className="sr-only">{division.name}</span>
              </button>
            );
          })}
        </div>
        <p className="sr-only" aria-live="polite" aria-atomic="true">
          নির্বাচিত বিভাগ: {activeDivision.name}। {activeDivision.summary}।
        </p>
        <div className="hero-map-wildlife-overlay" aria-hidden="true">
          <img
            src="/manus-storage/sahajcontact-map-tiger-waterlily-alpha-overlay-verified_5ad7e1cf.png"
            alt=""
            width={1280}
            height={720}
            loading="lazy"
            decoding="async"
          />
        </div>
      </div>
    </div>
  );
}
