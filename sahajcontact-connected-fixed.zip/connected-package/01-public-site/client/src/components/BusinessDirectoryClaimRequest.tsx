import { useState, type FormEvent } from "react";
import { CheckCircle2, ClipboardCheck, Loader2, Send, ShieldAlert } from "lucide-react";
import { trpc } from "@/lib/trpc";

type ClaimForm = {
  listingId: number | null;
  claimantName: string;
  relationship: string;
  contactEmail: string;
  contactPhone: string;
  requestExplanation: string;
  consentAccepted: boolean;
};

const initialForm: ClaimForm = {
  listingId: null,
  claimantName: "",
  relationship: "",
  contactEmail: "",
  contactPhone: "",
  requestExplanation: "",
  consentAccepted: false,
};

/**
 * Private review request only. The server independently re-checks that the
 * selected record remains published before it accepts any submission.
 */
export function BusinessDirectoryClaimRequest() {
  const [form, setForm] = useState<ClaimForm>(initialForm);
  const [submitted, setSubmitted] = useState(false);
  const claimableListings = trpc.businessDirectory.listClaimablePublished.useQuery();
  const submit = trpc.businessDirectory.submitClaimRequest.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setForm(initialForm);
    },
  });

  const listings = claimableListings.data ?? [];
  const hasPublishedListings = listings.length > 0;

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!form.listingId) return;
    setSubmitted(false);
    submit.mutate({ ...form, listingId: form.listingId });
  };

  return (
    <section className="mt-10 rounded-3xl border border-slate-700 bg-slate-900 p-6 shadow-2xl sm:p-9" aria-labelledby="directory-claim-request-heading">
      <div className="max-w-3xl">
        <div className="flex items-center gap-3">
          <span className="rounded-xl bg-cyan-400/10 p-3 text-cyan-300"><ClipboardCheck className="h-6 w-6" /></span>
          <h2 id="directory-claim-request-heading" className="text-2xl font-bold text-white">প্রকাশিত তথ্যে ownership বা correction review</h2>
        </div>
        <p className="mt-3 text-sm leading-7 text-slate-300">আপনার প্রতিষ্ঠানের আগে থেকে প্রকাশিত তথ্য থাকলে private review-এর জন্য ownership বা সংশোধনের অনুরোধ দিতে পারেন। অনুরোধটি নিজে কোনো তথ্য বদলায় না।</p>
        <div className="mt-4 flex gap-3 rounded-2xl border border-amber-300/25 bg-amber-300/10 p-4 text-sm leading-6 text-amber-100"><ShieldAlert className="mt-0.5 h-5 w-5 shrink-0" /><p>এটি ownership-এর প্রমাণ, licence বা সরকারি যাচাই, endorsement, partnership, “claimed/verified” badge, payment obligation বা guarantee নয়। NID, trade-licence number/ছবি, bank বা payment তথ্য, password, OTP, biometric বা অন্য কোনো secret দেবেন না।</p></div>
      </div>

      {claimableListings.isLoading ? <div className="mt-6 flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-950/60 p-4 text-sm text-slate-300"><Loader2 className="h-4 w-4 animate-spin" />প্রকাশিত তথ্য যাচাই হচ্ছে…</div> : !hasPublishedListings ? <div className="mt-6 rounded-2xl border border-dashed border-slate-700 bg-slate-950/50 p-6 text-sm leading-7 text-slate-300"><p className="font-bold text-slate-100">এখনও কোনো প্রকাশিত listing নেই।</p><p className="mt-1">বাস্তব কোনো business record owner প্রকাশ করলে কেবল সেই record-এর জন্য review অনুরোধের সুযোগ এখানে দেখা যাবে।</p></div> : submitted ? <div className="mt-6 rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-5"><div className="flex gap-3"><CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-300" /><div><h3 className="font-bold text-emerald-100">আপনার অনুরোধটি private review-এর জন্য সংরক্ষিত হয়েছে।</h3><p className="mt-1 text-sm leading-6 text-emerald-50/80">Owner সচেতনভাবে review না করা পর্যন্ত কোনো public তথ্য, ownership বা badge বদলাবে না।</p></div></div><button type="button" onClick={() => setSubmitted(false)} className="mt-4 text-sm font-bold text-emerald-200 underline underline-offset-4">আরেকটি অনুরোধ দিন</button></div> : <form onSubmit={handleSubmit} className="mt-7 grid gap-5 sm:grid-cols-2">
        <label className="sm:col-span-2 text-sm font-semibold text-slate-200">কোন প্রকাশিত তথ্য নিয়ে অনুরোধ করছেন?
          <select required value={form.listingId ?? ""} onChange={(event) => setForm((current) => ({ ...current, listingId: event.target.value ? Number(event.target.value) : null }))} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30">
            <option value="">প্রকাশিত প্রতিষ্ঠান নির্বাচন করুন</option>
            {listings.map((listing) => <option key={listing.id} value={listing.id}>{listing.businessName} · {listing.district}</option>)}
          </select>
        </label>
        <label className="text-sm font-semibold text-slate-200">আপনার নাম<input required maxLength={160} value={form.claimantName} onChange={(event) => setForm((current) => ({ ...current, claimantName: event.target.value }))} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30" /></label>
        <label className="text-sm font-semibold text-slate-200">প্রতিষ্ঠানের সঙ্গে সম্পর্ক<input required maxLength={180} value={form.relationship} onChange={(event) => setForm((current) => ({ ...current, relationship: event.target.value }))} placeholder="যেমন: owner, manager, প্রতিনিধি" className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white placeholder:text-slate-600 focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30" /></label>
        <label className="text-sm font-semibold text-slate-200">যোগাযোগের ইমেইল<input required type="email" maxLength={320} value={form.contactEmail} onChange={(event) => setForm((current) => ({ ...current, contactEmail: event.target.value }))} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30" /></label>
        <label className="text-sm font-semibold text-slate-200">যোগাযোগের ফোন<input required minLength={10} maxLength={32} value={form.contactPhone} onChange={(event) => setForm((current) => ({ ...current, contactPhone: event.target.value }))} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30" /></label>
        <label className="sm:col-span-2 text-sm font-semibold text-slate-200">কী review বা সংশোধন চান?<textarea required minLength={20} maxLength={2_000} rows={4} value={form.requestExplanation} onChange={(event) => setForm((current) => ({ ...current, requestExplanation: event.target.value }))} className="mt-2 w-full resize-y rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30" /></label>
        <label className="sm:col-span-2 flex items-start gap-3 rounded-xl border border-slate-700 bg-slate-950/80 p-4 text-sm leading-6 text-slate-300"><input required type="checkbox" checked={form.consentAccepted} onChange={(event) => setForm((current) => ({ ...current, consentAccepted: event.target.checked }))} className="mt-1 h-4 w-4 accent-cyan-400" /><span>আমি private owner review-এর জন্য এই যোগাযোগের তথ্য দেওয়ার অনুমতি আমার আছে বলে নিশ্চিত করছি। আমি কোনো sensitive identity, financial, payment বা security তথ্য দিচ্ছি না।</span></label>
        {submit.error ? <p className="sm:col-span-2 rounded-xl border border-rose-400/25 bg-rose-400/10 p-3 text-sm text-rose-100">অনুরোধটি সংরক্ষণ করা যায়নি: {submit.error.message}</p> : null}
        <div className="sm:col-span-2"><button type="submit" disabled={submit.isPending || !form.listingId} className="inline-flex items-center gap-2 rounded-xl bg-cyan-300 px-5 py-3 text-sm font-black text-slate-950 transition hover:bg-cyan-200 disabled:cursor-not-allowed disabled:opacity-60">{submit.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}{submit.isPending ? "সংরক্ষণ হচ্ছে…" : "Owner review-এর জন্য পাঠান"}</button></div>
      </form>}
    </section>
  );
}
