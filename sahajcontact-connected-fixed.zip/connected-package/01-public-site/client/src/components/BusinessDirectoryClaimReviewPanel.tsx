import { useEffect, useState } from "react";
import { Archive, BadgeCheck, ClipboardCheck, Clock3, Loader2, Mail, Phone, Save, XCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";

type ClaimReviewStatus = "pending" | "reviewed" | "declined" | "archived";

const statusCopy: Record<ClaimReviewStatus, { label: string; className: string; icon: typeof Clock3 }> = {
  pending: { label: "Review বাকি", className: "border-amber-300/30 bg-amber-300/10 text-amber-100", icon: Clock3 },
  reviewed: { label: "Review করা হয়েছে", className: "border-cyan-300/30 bg-cyan-300/10 text-cyan-100", icon: BadgeCheck },
  declined: { label: "গ্রহণ করা হয়নি", className: "border-rose-300/30 bg-rose-300/10 text-rose-100", icon: XCircle },
  archived: { label: "Archive", className: "border-slate-600 bg-slate-800 text-slate-200", icon: Archive },
};

/** Private owner workspace only; the data returned here is never used by public APIs. */
export function BusinessDirectoryClaimReviewPanel({ isOwner }: { isOwner: boolean }) {
  const utils = trpc.useUtils();
  const claimsQuery = trpc.businessDirectory.ownerClaimList.useQuery(undefined, { enabled: isOwner, retry: false });
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [statuses, setStatuses] = useState<Record<number, ClaimReviewStatus>>({});
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!claimsQuery.data) return;
    setNotes((current) => Object.fromEntries(claimsQuery.data!.map((item) => [item.id, current[item.id] ?? item.ownerNote ?? ""])));
    setStatuses((current) => Object.fromEntries(claimsQuery.data!.map((item) => [item.id, current[item.id] ?? item.status])) as Record<number, ClaimReviewStatus>);
  }, [claimsQuery.data]);

  const updateReview = trpc.businessDirectory.updateClaimReview.useMutation({
    onSuccess: async () => {
      await utils.businessDirectory.ownerClaimList.invalidate();
      setMessage("Private claim review সংরক্ষণ করা হয়েছে। কোনো public listing স্বয়ংক্রিয়ভাবে বদলায়নি।");
    },
    onError: (error) => setMessage(`সংরক্ষণ করা যায়নি: ${error.message}`),
  });

  const claims = claimsQuery.data ?? [];
  const pendingCount = claims.filter((item) => item.status === "pending").length;

  return (
    <section id="business-directory-claim-review" className="scroll-mt-24 rounded-2xl border border-cyan-400/25 bg-slate-950/60 p-4 sm:p-6" aria-labelledby="business-directory-claim-review-title">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-cyan-200"><ClipboardCheck className="h-5 w-5" /><p className="text-xs font-bold uppercase tracking-[0.16em]">Business Directory</p></div>
          <h3 id="business-directory-claim-review-title" className="mt-2 text-xl font-bold text-white">Ownership ও correction review</h3>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">এখানে থাকা তথ্য কেবল private owner review-এর জন্য। প্রতিটি অনুরোধ একটি প্রকাশিত তথ্যের সঙ্গে যুক্ত, তবে এটি ownership প্রমাণ বা কোনো public পরিবর্তনের নির্দেশ নয়।</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-2 self-start rounded-full border border-amber-300/25 bg-amber-300/10 px-3 py-1.5 text-xs font-bold text-amber-100"><Clock3 className="h-3.5 w-3.5" />{pendingCount} টি pending</span>
      </div>

      <div className="mt-4 rounded-xl border border-amber-300/25 bg-amber-300/10 p-3 text-xs leading-5 text-amber-100">Review status কেবল এই request-এর অবস্থা সংরক্ষণ করে। এটি licence বা government verification, endorsement, partnership, claimed/verified badge, payment বা guarantee তৈরি করে না; listing-এর public তথ্য পরিবর্তনের জন্য আলাদা সচেতন review প্রয়োজন।</div>
      {message ? <p aria-live="polite" className="mt-4 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200">{message}</p> : null}

      {claimsQuery.isLoading ? <div className="mt-5 flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 p-4 text-sm text-slate-300"><Loader2 className="h-4 w-4 animate-spin" />অনুরোধ লোড হচ্ছে…</div> : claims.length === 0 ? <div className="mt-5 rounded-xl border border-dashed border-slate-700 bg-slate-900/50 p-6 text-center text-sm text-slate-300"><ClipboardCheck className="mx-auto h-6 w-6 text-slate-500" /><p className="mt-2">এখনও কোনো ownership বা correction review অনুরোধ নেই।</p></div> : <div className="mt-5 grid gap-4">{claims.map((claim) => {
        const activeStatus = statuses[claim.id] ?? claim.status;
        const status = statusCopy[activeStatus];
        const StatusIcon = status.icon;
        return <article key={claim.id} className="rounded-2xl border border-slate-700 bg-slate-900/80 p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.14em] text-cyan-300">Published listing · #{claim.listingId}</p><h4 className="mt-1 text-lg font-bold text-white">{claim.listingName}</h4><p className="mt-1 text-sm text-slate-300">{claim.listingCategory} · {claim.listingDistrict}</p></div><span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-bold ${status.className}`}><StatusIcon className="h-3.5 w-3.5" />{status.label}</span></div>
          <div className="mt-4 grid gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-4 text-sm text-slate-200 sm:grid-cols-2"><p><span className="text-slate-400">অনুরোধকারী:</span> {claim.claimantName}</p><p><span className="text-slate-400">সম্পর্ক:</span> {claim.relationship}</p><p className="flex items-center gap-2 break-all"><Mail className="h-4 w-4 shrink-0 text-cyan-300" />{claim.contactEmail}</p><p className="flex items-center gap-2"><Phone className="h-4 w-4 shrink-0 text-cyan-300" />{claim.contactPhone}</p></div>
          <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/60 p-4"><p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-400">অনুরোধের বিবরণ</p><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-200">{claim.requestExplanation}</p></div>
          <p className="mt-3 text-xs text-slate-400">সম্মতি: {claim.consentAccepted === 1 ? "দেওয়া হয়েছে" : "recorded নয়"} · জমা: {new Date(claim.createdAt).toLocaleString("bn-BD")} · সর্বশেষ review record: {new Date(claim.updatedAt).toLocaleString("bn-BD")}</p>
          <div className="mt-4 grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto]"><label className="text-sm font-semibold text-slate-200">Private owner note<textarea maxLength={1_500} rows={3} value={notes[claim.id] ?? ""} onChange={(event) => setNotes((current) => ({ ...current, [claim.id]: event.target.value }))} className="mt-2 w-full resize-y rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30" /></label><div className="flex flex-wrap items-end gap-3"><label className="text-sm font-semibold text-slate-200">Review status<select value={activeStatus} onChange={(event) => setStatuses((current) => ({ ...current, [claim.id]: event.target.value as ClaimReviewStatus }))} className="mt-2 block rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/30"><option value="pending">Review বাকি</option><option value="reviewed">Review করা হয়েছে</option><option value="declined">গ্রহণ করা হয়নি</option><option value="archived">Archive</option></select></label><button type="button" disabled={updateReview.isPending} onClick={() => updateReview.mutate({ id: claim.id, status: activeStatus, ownerNote: notes[claim.id] ?? "" })} className="inline-flex items-center gap-2 rounded-xl bg-cyan-300 px-4 py-2.5 text-sm font-black text-slate-950 transition hover:bg-cyan-200 disabled:cursor-not-allowed disabled:opacity-60"><Save className="h-4 w-4" />সংরক্ষণ</button></div></div>
        </article>;
      })}</div>}
    </section>
  );
}
