import { useEffect, useState } from "react";
import { Building2, CheckCircle2, Clock3, Loader2, Mail, MapPin, Phone, Send, XCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";

type ReviewStatus = "pending" | "published" | "declined" | "archived";

const statusCopy: Record<ReviewStatus, { label: string; className: string; icon: typeof Clock3 }> = {
  pending: { label: "Review বাকি", className: "border-amber-300/30 bg-amber-300/10 text-amber-100", icon: Clock3 },
  published: { label: "Public-এ প্রকাশিত", className: "border-emerald-300/30 bg-emerald-300/10 text-emerald-100", icon: CheckCircle2 },
  declined: { label: "প্রকাশ করা হয়নি", className: "border-rose-300/30 bg-rose-300/10 text-rose-100", icon: XCircle },
  archived: { label: "Archive", className: "border-slate-600 bg-slate-800 text-slate-200", icon: Building2 },
};

export function BusinessDirectoryReviewPanel({ isOwner }: { isOwner: boolean }) {
  const utils = trpc.useUtils();
  const submissionsQuery = trpc.businessDirectory.ownerList.useQuery(undefined, { enabled: isOwner, retry: false });
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [statuses, setStatuses] = useState<Record<number, ReviewStatus>>({});
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!submissionsQuery.data) return;
    setNotes((current) => Object.fromEntries(submissionsQuery.data!.map((item) => [item.id, current[item.id] ?? item.ownerNote ?? ""])));
    setStatuses((current) => Object.fromEntries(submissionsQuery.data!.map((item) => [item.id, current[item.id] ?? item.status])) as Record<number, ReviewStatus>);
  }, [submissionsQuery.data]);

  const updateReview = trpc.businessDirectory.updateReview.useMutation({
    onSuccess: async () => {
      await Promise.all([
        utils.businessDirectory.ownerList.invalidate(),
        utils.businessDirectory.listPublished.invalidate(),
      ]);
      setMessage("Review status সংরক্ষণ করা হয়েছে।");
    },
    onError: (error) => setMessage(`সংরক্ষণ করা যায়নি: ${error.message}`),
  });

  const save = (id: number) => {
    updateReview.mutate({ id, status: statuses[id] ?? "pending", ownerNote: notes[id] ?? "" });
  };

  const submissions = submissionsQuery.data ?? [];
  const pendingCount = submissions.filter((item) => item.status === "pending").length;

  return (
    <section id="business-directory-review" className="scroll-mt-24 rounded-2xl border border-cyan-400/25 bg-slate-950/60 p-4 sm:p-6" aria-labelledby="business-directory-review-title">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-cyan-200"><Building2 className="h-5 w-5" /><p className="text-xs font-bold uppercase tracking-[0.16em]">Business Directory</p></div>
          <h3 id="business-directory-review-title" className="mt-2 text-xl font-bold text-white">ব্যবসা তথ্যভান্ডার review</h3>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">প্রতিটি আবেদন আগে private থাকে। কেবল আপনি সচেতনভাবে “Public-এ প্রকাশিত” করলে নাম, ধরন, জেলা, public পরিচিতি ও website দেখা যাবে; ব্যক্তিগত যোগাযোগের তথ্য public হবে না।</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-2 self-start rounded-full border border-amber-300/25 bg-amber-300/10 px-3 py-1.5 text-xs font-bold text-amber-100"><Clock3 className="h-3.5 w-3.5" />{pendingCount} টি pending</span>
      </div>

      <div className="mt-4 rounded-xl border border-sky-300/20 bg-sky-300/10 p-3 text-xs leading-5 text-sky-100">এটি licence, সরকারি অনুমোদন, endorsement, rating বা paid placement প্রমাণ করে না। অপ্রাসঙ্গিক বা অসম্পূর্ণ আবেদন “প্রকাশ করা হয়নি” বা “Archive” করে রাখুন।</div>
      {message ? <p aria-live="polite" className="mt-4 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200">{message}</p> : null}

      {submissionsQuery.isLoading ? <div className="mt-5 flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 p-4 text-sm text-slate-300"><Loader2 className="h-4 w-4 animate-spin" />আবেদন লোড হচ্ছে…</div> : submissions.length === 0 ? <div className="mt-5 rounded-xl border border-dashed border-slate-700 bg-slate-900/50 p-6 text-center text-sm text-slate-300"><Building2 className="mx-auto h-6 w-6 text-slate-500" /><p className="mt-2">এখনও কোনো Business Directory আবেদন নেই।</p></div> : <div className="mt-5 grid gap-4">{submissions.map((submission) => {
        const activeStatus = statuses[submission.id] ?? submission.status;
        const status = statusCopy[activeStatus];
        const StatusIcon = status.icon;
        return <article key={submission.id} className="rounded-2xl border border-slate-700 bg-slate-900/80 p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div><p className="text-xs font-bold uppercase tracking-[0.14em] text-cyan-300">{submission.category}</p><h4 className="mt-1 text-lg font-bold text-white">{submission.businessName}</h4><p className="mt-1 inline-flex items-center gap-1.5 text-sm text-slate-300"><MapPin className="h-3.5 w-3.5 text-cyan-300" />{submission.district}</p></div>
            <span className={`inline-flex items-center gap-1.5 self-start rounded-full border px-2.5 py-1 text-xs font-bold ${status.className}`}><StatusIcon className="h-3.5 w-3.5" />{status.label}</span>
          </div>
          <p className="mt-3 text-sm leading-6 text-slate-200">{submission.publicDescription}</p>
          {submission.publicWebsiteUrl ? <p className="mt-2 break-all text-xs text-cyan-200">Public website: {submission.publicWebsiteUrl}</p> : null}
          <div className="mt-4 grid gap-2 rounded-xl border border-slate-700 bg-slate-950/70 p-3 text-sm text-slate-200 sm:grid-cols-3"><p className="flex min-w-0 items-center gap-2"><Send className="h-4 w-4 shrink-0 text-slate-400" /><span className="truncate">{submission.contactName}</span></p><p className="flex min-w-0 items-center gap-2"><Mail className="h-4 w-4 shrink-0 text-slate-400" /><span className="truncate">{submission.contactEmail}</span></p><p className="flex min-w-0 items-center gap-2"><Phone className="h-4 w-4 shrink-0 text-slate-400" /><span className="truncate">{submission.contactPhone}</span></p></div>
          <div className="mt-4 grid gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(0,1.5fr)_auto] sm:items-end"><label className="text-xs font-semibold text-slate-300">Review status<select value={activeStatus} onChange={(event) => setStatuses((current) => ({ ...current, [submission.id]: event.target.value as ReviewStatus }))} className="mt-1.5 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/25"><option value="pending">Review বাকি</option><option value="published">Public-এ প্রকাশিত</option><option value="declined">প্রকাশ করা হয়নি</option><option value="archived">Archive</option></select></label><label className="text-xs font-semibold text-slate-300">Private owner note<textarea value={notes[submission.id] ?? ""} onChange={(event) => setNotes((current) => ({ ...current, [submission.id]: event.target.value }))} maxLength={1500} rows={2} placeholder="শুধু owner-এর জন্য নোট" className="mt-1.5 w-full resize-y rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white placeholder:text-slate-600 focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/25" /></label><button type="button" onClick={() => save(submission.id)} disabled={updateReview.isPending} className="inline-flex items-center justify-center gap-2 rounded-lg bg-cyan-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-cyan-500 disabled:cursor-not-allowed disabled:opacity-60"><CheckCircle2 className="h-4 w-4" />{updateReview.isPending ? "সংরক্ষণ হচ্ছে…" : "Review সংরক্ষণ"}</button></div>
        </article>;
      })}</div>}
    </section>
  );
}
