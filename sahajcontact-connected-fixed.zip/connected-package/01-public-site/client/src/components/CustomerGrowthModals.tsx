import { useEffect, useState } from "react";
import { ArrowRight, Compass, HelpCircle, ShieldCheck, X } from "lucide-react";
import { trackEvent } from "@/lib/analytics";
import { useServiceFinderVisibility } from "@/hooks/useServiceFinderVisibility";

// Owner decision: no unsolicited popup, callback lead collection, or public payment flow.
const WELCOME_POPUP_AUTO_OPEN_ENABLED = false;

const SERVICE_TOPICS = [
  { id: "nid", label: "NID ও নাগরিক নিবন্ধন", guidance: "প্রাসঙ্গিক সরকারি পোর্টাল ও স্থানীয় নির্বাচন অফিসের নির্দেশনা যাচাই করুন।" },
  { id: "passport", label: "পাসপোর্ট ও ভ্রমণ", guidance: "ই-পাসপোর্টের জন্য কেবল সরকারি নির্দেশনা ও নির্ধারিত আবেদন-পথ ব্যবহার করুন।" },
  { id: "allowance", label: "ভাতা ও সামাজিক সুরক্ষা", guidance: "যোগ্যতা ও আবেদন-সময়সীমা স্থানীয় সরকারি অফিস বা অনুমোদিত সরকারি পোর্টাল থেকে নিশ্চিত করুন।" },
  { id: "business", label: "ব্যবসা ও ট্রেড লাইসেন্স", guidance: "ট্রেড লাইসেন্স ও ব্যবসায়িক সেবার শর্ত সংশ্লিষ্ট স্থানীয় কর্তৃপক্ষ থেকে যাচাই করুন।" },
];

export function CustomerGrowthModals() {
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [showFinderModal, setShowFinderModal] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const hideFloatingActions = useServiceFinderVisibility();

  useEffect(() => {
    if (!WELCOME_POPUP_AUTO_OPEN_ENABLED) return;
    const timer = window.setTimeout(() => setShowWelcomeModal(true), 7000);
    return () => window.clearTimeout(timer);
  }, []);

  const activeTopic = SERVICE_TOPICS.find(topic => topic.id === selectedTopic) ?? null;

  return (
    <>
      {!hideFloatingActions && (
        <div className="fixed bottom-24 left-4 z-40 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => {
              trackEvent("sahaj_service_finder_open", { source: "floating_button" });
              setSelectedTopic(null);
              setShowFinderModal(true);
            }}
            className="bg-teal-700 text-white px-3.5 py-2.5 rounded-full shadow-lg flex items-center gap-2 font-semibold text-xs md:text-sm hover:bg-teal-800 transition-all transform hover:scale-105 border border-teal-400/30"
            title="কোন সেবার সরকারি তথ্য প্রয়োজন?"
          >
            <HelpCircle size={16} className="text-amber-300" />
            <span>সেবা ফাইন্ডার</span>
          </button>
        </div>
      )}

      {showWelcomeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border-t-4 border-teal-600 relative">
            <button type="button" onClick={() => setShowWelcomeModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1" aria-label="বন্ধ করুন"><X size={20} /></button>
            <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-full">সহজসেবা তথ্য সহায়ক</span>
            <h3 className="text-xl font-extrabold text-gray-900 mt-3">সঠিক সরকারি তথ্য খুঁজুন</h3>
            <p className="text-gray-600 text-sm leading-relaxed mt-2">আমরা এখানে কোনো আবেদন, কলব্যাক, payment বা ব্যক্তিগত তথ্য গ্রহণ করি না।</p>
            <button type="button" onClick={() => { setShowWelcomeModal(false); setShowFinderModal(true); }} className="mt-5 w-full bg-teal-700 hover:bg-teal-800 text-white font-bold py-2.5 px-4 rounded-xl text-sm transition-all">সেবা ফাইন্ডার খুলুন</button>
          </div>
        </div>
      )}

      {showFinderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <section className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border-t-4 border-teal-600 relative" aria-labelledby="service-finder-heading">
            <button type="button" onClick={() => setShowFinderModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1" aria-label="বন্ধ করুন"><X size={20} /></button>
            <div className="flex items-center gap-3 pr-8">
              <div className="w-11 h-11 rounded-full bg-teal-100 flex items-center justify-center text-teal-700"><Compass size={23} /></div>
              <div><span className="text-xs font-bold text-teal-700">READ-ONLY GUIDANCE</span><h3 id="service-finder-heading" className="text-xl font-extrabold text-gray-900 mt-0.5">কোন সেবার তথ্য প্রয়োজন?</h3></div>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed mt-4">একটি বিষয় বেছে নিন। এই সহায়কটি শুধু পথনির্দেশ দেয়; এটি আবেদন, অর্ডার, কলব্যাক বা payment নেয় না।</p>
            <div className="grid gap-2 mt-4">
              {SERVICE_TOPICS.map(topic => (
                <button key={topic.id} type="button" onClick={() => { setSelectedTopic(topic.id); trackEvent("sahaj_service_finder_select", { topic: topic.id }); }} className={`w-full text-left border rounded-xl p-3 text-sm font-semibold transition-colors flex items-center justify-between ${selectedTopic === topic.id ? "border-teal-600 bg-teal-50 text-teal-900" : "border-gray-200 hover:border-teal-300 text-gray-800"}`}>
                  <span>{topic.label}</span><ArrowRight size={16} className="text-teal-600" />
                </button>
              ))}
            </div>
            {activeTopic && <div className="mt-4 rounded-xl bg-slate-50 border border-slate-200 p-4 text-sm text-slate-700 leading-6"><strong className="block text-slate-900 mb-1">{activeTopic.label}</strong>{activeTopic.guidance}</div>}
            <div className="mt-5 rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900 leading-5 flex gap-2"><ShieldCheck size={16} className="shrink-0 mt-0.5" /> <span>OTP, PIN, পাসওয়ার্ড, payment number বা transaction ID কখনো শেয়ার করবেন না।</span></div>
            <div className="mt-5 flex flex-wrap gap-3"><a href="/bangladesh" className="text-sm font-bold text-teal-800 hover:underline">সরকারি তথ্য দেখুন</a><a href="/contact" className="text-sm font-bold text-slate-700 hover:underline">সাধারণ যোগাযোগ</a></div>
          </section>
        </div>
      )}
    </>
  );
}
