import { useEffect, useState, type ReactNode } from "react";

type DeferredMountProps = {
  children: ReactNode;
  delay?: number;
};

/**
 * Mounts non-critical UI after the browser has had a chance to paint the
 * primary page. The timeout fallback keeps the feature available in browsers
 * without requestIdleCallback.
 */
export default function DeferredMount({ children, delay = 1200 }: DeferredMountProps) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let timeoutId: number | undefined;
    let idleId: number | undefined;

    const activate = () => {
      if (!cancelled) setReady(true);
    };

    if (typeof window.requestIdleCallback === "function") {
      idleId = window.requestIdleCallback(activate, { timeout: delay });
    }
    timeoutId = window.setTimeout(activate, delay);

    return () => {
      cancelled = true;
      if (idleId !== undefined && typeof window.cancelIdleCallback === "function") {
        window.cancelIdleCallback(idleId);
      }
      if (timeoutId !== undefined) window.clearTimeout(timeoutId);
    };
  }, [delay]);

  return ready ? children : null;
}
