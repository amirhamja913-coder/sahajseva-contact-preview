import { ArrowUpRight, Award, BadgeCheck, BookOpen, GraduationCap, School } from "lucide-react";
import { trackEvent, trackOutbound } from "@/lib/analytics";
import { Link } from "wouter";
type Language = "BN" | "EN";

type EducationHubCard = {
  id: number;
  slug: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  iconName: string;
  officialUrl: string;
  visible: number;
  displayOrder: number;
};

type EducationHubSectionProps = {
  cards: EducationHubCard[];
  language: Language;
};

const iconMap = { School, GraduationCap, BookOpen, BadgeCheck, Award } as const;
const educationLogoUrl = "/manus-storage/sahajcontact-education-logo_39c45116.png";

function getIcon(iconName: string) {
  return iconMap[iconName as keyof typeof iconMap] ?? BookOpen;
}

export default function EducationHubSection({ cards, language }: EducationHubSectionProps) {
  if (cards.length === 0) return null;
  const isBangla = language === "BN";
  const visibleCards = [...cards].sort((a, b) => a.displayOrder - b.displayOrder);

  return (
    <section id="education-hub" aria-labelledby="education-hub-heading" style={{ padding: "4rem 0", background: "linear-gradient(135deg, #f0fdf4 0%, #ecfeff 48%, #fffaf0 100%)", borderTop: "1px solid #d1fae5", borderBottom: "1px solid #dbeafe" }}>
      <div className="container">
        <details data-service-folder="education-hub" className="education-hub-folder" style={{ background: "#ffffffb8", border: "1px solid #a7f3d0", borderRadius: "20px", boxShadow: "0 12px 28px rgba(15, 118, 110, 0.09)", overflow: "hidden" }}>
          <summary aria-label={isBangla ? "শিক্ষা তথ্যকেন্দ্র খুলুন" : "Open education information hub"} style={{ listStyle: "none", cursor: "pointer", padding: "1.15rem 1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", background: "linear-gradient(135deg, #f0fdf4 0%, #ffffff 65%, #ecfeff 100%)" }}>
            <span style={{ display: "flex", alignItems: "center", gap: "1rem", minWidth: 0 }}>
              <span aria-hidden="true" style={{ position: "relative", width: "clamp(3.5rem, 9vw, 5.25rem)", height: "clamp(3.5rem, 9vw, 5.25rem)", flex: "0 0 auto", display: "inline-flex", alignItems: "center", justifyContent: "center", overflow: "hidden", borderRadius: "999px", background: "linear-gradient(145deg, #d1fae5, #ecfeff)", border: "2px solid #a7f3d0", color: "#0f766e", boxShadow: "0 8px 14px rgba(15, 118, 110, 0.14)" }}>
                <GraduationCap size={30} strokeWidth={2.15} />
                <img src={educationLogoUrl} alt="" loading="lazy" onError={(event) => { event.currentTarget.style.display = "none"; }} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", background: "transparent" }} />
              </span>
              <span style={{ minWidth: 0 }}>
                <span className="section-number" style={{ display: "block", color: "#0f766e", fontWeight: 800 }}>{isBangla ? "০৫ / শিক্ষা-পথ" : "05 / EDUCATION WAYFINDER"}</span>
                <span id="education-hub-heading" style={{ display: "block", marginTop: "0.3rem", color: "#123d42", fontSize: "clamp(1.35rem, 4vw, 2.35rem)", lineHeight: 1.08, fontWeight: 900 }}>
                  {isBangla ? "আপনার সন্তানকে শিক্ষিত করে তুলুন" : "Educate Your Child"}
                </span>
                <span style={{ display: "block", marginTop: "0.4rem", color: "#456267", fontSize: "0.88rem", lineHeight: 1.45 }}>{isBangla ? "অফিসিয়াল শিক্ষা তথ্য দেখতে ট্যাপ করুন" : "Tap to view official education information"}</span>
              </span>
            </span>
            <span aria-hidden="true" style={{ flex: "0 0 auto", width: "2.4rem", height: "2.4rem", borderRadius: "999px", display: "inline-flex", alignItems: "center", justifyContent: "center", background: "#0f766e", color: "#fff", fontSize: "1.45rem", lineHeight: 1 }}>+</span>
          </summary>

          <div style={{ padding: "1.25rem" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", marginBottom: "1rem" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", padding: "0.55rem 0.8rem", borderRadius: "999px", background: "#ffffffcc", color: "#0f766e", border: "1px solid #a7f3d0", fontWeight: 800, fontSize: "0.82rem" }}>
                <BookOpen size={15} aria-hidden="true" /> {isBangla ? "একটি তথ্যকেন্দ্র" : "One information hub"}
              </span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 235px), 1fr))", gap: "1rem" }}>
          {visibleCards.map((card) => {
            const Icon = getIcon(card.iconName);
            const title = isBangla ? card.titleBn : card.titleEn;
            const description = isBangla ? card.descriptionBn : card.descriptionEn;
            return (
              <article key={card.id} style={{ display: "flex", flexDirection: "column", minWidth: 0, background: "#ffffff", border: "1px solid #d1fae5", borderRadius: "18px", padding: "1.15rem", boxShadow: "0 10px 24px rgba(15, 118, 110, 0.08)" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.7rem" }}>
                  <span style={{ width: "2.7rem", height: "2.7rem", flex: "0 0 auto", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: "14px", background: "#d1fae5", color: "#047857" }} aria-hidden="true"><Icon size={23} strokeWidth={2.15} /></span>
                  <span style={{ color: "#94a3b8", fontSize: "0.75rem", fontWeight: 800 }}>0{card.displayOrder}</span>
                </div>
                <h3 style={{ margin: "1rem 0 0.45rem", color: "#123d42", fontSize: "1.12rem", lineHeight: 1.25, fontWeight: 900 }}>{title}</h3>
                <p style={{ flex: 1, margin: 0, color: "#53686b", fontSize: "0.91rem", lineHeight: 1.55 }}>{description}</p>
                <div style={{ display: "flex", flexDirection: "column", gap: "0.55rem", marginTop: "1rem" }}>
                  <a
                    href={card.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.35rem", minHeight: "2.65rem", padding: "0.65rem 0.8rem", borderRadius: "999px", background: "#0f766e", color: "#ffffff", textDecoration: "none", fontWeight: 850, fontSize: "0.84rem" }}
                    onClick={() => { trackEvent("education_official_click", { card: card.slug, title: title }); trackOutbound(title, card.officialUrl, "education_hub"); }}
                  >
                    {isBangla ? "অফিসিয়াল তথ্য" : "Official information"} <ArrowUpRight size={14} aria-hidden="true" />
                  </a>
                  <Link
                      href="/contact"
                      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.35rem", minHeight: "2.55rem", padding: "0.6rem 0.8rem", borderRadius: "999px", background: "#ecfdf5", color: "#047857", border: "1px solid #a7f3d0", textDecoration: "none", fontWeight: 850, fontSize: "0.82rem" }}
                      onClick={() => trackEvent("education_contact_route_click", { card: card.slug, title: title })}
                    >
                      {isBangla ? "প্রশ্নের জন্য Contact পেজ" : "Questions via Contact page"}
                  </Link>
                </div>
              </article>
            );
          })}
            </div>
            <p style={{ margin: "1.25rem 0 0", color: "#64748b", fontSize: "0.8rem", lineHeight: 1.5 }}>
              {isBangla ? "সাহজসেবা কোনো শিক্ষা প্রতিষ্ঠান বা সরকারি কর্তৃপক্ষ নয়। ভর্তি, ফলাফল, বৃত্তি বা ভাতার সিদ্ধান্ত সংশ্লিষ্ট কর্তৃপক্ষের।" : "SahajContact is not an education institution or government authority. Admission, results, scholarships, and allowances are decided by the relevant authority."}
            </p>
          </div>
        </details>
      </div>
    </section>
  );
}
