import { useEffect } from "react";

function isExternalWebLink(href: string) {
  try {
    const destination = new URL(href, window.location.href);
    return (destination.protocol === "http:" || destination.protocol === "https:") && destination.origin !== window.location.origin;
  } catch {
    return false;
  }
}

function secureExternalAnchor(anchor: HTMLAnchorElement) {
  if (!isExternalWebLink(anchor.href)) return;

  anchor.target = "_blank";
  const relTokens = new Set(anchor.rel.split(/\s+/).filter(Boolean));
  relTokens.add("noopener");
  relTokens.add("noreferrer");
  anchor.rel = Array.from(relTokens).join(" ");
  anchor.dataset.externalLinkPolicy = "secure";
}

function secureExternalAnchors(root: ParentNode) {
  if (root instanceof HTMLAnchorElement) secureExternalAnchor(root);
  root.querySelectorAll<HTMLAnchorElement>("a[href]").forEach(secureExternalAnchor);
}

/**
 * Keeps all ordinary same-origin navigation in the current tab, while every
 * rendered http(s) destination outside SahajContact opens safely in a new tab.
 * It also covers data-driven and lazily mounted public cards without requiring
 * each CMS renderer to duplicate the same security attributes.
 */
export default function ExternalLinkSecurityPolicy() {
  useEffect(() => {
    secureExternalAnchors(document);

    const observer = new MutationObserver(records => {
      records.forEach(record => {
        if (record.type === "attributes" && record.target instanceof HTMLAnchorElement) {
          secureExternalAnchor(record.target);
          return;
        }
        record.addedNodes.forEach(node => {
          if (node instanceof Element) secureExternalAnchors(node);
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["href"],
    });

    return () => observer.disconnect();
  }, []);

  return null;
}
