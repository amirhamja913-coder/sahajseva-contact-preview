import { useState, type ReactNode } from "react";
import { AlertTriangle, ExternalLink } from "lucide-react";

interface ExternalLinkWithFallbackProps {
  href: string;
  title: string;
  className?: string;
  wrapperClassName?: string;
  ariaLabel?: string;
  showExternalIcon?: boolean;
  children: ReactNode;
  onClick?: () => void;
}

export function ExternalLinkWithFallback({
  href,
  title,
  className = "",
  wrapperClassName = "",
  ariaLabel,
  showExternalIcon = true,
  children,
  onClick,
}: ExternalLinkWithFallbackProps) {
  const [showNotice, setShowNotice] = useState(false);

  return (
    <span className={`external-link-fallback ${wrapperClassName}`.trim()}>
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={className}
        aria-label={ariaLabel}
        onClick={onClick}
      >
        {children}
        {showExternalIcon ? <ExternalLink className="w-3.5 h-3.5 inline-block ml-1 opacity-70" aria-hidden="true" /> : null}
      </a>
      <button
        type="button"
        onClick={() => setShowNotice((visible) => !visible)}
        className="external-link-help text-xs text-amber-700 dark:text-amber-400 hover:underline inline-flex items-center gap-0.5 px-1 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900"
        title="লিংক কাজ না করলে করণীয়"
        aria-expanded={showNotice}
        aria-label={`${title} লিংক কাজ না করলে করণীয় দেখুন`}
      >
        <AlertTriangle className="w-3 h-3" aria-hidden="true" />
        <span>সাহায্য</span>
      </button>

      {showNotice && (
        <span
          className="external-link-notice w-full text-xs text-muted-foreground bg-muted/80 p-2 rounded border border-border mt-1 block"
          role="status"
          aria-live="polite"
        >
          <strong>সরকারি সাইট সাময়িক ধীরগতির হলে:</strong> কিছুক্ষণ পর আবার চেষ্টা করুন অথবা সংশ্লিষ্ট অধিদপ্তরের হেল্পলাইনে (যেমন ৩৩৩ বা সংশ্লিষ্ট হটলাইন) যোগাযোগ করুন। <span className="font-medium">“{title}”</span> লিংকে ফিরে গিয়ে পুনরায় চেষ্টা করতে পারেন।
        </span>
      )}
    </span>
  );
}
