import { ArrowUpRight, Banknote, Building2, CreditCard, Landmark, ShieldCheck, WalletCards } from "lucide-react";
import { trackEvent, trackOutbound } from "@/lib/analytics";

const bankServicesLogoUrl = "/manus-storage/sahajcontact-bank-services-logo_6954f5de.png";

type Language = "BN" | "EN";

type FinancialServiceCard = {
  id: number;
  slug: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  disclaimerBn: string;
  disclaimerEn: string;
  buttonLabelBn: string;
  buttonLabelEn: string;
  iconName: string;
  officialUrl: string;
  visible: number;
  displayOrder: number;
};

type FinancialServicesSectionProps = {
  cards: FinancialServiceCard[];
  language: Language;
};

const iconMap = { Landmark, Banknote, WalletCards, CreditCard, Building2, ShieldCheck } as const;

function getIcon(iconName: string) {
  // Only render an explicit, reviewed icon set. Unknown legacy values retain the
  // neutral civic landmark fallback instead of allowing arbitrary components.
  return iconMap[iconName as keyof typeof iconMap] ?? Landmark;
}

export default function FinancialServicesSection({ cards, language }: FinancialServicesSectionProps) {
  if (cards.length === 0) return null;
  const isBangla = language === "BN";
  const visibleCards = [...cards].filter((card) => card.visible === 1).sort((a, b) => a.displayOrder - b.displayOrder);

  return (
    <section id="financial-services" aria-labelledby="financial-services-heading" style={{ padding: "3.25rem 0", background: "linear-gradient(135deg, #eff6ff 0%, #f8fafc 52%, #fff7ed 100%)", borderTop: "1px solid #dbeafe", borderBottom: "1px solid #fed7aa" }}>
      <div className="container">
        <details data-service-folder="bank-directory" className="financial-services-folder" style={{ background: "#ffffffb8", border: "1px solid #bfdbfe", borderRadius: "20px", boxShadow: "0 12px 28px rgba(30, 64, 175, 0.09)", overflow: "hidden" }}>
          <summary aria-label={isBangla ? "ব্যাংক ও আর্থিক সেবা খুলুন" : "Open Bank and Financial Services"} style={{ listStyle: "none", cursor: "pointer", padding: "1.15rem 1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", background: "linear-gradient(135deg, #eff6ff 0%, #ffffff 65%, #fff7ed 100%)" }}>
            <span style={{ display: "flex", alignItems: "center", gap: "1rem", minWidth: 0 }}>
              <span aria-hidden="true" style={{ position: "relative", width: "clamp(3.5rem, 9vw, 5.25rem)", height: "clamp(3.5rem, 9vw, 5.25rem)", flex: "0 0 auto", display: "inline-flex", alignItems: "center", justifyContent: "center", overflow: "hidden", borderRadius: "999px", background: "linear-gradient(145deg, #dbeafe, #fff7ed)", border: "2px solid #bfdbfe", color: "#1d4ed8", boxShadow: "0 8px 14px rgba(30, 64, 175, 0.14)" }}>
                <Landmark size={30} strokeWidth={2.15} />
                <img src={bankServicesLogoUrl} alt="" loading="lazy" onError={(event) => { event.currentTarget.style.display = "none"; }} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", background: "transparent" }} />
              </span>
              <span style={{ minWidth: 0 }}>
                <span className="section-number" style={{ display: "block", color: "#1d4ed8", fontWeight: 800 }}>{isBangla ? "০৭ / ব্যাংক ও আর্থিক সেবা" : "07 / BANKING & FINANCIAL SERVICES"}</span>
                <span id="financial-services-heading" style={{ display: "block", marginTop: "0.3rem", color: "#172554", fontSize: "clamp(1.35rem, 4vw, 2.25rem)", lineHeight: 1.08, fontWeight: 900 }}>
                  {isBangla ? "ব্যাংক ও আর্থিক সেবা" : "Bank and Financial Services"}
                </span>
                <span style={{ display: "block", marginTop: "0.35rem", color: "#475569", fontSize: "0.88rem", lineHeight: 1.45 }}>{isBangla ? "ডিরেক্টরি ও অফিসিয়াল তথ্য দেখতে ট্যাপ করুন" : "Tap to view the directory and official information"}</span>
              </span>
            </span>
            <span aria-hidden="true" style={{ flex: "0 0 auto", width: "2.4rem", height: "2.4rem", borderRadius: "999px", display: "inline-flex", alignItems: "center", justifyContent: "center", background: "#1d4ed8", color: "#fff", fontSize: "1.45rem", lineHeight: 1 }}>+</span>
          </summary>

          <div style={{ padding: "1.25rem" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", marginBottom: "1rem" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", padding: "0.55rem 0.8rem", borderRadius: "999px", background: "#ffffffcc", color: "#1d4ed8", border: "1px solid #bfdbfe", fontWeight: 800, fontSize: "0.82rem" }}>
                <Landmark size={15} aria-hidden="true" /> {isBangla ? "অফিসিয়াল ডিরেক্টরি" : "Official directory"}
              </span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 260px), 1fr))", gap: "1rem" }}>
          {visibleCards.map((card) => {
            const Icon = getIcon(card.iconName);
            const title = isBangla ? card.titleBn : card.titleEn;
            const description = isBangla ? card.descriptionBn : card.descriptionEn;
            const disclaimer = isBangla ? card.disclaimerBn : card.disclaimerEn;
            const buttonLabel = isBangla ? card.buttonLabelBn : card.buttonLabelEn;
            return (
              <article key={card.id} style={{ display: "flex", flexDirection: "column", minWidth: 0, background: "#ffffff", border: "1px solid #bfdbfe", borderRadius: "18px", padding: "1.15rem", boxShadow: "0 10px 24px rgba(30, 64, 175, 0.08)" }}>
                <span style={{ width: "2.7rem", height: "2.7rem", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: "14px", background: "#dbeafe", color: "#1d4ed8" }} aria-hidden="true"><Icon size={23} strokeWidth={2.15} /></span>
                <h3 style={{ margin: "1rem 0 0.45rem", color: "#172554", fontSize: "1.12rem", lineHeight: 1.25, fontWeight: 900 }}>{title}</h3>
                <p style={{ flex: 1, margin: 0, color: "#475569", fontSize: "0.91rem", lineHeight: 1.55 }}>{description}</p>
                <a
                  href={card.officialUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.35rem", minHeight: "2.8rem", marginTop: "1rem", padding: "0.65rem 0.8rem", borderRadius: "999px", background: "#1d4ed8", color: "#ffffff", textDecoration: "none", fontWeight: 850, fontSize: "0.84rem" }}
                  onClick={() => { trackEvent("bank_directory_click", { card: card.slug, title }); trackOutbound(title, card.officialUrl, "financial_services"); }}
                >
                  {buttonLabel} <ArrowUpRight size={14} aria-hidden="true" />
                </a>
                <p style={{ margin: "0.9rem 0 0", padding: "0.7rem 0.75rem", borderRadius: "12px", background: "#fff7ed", border: "1px solid #fed7aa", color: "#9a3412", fontSize: "0.78rem", lineHeight: 1.5 }}>{disclaimer}</p>
              </article>
            );
          })}
            </div>
          </div>
        </details>
      </div>
    </section>
  );
}
