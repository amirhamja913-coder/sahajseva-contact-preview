import { useEffect, useMemo, useState } from "react";
import { Bell, Edit3, FileImage, FileText, Home, Link2, Pin, Plus, Save, Trash2, Upload, Video } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

type ContentSettings = {
  heroTitleBn: string | null; heroTitleEn: string | null; heroSubtitleBn: string | null; heroSubtitleEn: string | null;
  heroBackgroundImageUrl: string | null; heroVideoUrl: string | null; heroAccentMessageBn: string | null; heroAccentMessageEn: string | null;
  primaryCtaLabelBn: string | null; primaryCtaLabelEn: string | null; primaryCtaHref: string | null;
  ownerNoticeTitleBn: string | null; ownerNoticeTitleEn: string | null; ownerNoticeTextBn: string | null; ownerNoticeTextEn: string | null;
  noticeVisible: number; quickLinksVisible: number; showStatActiveUsers: number; showStatPageViews: number; showStatKeyEvents: number; showStatTopCountries: number; showStatEngagement: number; showStatShares: number; brandAccentColor: string; brandHighlightColor: string; logoUrl?: string | null;
  siteNameBn: string | null; siteNameEn: string | null; headerTaglineBn: string | null; headerTaglineEn: string | null; contactPhone: string | null; contactEmail: string | null; socialLinksJson: string | null;
  notFoundTitleBn: string | null; notFoundTitleEn: string | null; notFoundMessageBn: string | null; notFoundMessageEn: string | null;
};

type QuickLink = {
  id: number; titleBn: string; titleEn: string | null; url: string; descriptionBn: string | null; descriptionEn: string | null;
  iconName: string; iconImageUrl: string | null; openInNewTab: number; visible: number; displayOrder: number;
};

type BlogPost = {
  id: number; titleBn: string; titleEn: string | null; slug: string; excerptBn: string; excerptEn: string | null;
  contentBn: string; contentEn: string | null; coverImageUrl: string | null; pdfUrl: string | null; isPinned: number; status: "draft" | "published";
  publishedAt?: string | Date | null; updatedAt: string | Date;
};

const emptySettings: ContentSettings = {
  heroTitleBn: "", heroTitleEn: "", heroSubtitleBn: "", heroSubtitleEn: "", heroBackgroundImageUrl: "", heroVideoUrl: "",
  heroAccentMessageBn: "", heroAccentMessageEn: "", primaryCtaLabelBn: "", primaryCtaLabelEn: "", primaryCtaHref: "",
  ownerNoticeTitleBn: "", ownerNoticeTitleEn: "", ownerNoticeTextBn: "", ownerNoticeTextEn: "", noticeVisible: 0, quickLinksVisible: 1, showStatActiveUsers: 1, showStatPageViews: 1, showStatKeyEvents: 0, showStatTopCountries: 1, showStatEngagement: 0, showStatShares: 1,
  brandAccentColor: "#0d5c56", brandHighlightColor: "#f2b84b", logoUrl: "", siteNameBn: "", siteNameEn: "", headerTaglineBn: "", headerTaglineEn: "", contactPhone: "",
  contactEmail: "", socialLinksJson: "", notFoundTitleBn: "পৃষ্ঠা পাওয়া যায়নি", notFoundTitleEn: "Page not found", notFoundMessageBn: "দুঃখিত, এই পৃষ্ঠাটি পাওয়া যায়নি।", notFoundMessageEn: "Sorry, this page could not be found.",
};

const emptyNotice = { id: null as number | null, titleBn: "", titleEn: "", slug: "", excerptBn: "", excerptEn: "", contentBn: "", contentEn: "", coverImageUrl: "", pdfUrl: "", isPinned: false, status: "draft" as "draft" | "published" };

async function fileToDataUrl(file: File) {
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি।"));
    reader.readAsDataURL(file);
  });
}

function Field({ label, children, wide = false }: { label: string; children: React.ReactNode; wide?: boolean }) {
  return <label className={`grid gap-1.5 text-xs text-slate-300 ${wide ? "sm:col-span-2" : ""}`}><span>{label}</span>{children}</label>;
}

const inputClass = "rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none transition focus:border-emerald-400";

export function HomepageBuilderPanel({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const workspace = trpc.siteManagement.getOwnerWorkspace.useQuery(undefined, { enabled: isOwner, retry: false });
  const announcement = trpc.siteManagement.management.getAnnouncement.useQuery(undefined, { enabled: isOwner, retry: false });
  const utils = trpc.useUtils();
  const upload = trpc.gallery.uploadBase64.useMutation();
  const [settings, setSettings] = useState<ContentSettings>(emptySettings);
  const [announcementForm, setAnnouncementForm] = useState({ messageBn: "", messageEn: "", linkUrl: "", color: "#0d5c56", enabled: false });
  const [message, setMessage] = useState("");
  const [linkDraft, setLinkDraft] = useState<QuickLink | null>(null);
  const [linkForm, setLinkForm] = useState({ titleBn: "", titleEn: "", url: "", descriptionBn: "", descriptionEn: "", iconName: "Link2", iconImageUrl: null as string | null, openInNewTab: true, visible: true, displayOrder: 0 });

  useEffect(() => {
    if (workspace.data?.settings) setSettings({ ...emptySettings, ...(workspace.data.settings as Partial<ContentSettings>) });
  }, [workspace.data?.settings]);
  useEffect(() => {
    if (announcement.data) setAnnouncementForm({ messageBn: announcement.data.messageBn ?? "", messageEn: announcement.data.messageEn ?? "", linkUrl: announcement.data.linkUrl ?? "", color: announcement.data.color ?? "#0d5c56", enabled: announcement.data.enabled === 1 });
  }, [announcement.data]);

  const saveSettings = trpc.siteManagement.saveContentSettings.useMutation({
    onSuccess: async () => { await Promise.all([workspace.refetch(), utils.siteManagement.getPublicContent.invalidate()]); setMessage(language === "EN" ? "Homepage settings saved successfully." : "Homepage settings সফলভাবে সংরক্ষণ হয়েছে।"); },
    onError: (error) => setMessage(error.message),
  });
  const saveAnnouncement = trpc.siteManagement.management.saveAnnouncement.useMutation({
    onSuccess: async () => { await announcement.refetch(); await utils.siteManagement.getPublicContent.invalidate(); setMessage(language === "EN" ? "Announcement banner saved successfully." : "Announcement banner সফলভাবে সংরক্ষণ হয়েছে।"); },
    onError: (error) => setMessage(error.message),
  });
  const createLink = trpc.siteManagement.createQuickLink.useMutation({ onSuccess: async () => { await workspace.refetch(); setLinkForm({ titleBn: "", titleEn: "", url: "", descriptionBn: "", descriptionEn: "", iconName: "Link2", iconImageUrl: null, openInNewTab: true, visible: true, displayOrder: 0 }); setMessage(language === "EN" ? "Quick link added successfully." : "Quick link সফলভাবে যোগ হয়েছে."); }, onError: (error) => setMessage(error.message) });
  const updateLink = trpc.siteManagement.updateQuickLink.useMutation({ onSuccess: async () => { await workspace.refetch(); setLinkDraft(null); setMessage(language === "EN" ? "Quick link updated successfully." : "Quick link সফলভাবে আপডেট হয়েছে।"); }, onError: (error) => setMessage(error.message) });
  const deleteLink = trpc.siteManagement.deleteQuickLink.useMutation({ onSuccess: async () => { await workspace.refetch(); setMessage(language === "EN" ? "Quick link deleted successfully." : "Quick link সফলভাবে মুছে ফেলা হয়েছে।"); }, onError: (error) => setMessage(error.message) });

  const uploadAsset = async (file: File, target: "heroBackgroundImageUrl" | "heroVideoUrl" | "logoUrl") => {
    if (file.size > 15 * 1024 * 1024) { setMessage(language === "EN" ? "Maximum file size is 15 MB." : "সর্বোচ্চ ১৫ MB ফাইল দিন।"); return; }
    try { const result = await upload.mutateAsync({ base64Data: await fileToDataUrl(file), fileName: `cms/homepage-${Date.now()}-${file.name.replace(/[^a-z0-9._-]/gi, "-")}`, contentType: file.type }); setSettings((current) => ({ ...current, [target]: result.url })); setMessage(language === "EN" ? "Media uploaded. Save changes to publish it." : "মিডিয়া আপলোড হয়েছে। প্রকাশ করতে Save Changes চাপুন।"); } catch (error) { setMessage(error instanceof Error ? error.message : "Upload failed"); }
  };
  const submitSettings = (event: React.FormEvent) => { event.preventDefault(); saveSettings.mutate({ ...settings, noticeVisible: Boolean(settings.noticeVisible), quickLinksVisible: Boolean(settings.quickLinksVisible), showStatActiveUsers: Boolean(settings.showStatActiveUsers), showStatPageViews: Boolean(settings.showStatPageViews), showStatKeyEvents: Boolean(settings.showStatKeyEvents), showStatTopCountries: Boolean(settings.showStatTopCountries), showStatEngagement: Boolean(settings.showStatEngagement), showStatShares: Boolean(settings.showStatShares), logoUrl: settings.logoUrl || null }); };
  const startEditLink = (link: QuickLink) => { setLinkDraft(link); setLinkForm({ titleBn: link.titleBn, titleEn: link.titleEn ?? "", url: link.url, descriptionBn: link.descriptionBn ?? "", descriptionEn: link.descriptionEn ?? "", iconName: link.iconName, iconImageUrl: link.iconImageUrl, openInNewTab: link.openInNewTab === 1, visible: link.visible === 1, displayOrder: link.displayOrder }); };
  const submitLink = (event: React.FormEvent) => { event.preventDefault(); const payload = { ...linkForm, titleEn: linkForm.titleEn.trim() || null, descriptionBn: linkForm.descriptionBn.trim() || null, descriptionEn: linkForm.descriptionEn.trim() || null }; if (linkDraft) updateLink.mutate({ id: linkDraft.id, ...payload }); else createLink.mutate(payload); };
  const updateSetting = (key: keyof ContentSettings, value: string | number | null) => setSettings((current) => ({ ...current, [key]: value }));
  const links = (workspace.data?.quickLinks ?? []) as QuickLink[];

  return <section className="rounded-2xl border border-emerald-500/25 bg-slate-900 p-5 shadow-xl sm:p-6">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><h2 className="flex items-center gap-2 text-xl font-bold text-white"><Home className="h-5 w-5 text-emerald-400" /> {language === "EN" ? "Homepage Builder" : "হোমপেজ বিল্ডার"}</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-slate-400">{language === "EN" ? "Control hero media, announcement banner, quick links, identity, contact and editable 404 copy from one owner-only panel." : "একটি owner-only panel থেকে Hero, Announcement, Quick Links, পরিচয়, যোগাযোগ এবং 404 পেজ নিয়ন্ত্রণ করুন।"}</p></div></div>
    {message && <div className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-950/35 px-4 py-3 text-sm text-emerald-200">{message}</div>}
    <form onSubmit={submitSettings} className="mt-5 grid gap-4 rounded-2xl border border-slate-800 bg-slate-950/50 p-4 sm:grid-cols-2">
      <div className="sm:col-span-2 flex items-center gap-2 text-sm font-bold text-slate-100"><Video className="h-4 w-4 text-amber-300" /> {language === "EN" ? "Hero & identity" : "Hero ও সাইট পরিচয়"}</div>
      <Field label="Hero title (বাংলা)"><input className={inputClass} value={settings.heroTitleBn ?? ""} onChange={(e) => updateSetting("heroTitleBn", e.target.value)} /></Field>
      <Field label="Hero title (English)"><input className={inputClass} value={settings.heroTitleEn ?? ""} onChange={(e) => updateSetting("heroTitleEn", e.target.value)} /></Field>
      <Field label="Hero description (বাংলা)" wide><textarea rows={3} className={inputClass} value={settings.heroSubtitleBn ?? ""} onChange={(e) => updateSetting("heroSubtitleBn", e.target.value)} /></Field>
      <Field label="Hero description (English)" wide><textarea rows={3} className={inputClass} value={settings.heroSubtitleEn ?? ""} onChange={(e) => updateSetting("heroSubtitleEn", e.target.value)} /></Field>
      <Field label="Hero সহায়ক লাইন (বাংলা)"><input className={inputClass} value={settings.heroAccentMessageBn ?? ""} onChange={(e) => updateSetting("heroAccentMessageBn", e.target.value)} placeholder="বাংলাদেশ-কেন্দ্রিক নাগরিক সহায়তা" /></Field>
      <Field label="Hero support line (English)"><input className={inputClass} value={settings.heroAccentMessageEn ?? ""} onChange={(e) => updateSetting("heroAccentMessageEn", e.target.value)} placeholder="Bangladesh-focused civic support" /></Field>
      <Field label="Hero background image URL"><input className={inputClass} value={settings.heroBackgroundImageUrl ?? ""} onChange={(e) => updateSetting("heroBackgroundImageUrl", e.target.value || null)} placeholder="/manus-storage/..." /><input type="file" accept="image/*" className="mt-2 text-xs text-slate-400" onChange={(e) => e.target.files?.[0] && uploadAsset(e.target.files[0], "heroBackgroundImageUrl")} /></Field>
      <Field label="Hero video URL"><input className={inputClass} value={settings.heroVideoUrl ?? ""} onChange={(e) => updateSetting("heroVideoUrl", e.target.value || null)} placeholder="https://...mp4" /><input type="file" accept="video/*" className="mt-2 text-xs text-slate-400" onChange={(e) => e.target.files?.[0] && uploadAsset(e.target.files[0], "heroVideoUrl")} /></Field>
      <Field label="Site name (বাংলা)"><input className={inputClass} value={settings.siteNameBn ?? ""} onChange={(e) => updateSetting("siteNameBn", e.target.value)} /></Field>
      <Field label="Site name (English)"><input className={inputClass} value={settings.siteNameEn ?? ""} onChange={(e) => updateSetting("siteNameEn", e.target.value)} /></Field>
      <Field label="Header tagline (বাংলা)"><input className={inputClass} value={settings.headerTaglineBn ?? ""} onChange={(e) => updateSetting("headerTaglineBn", e.target.value)} placeholder="সহজ জনসেবা পোর্টাল" /></Field>
      <Field label="Header tagline (English)"><input className={inputClass} value={settings.headerTaglineEn ?? ""} onChange={(e) => updateSetting("headerTaglineEn", e.target.value)} placeholder="Civic Service Portal" /></Field>
      <Field label="Logo URL"><input className={inputClass} value={settings.logoUrl ?? ""} onChange={(e) => updateSetting("logoUrl", e.target.value || null)} /><input type="file" accept="image/png,image/webp,image/jpeg" className="mt-2 text-xs text-slate-400" onChange={(e) => e.target.files?.[0] && uploadAsset(e.target.files[0], "logoUrl")} /><span className="text-[11px] text-slate-500">512×512 square PNG/WebP/JPG recommended.</span></Field>
      <Field label="404 title (বাংলা)"><input className={inputClass} value={settings.notFoundTitleBn ?? ""} onChange={(e) => updateSetting("notFoundTitleBn", e.target.value)} /></Field>
      <Field label="404 title (English)"><input className={inputClass} value={settings.notFoundTitleEn ?? ""} onChange={(e) => updateSetting("notFoundTitleEn", e.target.value)} /></Field>
      <Field label="404 message (বাংলা)" wide><textarea rows={2} className={inputClass} value={settings.notFoundMessageBn ?? ""} onChange={(e) => updateSetting("notFoundMessageBn", e.target.value)} /></Field>
      <Field label="404 message (English)" wide><textarea rows={2} className={inputClass} value={settings.notFoundMessageEn ?? ""} onChange={(e) => updateSetting("notFoundMessageEn", e.target.value)} /></Field>
      <div className="sm:col-span-2 flex flex-wrap items-center gap-4 text-xs text-slate-300"><label className="flex items-center gap-2"><input type="checkbox" checked={Boolean(settings.noticeVisible)} onChange={(e) => updateSetting("noticeVisible", e.target.checked ? 1 : 0)} /> {language === "EN" ? "Show owner notice" : "Owner notice দেখান"}</label><label className="flex items-center gap-2"><input type="checkbox" checked={Boolean(settings.quickLinksVisible)} onChange={(e) => updateSetting("quickLinksVisible", e.target.checked ? 1 : 0)} /> {language === "EN" ? "Show quick links" : "Quick links দেখান"}</label><button type="submit" disabled={saveSettings.isPending} className="ml-auto inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-500 disabled:opacity-60"><Save className="h-4 w-4" /> {saveSettings.isPending ? "…" : language === "EN" ? "Save Changes" : "Save Changes / সংরক্ষণ"}</button></div>
    </form>

    <form onSubmit={(event) => { event.preventDefault(); saveAnnouncement.mutate({ ...announcementForm, messageEn: announcementForm.messageEn.trim() || null, linkUrl: announcementForm.linkUrl.trim() || null }); }} className="mt-5 grid gap-4 rounded-2xl border border-slate-800 bg-slate-950/50 p-4 sm:grid-cols-2">
      <div className="sm:col-span-2 flex items-center gap-2 text-sm font-bold text-slate-100"><Bell className="h-4 w-4 text-amber-300" /> {language === "EN" ? "Announcement Banner" : "Announcement Banner / ঘোষণা ব্যানার"}</div>
      <Field label="বার্তা (বাংলা)"><input className={inputClass} value={announcementForm.messageBn} onChange={(e) => setAnnouncementForm((v) => ({ ...v, messageBn: e.target.value }))} /></Field>
      <Field label="Message (English)"><input className={inputClass} value={announcementForm.messageEn} onChange={(e) => setAnnouncementForm((v) => ({ ...v, messageEn: e.target.value }))} /></Field>
      <Field label="Link URL"><input className={inputClass} value={announcementForm.linkUrl} onChange={(e) => setAnnouncementForm((v) => ({ ...v, linkUrl: e.target.value }))} /></Field>
      <Field label="Banner color"><input type="color" className="h-11 w-full cursor-pointer rounded-xl border border-slate-700 bg-slate-900 p-1" value={announcementForm.color} onChange={(e) => setAnnouncementForm((v) => ({ ...v, color: e.target.value }))} /></Field>
      <div className="sm:col-span-2 flex flex-wrap items-center gap-4 text-xs text-slate-300"><label className="flex items-center gap-2"><input type="checkbox" checked={announcementForm.enabled} onChange={(e) => setAnnouncementForm((v) => ({ ...v, enabled: e.target.checked }))} /> {language === "EN" ? "Banner On" : "ব্যানার চালু"}</label><button disabled={saveAnnouncement.isPending} className="ml-auto inline-flex items-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-bold text-slate-950 hover:bg-amber-400 disabled:opacity-60"><Save className="h-4 w-4" /> Save Changes</button></div>
    </form>

    <div className="mt-5 grid gap-5 lg:grid-cols-[0.9fr_1.1fr]"><form onSubmit={submitLink} className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><div className="flex items-center gap-2 text-sm font-bold text-slate-100"><Link2 className="h-4 w-4 text-sky-300" /> {linkDraft ? (language === "EN" ? "Edit Quick Link" : "Quick Link সম্পাদনা") : (language === "EN" ? "Add Quick Link" : "Quick Link যোগ করুন")}</div><div className="mt-4 grid gap-3"><input required className={inputClass} placeholder="নাম (বাংলা)" value={linkForm.titleBn} onChange={(e) => setLinkForm((v) => ({ ...v, titleBn: e.target.value }))} /><input className={inputClass} placeholder="Name (English)" value={linkForm.titleEn} onChange={(e) => setLinkForm((v) => ({ ...v, titleEn: e.target.value }))} /><input required className={inputClass} placeholder="https:// অথবা /page" value={linkForm.url} onChange={(e) => setLinkForm((v) => ({ ...v, url: e.target.value }))} /><input className={inputClass} placeholder="Icon name, যেমন Link2" value={linkForm.iconName} onChange={(e) => setLinkForm((v) => ({ ...v, iconName: e.target.value }))} /><textarea className={inputClass} rows={2} placeholder="বিবরণ / Description" value={linkForm.descriptionBn} onChange={(e) => setLinkForm((v) => ({ ...v, descriptionBn: e.target.value }))} /><div className="flex flex-wrap gap-4 text-xs text-slate-300"><label><input type="checkbox" checked={linkForm.visible} onChange={(e) => setLinkForm((v) => ({ ...v, visible: e.target.checked }))} /> Visible</label><label><input type="checkbox" checked={linkForm.openInNewTab} onChange={(e) => setLinkForm((v) => ({ ...v, openInNewTab: e.target.checked }))} /> New tab</label><label>Order <input type="number" min={0} className="ml-1 w-16 rounded border border-slate-700 bg-slate-900 px-2 py-1" value={linkForm.displayOrder} onChange={(e) => setLinkForm((v) => ({ ...v, displayOrder: Number(e.target.value) || 0 }))} /></label></div><div className="flex gap-2"><button disabled={createLink.isPending || updateLink.isPending} className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-3 py-2 text-xs font-bold text-white"><Save className="h-4 w-4" /> Save Changes</button>{linkDraft && <button type="button" onClick={() => { setLinkDraft(null); setLinkForm({ titleBn: "", titleEn: "", url: "", descriptionBn: "", descriptionEn: "", iconName: "Link2", iconImageUrl: null, openInNewTab: true, visible: true, displayOrder: 0 }); }} className="rounded-xl border border-slate-700 px-3 py-2 text-xs text-slate-300">Cancel</button>}</div></div></form><div className="space-y-2">{links.map((link) => <div key={link.id} className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/50 p-3"><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-slate-100">{language === "EN" ? link.titleEn || link.titleBn : link.titleBn}</p><p className="truncate text-xs text-slate-500">{link.url} · {link.iconName}</p></div><button type="button" onClick={() => startEditLink(link)} className="rounded-lg border border-sky-500/30 px-2.5 py-1.5 text-xs text-sky-200"><Edit3 className="mr-1 inline h-3.5 w-3.5" />Edit</button><button type="button" onClick={() => window.confirm(language === "EN" ? "Are you sure you want to delete this quick link?" : "আপনি কি নিশ্চিত যে এই Quick Link মুছে ফেলবেন?") && deleteLink.mutate({ id: link.id })} className="rounded-lg border border-rose-500/35 px-2.5 py-1.5 text-xs text-rose-200"><Trash2 className="mr-1 inline h-3.5 w-3.5" />Delete</button></div>)}</div></div>
  </section>;
}

export function JonosobhaPanel({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const postsQuery = trpc.siteManagement.management.listBlogPosts.useQuery({ includeDrafts: true }, { enabled: isOwner, retry: false });
  const upload = trpc.gallery.uploadBase64.useMutation();
  const [form, setForm] = useState({ ...emptyNotice });
  const [message, setMessage] = useState("");
  const [uploading, setUploading] = useState(false);
  const update = (key: keyof typeof emptyNotice, value: string | boolean | number | null) => setForm((current) => ({ ...current, [key]: value }));
  const create = trpc.siteManagement.management.createBlogPost.useMutation({ onSuccess: async () => { await postsQuery.refetch(); setForm({ ...emptyNotice }); setMessage(language === "EN" ? "Notice created successfully." : "নোটিশ সফলভাবে তৈরি হয়েছে।"); }, onError: (error) => setMessage(error.message) });
  const edit = trpc.siteManagement.management.updateBlogPost.useMutation({ onSuccess: async () => { await postsQuery.refetch(); setForm({ ...emptyNotice }); setMessage(language === "EN" ? "Notice updated successfully." : "নোটিশ সফলভাবে আপডেট হয়েছে।"); }, onError: (error) => setMessage(error.message) });
  const remove = trpc.siteManagement.management.deleteBlogPost.useMutation({ onSuccess: async () => { await postsQuery.refetch(); setMessage(language === "EN" ? "Notice deleted successfully." : "নোটিশ সফলভাবে মুছে ফেলা হয়েছে।"); }, onError: (error) => setMessage(error.message) });

  const uploadFile = async (file: File, target: "coverImageUrl" | "pdfUrl") => {
    const allowed = target === "pdfUrl" ? file.type === "application/pdf" : file.type.startsWith("image/");
    if (!allowed) { setMessage(language === "EN" ? "Choose the correct file type." : "সঠিক ধরনের ফাইল নির্বাচন করুন।"); return; }
    if (file.size > 15 * 1024 * 1024) { setMessage(language === "EN" ? "Maximum file size is 15 MB." : "সর্বোচ্চ ১৫ MB ফাইল দিন।"); return; }
    setUploading(true);
    try { const result = await upload.mutateAsync({ base64Data: await fileToDataUrl(file), fileName: `cms/jonosobha-${Date.now()}-${file.name.replace(/[^a-z0-9._-]/gi, "-")}`, contentType: file.type }); update(target, result.url); setMessage(language === "EN" ? "File uploaded. Save the notice to publish it." : "ফাইল আপলোড হয়েছে। নোটিশ সংরক্ষণ করুন।"); } catch (error) { setMessage(error instanceof Error ? error.message : "Upload failed"); } finally { setUploading(false); }
  };
  const submit = (event: React.FormEvent) => { event.preventDefault(); const payload = { titleBn: form.titleBn, titleEn: form.titleEn.trim() || null, slug: form.slug || `${Date.now()}`, excerptBn: form.excerptBn, excerptEn: form.excerptEn.trim() || null, contentBn: form.contentBn, contentEn: form.contentEn.trim() || null, coverImageUrl: form.coverImageUrl.trim() || null, pdfUrl: form.pdfUrl.trim() || null, isPinned: form.isPinned, status: form.status }; if (form.id) edit.mutate({ id: form.id, ...payload }); else create.mutate(payload); };
  const posts = (postsQuery.data ?? []) as BlogPost[];
  const startEdit = (post: BlogPost) => setForm({ id: post.id, titleBn: post.titleBn, titleEn: post.titleEn ?? "", slug: post.slug, excerptBn: post.excerptBn, excerptEn: post.excerptEn ?? "", contentBn: post.contentBn, contentEn: post.contentEn ?? "", coverImageUrl: post.coverImageUrl ?? "", pdfUrl: post.pdfUrl ?? "", isPinned: post.isPinned === 1, status: post.status });

  return <section className="rounded-2xl border border-sky-500/25 bg-slate-900 p-5 shadow-xl sm:p-6"><div className="flex items-start justify-between gap-4"><div><h2 className="flex items-center gap-2 text-xl font-bold text-white"><Pin className="h-5 w-5 text-sky-300" /> {language === "EN" ? "Jonosobha / News / Notice" : "জনসভা / News / Notice"}</h2><p className="mt-1 text-sm leading-6 text-slate-400">{language === "EN" ? "Create, edit, publish, pin or remove bilingual notices with cover images and PDF files." : "বাংলা/ইংরেজি নোটিশ তৈরি, সম্পাদনা, প্রকাশ, pin এবং cover/PDF ফাইল ব্যবস্থাপনা করুন।"}</p></div><button type="button" onClick={() => setForm({ ...emptyNotice })} className="inline-flex items-center gap-1.5 rounded-xl border border-sky-400/35 px-3 py-2 text-xs font-bold text-sky-200"><Plus className="h-4 w-4" /> Add</button></div>
    {message && <div className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-950/35 px-4 py-3 text-sm text-emerald-200">{message}</div>}
    <form onSubmit={submit} className="mt-5 grid gap-4 rounded-2xl border border-slate-800 bg-slate-950/50 p-4 sm:grid-cols-2"><Field label="Title (বাংলা)"><input required className={inputClass} value={form.titleBn} onChange={(e) => update("titleBn", e.target.value)} /></Field><Field label="Title (English)"><input className={inputClass} value={form.titleEn} onChange={(e) => update("titleEn", e.target.value)} /></Field><Field label="Slug"><input className={inputClass} value={form.slug} onChange={(e) => update("slug", e.target.value)} placeholder="notice-slug" /></Field><Field label="Status"><select className={inputClass} value={form.status} onChange={(e) => update("status", e.target.value as "draft" | "published")}><option value="draft">Draft</option><option value="published">Published</option></select></Field><Field label="সংক্ষিপ্ত বিবরণ (বাংলা)" wide><textarea required rows={2} className={inputClass} value={form.excerptBn} onChange={(e) => update("excerptBn", e.target.value)} /></Field><Field label="Short description (English)" wide><textarea rows={2} className={inputClass} value={form.excerptEn} onChange={(e) => update("excerptEn", e.target.value)} /></Field><Field label="বিস্তারিত লেখা (বাংলা)" wide><textarea required rows={5} className={inputClass} value={form.contentBn} onChange={(e) => update("contentBn", e.target.value)} /></Field><Field label="Full content (English)" wide><textarea rows={5} className={inputClass} value={form.contentEn} onChange={(e) => update("contentEn", e.target.value)} /></Field><Field label="Cover image URL"><input className={inputClass} value={form.coverImageUrl} onChange={(e) => update("coverImageUrl", e.target.value)} /><input type="file" accept="image/*" className="mt-2 text-xs text-slate-400" onChange={(e) => e.target.files?.[0] && uploadFile(e.target.files[0], "coverImageUrl")} /></Field><Field label="PDF file URL"><input className={inputClass} value={form.pdfUrl} onChange={(e) => update("pdfUrl", e.target.value)} /><input type="file" accept="application/pdf" className="mt-2 text-xs text-slate-400" onChange={(e) => e.target.files?.[0] && uploadFile(e.target.files[0], "pdfUrl")} /></Field><div className="sm:col-span-2 flex flex-wrap items-center gap-4 text-xs text-slate-300"><label className="flex items-center gap-2"><input type="checkbox" checked={form.isPinned} onChange={(e) => update("isPinned", e.target.checked)} /> {language === "EN" ? "Pin important notice" : "গুরুত্বপূর্ণ নোটিশ Pin করুন"}</label><button disabled={uploading || create.isPending || edit.isPending} className="ml-auto inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-sky-500 disabled:opacity-60"><Save className="h-4 w-4" /> {form.id ? "Update / আপডেট" : "Save / সংরক্ষণ"}</button>{form.id && <button type="button" onClick={() => setForm({ ...emptyNotice })} className="rounded-xl border border-slate-700 px-3 py-2.5 text-xs text-slate-300">Cancel</button>}</div></form>
    <div className="mt-5 space-y-3">{posts.length === 0 && <p className="rounded-xl border border-dashed border-slate-700 p-4 text-sm text-slate-500">কোনো Jonosobha post নেই।</p>}{posts.map((post) => <article key={post.id} className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-start"><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-slate-100">{language === "EN" ? post.titleEn || post.titleBn : post.titleBn}</h3>{post.isPinned === 1 && <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[11px] text-amber-200">Pinned</span>}<span className="rounded-full bg-slate-800 px-2 py-0.5 text-[11px] text-slate-300">{post.status}</span></div><p className="mt-1 text-xs leading-5 text-slate-400">{language === "EN" ? post.excerptEn || post.excerptBn : post.excerptBn}</p><div className="mt-2 flex flex-wrap gap-3 text-[11px] text-slate-500">{post.coverImageUrl && <a href={post.coverImageUrl} target="_blank" rel="noreferrer"><FileImage className="mr-1 inline h-3.5 w-3.5" /> Cover</a>}{post.pdfUrl && <a href={post.pdfUrl} target="_blank" rel="noreferrer"><FileText className="mr-1 inline h-3.5 w-3.5" /> PDF</a>}</div></div><div className="flex shrink-0 gap-2"><button type="button" onClick={() => startEdit(post)} className="rounded-lg border border-sky-500/30 px-2.5 py-1.5 text-xs text-sky-200"><Edit3 className="mr-1 inline h-3.5 w-3.5" />Edit</button><button type="button" onClick={() => window.confirm(language === "EN" ? "Are you sure you want to delete this notice?" : "আপনি কি নিশ্চিত যে এই নোটিশ মুছে ফেলবেন?") && remove.mutate({ id: post.id })} className="rounded-lg border border-rose-500/35 px-2.5 py-1.5 text-xs text-rose-200"><Trash2 className="mr-1 inline h-3.5 w-3.5" />Delete</button></div></div></article>)}</div>
  </section>;
}
