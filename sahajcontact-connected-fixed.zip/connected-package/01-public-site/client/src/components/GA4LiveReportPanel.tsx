import { BarChart3, CheckCircle2, Globe2, RefreshCw, Users } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

function numberForDashboard(value: number, language: "BN" | "EN") {
  return value.toLocaleString(language === "EN" ? "en-US" : "bn-BD");
}

export function GA4LiveReportPanel({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const reportQuery = trpc.adminAnalytics.getLiveGa4DashboardReport.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
    staleTime: 60_000,
  });
  const manualReportQuery = trpc.adminAnalytics.getLatestVerifiedManualGa4Report.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const permissionSetupQuery = trpc.adminAnalytics.getGa4PermissionSetup.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
    staleTime: 5 * 60_000,
  });
  const refreshVerifiedReportMutation = trpc.adminAnalytics.refreshVerifiedLiveGa4Report.useMutation({
    onSuccess: async () => {
      await Promise.all([reportQuery.refetch(), manualReportQuery.refetch()]);
    },
  });
  const isEnglish = language === "EN";
  const report = reportQuery.data;

  return (
    <section className="rounded-2xl border border-emerald-500/25 bg-slate-900 p-6 shadow-xl" aria-labelledby="ga4-live-report-heading">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 id="ga4-live-report-heading" className="flex items-center gap-2 text-xl font-bold text-slate-100">
              <BarChart3 className="h-5 w-5 text-emerald-400" />
              {isEnglish ? "Live GA4 Report" : "লাইভ GA4 রিপোর্ট"}
            </h2>
            <span className="rounded-full border border-emerald-400/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-bold text-emerald-200">
              {isEnglish ? "Owner only" : "শুধু Owner"}
            </span>
          </div>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-400">
            {isEnglish
              ? "This panel reads aggregate metrics directly from GA4. Credentials and property configuration never reach the browser; the owner-only setup card can reveal just the approved service-account email."
              : "এই প্যানেল GA4 থেকে সরাসরি সামগ্রিক মেট্রিক দেখায়। Credential ও property configuration কখনো ব্রাউজারে আসে না; owner-only setup card-এ কেবল অনুমোদিত service-account email দেখা যেতে পারে।"}
          </p>
        </div>
        <button
          type="button"
          onClick={() => reportQuery.refetch()}
          disabled={reportQuery.isFetching}
          className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl border border-emerald-400/35 bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-100 transition hover:bg-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${reportQuery.isFetching ? "animate-spin" : ""}`} />
          {reportQuery.isFetching ? (isEnglish ? "Refreshing…" : "রিফ্রেশ হচ্ছে…") : (isEnglish ? "Refresh live data" : "লাইভ ডাটা রিফ্রেশ")}
        </button>
      </div>

      <div className="mt-5 rounded-xl border border-amber-400/30 bg-amber-950/25 p-4" aria-live="polite">
        <p className="flex items-center gap-2 text-sm font-bold text-amber-100"><CheckCircle2 className="h-4 w-4 text-amber-300" />{isEnglish ? "GA4 access setup" : "GA4 access সেটআপ"}</p>
        {permissionSetupQuery.data ? (
          <>
            <p className="mt-2 text-xs leading-5 text-amber-100/80">
              {isEnglish
                ? "In Google Analytics, open Admin → Property access management and add this email as Viewer or Analyst. This card returns only this email."
                : "Google Analytics-এ Admin → Property access management খুলে এই email-কে Viewer বা Analyst হিসেবে যোগ করুন। এই card কেবল এই email-টিই দেখায়।"}
            </p>
            <code className="mt-3 block max-w-full overflow-x-auto rounded-lg border border-amber-300/25 bg-slate-950/80 px-3 py-2 text-xs font-semibold text-amber-100">
              {permissionSetupQuery.data.serviceAccountEmail}
            </code>
            <p className="mt-2 text-[11px] leading-5 text-slate-400">
              {isEnglish
                ? "No JSON, private key, access token, project data, or configured property ID is exposed here."
                : "এখানে কোনো JSON, private key, access token, project তথ্য বা configured property ID প্রকাশ করা হয় না।"}
            </p>
          </>
        ) : permissionSetupQuery.isError ? (
          <p className="mt-2 text-xs leading-5 text-amber-100/80">{isEnglish ? "The owner-only permission setup email is temporarily unavailable." : "Owner-only permission setup email সাময়িকভাবে পাওয়া যাচ্ছে না।"}</p>
        ) : (
          <p className="mt-2 text-xs leading-5 text-amber-100/80">{isEnglish ? "Loading owner-only permission setup email…" : "Owner-only permission setup email লোড হচ্ছে…"}</p>
        )}
      </div>

      <div className="mt-5 rounded-xl border border-violet-400/30 bg-violet-950/25 p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="flex items-center gap-2 text-sm font-bold text-violet-100"><CheckCircle2 className="h-4 w-4 text-violet-300" />{isEnglish ? "Owner-approved manual update" : "Owner-approved ম্যানুয়াল আপডেট"}</p>
            <p className="mt-1 max-w-3xl text-xs leading-5 text-violet-100/75">
              {isEnglish
                ? "Saves the verified live GA4 aggregates as a separate manual report. It does not trigger, alter, or count as the automatic daily snapshot, and it never changes the public automatic-status card."
                : "যাচাইকৃত লাইভ GA4 সামগ্রিক ডাটা আলাদা manual report হিসেবে সংরক্ষণ করে। এটি automatic daily snapshot চালায় না, বদলায় না, বা তার পরিবর্তে গণ্য হয় না; public automatic-status card-ও বদলায় না।"}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              const confirmed = window.confirm(isEnglish
                ? "Save a separate owner-approved manual report using current live GA4 aggregates?"
                : "বর্তমান লাইভ GA4 সামগ্রিক ডাটা দিয়ে আলাদা owner-approved manual report সংরক্ষণ করবেন?");
              if (confirmed) refreshVerifiedReportMutation.mutate();
            }}
            disabled={refreshVerifiedReportMutation.isPending}
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl border border-violet-300/40 bg-violet-500/15 px-3 py-2 text-xs font-bold text-violet-100 transition hover:bg-violet-500/25 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <CheckCircle2 className="h-3.5 w-3.5" />
            {refreshVerifiedReportMutation.isPending
              ? (isEnglish ? "Verifying & saving…" : "যাচাই ও সংরক্ষণ হচ্ছে…")
              : (isEnglish ? "Update verified GA4 report manually" : "ম্যানুয়ালি যাচাইকৃত GA4 রিপোর্ট আপডেট")}
          </button>
        </div>
        {refreshVerifiedReportMutation.isError && <p className="mt-3 rounded-lg border border-rose-400/25 bg-rose-950/30 px-3 py-2 text-xs leading-5 text-rose-100">{isEnglish ? "The verified report could not be saved. No manual report was labelled as updated." : "যাচাইকৃত রিপোর্ট সংরক্ষণ করা যায়নি। কোনো manual report-কে updated বলা হয়নি।"}</p>}
        {refreshVerifiedReportMutation.isSuccess && <p className="mt-3 rounded-lg border border-emerald-400/25 bg-emerald-950/30 px-3 py-2 text-xs leading-5 text-emerald-100">{isEnglish ? "Verified manual GA4 report saved separately. The automatic scheduler remains unchanged." : "যাচাইকৃত manual GA4 রিপোর্ট আলাদা করে সংরক্ষিত হয়েছে। Automatic scheduler অপরিবর্তিত আছে।"}</p>}
        {manualReportQuery.data && <p className="mt-3 text-xs leading-5 text-violet-100/80">{isEnglish ? "Latest separate manual record:" : "সর্বশেষ পৃথক manual record:"} {new Date(manualReportQuery.data.createdAt).toLocaleString(isEnglish ? "en-GB" : "bn-BD")} · {isEnglish ? "7-day users/sessions and 30-day page views/events" : "৭ দিনের ব্যবহারকারী/সেশন এবং ৩০ দিনের পেজ ভিউ/ইভেন্ট"}</p>}
      </div>

      {reportQuery.isLoading ? (
        <p className="mt-5 rounded-xl border border-slate-700 bg-slate-950/70 p-4 text-sm text-slate-400" aria-live="polite">
          {isEnglish ? "Loading live GA4 metrics…" : "লাইভ GA4 মেট্রিক লোড হচ্ছে…"}
        </p>
      ) : reportQuery.isError || !report ? (
        <p className="mt-5 rounded-xl border border-amber-500/30 bg-amber-950/30 p-4 text-sm leading-6 text-amber-100" aria-live="polite">
          {isEnglish
            ? "Live GA4 data is temporarily unavailable. Check the protected GA4 configuration and try the refresh button again; no traffic figures are estimated here."
            : "লাইভ GA4 ডাটা সাময়িকভাবে পাওয়া যাচ্ছে না। সুরক্ষিত GA4 configuration পরীক্ষা করে রিফ্রেশ বাটনে আবার চেষ্টা করুন; এখানে কোনো ট্রাফিক সংখ্যা অনুমান করা হয় না।"}
        </p>
      ) : (
        <div className="mt-5 space-y-5" aria-live="polite">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              { label: isEnglish ? "Active users" : "সক্রিয় ব্যবহারকারী", value: report.activeUsers7d, period: isEnglish ? "Last 7 days" : "গত ৭ দিন", icon: Users },
              { label: isEnglish ? "Sessions" : "সেশন", value: report.sessions7d, period: isEnglish ? "Last 7 days" : "গত ৭ দিন", icon: BarChart3 },
              { label: isEnglish ? "Page views" : "পেজ ভিউ", value: report.pageViews30d, period: isEnglish ? "Last 30 days" : "গত ৩০ দিন", icon: Globe2 },
              { label: isEnglish ? "Events" : "ইভেন্ট", value: report.totalEvents30d, period: isEnglish ? "Last 30 days" : "গত ৩০ দিন", icon: BarChart3 },
            ].map(({ label, value, period, icon: Icon }) => (
              <div key={label} className="rounded-xl border border-slate-800 bg-slate-950 p-4">
                <div className="flex items-center justify-between gap-2 text-slate-400"><p className="text-xs">{label}</p><Icon className="h-4 w-4 text-emerald-400" /></div>
                <p className="mt-1 text-2xl font-black text-emerald-400">{numberForDashboard(value, language)}</p>
                <p className="mt-1 text-[11px] text-slate-500">{period}</p>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-sky-500/25 bg-sky-950/20 p-4">
            <div className="mb-3 flex items-center gap-2 text-sm font-bold text-sky-100"><Globe2 className="h-4 w-4" />{isEnglish ? "Top countries by active users" : "সক্রিয় ব্যবহারকারী অনুযায়ী শীর্ষ দেশ"}</div>
            {report.topCountries.length ? (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
                {report.topCountries.map((country: { country: string; activeUsers: number; sessions: number }) => (
                  <div key={country.country} className="rounded-lg border border-sky-400/15 bg-slate-950/70 px-3 py-2.5">
                    <p className="truncate text-xs font-bold text-slate-100" title={country.country}>{country.country}</p>
                    <p className="mt-1 text-xs text-sky-200">{numberForDashboard(country.activeUsers, language)} {isEnglish ? "users" : "ব্যবহারকারী"}</p>
                    <p className="text-[11px] text-slate-500">{numberForDashboard(country.sessions, language)} {isEnglish ? "sessions" : "সেশন"}</p>
                  </div>
                ))}
              </div>
            ) : <p className="text-xs text-slate-400">{isEnglish ? "No country breakdown is available for this period." : "এই সময়সীমার জন্য কোনো দেশভিত্তিক তথ্য পাওয়া যায়নি।"}</p>}
          </div>

          <p className="text-[11px] text-slate-500">{isEnglish ? "Live data fetched" : "লাইভ ডাটা নেওয়া হয়েছে"}: {new Date(report.capturedAt).toLocaleString(isEnglish ? "en-GB" : "bn-BD")}</p>
        </div>
      )}
    </section>
  );
}
