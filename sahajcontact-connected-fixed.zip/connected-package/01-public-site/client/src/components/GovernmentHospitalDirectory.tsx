import { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Building2, ExternalLink, LoaderCircle, MapPin, Phone, Search, Stethoscope } from "lucide-react";

type OfficialHospitalRow = Record<string, unknown>;

export type GovernmentHospital = {
  id: string;
  nameBn: string;
  nameEn: string;
  division: string;
  district: string;
  upazila: string;
  type: "district" | "upazila";
  mobile: string;
};

const asText = (value: unknown) => (value === null || value === undefined ? "" : String(value).trim());
const normalize = (value: string) => value.toLocaleLowerCase("bn-BD").replace(/\s+/g, " ").trim();

function parseOfficialRows(rows: OfficialHospitalRow[]): GovernmentHospital[] {
  const includedTypes = new Map<string, GovernmentHospital["type"]>([
    ["District/General Hospital", "district"],
    ["Upazila Health Complex", "upazila"],
  ]);

  return rows
    .filter(row => asText(row.Agency) === "DGHS" && asText(row.Ownership) === "Fully Government-owned")
    .map(row => {
      const facilityType = includedTypes.get(asText(row.Type));
      if (!facilityType) return null;
      const id = asText(row.Id);
      const nameEn = asText(row.Name);
      if (!id || !nameEn) return null;
      return {
        id,
        nameBn: asText(row["Name (Bangla)"]) || nameEn,
        nameEn,
        division: asText(row.Division),
        district: asText(row.District),
        upazila: asText(row.Upazila),
        type: facilityType,
        mobile: asText(row.Mobile),
      } satisfies GovernmentHospital;
    })
    .filter((record): record is GovernmentHospital => record !== null)
    .sort((a, b) => a.district.localeCompare(b.district) || a.upazila.localeCompare(b.upazila) || a.nameEn.localeCompare(b.nameEn));
}

const sourceDate = "22 August 2026";

export default function GovernmentHospitalDirectory({
  isEnglish,
  exportUrl,
  registryUrl,
  onOpenOfficialRegistry,
}: {
  isEnglish: boolean;
  exportUrl: string;
  registryUrl: string;
  onOpenOfficialRegistry?: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [records, setRecords] = useState<GovernmentHospital[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState("");
  const [district, setDistrict] = useState("");
  const [upazila, setUpazila] = useState("");
  const [facilityType, setFacilityType] = useState<"" | GovernmentHospital["type"]>("");
  const [visibleCount, setVisibleCount] = useState(18);

  useEffect(() => {
    if (!isOpen || records.length || loading || error) return;
    let cancelled = false;
    setLoading(true);
    void (async () => {
      try {
        const response = await fetch(exportUrl, { cache: "force-cache" });
        if (!response.ok) throw new Error("Unable to load official directory export");
        const XLSX = await import("xlsx");
        const workbook = XLSX.read(await response.arrayBuffer(), { type: "array" });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<OfficialHospitalRow>(worksheet, { defval: "" });
        const parsed = parseOfficialRows(rows);
        if (!parsed.length) throw new Error("Official export did not contain matching government hospital records");
        if (!cancelled) setRecords(parsed);
      } catch {
        if (!cancelled) setError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [error, exportUrl, isOpen, loading, records.length]);

  const districtOptions = useMemo(() => Array.from(new Set(records.map(record => record.district).filter(Boolean))).sort(), [records]);
  const upazilaOptions = useMemo(() => Array.from(new Set(records.filter(record => !district || record.district === district).map(record => record.upazila).filter(Boolean))).sort(), [district, records]);
  const filteredRecords = useMemo(() => {
    const search = normalize(query);
    return records.filter(record => {
      const matchesSearch = !search || [record.nameBn, record.nameEn, record.division, record.district, record.upazila].some(value => normalize(value).includes(search));
      return matchesSearch && (!district || record.district === district) && (!upazila || record.upazila === upazila) && (!facilityType || record.type === facilityType);
    });
  }, [district, facilityType, query, records, upazila]);

  const resetFilters = () => {
    setQuery("");
    setDistrict("");
    setUpazila("");
    setFacilityType("");
    setVisibleCount(18);
  };

  const results = filteredRecords.slice(0, visibleCount);
  const recordLabel = isEnglish ? "government hospitals" : "সরকারি হাসপাতাল";

  return (
    <section aria-labelledby="nationwide-government-hospital-directory" className="mt-5 border-t border-cyan-200 pt-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="support-card-kicker m-0">{isEnglish ? "Official DGHS data" : "DGHS-এর official তথ্য"}</p>
          <h3 id="nationwide-government-hospital-directory" className="mt-1 flex items-center gap-2 text-lg font-black text-cyan-950">
            <Stethoscope size={21} aria-hidden="true" />
            {isEnglish ? "Nationwide government hospital directory" : "সারা বাংলাদেশের সরকারি হাসপাতাল ডিরেক্টরি"}
          </h3>
          <p className="mb-0 mt-1 max-w-3xl text-sm leading-6 text-slate-600">
            {isEnglish
              ? "Search district/general hospitals and Upazila Health Complexes by district, upazila, or facility name."
              : "জেলা/জেনারেল হাসপাতাল ও উপজেলা স্বাস্থ্য কমপ্লেক্স জেলা, উপজেলা অথবা প্রতিষ্ঠানের নাম দিয়ে খুঁজুন।"}
          </p>
        </div>
        <a href={registryUrl} target="_blank" rel="noreferrer" onClick={onOpenOfficialRegistry} className="healthcare-source shrink-0">
          {isEnglish ? "DGHS live registry" : "DGHS live registry"} <ExternalLink size={14} aria-hidden="true" />
        </a>
      </div>

      <details className="mt-4 overflow-hidden rounded-2xl border border-cyan-200 bg-cyan-50/40" onToggle={event => setIsOpen(event.currentTarget.open)}>
        <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 text-sm font-extrabold text-cyan-900 marker:content-none">
          <span className="flex items-center gap-2"><Building2 size={18} aria-hidden="true" />{isEnglish ? "Open searchable directory" : "জেলা ও উপজেলা অনুযায়ী খুঁজুন"}</span>
          <span className="rounded-full bg-cyan-700 px-3 py-1 text-xs font-black text-white">{isEnglish ? "Search" : "খুলুন"}</span>
        </summary>
        <div className="border-t border-cyan-200 bg-white p-4">
          {loading ? <div className="flex items-center gap-2 py-8 text-sm font-semibold text-slate-600"><LoaderCircle size={19} className="animate-spin" aria-hidden="true" />{isEnglish ? "Loading the official DGHS export…" : "DGHS-এর official তালিকা লোড হচ্ছে…"}</div> : null}
          {error ? <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-950"><strong>{isEnglish ? "The directory could not be loaded right now." : "তালিকাটি এই মুহূর্তে লোড করা যাচ্ছে না।"}</strong><br />{isEnglish ? "Please use the live official DGHS registry to search the current record." : "বর্তমান তথ্যের জন্য DGHS-এর live official registry ব্যবহার করুন।"}</div> : null}
          {!loading && !error && records.length ? <>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              <label className="block text-xs font-bold text-slate-700"><span className="sr-only">{isEnglish ? "Search" : "খোঁজ"}</span><div className="relative"><Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-cyan-700" aria-hidden="true" /><input value={query} onChange={event => { setQuery(event.target.value); setVisibleCount(18); }} placeholder={isEnglish ? "Hospital, district, upazila" : "হাসপাতাল, জেলা বা উপজেলা"} className="h-11 w-full rounded-xl border border-cyan-200 bg-white pl-9 pr-3 text-sm text-slate-900 outline-none ring-cyan-500 placeholder:text-slate-400 focus:ring-2" /></div></label>
              <label className="block text-xs font-bold text-slate-700"><span className="mb-1 block">{isEnglish ? "District" : "জেলা"}</span><select value={district} onChange={event => { setDistrict(event.target.value); setUpazila(""); setVisibleCount(18); }} className="h-10 w-full rounded-xl border border-cyan-200 bg-white px-3 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-cyan-500"><option value="">{isEnglish ? "All districts" : "সব জেলা"}</option>{districtOptions.map(option => <option key={option} value={option}>{option}</option>)}</select></label>
              <label className="block text-xs font-bold text-slate-700"><span className="mb-1 block">{isEnglish ? "Upazila" : "উপজেলা"}</span><select value={upazila} onChange={event => { setUpazila(event.target.value); setVisibleCount(18); }} className="h-10 w-full rounded-xl border border-cyan-200 bg-white px-3 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-cyan-500"><option value="">{isEnglish ? "All upazilas" : "সব উপজেলা"}</option>{upazilaOptions.map(option => <option key={option} value={option}>{option}</option>)}</select></label>
              <label className="block text-xs font-bold text-slate-700"><span className="mb-1 block">{isEnglish ? "Facility type" : "প্রতিষ্ঠানের ধরন"}</span><select value={facilityType} onChange={event => { setFacilityType(event.target.value as "" | GovernmentHospital["type"]); setVisibleCount(18); }} className="h-10 w-full rounded-xl border border-cyan-200 bg-white px-3 text-sm text-slate-900 outline-none focus:ring-2 focus:ring-cyan-500"><option value="">{isEnglish ? "All types" : "সব ধরন"}</option><option value="district">{isEnglish ? "District / General Hospital" : "জেলা / জেনারেল হাসপাতাল"}</option><option value="upazila">{isEnglish ? "Upazila Health Complex" : "উপজেলা স্বাস্থ্য কমপ্লেক্স"}</option></select></label>
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2"><p className="m-0 text-sm font-bold text-cyan-950">{filteredRecords.length.toLocaleString()} {recordLabel} {isEnglish ? "found" : "পাওয়া গেছে"}</p>{(query || district || upazila || facilityType) ? <button type="button" onClick={resetFilters} className="rounded-lg px-2 py-1 text-xs font-bold text-cyan-800 underline decoration-cyan-300 underline-offset-4">{isEnglish ? "Clear filters" : "ফিল্টার মুছুন"}</button> : null}</div>
            <div className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">{results.map(record => <article key={record.id} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm"><div className="flex items-start justify-between gap-2"><span className="inline-flex items-center gap-1 rounded-full bg-cyan-50 px-2 py-1 text-[11px] font-bold text-cyan-900"><Building2 size={13} aria-hidden="true" />{record.type === "district" ? (isEnglish ? "District / General" : "জেলা / জেনারেল") : (isEnglish ? "Upazila Health Complex" : "উপজেলা স্বাস্থ্য কমপ্লেক্স")}</span><MapPin size={17} className="shrink-0 text-cyan-700" aria-hidden="true" /></div><h4 className="mb-1 mt-3 text-[0.96rem] font-extrabold leading-5 text-slate-900">{isEnglish ? record.nameEn : record.nameBn}</h4>{isEnglish ? null : <p className="m-0 text-xs leading-5 text-slate-500">{record.nameEn}</p>}<p className="mb-0 mt-2 text-xs leading-5 text-slate-700">{[record.upazila, record.district, record.division].filter(Boolean).join(", ") || (isEnglish ? "Location not supplied in export" : "রপ্তানিতে অবস্থান দেওয়া নেই")}</p>{record.mobile ? <a className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-cyan-800 underline underline-offset-4" href={`tel:${record.mobile}`}><Phone size={13} aria-hidden="true" />{record.mobile}</a> : <p className="mb-0 mt-2 text-xs text-slate-500">{isEnglish ? "Phone not supplied in export" : "রপ্তানিতে ফোন দেওয়া নেই"}</p>}</article>)}</div>
            {!results.length ? <div className="mt-3 rounded-xl bg-slate-50 p-4 text-sm text-slate-700">{isEnglish ? "No matching facility appears in this official export. Try another spelling or use the live registry." : "এই official তালিকায় মিল পাওয়া যায়নি। অন্য বানান দিয়ে চেষ্টা করুন বা live registry দেখুন।"}</div> : null}
            {filteredRecords.length > visibleCount ? <button type="button" onClick={() => setVisibleCount(count => count + 18)} className="mt-4 inline-flex min-h-10 items-center gap-1 rounded-xl bg-cyan-800 px-4 text-sm font-extrabold text-white transition active:scale-[0.97]">{isEnglish ? "Show more hospitals" : "আরও হাসপাতাল দেখুন"} <ArrowUpRight size={16} aria-hidden="true" /></button> : null}
            <p className="mb-0 mt-5 rounded-xl bg-slate-50 p-3 text-xs leading-5 text-slate-600">{isEnglish ? `Imported from a DGHS Facility Registry export checked ${sourceDate}. It includes records explicitly marked DGHS, fully government-owned, and District/General Hospital or Upazila Health Complex. The live DGHS registry is the source of record; service availability and contacts can change.` : `${sourceDate}-এ যাচাই করা DGHS Facility Registry export থেকে তালিকাটি আনা হয়েছে। শুধু DGHS, সম্পূর্ণ সরকারি মালিকানাধীন এবং জেলা/জেনারেল হাসপাতাল বা উপজেলা স্বাস্থ্য কমপ্লেক্স হিসেবে চিহ্নিত রেকর্ড রাখা হয়েছে। সর্বশেষ তথ্যের উৎস DGHS live registry; সেবার প্রাপ্যতা ও যোগাযোগ পরিবর্তিত হতে পারে।`}</p>
          </> : null}
        </div>
      </details>
    </section>
  );
}

export { parseOfficialRows };
