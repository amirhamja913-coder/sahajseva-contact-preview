import { useEffect, useMemo, useState } from "react";
import { Check, Copy, Eye, EyeOff, LayoutDashboard, Monitor, RotateCcw, Save, Smartphone, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";
import {
  DEFAULT_HOME_SECTION_LAYOUT,
  HOME_SECTION_LAYOUT_KEYS,
  normalizeHomeSectionLayout,
  parseHomeSectionLayout,
  type HomeSectionLayout,
  type HomeSectionLayoutKey,
} from "@shared/homeSectionLayout";

const labels: Record<HomeSectionLayoutKey, { bn: string; en: string; detailBn: string; detailEn: string }> = {
  quickLinks: { bn: "দ্রুত সেবা লিংক", en: "Quick service links", detailBn: "হোমপেজের অনুমোদিত দ্রুত-সেবা অংশ", detailEn: "Approved quick-service block on the homepage" },
  bangladesh: { bn: "বাংলাদেশ ভিজ্যুয়াল", en: "Bangladesh visual", detailBn: "মানচিত্র ও বাংলাদেশ পরিচিতি ব্লক", detailEn: "Map and Bangladesh introduction block" },
  tourism: { bn: "বাংলাদেশকে ঘুরে দেখুন", en: "Explore Bangladesh", detailBn: "পর্যটন ও ভ্রমণ-নির্দেশনা ব্লক", detailEn: "Tourism and travel guidance block" },
  howTo: { bn: "করণীয় নির্দেশনা", en: "How-to guidance", detailBn: "নাগরিক করণীয় ও সহায়তা ব্লক", detailEn: "Civic actions and guidance block" },
  faq: { bn: "সাধারণ প্রশ্ন", en: "Common questions", detailBn: "অনুমোদিত FAQ ব্লক", detailEn: "Approved FAQ block" },
  story: { bn: "জনসেবার গল্প", en: "Public-service story", detailBn: "পাবলিক তথ্যভিত্তিক গল্পের ব্লক", detailEn: "Public informational story block" },
  gallery: { bn: "উন্মুক্ত গ্যালারি", en: "Open gallery", detailBn: "ফুটারের আগের অনুমোদিত গ্যালারি ব্লক", detailEn: "Approved gallery block before the footer" },
};

const surfaceOptions = [
  { value: "inherit", bn: "মূল ডিজাইন", en: "Original" },
  { value: "paper", bn: "সাদা কার্ড", en: "Paper" },
  { value: "tint", bn: "হালকা রঙ", en: "Tint" },
  { value: "outline", bn: "বর্ডার", en: "Outline" },
] as const;

function cloneLayout(layout: HomeSectionLayout) {
  return normalizeHomeSectionLayout(JSON.parse(JSON.stringify(layout)));
}

export default function HomeSectionLayoutBuilder() {
  const { language } = useLanguage();
  const isBn = language === "BN";
  const workspaceQuery = trpc.siteManagement.getOwnerWorkspace.useQuery(undefined, { retry: false });
  const [layout, setLayout] = useState<HomeSectionLayout>(DEFAULT_HOME_SECTION_LAYOUT);
  const [clipboard, setClipboard] = useState<HomeSectionLayout | null>(null);
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "mobile">("desktop");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const saveMutation = trpc.siteManagement.saveHomeSectionLayout.useMutation({
    onSuccess: () => {
      setNotice(isBn ? "Layout live public homepage-এ সংরক্ষিত হয়েছে।" : "Layout has been saved to the live public homepage.");
      setError("");
      void workspaceQuery.refetch();
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice("");
    },
  });

  useEffect(() => {
    setLayout(parseHomeSectionLayout(workspaceQuery.data?.settings?.homeSectionLayoutJson));
  }, [workspaceQuery.data?.settings?.homeSectionLayoutJson]);

  const orderedSections = useMemo(() => HOME_SECTION_LAYOUT_KEYS
    .map((key, originalIndex) => ({ key, originalIndex, item: layout[key] }))
    .sort((a, b) => a.item.order - b.item.order || a.originalIndex - b.originalIndex), [layout]);

  const update = (key: HomeSectionLayoutKey, changes: Partial<HomeSectionLayout[HomeSectionLayoutKey]>) => {
    setLayout((current) => ({ ...current, [key]: { ...current[key], ...changes } }));
    setNotice("");
  };
  const move = (key: HomeSectionLayoutKey, direction: -1 | 1) => {
    const index = orderedSections.findIndex((section) => section.key === key);
    const target = orderedSections[index + direction];
    if (!target) return;
    setLayout((current) => ({
      ...current,
      [key]: { ...current[key], order: target.item.order },
      [target.key]: { ...current[target.key], order: current[key].order },
    }));
    setNotice("");
  };
  const save = () => saveMutation.mutate({ sections: HOME_SECTION_LAYOUT_KEYS.map((key) => ({ key, ...layout[key] })) });
  const copyLayout = () => {
    setClipboard(cloneLayout(layout));
    setNotice(isBn ? "বর্তমান সাজানো অবস্থা এই editor-এ কপি হয়েছে।" : "The current arrangement has been copied in this editor.");
  };
  const pasteLayout = () => {
    if (!clipboard) return;
    setLayout(cloneLayout(clipboard));
    setNotice(isBn ? "কপি করা সাজানো অবস্থা বসানো হয়েছে—Save করলে live হবে।" : "The copied arrangement is applied—save to make it live.");
  };
  const restore = () => {
    setLayout(DEFAULT_HOME_SECTION_LAYOUT);
    setNotice(isBn ? "নিরাপদ মূল layout ফিরেছে—Save করলে live হবে।" : "The safe default layout is restored—save to make it live.");
  };

  return (
    <section id="layout-builder" className="rounded-2xl border border-violet-400/35 bg-violet-500/10 p-5 shadow-xl sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-3xl">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-violet-200">Layout &amp; Section Builder</p>
          <h2 className="mt-1 text-xl font-black text-white">{isBn ? "হোমপেজের নকশা ও সেকশন সাজান" : "Arrange homepage design and sections"}</h2>
          <p className="mt-2 text-sm leading-6 text-slate-300">{isBn ? "Mobile ও desktop-এর জন্য এই সাতটি অনুমোদিত public section-এর ক্রম, visibility, card surface এবং mobile density পরিবর্তন করতে পারবেন। নিরাপত্তা, Admin, account, backup, analytics ও payment অংশ এখানে নেই।" : "You can adjust the order, visibility, card surface, and mobile density of these seven approved public sections. Security, Admin, account, backup, analytics, and payment areas are not editable here."}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={copyLayout} className="inline-flex items-center gap-2 rounded-xl border border-violet-300/50 px-3 py-2 text-xs font-black text-violet-100 hover:bg-violet-300/10"><Copy className="h-4 w-4" />{isBn ? "কপি" : "Copy"}</button>
          <button type="button" onClick={pasteLayout} disabled={!clipboard || saveMutation.isPending} className="rounded-xl border border-slate-500 px-3 py-2 text-xs font-black text-slate-100 hover:border-violet-300 disabled:cursor-not-allowed disabled:opacity-50">{isBn ? "পেস্ট" : "Paste"}</button>
          <button type="button" onClick={restore} disabled={saveMutation.isPending} className="inline-flex items-center gap-2 rounded-xl border border-slate-500 px-3 py-2 text-xs font-black text-slate-100 hover:border-violet-300 disabled:opacity-50"><RotateCcw className="h-4 w-4" />{isBn ? "মূল নকশা" : "Default"}</button>
        </div>
      </div>

      <div className="mt-4 grid gap-3 rounded-xl border border-violet-200/15 bg-slate-950/50 p-3 text-xs text-slate-300 sm:grid-cols-2">
        <p className="flex items-center gap-2"><Monitor className="h-4 w-4 text-violet-200" />{isBn ? "Desktop: ক্রম ও surface public homepage-এ প্রযোজ্য।" : "Desktop: order and surface apply to the public homepage."}</p>
        <p className="flex items-center gap-2"><Smartphone className="h-4 w-4 text-violet-200" />{isBn ? "Mobile: প্রতিটি section comfortable বা compact রাখা যায়।" : "Mobile: each section can be comfortable or compact."}</p>
      </div>

      <div className="mt-4 rounded-2xl border border-violet-200/20 bg-slate-950/55 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div><h3 className="text-sm font-black text-white">{isBn ? "সাজানোর পূর্বরূপ" : "Arrangement preview"}</h3><p className="mt-1 text-xs leading-5 text-slate-400">{isBn ? "এটি live content বদলায় না; নিচের ক্রম, নকশা ও mobile spacing Save করার আগেই যাচাই করুন।" : "This does not change live content; review order, surface, and mobile spacing before saving."}</p></div>
          <div className="flex rounded-xl border border-slate-700 p-1 text-xs font-bold">
            <button type="button" onClick={() => setPreviewDevice("desktop")} className={`rounded-lg px-3 py-1.5 ${previewDevice === "desktop" ? "bg-violet-300 text-slate-950" : "text-slate-200"}`}><Monitor className="mr-1 inline h-3.5 w-3.5" />{isBn ? "ডেস্কটপ" : "Desktop"}</button>
            <button type="button" onClick={() => setPreviewDevice("mobile")} className={`rounded-lg px-3 py-1.5 ${previewDevice === "mobile" ? "bg-violet-300 text-slate-950" : "text-slate-200"}`}><Smartphone className="mr-1 inline h-3.5 w-3.5" />{isBn ? "মোবাইল" : "Mobile"}</button>
          </div>
        </div>
        <div className={`mt-4 grid gap-2 transition-[max-width] duration-200 ${previewDevice === "mobile" ? "mx-auto max-w-sm" : "max-w-none sm:grid-cols-2"}`} aria-label={isBn ? "নকশার পূর্বরূপ" : "Layout preview"}>
          {orderedSections.filter(({ item }) => item.visible).map(({ key, item }, index) => {
            const label = labels[key];
            return <div key={`preview-${key}`} className={`rounded-xl border p-3 ${item.surface === "paper" ? "border-slate-200 bg-white text-slate-900" : item.surface === "tint" ? "border-violet-300/35 bg-violet-400/15 text-violet-50" : item.surface === "outline" ? "border-violet-300/70 bg-transparent text-violet-100" : "border-slate-700 bg-slate-900 text-white"} ${previewDevice === "mobile" && item.mobileDensity === "compact" ? "py-2" : "py-4"}`}>
              <p className="text-[10px] font-black uppercase tracking-[0.16em] opacity-65">{String(index + 1).padStart(2, "0")}</p><p className="mt-1 text-sm font-black">{isBn ? label.bn : label.en}</p>
            </div>;
          })}
          {orderedSections.every(({ item }) => !item.visible) ? <p className="rounded-xl border border-amber-300/35 bg-amber-300/10 p-3 text-xs text-amber-100">{isBn ? "কমপক্ষে একটি section দেখান, তাহলে পূর্বরূপ দেখা যাবে।" : "Show at least one section to see the preview."}</p> : null}
        </div>
      </div>

      {workspaceQuery.isLoading ? <p className="mt-5 text-sm text-slate-300">{isBn ? "বর্তমান সাজানো অবস্থা লোড হচ্ছে…" : "Loading current arrangement…"}</p> : null}
      {error ? <p className="mt-4 rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-sm text-rose-100" role="alert">{error}</p> : null}
      {notice ? <p className="mt-4 rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-3 text-sm text-emerald-50" role="status">{notice}</p> : null}

      <div className="mt-5 space-y-3">
        {orderedSections.map(({ key, item }, index) => {
          const label = labels[key];
          return <article key={key} className="rounded-2xl border border-slate-700/80 bg-slate-950/65 p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div><p className="text-xs font-bold text-violet-200">{String(index + 1).padStart(2, "0")}</p><h3 className="mt-1 font-black text-white">{isBn ? label.bn : label.en}</h3><p className="mt-1 text-xs leading-5 text-slate-400">{isBn ? label.detailBn : label.detailEn}</p></div>
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => move(key, -1)} disabled={index === 0 || saveMutation.isPending} className="rounded-lg border border-slate-600 px-2.5 py-1.5 text-xs font-bold text-slate-100 disabled:opacity-40" aria-label={isBn ? "উপরে নিন" : "Move up"}>↑</button>
                <button type="button" onClick={() => move(key, 1)} disabled={index === orderedSections.length - 1 || saveMutation.isPending} className="rounded-lg border border-slate-600 px-2.5 py-1.5 text-xs font-bold text-slate-100 disabled:opacity-40" aria-label={isBn ? "নিচে নিন" : "Move down"}>↓</button>
                <button type="button" onClick={() => update(key, { visible: !item.visible })} disabled={saveMutation.isPending} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-600 px-2.5 py-1.5 text-xs font-bold text-slate-100 disabled:opacity-40">{item.visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}{item.visible ? (isBn ? "দেখানো" : "Shown") : (isBn ? "যোগ করুন" : "Add")}</button>
                <button type="button" onClick={() => { if (window.confirm(isBn ? `“${label.bn}” নকশা থেকে সরাবেন? তথ্য মুছবে না; পরে “যোগ করুন” দিয়ে আবার দেখানো যাবে।` : `Remove “${label.en}” from the layout? Its data is not deleted and can be added back later.`)) update(key, { visible: false }); }} disabled={!item.visible || saveMutation.isPending} className="inline-flex items-center gap-1.5 rounded-lg border border-rose-400/45 px-2.5 py-1.5 text-xs font-bold text-rose-100 disabled:opacity-40"><Trash2 className="h-3.5 w-3.5" />{isBn ? "নকশা থেকে সরান" : "Remove"}</button>
              </div>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5 text-xs font-semibold text-slate-300"><span>{isBn ? "কার্ডের নকশা" : "Section surface"}</span><select value={item.surface} onChange={(event) => update(key, { surface: event.target.value as typeof item.surface })} disabled={saveMutation.isPending} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white outline-none focus:border-violet-300">{surfaceOptions.map((option) => <option key={option.value} value={option.value}>{isBn ? option.bn : option.en}</option>)}</select></label>
              <label className="grid gap-1.5 text-xs font-semibold text-slate-300"><span>{isBn ? "মোবাইলের spacing" : "Mobile spacing"}</span><select value={item.mobileDensity} onChange={(event) => update(key, { mobileDensity: event.target.value as typeof item.mobileDensity })} disabled={saveMutation.isPending} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm text-white outline-none focus:border-violet-300"><option value="comfortable">{isBn ? "আরামদায়ক" : "Comfortable"}</option><option value="compact">{isBn ? "সংক্ষিপ্ত" : "Compact"}</option></select></label>
            </div>
          </article>;
        })}
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-violet-200/15 pt-5">
        <p className="max-w-2xl text-xs leading-5 text-slate-300">{isBn ? "Save করলে পরিবর্তনটি public homepage-এ live হবে। এটি কেবল approved section settings বদলায়; section-এর তথ্য মুছে ফেলে না।" : "Saving makes this change live on the public homepage. It changes only approved section settings and never deletes section data."}</p>
        <button type="button" onClick={save} disabled={saveMutation.isPending || workspaceQuery.isLoading} className="inline-flex items-center gap-2 rounded-xl bg-violet-300 px-4 py-2.5 text-sm font-black text-slate-950 hover:bg-violet-200 disabled:cursor-not-allowed disabled:opacity-50"><Save className="h-4 w-4" />{saveMutation.isPending ? (isBn ? "সংরক্ষণ হচ্ছে…" : "Saving…") : (isBn ? "Layout Live Save" : "Save layout live")}</button>
      </div>
    </section>
  );
}
