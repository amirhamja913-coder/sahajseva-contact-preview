import { useMemo, useState } from "react";
import { Newspaper, Video, Clapperboard, Tv, ArrowUpRight, MessageCircle, Radio, Globe2, Megaphone } from "lucide-react";
import { Link } from "wouter";
import { trackEvent, trackOutbound } from "@/lib/analytics";

type Language = "BN" | "EN";

export type MediaHubSettings = {
  slug: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  disclaimerBn: string;
  disclaimerEn: string;
  iconName: string;
  visible: number;
};

export type MediaHubChannel = {
  id: number;
  categorySlug: "news" | "drama" | "movie" | "government" | "national-newspapers" | string;
  categoryNameBn: string;
  categoryNameEn: string;
  channelNameBn: string;
  channelNameEn: string;
  officialUrl: string;
  logoUrl?: string | null;
  descriptionBn?: string | null;
  descriptionEn?: string | null;
  visible: number;
  displayOrder: number;
  isPrime?: number;
};

export type MediaHubView = "all" | "tv" | "newspapers";

type MediaHubSectionProps = {
  settings: MediaHubSettings | null | undefined;
  channels: MediaHubChannel[];
  language: Language;
  view?: MediaHubView;
  homeDirectory?: boolean;
  headingOverride?: {
    kicker: string;
    title: string;
    description: string;
  };
};

const categoryMeta = {
  news: { icon: Newspaper, fallbackBn: "সংবাদ", fallbackEn: "News" },
  drama: { icon: Video, fallbackBn: "নাটক/সিরিয়াল", fallbackEn: "Drama / Serial" },
  movie: { icon: Clapperboard, fallbackBn: "সিনেমা", fallbackEn: "Movies" },
  government: { icon: Tv, fallbackBn: "সরকারি", fallbackEn: "Government" },
  "national-newspapers": { icon: Newspaper, fallbackBn: "জাতীয় পত্রিকা", fallbackEn: "National Newspapers" },
} as const;

const mediaSectionIcons = { Tv, Newspaper, Radio, Globe2, Megaphone } as const;

function getNeutralChannelMonogram(channelName: string) {
  const compact = channelName.replace(/\s+/g, "").trim();
  return compact.slice(0, 2).toUpperCase() || "মি";
}

export default function MediaHubSection({ settings, channels, language, view = "all", homeDirectory = false, headingOverride }: MediaHubSectionProps) {
  const [activeCategory, setActiveCategory] = useState<"news" | "drama" | "movie" | "government" | "national-newspapers">("national-newspapers");
  const isBangla = language === "BN";
  const activeSettings: MediaHubSettings = settings ?? {
    slug: "media-hub",
    titleBn: "বাংলাদেশের সংবাদমাধ্যম ও গণমাধ্যম",
    titleEn: "Bangladesh Media Directory",
    descriptionBn: "প্রকাশিত টিভি চ্যানেল ও জাতীয় পত্রিকার অফিসিয়াল লিংক এক জায়গায় দেখুন।",
    descriptionEn: "Find official links for published television channels and national newspapers in one place.",
    disclaimerBn: "লিংকগুলো সংশ্লিষ্ট প্রতিষ্ঠানের অফিসিয়াল ওয়েবসাইটে নিয়ে যাবে।",
    disclaimerEn: "Links open the respective organisations’ official websites.",
    iconName: "Tv",
    visible: 1,
  };
  const permittedCategories = view === "newspapers"
    ? ["national-newspapers"]
    : view === "tv"
      ? ["news", "drama", "movie", "government"]
      : ["national-newspapers", "news", "drama", "movie", "government"];
  const visibleChannels = useMemo(
    () => channels
      .filter((channel) => Number(channel.visible) === 1 && permittedCategories.includes(channel.categorySlug))
      .sort((a, b) => a.displayOrder - b.displayOrder || (b.isPrime ?? 0) - (a.isPrime ?? 0) || a.id - b.id),
    [channels, permittedCategories.join("|")],
  );

  if (settings && Number(settings.visible) !== 1) return null;

  const grouped = visibleChannels.reduce<Record<string, MediaHubChannel[]>>((result, channel) => {
    (result[channel.categorySlug] ??= []).push(channel);
    return result;
  }, {});
  const availableCategories = (["national-newspapers", "news", "drama", "movie", "government"] as const).filter((category) => permittedCategories.includes(category) && (grouped[category] ?? []).length > 0);
  const selectedCategory = availableCategories.includes(activeCategory) ? activeCategory : (availableCategories[0] ?? "national-newspapers");
  const selectedMeta = categoryMeta[selectedCategory];
  const SelectedIcon = selectedMeta.icon;
  const title = headingOverride?.title ?? (isBangla ? activeSettings.titleBn : activeSettings.titleEn);
  const description = headingOverride?.description ?? (isBangla ? activeSettings.descriptionBn : activeSettings.descriptionEn);
  const kicker = headingOverride?.kicker ?? (isBangla ? "০৬ / প্রবাসী মিডিয়া হাব" : "06 / DIASPORA MEDIA HUB");
  const disclaimer = isBangla ? activeSettings.disclaimerBn : activeSettings.disclaimerEn;
  const SectionIcon = mediaSectionIcons[activeSettings.iconName as keyof typeof mediaSectionIcons] ?? Tv;
  const tvChannelCount = visibleChannels.filter((channel) => channel.categorySlug !== "national-newspapers").length;
  const newspaperCount = visibleChannels.filter((channel) => channel.categorySlug === "national-newspapers").length;

  if (homeDirectory) {
    return (
      <section id="media-hub" aria-labelledby="media-hub-heading" className="media-directory-section">
        <div className="container">
          <div className="media-directory-heading">
            <div>
              <span className="section-number">{kicker}</span>
              <h2 id="media-hub-heading">{title}</h2>
              <p>{description}</p>
            </div>
            <span className="media-directory-disclaimer"><SectionIcon size={15} aria-hidden="true" /> {disclaimer}</span>
          </div>

          <div className="media-directory-grid">
            <Link href="/tv-channels" className="media-directory-folder media-directory-folder-tv" onClick={() => trackEvent("media_directory_open", { folder: "tv" })}>
              <img src="/manus-storage/sahaj-media-tv-feature_99ce3b36.png" alt="" loading="lazy" decoding="async" />
              <span className="media-directory-scrim" aria-hidden="true" />
              <span className="media-directory-copy">
                <span className="media-directory-icon"><Tv size={28} aria-hidden="true" /></span>
                <span className="media-directory-eyebrow">{isBangla ? "ভিডিও ফোল্ডার" : "VIDEO FOLDER"}</span>
                <strong>{isBangla ? "বাংলাদেশ টিভি চ্যানেল" : "Bangladesh TV Channels"}</strong>
                <span>{isBangla ? `${tvChannelCount}টি প্রকাশিত টিভি চ্যানেলের অফিসিয়াল ডিরেক্টরি দেখুন` : `Browse the official directory of ${tvChannelCount} published TV channels`}</span>
                <span className="media-directory-cta">{isBangla ? "টিভি ফোল্ডার খুলুন" : "Open TV folder"} <ArrowUpRight size={17} aria-hidden="true" /></span>
              </span>
            </Link>

            <Link href="/newspapers" className="media-directory-folder media-directory-folder-newspaper" onClick={() => trackEvent("media_directory_open", { folder: "newspapers" })}>
              <img src="/manus-storage/sahaj-media-newspaper-feature_9ca95b5e.png" alt="" loading="lazy" decoding="async" />
              <span className="media-directory-scrim" aria-hidden="true" />
              <span className="media-directory-copy">
                <span className="media-directory-icon"><Newspaper size={28} aria-hidden="true" /></span>
                <span className="media-directory-eyebrow">{isBangla ? "পত্রিকা ফোল্ডার" : "NEWSPAPER FOLDER"}</span>
                <strong>{isBangla ? "বাংলাদেশ পত্রিকা পোর্টাল" : "Bangladesh Newspaper Portal"}</strong>
                <span>{isBangla ? `${newspaperCount}টি প্রকাশিত পত্রিকার সম্পূর্ণ ফোল্ডার দেখুন` : `Open the complete folder of ${newspaperCount} published newspapers`}</span>
                <span className="media-directory-cta">{isBangla ? "পত্রিকা ফোল্ডার খুলুন" : "Open newspaper folder"} <ArrowUpRight size={17} aria-hidden="true" /></span>
              </span>
            </Link>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="media-hub" aria-labelledby="media-hub-heading" style={{ padding: "4.5rem 0", background: "radial-gradient(circle at 6% 12%, rgba(15,118,110,0.12) 0, transparent 22rem), radial-gradient(circle at 95% 8%, rgba(217,119,6,0.14) 0, transparent 20rem), linear-gradient(135deg, #fffcf4 0%, #f7fbf8 48%, #fff8e7 100%)", borderTop: "1px solid #d8e7df", borderBottom: "1px solid #eadfc6" }}>
      <div className="container">
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "1rem", flexWrap: "wrap", marginBottom: "1.5rem" }}>
          <div style={{ maxWidth: "780px" }}>
            <span className="section-number" style={{ color: "#0f766e", fontWeight: 800, letterSpacing: "0.06em" }}>{kicker}</span>
            <h2 id="media-hub-heading" style={{ margin: "0.35rem 0 0", color: "#102a43", fontSize: "clamp(1.8rem, 4vw, 3rem)", lineHeight: 1.08, fontWeight: 900 }}>{title}</h2>
            <p style={{ margin: "0.75rem 0 0", color: "#475569", fontSize: "1rem", lineHeight: 1.65 }}>{description}</p>
          </div>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", padding: "0.55rem 0.85rem", borderRadius: "999px", background: "#fffdf8cc", color: "#0f766e", border: "1px solid #b8d8cf", fontWeight: 800, fontSize: "0.82rem", boxShadow: "0 6px 18px rgba(15,118,110,0.08)" }}>
            <SectionIcon size={15} aria-hidden="true" /> {view === "tv" ? (isBangla ? "নির্বাচিত টিভি চ্যানেল" : "Selected TV channels") : view === "newspapers" ? (isBangla ? "নির্বাচিত জাতীয় পত্রিকা" : "Selected national newspapers") : (isBangla ? "নির্বাচিত চ্যানেল ও পত্রিকা" : "Selected channels & newspapers")}
          </span>
        </div>

        <div role="tablist" aria-label={isBangla ? "মিডিয়া বিভাগ" : "Media categories"} style={{ display: availableCategories.length > 1 ? "flex" : "none", gap: "0.55rem", overflowX: "auto", paddingBottom: "0.35rem", marginBottom: "1.5rem" }}>
          {availableCategories.map((category) => {
            const meta = categoryMeta[category];
            const Icon = meta.icon;
            const active = selectedCategory === category;
            const categoryLabel = isBangla ? (grouped[category]?.[0]?.categoryNameBn || meta.fallbackBn) : (grouped[category]?.[0]?.categoryNameEn || meta.fallbackEn);
            return (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => { setActiveCategory(category); trackEvent("media_hub_tab_click", { category }); }}
                style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", flex: "0 0 auto", minHeight: "2.65rem", padding: "0.6rem 1rem", borderRadius: "999px", border: active ? "1px solid #0f766e" : "1px solid #cbd9d3", background: active ? "#0f766e" : "#fffdf9", color: active ? "#ffffff" : "#28423e", fontWeight: 850, cursor: "pointer", whiteSpace: "nowrap", boxShadow: active ? "0 5px 14px rgba(15,118,110,0.23)" : "0 2px 6px rgba(20,83,45,0.04)" }}
              >
                <Icon size={16} aria-hidden="true" /> {categoryLabel}
              </button>
            );
          })}
        </div>

        {availableCategories.length === 0 ? (
          <div role="status" style={{ padding: "1.35rem", borderRadius: "16px", border: "1px dashed #9fc8ba", background: "#fffdf8", color: "#365a53", lineHeight: 1.65, fontWeight: 700 }}>
            {isBangla ? "এই বিভাগে এখনো কোনো প্রকাশিত মিডিয়া রেকর্ড নেই। Admin Media Hub থেকে রেকর্ড প্রকাশ করলে এখানে ক্রমানুসারে দেখা যাবে।" : "There are no published media records in this directory yet. Published records from Admin Media Hub will appear here in order."}
          </div>
        ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 290px), 1fr))", gap: "1.1rem" }} role="tabpanel" aria-label={isBangla ? selectedMeta.fallbackBn : selectedMeta.fallbackEn}>
          {(grouped[selectedCategory] ?? []).map((channel) => {
            const channelName = isBangla ? channel.channelNameBn : channel.channelNameEn;
            const channelDesc = isBangla ? (channel.descriptionBn || "অফিসিয়াল সংবাদ ও সম্প্রচার মাধ্যম") : (channel.descriptionEn || "Official news and broadcasting portal");
            const isPrime = channel.isPrime === 1;
            const logoSize = isPrime ? "80px" : "64px";
            const monogram = getNeutralChannelMonogram(channelName);
            // Remote favicons often block browser loading or render as a blank tile.
            // Render only owner-managed storage artwork; every other entry gets the
            // permanent category-icon + monogram treatment below.
            const storedLogoUrl = channel.logoUrl?.trim();
            const logoUrl = storedLogoUrl?.startsWith("/manus-storage/") ? storedLogoUrl : null;
            return (
              <a
                key={channel.id}
                href={channel.officialUrl}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  gap: "0.9rem",
                  padding: isPrime ? "1.35rem 1.25rem" : "1.1rem 1rem",
                  borderRadius: "18px",
                  background: isPrime ? "linear-gradient(135deg, #fff8e4 0%, #fffdf8 70%, #f7e3a8 100%)" : "linear-gradient(145deg, #fffefb 0%, #ffffff 58%, #f3faf7 100%)",
                  border: isPrime ? "2px solid #d97706" : "1px solid #d5e7df",
                  color: "#102a43",
                  textDecoration: "none",
                  boxShadow: isPrime ? "0 14px 32px rgba(217,119,6,0.18)" : "0 8px 22px rgba(15,118,110,0.08)",
                  position: "relative",
                  transition: "transform 0.18s ease, box-shadow 0.18s ease",
                }}
                onClick={() => { trackEvent("media_channel_click", { category: channel.categorySlug, channel: channel.channelNameEn }); trackOutbound(channelName, channel.officialUrl, "media_hub"); }}
              >
                <div style={{ display: "flex", alignItems: "flex-start", gap: "0.9rem" }}>
                  <div
                    style={{
                      flex: `0 0 ${logoSize}`,
                      width: logoSize,
                      height: logoSize,
                      borderRadius: "14px",
                      background: isPrime ? "linear-gradient(145deg, #fff4c8 0%, #fffdf5 54%, #fae9bd 100%)" : "linear-gradient(145deg, #e7f5f0 0%, #fffdf9 55%, #dcf1e7 100%)",
                      border: isPrime ? "2px solid #e6a334" : "1px solid #b8d8cf",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      overflow: "hidden",
                      boxShadow: "0 4px 12px rgba(0,0,0,0.06)",
                      position: "relative",
                    }}
                  >
                    <SelectedIcon size={isPrime ? 36 : 28} strokeWidth={2.4} color={isPrime ? "#a65309" : "#0f766e"} aria-hidden="true" />
                    <span aria-hidden="true" style={{ position: "absolute", right: "5px", bottom: "4px", minWidth: "1.3rem", padding: "0.08rem 0.18rem", borderRadius: "999px", background: isPrime ? "#d97706" : "#0f766e", color: "#fff", fontSize: "0.53rem", fontWeight: 950, lineHeight: 1.1, textAlign: "center", boxShadow: "0 0 0 3px rgba(255,255,255,0.8)" }}>{monogram}</span>
                    {logoUrl && (
                      <img
                        src={logoUrl}
                        alt={`${channelName} owner-provided logo`}
                        loading="lazy"
                        decoding="async"
                        referrerPolicy="no-referrer"
                        data-owner-logo="true"
                        onError={(event) => { event.currentTarget.style.display = "none"; }}
                        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", padding: isPrime ? "8px" : "7px", background: "linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)" }}
                      />
                    )}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.45rem", flexWrap: "wrap", marginBottom: "0.2rem" }}>
                      <span style={{ fontSize: "0.75rem", fontWeight: 800, color: "#0f766e", background: "#e7f5f0", padding: "0.12rem 0.45rem", borderRadius: "6px" }}>
                        {isBangla ? channel.categoryNameBn : channel.categoryNameEn}
                      </span>
                      <span style={{ fontSize: "0.72rem", fontWeight: 900, color: "#365a53", background: "#fffdf8", border: "1px solid #c9ddd5", padding: "0.12rem 0.42rem", borderRadius: "6px" }}>
                        {isBangla ? `ক্রম ${new Intl.NumberFormat("bn-BD").format(channel.displayOrder)}` : `No. ${channel.displayOrder}`}
                      </span>
                      {isPrime && (
                        <span style={{ borderRadius: "999px", background: "#e6a334", color: "#3a2404", padding: "0.15rem 0.55rem", fontSize: "0.68rem", fontWeight: 950, letterSpacing: "0.03em" }}>
                          {view === "newspapers" ? (isBangla ? "⭐ প্রাইম সংবাদমাধ্যম" : "⭐ PRIME NEWSPAPER") : (isBangla ? "⭐ প্রাইম মিডিয়া" : "⭐ PRIME MEDIA")}
                        </span>
                      )}
                    </div>
                    <h3 style={{ margin: 0, fontSize: isPrime ? "1.2rem" : "1.05rem", fontWeight: 900, color: "#102a43", lineHeight: 1.25, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {channelName}
                    </h3>
                    <p style={{ margin: "0.3rem 0 0", fontSize: "0.85rem", color: "#475569", lineHeight: 1.45, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                      {channelDesc}
                    </p>
                  </div>
                </div>

                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: "0.6rem", borderTop: "1px solid #e6efe9", fontSize: "0.85rem", fontWeight: 850 }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.35rem", color: isPrime ? "#a65309" : "#0f766e" }}>
                    {isBangla ? "অফিসিয়াল সাইট দেখুন" : "Visit Official Site"}
                  </span>
                  <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: "1.85rem", height: "1.85rem", borderRadius: "50%", background: isPrime ? "#fff0c8" : "#e7f5f0", color: isPrime ? "#a65309" : "#0f766e" }}>
                    <ArrowUpRight size={15} aria-hidden="true" />
                  </span>
                </div>
              </a>
            );
          })}
        </div>
        )}

        <p style={{ display: "flex", alignItems: "flex-start", gap: "0.45rem", margin: "1.5rem 0 0", color: "#64748b", fontSize: "0.82rem", lineHeight: 1.55 }}>
          <MessageCircle size={15} color="#64748b" aria-hidden="true" /> <span>{disclaimer}</span>
        </p>
      </div>
    </section>
  );
}
