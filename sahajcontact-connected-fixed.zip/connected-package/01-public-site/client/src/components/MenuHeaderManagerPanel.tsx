import { useEffect, useState } from "react";
import { GripVertical, Link2, Palette, Plus, Save, Settings2, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

type HeaderDraft = {
  headerAnnouncementEnabled: boolean;
  headerAnnouncementTextBn: string;
  headerAnnouncementTextEn: string;
  headerAnnouncementButtonBn: string;
  headerAnnouncementButtonEn: string;
  headerAnnouncementColor: string;
  showLanguageBn: boolean;
  showLanguageEn: boolean;
  defaultSiteLanguage: "BN" | "EN";
  probashiHelpVisible: boolean;
  probashiHelpTitleBn: string;
  probashiHelpTitleEn: string;
  probashiHelpSubtitleBn: string;
  probashiHelpSubtitleEn: string;
  probashiHelpLinkBn: string;
  probashiHelpLinkEn: string;
  probashiHelpHref: string;
};

type MenuDraft = { id: number | null; titleBn: string; titleEn: string; url: string; visible: boolean; displayOrder: number };
type SavedMenuItem = Omit<MenuDraft, "id"> & { id: number };

const defaultHeaderDraft: HeaderDraft = {
  headerAnnouncementEnabled: true,
  headerAnnouncementTextBn: "গ্রামীণ মোটিফ চলছে",
  headerAnnouncementTextEn: "Rural motif is active",
  headerAnnouncementButtonBn: "থামাতে চাপুন",
  headerAnnouncementButtonEn: "Tap to pause",
  headerAnnouncementColor: "#0d5c56",
  showLanguageBn: true,
  showLanguageEn: true,
  defaultSiteLanguage: "BN",
  probashiHelpVisible: true,
  probashiHelpTitleBn: "প্রবাসী সহায়তা",
  probashiHelpTitleEn: "Expatriate Support",
  probashiHelpSubtitleBn: "প্রবাসী গাইড ও কান্ট্রি ফিল্টার",
  probashiHelpSubtitleEn: "Expat Guide & Country Filter",
  probashiHelpLinkBn: "গাইডলাইন দেখতে চাপুন",
  probashiHelpLinkEn: "Tap to view guidelines",
  probashiHelpHref: "/#expatriates",
};

const emptyMenuDraft: MenuDraft = { id: null, titleBn: "", titleEn: "", url: "/", visible: true, displayOrder: 0 };

function asBool(value: unknown, fallback = true) {
  return value === undefined || value === null ? fallback : value === true || value === 1;
}

export function MenuHeaderManagerPanel({ isOwner }: { isOwner: boolean }) {
  const utils = trpc.useUtils();
  const managerQuery = trpc.siteManagement.management.getHeaderManager.useQuery(undefined, { enabled: isOwner, retry: false });
  const [draft, setDraft] = useState<HeaderDraft>(defaultHeaderDraft);
  const [menuItems, setMenuItems] = useState<SavedMenuItem[]>([]);
  const [menuDraft, setMenuDraft] = useState<MenuDraft>(emptyMenuDraft);
  const [draggedId, setDraggedId] = useState<number | null>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const settings = managerQuery.data?.settings;
    if (settings) {
      setDraft({
        headerAnnouncementEnabled: asBool(settings.headerAnnouncementEnabled),
        headerAnnouncementTextBn: settings.headerAnnouncementTextBn ?? defaultHeaderDraft.headerAnnouncementTextBn,
        headerAnnouncementTextEn: settings.headerAnnouncementTextEn ?? defaultHeaderDraft.headerAnnouncementTextEn,
        headerAnnouncementButtonBn: settings.headerAnnouncementButtonBn ?? defaultHeaderDraft.headerAnnouncementButtonBn,
        headerAnnouncementButtonEn: settings.headerAnnouncementButtonEn ?? defaultHeaderDraft.headerAnnouncementButtonEn,
        headerAnnouncementColor: settings.headerAnnouncementColor ?? defaultHeaderDraft.headerAnnouncementColor,
        showLanguageBn: asBool(settings.showLanguageBn),
        showLanguageEn: asBool(settings.showLanguageEn),
        defaultSiteLanguage: settings.defaultSiteLanguage === "EN" ? "EN" : "BN",
        probashiHelpVisible: asBool(settings.probashiHelpVisible),
        probashiHelpTitleBn: settings.probashiHelpTitleBn ?? defaultHeaderDraft.probashiHelpTitleBn,
        probashiHelpTitleEn: settings.probashiHelpTitleEn ?? defaultHeaderDraft.probashiHelpTitleEn,
        probashiHelpSubtitleBn: settings.probashiHelpSubtitleBn ?? defaultHeaderDraft.probashiHelpSubtitleBn,
        probashiHelpSubtitleEn: settings.probashiHelpSubtitleEn ?? defaultHeaderDraft.probashiHelpSubtitleEn,
        probashiHelpLinkBn: settings.probashiHelpLinkBn ?? defaultHeaderDraft.probashiHelpLinkBn,
        probashiHelpLinkEn: settings.probashiHelpLinkEn ?? defaultHeaderDraft.probashiHelpLinkEn,
        probashiHelpHref: settings.probashiHelpHref ?? defaultHeaderDraft.probashiHelpHref,
      });
    }
  }, [managerQuery.data?.settings]);

  useEffect(() => {
    const savedNavigation = managerQuery.data?.navigation;
    if (savedNavigation) setMenuItems(savedNavigation.map((item) => ({
      id: item.id, titleBn: item.titleBn, titleEn: item.titleEn, url: item.url, visible: asBool(item.visible), displayOrder: item.displayOrder,
    })));
  }, [managerQuery.data?.navigation]);

  const refresh = async (nextMessage: string) => {
    await Promise.all([managerQuery.refetch(), utils.siteManagement.getPublicContent.invalidate()]);
    setMessage(nextMessage);
  };

  const saveHeaderMutation = trpc.siteManagement.management.saveHeaderSettings.useMutation({
    onSuccess: () => void refresh("সফলভাবে আপডেট হয়েছে—Public Site এখন নতুন Header Settings ব্যবহার করছে।"),
    onError: (error) => setMessage(`সংরক্ষণ করা যায়নি: ${error.message}`),
  });
  const createMenuMutation = trpc.siteManagement.management.createNavigationItem.useMutation({
    onSuccess: () => { setMenuDraft(emptyMenuDraft); void refresh("নতুন মেনু সফলভাবে যুক্ত হয়েছে।"); },
    onError: (error) => setMessage(`মেনু যোগ করা যায়নি: ${error.message}`),
  });
  const updateMenuMutation = trpc.siteManagement.management.updateNavigationItem.useMutation({
    onSuccess: () => { setMenuDraft(emptyMenuDraft); void refresh("মেনু সফলভাবে আপডেট হয়েছে।"); },
    onError: (error) => setMessage(`মেনু আপডেট করা যায়নি: ${error.message}`),
  });
  const deleteMenuMutation = trpc.siteManagement.management.deleteNavigationItem.useMutation({
    onSuccess: () => void refresh("মেনু সফলভাবে ডিলেট হয়েছে।"),
    onError: (error) => setMessage(`মেনু ডিলেট করা যায়নি: ${error.message}`),
  });
  const reorderMenuMutation = trpc.siteManagement.management.reorderNavigationItems.useMutation({
    onSuccess: () => void refresh("Menu order সফলভাবে আপডেট হয়েছে।"),
    onError: (error) => setMessage(`Menu order সংরক্ষণ করা যায়নি: ${error.message}`),
  });

  const updateDraft = <K extends keyof HeaderDraft>(key: K, value: HeaderDraft[K]) => setDraft((current) => ({ ...current, [key]: value }));
  const reorderLocal = (sourceId: number, targetId: number) => {
    const sourceIndex = menuItems.findIndex((item) => item.id === sourceId);
    const targetIndex = menuItems.findIndex((item) => item.id === targetId);
    if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
    const next = [...menuItems];
    const [moved] = next.splice(sourceIndex, 1);
    next.splice(targetIndex, 0, moved);
    setMenuItems(next.map((item, index) => ({ ...item, displayOrder: index })));
  };
  const moveItem = (id: number, direction: -1 | 1) => {
    const currentIndex = menuItems.findIndex((item) => item.id === id);
    const target = currentIndex + direction;
    if (currentIndex < 0 || target < 0 || target >= menuItems.length) return;
    reorderLocal(id, menuItems[target].id);
  };

  if (!isOwner) return null;

  return <section className="rounded-2xl border border-emerald-800/70 bg-slate-950 p-5 shadow-xl sm:p-7">
    <div className="mb-6 flex flex-col gap-3 border-b border-slate-800 pb-5 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.22em] text-emerald-400">Full Control CMS</p>
        <h2 className="mt-1 flex items-center gap-2 text-2xl font-black text-white"><Settings2 className="h-6 w-6 text-emerald-400" />Menu &amp; Header Manager</h2>
        <p className="mt-1 text-sm text-slate-300">Save করলেই Public Site-এর Desktop ও Mobile Header আপডেট হবে।</p>
      </div>
      <a href="/" target="_blank" rel="noreferrer" className="inline-flex items-center justify-center rounded-lg border border-emerald-600 px-4 py-2 text-sm font-bold text-emerald-300">Public Site দেখুন</a>
    </div>

    {message && <p className="mb-5 rounded-lg border border-emerald-700/70 bg-emerald-950/60 px-4 py-3 text-sm font-bold text-emerald-100" role="status">{message}</p>}

    <div className="grid gap-5 xl:grid-cols-2">
      <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <div className="flex items-center gap-2"><Palette className="h-5 w-5 text-emerald-400" /><h3 className="font-bold text-white">১. Announcement Bar Control</h3></div>
        <label className="flex items-center justify-between gap-3 rounded-lg bg-slate-800 px-3 py-3 text-sm font-semibold text-slate-100"><span>উপরের সবুজ বার চালু রাখুন</span><input type="checkbox" checked={draft.headerAnnouncementEnabled} onChange={(event) => updateDraft("headerAnnouncementEnabled", event.target.checked)} /></label>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm text-slate-300">বাংলা লেখা<input value={draft.headerAnnouncementTextBn} onChange={(event) => updateDraft("headerAnnouncementTextBn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
          <label className="text-sm text-slate-300">English text<input value={draft.headerAnnouncementTextEn} onChange={(event) => updateDraft("headerAnnouncementTextEn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
          <label className="text-sm text-slate-300">বাংলা Button<input value={draft.headerAnnouncementButtonBn} onChange={(event) => updateDraft("headerAnnouncementButtonBn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
          <label className="text-sm text-slate-300">English Button<input value={draft.headerAnnouncementButtonEn} onChange={(event) => updateDraft("headerAnnouncementButtonEn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
        </div>
        <label className="flex items-center gap-3 text-sm text-slate-300">Bar Color<input aria-label="Announcement Bar Color" type="color" value={draft.headerAnnouncementColor} onChange={(event) => updateDraft("headerAnnouncementColor", event.target.value)} className="h-9 w-12 rounded border-0 bg-transparent" /><code className="text-emerald-300">{draft.headerAnnouncementColor}</code></label>
      </div>

      <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="font-bold text-white">২. Language Toggle Control</h3>
        <label className="flex items-center justify-between rounded-lg bg-slate-800 px-3 py-3 text-sm font-semibold text-slate-100"><span>বাংলা বাটন দেখান</span><input type="checkbox" checked={draft.showLanguageBn} onChange={(event) => updateDraft("showLanguageBn", event.target.checked)} /></label>
        <label className="flex items-center justify-between rounded-lg bg-slate-800 px-3 py-3 text-sm font-semibold text-slate-100"><span>English বাটন দেখান</span><input type="checkbox" checked={draft.showLanguageEn} onChange={(event) => updateDraft("showLanguageEn", event.target.checked)} /></label>
        <fieldset className="rounded-lg border border-slate-700 p-3"><legend className="px-1 text-sm text-slate-300">Default Language</legend><label className="mr-5 text-sm text-white"><input className="mr-2" type="radio" checked={draft.defaultSiteLanguage === "BN"} onChange={() => updateDraft("defaultSiteLanguage", "BN")} />বাংলা</label><label className="text-sm text-white"><input className="mr-2" type="radio" checked={draft.defaultSiteLanguage === "EN"} onChange={() => updateDraft("defaultSiteLanguage", "EN")} />English</label></fieldset>
        <button type="button" onClick={() => saveHeaderMutation.mutate(draft)} disabled={saveHeaderMutation.isPending} className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-3 font-bold text-white disabled:opacity-60"><Save className="h-4 w-4" />{saveHeaderMutation.isPending ? "সংরক্ষণ হচ্ছে..." : "Save Header Changes"}</button>
      </div>

      <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-900/70 p-4 xl:col-span-2">
        <div><h3 className="font-bold text-white">৩. Menu Items Control</h3><p className="mt-1 text-sm text-slate-400">Drag &amp; Drop করে সাজান, তারপর <strong className="text-emerald-300">Save Menu Order</strong> চাপুন।</p></div>
        <div className="space-y-2">
          {menuItems.map((item) => <article key={item.id} draggable onDragStart={() => setDraggedId(item.id)} onDragOver={(event) => event.preventDefault()} onDrop={() => { if (draggedId !== null) reorderLocal(draggedId, item.id); setDraggedId(null); }} className="flex flex-col gap-3 rounded-lg border border-slate-700 bg-slate-950 p-3 sm:flex-row sm:items-center">
            <GripVertical className="hidden h-5 w-5 shrink-0 cursor-grab text-slate-500 sm:block" aria-label="Drag to reorder" />
            <div className="min-w-0 flex-1"><p className="font-bold text-white">{item.titleBn} <span className="font-normal text-slate-400">/ {item.titleEn}</span></p><p className="truncate text-xs text-slate-400">{item.url}</p></div>
            <span className={`rounded-full px-2 py-1 text-xs font-bold ${item.visible ? "bg-emerald-900 text-emerald-200" : "bg-slate-800 text-slate-300"}`}>{item.visible ? "Show" : "Hidden"}</span>
            <div className="flex flex-wrap gap-2"><button type="button" onClick={() => moveItem(item.id, -1)} className="rounded border border-slate-600 px-2 py-1 text-xs text-white">↑</button><button type="button" onClick={() => moveItem(item.id, 1)} className="rounded border border-slate-600 px-2 py-1 text-xs text-white">↓</button><button type="button" onClick={() => setMenuDraft(item)} className="rounded border border-emerald-700 px-3 py-1 text-xs font-bold text-emerald-300">Edit</button><button type="button" onClick={() => { if (window.confirm("আপনি কি নিশ্চিত?")) deleteMenuMutation.mutate({ id: item.id }); }} className="inline-flex items-center gap-1 rounded border border-red-800 px-3 py-1 text-xs font-bold text-red-300"><Trash2 className="h-3 w-3" />Delete</button></div>
          </article>)}
        </div>
        <button type="button" onClick={() => reorderMenuMutation.mutate(menuItems.map((item, displayOrder) => ({ id: item.id, displayOrder })))} disabled={menuItems.length === 0 || reorderMenuMutation.isPending} className="rounded-lg border border-emerald-600 px-4 py-2 text-sm font-bold text-emerald-300 disabled:opacity-50"><Save className="mr-2 inline h-4 w-4" />Save Menu Order</button>
        <form onSubmit={(event) => { event.preventDefault(); const payload = { ...menuDraft, displayOrder: menuDraft.id === null ? menuItems.length : menuDraft.displayOrder }; if (menuDraft.id === null) createMenuMutation.mutate(payload); else updateMenuMutation.mutate(payload as SavedMenuItem); }} className="grid gap-3 rounded-xl border border-dashed border-emerald-700 bg-emerald-950/20 p-4 md:grid-cols-2">
          <div className="md:col-span-2 flex items-center justify-between"><h4 className="font-bold text-white">{menuDraft.id === null ? "Add New Menu" : "Edit Menu Item"}</h4>{menuDraft.id !== null && <button type="button" onClick={() => setMenuDraft(emptyMenuDraft)} className="text-sm text-slate-300">Cancel</button>}</div>
          <label className="text-sm text-slate-300">বাংলা নাম<input required value={menuDraft.titleBn} onChange={(event) => setMenuDraft((current) => ({ ...current, titleBn: event.target.value }))} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
          <label className="text-sm text-slate-300">English Name<input required value={menuDraft.titleEn} onChange={(event) => setMenuDraft((current) => ({ ...current, titleEn: event.target.value }))} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
          <label className="text-sm text-slate-300 md:col-span-2">Edit Link<input required value={menuDraft.url} onChange={(event) => setMenuDraft((current) => ({ ...current, url: event.target.value }))} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label>
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-100"><input type="checkbox" checked={menuDraft.visible} onChange={(event) => setMenuDraft((current) => ({ ...current, visible: event.target.checked }))} />Hide/Show on Public Site</label>
          <button type="submit" disabled={createMenuMutation.isPending || updateMenuMutation.isPending} className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 font-bold text-white"><Plus className="h-4 w-4" />{menuDraft.id === null ? "Add New Menu" : "Save Menu Update"}</button>
        </form>
      </div>

      <div className="space-y-4 rounded-xl border border-slate-800 bg-slate-900/70 p-4 xl:col-span-2">
        <div className="flex items-center gap-2"><Link2 className="h-5 w-5 text-blue-300" /><h3 className="font-bold text-white">৪. Probashi Help Box Control</h3></div>
        <label className="flex items-center justify-between rounded-lg bg-slate-800 px-3 py-3 text-sm font-semibold text-slate-100"><span>“প্রবাসী সহায়তা” বক্স Show/Hide</span><input type="checkbox" checked={draft.probashiHelpVisible} onChange={(event) => updateDraft("probashiHelpVisible", event.target.checked)} /></label>
        <div className="grid gap-3 md:grid-cols-2"><label className="text-sm text-slate-300">Title (বাংলা)<input value={draft.probashiHelpTitleBn} onChange={(event) => updateDraft("probashiHelpTitleBn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label><label className="text-sm text-slate-300">Title (English)<input value={draft.probashiHelpTitleEn} onChange={(event) => updateDraft("probashiHelpTitleEn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label><label className="text-sm text-slate-300">Subtitle (বাংলা)<input value={draft.probashiHelpSubtitleBn} onChange={(event) => updateDraft("probashiHelpSubtitleBn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label><label className="text-sm text-slate-300">Subtitle (English)<input value={draft.probashiHelpSubtitleEn} onChange={(event) => updateDraft("probashiHelpSubtitleEn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label><label className="text-sm text-slate-300">Link Text (বাংলা)<input value={draft.probashiHelpLinkBn} onChange={(event) => updateDraft("probashiHelpLinkBn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label><label className="text-sm text-slate-300">Link Text (English)<input value={draft.probashiHelpLinkEn} onChange={(event) => updateDraft("probashiHelpLinkEn", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label><label className="text-sm text-slate-300 md:col-span-2">Guideline Link<input value={draft.probashiHelpHref} onChange={(event) => updateDraft("probashiHelpHref", event.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-950 p-2 text-white" /></label></div>
        <button type="button" onClick={() => saveHeaderMutation.mutate(draft)} disabled={saveHeaderMutation.isPending} className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-3 font-bold text-white disabled:opacity-60"><Save className="h-4 w-4" />Save Changes</button>
      </div>
    </div>
  </section>;
}
