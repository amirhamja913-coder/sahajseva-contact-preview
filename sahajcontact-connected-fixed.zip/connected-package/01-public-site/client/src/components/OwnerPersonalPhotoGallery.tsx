import { Download, FolderOpen, Images } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

export default function OwnerPersonalPhotoGallery() {
  const { language } = useLanguage();
  const isEnglish = language === "EN";
  const photosQuery = trpc.personalGallery.publicPhotos.useQuery({ folder: "gallery" }, { staleTime: 60_000, refetchOnWindowFocus: false });
  const photos = photosQuery.data ?? [];

  if (photosQuery.isLoading || photos.length === 0) return null;

  return (
    <section id="owner-personal-gallery" className="bg-stone-50 px-4 py-12 sm:py-16">
      <div className="mx-auto max-w-6xl">
        <details open className="group overflow-hidden rounded-3xl border border-emerald-200 bg-white shadow-sm">
          <summary className="flex cursor-pointer list-none flex-col gap-4 bg-gradient-to-r from-emerald-50 via-white to-amber-50 px-5 py-5 sm:flex-row sm:items-end sm:justify-between sm:px-7">
            <div>
              <p className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.18em] text-emerald-700"><FolderOpen size={16} />{isEnglish ? "Open public gallery folder" : "উন্মুক্ত পাবলিক গ্যালারি ফোল্ডার"}</p>
              <h2 className="mt-2 text-2xl font-black text-slate-900 sm:text-3xl">{isEnglish ? "Personal Photo Gallery" : "নিজস্ব স্থিরচিত্র"}</h2>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">{isEnglish ? "This folder opens by default. Public photographs remain in the owner-set serial order inside it." : "ফোল্ডারটি ডিফল্টভাবে খোলা থাকে। এর ভিতরে মালিক নির্ধারিত ক্রমে সব প্রকাশ্য ছবি সিরিয়াল অনুযায়ী সাজানো আছে।"}</p>
            </div>
            <span className="inline-flex w-fit items-center gap-2 rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-bold text-emerald-800"><Images size={15} />{photos.length} {isEnglish ? "photos" : "টি ছবি"}</span>
          </summary>
          <div className="border-t border-emerald-100 p-5 sm:p-7">
            <div className="mb-4 rounded-xl border border-emerald-100 bg-emerald-50/50 px-4 py-3 text-sm leading-6 text-slate-600">
              <strong className="text-slate-900">{isEnglish ? "Gallery summary:" : "গ্যালারি সারসংক্ষেপ:"}</strong>{" "}
              {isEnglish ? `${photos.length} public photo${photos.length === 1 ? " is" : "s are"} available below in the owner-set order.` : `নিচে মালিক নির্ধারিত ক্রমে ${photos.length}টি প্রকাশ্য ছবি দেখা যাচ্ছে।`}
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-label={isEnglish ? "Open photo gallery in serial order" : "ক্রম অনুযায়ী উন্মুক্ত ছবির গ্যালারি"}>
              {photos.map((photo, index) => {
                const title = isEnglish ? photo.titleEn : photo.titleBn;
                const description = isEnglish ? photo.descriptionEn : photo.descriptionBn;
                return <article key={photo.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <a href={photo.imageUrl} target="_blank" rel="noopener noreferrer" aria-label={isEnglish ? `Open ${title}` : `${title} বড় করে দেখুন`}><img src={photo.imageUrl} alt={title} className="h-56 w-full object-cover transition duration-200 hover:scale-[1.02]" loading="lazy" /></a>
                  <div className="p-4"><span className="inline-flex rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-black tracking-wide text-emerald-800">{isEnglish ? `PHOTO ${String(index + 1).padStart(2, "0")}` : `ছবি ${String(index + 1).padStart(2, "০")}`}</span><h3 className="mt-2 font-black text-slate-900">{title}</h3>{description ? <p className="mt-1.5 text-sm leading-6 text-slate-600">{description}</p> : null}<a href={photo.imageUrl} download className="mt-4 inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-3 py-2 text-sm font-bold text-white hover:bg-emerald-800"><Download size={16} />{isEnglish ? "Download photo" : "ছবি ডাউনলোড করুন"}</a></div>
                </article>;
              })}
            </div>
          </div>
        </details>
      </div>
    </section>
  );
}
