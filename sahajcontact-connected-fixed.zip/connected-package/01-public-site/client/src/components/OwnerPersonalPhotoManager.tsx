import { useState, type ChangeEvent } from "react";
import { ArrowDown, ArrowUp, Eye, EyeOff, ImagePlus, MapPinned, Pencil, Trash2, Upload } from "lucide-react";
import { trpc } from "@/lib/trpc";

type Folder = "gallery" | "map";
type FormState = {
  id: number | null;
  folder: Folder;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  imageUrl: string;
  storageKey: string;
  isPublic: boolean;
  displayOrder: string;
};

const blankForm: FormState = {
  id: null,
  folder: "gallery",
  titleBn: "",
  titleEn: "",
  descriptionBn: "",
  descriptionEn: "",
  imageUrl: "",
  storageKey: "",
  isPublic: false,
  displayOrder: "0",
};

function toDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি"));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });
}

export function OwnerPersonalPhotoManager({ isOwner }: { isOwner: boolean }) {
  const utils = trpc.useUtils();
  const photosQuery = trpc.personalGallery.ownerPhotos.useQuery(undefined, { enabled: isOwner });
  const [form, setForm] = useState<FormState>(blankForm);
  const [notice, setNotice] = useState("");
  const upload = trpc.personalGallery.upload.useMutation();
  const refresh = () => {
    void utils.personalGallery.ownerPhotos.invalidate();
    void utils.personalGallery.publicPhotos.invalidate();
  };
  const create = trpc.personalGallery.create.useMutation({
    onSuccess: () => {
      setNotice("ছবির তথ্য সংরক্ষণ হয়েছে।");
      setForm(blankForm);
      refresh();
    },
  });
  const update = trpc.personalGallery.update.useMutation({
    onSuccess: () => {
      setNotice("ছবির তথ্য আপডেট হয়েছে।");
      setForm(blankForm);
      refresh();
    },
  });
  const reorder = trpc.personalGallery.reorder.useMutation({
    onSuccess: () => {
      setNotice("ছবির ক্রম আপডেট হয়েছে।");
      refresh();
    },
  });
  const remove = trpc.personalGallery.delete.useMutation({
    onSuccess: () => {
      setNotice("ছবি ডিলিট করা হয়েছে।");
      refresh();
    },
  });

  if (!isOwner) return null;

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm(current => ({ ...current, [key]: value }));
  };
  const handleUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!/^image\/(jpeg|png|webp)$/i.test(file.type)) {
      setNotice("JPEG, PNG অথবা WebP ছবি দিন।");
      return;
    }
    try {
      setNotice("ছবি upload হচ্ছে…");
      const base64Data = await toDataUrl(file);
      const stored = await upload.mutateAsync({
        base64Data,
        fileName: file.name,
        contentType: file.type,
        folder: form.folder,
      });
      setForm(current => ({ ...current, imageUrl: stored.url, storageKey: stored.key }));
      setNotice("ছবি প্রস্তুত। এখন নাম, serial ও public status যাচাই করে Save করুন।");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Upload সম্পন্ন হয়নি।");
    }
  };
  const submit = () => {
    const payload = {
      folder: form.folder,
      titleBn: form.titleBn.trim(),
      titleEn: form.titleEn.trim(),
      descriptionBn: form.descriptionBn.trim() || undefined,
      descriptionEn: form.descriptionEn.trim() || undefined,
      imageUrl: form.imageUrl,
      storageKey: form.storageKey,
      isPublic: form.isPublic,
      displayOrder: Number(form.displayOrder),
    };
    if (!payload.imageUrl || !payload.storageKey) {
      setNotice("আগে ছবি upload করুন।");
      return;
    }
    if (form.id) update.mutate({ id: form.id, ...payload });
    else create.mutate(payload);
  };

  const photos = [...(photosQuery.data ?? [])].sort((a, b) => a.displayOrder - b.displayOrder || a.id - b.id);
  const edit = (photo: typeof photos[number]) => {
    setForm({
      id: photo.id,
      folder: photo.folder,
      titleBn: photo.titleBn,
      titleEn: photo.titleEn,
      descriptionBn: photo.descriptionBn ?? "",
      descriptionEn: photo.descriptionEn ?? "",
      imageUrl: photo.imageUrl,
      storageKey: photo.storageKey,
      isPublic: photo.isPublic === 1,
      displayOrder: String(photo.displayOrder),
    });
  };
  const isSaving = create.isPending || update.isPending || upload.isPending;
  const mutationError = create.error ?? update.error ?? reorder.error ?? remove.error;

  return (
    <section id="cms-owner-gallery-manager" className="rounded-2xl border border-emerald-400/30 bg-slate-900 p-5 shadow-xl sm:p-6">
      <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
        <div>
          <p className="text-xs font-black tracking-[0.2em] text-emerald-300">OWNER MEDIA CONTROL</p>
          <h2 className="mt-1 text-xl font-black text-white">নিজস্ব ছবি ও Map Photo ফোল্ডার</h2>
          <p className="mt-1 max-w-3xl text-sm text-slate-300">
            Gallery ছবি Main Page-এর উন্মুক্ত গ্যালারিতে দেখা যাবে। Map Photo-র মধ্যে সবচেয়ে কম ক্রমের প্রকাশ্য ছবিটি Contact পেজের মানচিত্রের পাশে দেখা যাবে।
          </p>
          <p className="mt-2 rounded-lg border border-emerald-400/20 bg-emerald-950/40 px-3 py-2 text-xs leading-5 text-emerald-100">
            <strong>উন্মুক্ত গ্যালারি নিয়ম:</strong> Folder-এ “Gallery” দিন, “Public site-এ প্রকাশ করুন” নির্বাচন করুন এবং ছোট display order আগে রাখুন। Save করার পর public site refresh করে দেখুন।
          </p>
        </div>
        <button type="button" onClick={() => { setForm(blankForm); setNotice(""); }} className="w-full rounded-xl border border-slate-600 px-3 py-2 text-sm font-bold text-white sm:w-auto">
          নতুন ছবি
        </button>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-3 rounded-2xl border border-slate-700 bg-slate-950/60 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="text-sm font-bold text-slate-100">ফোল্ডার
              <select value={form.folder} onChange={event => setField("folder", event.target.value as Folder)} className="mt-1.5 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white">
                <option value="gallery">উন্মুক্ত গ্যালারি (Main Page)</option>
                <option value="map">Map Photo (Contact পেজ)</option>
              </select>
            </label>
            <label className="text-sm font-bold text-slate-100">প্রদর্শনের ক্রম
              <input type="number" min="0" value={form.displayOrder} onChange={event => setField("displayOrder", event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" />
            </label>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="text-sm font-bold text-slate-100">বাংলা নাম
              <input value={form.titleBn} onChange={event => setField("titleBn", event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" />
            </label>
            <label className="text-sm font-bold text-slate-100">English title
              <input value={form.titleEn} onChange={event => setField("titleEn", event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" />
            </label>
          </div>
          <label className="block text-sm font-bold text-slate-100">বাংলা বর্ণনা
            <textarea value={form.descriptionBn} onChange={event => setField("descriptionBn", event.target.value)} className="mt-1.5 min-h-16 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" />
          </label>
          <label className="block text-sm font-bold text-slate-100">English description
            <textarea value={form.descriptionEn} onChange={event => setField("descriptionEn", event.target.value)} className="mt-1.5 min-h-16 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" />
          </label>
          <label className="flex items-center gap-2 text-sm font-bold text-slate-100"><input type="checkbox" checked={form.isPublic} onChange={event => setField("isPublic", event.target.checked)} /> Public site-এ প্রকাশ করুন</label>
          <label className="block rounded-xl border border-dashed border-slate-600 p-3 text-sm font-bold text-slate-100"><ImagePlus className="mb-1 text-emerald-300" size={18} />JPEG, PNG অথবা WebP ছবি
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={event => void handleUpload(event)} className="mt-2 block w-full text-xs" />
          </label>
          {form.imageUrl ? <img src={form.imageUrl} alt="Selected upload preview" className="h-36 w-full rounded-xl object-cover" /> : null}
          <button type="button" disabled={isSaving} onClick={submit} className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-4 py-2.5 font-black text-slate-950 disabled:opacity-50"><Upload size={17} />{form.id ? "পরিবর্তন সংরক্ষণ করুন" : "ছবি সংরক্ষণ করুন"}</button>
          {notice ? <p className="text-sm font-semibold text-emerald-300" aria-live="polite">{notice}</p> : null}
          {mutationError ? <p className="text-sm text-red-300" role="alert">{mutationError.message}</p> : null}
        </div>

        <div className="space-y-3">
          <h3 className="font-black text-white">আপনার ছবি ({photos.length})</h3>
          {photosQuery.isLoading ? <p className="text-slate-300">লোড হচ্ছে…</p> : null}
          {photos.map(photo => (
            <div key={photo.id} className="flex flex-col gap-3 rounded-2xl border border-slate-700 bg-slate-950/50 p-3 sm:flex-row">
              <img src={photo.imageUrl} alt={photo.titleBn} className="h-40 w-full rounded-xl object-cover sm:h-20 sm:w-24" />
              <div className="min-w-0 flex-1">
                <p className="truncate font-black text-white">{photo.folder === "map" ? <MapPinned className="mr-1 inline text-emerald-300" size={14} /> : null}{photo.titleBn}</p>
                <p className="text-xs text-slate-400">{photo.folder === "map" ? "Map Photo" : "Gallery"} · ক্রম {photo.displayOrder} · {photo.isPublic ? "Public" : "Hidden"}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" onClick={() => edit(photo)} className="inline-flex items-center gap-1 rounded-lg bg-slate-700 px-2 py-1 text-xs font-bold text-white"><Pencil size={12} />Edit</button>
                  <button type="button" onClick={() => reorder.mutate({ id: photo.id, displayOrder: Math.max(0, photo.displayOrder - 1) })} className="rounded-lg bg-slate-700 p-1 text-white" aria-label="Move earlier"><ArrowUp size={14} /></button>
                  <button type="button" onClick={() => reorder.mutate({ id: photo.id, displayOrder: photo.displayOrder + 1 })} className="rounded-lg bg-slate-700 p-1 text-white" aria-label="Move later"><ArrowDown size={14} /></button>
                  <button type="button" onClick={() => { if (window.confirm(`আপনি কি নিশ্চিত যে “${photo.titleBn}” ডিলিট করবেন?`)) remove.mutate({ id: photo.id }); }} className="inline-flex items-center gap-1 rounded-lg bg-red-900/80 px-2 py-1 text-xs font-bold text-white"><Trash2 size={12} />Delete</button>
                  <span className="inline-flex items-center gap-1 rounded-lg border border-slate-600 px-2 py-1 text-xs text-slate-200">{photo.isPublic ? <Eye size={12} /> : <EyeOff size={12} />}{photo.isPublic ? "Public" : "Hidden"}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
