import { ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type PhoneLoginDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

/**
 * Legacy compatibility shell. The public portal no longer supports phone-based
 * sign-in and never asks for a phone number, OTP, PIN, or password.
 */
export default function PhoneLoginDialog({ open, onOpenChange }: PhoneLoginDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mb-2 flex h-11 w-11 items-center justify-center rounded-full bg-teal-50 text-teal-700"><ShieldCheck className="h-6 w-6" /></div>
          <DialogTitle>ফোন-ভিত্তিক সাইন-ইন চালু নেই</DialogTitle>
          <DialogDescription className="pt-2 leading-6">নিরাপত্তার জন্য SahajContact ফোন নম্বর, OTP, PIN বা পাসওয়ার্ড সংগ্রহ করে না। সরকারি সেবার জন্য সংশ্লিষ্ট অফিসিয়াল পোর্টাল ব্যবহার করুন।</DialogDescription>
        </DialogHeader>
        <Button type="button" onClick={() => onOpenChange(false)} className="mt-2">বন্ধ করুন</Button>
      </DialogContent>
    </Dialog>
  );
}
