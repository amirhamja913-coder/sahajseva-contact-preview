import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

const gallerySource = readFileSync(new URL("./PremiumPhotoGallery.tsx", import.meta.url), "utf8");

describe("open public photo gallery folder", () => {
  it("keeps the public gallery open by default behind a semantic details control", () => {
    expect(gallerySource).toContain('data-gallery-folder="open-public-gallery"');
    expect(gallerySource).toContain("<details open className=");
    expect(gallerySource).toContain("ফোল্ডার খোলা");
    expect(gallerySource).toContain("এই ফোল্ডারটি শুরুতেই খোলা থাকে");
  });

  it("uses only one folder surface instead of a decorative outer folder tab", () => {
    expect(gallerySource).not.toContain("relative mx-5 h-4 w-52 rounded-t-2xl");
    expect(gallerySource).not.toContain('className="group -mt-px overflow-hidden');
  });

  it("keeps every published record available through one focused image viewer", () => {
    expect(gallerySource).toContain("...(folderPhotosQuery.data ?? []).map");
    expect(gallerySource).toContain("...(legacyPhotosQuery.data ?? []).map");
    expect(gallerySource).toContain("const [activeIndex, setActiveIndex] = useState(0)");
    expect(gallerySource).toContain("One-image viewer");
    expect(gallerySource).toContain("One image at a time public gallery viewer");
    expect(gallerySource).toContain('aria-label={isEn ? "Show previous photo"');
    expect(gallerySource).toContain('aria-label={isEn ? "Show next photo"');
  });

  it("provides a scrollable in-folder list so every published image remains visibly reachable", () => {
    expect(gallerySource).toContain("data-gallery-scroll-list");
    expect(gallerySource).toContain("max-h-64 overflow-y-auto overscroll-contain");
    expect(gallerySource).toContain("সব প্রকাশিত ছবি");
    expect(gallerySource).toContain("scroll করে ছবি দেখুন");
    expect(gallerySource).toContain("cards.map((card, index) => {");
  });

  it("does not render the prior tall multi-card grid", () => {
    expect(gallerySource).not.toContain("grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5");
    expect(gallerySource).not.toContain("cards.slice(0, 2).map");
  });
});
