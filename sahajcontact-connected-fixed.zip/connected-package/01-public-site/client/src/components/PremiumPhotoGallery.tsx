import { useEffect, useMemo, useState } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, Download, FolderOpen, Image as ImageIcon } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

type OpenGalleryCard = {
  key: string;
  source: "folder" | "legacy";
  id: number;
  imageUrl: string;
  titleBn: string;
  titleEn: string;
  descriptionBn?: string | null;
  descriptionEn?: string | null;
};

/**
 * The public gallery keeps the owner-selected gallery folder together with
 * previously published legacy records. It deliberately renders one selected
 * image at a time; every record stays reachable through the scrollable photo list.
 */
export default function OpenPhotoGallery() {
  const { language } = useLanguage();
  const isEn = language === "EN";
  const [activeIndex, setActiveIndex] = useState(0);
  const folderPhotosQuery = trpc.personalGallery.publicPhotos.useQuery(
    { folder: "gallery" },
    { staleTime: 60_000, refetchOnWindowFocus: false },
  );
  const legacyPhotosQuery = trpc.premiumGallery.publicProducts.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const openLegacyFullImage = trpc.premiumGallery.getPublicImageLink.useMutation({
    onSuccess: result => window.open(result.url, "_blank", "noopener,noreferrer"),
  });

  const cards = useMemo<OpenGalleryCard[]>(() => [
    ...(folderPhotosQuery.data ?? []).map(photo => ({
      key: `folder-${photo.id}`,
      source: "folder" as const,
      id: photo.id,
      imageUrl: photo.imageUrl,
      titleBn: photo.titleBn,
      titleEn: photo.titleEn,
      descriptionBn: photo.descriptionBn,
      descriptionEn: photo.descriptionEn,
    })),
    ...(legacyPhotosQuery.data ?? []).map(photo => ({
      key: `published-${photo.id}`,
      source: "legacy" as const,
      id: photo.id,
      imageUrl: photo.previewImageUrl,
      titleBn: photo.titleBn,
      titleEn: photo.titleEn,
      descriptionBn: photo.descriptionBn,
      descriptionEn: photo.descriptionEn,
    })),
  ], [folderPhotosQuery.data, legacyPhotosQuery.data]);

  useEffect(() => {
    setActiveIndex(current => Math.min(current, Math.max(cards.length - 1, 0)));
  }, [cards.length]);

  const title = isEn ? "Open public photo folder" : "উন্মুক্ত ছবি গ্যালারি ফোল্ডার";
  const subtitle = isEn
    ? "This folder stays open. Select any published image from the scrollable list to view it one at a time."
    : "এই ফোল্ডারটি শুরুতেই খোলা থাকে। নিচের scroll তালিকা থেকে যেকোনো প্রকাশিত ছবি বেছে নিয়ে একবারে একটি করে দেখুন।";
  const isLoading = folderPhotosQuery.isLoading || legacyPhotosQuery.isLoading;
  const activeCard = cards[activeIndex];
  const activeTitle = activeCard ? (isEn ? activeCard.titleEn : activeCard.titleBn) : "";
  const activeDescription = activeCard ? (isEn ? activeCard.descriptionEn : activeCard.descriptionBn) : "";

  const moveViewer = (direction: -1 | 1) => {
    if (cards.length < 2) return;
    setActiveIndex(current => (current + direction + cards.length) % cards.length);
  };

  return (
    <section id="open-photo-gallery-content" className="border-t border-[#d9e4dd] bg-[#eef5f0] py-12 sm:py-16" aria-labelledby="open-photo-gallery-title">
      <div className="container">
        <div className="mx-auto max-w-6xl">
          <details open className="group max-h-[calc(100svh-2rem)] overflow-hidden rounded-[1.5rem] border border-[#9ab9ab] bg-white shadow-[0_18px_45px_rgba(13,43,62,0.10)] sm:rounded-[2rem]" data-gallery-folder="open-public-gallery" data-gallery-compact-surface>
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 bg-[#f8fcf8] px-5 py-5 marker:content-none sm:px-8 sm:py-7">
              <div className="flex min-w-0 items-start gap-3 sm:gap-4">
                <span className="mt-1 inline-flex shrink-0 rounded-2xl bg-[#0f766e] p-2.5 text-white shadow-sm"><FolderOpen size={20} aria-hidden="true" /></span>
                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#0f766e]">SahajContact Visual Archive</p>
                  <h2 id="open-photo-gallery-title" className="mt-1 font-serif text-2xl font-black text-[#0d2b3e] sm:text-3xl">{title}</h2>
                  <p className="mt-2 max-w-3xl leading-7 text-slate-600">{subtitle}</p>
                </div>
              </div>
              <span className="flex shrink-0 items-center gap-2 rounded-full border border-[#b9cec6] bg-[#e5eee9] px-3 py-2 text-xs font-black text-[#0f766e] sm:px-4">
                <span className="group-open:hidden">{isEn ? "Show viewer" : "ছবি দেখুন"}</span>
                <span className="hidden group-open:inline">{isEn ? "Folder open" : "ফোল্ডার খোলা"}</span>
                <ChevronDown size={18} className="transition-transform duration-200 group-open:rotate-180" aria-hidden="true" />
              </span>
            </summary>

            <div className="max-h-[calc(100svh-7rem)] overflow-y-auto overscroll-contain border-t border-[#d9e4dd] bg-[#fcfdfb] px-4 py-5 sm:px-8 sm:py-8">
              {!isLoading ? <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dce9df] bg-white px-4 py-3 text-sm font-semibold text-slate-600"><p>{isEn ? `Public folder summary: ${cards.length} published photo${cards.length === 1 ? "" : "s"}. Scroll through the complete list and select any photo to view it.` : `পাবলিক গ্যালারি সারসংক্ষেপ: প্রকাশিত ${cards.length}টি ছবি আছে। সম্পূর্ণ তালিকায় scroll করে যেকোনো ছবি বেছে দেখুন।`}</p><span className="rounded-full bg-[#e5eee9] px-3 py-1.5 text-xs font-black text-[#0f766e]">{isEn ? "One-image viewer" : "এক ছবির viewer"}</span></div> : null}
              {isLoading ? <p className="py-8 text-slate-600">{isEn ? "Loading gallery…" : "গ্যালারি লোড হচ্ছে…"}</p> : null}
              {!isLoading && cards.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-[#b9cec6] bg-white/70 p-9 text-center text-slate-600">
                  <ImageIcon className="mx-auto mb-3 text-[#0f766e]" size={34} />
                  <p className="font-bold">{isEn ? "The owner has not published a photo yet." : "এখনও কোনো ছবি প্রকাশ করা হয়নি।"}</p>
                </div>
              ) : null}

              {!isLoading && activeCard ? (
                <div className="overflow-hidden rounded-[1.35rem] border border-[#c8dbd0] bg-[#092f38] shadow-[0_16px_42px_rgba(13,43,62,0.16)] sm:rounded-[1.75rem]" aria-label={isEn ? "One image at a time public gallery viewer" : "একবারে একটি ছবির উন্মুক্ত গ্যালারি viewer"}>
                  <div className="relative flex h-[min(40svh,22rem)] min-h-0 items-center justify-center bg-[radial-gradient(circle_at_center,_#1e5660_0%,_#092f38_70%)] sm:h-[min(44svh,26rem)]">
                    <img src={activeCard.imageUrl} alt={activeTitle} className="h-full w-full object-contain" loading="eager" />
                    {cards.length > 1 ? <>
                      <button type="button" onClick={() => moveViewer(-1)} className="absolute left-3 inline-flex min-h-11 min-w-11 items-center justify-center rounded-full border border-white/45 bg-[#092f38]/80 text-white shadow-lg transition hover:bg-[#0f766e] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white active:scale-95 sm:left-5" aria-label={isEn ? "Show previous photo" : "আগের ছবি দেখুন"}><ChevronLeft size={24} /></button>
                      <button type="button" onClick={() => moveViewer(1)} className="absolute right-3 inline-flex min-h-11 min-w-11 items-center justify-center rounded-full border border-white/45 bg-[#092f38]/80 text-white shadow-lg transition hover:bg-[#0f766e] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white active:scale-95 sm:right-5" aria-label={isEn ? "Show next photo" : "পরের ছবি দেখুন"}><ChevronRight size={24} /></button>
                    </> : null}
                    <span className="absolute right-3 top-3 rounded-full bg-black/65 px-3 py-1.5 text-xs font-black text-white sm:right-5 sm:top-5">{isEn ? `Photo ${activeIndex + 1} of ${cards.length}` : `ছবি ${activeIndex + 1} / ${cards.length}`}</span>
                  </div>
                  <div className="grid gap-4 bg-white p-5 sm:grid-cols-[1fr_auto] sm:items-end sm:p-7">
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.16em] text-[#0f766e]">{isEn ? `Photo ${String(activeIndex + 1).padStart(2, "0")}` : `ছবি ${String(activeIndex + 1).padStart(2, "০")}`}</p>
                      <h3 className="mt-2 text-xl font-black text-[#0d2b3e] sm:text-2xl">{activeTitle}</h3>
                      <p className="mt-2 max-w-3xl leading-7 text-slate-600">{activeDescription || (isEn ? "No public summary was provided for this published photo." : "এই প্রকাশিত ছবির জন্য কোনো পাবলিক সারসংক্ষেপ দেওয়া হয়নি।")}</p>
                    </div>
                    {activeCard.source === "folder" ? (
                      <a href={activeCard.imageUrl} download className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#0f766e] px-4 py-3 text-sm font-black text-white transition hover:bg-[#0b635d] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0f766e] active:scale-95"><Download size={17} /> {isEn ? "Download photo" : "ছবি ডাউনলোড করুন"}</a>
                    ) : (
                      <button type="button" disabled={openLegacyFullImage.isPending} onClick={() => openLegacyFullImage.mutate({ productId: activeCard.id })} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#0f766e] px-4 py-3 text-sm font-black text-white transition hover:bg-[#0b635d] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0f766e] active:scale-95 disabled:cursor-wait disabled:opacity-60"><Download size={17} /> {openLegacyFullImage.isPending ? (isEn ? "Opening…" : "খুলছে…") : (isEn ? "Open full photo" : "পূর্ণ ছবি খুলুন")}</button>
                    )}
                    {activeCard.source === "legacy" && openLegacyFullImage.error ? <p className="text-xs font-semibold text-red-700 sm:col-span-2">{openLegacyFullImage.error.message}</p> : null}
                  </div>
                </div>
              ) : null}

              {!isLoading && cards.length > 1 ? (
                <section className="mt-5 overflow-hidden rounded-[1.35rem] border border-[#c8dbd0] bg-white" aria-labelledby="gallery-scroll-list-title">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#d9e4dd] bg-[#f8fcf8] px-4 py-3 sm:px-5">
                    <div>
                      <h3 id="gallery-scroll-list-title" className="font-black text-[#0d2b3e]">{isEn ? "All published photos" : "সব প্রকাশিত ছবি"}</h3>
                      <p className="mt-0.5 text-xs font-semibold text-slate-600">{isEn ? "Scroll to browse, then select a photo to open it above." : "scroll করে ছবি দেখুন, তারপর পছন্দের ছবিটি নির্বাচন করুন।"}</p>
                    </div>
                    <span className="rounded-full bg-[#e5eee9] px-3 py-1.5 text-xs font-black text-[#0f766e]">{isEn ? `${cards.length} photos` : `${cards.length}টি ছবি`}</span>
                  </div>
                  <div className="max-h-64 overflow-y-auto overscroll-contain p-3 sm:p-4" data-gallery-scroll-list aria-label={isEn ? "Scrollable list of all published photos" : "সব প্রকাশিত ছবির scrollable তালিকা"}>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {cards.map((card, index) => {
                        const cardTitle = isEn ? card.titleEn : card.titleBn;
                        const isActive = index === activeIndex;
                        return <button key={card.key} type="button" onClick={() => setActiveIndex(index)} className={`flex min-h-24 w-full items-center gap-3 rounded-2xl border p-2.5 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0f766e] active:scale-[0.99] ${isActive ? "border-[#0f766e] bg-[#e9f7f1] shadow-sm" : "border-[#d9e4dd] bg-white hover:border-[#75aa99] hover:bg-[#f8fcf8]"}`} aria-label={isEn ? `Show photo ${index + 1}: ${card.titleEn}` : `ছবি ${index + 1} দেখুন: ${card.titleBn}`} aria-pressed={isActive}>
                          <img src={card.imageUrl} alt="" className="h-20 w-24 shrink-0 rounded-xl border border-[#c8dbd0] bg-[#eef5f0] object-cover" loading="lazy" decoding="async" />
                          <span className="min-w-0">
                            <span className="block text-xs font-black tracking-wide text-[#0f766e]">{isEn ? `PHOTO ${String(index + 1).padStart(2, "0")}` : `ছবি ${String(index + 1).padStart(2, "০")}`}</span>
                            <span className="mt-1 block line-clamp-2 font-black leading-5 text-[#0d2b3e]">{cardTitle || (isEn ? "Published photo" : "প্রকাশিত ছবি")}</span>
                            <span className="mt-1 block text-xs font-semibold text-slate-500">{isActive ? (isEn ? "Showing above" : "উপরে দেখা যাচ্ছে") : (isEn ? "Select to view" : "দেখতে নির্বাচন করুন")}</span>
                          </span>
                        </button>;
                      })}
                    </div>
                  </div>
                </section>
              ) : null}
            </div>
          </details>
        </div>
      </div>
    </section>
  );
}
