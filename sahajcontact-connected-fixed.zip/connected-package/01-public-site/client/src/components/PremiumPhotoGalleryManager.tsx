import { ChangeEvent, useState } from "react";
import { Eye, EyeOff, ImagePlus, Pencil, Trash2, Upload } from "lucide-react";
import { trpc } from "@/lib/trpc";

type FormState = {
  id: number | null;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  previewImageUrl: string;
  fullImageKey: string;
  isPublished: boolean;
};

const blankForm: FormState = { id: null, titleBn: "", titleEn: "", descriptionBn: "", descriptionEn: "", previewImageUrl: "", fullImageKey: "", isPublished: false };

function toDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি"));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });
}

export function PremiumPhotoGalleryManager({ isOwner }: { isOwner: boolean }) {
  const utils = trpc.useUtils();
  const productsQuery = trpc.premiumGallery.ownerProducts.useQuery(undefined, { enabled: isOwner });
  const [form, setForm] = useState<FormState>(blankForm);
  const [notice, setNotice] = useState("");
  const upload = trpc.premiumGallery.uploadAsset.useMutation();
  const create = trpc.premiumGallery.create.useMutation({ onSuccess: () => { setNotice("ছবি সংরক্ষণ হয়েছে।"); setForm(blankForm); void utils.premiumGallery.ownerProducts.invalidate(); void utils.premiumGallery.publicProducts.invalidate(); } });
  const update = trpc.premiumGallery.update.useMutation({ onSuccess: () => { setNotice("ছবির তথ্য আপডেট হয়েছে।"); setForm(blankForm); void utils.premiumGallery.ownerProducts.invalidate(); void utils.premiumGallery.publicProducts.invalidate(); } });
  const remove = trpc.premiumGallery.delete.useMutation({ onSuccess: () => { setNotice("ছবির তথ্য ডিলিট করা হয়েছে।"); void utils.premiumGallery.ownerProducts.invalidate(); void utils.premiumGallery.publicProducts.invalidate(); } });

  if (!isOwner) return null;

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm(current => ({ ...current, [key]: value }));
  const handleUpload = async (event: ChangeEvent<HTMLInputElement>, kind: "preview" | "original") => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!/^image\/(jpeg|png|webp)$/i.test(file.type)) { setNotice("JPEG, PNG অথবা WebP ছবি দিন।"); return; }
    try {
      setNotice(kind === "preview" ? "গ্যালারির ছবি upload হচ্ছে…" : "পূর্ণমানের ছবি upload হচ্ছে…");
      const base64Data = await toDataUrl(file);
      const stored = await upload.mutateAsync({ base64Data, fileName: file.name, contentType: file.type, kind });
      if (kind === "preview") setField("previewImageUrl", stored.url);
      else setField("fullImageKey", stored.key);
      setNotice("ছবি প্রস্তুত।");
    } catch (error) { setNotice(error instanceof Error ? error.message : "Upload সম্পন্ন হয়নি।"); }
  };

  const submit = () => {
    const payload = { titleBn: form.titleBn.trim(), titleEn: form.titleEn.trim(), descriptionBn: form.descriptionBn.trim() || undefined, descriptionEn: form.descriptionEn.trim() || undefined, previewImageUrl: form.previewImageUrl, fullImageKey: form.fullImageKey, priceBdt: 0, watermarkText: "Public Gallery", isPublished: form.isPublished };
    if (!payload.previewImageUrl || !payload.fullImageKey) { setNotice("গ্যালারির ছবি এবং পূর্ণমানের ছবি—দুইটি ফাইল দিন।"); return; }
    if (form.id) update.mutate({ id: form.id, ...payload }); else create.mutate(payload);
  };

  return <section className="rounded-2xl border border-emerald-400/30 bg-slate-900 p-5 shadow-xl sm:p-6">
    <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-start"><div><p className="text-xs font-black tracking-[0.2em] text-emerald-300">PUBLIC PHOTO GALLERY</p><h2 className="mt-1 text-xl font-black text-white">উন্মুক্ত ছবি গ্যালারি পরিচালনা</h2><p className="mt-1 max-w-3xl text-sm text-slate-300">প্রকাশিত প্রতিটি ছবি সবার জন্য উন্মুক্ত থাকবে। মূল্য, watermark বা কেনার ধাপ দেখানো হবে না।</p></div><button type="button" onClick={() => { setForm(blankForm); setNotice(""); }} className="rounded-xl border border-slate-600 px-3 py-2 text-sm font-bold text-white">নতুন ছবি</button></div>
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="space-y-3 rounded-2xl border border-slate-700 bg-slate-950/60 p-4">
        <div className="grid gap-3 sm:grid-cols-2"><label className="text-sm font-bold text-slate-100">বাংলা নাম<input value={form.titleBn} onChange={event => setField("titleBn", event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label><label className="text-sm font-bold text-slate-100">English title<input value={form.titleEn} onChange={event => setField("titleEn", event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label></div>
        <label className="block text-sm font-bold text-slate-100">বাংলা বর্ণনা<textarea value={form.descriptionBn} onChange={event => setField("descriptionBn", event.target.value)} className="mt-1.5 min-h-20 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
        <label className="block text-sm font-bold text-slate-100">English description<textarea value={form.descriptionEn} onChange={event => setField("descriptionEn", event.target.value)} className="mt-1.5 min-h-20 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
        <label className="flex items-center gap-2 text-sm font-bold text-slate-100"><input type="checkbox" checked={form.isPublished} onChange={event => setField("isPublished", event.target.checked)} /> Public gallery-তে প্রকাশ করুন</label>
        <div className="grid gap-3 sm:grid-cols-2"><label className="rounded-xl border border-dashed border-slate-600 p-3 text-sm font-bold text-slate-100"><ImagePlus className="mb-1 text-emerald-300" size={18} />গ্যালারির ছবি<input type="file" accept="image/jpeg,image/png,image/webp" onChange={event => void handleUpload(event, "preview")} className="mt-2 block w-full text-xs" /></label><label className="rounded-xl border border-dashed border-slate-600 p-3 text-sm font-bold text-slate-100"><ImagePlus className="mb-1 text-emerald-300" size={18} />পূর্ণমানের ছবি<input type="file" accept="image/jpeg,image/png,image/webp" onChange={event => void handleUpload(event, "original")} className="mt-2 block w-full text-xs" /></label></div>
        {form.previewImageUrl ? <img src={form.previewImageUrl} alt="Preview" className="h-32 w-full rounded-xl object-cover" /> : null}
        <button type="button" disabled={create.isPending || update.isPending || upload.isPending} onClick={submit} className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-4 py-2.5 font-black text-slate-950 disabled:opacity-50"><Upload size={17} />{form.id ? "পরিবর্তন সংরক্ষণ করুন" : "ছবি সংরক্ষণ করুন"}</button>
        {notice ? <p className="text-sm font-semibold text-emerald-300">{notice}</p> : null}{create.error || update.error ? <p className="text-sm text-red-300">{create.error?.message ?? update.error?.message}</p> : null}
      </div>
      <div className="space-y-3"><h3 className="font-black text-white">আপনার গ্যালারির ছবি ({productsQuery.data?.length ?? 0})</h3>{productsQuery.isLoading ? <p className="text-slate-300">লোড হচ্ছে…</p> : null}{productsQuery.data?.map(product => <div key={product.id} className="flex gap-3 rounded-2xl border border-slate-700 bg-slate-950/50 p-3"><img src={product.previewImageUrl} alt={product.titleBn} className="h-20 w-24 rounded-xl object-cover" /><div className="min-w-0 flex-1"><p className="truncate font-black text-white">{product.titleBn}</p><p className="text-xs text-slate-400">{product.isPublished ? "Public" : "Hidden"}</p><div className="mt-2 flex flex-wrap gap-2"><button type="button" onClick={() => setForm({ id: product.id, titleBn: product.titleBn, titleEn: product.titleEn, descriptionBn: product.descriptionBn ?? "", descriptionEn: product.descriptionEn ?? "", previewImageUrl: product.previewImageUrl, fullImageKey: product.fullImageKey, isPublished: product.isPublished === 1 })} className="inline-flex items-center gap-1 rounded-lg bg-slate-700 px-2 py-1 text-xs font-bold text-white"><Pencil size={12} />Edit</button><button type="button" onClick={() => { if (window.confirm(`আপনি কি নিশ্চিত যে “${product.titleBn}” ডিলিট করবেন?`)) remove.mutate({ id: product.id }); }} className="inline-flex items-center gap-1 rounded-lg bg-red-900/80 px-2 py-1 text-xs font-bold text-white"><Trash2 size={12} />Delete</button><span className="inline-flex items-center gap-1 rounded-lg border border-slate-600 px-2 py-1 text-xs text-slate-200">{product.isPublished ? <Eye size={12} /> : <EyeOff size={12} />}{product.isPublished ? "Public" : "Hidden"}</span></div></div></div>)}</div>
    </div>
  </section>;
}
