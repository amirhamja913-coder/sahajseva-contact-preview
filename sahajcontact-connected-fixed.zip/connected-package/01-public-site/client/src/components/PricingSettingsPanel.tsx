import { AlertTriangle, LockKeyhole, ShieldCheck } from "lucide-react";

/**
 * Kept mounted in the owner dashboard so the former commercial-control location
 * remains discoverable, but deliberately contains no price, order, payment, or
 * completion action. Public payment is not configured for this portal.
 */
export function PricingSettingsPanel({ isOwner }: { isOwner: boolean }) {
  if (!isOwner) return null;

  return (
    <section className="rounded-2xl border border-amber-400/35 bg-slate-900 p-5 shadow-xl" aria-labelledby="commercial-status-heading">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="mb-2 flex items-center gap-2 text-amber-200"><AlertTriangle className="h-5 w-5" /><span className="text-xs font-bold uppercase tracking-wider">নিরাপদ বাণিজ্যিক অবস্থা</span></div>
          <h2 id="commercial-status-heading" className="text-xl font-bold text-white">মূল্য, অর্ডার ও payment নিয়ন্ত্রণ বন্ধ</h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-300">SahajContact এখন তথ্য, Gallery এবং review-first institutional inquiry portal হিসেবে চলছে। এখানে কোনো public rate card, service order, payment collection, receipt বা payment completion চালু নেই।</p>
        </div>
        <div className="inline-flex w-fit items-center gap-2 rounded-xl bg-amber-950/60 px-3 py-2 text-xs font-semibold text-amber-100"><LockKeyhole className="h-4 w-4" /> Inactive by policy</div>
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-3">
        <article className="rounded-xl border border-slate-700 bg-slate-950/50 p-4"><ShieldCheck className="mb-2 h-5 w-5 text-emerald-300" /><h3 className="font-bold text-white">Public safety</h3><p className="mt-1 text-sm leading-6 text-slate-300">কোনো visitor-এর OTP, PIN, password, payment number বা transaction ID নেওয়া হয় না।</p></article>
        <article className="rounded-xl border border-slate-700 bg-slate-950/50 p-4"><ShieldCheck className="mb-2 h-5 w-5 text-emerald-300" /><h3 className="font-bold text-white">Institutional review</h3><p className="mt-1 text-sm leading-6 text-slate-300">NGO, sponsor ও বিজ্ঞাপনদাতার আগ্রহ কেবল review-first inquiry হিসেবে বিবেচিত হয়; এটি approval বা public listing নয়।</p></article>
        <article className="rounded-xl border border-slate-700 bg-slate-950/50 p-4"><ShieldCheck className="mb-2 h-5 w-5 text-emerald-300" /><h3 className="font-bold text-white">Future prerequisite</h3><p className="mt-1 text-sm leading-6 text-slate-300">ভবিষ্যতে কোনো paid feature বিবেচনার আগে verified business setup, written policy, privacy review এবং owner approval লাগবে।</p></article>
      </div>
    </section>
  );
}
