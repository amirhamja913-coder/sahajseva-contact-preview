import { Activity, BarChart3, Clock3, Globe2, MousePointerClick, UsersRound } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage, type SiteLanguage } from "@/contexts/LanguageContext";

function formatMetric(value: number) {
  return new Intl.NumberFormat("bn-BD").format(value);
}

function formatUpdatedAt(value: Date, language: SiteLanguage) {
  return new Intl.DateTimeFormat(language === "BN" ? "bn-BD" : "en-GB", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Dhaka",
  }).format(value);
}

export default function PublicSeoSnapshot() {
  const { language } = useLanguage();
  const { data, isLoading } = trpc.adminAnalytics.getPublicSeoSummary.useQuery(undefined, {
    staleTime: 10 * 60 * 1000,
  });

  const isBn = language === "BN";
  if (isLoading) return null;

  if (!data || data.availability === "unavailable" || !data.metrics) {
    return (
      <section id="public-seo-report" className="public-seo-snapshot" aria-labelledby="public-seo-snapshot-title">
        <div className="container">
          <div className="public-seo-snapshot__frame">
            <div className="public-seo-snapshot__intro">
              <span className="public-seo-snapshot__eyebrow"><Activity size={15} aria-hidden="true" /> {isBn ? "সাইটের স্বচ্ছতা" : "Site transparency"}</span>
              <h2 id="public-seo-snapshot-title">{isBn ? "স্বয়ংক্রিয় SEO ও GA4 রিপোর্ট" : "Automatic SEO & GA4 report"}</h2>
              <p>{isBn ? "নির্ধারিত স্বয়ংক্রিয় আপডেটের পর GA4-এর সংরক্ষিত সমষ্টিগত তথ্য এখানে প্রকাশ করা হবে। কোনো ব্যক্তিগত তথ্য, অবস্থান বা পরিচয় প্রকাশ করা হয় না।" : "Stored aggregate GA4 data will appear here after a scheduled automatic update. No personal, location, or identifying data is shown."}</p>
            </div>
            <div className="public-seo-snapshot__freshness" role="status" aria-live="polite">
              <Clock3 size={16} aria-hidden="true" />
              <span>{isBn ? "প্রথম স্বয়ংক্রিয় SEO update-এর অপেক্ষায় — কোনো অনুমিত সংখ্যা দেখানো হচ্ছে না।" : "Awaiting the first automatic SEO update — no estimated figures are shown."}</span>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const status = data.freshness === "current"
    ? (isBn ? "সর্বশেষ স্বয়ংক্রিয় আপডেট" : "Latest automatic update")
    : (isBn ? "সর্বশেষ তথ্য—নতুন আপডেট অপেক্ষমান" : "Latest data — refresh pending");

  const metrics = [
    { icon: BarChart3, value: data.metrics.pageViewsLast30Days, label: isBn ? "গত ৩০ দিনের পেজ ভিউ" : "Page views · last 30 days" },
    { icon: Activity, value: data.metrics.sessionsLast7Days, label: isBn ? "গত ৭ দিনের সেশন" : "Sessions · last 7 days" },
    { icon: UsersRound, value: data.metrics.activeUsersLast7Days, label: isBn ? "গত ৭ দিনের সক্রিয় ব্যবহারকারী" : "Active users · last 7 days" },
    { icon: MousePointerClick, value: data.metrics.totalEventsLast30Days, label: isBn ? "গত ৩০ দিনের ইভেন্ট" : "Events · last 30 days" },
  ];

  return (
    <section id="public-seo-report" className="public-seo-snapshot" aria-labelledby="public-seo-snapshot-title">
      <div className="container">
        <div className="public-seo-snapshot__frame">
          <div className="public-seo-snapshot__intro">
            <span className="public-seo-snapshot__eyebrow"><Activity size={15} aria-hidden="true" /> {isBn ? "সাইটের স্বচ্ছতা" : "Site transparency"}</span>
            <h2 id="public-seo-snapshot-title">{isBn ? "স্বয়ংক্রিয় SEO ও GA4 রিপোর্ট" : "Automatic SEO & GA4 report"}</h2>
            <p>{isBn ? "এটি নির্ধারিত স্বয়ংক্রিয় আপডেটে GA4 থেকে সংরক্ষিত সমষ্টিগত তথ্য। কোনো ব্যক্তিগত তথ্য, অবস্থান বা পরিচয় প্রকাশ করা হয় না।" : "This is a stored, aggregate GA4 snapshot from a scheduled automatic update. No personal, location, or identifying data is shown."}</p>
          </div>
          <dl className="public-seo-snapshot__metrics">
            {metrics.map(({ icon: Icon, value, label }) => (
              <div key={label} className="public-seo-snapshot__metric">
                <dt><Icon size={17} aria-hidden="true" /> {label}</dt>
                <dd>{formatMetric(value)}</dd>
              </div>
            ))}
          </dl>
          {data.metrics.topCountries.length > 0 ? (
            <div className="mt-5 rounded-2xl border border-[var(--line)] bg-white/70 p-4 text-left">
              <div className="flex items-center gap-2 text-sm font-semibold text-[var(--ink)]">
                <Globe2 size={17} aria-hidden="true" />
                <span>{isBn ? "সক্রিয় ব্যবহারকারী অনুযায়ী শীর্ষ দেশ · গত ৩০ দিন" : "Top countries by active users · last 30 days"}</span>
              </div>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3" aria-label={isBn ? "গত ৩০ দিনের শীর্ষ দেশসমূহ" : "Top countries in the last 30 days"}>
                {data.metrics.topCountries.map((country) => (
                  <li key={country.country} className="rounded-xl bg-[var(--paper-deep)] px-3 py-2 text-sm text-[var(--ink)]">
                    <strong className="block">{country.country}</strong>
                    <span className="text-[var(--ink-soft)]">
                      {formatMetric(country.activeUsers)} {isBn ? "সক্রিয় ব্যবহারকারী" : "active users"} · {formatMetric(country.sessions)} {isBn ? "সেশন" : "sessions"}
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-xs leading-5 text-[var(--ink-soft)]">
                {isBn
                  ? "এটি কেবল নির্ধারিত স্বয়ংক্রিয় GA4 aggregate snapshot। পেজভিত্তিক, traffic source, নতুন ব্যবহারকারী, engagement, conversion বা lead-এর তথ্য এই daily public summary-তে সংরক্ষিত নেই।"
                  : "This is only a scheduled automatic GA4 aggregate snapshot. Page-level, traffic-source, new-user, engagement, conversion, and lead data are not stored in this daily public summary."}
              </p>
            </div>
          ) : null}
          <div className="public-seo-snapshot__freshness">
            <Clock3 size={16} aria-hidden="true" />
            <span>{status}</span>
            <time dateTime={data.updatedAt.toISOString()}>{formatUpdatedAt(data.updatedAt, language)}</time>
          </div>
        </div>
      </div>
    </section>
  );
}
