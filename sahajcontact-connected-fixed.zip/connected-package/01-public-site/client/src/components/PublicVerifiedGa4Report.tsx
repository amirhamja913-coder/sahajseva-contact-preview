import { Activity, BadgeCheck, BarChart3, Clock3, Globe2, UsersRound } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

function formatMetric(value: number, isEnglish: boolean) {
  return new Intl.NumberFormat(isEnglish ? "en-US" : "bn-BD").format(value);
}

export default function PublicVerifiedGa4Report() {
  const { language } = useLanguage();
  const isEnglish = language === "EN";
  const manualReportQuery = trpc.adminAnalytics.getPublicVerifiedManualGa4Report.useQuery(undefined, { staleTime: 10 * 60 * 1000 });
  const report = manualReportQuery.data?.report;
  if (!report) return null;

  const metrics = [
    { icon: UsersRound, value: report.activeUsersLast7Days, label: isEnglish ? "Active users · last 7 days" : "সক্রিয় ব্যবহারকারী · গত ৭ দিন" },
    { icon: Activity, value: report.sessionsLast7Days, label: isEnglish ? "Sessions · last 7 days" : "সেশন · গত ৭ দিন" },
    { icon: BarChart3, value: report.pageViewsLast30Days, label: isEnglish ? "Page views · last 30 days" : "পেজ ভিউ · গত ৩০ দিন" },
    { icon: Globe2, value: report.totalEventsLast30Days, label: isEnglish ? "Events · last 30 days" : "ইভেন্ট · গত ৩০ দিন" },
  ];

  return (
    <section className="bg-[#f5f1e7] px-4 py-10 sm:py-14" aria-labelledby="public-manual-ga4-title">
      <div className="container max-w-6xl rounded-3xl border border-violet-800/15 bg-white p-5 shadow-[0_18px_60px_rgba(67,56,202,0.08)] sm:p-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-violet-100 px-3 py-1 text-xs font-extrabold text-violet-800"><BadgeCheck className="h-4 w-4" />{isEnglish ? "Owner-approved manual update" : "Owner-approved ম্যানুয়াল আপডেট"}</span>
            <h2 id="public-manual-ga4-title" className="mt-3 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl">{isEnglish ? "Verified live GA4 report" : "যাচাইকৃত লাইভ GA4 রিপোর্ট"}</h2>
            <p className="mt-2 text-sm leading-6 text-slate-600">{isEnglish ? "This is a separate owner-approved manual capture of aggregate GA4 data. It is not an automatic daily snapshot and does not represent the scheduled refresh status." : "এটি GA4-এর সামগ্রিক ডাটার আলাদা owner-approved manual capture। এটি automatic daily snapshot নয় এবং scheduled refresh-এর অবস্থা বোঝায় না।"}</p>
          </div>
          <div className="inline-flex shrink-0 items-center gap-2 rounded-xl border border-violet-200 bg-violet-50 px-3 py-2 text-xs font-bold text-violet-800"><Clock3 className="h-4 w-4" />{new Date(report.updatedAt).toLocaleString(isEnglish ? "en-GB" : "bn-BD", { timeZone: "Asia/Dhaka" })}</div>
        </div>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {metrics.map(({ icon: Icon, value, label }) => <div key={label} className="rounded-2xl border border-violet-100 bg-violet-50/40 p-4"><Icon className="h-5 w-5 text-violet-600" /><p className="mt-4 text-2xl font-black text-slate-900">{formatMetric(value, isEnglish)}</p><p className="mt-1 text-xs font-semibold leading-5 text-slate-600">{label}</p></div>)}
        </div>
        {report.topCountries.length > 0 && <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4"><p className="text-sm font-bold text-slate-800">{isEnglish ? "Top countries by active users" : "সক্রিয় ব্যবহারকারী অনুযায়ী শীর্ষ দেশ"}</p><div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">{report.topCountries.map((country) => <div key={country.country} className="rounded-xl border border-slate-200 bg-white px-3 py-2"><p className="truncate text-xs font-bold text-slate-800">{country.country}</p><p className="mt-1 text-xs text-slate-600">{formatMetric(country.activeUsers, isEnglish)} {isEnglish ? "users" : "ব্যবহারকারী"}</p><p className="text-[11px] text-slate-500">{formatMetric(country.sessions, isEnglish)} {isEnglish ? "sessions" : "সেশন"}</p></div>)}</div></div>}
      </div>
    </section>
  );
}
