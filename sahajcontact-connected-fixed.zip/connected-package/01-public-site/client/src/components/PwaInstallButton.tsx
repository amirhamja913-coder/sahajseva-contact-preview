import { Download, Share2, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const INSTALL_DISMISSAL_KEY = "sahajseva-pwa-install-dismissed-until";
const ADMIN_INSTALL_DISMISSAL_KEY = "sahajseva-admin-pwa-install-dismissed-until";

const isStandaloneDisplay = () =>
  window.matchMedia("(display-mode: standalone)").matches ||
  ("standalone" in navigator && Boolean((navigator as Navigator & { standalone?: boolean }).standalone));

const isIosDevice = () => /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !("MSStream" in window);
const isAndroidDevice = () => /android/i.test(window.navigator.userAgent);

const hasRecentInstallDismissal = (storageKey: string) => {
  try {
    return window.sessionStorage.getItem(storageKey) === "dismissed";
  } catch {
    return false;
  }
};

const rememberInstallDismissal = (storageKey: string) => {
  try {
    // A visitor may close the reminder during this visit, but it returns with
    // the next browser session instead of disappearing for weeks after a tap.
    window.sessionStorage.setItem(storageKey, "dismissed");
  } catch {
    // Private browsing or restricted storage should never block the install path.
  }
};

interface PwaInstallButtonProps {
  appName?: string;
  bannerTitle?: string;
  bannerDescription?: string;
  helpTitle?: string;
}

export default function PwaInstallButton({
  appName = "সহজসেবা",
  bannerTitle,
  bannerDescription,
  helpTitle,
}: PwaInstallButtonProps) {
  const { language } = useLanguage();
  const isEn = language === "EN";

  const resolvedAppName = appName.includes("অ্যাডমিন") || appName.includes("Admin")
    ? (isEn ? "SahajContact Admin" : "অ্যাডমিন ড্যাশবোর্ড")
    : (isEn ? "SahajContact" : "সহজসেবা");

  const resolvedBannerTitle = bannerTitle || (isEn ? "Keep SahajContact with you" : "সহজসেবা সঙ্গে রাখুন");
  const resolvedBannerDescription = bannerDescription || (isEn ? "Install once to quickly access citizen services from your home screen." : "একবার ইনস্টল করলে হোমস্ক্রিন থেকে দ্রুত নাগরিক সেবা খুঁজে পাবেন।");
  const resolvedHelpTitle = helpTitle || (isEn ? "Add SahajContact to Home Screen" : "হোম স্ক্রিনে সহজসেবা নিন");

  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isIos, setIsIos] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [showInstallHelp, setShowInstallHelp] = useState(false);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const isAdminApp = appName.includes("অ্যাডমিন") || appName.includes("Admin");
  const dismissalKey = isAdminApp ? ADMIN_INSTALL_DISMISSAL_KEY : INSTALL_DISMISSAL_KEY;

  useEffect(() => {
    const standalone = isStandaloneDisplay();
    const ios = isIosDevice();
    const android = isAndroidDevice();
    const recentlyDismissed = hasRecentInstallDismissal(dismissalKey);

    setIsStandalone(standalone);
    setIsIos(ios);
    setIsAndroid(android);

    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
      if (!recentlyDismissed) setShowInstallBanner(true);
    };
    const handleAppInstalled = () => {
      setInstallPrompt(null);
      setIsStandalone(true);
      setShowInstallBanner(false);
      setShowInstallHelp(false);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    let bannerTimer: number | undefined;
    if (!standalone && !recentlyDismissed) {
      bannerTimer = window.setTimeout(() => setShowInstallBanner(true), 900);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
      if (bannerTimer) window.clearTimeout(bannerTimer);
    };
  }, [dismissalKey]);

  const canInstall = !isStandalone;

  const handleInstall = async () => {
    if (installPrompt) {
      try {
        await installPrompt.prompt();
        const choice = await installPrompt.userChoice;
        setInstallPrompt(null);
        setShowInstallBanner(false);
        if (choice.outcome === "dismissed") {
          rememberInstallDismissal(dismissalKey);
        }
        return;
      } catch {
        setInstallPrompt(null);
      }
    }

    setShowInstallHelp(true);
  };

  const dismissInstallBanner = () => {
    rememberInstallDismissal(dismissalKey);
    setShowInstallBanner(false);
  };

  return (
    <>
      {canInstall && (
        <button type="button" className="button button-install" onClick={handleInstall}>
          <Download size={16} aria-hidden="true" />
          {installPrompt ? (isEn ? `Install ${resolvedAppName}` : `${resolvedAppName} ইনস্টল করুন`) : (isEn ? "Add to Home Screen" : "হোম স্ক্রিনে নিন")}
        </button>
      )}

      {showInstallBanner && canInstall && (
        <aside className="pwa-install-banner" role="region" aria-label={`${resolvedAppName} app install`}>
          <div className="pwa-install-banner-copy">
            <strong>{resolvedBannerTitle}</strong>
            <span>{resolvedBannerDescription}</span>
          </div>
          <button type="button" className="button button-primary pwa-install-banner-action" onClick={handleInstall}>
            <Download size={15} aria-hidden="true" />
            {isEn ? "Install" : "ইনস্টল করুন"}
          </button>
          <button type="button" className="pwa-install-banner-close" onClick={dismissInstallBanner} aria-label={isEn ? "Dismiss install reminder" : "ইনস্টল বার্তা পরে দেখান"}>
            <X size={17} aria-hidden="true" />
          </button>
        </aside>
      )}

      {showInstallHelp && (
        <div className="pwa-install-help" role="dialog" aria-modal="true" aria-labelledby="pwa-install-help-title">
          <div className="pwa-install-help-card">
            <button type="button" className="pwa-install-help-close" onClick={() => setShowInstallHelp(false)} aria-label={isEn ? "Close install instructions" : "ইনস্টল নির্দেশনা বন্ধ করুন"}>
              <X size={18} aria-hidden="true" />
            </button>
            <h2 id="pwa-install-help-title">{resolvedHelpTitle}</h2>
            {isAdminApp && (
              <p className="mb-3 text-left text-xs font-semibold text-emerald-300">
                {isEn ? "This will be installed as a dedicated admin app." : "এটি শুধু অ্যাডমিন ড্যাশবোর্ডের আলাদা অ্যাপ হিসেবে ইনস্টল হবে।"}
              </p>
            )}
            {isIos ? (
              <div className="space-y-2 text-left text-xs text-slate-300">
                <p>🍎 <strong>{isEn ? "How to install on iPhone (Safari):" : "আইফোন (Safari) দিয়ে ইনস্টল করার নিয়ম:"}</strong></p>
                <ol className="list-decimal list-inside space-y-1 pl-1 text-slate-300">
                  <li>{isEn ? "Tap the " : "সাফারি ব্রাউজারের নিচের বারে "}<strong>Share (➦)</strong>{isEn ? " icon in the Safari bottom bar." : " আইকনে চাপ দিন।"}</li>
                  <li>{isEn ? "Scroll down and tap " : "মেনু থেকে স্ক্রোল করে নিচের দিকে "}<strong>"Add to Home Screen"</strong>.</li>
                  <li>{isEn ? "Tap " : "ডানপাশের ওপরের কোণায় "}<strong>"Add"</strong>{isEn ? " at the top right to install!" : " চাপলেই অ্যাপটি আপনার আইফোনে ইনস্টল হয়ে যাবে!"}</li>
                </ol>
              </div>
            ) : isAndroid ? (
              <div className="space-y-2 text-left text-xs text-slate-300">
                <p>🤖 <strong>{isEn ? "How to install on Android (Chrome / Edge):" : "অ্যান্ড্রয়েড (Chrome / Edge) দিয়ে ইনস্টল করার নিয়ম:"}</strong></p>
                <ol className="list-decimal list-inside space-y-1 pl-1 text-slate-300">
                  <li>{isEn ? "Tap the " : "ব্রাউজারের ওপরের ডান কোণায় "}<strong>three dots (⋮)</strong>{isEn ? " menu at the top right." : " মেনুতে চাপ দিন।"}</li>
                  <li>{isEn ? "Select " : "মেনু থেকে "}<strong>"Install app"</strong>{isEn ? " or " : " বা "}<strong>"Add to Home screen"</strong>.</li>
                  <li>{isEn ? "Confirm to add " : "কনফার্ম করলেই আপনার মোবাইলের হোমস্ক্রিনে "}<strong>{isAdminApp ? (isEn ? "Admin App" : "অ্যাডমিন অ্যাপ") : resolvedAppName}</strong>{isEn ? " to your home screen!" : " যুক্ত হয়ে যাবে!"}</li>
                </ol>
              </div>
            ) : (
              <div className="space-y-2 text-left text-xs text-slate-300">
                <p>💻 <strong>{isEn ? "How to install from desktop or mobile browser:" : "ডেস্কটপ বা মোবাইল ব্রাউজার থেকে ইনস্টল করার নিয়ম:"}</strong></p>
                <ol className="list-decimal list-inside space-y-1 pl-1 text-slate-300">
                  <li>{isEn ? "Click the install (⊕) icon on the right side of the address bar." : "ব্রাউজারের অ্যাড্রেস বারের ডানপাশে ইনস্টল (⊕) আইকনে ক্লিক করুন।"}</li>
                  <li>{isEn ? "Or select " : "অথবা ব্রাউজার মেনু থেকে "}<strong>"Install SahajContact"</strong>{isEn ? " from the browser menu." : " সিলেক্ট করুন।"}</li>
                </ol>
              </div>
            )}
            <button type="button" className="button button-primary" onClick={() => setShowInstallHelp(false)}>{isEn ? "Understood" : "বুঝেছি"}</button>
          </div>
        </div>
      )}
    </>
  );
}
