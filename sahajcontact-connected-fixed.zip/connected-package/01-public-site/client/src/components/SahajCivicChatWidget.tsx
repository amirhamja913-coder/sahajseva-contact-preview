import { useEffect, useRef, useState } from "react";
import {
  Bot,
  ChevronDown,
  Loader2,
  MessageCircle,
  Send,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useServiceFinderVisibility } from "@/hooks/useServiceFinderVisibility";
import { trackEvent } from "@/lib/analytics";

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

type QuickReply = {
  label: string;
  prompt: string;
};

export const SAHAJ_CHAT_QUICK_REPLIES: QuickReply[] = [
  { label: "সরকারি ফি যাচাই", prompt: "সরকারি ফি ও অফিসিয়াল নির্দেশনা কোথায় যাচাই করব?" },
  { label: "NID সংশোধন", prompt: "NID সংশোধনের জন্য কী কী লাগবে এবং কীভাবে আবেদন করব?" },
  { label: "আবেদন স্ট্যাটাস", prompt: "অফিসিয়াল পোর্টালে আবেদন স্ট্যাটাস কীভাবে জানতে পারি?" },
  { label: "ড্রাইভিং লাইসেন্স", prompt: "ড্রাইভিং লাইসেন্স আবেদনের প্রাথমিক ধাপগুলো কী?" },
  { label: "BSTI আবেদন", prompt: "BSTI আবেদনের জন্য কী কী তথ্য ও কাগজপত্র প্রয়োজন?" },
  { label: "ই-পাসপোর্ট", prompt: "ই-পাসপোর্ট আবেদনের প্রাথমিক নিয়মগুলো জানতে চাই।" },
  { label: "সাধারণ যোগাযোগ", prompt: "সাধারণ যোগাযোগের নিরাপদ উপায় কী?" },
];

const WELCOME_MESSAGE: ChatMessage = {
  role: "assistant",
  content:
    "আসসালামু আলাইকুম। আমি সহজসেবার বাংলা তথ্য সহকারী। NID, পাসপোর্ট, ভাতা, ড্রাইভিং লাইসেন্স ও BSTI-র সরকারি নিয়ম ও অফিসিয়াল তথ্য খুঁজতে সাহায্য করতে পারি। শুরু করতে নিচের সাধারণ প্রশ্নগুলোর একটি বেছে নিন।",
};

const FALLBACK_MESSAGE: ChatMessage = {
  role: "assistant",
  content:
    "দুঃখিত, এই মুহূর্তে AI সহকারী উত্তর দিতে পারছে না। ব্যক্তিগত তথ্য chat-এ দেবেন না। সাধারণ যোগাযোগের জন্য পোর্টালের Contact পেজ ব্যবহার করুন এবং সরকারি সেবার জন্য সংশ্লিষ্ট অফিসিয়াল পোর্টাল অনুসরণ করুন।",
};

const SENSITIVE_DATA_PATTERN = /\b(otp|pin|password|transaction|trx|bKash|nagad)\b|পাসওয়ার্ড|লেনদেন|ট্রানজ্যাকশন|বিকাশ|নগদ/i;
const SENSITIVE_DATA_REPLY = "নিরাপত্তার জন্য OTP, PIN, পাসওয়ার্ড, payment number বা transaction ID chat-এ দেওয়া বা যাচাই করা যায় না। সরকারি ফি ও আবেদন সংক্রান্ত তথ্য সংশ্লিষ্ট অফিসিয়াল পোর্টাল থেকে যাচাই করুন।";

export default function SahajCivicChatWidget() {
  const hideFloatingActions = useServiceFinderVisibility();
  const [isOpen, setIsOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const messagesRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: (response) => {
      trackEvent("sahaj_chat_response", { status: "success" });
      setMessages((current) => [
        ...current,
        { role: "assistant", content: response.content },
      ]);
    },
    onError: () => {
      trackEvent("sahaj_chat_response", { status: "fallback" });
      setMessages((current) => [...current, FALLBACK_MESSAGE]);
    },
  });

  useEffect(() => {
    const container = messagesRef.current;
    if (!container) return;

    container.scrollTo({
      top: container.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, chatMutation.isPending, isOpen]);

  useEffect(() => {
    if (isOpen) {
      window.setTimeout(() => inputRef.current?.focus(), 120);
    }
  }, [isOpen]);

  const sendMessage = (rawMessage: string, source: "typed" | "quick_reply" = "typed") => {
    const content = rawMessage.trim();
    if (!content || chatMutation.isPending) return;

    if (SENSITIVE_DATA_PATTERN.test(content)) {
      setMessages((current) => [
        ...current,
        { role: "user", content },
        { role: "assistant", content: SENSITIVE_DATA_REPLY },
      ]);
      setDraft("");
      return;
    }

    trackEvent("sahaj_chat_message", { source });
    const nextMessages: ChatMessage[] = [
      ...messages,
      { role: "user", content },
    ];

    setMessages(nextMessages);
    setDraft("");
    chatMutation.mutate({ messages: nextMessages.slice(-12) });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    sendMessage(draft);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage(draft);
    }
  };

  return (
    <>
      {isOpen && (
        <section
          id="sahaj-civic-chat"
          aria-label="সহজসেবা AI সহায়তা"
          className="fixed inset-x-3 bottom-24 z-50 flex max-h-[min(76vh,640px)] flex-col overflow-hidden rounded-3xl border border-[#c7d8d2] bg-[#fffdf7] shadow-[0_24px_70px_rgba(16,45,51,0.25)] sm:inset-x-auto sm:right-5 sm:w-[390px]"
        >
          <header className="flex items-center justify-between gap-3 bg-[#123d42] px-4 py-3 text-white">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-[#f2b84b] text-[#123d42]">
                <Bot className="size-5" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-bold">সহজসেবা AI সহকারী</p>
                <p className="flex items-center gap-1 text-[11px] text-[#d9efea]">
                  <span className="size-1.5 rounded-full bg-[#77d7ad]" aria-hidden="true" />
                  সাধারণ প্রশ্নে তাৎক্ষণিক সহায়তা
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                trackEvent("sahaj_chat_close", { source: "header_button" });
                setIsOpen(false);
              }}
              aria-label="চ্যাট বন্ধ করুন"
              className="rounded-full p-2 text-white/80 transition hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f2b84b] active:scale-95"
            >
              <X className="size-5" aria-hidden="true" />
            </button>
          </header>

          <div
            ref={messagesRef}
            role="log"
            aria-live="polite"
            aria-label="চ্যাট বার্তা"
            className="min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-4 sm:px-4"
          >
            {messages.map((message, index) => (
              <div
                key={`${message.role}-${index}`}
                className={`flex items-end gap-2 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <div className="mb-0.5 flex size-7 shrink-0 items-center justify-center rounded-xl bg-[#e1f0ed] text-[#0f766e]">
                    <Sparkles className="size-3.5" aria-hidden="true" />
                  </div>
                )}
                <div
                  className={`max-w-[84%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-6 ${
                    message.role === "user"
                      ? "rounded-br-md bg-[#0f766e] text-white"
                      : "rounded-bl-md border border-[#e0e8e3] bg-white text-[#20383b] shadow-sm"
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}

            {chatMutation.isPending && (
              <div className="flex items-end gap-2">
                <div className="flex size-7 shrink-0 items-center justify-center rounded-xl bg-[#e1f0ed] text-[#0f766e]">
                  <Sparkles className="size-3.5" aria-hidden="true" />
                </div>
                <div className="flex items-center gap-1 rounded-2xl rounded-bl-md border border-[#e0e8e3] bg-white px-4 py-3 shadow-sm">
                  <span className="size-1.5 rounded-full bg-[#0f766e] motion-safe:animate-pulse" />
                  <span className="size-1.5 rounded-full bg-[#0f766e] motion-safe:animate-pulse [animation-delay:120ms]" />
                  <span className="size-1.5 rounded-full bg-[#0f766e] motion-safe:animate-pulse [animation-delay:240ms]" />
                  <span className="sr-only">উত্তর তৈরি হচ্ছে</span>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-[#e4ebe7] bg-[#f6faf7] px-3 pb-3 pt-3 sm:px-4">
            <div className="mb-3 flex items-center gap-2 text-[11px] font-bold text-[#35615f]">
              <MessageCircle className="size-3.5" aria-hidden="true" />
              <span>সাধারণ প্রশ্ন — এক ক্লিকে জিজ্ঞেস করুন</span>
            </div>
            <div className="mb-3 flex gap-2 overflow-x-auto pb-1 sm:flex-wrap sm:overflow-visible">
              {SAHAJ_CHAT_QUICK_REPLIES.map((quickReply) => (
                <button
                  key={quickReply.label}
                  type="button"
                  onClick={() => {
                    trackEvent("sahaj_chat_quick_reply", { label: quickReply.label });
                    sendMessage(quickReply.prompt, "quick_reply");
                  }}
                  disabled={chatMutation.isPending}
                  className="shrink-0 rounded-full border border-[#b9d7d0] bg-white px-3 py-1.5 text-xs font-semibold text-[#14665f] transition hover:border-[#0f766e] hover:bg-[#e6f4f0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0f766e] disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]"
                >
                  {quickReply.label}
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="flex items-center gap-2">
              <input
                ref={inputRef}
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={handleKeyDown}
                type="text"
                placeholder="আপনার প্রশ্ন লিখুন..."
                aria-label="আপনার প্রশ্ন"
                disabled={chatMutation.isPending}
                className="min-w-0 flex-1 rounded-2xl border border-[#c9d9d4] bg-white px-3.5 py-2.5 text-sm text-[#20383b] outline-none transition placeholder:text-[#7f9692] focus:border-[#0f766e] focus:ring-2 focus:ring-[#0f766e]/15 disabled:bg-[#edf2ef]"
              />
              <button
                type="submit"
                disabled={!draft.trim() || chatMutation.isPending}
                aria-label="প্রশ্ন পাঠান"
                className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-[#0f766e] text-white transition hover:bg-[#0b625d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f2b84b] disabled:cursor-not-allowed disabled:opacity-45 active:scale-95"
              >
                {chatMutation.isPending ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Send className="size-4" aria-hidden="true" />
                )}
              </button>
            </form>
            <p className="mt-2 flex items-center gap-1 text-[10px] leading-4 text-[#728682]">
              <ShieldCheck className="size-3" aria-hidden="true" />
              OTP, PIN, পাসওয়ার্ড, পূর্ণ NID নম্বর, payment number বা transaction ID chat-এ দেবেন না।
            </p>
          </div>
        </section>
      )}

      {(!hideFloatingActions || isOpen) && (
        <button
          type="button"
          onClick={() => {
            const nextOpenState = !isOpen;
          trackEvent(nextOpenState ? "sahaj_chat_open" : "sahaj_chat_close", { source: "floating_button" });
          setIsOpen(nextOpenState);
        }}
        aria-expanded={isOpen}
        aria-controls="sahaj-civic-chat"
          aria-label={isOpen ? "চ্যাট বন্ধ করুন" : "AI সহায়তা খুলুন"}
          className="sahaj-floating-chat fixed right-4 z-50 flex items-center gap-2 rounded-full bg-[#0f766e] px-4 py-3 text-sm font-bold text-white shadow-[0_12px_30px_rgba(15,118,110,0.3)] transition hover:bg-[#0b625d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f2b84b] active:scale-95 sm:right-5"
        >
        {isOpen ? (
          <ChevronDown className="size-5" aria-hidden="true" />
        ) : (
          <MessageCircle className="size-5" aria-hidden="true" />
        )}
          <span className="hidden sm:inline">{isOpen ? "চ্যাট বন্ধ করুন" : "AI সহায়তা"}</span>
        </button>
      )}

    </>
  );
}
