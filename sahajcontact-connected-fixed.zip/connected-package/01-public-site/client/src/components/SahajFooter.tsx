import { useState } from "react";
import { Link } from "wouter";
import { ExternalLink, Lock, Mail } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

export const FOOTER_LEGAL_LINKS = [
  { label: "প্রাইভেসি নীতি", labelEn: "Privacy Policy", href: "/privacy-policy" },
  { label: "শর্তাবলী", labelEn: "Terms & Safety", href: "/terms" },
  { label: "নিরাপত্তা পরামর্শ", labelEn: "Security Advice", href: "/security-policy" },
  { label: "অভিযোগ জানান", labelEn: "Submit a Complaint", href: "/complaint" },
];

export const FOOTER_NAV_SECTIONS = [
  {
    title: "সেবা",
    titleEn: "Services",
    links: [
      { label: "প্রাতিষ্ঠানিক সহযোগিতা", labelEn: "Institutional collaboration", href: "/sponsor" },
      { label: "যোগাযোগ সহায়তা", labelEn: "Contact support", href: "/contact" },
      { label: "কম্প্লেইন্ট সেল", labelEn: "Complaint Cell", href: "/complaint" },
    ],
  },
  {
    title: "কোম্পানি",
    titleEn: "Company",
    links: [
      { label: "আমাদের সম্পর্কে", labelEn: "About Us", href: "/#about" },
      { label: "যোগাযোগ", labelEn: "Contact", href: "/contact" },
      { label: "Sponsor Us", labelEn: "Sponsor Us", href: "/sponsor" },
      { label: "ক্যারিয়ার", labelEn: "Careers", href: "/sponsor" },
    ],
  },
  {
    title: "ব্যবসা",
    titleEn: "Business",
    links: [
      { label: "ব্যবসা তথ্যভান্ডার", labelEn: "Business directory", href: "/business-directory" },
      { label: "বিজ্ঞাপন অনুসন্ধান", labelEn: "Advertising inquiry", href: "/advertise" },
      { label: "প্রাতিষ্ঠানিক প্রস্তাব", labelEn: "Institutional proposal", href: "/sponsor" },
      { label: "এনজিও সহযোগিতা", labelEn: "NGO collaboration", href: "/ngo-partnership" },
    ],
  },
  {
    title: "অন্যান্য",
    titleEn: "Other",
    links: FOOTER_LEGAL_LINKS,
  },
];

export const FOOTER_SSL_LABEL = "🔒 SSL সিকিউর - আপনার তথ্য এনক্রিপ্ট করা আছে";
export const FOOTER_SECURITY_LABEL = "⚠️ সতর্কতা: আমরা কখনো আপনার কাছে OTP, পিন, পাসওয়ার্ড চাইবো না";
export const FOOTER_OTP_WARNING = "আমরা OTP চাই না";
export const FOOTER_ADMIN_ENTRY = { label: "মালিকের Admin Dashboard", labelEn: "Owner Admin Dashboard", href: ["/admin", "dashboard"].join("/") } as const;

const FOOTER_COPY = {
  BN: {
    brand: "সহজ সেবা",
    tagline: "সহজ পথে প্রয়োজনীয় সেবার নির্ভরযোগ্য সহায়তা।",
    hours: "সকাল ৯টা — রাত ৯টা",
    termsTitle: "শর্তাবলী ও নিরাপদ ব্যবহার নীতিমালা",
    termsIntro: "SahajContact একটি স্বাধীন তথ্যমূলক ও নাগরিক সহায়তা পোর্টাল। আমাদের প্রধান উদ্দেশ্য হলো সাধারণ মানুষ ও প্রবাসীদের সঠিক সরকারি লিংক এবং নিরাপদ সেবার পথ দেখানো।",
    dosTitle: "✅ যা করবেন (নিরাপদ থাকার উপায়):",
    dos: ["সকল সরকারি কাজের জন্য কেবল অফিশিয়াল ওয়েবসাইট (.gov.bd) ব্যবহার করুন।", "পাসপোর্ট, এনআইডি, জন্ম নিবন্ধন বা ভিসা আবেদনের সময় অফিশিয়াল পোর্টালেই সরকারি ফি পরিশোধ করুন।", "আপনার পাসওয়ার্ড, ওটিপি (OTP), পিন নাম্বার বা ব্যাংক অ্যাকাউন্ট তথ্য কখনো কারো সাথে শেয়ার করবেন না।", "বিদেশে যাওয়ার আগে বা যেকোনো সেবার জন্য বিএমইটি (BMET) ও অফিশিয়াল নীতিমালা যাচাই করুন।"],
    dontTitle: "❌ যা করবেন না (প্রতারণা থেকে বাঁচতে):",
    donts: ["ফেসবুক, হোয়াটসঅ্যাপ বা অপরিচিত কোনো ব্যক্তির ব্যক্তিগত বিকাশ/নগদ নম্বরে কোনো কাজের জন্য টাকা পাঠাবেন না।", "অপরিচিত কারো কথায় প্রলুব্ধ হয়ে টুরিস্ট ভিসায় বা অবৈধ পথে বিদেশ যাওয়ার চেষ্টা করবেন না।", "সংশয়ী লিংকে ক্লিক করে ব্যক্তিগত বা গোপনীয় তথ্য ইনপুট দেবেন না। SahajContact কখনোই আপনার কাছে কোনো পাসওয়ার্ড বা ওটিপি চাইবে না।"],
    termsDisclaimer: "দায়িত্ব অস্বীকার: এই সাইটের তথ্য বা লিংক ব্যবহার করে কোনো লেনদেন বা জটিলতা তৈরি হলে SahajContact বা এর প্রশাসক দায়ী থাকবে না। সবসময় সরকারি অফিশিয়াল চ্যানেল ব্যবহার করুন।",
    understood: "বুঝেছি, ধন্যবাদ",
    securityTitle: "নিরাপত্তা পরামর্শ ও সতর্কতা",
    securityWarning: "⚠️ সতর্কতা: SahajContact বা এর কোনো প্রতিনিধি কখনোই আপনার কাছে কোনো ওটিপি (OTP), ব্যাংক পিন, বা পাসওয়ার্ড চাইবে না।",
    securityBody: "আপনার অ্যাকাউন্ট ও ব্যক্তিগত তথ্য নিরাপদ রাখতে সবসময় শক্তিশালী পাসওয়ার্ড ব্যবহার করুন এবং সন্দেহজনক কল বা লিংকের বিষয়ে সতর্ক থাকুন।",
    close: "বন্ধ করুন",
    disclaimer: "দাবি অস্বীকার: SahajContact একটি তথ্যমূলক ওয়েবসাইট। আমরা বাংলাদেশ সরকারের কোনো অফিসিয়াল প্রতিষ্ঠান নই। এখানে দেয়া সকল লিংক সরকারি .gov.bd ওয়েবসাইটে রিডাইরেক্ট করে। কোনো আবেদন বা লেনদেনের জন্য দায়িত্ব সম্পূর্ণ ব্যবহারকারীর। সঠিক তথ্যের জন্য অবশ্যই অফিসিয়াল ওয়েবসাইট চেক করুন।",
    privacySummary: "গোপনীয়তা নীতি: আমরা কোনো ব্যক্তিগত তথ্য যেমন NID নম্বর, মোবাইল নম্বর, পাসওয়ার্ড সংগ্রহ করি না।",
    details: "বিস্তারিত দেখুন",
    copyright: "© ২০২৬ সহজ সেবা। সকল স্বত্ব সংরক্ষিত।",
    privacyPoints: ["১. আমরা কোনো ব্যক্তিগত তথ্য যেমন NID নম্বর, মোবাইল নম্বর, পাসওয়ার্ড সংগ্রহ করি না।", "২. আমরা শুধু Google Analytics ব্যবহার করি সাইট উন্নত করার জন্য।", "৩. আমরা কোনো থার্ড পার্টির কাছে ডাটা বিক্রি করি না।", "৪. ব্যবহারকারীর নিরাপত্তার জন্য আমরা শুধু অফিসিয়াল সরকারি লিংক প্রদান করি।"],
    contact: "যোগাযোগ: অফিশিয়াল পোর্টালে সরাসরি বার্তা পাঠান",
    updated: "সর্বশেষ আপডেট: ১৮ আগস্ট ২০২৬",
    ownership: "নিরাপদ সেবা ও গোপনীয়তা:",
    protected: "কোনো OTP, PIN, পাসওয়ার্ড বা সংবেদনশীল তথ্য এখানে চাই না",
  },
  EN: {
    brand: "Sahaj Seva",
    tagline: "Reliable help for essential services, made easier.",
    hours: "9:00 AM — 9:00 PM",
    termsTitle: "Terms & Safe Use Policy",
    termsIntro: "SahajContact is an independent information and civic-assistance portal. Our purpose is to guide citizens and expatriates toward accurate official links and safer service pathways.",
    dosTitle: "✅ Do this (stay safe):",
    dos: ["Use only official websites (.gov.bd) for government work.", "Pay government fees only on official portals when applying for a passport, NID, birth registration, or visa.", "Never share your password, OTP, PIN, or bank-account information with anyone.", "Before travelling abroad or using any service, verify BMET information and the official policy."],
    dontTitle: "❌ Do not do this (avoid fraud):",
    donts: ["Do not send money for any service to a stranger’s personal bKash or Nagad number through Facebook or WhatsApp.", "Do not attempt to travel abroad on a tourist visa or through an illegal route because of a stranger’s promise.", "Do not enter personal or confidential information after clicking a suspicious link. SahajContact will never ask for your password or OTP."],
    termsDisclaimer: "Disclaimer: SahajContact and its administrators are not responsible for transactions or complications resulting from use of information or links on this site. Always use official government channels.",
    understood: "Understood, thank you",
    securityTitle: "Security Advice & Warning",
    securityWarning: "⚠️ Warning: SahajContact and its representatives will never ask for your OTP, bank PIN, or password.",
    securityBody: "Use a strong password to protect your account and personal information, and stay alert to suspicious calls or links.",
    close: "Close",
    disclaimer: "Disclaimer: SahajContact is an informational website, not an official institution of the Government of Bangladesh. Links redirect to official .gov.bd websites. Users are solely responsible for applications and transactions. Always verify information on the official website.",
    privacySummary: "Privacy: We do not collect personal information such as NID numbers, mobile numbers, or passwords.",
    details: "View details",
    copyright: "© 2026 Sahaj Seva. All rights reserved.",
    privacyPoints: ["1. We do not collect personal information such as NID numbers, mobile numbers, or passwords.", "2. We use Google Analytics only to improve the site.", "3. We do not sell data to third parties.", "4. For user safety, we provide official government links only."],
    contact: "Contact: Send a direct message through the official portal",
    updated: "Last updated: 18 August 2026",
    ownership: "Safe service and privacy:",
    protected: "We never ask for OTPs, PINs, passwords or sensitive credentials here",
  },
} as const;

export function SahajFooter({ language: languageOverride }: { language?: "BN" | "EN" }) {
  const { language: activeLanguage } = useLanguage();
  const language = languageOverride ?? activeLanguage;
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const siteContentQuery = trpc.siteManagement.getPublicContent.useQuery(undefined, { staleTime: 60_000, refetchOnWindowFocus: false });
  const managedSettings = siteContentQuery.data?.settings;
  const managedBrand = language === "EN" ? managedSettings?.siteNameEn || footerCopyFallback("EN") : managedSettings?.siteNameBn || footerCopyFallback("BN");
  let managedSocialLinks: Array<{ label: string; url: string }> = [];
  try {
    const parsed = managedSettings?.socialLinksJson ? JSON.parse(managedSettings.socialLinksJson) : [];
    managedSocialLinks = Array.isArray(parsed) ? parsed.filter((item): item is { label: string; url: string } => Boolean(item && typeof item.label === "string" && typeof item.url === "string")) : [];
  } catch {
    managedSocialLinks = [];
  }
  const footerCopy = FOOTER_COPY[language];
  const navSections = FOOTER_NAV_SECTIONS.map((section) => ({
    ...section,
    title: language === "EN" ? section.titleEn : section.title,
    links: section.links.map((link) => ({ ...link, label: language === "EN" ? link.labelEn : link.label })),
  }));

  return (
    <footer className="sahaj-footer bg-black text-slate-300 pt-10 pb-8 border-t border-slate-900 font-sans" role="contentinfo">
      <div className="container mx-auto px-4 max-w-4xl">
        
        {/* Top Header matching reference */}
        <div className="space-y-2 pb-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            {managedSettings?.logoUrl && <img src={managedSettings.logoUrl} alt={managedBrand} className="h-10 w-10 rounded-xl object-contain shadow-sm" loading="lazy" />}
            <span className="text-2xl font-bold tracking-tight text-white">{managedBrand}</span>
          </div>
          <p className="text-sm text-slate-400">{footerCopy.tagline}</p>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-2 text-sm text-slate-300">
            <Link href="/contact" data-testid="footer-contact-route" className="inline-flex items-center gap-1.5 hover:text-white"><Mail size={14} aria-hidden="true" />{footerCopy.contact}</Link>
            {managedSocialLinks.map((social) => <a key={`${social.label}-${social.url}`} href={social.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 hover:text-white"><ExternalLink size={13} aria-hidden="true" />{social.label}</a>)}
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-300 pt-1">
            <span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span>
            <span>{footerCopy.hours}</span>
          </div>
        </div>

        {/* 2x2 or 4-column Compact Link Grid matching reference */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8 border-b border-slate-900">
          {navSections.map((section, idx) => (
            <div key={idx} className="space-y-3">
              <h4 className="text-base font-semibold text-white tracking-wide">{section.title}</h4>
              <ul className="space-y-2.5 text-sm">
                {section.links.map((link, lIdx) => (
                  <li key={lIdx}>
                    {link.href === "/privacy-policy" ? (
                      <button
                        onClick={() => setShowPrivacyModal(true)}
                        className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1.5 text-left"
                      >
                        <span>{link.label}</span>
                        <span className="text-xs opacity-50">↗</span>
                      </button>
                    ) : link.href === "/terms" ? (
                      <button
                        onClick={() => setShowTermsModal(true)}
                        className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1.5 text-left"
                      >
                        <span>{link.label}</span>
                        <span className="text-xs opacity-50">↗</span>
                      </button>
                    ) : link.href === "/security-policy" ? (
                      <button
                        onClick={() => setShowSecurityModal(true)}
                        className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1.5 text-left"
                      >
                        <span>{link.label}</span>
                        <span className="text-xs opacity-50">↗</span>
                      </button>
                    ) : (
                      <a
                        href={link.href}
                        className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1.5"
                        {...(link.href.startsWith("http") ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      >
                        <span>{link.label}</span>
                        <span className="text-xs opacity-50">↗</span>
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Terms & Safety Modal / Dialog */}
        {showTermsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-xl max-w-2xl w-full p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-xl font-bold text-teal-400 flex items-center gap-2">
                  <span>🛡️</span> {footerCopy.termsTitle}
                </h3>
                <button
                  onClick={() => setShowTermsModal(false)}
                  className="text-slate-400 hover:text-white text-xl font-bold px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 transition"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4 text-sm leading-relaxed text-slate-300">
                <p className="font-medium text-white">
                  {footerCopy.termsIntro}
                </p>

                <div className="bg-slate-800/80 p-4 rounded-lg border border-teal-500/30 space-y-2">
                  <h4 className="font-bold text-teal-300">{footerCopy.dosTitle}</h4>
                  <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
                    {footerCopy.dos.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                </div>

                <div className="bg-rose-950/40 p-4 rounded-lg border border-rose-500/30 space-y-2">
                  <h4 className="font-bold text-rose-300">{footerCopy.dontTitle}</h4>
                  <ul className="list-disc pl-5 space-y-1.5 text-slate-300">
                    {footerCopy.donts.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                </div>

                <p className="text-xs text-slate-400 italic pt-2 border-t border-slate-800">
                  {footerCopy.termsDisclaimer}
                </p>
              </div>

              <div className="flex justify-end pt-3 border-t border-slate-800">
                <button
                  onClick={() => setShowTermsModal(false)}
                  className="bg-teal-600 hover:bg-teal-500 text-white font-medium px-5 py-2 rounded-lg transition"
                >
                  {footerCopy.understood}
                </button>
              </div>
            </div>
          </div>
        )}

        {showSecurityModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded-xl max-w-lg w-full p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-xl font-bold text-amber-400 flex items-center gap-2">
                  <span>🔒</span> {footerCopy.securityTitle}
                </h3>
                <button
                  onClick={() => setShowSecurityModal(false)}
                  className="text-slate-400 hover:text-white text-xl font-bold px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 transition"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3 text-sm leading-relaxed text-slate-300">
                <p className="bg-amber-950/40 border border-amber-500/30 p-3 rounded-lg text-amber-200 font-medium">
                  {footerCopy.securityWarning}
                </p>
                <p>
                  {footerCopy.securityBody}
                </p>
              </div>

              <div className="flex justify-end pt-3 border-t border-slate-800">
                <button
                  onClick={() => setShowSecurityModal(false)}
                  className="bg-amber-600 hover:bg-amber-500 text-white font-medium px-5 py-2 rounded-lg transition"
                >
                  {footerCopy.close}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Detailed Disclaimer & Privacy Summary */}
        <div className="pt-6 text-xs text-slate-500 space-y-3">
          <p className="text-slate-400 leading-relaxed font-medium">
            {footerCopy.disclaimer}
          </p>
          <p className="flex items-center gap-2 flex-wrap">
            <span>{footerCopy.privacySummary}</span>
            <button
              onClick={() => setShowPrivacyModal(true)}
              className="text-rose-400 hover:text-rose-300 underline font-medium"
            >
              {footerCopy.details}
            </button>
          </p>
          <p className="pt-2 text-slate-600">
            {footerCopy.copyright}
          </p>
          <div className="border-t border-slate-900 pt-4 text-center">
            <Link
              href={FOOTER_ADMIN_ENTRY.href}
              data-testid="footer-admin-entry"
              className="inline-flex items-center gap-1.5 text-[11px] text-slate-600 transition-colors hover:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 focus:ring-offset-black"
              aria-label={language === "EN" ? FOOTER_ADMIN_ENTRY.labelEn : FOOTER_ADMIN_ENTRY.label}
            >
              <Lock size={11} aria-hidden="true" />
              <span>{language === "EN" ? FOOTER_ADMIN_ENTRY.labelEn : FOOTER_ADMIN_ENTRY.label}</span>
            </Link>
          </div>
        </div>

      </div>

      {/* Privacy Policy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="bg-slate-900 border border-slate-800 text-slate-200 rounded-xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Lock className="text-rose-500" size={20} />
                <h3 className="text-lg font-bold text-white">Privacy Policy - SahajContact</h3>
              </div>
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="text-slate-400 hover:text-white text-xl font-bold px-2 py-1"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-3 text-sm text-slate-300 leading-relaxed text-left">
              {footerCopy.privacyPoints.map((point) => <p key={point} className="font-medium text-slate-200">{point}</p>)}
            </div>

            <div className="pt-3 border-t border-slate-800 text-xs text-slate-400 space-y-1 text-left">
              <p>{footerCopy.contact}</p>
              <p>{footerCopy.updated}</p>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-lg transition-colors"
              >
                {footerCopy.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}

function footerCopyFallback(language: "BN" | "EN") {
  return language === "EN" ? FOOTER_COPY.EN.brand : FOOTER_COPY.BN.brand;
}


export default SahajFooter;
