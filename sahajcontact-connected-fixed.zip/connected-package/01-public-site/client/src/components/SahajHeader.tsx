import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { CheckCircle2, ChevronDown, ExternalLink, Home, Menu, Moon, ShieldAlert, Sun, Wheat, X } from "lucide-react";
import { expatGuidelines, regionalGuides, type RegionalRegion } from "@/components/UtilityAndExpatriateSections";
import { trackEvent, trackOutbound } from "@/lib/analytics";
import { useTheme } from "@/contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

const fallbackNavigation = [
  ["হোম", "Home", "/"], ["সেবা", "Services", "/#services"], ["আমাদের সম্পর্কে", "About Us", "/about"],
  ["পার্টনারশিপ ও NGO সহায়তা", "Partnership & NGO", "/funding-guidance"], ["নারী ও শিশু এবং সাধারণ মানুষের পরবর্তী পরিকল্পনা", "Future Plan", "/future-plan"],
  ["সাধারণ মানুষের জন্য নির্দেশনা", "Public Guidance", "/public-guidance"], ["নিরাপত্তা নীতি", "Security Policy", "/security-policy"],
  ["যোগাযোগ", "Contact", "/contact"], ["Sponsor Us", "Sponsor Us", "/sponsor"], ["সেবার টুলস", "Service Tools", "/tools"],
].map(([titleBn, titleEn, url], displayOrder) => ({ id: `fallback-${displayOrder}`, titleBn, titleEn, url, displayOrder }));

const publicMenuGroups = [
  { id: "business", titleBn: "ব্যবসা ও প্রতিষ্ঠানের তথ্য", titleEn: "Business & Organisation", links: [{ titleBn: "ব্যবসা তথ্যভান্ডার", titleEn: "Business directory", href: "/business-directory" }, { titleBn: "সেবার টুলস", titleEn: "Service tools", href: "/tools" }] },
  { id: "partners", titleBn: "পার্টনার ও এনজিও", titleEn: "Partners & NGO", links: [{ titleBn: "অংশীদারিত্ব ও NGO সহায়তা", titleEn: "Partnership & NGO support", href: "/funding-guidance" }] },
  { id: "sponsor", titleBn: "স্পন্সরশিপ", titleEn: "Sponsorship", links: [{ titleBn: "স্পন্সর হওয়ার তথ্য", titleEn: "Sponsor information", href: "/sponsor" }] },
  { id: "insights", titleBn: "তথ্য ও নির্দেশনা", titleEn: "Insights & guidance", links: [{ titleBn: "সাধারণ মানুষের নির্দেশনা", titleEn: "Public guidance", href: "/public-guidance" }, { titleBn: "ভবিষ্যৎ পরিকল্পনা", titleEn: "Future plan", href: "/future-plan" }] },
  { id: "policy", titleBn: "আইনি ও নীতিমালা", titleEn: "Legal & policy", links: [{ titleBn: "নিরাপত্তা নীতি", titleEn: "Security policy", href: "/security-policy" }] },
];

export default function SahajHeader() {
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileExpatOpen, setMobileExpatOpen] = useState(false);
  const [mobileExpatRegion, setMobileExpatRegion] = useState<RegionalRegion>("bangladesh");
  const [ruralMotifPaused, setRuralMotifPaused] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage, applyManagedDefaultLanguage } = useLanguage();
  const { data: publicContent } = trpc.siteManagement.getPublicContent.useQuery();
  const headerSettings = publicContent?.settings;
  const headerLogoUrl = headerSettings?.logoUrl?.trim() || "/manus-storage/sahajseva-logo-optimized_3ff0d912.webp";
  const navigation = publicContent?.navigation?.length ? publicContent.navigation : fallbackNavigation;
  const isEn = language === "EN";
  const headerSiteName = (isEn ? headerSettings?.siteNameEn : headerSettings?.siteNameBn)?.trim() || "SahajContact";
  const headerTagline = (isEn ? headerSettings?.headerTaglineEn : headerSettings?.headerTaglineBn)?.trim() || (isEn ? "Civic Service Portal" : "সহজ জনসেবা পোর্টাল");
  const showLanguageBn = headerSettings?.showLanguageBn !== 0;
  const showLanguageEn = headerSettings?.showLanguageEn !== 0;
  const announcementEnabled = headerSettings?.headerAnnouncementEnabled !== 0;
  const announcementText = isEn ? (headerSettings?.headerAnnouncementTextEn ?? "Rural motif is active") : (headerSettings?.headerAnnouncementTextBn ?? "গ্রামীণ মোটিফ চলছে");
  const announcementButton = isEn ? (headerSettings?.headerAnnouncementButtonEn ?? "Tap to pause") : (headerSettings?.headerAnnouncementButtonBn ?? "থামাতে চাপুন");
  const probashiTitle = isEn ? (headerSettings?.probashiHelpTitleEn ?? "Expatriate Support") : (headerSettings?.probashiHelpTitleBn ?? "প্রবাসী সহায়তা");
  const probashiSubtitle = isEn ? (headerSettings?.probashiHelpSubtitleEn ?? "Expat Guide & Country Filter") : (headerSettings?.probashiHelpSubtitleBn ?? "প্রবাসী গাইড ও কান্ট্রি ফিল্টার");
  const probashiLink = isEn ? (headerSettings?.probashiHelpLinkEn ?? "Tap to view guidelines") : (headerSettings?.probashiHelpLinkBn ?? "গাইডলাইন দেখতে চাপুন");
  const isActive = (path: string) => location === path;
  const selectedMobileExpatGuide = regionalGuides.find((guide) => guide.id === mobileExpatRegion) ?? regionalGuides[0];

  useEffect(() => {
    if (headerSettings?.defaultSiteLanguage) applyManagedDefaultLanguage(headerSettings.defaultSiteLanguage);
  }, [applyManagedDefaultLanguage, headerSettings?.defaultSiteLanguage]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen((open) => {
      const next = !open;
      if (next) setMobileExpatOpen(false);
      return next;
    });
  };

  const toggleMobileExpatGuide = () => {
    setMobileExpatOpen((open) => {
      const next = !open;
      trackEvent("expatriate_menu_toggle", {
        placement: "mobile_menu",
        state: next ? "open" : "closed",
      });
      return next;
    });
  };

  return (
    <>
      <header className="sticky-sahaj-header">
        <div className="container header-container">
          <div className="sahaj-header-left-stack">
            <Link href="/" className="sahaj-logo-wrap" onClick={() => {
              setMobileMenuOpen(false);
              setMobileExpatOpen(false);
              if (location === "/") window.scrollTo({ top: 0, behavior: "smooth" });
            }}>
              <div className="sahaj-logo-mark" aria-hidden="true">
                <img
                  src={headerLogoUrl}
                  alt=""
                  width={42}
                  height={42}
                  loading="eager"
                  decoding="async"
                />
              </div>
              <div className="sahaj-logo-text-stack">
                <span className="sahaj-logo-title">{headerSiteName}</span>
                <span className="sahaj-logo-subtitle">{headerTagline}</span>
              </div>
            </Link>
            <div className="sahaj-language-toggle inline-flex" role="group" aria-label="ভাষা নির্বাচন / Language selection" style={{ marginTop: '2px' }}>
              {showLanguageBn && <button type="button" className={language === "BN" ? "active" : ""} aria-pressed={language === "BN"} onClick={() => setLanguage("BN")}>বাংলা</button>}
              {showLanguageBn && showLanguageEn && <span aria-hidden="true">|</span>}
              {showLanguageEn && <button type="button" className={language === "EN" ? "active" : ""} aria-pressed={language === "EN"} onClick={() => setLanguage("EN")}>English</button>}
            </div>
          </div>

          <nav className="sahaj-desktop-nav" aria-label={isEn ? "Main Menu" : "প্রধান মেনু"}>
            {navigation.map((item) => (
              <Link key={item.id} href={item.url} className={`sahaj-nav-link ${isActive(item.url) ? "active" : ""}`}>
                {isEn ? item.titleEn : item.titleBn}
              </Link>
            ))}
          </nav>

          <div className="sahaj-header-cta-group">
            <button
              type="button"
              className="sahaj-theme-toggle"
              onClick={() => toggleTheme?.()}
              aria-label={theme === "dark" ? "লাইট মোড চালু করুন" : "ডার্ক মোড চালু করুন"}
              title={theme === "dark" ? (isEn ? "Light mode" : "লাইট মোড") : (isEn ? "Dark mode" : "ডার্ক মোড")}
            >
              {theme === "dark" ? <Sun size={16} aria-hidden="true" /> : <Moon size={16} aria-hidden="true" />}
              <span>{theme === "dark" ? (isEn ? "Light" : "লাইট") : (isEn ? "Dark" : "ডার্ক")}</span>
            </button>
            <Link
              href="/"
              className="sahaj-home-link-clean"
              title={isEn ? "Go to Home" : "হোম পেজে যান"}
              onClick={(e) => {
                if (location === "/") {
                  e.preventDefault();
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }
              }}
            >
              <Home size={15} aria-hidden="true" />
              <span>{isEn ? "Home" : "হোম"}</span>
            </Link>
            <button
              type="button"
              className="sahaj-mobile-toggle"
              onClick={toggleMobileMenu}
              aria-label={isEn ? "Open or close menu" : "মেনু খুলুন বা বন্ধ করুন"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="sahaj-mobile-menu">
            <div className="container sahaj-mobile-menu-inner">
              <div className="sahaj-mobile-top-actions">
                <Link
                  href="/"
                  onClick={(e) => {
                    setMobileMenuOpen(false);
                    setMobileExpatOpen(false);
                    if (location === "/") {
                      e.preventDefault();
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }
                  }}
                  className="sahaj-home-link-clean mobile-cta"
                  title={isEn ? "Go to Home" : "হোম পেজে যান"}
                >
                  <Home size={16} aria-hidden="true" /> {isEn ? "Home" : "হোম"}
                </Link>
                <button
                  type="button"
                  className="sahaj-theme-toggle mobile-theme-toggle"
                  onClick={() => toggleTheme?.()}
                  aria-label={theme === "dark" ? "লাইট মোড চালু করুন" : "ডার্ক মোড চালু করুন"}
                >
                  {theme === "dark" ? <Sun size={16} aria-hidden="true" /> : <Moon size={16} aria-hidden="true" />}
                  <span>{theme === "dark" ? (isEn ? "Light Mode" : "লাইট মোড") : (isEn ? "Dark Mode" : "ডার্ক মোড")}</span>
                </button>
                <div className="sahaj-language-toggle inline-flex" role="group" aria-label="ভাষা নির্বাচন / Language selection">
                  {showLanguageBn && <button type="button" className={language === "BN" ? "active" : ""} aria-pressed={language === "BN"} onClick={() => setLanguage("BN")}>বাংলা</button>}
                  {showLanguageBn && showLanguageEn && <span aria-hidden="true">|</span>}
                  {showLanguageEn && <button type="button" className={language === "EN" ? "active" : ""} aria-pressed={language === "EN"} onClick={() => setLanguage("EN")}>English</button>}
                </div>
              </div>
              <div className="sahaj-mobile-links-divider" role="separator" />
              {announcementEnabled && <button
                type="button"
                className={`sahaj-rural-motif ${ruralMotifPaused ? "is-paused" : ""}`}
                style={{ backgroundColor: headerSettings?.headerAnnouncementColor ?? undefined }}
                aria-pressed={ruralMotifPaused}
                aria-label={ruralMotifPaused ? (isEn ? "Resume rural motif animation" : "ধানের শীষের নড়াচড়া চালু করুন") : (isEn ? "Pause rural motif animation" : "ধানের শীষের নড়াচড়া থামান")}
                title={ruralMotifPaused ? (isEn ? "Resume rural motif" : "ধানের শীষের নড়াচড়া চালু করুন") : (isEn ? "Pause rural motif" : "ধানের শীষের নড়াচড়া থামান")}
                onClick={() => setRuralMotifPaused((paused) => !paused)}
              >
                <Wheat size={21} aria-hidden="true" />
                <span>{ruralMotifPaused ? (isEn ? "Rural Motif Paused" : "গ্রামীণ মোটিফ থামানো") : announcementText}</span>
                <small>{ruralMotifPaused ? (isEn ? "Tap to resume" : "চালু করতে চাপুন") : announcementButton}</small>
              </button>}
              {navigation.map((item) => (
                <Link key={item.id} href={item.url} onClick={() => setMobileMenuOpen(false)} className={`sahaj-mobile-link ${isActive(item.url) ? "active" : ""}`}>
                  {isEn ? item.titleEn : item.titleBn}
                </Link>
              ))}

              <section className="sahaj-mobile-panel-groups" aria-label={isEn ? "Organisation and account navigation" : "সংগঠন ও অ্যাকাউন্ট নেভিগেশন"}>
                {publicMenuGroups.map((group) => (
                  <div className="sahaj-mobile-panel-group" key={group.id}>
                    <h3>{isEn ? group.titleEn : group.titleBn}</h3>
                    <div className="sahaj-mobile-panel-group-links">
                      {group.links.map((link) => (
                        <Link
                          key={link.href}
                          href={link.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className={`sahaj-mobile-panel-group-link ${isActive(link.href) ? "active" : ""}`}
                        >
                          {isEn ? link.titleEn : link.titleBn}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </section>

              {headerSettings?.probashiHelpVisible !== 0 && <div className="sahaj-mobile-expat-folder">
                <button
                  type="button"
                  className={`sahaj-mobile-expat-trigger ${mobileExpatOpen ? "is-open" : ""}`}
                  aria-expanded={mobileExpatOpen}
                  aria-controls="sahaj-mobile-expat-panel"
                  onClick={toggleMobileExpatGuide}
                >
                  <span className="sahaj-mobile-expat-trigger-copy">
                    <span className="sahaj-mobile-expat-kicker">{probashiTitle}</span>
                    <span className="sahaj-mobile-expat-trigger-title">🌍 {probashiSubtitle}</span>
                    <small>{mobileExpatOpen ? (isEn ? "Tap to close" : "বন্ধ করতে চাপুন") : probashiLink}</small>
                  </span>
                  <ChevronDown className="sahaj-mobile-expat-chevron" size={19} aria-hidden="true" />
                </button>

                {mobileExpatOpen && (
                  <div id="sahaj-mobile-expat-panel" className="sahaj-mobile-expat-panel" data-utm-campaign="mobile_expatriate_country_guide">
                      <div className="sahaj-mobile-expat-panel-intro">
                      <ShieldAlert size={18} aria-hidden="true" />
                      <div>
                        <strong>{isEn ? "5 Essential Guidelines for Expatriates" : "প্রবাসী ভাই-বোনদের জন্য ৫টি জরুরি গাইডলাইন"}</strong>
                        <p>{isEn ? "Wherever you are abroad, keep these rules in mind to avoid fraud and access official services." : "বিদেশে যেখানেই থাকুন, প্রতারণা এড়িয়ে সরকারি সেবা নিতে এই নিয়মগুলো মনে রাখুন।"}</p>
                      </div>
                      </div>
                      <a
                        href={headerSettings?.probashiHelpHref ?? "/#expatriates"}
                        className="sahaj-mobile-expat-link-btn"
                        onClick={() => trackEvent("probashi_help_guideline_click", { placement: "mobile_menu" })}
                      >
                        <span>{probashiLink}</span>
                        <ExternalLink size={14} aria-hidden="true" />
                      </a>

                    <div className="sahaj-mobile-expat-guidelines" aria-label={isEn ? "Five essential expatriate guidelines" : "প্রবাসীদের পাঁচটি জরুরি গাইডলাইন"}>
                      {expatGuidelines.map((guideline) => (
                        <article className="sahaj-mobile-expat-guideline" key={guideline.number}>
                          <div className="sahaj-mobile-expat-guideline-heading">
                            <span className="sahaj-mobile-expat-badge" aria-hidden="true">#{guideline.number}</span>
                            <h4>{isEn ? guideline.titleEn : guideline.titleBn}</h4>
                          </div>
                          <ul className="sahaj-mobile-expat-bullets">
                            <li><CheckCircle2 size={13} aria-hidden="true" /> <span>{isEn ? guideline.safeEn : guideline.safeBn}</span></li>
                            <li><ShieldAlert size={13} aria-hidden="true" /> <span>{isEn ? guideline.cautionEn : guideline.cautionBn}</span></li>
                          </ul>
                          <p className="sahaj-mobile-expat-note">{isEn ? guideline.noteEn : guideline.noteBn}</p>
                        </article>
                      ))}
                    </div>

                    <div className="sahaj-mobile-expat-region-picker">
                      <span className="sahaj-mobile-expat-picker-label">{isEn ? "Select Country / Destination:" : "দেশ বা গন্তব্য নির্বাচন করুন:"}</span>
                      <div className="sahaj-mobile-expat-region-chips" role="tablist" aria-label={isEn ? "Destination country selection" : "গন্তব্য দেশ নির্বাচন"}>
                        {regionalGuides.map((guide) => {
                          const isSelected = mobileExpatRegion === guide.id;
                          return (
                            <button
                              key={guide.id}
                              type="button"
                              role="tab"
                              aria-selected={isSelected}
                              className={`sahaj-mobile-expat-region-chip ${isSelected ? "is-selected" : ""}`}
                              onClick={() => {
                                setMobileExpatRegion(guide.id);
                                trackEvent("expatriate_region_select", { placement: "mobile_menu", region: guide.id });
                              }}
                            >
                              <span>{guide.flag}</span>
                              <span>{isEn ? guide.nameEn : guide.nameBn}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="sahaj-mobile-expat-region-card">
                      <div className="sahaj-mobile-expat-region-header">
                        <span aria-hidden="true" style={{ fontSize: "1.4rem" }}>{selectedMobileExpatGuide.flag}</span>
                        <div>
                          <h5>{isEn ? selectedMobileExpatGuide.nameEn : selectedMobileExpatGuide.nameBn}</h5>
                          <p>{isEn ? selectedMobileExpatGuide.summaryEn : selectedMobileExpatGuide.summaryBn}</p>
                        </div>
                      </div>

                      <div className="sahaj-mobile-expat-steps">
                        <span className="sahaj-mobile-expat-steps-title">{isEn ? "Recommended Steps:" : "করণীয় পদক্ষেপ:"}</span>
                        <ol>
                          {(isEn ? selectedMobileExpatGuide.stepsEn : selectedMobileExpatGuide.stepsBn).map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>

                      <div className="sahaj-mobile-expat-actions">
                        {selectedMobileExpatGuide.links.map((link) => (
                          <a
                            key={link.href}
                            href={link.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="sahaj-mobile-expat-link-btn"
                            title={link.title}
                            onClick={() => {
                              trackEvent("expatriate_link_click", { region: selectedMobileExpatGuide.id, destination: link.href });
                              trackOutbound(link.labelBn, link.href, "mobile_expatriate_country_guide");
                            }}
                          >
                            <span>{isEn ? link.labelEn : link.labelBn}</span>
                            <ExternalLink size={14} aria-hidden="true" />
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>}
            </div>
          </div>
        )}
      </header>
    </>
  );
}
