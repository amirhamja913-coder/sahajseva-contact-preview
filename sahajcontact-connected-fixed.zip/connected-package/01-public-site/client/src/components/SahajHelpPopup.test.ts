import { readFileSync } from "node:fs";
import { describe, expect, it, vi } from "vitest";
import {
  HELP_POPUP_BUTTON_LABEL,
  HELP_POPUP_DELAY_MS,
  HELP_POPUP_AUTO_OPEN_ENABLED,
  HELP_POPUP_MESSAGE,
  HELP_POPUP_CONTACT_ROUTE,
  scheduleHelpPopup,
} from "./SahajHelpPopup";

const popupSource = readFileSync(new URL("./SahajHelpPopup.tsx", import.meta.url), "utf8");

describe("SahajHelpPopup", () => {
  it("waits exactly 10 seconds before showing and can cancel its timer", () => {
    vi.useFakeTimers();
    const onShow = vi.fn();

    const cancel = scheduleHelpPopup(onShow);
    vi.advanceTimersByTime(HELP_POPUP_DELAY_MS - 1);
    expect(onShow).not.toHaveBeenCalled();

    vi.advanceTimersByTime(1);
    expect(onShow).toHaveBeenCalledTimes(1);

    const secondShow = vi.fn();
    const cancelSecondTimer = scheduleHelpPopup(secondShow);
    cancelSecondTimer();
    vi.advanceTimersByTime(HELP_POPUP_DELAY_MS);
    expect(secondShow).not.toHaveBeenCalled();

    cancel();
    vi.useRealTimers();
  });

  it("uses the public contact route without a personal-reply or WhatsApp promise", () => {
    expect(HELP_POPUP_MESSAGE).toBe("সরকারি সেবার তথ্যের জন্য Contact পেজ ব্যবহার করুন");
    expect(HELP_POPUP_BUTTON_LABEL).toBe("যোগাযোগ পেজে যান");
    expect(HELP_POPUP_CONTACT_ROUTE).toBe("/contact");
    expect(popupSource).not.toContain("wa.me/");
    expect(popupSource).not.toContain("01965177538");
  });

  it("keeps the legacy auto-open overlay disabled while preserving the closed reserve wrapper", () => {
    expect(HELP_POPUP_AUTO_OPEN_ENABLED).toBe(false);
    expect(popupSource).toContain("if (!HELP_POPUP_AUTO_OPEN_ENABLED) return;");
  });

  it("keeps a permanent fixed reserve wrapper while the dialog remains closed until opened", () => {
    expect(popupSource).toContain("const [isOpen, setIsOpen] = useState(false)");
    expect(popupSource).toContain('className="help-popup-reserve"');
    expect(popupSource).toContain("{isOpen && (");
    expect(popupSource).toContain('aria-label="সহায়তা পপআপ বন্ধ করুন"');
    expect(popupSource).toContain("onClick={() => setIsOpen(false)}");
    expect(popupSource).toContain('data-testid="help-popup-contact"');
  });

  it("defines mobile safe-area offsets and hero aspect-ratio reservation", () => {
    const stylesheetSource = readFileSync(new URL("../index.css", import.meta.url), "utf8");
    expect(stylesheetSource).toContain(".help-popup-reserve");
    expect(stylesheetSource).toContain("env(safe-area-inset-bottom)");
    expect(stylesheetSource).toContain("aspect-ratio: 960 / 430");
  });
});
