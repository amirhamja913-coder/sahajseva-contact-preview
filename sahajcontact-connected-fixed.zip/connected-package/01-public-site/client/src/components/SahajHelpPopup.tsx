import { useEffect, useState } from "react";
import { MessageCircle, X } from "lucide-react";
import { Link } from "wouter";
import { trackEvent } from "@/lib/analytics";

export const HELP_POPUP_DELAY_MS = 10_000;
export const HELP_POPUP_AUTO_OPEN_ENABLED = false;
export const HELP_POPUP_MESSAGE = "সরকারি সেবার তথ্যের জন্য Contact পেজ ব্যবহার করুন";
export const HELP_POPUP_BUTTON_LABEL = "যোগাযোগ পেজে যান";
export const HELP_POPUP_CONTACT_ROUTE = "/contact";

export function scheduleHelpPopup(onShow: () => void) {
  const timer = globalThis.setTimeout(onShow, HELP_POPUP_DELAY_MS);
  return () => globalThis.clearTimeout(timer);
}

export default function SahajHelpPopup() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!HELP_POPUP_AUTO_OPEN_ENABLED) return;
    return scheduleHelpPopup(() => setIsOpen(true));
  }, []);

  const handleContactClick = () => {
    trackEvent("contact_route_click", { button_location: "help_popup" });
  };

  return (
    <div className="help-popup-reserve" data-testid="help-popup-reserve">
      {isOpen && (
        <aside
          className="help-popup-panel rounded-2xl border border-[#b9e5db] bg-[#f7fffc] p-4 text-[#103f43] shadow-[0_18px_60px_rgba(16,63,67,0.24)]"
          role="dialog"
      aria-label="তথ্য সহায়তা"
      aria-live="polite"
      data-testid="help-popup"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#d8f7ed] text-[#087f5b]" aria-hidden="true">
            <MessageCircle size={19} fill="currentColor" />
          </span>
          <span className="text-xs font-bold uppercase tracking-[0.12em] text-[#087f5b]">সহজ সহায়তা</span>
        </div>
        <button
          type="button"
          className="-mr-1 -mt-1 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[#527174] transition-colors hover:bg-[#e6f4ef] hover:text-[#103f43] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#087f5b] active:scale-95"
          aria-label="সহায়তা পপআপ বন্ধ করুন"
          onClick={() => setIsOpen(false)}
        >
          <X size={18} aria-hidden="true" />
        </button>
      </div>

      <p className="mt-3 text-base font-semibold leading-7 text-[#103f43]">{HELP_POPUP_MESSAGE}</p>

      <Link
        className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#087f5b] px-4 py-3 text-sm font-bold text-white shadow-[0_8px_20px_rgba(8,127,91,0.2)] transition-all hover:bg-[#066b4d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#087f5b] focus-visible:ring-offset-2 active:scale-[0.98]"
        href={HELP_POPUP_CONTACT_ROUTE}
        aria-label={HELP_POPUP_BUTTON_LABEL}
        data-testid="help-popup-contact"
        onClick={handleContactClick}
      >
        <MessageCircle size={19} fill="currentColor" aria-hidden="true" />
        <span>{HELP_POPUP_BUTTON_LABEL}</span>
      </Link>
        </aside>
      )}
    </div>
  );
}
