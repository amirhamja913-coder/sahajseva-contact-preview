export default function SahajPageSkeleton() {
  return (
    <div className="page-skeleton" role="status" aria-live="polite" aria-busy="true" aria-label="পৃষ্ঠা লোড হচ্ছে">
      <span className="sr-only">পৃষ্ঠা লোড হচ্ছে…</span>

      <header className="page-skeleton-header" aria-hidden="true">
        <div className="skeleton-shimmer page-skeleton-logo" />
        <div className="page-skeleton-nav">
          <div className="skeleton-shimmer page-skeleton-nav-item" />
          <div className="skeleton-shimmer page-skeleton-nav-item page-skeleton-nav-item-wide" />
          <div className="skeleton-shimmer page-skeleton-nav-item" />
        </div>
        <div className="skeleton-shimmer page-skeleton-menu" />
      </header>

      <main className="page-skeleton-main" aria-hidden="true">
        <section className="page-skeleton-hero">
          <div className="page-skeleton-hero-copy">
            <div className="skeleton-shimmer page-skeleton-eyebrow" />
            <div className="skeleton-shimmer page-skeleton-title" />
            <div className="skeleton-shimmer page-skeleton-title page-skeleton-title-short" />
            <div className="skeleton-shimmer page-skeleton-paragraph" />
            <div className="skeleton-shimmer page-skeleton-paragraph page-skeleton-paragraph-short" />
            <div className="page-skeleton-actions">
              <div className="skeleton-shimmer page-skeleton-button" />
              <div className="skeleton-shimmer page-skeleton-button page-skeleton-button-secondary" />
            </div>
          </div>
          <div className="skeleton-shimmer page-skeleton-hero-art" />
        </section>

        <section className="page-skeleton-finder">
          <div className="skeleton-shimmer page-skeleton-section-label" />
          <div className="skeleton-shimmer page-skeleton-search" />
        </section>

        <section className="page-skeleton-cards">
          <div className="skeleton-shimmer page-skeleton-card" />
          <div className="skeleton-shimmer page-skeleton-card" />
          <div className="skeleton-shimmer page-skeleton-card" />
        </section>
      </main>
    </div>
  );
}
