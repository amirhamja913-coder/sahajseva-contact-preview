import { useEffect, useState } from "react";

const LOGO_SRC = "/manus-storage/sahajseva-logo-optimized_3ff0d912.webp";

const isStandaloneDisplay = () =>
  window.matchMedia("(display-mode: standalone)").matches ||
  ("standalone" in navigator && Boolean((navigator as Navigator & { standalone?: boolean }).standalone));

export default function SahajSplashScreen() {
  const [isStandalone, setIsStandalone] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const standalone = isStandaloneDisplay();
    setIsStandalone(standalone);

    if (!standalone) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const displayDuration = reducedMotion ? 260 : 980;
    const exitDelay = Math.max(120, displayDuration - 220);

    setIsVisible(true);
    const exitTimer = window.setTimeout(() => setIsExiting(true), exitDelay);
    const hideTimer = window.setTimeout(() => setIsVisible(false), displayDuration);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(hideTimer);
    };
  }, []);

  if (!isStandalone || !isVisible) return null;

  return (
    <div
      className={`sahaj-splash-screen${isExiting ? " is-exiting" : ""}`}
      role="status"
      aria-live="polite"
      aria-label="সহজসেবা লোড হচ্ছে"
    >
      <div className="sahaj-splash-card">
        <div className="sahaj-splash-orbit" aria-hidden="true">
          <span className="sahaj-splash-orbit-ring sahaj-splash-orbit-ring-one" />
          <span className="sahaj-splash-orbit-ring sahaj-splash-orbit-ring-two" />
          <img src={LOGO_SRC} alt="" width={84} height={84} className="sahaj-splash-logo" />
        </div>
        <p className="sahaj-splash-kicker">বাংলাদেশ কর্তৃক নাগরিক সহায়তা</p>
        <h1>সহজসেবা</h1>
        <p className="sahaj-splash-tagline">সহজ জনসেবা, সবার জন্য</p>
        <div className="sahaj-splash-route" aria-hidden="true">
          <span className="sahaj-splash-route-line" />
          <span className="sahaj-splash-route-pin" />
        </div>
        <span className="sahaj-splash-loading">সেবা প্রস্তুত হচ্ছে...</span>
      </div>
    </div>
  );
}
