import { useState } from "react";
import { ImageUp, Link2, Save, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

type QuickLink = {
  id: number;
  titleBn: string;
  titleEn: string | null;
  url: string;
  descriptionBn: string | null;
  descriptionEn: string | null;
  iconName: string;
  iconImageUrl: string | null;
  openInNewTab: number;
  visible: number;
  displayOrder: number;
};

async function fileToDataUrl(file: File) {
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি।"));
    reader.readAsDataURL(file);
  });
}

export function ServiceCardAssetManager({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const workspace = trpc.siteManagement.getOwnerWorkspace.useQuery(undefined, { enabled: isOwner, retry: false });
  const utils = trpc.useUtils();
  const upload = trpc.gallery.uploadBase64.useMutation();
  const [message, setMessage] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);
  const update = trpc.siteManagement.updateQuickLink.useMutation({
    onSuccess: async () => {
      await Promise.all([workspace.refetch(), utils.siteManagement.getPublicContent.invalidate()]);
      setMessage(language === "EN" ? "Service-card icon saved and published." : "সার্ভিস কার্ডের আইকন সংরক্ষণ ও প্রকাশ হয়েছে।");
    },
    onError: (error) => setMessage(error.message),
    onSettled: () => setBusyId(null),
  });
  const cards = (workspace.data?.quickLinks ?? []) as QuickLink[];

  const saveImage = async (card: QuickLink, imageUrl: string | null) => {
    setBusyId(card.id);
    update.mutate({
      id: card.id,
      titleBn: card.titleBn,
      titleEn: card.titleEn,
      url: card.url,
      descriptionBn: card.descriptionBn,
      descriptionEn: card.descriptionEn,
      iconName: card.iconName,
      iconImageUrl: imageUrl,
      openInNewTab: card.openInNewTab === 1,
      visible: card.visible === 1,
      displayOrder: card.displayOrder,
    });
  };

  const chooseFile = async (card: QuickLink, file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setMessage(language === "EN" ? "Choose an image file." : "একটি image ফাইল নির্বাচন করুন।");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setMessage(language === "EN" ? "Icon image must be 5 MB or smaller." : "আইকন ছবি সর্বোচ্চ ৫ MB হতে পারবে।");
      return;
    }
    setBusyId(card.id);
    try {
      const uploaded = await upload.mutateAsync({
        base64Data: await fileToDataUrl(file),
        fileName: `cms/service-card-icon-${card.id}-${Date.now()}-${file.name.replace(/[^a-z0-9._-]/gi, "-")}`,
        contentType: file.type,
      });
      await saveImage(card, uploaded.url);
    } catch (error) {
      setBusyId(null);
      setMessage(error instanceof Error ? error.message : "Upload failed");
    }
  };

  return <section className="rounded-2xl border border-sky-500/25 bg-slate-900 p-5 shadow-xl sm:p-6">
    <div className="flex items-start gap-3"><ImageUp className="mt-0.5 h-5 w-5 text-sky-300" /><div><h2 className="text-xl font-bold text-white">{language === "EN" ? "Service Card Icon Upload" : "সার্ভিস কার্ড আইকন আপলোড"}</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-slate-400">{language === "EN" ? "Upload an optional image icon for each existing service card. The existing icon name remains the fallback when no image is set." : "প্রতিটি বিদ্যমান সার্ভিস কার্ডের জন্য ঐচ্ছিক image icon আপলোড করুন। ছবি না থাকলে বর্তমান icon name স্বয়ংক্রিয়ভাবে fallback হিসেবে থাকবে।"}</p></div></div>
    {message && <p className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-100">{message}</p>}
    <div className="mt-5 grid gap-3 lg:grid-cols-2">
      {cards.map((card) => <article key={card.id} className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/50 p-3">
        {card.iconImageUrl ? <img src={card.iconImageUrl} alt="" className="h-12 w-12 rounded-lg object-cover" /> : <span className="grid h-12 w-12 place-items-center rounded-lg bg-sky-500/10 text-sky-200"><Link2 className="h-5 w-5" /></span>}
        <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold text-white">{language === "EN" ? card.titleEn || card.titleBn : card.titleBn}</p><p className="truncate text-xs text-slate-500">{card.iconImageUrl ? "Uploaded icon" : `Fallback: ${card.iconName}`}</p></div>
        <label className="cursor-pointer rounded-lg border border-sky-400/35 px-2.5 py-2 text-xs font-bold text-sky-100"><ImageUp className="mr-1 inline h-3.5 w-3.5" />{busyId === card.id ? "…" : language === "EN" ? "Upload" : "আপলোড"}<input className="hidden" type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={(event) => chooseFile(card, event.target.files?.[0])} /></label>
        {card.iconImageUrl && <button type="button" disabled={busyId === card.id || update.isPending} onClick={() => saveImage(card, null)} className="rounded-lg border border-rose-500/35 px-2.5 py-2 text-xs font-bold text-rose-200"><Trash2 className="mr-1 inline h-3.5 w-3.5" />{language === "EN" ? "Remove" : "সরান"}</button>}
      </article>)}
    </div>
    {!cards.length && <p className="mt-4 rounded-xl border border-dashed border-slate-700 p-4 text-sm text-slate-400">{language === "EN" ? "Add a service card in Homepage Builder first." : "আগে Homepage Builder থেকে একটি সার্ভিস কার্ড যোগ করুন।"}</p>}
  </section>;
}
