import { readFileSync } from "node:fs";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("ServiceChecklistModal public-safety contract", () => {
  const source = readFileSync("client/src/components/ServiceChecklistModal.tsx", "utf8");

  it("keeps the core government-service preparation guidance", () => {
    expect(source).toContain("সরকারি বা যাচাইকৃত অফিসিয়াল নির্দেশনা");
    expect(source).toContain("অফিসিয়াল ওয়েবসাইট, হেল্পলাইন বা অফিস");
  });

  it("does not create an order, payment, phone, or credential collection flow", () => {
    expect(source).toContain("কোনো আবেদন গ্রহণ, অর্ডার, পেমেন্ট বা পরিচয় যাচাই করে না");
    expect(source).toContain("পাসওয়ার্ড, OTP, transaction ID বা পেমেন্ট তথ্য এই portal-এ দেবেন না");
    expect(source).not.toContain("sendToWhatsApp");
    expect(source).not.toContain("customerName");
    expect(source).not.toContain("customerPhone");
    expect(source).not.toContain("সহায়তা ফি:");
  });
});
