import { useState } from "react";
import { Check, ClipboardList, ShieldAlert, X } from "lucide-react";

const CHECKLIST_ITEMS = [
  "সেবার জন্য প্রয়োজনীয় কাগজপত্র ও তথ্য আগে যাচাই করুন।",
  "শুধু সংশ্লিষ্ট সরকারি বা যাচাইকৃত অফিসিয়াল নির্দেশনা অনুসরণ করুন।",
  "আবেদন বা ফি–সংক্রান্ত তথ্য সংশ্লিষ্ট প্রতিষ্ঠানের অফিসিয়াল মাধ্যমে নিশ্চিত করুন।",
  "কোনো ব্যক্তিগত নম্বর, পাসওয়ার্ড, OTP, transaction ID বা পেমেন্ট তথ্য এই portal-এ দেবেন না।",
];

interface ServiceChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceName?: string;
}

export default function ServiceChecklistModal({
  isOpen,
  onClose,
  serviceName = "সেবা",
}: ServiceChecklistModalProps) {
  const [checked, setChecked] = useState<boolean[]>(() => CHECKLIST_ITEMS.map(() => false));

  if (!isOpen) return null;

  const completed = checked.every(Boolean);

  const toggleItem = (index: number) => {
    setChecked((current) => current.map((item, itemIndex) => (itemIndex === index ? !item : item)));
  };

  const closeAndReset = () => {
    setChecked(CHECKLIST_ITEMS.map(() => false));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-950/65 p-3 sm:items-center" role="presentation">
      <section
        aria-labelledby="service-checklist-title"
        aria-modal="true"
        role="dialog"
        className="w-full max-w-lg overflow-hidden rounded-[2rem] border border-teal-100 bg-white shadow-2xl"
      >
        <header className="flex items-start justify-between gap-4 bg-gradient-to-r from-teal-700 to-cyan-700 px-5 py-5 text-white">
          <div className="flex gap-3">
            <ClipboardList className="mt-1 h-6 w-6 shrink-0" aria-hidden="true" />
            <div>
              <p className="text-xs font-semibold tracking-[0.16em] text-teal-100">প্রস্তুতি নির্দেশনা</p>
              <h2 id="service-checklist-title" className="mt-1 text-xl font-bold">{serviceName}</h2>
            </div>
          </div>
          <button
            type="button"
            onClick={closeAndReset}
            className="rounded-full p-2 text-white transition hover:bg-white/15 focus:outline-none focus:ring-2 focus:ring-white"
            aria-label="নির্দেশনা বন্ধ করুন"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </header>

        <div className="space-y-4 px-5 py-5">
          <p className="text-sm leading-6 text-slate-600">
            নিচের বিষয়গুলো দেখে নিন। এটি কেবল তথ্য ও প্রস্তুতি সহায়তা; SahajContact কোনো আবেদন গ্রহণ, অর্ডার, পেমেন্ট বা পরিচয় যাচাই করে না।
          </p>

          <ul className="space-y-3">
            {CHECKLIST_ITEMS.map((item, index) => (
              <li key={item}>
                <button
                  type="button"
                  onClick={() => toggleItem(index)}
                  className={`flex w-full items-start gap-3 rounded-2xl border p-3 text-left transition focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    checked[index]
                      ? "border-teal-300 bg-teal-50 text-teal-950"
                      : "border-slate-200 bg-slate-50 text-slate-700 hover:border-teal-200"
                  }`}
                >
                  <span
                    className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                      checked[index] ? "border-teal-600 bg-teal-600 text-white" : "border-slate-300 bg-white"
                    }`}
                    aria-hidden="true"
                  >
                    {checked[index] ? <Check className="h-3.5 w-3.5" /> : null}
                  </span>
                  <span className="text-sm leading-6">{item}</span>
                </button>
              </li>
            ))}
          </ul>

          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-sm leading-6 text-amber-950">
            <div className="flex gap-2">
              <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
              <p>
                ফি, আবেদন বা অ্যাকাউন্ট–সংক্রান্ত কাজের জন্য শুধু সংশ্লিষ্ট প্রতিষ্ঠানের অফিসিয়াল ওয়েবসাইট, হেল্পলাইন বা অফিস ব্যবহার করুন।
              </p>
            </div>
          </div>

          <div className="flex flex-col-reverse gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:justify-between">
            <p className="text-xs leading-5 text-slate-500">
              {completed ? "সব নির্দেশনা দেখা হয়েছে।" : "প্রয়োজনে প্রতিটি নির্দেশনায় ট্যাপ করে দেখে নিন।"}
            </p>
            <button
              type="button"
              onClick={closeAndReset}
              className="rounded-xl bg-teal-700 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2"
            >
              বুঝেছি
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
