import { lazy, useMemo, useState } from "react";
import { Filter, Loader2, MessageCircle, Send, Sparkles, Star, ArrowUpDown } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export type ServiceReview = {
  id: number;
  serviceId: string;
  serviceName: string;
  rating: number;
  comment: string;
  createdAt: Date;
};

type ServiceReviewsProps = {
  serviceId: string;
  serviceName: string;
  reviews: ServiceReview[];
  isLoading?: boolean;
  hasError?: boolean;
};

function formatReviewDate(value: Date) {
  return new Intl.DateTimeFormat("bn-BD", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(value));
}

function formatAverage(value: number) {
  return value.toLocaleString("bn-BD", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  });
}

export default function ServiceReviews({ serviceId, serviceName, reviews, isLoading = false, hasError = false }: ServiceReviewsProps) {
  const { isAuthenticated } = useAuth();
  const isSiteWide = serviceId === "00";
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [formError, setFormError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [sortBy, setSortBy] = useState<"newest" | "highest" | "lowest">("newest");
  const [filterStar, setFilterStar] = useState<number | "all">("all");
  const [showAllReviews, setShowAllReviews] = useState(false);
  const utils = trpc.useUtils();

  const averageRating = useMemo(() => {
    if (reviews.length === 0) return 0;
    return reviews.reduce((total, review) => total + review.rating, 0) / reviews.length;
  }, [reviews]);

  const filteredAndSortedReviews = useMemo(() => {
    let result = [...reviews];

    // Filter by star rating
    if (filterStar !== "all") {
      result = result.filter(r => r.rating === filterStar);
    }

    // Sort
    result.sort((a, b) => {
      if (sortBy === "newest") {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === "highest") {
        return b.rating - a.rating || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === "lowest") {
        return a.rating - b.rating || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      return 0;
    });

    return result;
  }, [reviews, sortBy, filterStar]);

  const latestReview = useMemo(() => [...reviews]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 1), [reviews]);

  const visibleReviews = showAllReviews ? filteredAndSortedReviews : latestReview;

  const submitReview = trpc.reviews.submit.useMutation({
    onSuccess: async () => {
      setRating(0);
      setComment("");
      setFormError("");
      setSuccessMessage("আপনার মতামত জমা হয়েছে। অনুমোদনের পর এটি সবার জন্য দেখা যাবে।");
      await utils.reviews.listApproved.invalidate();
    },
    onError: error => {
      setSuccessMessage("");
      setFormError(error.message);
    },
  });

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError("");
    setSuccessMessage("");

    if (!isAuthenticated) {
      setFormError("মতামত জমা দেওয়ার জন্য যাচাইকৃত অ্যাকাউন্ট প্রয়োজন। এই পোর্টাল ফোন নম্বর, OTP বা পাসওয়ার্ড নেয় না।");
      return;
    }

    if (rating === 0) {
      setFormError("দয়া করে ১ থেকে ৫ তারকা বেছে নিন।");
      return;
    }

    const trimmedComment = comment.trim();
    if (trimmedComment.length < 5) {
      setFormError("কমপক্ষে ৫ অক্ষরের মতামত লিখুন।");
      return;
    }

    submitReview.mutate({
      serviceId,
      serviceName,
      rating,
      comment: trimmedComment,
    });
  };

  return (
    <div className={`service-reviews${isSiteWide ? " site-wide-reviews" : ""}`} aria-labelledby={`reviews-heading-${serviceId}`}>
      <div className="service-reviews-heading">
        <div>
          <span className="service-reviews-kicker"><MessageCircle size={13} aria-hidden="true" /> {isSiteWide ? "সাইটব্যাপী গ্রাহকের মতামত" : "গ্রাহকের মতামত"}</span>
          <h4 id={`reviews-heading-${serviceId}`}>{isSiteWide ? "সাহজসেবা সম্পর্কে আপনার অভিজ্ঞতা লিখুন" : "এই সেবা নিয়ে অভিজ্ঞতা লিখুন"}</h4>
        </div>
        {reviews.length > 0 && (
          <div className="service-review-summary" aria-label={`${formatAverage(averageRating)} out of 5, ${reviews.length} reviews`}>
            <span className="service-review-summary-stars" aria-hidden="true">
              {Array.from({ length: 5 }, (_, index) => (
                <Star key={index} size={14} fill={index < Math.round(averageRating) ? "currentColor" : "none"} />
              ))}
            </span>
            <strong>{formatAverage(averageRating)} / ৫</strong>
            <span>{reviews.length.toLocaleString("bn-BD")}টি অনুমোদিত মতামত</span>
          </div>
        )}
      </div>

      {reviews.length > 0 && showAllReviews && (
        <div className="service-review-controls" style={{ display: "flex", flexWrap: "wrap", gap: "10px", alignItems: "center", justifyContent: "space-between", marginBottom: "16px", padding: "10px 14px", background: "#f8fafc", borderRadius: "10px", border: "1px solid #e2e8f0" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "14px", color: "#334155" }}>
            <ArrowUpDown size={15} style={{ color: "#006A4E" }} />
            <span>সর্ট করুন:</span>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              style={{ padding: "6px 10px", borderRadius: "6px", border: "1px solid #cbd5e1", background: "#fff", fontSize: "13px", fontWeight: "500", cursor: "pointer" }}
              aria-label="মতামত সর্ট করার অপশন"
            >
              <option value="newest">নতুনতম (Newest)</option>
              <option value="highest">সর্বোচ্চ রেটিং (Highest Rating)</option>
              <option value="lowest">সর্বনিম্ন রেটিং (Lowest Rating)</option>
            </select>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "14px", color: "#334155" }}>
            <Filter size={15} style={{ color: "#006A4E" }} />
            <span>তারকা ফিল্টার:</span>
            <select
              value={filterStar}
              onChange={e => setFilterStar(e.target.value === "all" ? "all" : Number(e.target.value))}
              style={{ padding: "6px 10px", borderRadius: "6px", border: "1px solid #cbd5e1", background: "#fff", fontSize: "13px", fontWeight: "500", cursor: "pointer" }}
              aria-label="তারকা অনুযায়ী মতামত ফিল্টার"
            >
              <option value="all">সব তারকা (All)</option>
              <option value="5">৫ তারকা (5 Stars)</option>
              <option value="4">৪ তারকা (4 Stars)</option>
              <option value="3">৩ তারকা (3 Stars)</option>
              <option value="2">২ তারকা (2 Stars)</option>
              <option value="1">১ তারকা (1 Star)</option>
            </select>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="service-review-empty" role="status" aria-live="polite">
          <Loader2 size={18} className="animate-spin" aria-hidden="true" />
          <p>মতামত লোড হচ্ছে...</p>
        </div>
      ) : hasError ? (
        <div className="service-review-empty error" role="status" aria-live="polite">
          <MessageCircle size={18} aria-hidden="true" />
          <p>মতামত এখন লোড করা যাচ্ছে না। পরে আবার চেষ্টা করুন।</p>
        </div>
      ) : reviews.length === 0 ? (
        <div className="service-review-empty" role="status">
          <MessageCircle size={18} aria-hidden="true" />
          <p>{isSiteWide ? "এখনও কোনো অনুমোদিত সাইটব্যাপী মতামত নেই। আপনার বাস্তব অভিজ্ঞতা দিয়ে প্রথম মতামতটি লিখুন।" : "এখনও কোনো অনুমোদিত মতামত নেই। আপনার অভিজ্ঞতা দিয়ে প্রথম মতামতটি লিখুন।"}</p>
        </div>
      ) : visibleReviews.length === 0 ? (
        <div className="service-review-empty" role="status">
          <MessageCircle size={18} aria-hidden="true" />
          <p>এই ফিল্টারের সাথে মিলে যায় এমন কোনো মতামত পাওয়া যায়নি। অন্য ফিল্টার বা "সব তারকা" সিলেক্ট করুন।</p>
        </div>
      ) : (
        <div className="service-review-list" aria-label={`${isSiteWide ? "সাহজসেবা পোর্টালের" : serviceName + " এর"} অনুমোদিত মতামত`}>
          {visibleReviews.map(review => (
            <article className="service-review-item" key={review.id}>
              <div className="service-review-item-top">
                <span className="service-review-item-stars" aria-label={`${review.rating} out of 5 stars`}>
                  {Array.from({ length: 5 }, (_, index) => (
                    <Star key={index} size={13} fill={index < review.rating ? "currentColor" : "none"} aria-hidden="true" />
                  ))}
                </span>
                <time dateTime={new Date(review.createdAt).toISOString()}>{formatReviewDate(review.createdAt)}</time>
              </div>
              <p>{review.comment}</p>
              <span className="service-review-author">গ্রাহক</span>
            </article>
          ))}
        </div>
      )}

      {reviews.length > 1 && (
        <button
          type="button"
          className="service-review-show-all"
          aria-expanded={showAllReviews}
          onClick={() => setShowAllReviews(value => !value)}
          style={{ marginTop: "0.85rem", minHeight: "2.65rem", padding: "0.6rem 0.9rem", border: "1px solid #006A4E", borderRadius: "999px", background: showAllReviews ? "#ffffff" : "#006A4E", color: showAllReviews ? "#006A4E" : "#ffffff", fontWeight: 800, cursor: "pointer" }}
        >
          {showAllReviews ? "সব মতামত লুকান" : `সব মতামত দেখুন (${reviews.length.toLocaleString("bn-BD")}টি)`}
        </button>
      )}

      <form className="service-review-form" onSubmit={handleSubmit}>
        <h5>আপনার মতামত বা অভিজ্ঞতা জানান</h5>
        <div className="service-review-star-select" role="group" aria-label="রেটিং নির্বাচন করুন">
          <span>রেটিং দিন:</span>
          <div style={{ display: "inline-flex", gap: "4px", cursor: "pointer" }}>
            {Array.from({ length: 5 }, (_, index) => {
              const starVal = index + 1;
              return (
                <button
                  type="button"
                  key={starVal}
                  onClick={() => setRating(starVal)}
                  style={{ background: "none", border: "none", padding: "2px", cursor: "pointer", color: starVal <= rating ? "#f59e0b" : "#cbd5e1" }}
                  aria-label={`${starVal} star`}
                >
                  <Star size={20} fill={starVal <= rating ? "currentColor" : "none"} />
                </button>
              );
            })}
          </div>
          <span style={{ fontSize: "13px", fontWeight: "600", color: "#475569" }}>{rating > 0 ? `${rating} / ৫` : "তারকা নির্বাচন করুন"}</span>
        </div>

        <div className="service-review-textarea-wrapper">
          <textarea
            value={comment}
            onChange={e => setComment(e.target.value)}
            placeholder="আপনার অভিজ্ঞতা এখানে লিখুন (কমপক্ষে ৫ অক্ষর)..."
            rows={3}
            maxLength={500}
            aria-label="মতামত লিখুন"
          />
        </div>

        {formError && <p className="service-review-error" role="alert">{formError}</p>}
        {successMessage && <p className="service-review-success" role="status">{successMessage}</p>}

        <div className="service-review-submit-row">
          <button type="submit" className="service-review-submit-btn" disabled={submitReview.isPending}>
            {submitReview.isPending ? <Loader2 size={16} className="animate-spin" /> : <Send size={15} />}
            <span>{submitReview.isPending ? "জমা হচ্ছে..." : "মতামত জমা দিন"}</span>
          </button>
          <span className="service-review-disclaimer">বাস্তব অভিজ্ঞতা শেয়ার করুন। যাচাইয়ের পর প্রকাশিত হবে। OTP, পাসওয়ার্ড বা payment তথ্য লিখবেন না।</span>
        </div>
      </form>
    </div>
  );
}
