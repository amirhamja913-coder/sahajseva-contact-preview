import { describe, expect, it } from "vitest";
import {
  buildCampaignUrl,
  buildFacebookShareUrl,
  buildShareText,
  buildWhatsAppShareUrl,
} from "./ServiceShareButton";

describe("ServiceShareButton share destinations", () => {
  const title = "জাতীয় পরিচয়পত্র (NID)";
  const url = "https://services.nidw.gov.bd/?source=sahaj seva";

  it("builds Bengali share text with the service and official link", () => {
    const text = buildShareText(title, url);

    expect(text).toContain(title);
    expect(text).toContain("অফিসিয়াল ও সহায়ক লিংক:");
    expect(text).toContain(url);
  });

  it("builds an encoded WhatsApp share URL", () => {
    const shareUrl = buildWhatsAppShareUrl(title, url);
    const parsed = new URL(shareUrl);

    expect(parsed.origin).toBe("https://api.whatsapp.com");
    expect(parsed.pathname).toBe("/send");
    expect(parsed.searchParams.get("text")).toContain(title);
    expect(parsed.searchParams.get("text")).toContain(url);
  });

  it("builds an encoded Facebook share URL for the exact service destination", () => {
    const shareUrl = buildFacebookShareUrl(url);
    const parsed = new URL(shareUrl);

    expect(parsed.origin).toBe("https://www.facebook.com");
    expect(parsed.pathname).toBe("/sharer/sharer.php");
    expect(parsed.searchParams.get("u")).toBe(url);
  });

  it("adds campaign parameters without discarding an existing query string", () => {
    const campaignUrl = buildCampaignUrl("https://sahajcontact-8xyxsefc.manus.space/#service-1", "whatsapp");
    const parsed = new URL(campaignUrl);

    expect(parsed.hash).toBe("#service-1");
    expect(parsed.searchParams.get("utm_source")).toBe("whatsapp");
    expect(parsed.searchParams.get("utm_medium")).toBe("social");
    expect(parsed.searchParams.get("utm_campaign")).toBe("service_share");
  });
});
