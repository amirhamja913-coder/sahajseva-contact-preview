import React, { useState, useRef, useEffect } from "react";
import { Share2, Check, MessageCircle, Facebook, Link as LinkIcon, Sparkles } from "lucide-react";
import { trackEvent } from "@/lib/analytics";

interface ServiceShareButtonProps {
  title: string;
  url?: string;
  shareUrl?: string;
  description?: string;
}

export const buildShareText = (
  title: string,
  url: string,
  description = "সহজ জনসেবা — সরকারি সেবা ও সহায়তা",
) => `${title} — ${description}\nঅফিসিয়াল ও সহায়ক লিংক: ${url}`;

export const buildWhatsAppShareUrl = (title: string, url: string, description?: string) =>
  `https://api.whatsapp.com/send?text=${encodeURIComponent(buildShareText(title, url, description))}`;

export const buildFacebookShareUrl = (url: string) =>
  `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;

export const buildCampaignUrl = (url: string, source: string) => {
  const target = new URL(url, "https://sahajcontact-8xyxsefc.manus.space");
  target.searchParams.set("utm_source", source);
  target.searchParams.set("utm_medium", "social");
  target.searchParams.set("utm_campaign", "service_share");
  return target.toString();
};

export const ServiceShareButton: React.FC<ServiceShareButtonProps> = ({
  title,
  url = typeof window !== "undefined" ? window.location.href : "https://sahajcontact-8xyxsefc.manus.space",
  shareUrl,
  description = "সহজ জনসেবা — সরকারি সেবা ও সহায়তা",
}) => {
  const [copied, setCopied] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const shareTarget = shareUrl ?? url;

  const handleWhatsAppShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    const campaignUrl = buildCampaignUrl(shareTarget, "whatsapp");
    trackEvent("social_share_click", {
      platform: "whatsapp",
      campaign_source: "whatsapp",
      campaign_medium: "social",
      campaign_name: "service_share",
      content_type: "service",
      item_name: title,
    });
    window.open(buildWhatsAppShareUrl(title, campaignUrl, description), "_blank", "noopener,noreferrer");
    setIsOpen(false);
  };

  const handleFacebookShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    const campaignUrl = buildCampaignUrl(shareTarget, "facebook");
    trackEvent("social_share_click", {
      platform: "facebook",
      campaign_source: "facebook",
      campaign_medium: "social",
      campaign_name: "service_share",
      content_type: "service",
      item_name: title,
    });
    window.open(buildFacebookShareUrl(campaignUrl), "_blank", "noopener,noreferrer");
    setIsOpen(false);
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    const targetUrl = buildCampaignUrl(shareTarget, "copy_link");
    trackEvent("social_share_click", {
      platform: "copy_link",
      campaign_source: "copy_link",
      campaign_medium: "social",
      campaign_name: "service_share",
      content_type: "service",
      item_name: title,
    });
    navigator.clipboard.writeText(targetUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      prompt("লিংক কপি করুন:", targetUrl);
    });
    setIsOpen(false);
  };

  const handleToggleMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsOpen((prev) => !prev);
  };

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={handleToggleMenu}
        title="সেবাটি শেয়ার করুন"
        aria-label={`${title} শেয়ার করুন`}
        aria-haspopup="menu"
        aria-expanded={isOpen}
        className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 active:scale-95 rounded-md border border-emerald-200 transition-all duration-150 shadow-xs group"
      >
        <Share2 className="w-3.5 h-3.5 text-emerald-600 transition-transform group-hover:rotate-12" />
        <span>শেয়ার</span>
      </button>

      {isOpen && (
        <div
          role="menu"
          className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50 transform origin-top-right transition-all animate-in fade-in zoom-in-95 duration-150 ring-1 ring-black/5"
        >
          <div className="px-3.5 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100 mb-1 flex items-center justify-between">
            <span>শেয়ার অপশন</span>
            <Sparkles className="w-3 h-3 text-emerald-500 animate-pulse" />
          </div>

          <button
            role="menuitem"
            onClick={handleWhatsAppShare}
            className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-emerald-50/80 hover:text-emerald-900 flex items-center gap-2.5 transition-all duration-150 group"
          >
            <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0 transition-transform group-hover:scale-110">
              <MessageCircle className="w-4 h-4 fill-emerald-600 text-white" />
            </div>
            <div>
              <div className="font-medium">WhatsApp এ পাঠান</div>
              <div className="text-[10px] text-slate-400">সরাসরি চ্যাটে শেয়ার করুন</div>
            </div>
          </button>

          <button
            role="menuitem"
            onClick={handleFacebookShare}
            className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-blue-50/80 hover:text-blue-900 flex items-center gap-2.5 transition-all duration-150 group"
          >
            <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0 transition-transform group-hover:scale-110">
              <Facebook className="w-4 h-4 fill-blue-600 text-white" />
            </div>
            <div>
              <div className="font-medium">Facebook এ শেয়ার</div>
              <div className="text-[10px] text-slate-400">নিউজফিডে পোস্ট করুন</div>
            </div>
          </button>

          <div className="border-t border-slate-100 my-1 pt-1" />

          <button
            role="menuitem"
            onClick={handleCopyLink}
            className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 transition-all duration-150 group"
          >
            {copied ? (
              <>
                <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                  <Check className="w-4 h-4 text-emerald-600" />
                </div>
                <div>
                  <div className="font-medium text-emerald-600">সফলভাবে কপি হয়েছে!</div>
                  <div className="text-[10px] text-emerald-500">লিংক ক্লিপবোর্ডে সংরক্ষিত</div>
                </div>
              </>
            ) : (
              <>
                <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center shrink-0 transition-transform group-hover:scale-110">
                  <LinkIcon className="w-4 h-4 text-slate-500" />
                </div>
                <div>
                  <div className="font-medium">লিংক কপি করুন</div>
                  <div className="text-[10px] text-slate-400">ক্লিপবোর্ডে লিংক নিন</div>
                </div>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
