import { useEffect, useMemo, useState } from "react";
import { Eye, ImagePlus, RotateCcw, Save, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";
import { PUBLIC_THEME_SCOPES, parsePublicThemeOverrides, type PublicThemeScopeKey } from "@shared/publicTheme";

type ScopedThemeDraft = { backgroundImageUrl: string; backgroundColor: string; overlayOpacity: number };

const controlClass = "mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none transition focus:border-emerald-400";

function makeDraft(baseColor: string, value?: Partial<ScopedThemeDraft>): ScopedThemeDraft {
  return { backgroundImageUrl: value?.backgroundImageUrl ?? "", backgroundColor: value?.backgroundColor ?? baseColor, overlayOpacity: value?.overlayOpacity ?? 0.84 };
}

async function asDataUrl(file: File) {
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি।"));
    reader.readAsDataURL(file);
  });
}

export function ThemeBackgroundManager({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const utils = trpc.useUtils();
  const workspace = trpc.siteManagement.getOwnerWorkspace.useQuery(undefined, { enabled: isOwner, retry: false });
  const upload = trpc.gallery.uploadBase64.useMutation();
  const [scopeKey, setScopeKey] = useState<PublicThemeScopeKey>("home");
  const [draft, setDraft] = useState<ScopedThemeDraft>(() => makeDraft("#f3faf6"));
  const [message, setMessage] = useState("");
  const baseColor = workspace.data?.settings?.pageBackgroundColor ?? "#f3faf6";
  const overrides = useMemo(() => parsePublicThemeOverrides(workspace.data?.settings?.themeBackgroundOverridesJson), [workspace.data?.settings?.themeBackgroundOverridesJson]);
  const selectedScope = PUBLIC_THEME_SCOPES.find(scope => scope.key === scopeKey) ?? PUBLIC_THEME_SCOPES[0];
  const selectedOverride = overrides[scopeKey];

  useEffect(() => {
    setDraft(makeDraft(baseColor, overrides[scopeKey]));
  }, [baseColor, overrides, scopeKey]);

  const refreshPublishedTheme = async () => {
    await Promise.all([workspace.refetch(), utils.siteManagement.getPublicContent.invalidate()]);
  };

  const saveTheme = trpc.siteManagement.saveScopedBackgroundTheme.useMutation({
    onSuccess: async () => {
      await refreshPublishedTheme();
      setMessage(language === "EN" ? "Selected page/menu background saved and published." : "নির্বাচিত পেজ/মেনুর ব্যাকগ্রাউন্ড সেভ হয়েছে এবং প্রকাশ হয়েছে।");
    },
    onError: error => setMessage(error.message),
  });
  const resetTheme = trpc.siteManagement.resetScopedBackgroundTheme.useMutation({
    onSuccess: async () => {
      await refreshPublishedTheme();
      setDraft(makeDraft(baseColor));
      setMessage(language === "EN" ? "Selected page/menu now uses the whole-site background again." : "নির্বাচিত পেজ/মেনু এখন আবার পুরো সাইটের ব্যাকগ্রাউন্ড ব্যবহার করবে।");
    },
    onError: error => setMessage(error.message),
  });

  const uploadImage = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      setMessage(language === "EN" ? "Please choose an image file." : "শুধু ছবি ফাইল দিন।");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setMessage(language === "EN" ? "Maximum image size is 10 MB." : "ছবির সর্বোচ্চ সাইজ ১০ MB।");
      return;
    }
    try {
      const safeName = file.name.replace(/[^a-z0-9._-]/gi, "-");
      const result = await upload.mutateAsync({
        base64Data: await asDataUrl(file),
        fileName: `cms/theme-${scopeKey}-background-${Date.now()}-${safeName}`,
        contentType: file.type,
      });
      setDraft(current => ({ ...current, backgroundImageUrl: result.url }));
      setMessage(language === "EN" ? "Image uploaded. Save to publish it." : "ছবি আপলোড হয়েছে। প্রকাশ করতে সেভ চাপুন।");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Upload failed");
    }
  };

  if (!isOwner) return null;

  return <section id="cms-theme-background-manager" className="scroll-mt-24 rounded-2xl border border-emerald-400/30 bg-slate-900 p-5 shadow-xl sm:p-6">
    <div className="flex items-start gap-3"><Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-emerald-300" /><div><h2 className="text-xl font-bold text-white">{language === "EN" ? "Theme & Background Manager" : "থিম ও ব্যাকগ্রাউন্ড ম্যানেজার"}</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-slate-400">{language === "EN" ? "Choose an approved public page/menu group, upload one managed image, and publish a readable background. Admin, dashboard and recovery routes are never available here." : "অনুমোদিত পাবলিক পেজ/মেনু গ্রুপ নির্বাচন করে একটি ম্যানেজড ছবি আপলোড করুন এবং পাঠযোগ্য ব্যাকগ্রাউন্ড প্রকাশ করুন। Admin, dashboard ও recovery route এখানে কখনো পাওয়া যাবে না।"}</p></div></div>
    {message && <p className="mt-4 rounded-xl border border-emerald-300/20 bg-emerald-950/35 px-4 py-3 text-sm text-emerald-50" role="status">{message}</p>}
    <div className="mt-5 grid gap-4 rounded-2xl border border-slate-800 bg-slate-950/45 p-4 sm:grid-cols-2">
      <label className="text-xs text-slate-300">{language === "EN" ? "Public page/menu group" : "পাবলিক পেজ/মেনু গ্রুপ"}<select className={controlClass} value={scopeKey} onChange={event => setScopeKey(event.target.value as PublicThemeScopeKey)}>{PUBLIC_THEME_SCOPES.map(scope => <option key={scope.key} value={scope.key}>{language === "EN" ? scope.labelEn : scope.labelBn}</option>)}</select></label>
      <div className="flex items-end"><a href={selectedScope.previewPath} target="_blank" rel="noopener noreferrer" className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-300/50 px-3 py-2.5 text-sm font-bold text-emerald-100 transition hover:border-emerald-300 hover:bg-emerald-400/10"><Eye className="h-4 w-4" />{language === "EN" ? "Open selected public page" : "নির্বাচিত পাবলিক পেজ দেখুন"}</a></div>
      <label className="text-xs text-slate-300">{language === "EN" ? "Background base color" : "ব্যাকগ্রাউন্ড বেস রঙ"}<span className="mt-1 flex items-center gap-2"><input type="color" className="h-10 w-12 cursor-pointer rounded-lg border border-slate-700 bg-slate-950 p-1" value={draft.backgroundColor} onChange={event => setDraft(current => ({ ...current, backgroundColor: event.target.value }))} /><input className={controlClass} value={draft.backgroundColor} onChange={event => setDraft(current => ({ ...current, backgroundColor: event.target.value }))} maxLength={7} /></span></label>
      <label className="text-xs text-slate-300">{language === "EN" ? "Readability overlay" : "পাঠযোগ্যতার overlay"}<select className={controlClass} value={String(draft.overlayOpacity)} onChange={event => setDraft(current => ({ ...current, overlayOpacity: Number(event.target.value) }))}><option value="0.72">72%</option><option value="0.8">80%</option><option value="0.84">84%</option><option value="0.9">90%</option><option value="0.94">94%</option></select></label>
      <div className="sm:col-span-2 rounded-xl border border-slate-800 bg-slate-900/70 p-3"><div className="flex flex-col gap-3 sm:flex-row sm:items-end"><div className="min-w-0 flex-1"><p className="text-xs text-slate-300">{language === "EN" ? "Managed background image" : "ম্যানেজড ব্যাকগ্রাউন্ড ছবি"}</p><p className="mt-1 truncate text-xs text-slate-500">{draft.backgroundImageUrl || (language === "EN" ? "Upload an image to create an override." : "Override দিতে একটি ছবি আপলোড করুন।")}</p></div><label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-emerald-300/50 px-3 py-2.5 text-sm text-emerald-100 hover:border-emerald-300"><ImagePlus className="h-4 w-4" />{upload.isPending ? (language === "EN" ? "Uploading…" : "আপলোড হচ্ছে…") : (language === "EN" ? "Upload image" : "ছবি আপলোড")}<input type="file" accept="image/*" className="sr-only" disabled={upload.isPending} onChange={event => event.target.files?.[0] && void uploadImage(event.target.files[0])} /></label>{draft.backgroundImageUrl && <button type="button" className="rounded-xl border border-rose-400/40 px-3 py-2.5 text-sm text-rose-100" onClick={() => setDraft(current => ({ ...current, backgroundImageUrl: "" }))}>{language === "EN" ? "Remove image" : "ছবি সরান"}</button>}</div>{draft.backgroundImageUrl && <div className="mt-3 h-36 rounded-lg border border-white/10 bg-cover bg-center" style={{ backgroundImage: `linear-gradient(rgba(255,255,255,${draft.overlayOpacity}), rgba(255,255,255,${draft.overlayOpacity})), url(${draft.backgroundImageUrl})`, backgroundColor: draft.backgroundColor }} />}</div>
    </div>
    <div className="mt-4 flex flex-col gap-3 border-t border-emerald-400/15 pt-4 sm:flex-row sm:items-center sm:justify-between"><p className="max-w-xl text-xs leading-5 text-slate-400">{selectedOverride ? (language === "EN" ? "A custom background is live for this group. Reset returns it to the whole-site setting in Site Appearance Control." : "এই গ্রুপে কাস্টম ব্যাকগ্রাউন্ড লাইভ আছে। রিসেট করলে এটি Site Appearance Control-এর পুরো সাইট সেটিং ব্যবহার করবে।") : (language === "EN" ? "This group inherits the whole-site background until a selected image is saved." : "নির্বাচিত ছবি সেভ না করা পর্যন্ত এই গ্রুপ পুরো সাইটের ব্যাকগ্রাউন্ড ব্যবহার করে।")}</p><div className="flex flex-col gap-2 sm:flex-row"><button type="button" disabled={!selectedOverride || resetTheme.isPending} onClick={() => resetTheme.mutate({ scopeKey })} className="inline-flex items-center justify-center gap-2 rounded-xl border border-rose-400/40 px-3 py-2.5 text-sm font-bold text-rose-100 disabled:cursor-not-allowed disabled:opacity-50"><RotateCcw className="h-4 w-4" />{language === "EN" ? "Reset selected scope" : "নির্বাচিত অংশ রিসেট"}</button><button type="button" disabled={!draft.backgroundImageUrl || saveTheme.isPending} onClick={() => saveTheme.mutate({ scopeKey, ...draft })} className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"><Save className="h-4 w-4" />{saveTheme.isPending ? (language === "EN" ? "Saving…" : "সেভ হচ্ছে…") : (language === "EN" ? "Save selected background" : "নির্বাচিত ব্যাকগ্রাউন্ড সেভ")}</button></div></div>
  </section>;
}
