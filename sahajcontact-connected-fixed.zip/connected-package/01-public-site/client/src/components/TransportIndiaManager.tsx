import { useState } from "react";
import { Bus, FileText, IdCard, Image as ImageIcon, Landmark, MapPin, Pencil, Plane, Plus, Save, Ship, ShieldCheck, Train, Trash2, Upload } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

type GalleryItem = { url: string; captionBn: string; captionEn: string };
type BorderForm = {
  id: number | null; nameBn: string; nameEn: string; locationBn: string; locationEn: string;
  bangladeshAddressBn: string; bangladeshAddressEn: string; indiaCounterpartBn: string; indiaCounterpartEn: string;
  infoBn: string; infoEn: string; officialSourceUrl: string; officialSourceLabelBn: string; officialSourceLabelEn: string; mapUrl: string;
  imageUrl: string | null; gallery: GalleryItem[]; visible: boolean; displayOrder: number;
};
type GuideForm = {
  id: number | null; kind: "india_travel" | "transport"; titleBn: string; titleEn: string; descriptionBn: string; descriptionEn: string;
  checklistBn: string; checklistEn: string; officialUrl: string; officialLabelBn: string; officialLabelEn: string;
  iconName: "Bus" | "Train" | "Plane" | "Ship" | "MapPin" | "Landmark" | "ShieldCheck" | "FileText" | "IdCard";
  iconImageUrl: string | null; coverImageUrl: string | null; sourceName: string; lastVerifiedAt: string; visible: boolean; displayOrder: number;
};

const inputClass = "mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none transition focus:border-emerald-400";
const emptyBorder: BorderForm = { id: null, nameBn: "", nameEn: "", locationBn: "", locationEn: "", bangladeshAddressBn: "", bangladeshAddressEn: "", indiaCounterpartBn: "", indiaCounterpartEn: "", infoBn: "", infoEn: "", officialSourceUrl: "", officialSourceLabelBn: "", officialSourceLabelEn: "", mapUrl: "", imageUrl: null, gallery: [], visible: true, displayOrder: 0 };
const emptyGuide: GuideForm = { id: null, kind: "india_travel", titleBn: "", titleEn: "", descriptionBn: "", descriptionEn: "", checklistBn: "", checklistEn: "", officialUrl: "", officialLabelBn: "অফিসিয়াল উৎস দেখুন", officialLabelEn: "View official source", iconName: "Landmark", iconImageUrl: null, coverImageUrl: null, sourceName: "", lastVerifiedAt: "", visible: true, displayOrder: 0 };

const iconOptions = ["Bus", "Train", "Plane", "Ship", "MapPin", "Landmark", "ShieldCheck", "FileText", "IdCard"] as const;
const IconPreview = ({ name, className = "h-5 w-5" }: { name: GuideForm["iconName"]; className?: string }) => {
  const icons = { Bus, Train, Plane, Ship, MapPin, Landmark, ShieldCheck, FileText, IdCard };
  const Icon = icons[name] ?? Landmark;
  return <Icon className={className} />;
};

async function fileToDataUrl(file: File) {
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি।"));
    reader.readAsDataURL(file);
  });
}

export function TransportIndiaManager({ isOwner }: { isOwner: boolean }) {
  const { language } = useLanguage();
  const utils = trpc.useUtils();
  const borderQuery = trpc.siteManagement.management.getBorderPorts.useQuery(undefined, { enabled: isOwner, retry: false });
  const guideQuery = trpc.siteManagement.management.getTransportIndiaGuides.useQuery(undefined, { enabled: isOwner, retry: false });
  const upload = trpc.gallery.uploadBase64.useMutation();
  const [borderForm, setBorderForm] = useState<BorderForm>(emptyBorder);
  const [guideForm, setGuideForm] = useState<GuideForm>(emptyGuide);
  const [message, setMessage] = useState("");
  const [activeEditor, setActiveEditor] = useState<"border" | "guide" | null>(null);

  const refresh = async () => {
    await Promise.all([
      borderQuery.refetch(),
      guideQuery.refetch(),
      utils.siteManagement.getTravelContent.invalidate(),
    ]);
  };
  const complete = async (text: string, close: "border" | "guide") => {
    await refresh();
    if (close === "border") setBorderForm(emptyBorder);
    else setGuideForm(emptyGuide);
    setActiveEditor(null);
    setMessage(text);
  };
  const createBorder = trpc.siteManagement.management.createBorderPort.useMutation({ onSuccess: () => void complete(language === "EN" ? "Border port published." : "বর্ডার পোর্ট প্রকাশ হয়েছে।", "border"), onError: (error) => setMessage(error.message) });
  const updateBorder = trpc.siteManagement.management.updateBorderPort.useMutation({ onSuccess: () => void complete(language === "EN" ? "Border port updated and published." : "বর্ডার পোর্ট আপডেট হয়ে public-এ প্রকাশ হয়েছে।", "border"), onError: (error) => setMessage(error.message) });
  const deleteBorder = trpc.siteManagement.management.deleteBorderPort.useMutation({ onSuccess: () => void refresh().then(() => setMessage(language === "EN" ? "Border port deleted." : "বর্ডার পোর্ট মুছে ফেলা হয়েছে।")), onError: (error) => setMessage(error.message) });
  const createGuide = trpc.siteManagement.management.createTransportIndiaGuide.useMutation({ onSuccess: () => void complete(language === "EN" ? "Guide published." : "গাইড প্রকাশ হয়েছে।", "guide"), onError: (error) => setMessage(error.message) });
  const updateGuide = trpc.siteManagement.management.updateTransportIndiaGuide.useMutation({ onSuccess: () => void complete(language === "EN" ? "Guide updated and published." : "গাইড আপডেট হয়ে public-এ প্রকাশ হয়েছে।", "guide"), onError: (error) => setMessage(error.message) });
  const deleteGuide = trpc.siteManagement.management.deleteTransportIndiaGuide.useMutation({ onSuccess: () => void refresh().then(() => setMessage(language === "EN" ? "Guide deleted." : "গাইড মুছে ফেলা হয়েছে।")), onError: (error) => setMessage(error.message) });

  const uploadImage = async (file: File, target: "border" | "icon" | "cover") => {
    if (!file.type.startsWith("image/")) { setMessage(language === "EN" ? "Please choose an image file." : "শুধু image file দিন।"); return; }
    if (file.size > 10 * 1024 * 1024) { setMessage(language === "EN" ? "Maximum image size is 10 MB." : "সর্বোচ্চ ১০ MB image দিন।"); return; }
    try {
      const result = await upload.mutateAsync({ base64Data: await fileToDataUrl(file), fileName: `cms/transport-india-${Date.now()}-${file.name.replace(/[^a-z0-9._-]/gi, "-")}`, contentType: file.type });
      if (target === "border") setBorderForm((current) => ({ ...current, imageUrl: result.url }));
      if (target === "icon") setGuideForm((current) => ({ ...current, iconImageUrl: result.url }));
      if (target === "cover") setGuideForm((current) => ({ ...current, coverImageUrl: result.url }));
      setMessage(language === "EN" ? "Image uploaded. Save to publish." : "ছবি আপলোড হয়েছে। প্রকাশ করতে Save চাপুন।");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Upload failed"); }
  };

  const submitBorder = (event: React.FormEvent) => {
    event.preventDefault();
    const { id, ...rawPayload } = borderForm;
    const payload = {
      ...rawPayload,
      bangladeshAddressBn: rawPayload.bangladeshAddressBn.trim() || null,
      bangladeshAddressEn: rawPayload.bangladeshAddressEn.trim() || null,
      indiaCounterpartBn: rawPayload.indiaCounterpartBn.trim() || null,
      indiaCounterpartEn: rawPayload.indiaCounterpartEn.trim() || null,
      officialSourceUrl: rawPayload.officialSourceUrl.trim() || null,
      officialSourceLabelBn: rawPayload.officialSourceLabelBn.trim() || null,
      officialSourceLabelEn: rawPayload.officialSourceLabelEn.trim() || null,
      mapUrl: rawPayload.mapUrl.trim() || null,
    };
    if (id) updateBorder.mutate({ id, ...payload }); else createBorder.mutate(payload);
  };
  const submitGuide = (event: React.FormEvent) => {
    event.preventDefault();
    const { id, lastVerifiedAt, ...rest } = guideForm;
    const payload = { ...rest, checklistBn: rest.checklistBn.trim() || null, checklistEn: rest.checklistEn.trim() || null, lastVerifiedAt: lastVerifiedAt ? new Date(`${lastVerifiedAt}T00:00:00.000Z`) : null };
    if (id) updateGuide.mutate({ id, ...payload }); else createGuide.mutate(payload);
  };
  const editBorder = (port: NonNullable<typeof borderQuery.data>[number]) => {
    setBorderForm({ id: port.id, nameBn: port.nameBn, nameEn: port.nameEn, locationBn: port.locationBn, locationEn: port.locationEn, bangladeshAddressBn: port.bangladeshAddressBn ?? "", bangladeshAddressEn: port.bangladeshAddressEn ?? "", indiaCounterpartBn: port.indiaCounterpartBn ?? "", indiaCounterpartEn: port.indiaCounterpartEn ?? "", infoBn: port.infoBn, infoEn: port.infoEn, officialSourceUrl: port.officialSourceUrl ?? "", officialSourceLabelBn: port.officialSourceLabelBn ?? "", officialSourceLabelEn: port.officialSourceLabelEn ?? "", mapUrl: port.mapUrl ?? "", imageUrl: port.imageUrl, gallery: (() => { try { return JSON.parse(port.galleryJson ?? "[]") as GalleryItem[]; } catch { return []; } })(), visible: port.visible === 1, displayOrder: port.displayOrder });
    setActiveEditor("border");
  };
  const editGuide = (guide: NonNullable<typeof guideQuery.data>[number]) => {
    setGuideForm({ id: guide.id, kind: guide.kind, titleBn: guide.titleBn, titleEn: guide.titleEn, descriptionBn: guide.descriptionBn, descriptionEn: guide.descriptionEn, checklistBn: guide.checklistBn ?? "", checklistEn: guide.checklistEn ?? "", officialUrl: guide.officialUrl, officialLabelBn: guide.officialLabelBn, officialLabelEn: guide.officialLabelEn, iconName: guide.iconName as GuideForm["iconName"], iconImageUrl: guide.iconImageUrl, coverImageUrl: guide.coverImageUrl, sourceName: guide.sourceName, lastVerifiedAt: guide.lastVerifiedAt ? new Date(guide.lastVerifiedAt).toISOString().slice(0, 10) : "", visible: guide.visible === 1, displayOrder: guide.displayOrder });
    setActiveEditor("guide");
  };

  return <section className="rounded-2xl border border-sky-500/30 bg-slate-900 p-5 shadow-xl sm:p-6">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div><h2 className="flex items-center gap-2 text-xl font-bold text-white"><Landmark className="h-5 w-5 text-sky-300" /> {language === "EN" ? "Transport & India Management" : "Transport & India Management"}</h2><p className="mt-1 max-w-4xl text-sm leading-6 text-slate-400">{language === "EN" ? "Manage Bangladesh–India border cards, transport and official-source guidance. Every save refreshes the public travel page immediately." : "বাংলাদেশ–ভারত বর্ডার কার্ড, পরিবহন ও অফিসিয়াল-সোর্স গাইড এখানে Add, Edit, Delete, Hide/Show ও সিরিয়াল করুন। প্রতিটি Save-এর পর public travel page সঙ্গে সঙ্গে আপডেট হয়।"}</p></div>
      <div className="flex flex-wrap gap-2"><button type="button" onClick={() => { setBorderForm(emptyBorder); setActiveEditor("border"); }} className="inline-flex items-center gap-1.5 rounded-xl bg-sky-600 px-3 py-2 text-xs font-bold text-white hover:bg-sky-500"><Plus className="h-3.5 w-3.5" /> বর্ডার পোর্ট</button><button type="button" onClick={() => { setGuideForm(emptyGuide); setActiveEditor("guide"); }} className="inline-flex items-center gap-1.5 rounded-xl border border-sky-300/40 px-3 py-2 text-xs font-bold text-sky-100 hover:bg-sky-400/10"><Plus className="h-3.5 w-3.5" /> গাইড / পরিবহন</button></div>
    </div>
    <div className="mt-4 rounded-xl border border-amber-500/25 bg-amber-950/25 p-3 text-xs leading-5 text-amber-100"><ShieldCheck className="mr-1 inline h-4 w-4 align-text-bottom" /> {language === "EN" ? "Use official sources only. This page must not promise visa eligibility, port hours, fees, facilities, or border entry." : "শুধু অফিসিয়াল উৎস দিন। ভিসা-যোগ্যতা, পোর্টের সময়, ফি, সুবিধা বা সীমান্তে প্রবেশ নিশ্চিত বলে কোনো দাবি লিখবেন না।"}</div>
    {message && <p className="mt-4 rounded-xl border border-emerald-500/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-100">{message}</p>}

    {activeEditor === "border" && <form onSubmit={submitBorder} className="mt-5 grid gap-3 rounded-2xl border border-sky-500/20 bg-slate-950/55 p-4 sm:grid-cols-2">
      <div className="sm:col-span-2 flex items-center justify-between"><h3 className="font-bold text-slate-100">{borderForm.id ? "বর্ডার পোর্ট সম্পাদনা" : "নতুন বর্ডার পোর্ট"}</h3><label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={borderForm.visible} onChange={(event) => setBorderForm((current) => ({ ...current, visible: event.target.checked }))} /> Public-এ দেখান</label></div>
      <label className="text-xs text-slate-300">নাম (বাংলা)<input required className={inputClass} value={borderForm.nameBn} onChange={(event) => setBorderForm((current) => ({ ...current, nameBn: event.target.value }))} /></label><label className="text-xs text-slate-300">Name (English)<input required className={inputClass} value={borderForm.nameEn} onChange={(event) => setBorderForm((current) => ({ ...current, nameEn: event.target.value }))} /></label>
      <label className="text-xs text-slate-300">লোকেশন (বাংলা)<input required className={inputClass} value={borderForm.locationBn} onChange={(event) => setBorderForm((current) => ({ ...current, locationBn: event.target.value }))} /></label><label className="text-xs text-slate-300">Location (English)<input required className={inputClass} value={borderForm.locationEn} onChange={(event) => setBorderForm((current) => ({ ...current, locationEn: event.target.value }))} /></label>
      <label className="text-xs text-slate-300">বাংলাদেশ-side ঠিকানা <textarea rows={2} className={inputClass} value={borderForm.bangladeshAddressBn} onChange={(event) => setBorderForm((current) => ({ ...current, bangladeshAddressBn: event.target.value }))} placeholder="যেমন: বেনাপোল, শার্শা, যশোর" /></label><label className="text-xs text-slate-300">Bangladesh-side address <textarea rows={2} className={inputClass} value={borderForm.bangladeshAddressEn} onChange={(event) => setBorderForm((current) => ({ ...current, bangladeshAddressEn: event.target.value }))} placeholder="e.g. Benapole, Sharsha, Jashore" /></label>
      <label className="text-xs text-slate-300">India counterpart (বাংলা)<input className={inputClass} value={borderForm.indiaCounterpartBn} onChange={(event) => setBorderForm((current) => ({ ...current, indiaCounterpartBn: event.target.value }))} placeholder="যেমন: পেট্রাপোল, উত্তর ২৪ পরগনা" /></label><label className="text-xs text-slate-300">India counterpart (English)<input className={inputClass} value={borderForm.indiaCounterpartEn} onChange={(event) => setBorderForm((current) => ({ ...current, indiaCounterpartEn: event.target.value }))} placeholder="e.g. Petrapole, North 24 Parganas" /></label>
      <label className="text-xs text-slate-300">তথ্য (বাংলা)<textarea required rows={3} className={inputClass} value={borderForm.infoBn} onChange={(event) => setBorderForm((current) => ({ ...current, infoBn: event.target.value }))} /></label><label className="text-xs text-slate-300">Information (English)<textarea required rows={3} className={inputClass} value={borderForm.infoEn} onChange={(event) => setBorderForm((current) => ({ ...current, infoEn: event.target.value }))} /></label>
      <label className="text-xs text-slate-300">অফিসিয়াল source URL<input type="url" className={inputClass} value={borderForm.officialSourceUrl} onChange={(event) => setBorderForm((current) => ({ ...current, officialSourceUrl: event.target.value }))} placeholder="https://..." /></label><label className="text-xs text-slate-300">Map / directions URL<input type="url" className={inputClass} value={borderForm.mapUrl} onChange={(event) => setBorderForm((current) => ({ ...current, mapUrl: event.target.value }))} placeholder="https://..." /></label>
      <label className="text-xs text-slate-300">অফিসিয়াল source label<input className={inputClass} value={borderForm.officialSourceLabelBn} onChange={(event) => setBorderForm((current) => ({ ...current, officialSourceLabelBn: event.target.value }))} placeholder="যেমন: অফিসিয়াল পোর্ট তথ্য" /></label><label className="text-xs text-slate-300">Official source label (English)<input className={inputClass} value={borderForm.officialSourceLabelEn} onChange={(event) => setBorderForm((current) => ({ ...current, officialSourceLabelEn: event.target.value }))} placeholder="e.g. View official port information" /></label>
      <label className="text-xs text-slate-300">ছবি URL<input className={inputClass} value={borderForm.imageUrl ?? ""} onChange={(event) => setBorderForm((current) => ({ ...current, imageUrl: event.target.value || null }))} /></label><label className="text-xs text-slate-300">Cover image upload<input type="file" accept="image/*" className="mt-2 block text-xs text-slate-400" onChange={(event) => event.target.files?.[0] && void uploadImage(event.target.files[0], "border")} /></label>
      <div className="sm:col-span-2 rounded-xl border border-slate-800 p-3"><div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold text-slate-200">Gallery images (optional)</span><button type="button" className="text-xs font-semibold text-sky-300" onClick={() => setBorderForm((current) => ({ ...current, gallery: [...current.gallery, { url: "", captionBn: "", captionEn: "" }] }))}>+ ছবি যোগ করুন</button></div>{borderForm.gallery.map((item, index) => <div key={index} className="mb-2 grid gap-2 sm:grid-cols-[1fr_1fr_1fr_auto]"><input className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-xs text-white" placeholder="Image URL" value={item.url} onChange={(event) => setBorderForm((current) => ({ ...current, gallery: current.gallery.map((value, itemIndex) => itemIndex === index ? { ...value, url: event.target.value } : value) }))} /><input className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-xs text-white" placeholder="Caption বাংলা" value={item.captionBn} onChange={(event) => setBorderForm((current) => ({ ...current, gallery: current.gallery.map((value, itemIndex) => itemIndex === index ? { ...value, captionBn: event.target.value } : value) }))} /><input className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-xs text-white" placeholder="Caption English" value={item.captionEn} onChange={(event) => setBorderForm((current) => ({ ...current, gallery: current.gallery.map((value, itemIndex) => itemIndex === index ? { ...value, captionEn: event.target.value } : value) }))} /><button type="button" className="rounded-lg px-2 text-xs text-rose-300 hover:bg-rose-500/10" onClick={() => setBorderForm((current) => ({ ...current, gallery: current.gallery.filter((_, itemIndex) => itemIndex !== index) }))}>বাদ</button></div>)}</div>
      <label className="text-xs text-slate-300">Display order<input type="number" min="0" className={inputClass} value={borderForm.displayOrder} onChange={(event) => setBorderForm((current) => ({ ...current, displayOrder: Number(event.target.value) || 0 }))} /></label><div className="flex items-end gap-2"><button disabled={createBorder.isPending || updateBorder.isPending} className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-500 disabled:opacity-50"><Save className="h-4 w-4" /> Save & Publish</button><button type="button" onClick={() => setActiveEditor(null)} className="rounded-xl border border-slate-700 px-4 py-2.5 text-sm text-slate-200">Cancel</button></div>
    </form>}

    {activeEditor === "guide" && <form onSubmit={submitGuide} className="mt-5 grid gap-3 rounded-2xl border border-sky-500/20 bg-slate-950/55 p-4 sm:grid-cols-2">
      <div className="sm:col-span-2 flex items-center justify-between"><h3 className="font-bold text-slate-100">{guideForm.id ? "Guide সম্পাদনা" : "নতুন Guide / Transport card"}</h3><label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={guideForm.visible} onChange={(event) => setGuideForm((current) => ({ ...current, visible: event.target.checked }))} /> Public-এ দেখান</label></div>
      <label className="text-xs text-slate-300">Category<select className={inputClass} value={guideForm.kind} onChange={(event) => setGuideForm((current) => ({ ...current, kind: event.target.value as GuideForm["kind"] }))}><option value="india_travel">India travel / official guidance</option><option value="transport">Transport</option></select></label><label className="text-xs text-slate-300">Icon fallback<select className={inputClass} value={guideForm.iconName} onChange={(event) => setGuideForm((current) => ({ ...current, iconName: event.target.value as GuideForm["iconName"] }))}>{iconOptions.map((icon) => <option key={icon} value={icon}>{icon}</option>)}</select></label>
      <label className="text-xs text-slate-300">শিরোনাম (বাংলা)<input required className={inputClass} value={guideForm.titleBn} onChange={(event) => setGuideForm((current) => ({ ...current, titleBn: event.target.value }))} /></label><label className="text-xs text-slate-300">Title (English)<input required className={inputClass} value={guideForm.titleEn} onChange={(event) => setGuideForm((current) => ({ ...current, titleEn: event.target.value }))} /></label>
      <label className="text-xs text-slate-300">বর্ণনা (বাংলা)<textarea required rows={3} className={inputClass} value={guideForm.descriptionBn} onChange={(event) => setGuideForm((current) => ({ ...current, descriptionBn: event.target.value }))} /></label><label className="text-xs text-slate-300">Description (English)<textarea required rows={3} className={inputClass} value={guideForm.descriptionEn} onChange={(event) => setGuideForm((current) => ({ ...current, descriptionEn: event.target.value }))} /></label>
      <label className="text-xs text-slate-300">সতর্ক Checklist (বাংলা)<textarea rows={4} className={inputClass} value={guideForm.checklistBn} onChange={(event) => setGuideForm((current) => ({ ...current, checklistBn: event.target.value }))} placeholder="প্রতিটি লাইনে একটি item লিখুন" /></label><label className="text-xs text-slate-300">Safety checklist (English)<textarea rows={4} className={inputClass} value={guideForm.checklistEn} onChange={(event) => setGuideForm((current) => ({ ...current, checklistEn: event.target.value }))} placeholder="One item per line" /></label>
      <label className="text-xs text-slate-300">Official URL<input required type="url" className={inputClass} value={guideForm.officialUrl} onChange={(event) => setGuideForm((current) => ({ ...current, officialUrl: event.target.value }))} /></label><label className="text-xs text-slate-300">অফিসিয়াল উৎসের নাম<input required className={inputClass} value={guideForm.sourceName} onChange={(event) => setGuideForm((current) => ({ ...current, sourceName: event.target.value }))} placeholder="e.g. Bangladesh Land Port Authority" /></label>
      <label className="text-xs text-slate-300">বাটনের লেখা (বাংলা)<input required className={inputClass} value={guideForm.officialLabelBn} onChange={(event) => setGuideForm((current) => ({ ...current, officialLabelBn: event.target.value }))} /></label><label className="text-xs text-slate-300">Button label (English)<input required className={inputClass} value={guideForm.officialLabelEn} onChange={(event) => setGuideForm((current) => ({ ...current, officialLabelEn: event.target.value }))} /></label>
      <label className="text-xs text-slate-300">Icon image URL (optional)<input className={inputClass} value={guideForm.iconImageUrl ?? ""} onChange={(event) => setGuideForm((current) => ({ ...current, iconImageUrl: event.target.value || null }))} /><input type="file" accept="image/*" className="mt-2 block text-xs text-slate-400" onChange={(event) => event.target.files?.[0] && void uploadImage(event.target.files[0], "icon")} /></label><label className="text-xs text-slate-300">Cover image URL (optional)<input className={inputClass} value={guideForm.coverImageUrl ?? ""} onChange={(event) => setGuideForm((current) => ({ ...current, coverImageUrl: event.target.value || null }))} /><input type="file" accept="image/*" className="mt-2 block text-xs text-slate-400" onChange={(event) => event.target.files?.[0] && void uploadImage(event.target.files[0], "cover")} /></label>
      <label className="text-xs text-slate-300">Last verified (optional)<input type="date" className={inputClass} value={guideForm.lastVerifiedAt} onChange={(event) => setGuideForm((current) => ({ ...current, lastVerifiedAt: event.target.value }))} /></label><label className="text-xs text-slate-300">Display order<input type="number" min="0" className={inputClass} value={guideForm.displayOrder} onChange={(event) => setGuideForm((current) => ({ ...current, displayOrder: Number(event.target.value) || 0 }))} /></label>
      <div className="sm:col-span-2 flex flex-wrap gap-2"><button disabled={createGuide.isPending || updateGuide.isPending} className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-500 disabled:opacity-50"><Save className="h-4 w-4" /> Save & Publish</button><button type="button" onClick={() => setActiveEditor(null)} className="rounded-xl border border-slate-700 px-4 py-2.5 text-sm text-slate-200">Cancel</button></div>
    </form>}

    <div className="mt-6 grid gap-5 lg:grid-cols-2"><div className="rounded-2xl border border-slate-800 bg-slate-950/45 p-4"><h3 className="mb-3 flex items-center gap-2 font-bold text-white"><MapPin className="h-4 w-4 text-sky-300" /> বর্ডার পোর্ট তালিকা</h3>{borderQuery.isLoading ? <p className="text-sm text-slate-400">লোড হচ্ছে…</p> : <div className="space-y-2">{borderQuery.data?.map((port) => <div key={port.id} className="flex gap-3 rounded-xl border border-slate-800 bg-slate-900/80 p-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-sky-950 text-sky-200">{port.imageUrl ? <img src={port.imageUrl} alt="" className="h-full w-full object-cover" /> : <MapPin className="h-5 w-5" />}</div><div className="min-w-0 flex-1"><p className="font-semibold text-slate-100">{port.nameBn}</p><p className="mt-0.5 text-xs text-slate-400">#{port.displayOrder} · {port.visible === 1 ? "Public" : "Hidden"}</p></div><div className="flex items-start gap-1"><button type="button" aria-label="Edit border port" onClick={() => editBorder(port)} className="rounded-lg p-2 text-sky-200 hover:bg-sky-500/10"><Pencil className="h-4 w-4" /></button><button type="button" aria-label="Delete border port" onClick={() => window.confirm(`“${port.nameBn}” মুছে ফেলবেন?`) && deleteBorder.mutate({ id: port.id })} className="rounded-lg p-2 text-rose-300 hover:bg-rose-500/10"><Trash2 className="h-4 w-4" /></button></div></div>)}{!borderQuery.data?.length && <p className="text-sm text-slate-400">এখনো কোনো বর্ডার পোর্ট নেই।</p>}</div>}</div>
      <div className="rounded-2xl border border-slate-800 bg-slate-950/45 p-4"><h3 className="mb-3 flex items-center gap-2 font-bold text-white"><ImageIcon className="h-4 w-4 text-sky-300" /> India & Transport guide তালিকা</h3>{guideQuery.isLoading ? <p className="text-sm text-slate-400">লোড হচ্ছে…</p> : <div className="space-y-2">{guideQuery.data?.map((guide) => <div key={guide.id} className="flex gap-3 rounded-xl border border-slate-800 bg-slate-900/80 p-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-sky-950 text-sky-200">{guide.iconImageUrl ? <img src={guide.iconImageUrl} alt="" className="h-full w-full object-cover" /> : <IconPreview name={guide.iconName as GuideForm["iconName"]} />}</div><div className="min-w-0 flex-1"><p className="font-semibold text-slate-100">{guide.titleBn}</p><p className="mt-0.5 text-xs text-slate-400">{guide.kind === "transport" ? "Transport" : "India"} · #{guide.displayOrder} · {guide.visible === 1 ? "Public" : "Hidden"}</p></div><div className="flex items-start gap-1"><button type="button" aria-label="Edit guide" onClick={() => editGuide(guide)} className="rounded-lg p-2 text-sky-200 hover:bg-sky-500/10"><Pencil className="h-4 w-4" /></button><button type="button" aria-label="Delete guide" onClick={() => window.confirm(`“${guide.titleBn}” মুছে ফেলবেন?`) && deleteGuide.mutate({ id: guide.id })} className="rounded-lg p-2 text-rose-300 hover:bg-rose-500/10"><Trash2 className="h-4 w-4" /></button></div></div>)}{!guideQuery.data?.length && <p className="text-sm text-slate-400">নতুন অফিসিয়াল গাইড বা Transport card যোগ করুন।</p>}</div>}</div></div>
  </section>;
}
