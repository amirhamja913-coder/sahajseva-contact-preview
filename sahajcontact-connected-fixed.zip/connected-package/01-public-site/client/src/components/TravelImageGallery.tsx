import { useCallback, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Image as ImageIcon } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

type GalleryItem = {
  url: string;
  captionBn?: string;
  captionEn?: string;
};

type ScrollableCarouselApi = {
  scrollTo: (index: number) => void;
  selectedScrollSnap: () => number;
  on: (event: "select", callback: () => void) => void;
};

type TravelImageGalleryProps = {
  coverUrl?: string | null;
  galleryJson?: string | null;
  title: string;
  language: "BN" | "EN";
  aspectClassName?: string;
};

function parseGallery(galleryJson?: string | null): GalleryItem[] {
  if (!galleryJson) return [];
  try {
    const parsed: unknown = JSON.parse(galleryJson);
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((item): GalleryItem[] => {
      if (
        !item ||
        typeof item !== "object" ||
        typeof (item as GalleryItem).url !== "string"
      ) {
        return [];
      }

      const url = (item as GalleryItem).url.trim();
      return url ? [{ ...(item as GalleryItem), url }] : [];
    });
  } catch {
    return [];
  }
}

export default function TravelImageGallery({
  coverUrl,
  galleryJson,
  title,
  language,
  aspectClassName = "aspect-[16/10]",
}: TravelImageGalleryProps) {
  const images = useMemo(() => {
    const candidates: GalleryItem[] = [];
    const normalizedCoverUrl = coverUrl?.trim();
    if (normalizedCoverUrl) candidates.push({ url: normalizedCoverUrl });
    candidates.push(...parseGallery(galleryJson));

    return candidates.filter(
      (item, index, all) => all.findIndex(candidate => candidate.url === item.url) === index,
    );
  }, [coverUrl, galleryJson]);
  const [activeIndex, setActiveIndex] = useState(0);
  const carouselApiRef = useRef<ScrollableCarouselApi | null>(null);
  const handleCarouselApi = useCallback((api: ScrollableCarouselApi | undefined) => {
    if (!api) return;
    carouselApiRef.current = api;
    const syncActiveImage = () => setActiveIndex(api.selectedScrollSnap());
    syncActiveImage();
    api.on("select", syncActiveImage);
  }, []);

  if (images.length === 0) {
    return (
      <div className={`${aspectClassName} bg-emerald-50 dark:bg-emerald-950/30 flex items-center justify-center text-emerald-700 dark:text-emerald-300`}>
        <ImageIcon size={30} aria-hidden="true" />
        <span className="sr-only">{language === "EN" ? `No images available for ${title}` : `${title}-এর কোনো ছবি পাওয়া যায়নি`}</span>
      </div>
    );
  }

  return (
    <div className="group relative overflow-hidden bg-muted" aria-label={language === "EN" ? `${title} image gallery` : `${title}-এর ছবি গ্যালারি`}>
      <Carousel opts={{ loop: images.length > 1 }} className="w-full" setApi={handleCarouselApi}>
        <CarouselContent>
          {images.map((image, index) => {
            const imageCaption = language === "EN" ? image.captionEn : image.captionBn;
            return (
              <CarouselItem key={`${image.url}-${index}`}>
                <div className={`${aspectClassName} relative`}>
                  <img
                    src={image.url}
                    alt={imageCaption || `${title} ${language === "EN" ? "travel view" : "ভ্রমণ দৃশ্য"} ${index + 1}`}
                    className="h-full w-full object-cover"
                    loading={index === 0 ? "eager" : "lazy"}
                  />
                  {imageCaption && (
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/35 to-transparent px-4 pb-3 pt-8 text-xs font-medium text-white">
                      {imageCaption}
                    </div>
                  )}
                </div>
              </CarouselItem>
            );
          })}
        </CarouselContent>
        {images.length > 1 && (
          <>
            <CarouselPrevious aria-label={language === "EN" ? "Previous image" : "আগের ছবি"} className="left-2 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100" />
            <CarouselNext aria-label={language === "EN" ? "Next image" : "পরের ছবি"} className="right-2 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100" />
          </>
        )}
      </Carousel>
      {images.length > 1 && (
        <div className="absolute bottom-2 left-3 right-3 z-10 flex items-center justify-center gap-1.5 overflow-x-auto rounded-full bg-black/45 px-2.5 py-1.5" aria-label={language === "EN" ? "Gallery images" : "গ্যালারি ছবি"}>
          {images.map((image, index) => (
            <button
              key={`dot-${image.url}-${index}`}
              type="button"
              aria-current={index === activeIndex ? "true" : undefined}
              aria-label={`${language === "EN" ? "View image" : "ছবি দেখুন"} ${index + 1}`}
              onClick={() => {
                setActiveIndex(index);
                carouselApiRef.current?.scrollTo(index);
              }}
              className={`h-2 w-2 shrink-0 rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white ${index === activeIndex ? "bg-white" : "bg-white/50 hover:bg-white/80"}`}
            />
          ))}
        </div>
      )}
      <div className="pointer-events-none absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1 text-[11px] font-semibold text-white" aria-live="polite">
        <ChevronLeft size={11} aria-hidden="true" />
        {activeIndex + 1}/{images.length}
        <ChevronRight size={11} aria-hidden="true" />
      </div>
      {images.length > 1 && (
        <div className="border-t border-emerald-900/10 bg-white/95 px-3 py-3 dark:bg-slate-950/95">
          <div className="mb-2 flex items-center justify-between gap-3 text-xs font-bold text-emerald-900 dark:text-emerald-100">
            <span>{language === "EN" ? `All ${images.length} photos` : `সব ${images.length}টি ছবি`}</span>
            <span className="text-[11px] font-medium text-muted-foreground">{language === "EN" ? "Choose a photo" : "ছবি বেছে নিন"}</span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1" aria-label={language === "EN" ? "All gallery photo thumbnails" : "গ্যালারির সব ছবির থাম্বনেইল"}>
            {images.map((image, index) => {
              const imageCaption = language === "EN" ? image.captionEn : image.captionBn;
              const isActive = index === activeIndex;
              return (
                <button
                  key={`thumbnail-${image.url}-${index}`}
                  type="button"
                  aria-label={`${language === "EN" ? "View photo" : "ছবি দেখুন"} ${index + 1}${imageCaption ? `: ${imageCaption}` : ""}`}
                  aria-pressed={isActive}
                  onClick={() => {
                    setActiveIndex(index);
                    carouselApiRef.current?.scrollTo(index);
                  }}
                  className={`relative h-14 w-20 shrink-0 overflow-hidden rounded-md border-2 bg-muted transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 ${isActive ? "border-emerald-600 ring-1 ring-emerald-600" : "border-transparent hover:border-emerald-300"}`}
                >
                  <img
                    src={image.url}
                    alt=""
                    aria-hidden="true"
                    className="h-full w-full object-cover"
                    loading={index < 4 ? "eager" : "lazy"}
                  />
                  <span className="absolute inset-x-0 bottom-0 bg-black/60 px-1 py-0.5 text-[10px] font-bold text-white" aria-hidden="true">{index + 1}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
