import { useEffect, useState, type ReactNode } from "react";
import { ArrowUpRight, Banknote, BriefcaseBusiness, CheckCircle2, ClipboardCheck, CloudSun, FileText, Globe2, HeartHandshake, Landmark, Phone, Plane, Scale, ShieldAlert, ShieldCheck, Smartphone, Sprout, WalletCards, Waves, Wheat } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { ExternalLinkWithFallback } from "./ExternalLinkWithFallback";
import { trackEvent, trackOutbound } from "../lib/analytics";
import { useLanguage } from "@/contexts/LanguageContext";
import UtilityAndExpatriateSectionsEnglish from "./UtilityAndExpatriateSectionsEnglish";

export type OfficialLink = {
  label: string;
  href: string;
  title: string;
};

type BillCard = {
  icon: LucideIcon;
  title: string;
  description: string;
  providers: string[];
  links: OfficialLink[];
  actionLabel: string;
};

export const billCards: BillCard[] = [
  {
    icon: Landmark,
    title: "বিদ্যুৎ বিল",
    description: "DPDC, DESCO ও NESCO-এর অফিসিয়াল বিল/রিচার্জ পোর্টালে যান।",
    providers: ["DPDC", "DESCO", "NESCO"],
    links: [
      { label: "DPDC পে করুন", href: "https://dpdc.gov.bd/pages/static-pages/6922dee2933eb65569e1e1bb", title: "DPDC অনলাইন বিল পরিশোধ" },
      { label: "DESCO পে করুন", href: "https://prepaid.desco.org.bd/customer/", title: "DESCO Prepaid Customer Portal" },
      { label: "NESCO পে করুন", href: "https://prepaid.nesco.gov.bd/", title: "NESCO Customer Service Portal" },
    ],
    actionLabel: "পে করুন",
  },
  {
    icon: Waves,
    title: "গ্যাস বিল",
    description: "Titas Gas-এর অফিসিয়াল customer portal-এ লগইন করে বিলের তথ্য দেখুন।",
    providers: ["Titas Gas"],
    links: [{ label: "পে করুন", href: "https://portal.titasgas.org.bd/login", title: "Titas Gas Customer Portal" }],
    actionLabel: "পে করুন",
  },
  {
    icon: Waves,
    title: "পানির বিল",
    description: "চট্টগ্রাম WASA-এর অফিসিয়াল e-bill entry point-এ বিল ও payment menu দেখুন।",
    providers: ["WASA চট্টগ্রাম"],
    links: [{ label: "পে করুন", href: "http://ebill.cwasabd.org/ebill/home.aspx", title: "চট্টগ্রাম WASA e-bill" }],
    actionLabel: "পে করুন",
  },
  {
    icon: Globe2,
    title: "ইন্টারনেট বিল",
    description: "Link3, Circle ও Amber IT-এর operator-owned billing portal ব্যবহার করুন।",
    providers: ["Link3", "Circle", "Amber IT"],
    links: [
      { label: "Link3 পে করুন", href: "https://selfcare.link3.net/payonline", title: "Link3 Online Payment" },
      { label: "Circle পে করুন", href: "https://www.circlenetworkbd.net/pay-bill", title: "Circle Network Pay Bill" },
      { label: "Amber IT পে করুন", href: "https://www.amberit.com.bd/bill-pay", title: "Amber IT Online Bill Pay" },
    ],
    actionLabel: "পে করুন",
  },
  {
    icon: Smartphone,
    title: "মোবাইল রিচার্জ",
    description: "GP, Robi ও Banglalink-এর অফিসিয়াল recharge page-এ যান।",
    providers: ["GP", "Robi", "Banglalink"],
    links: [
      { label: "GP রিচার্জ করুন", href: "https://www.grameenphone.com/personal/services/financial-services/gpay/utility-bill-payment", title: "Grameenphone GPAY Utility Bill Payment" },
      { label: "Robi রিচার্জ করুন", href: "https://www.robi.com.bd/en/recharge", title: "Robi Recharge" },
      { label: "Banglalink রিচার্জ করুন", href: "https://www.banglalink.net/recharge", title: "Banglalink Recharge" },
    ],
    actionLabel: "রিচার্জ করুন",
  },
];

export const expatVisaLinks: OfficialLink[] = [
  { label: "সৌদি", href: "https://www.mofa.gov.sa/en/eservices/pages/default.aspx", title: "Saudi Arabia Ministry of Foreign Affairs e-Services" },
  { label: "কাতার", href: "https://portal.moi.gov.qa/wps/portal/visainquiry", title: "Qatar Ministry of Interior Visa Inquiry" },
  { label: "দুবাই / UAE", href: "https://gdrfad.gov.ae/en/node/14321", title: "Dubai GDRFA Visa Status" },
];

export const remittanceLinks: OfficialLink[] = [
  { label: "bKash রেমিট্যান্স", href: "https://www.bkash.com/en/products-services/remittance", title: "bKash official remittance" },
  { label: "Nagad রেমিট্যান্স", href: "https://nagad.com.bd/services/?service=remittance", title: "Nagad official remittance" },
  { label: "ব্যাংক খুঁজুন", href: "https://www.bb.org.bd/en/index.php/links/links/9", title: "Bangladesh Bank scheduled-bank directory" },
];

export type ExpatGuideline = {
  number: string;
  titleBn: string;
  titleEn: string;
  safeBn: string;
  safeEn: string;
  cautionBn: string;
  cautionEn: string;
  noteBn: string;
  noteEn: string;
};

export const expatGuidelines: ExpatGuideline[] = [
  {
    number: "১",
    titleBn: "শুধু অফিসিয়াল ওয়েবসাইট ব্যবহার করুন",
    titleEn: "Use official websites only",
    safeBn: "সব কাজ করুন .gov.bd বা .gov ওয়েবসাইটে",
    safeEn: "Use .gov.bd or .gov websites for official services",
    cautionBn: "Facebook, WhatsApp বা দালালের মাধ্যমে টাকা দেবেন না",
    cautionEn: "Never send money through Facebook, WhatsApp, or an agent",
    noteBn: "পাসপোর্ট, NID, PCC ও BMET—সবকিছুর অফিসিয়াল লিংক আমাদের সাইটে পাবেন।",
    noteEn: "Find official links for passport, NID, PCC, and BMET services on this site.",
  },
  {
    number: "২",
    titleBn: "আপনার গুরুত্বপূর্ণ ডকুমেন্ট নিরাপদে রাখুন",
    titleEn: "Keep your important documents safe",
    safeBn: "পাসপোর্ট, ভিসা, আকামা/আইডি কার্ড ও BMET কার্ডের কপি নিরাপদে রাখুন",
    safeEn: "Keep secure copies of your passport, visa, ID, and BMET card",
    cautionBn: "অপরিচিত কাউকে পাসওয়ার্ড, OTP বা NID নম্বর দেবেন না",
    cautionEn: "Never share your password, OTP, or NID number with strangers",
    noteBn: "আবেদনের রসিদ ও রেফারেন্স নম্বরও সংরক্ষণ করুন।",
    noteEn: "Also keep your application receipts and reference numbers.",
  },
  {
    number: "৩",
    titleBn: "বৈধ পথে রেমিট্যান্স পাঠান",
    titleEn: "Send remittances through legal channels",
    safeBn: "ব্যাংক, bKash Global বা Western Union ব্যবহার করুন; প্রযোজ্য সরকারি ঘোষণায় ২.৫% প্রণোদনা পেতে পারেন",
    safeEn: "Use banks, bKash Global, or Western Union; eligible transfers may receive the announced 2.5% government incentive",
    cautionBn: "হুন্ডি করবেন না—এটি আইনত দণ্ডনীয় অপরাধ",
    cautionEn: "Do not use hundi; it is a punishable offence",
    noteBn: "লেনদেনের রসিদ ও প্রেরণ-তথ্য সংরক্ষণ করুন।",
    noteEn: "Keep the transaction receipt and remittance details.",
  },
  {
    number: "৪",
    titleBn: "দূতাবাসই আপনার ভরসা",
    titleEn: "Your embassy is your first point of support",
    safeBn: "বিপদে পড়লে সবার আগে নিজ দেশের বাংলাদেশ দূতাবাস বা কনস্যুলেটে কল করুন",
    safeEn: "In trouble, contact the Bangladesh embassy or consulate in your country first",
    cautionBn: "পাসপোর্ট হারালে, জেলে গেলে বা বেতন না পেলে দূতাবাসের সহায়তা নিন",
    cautionEn: "Contact the mission if your passport is lost, you are detained, or your wages are withheld",
    noteBn: "নিচে দেশ নির্বাচন করলে আপনার দেশের প্রাসঙ্গিক মিশনের লিংক পাবেন।",
    noteEn: "Select your country below to find the relevant mission links.",
  },
  {
    number: "৫",
    titleBn: "চাকরির বিষয়ে সতর্ক থাকুন",
    titleEn: "Be careful about overseas jobs",
    safeBn: "বিদেশ যাওয়ার আগে BMET থেকে স্মার্ট কার্ড নিন এবং চাকরির কন্ট্রাক্ট ভালো করে পড়ুন",
    safeEn: "Get a BMET smart card before travelling and read the employment contract carefully",
    cautionBn: "ভিসা ছাড়া বা টুরিস্ট ভিসায় কাজে যাবেন না; ‘ভালো চাকরি আছে’ বলে টাকা চাইলে তা প্রতারণা হতে পারে",
    cautionEn: "Do not work without a visa or on a tourist visa; money requests for a ‘great job’ may be fraud",
    noteBn: "কোনো কাগজে স্বাক্ষরের আগে শর্ত, বেতন ও নিয়োগকর্তার তথ্য যাচাই করুন।",
    noteEn: "Verify the terms, salary, and employer before signing any document.",
  },
];

export type RegionalRegion = string;
export type RegionalGuideLink = OfficialLink & { labelBn: string; labelEn: string };
export type RegionalGuide = {
  id: RegionalRegion;
  flag: string;
  nameBn: string;
  nameEn: string;
  summaryBn: string;
  summaryEn: string;
  stepsBn: string[];
  stepsEn: string[];
  links: RegionalGuideLink[];
};

export const regionalGuides: RegionalGuide[] = [
  {
    id: "bangladesh",
    flag: "🇧🇩",
    nameBn: "বাংলাদেশ",
    nameEn: "Bangladesh",
    summaryBn: "দেশের ভেতর থেকে NID, পাসপোর্ট ও ভূমি সেবার সরকারি entry point খুঁজুন।",
    summaryEn: "Find official entry points for NID, passport, and land services from inside Bangladesh.",
    stepsBn: ["সেবার ধরন বেছে নিন", "শুধু সরকারি ডোমেইনে তথ্য দিন", "আবেদন নম্বর ও রসিদ সংরক্ষণ করুন"],
    stepsEn: ["Choose the service", "Enter information only on official domains", "Save your application number and receipt"],
    links: [
      { label: "NID সরকারি পোর্টাল", labelBn: "NID সরকারি পোর্টাল", labelEn: "Official NID portal", href: "https://services.nidw.gov.bd/", title: "National ID official service portal" },
      { label: "ই-পাসপোর্ট", labelBn: "ই-পাসপোর্ট", labelEn: "E-passport", href: "https://www.epassport.gov.bd/", title: "Bangladesh e-passport official portal" },
      { label: "ভূমি সেবা", labelBn: "ভূমি সেবা", labelEn: "Land services", href: "https://land.gov.bd/", title: "Bangladesh land services official portal" },
    ],
  },
  {
    id: "saudi",
    flag: "🇸🇦",
    nameBn: "সৌদি আরব",
    nameEn: "Saudi Arabia",
    summaryBn: "সৌদি আরব থেকে ভিসা, বিদেশযাত্রা ও প্রবাসী কল্যাণের সরকারি পথ এক জায়গায় দেখুন।",
    summaryEn: "Access official visa, overseas employment, and expatriate welfare routes from Saudi Arabia.",
    stepsBn: ["ভিসা বা কর্মসংস্থানের বিষয় নির্ধারণ করুন", "সৌদি বা বাংলাদেশি সরকারি পোর্টাল যাচাই করুন", "দালালকে পাসপোর্ট/OTP দেবেন না"],
    stepsEn: ["Identify your visa or employment need", "Verify the Saudi or Bangladesh government portal", "Never share your passport or OTP with an agent"],
    links: [
      { label: "সৌদি ভিসা সেবা", labelBn: "সৌদি ভিসা সেবা", labelEn: "Saudi visa services", href: "https://www.mofa.gov.sa/en/eservices/pages/default.aspx", title: "Saudi Arabia Ministry of Foreign Affairs e-services" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "Bangladesh Bureau of Manpower Employment and Training official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare and Overseas Employment official website" },
    ],
  },
  {
    id: "uae",
    flag: "🇦🇪",
    nameBn: "সংযুক্ত আরব আমিরাত (দুবাই/আবুধাবি)",
    nameEn: "United Arab Emirates",
    summaryBn: "সংযুক্ত আরব আমিরাত থেকে দূতাবাস, ভিসা ও প্রবাসী কল্যাণ সেবা দেখুন।",
    summaryEn: "Access embassy and expatriate services from UAE.",
    stepsBn: ["দুবাই বা আবুধাবি দূতাবাস নির্বাচন করুন", "ভিসা ও কর্মসংস্থান যাচাই করুন", "নিরাপদ চ্যানেলে রেমিট্যান্স পাঠান"],
    stepsEn: ["Select Dubai or Abu Dhabi embassy", "Verify visa and employment", "Remit via secure official channels"],
    links: [
      { label: "দুবাই দূতাবাস / কনস্যুলেট", labelBn: "দুবাই দূতাবাস / কনস্যুলেট", labelEn: "Dubai Consulate", href: "https://dubai.mofa.gov.bd/", title: "Bangladesh Consulate General in Dubai" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "usa",
    flag: "🇺🇸",
    nameBn: "যুক্তরাষ্ট্র (ইউএসএ)",
    nameEn: "United States",
    summaryBn: "আমেরিকা থেকে ওয়াশিংটন ডিসি দূতাবাস ও কনস্যুলার সেবার পথ।",
    summaryEn: "Consular and embassy services from the USA.",
    stepsBn: ["কনস্যুলার সেবা বেছে নিন", "অনলাইন আবেদন করুন", "অফিসিয়াল পোর্টালে যোগাযোগ করুন"],
    stepsEn: ["Select consular service", "Apply online", "Contact via official portals"],
    links: [
      { label: "ওয়াশিংটন ডিসি দূতাবাস", labelBn: "ওয়াশিংটন ডিসি দূতাবাস", labelEn: "Embassy in Washington DC", href: "https://washington.mofa.gov.bd/", title: "Embassy of Bangladesh in Washington DC" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "uk",
    flag: "🇬🇧",
    nameBn: "যুক্তরাজ্য (ইউকে)",
    nameEn: "United Kingdom",
    summaryBn: "যুক্তরাজ্য থেকে লন্ডন হাইকমিশন ও কনস্যুলার সেবা।",
    summaryEn: "London High Commission and consular services from UK.",
    stepsBn: ["লন্ডন হাইকমিশনের সেবা দেখুন", "পাসপোর্ট ও নোটারি তথ্য জানুন", "সরকারি পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check High Commission services", "Review passport and notary info", "Visit official portal"],
    links: [
      { label: "লন্ডন হাইকমিশন", labelBn: "লন্ডন হাইকমিশন", labelEn: "High Commission in London", href: "https://london.mofa.gov.bd/", title: "High Commission of Bangladesh in London" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "canada",
    flag: "🇨🇦",
    nameBn: "কানাডা",
    nameEn: "Canada",
    summaryBn: "কানাডা থেকে অটোয়া হাইকমিশন ও কনস্যুলার সেবা।",
    summaryEn: "Ottawa High Commission and consular services from Canada.",
    stepsBn: ["হাইকমিশন সেবা বেছে নিন", "অনলাইন সেবা যাচাই করুন", "অফিসিয়াল লিংকে প্রবেশ করুন"],
    stepsEn: ["Select High Commission service", "Verify online services", "Access official links"],
    links: [
      { label: "অটোয়া হাইকমিশন", labelBn: "অটোয়া হাইকমিশন", labelEn: "High Commission in Ottawa", href: "https://ottawa.mofa.gov.bd/", title: "High Commission of Bangladesh in Ottawa" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "italy",
    flag: "🇮🇹",
    nameBn: "ইতালি",
    nameEn: "Italy",
    summaryBn: "ইতালি থেকে রোম দূতাবাস ও কনস্যুলার সেবা।",
    summaryEn: "Embassy in Rome and consular services from Italy.",
    stepsBn: ["রোম দূতাবাসের সেবা দেখুন", "পাসপোর্ট ও ভিসা সংক্রান্ত তথ্য জানুন", "সরকারি পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check Rome Embassy services", "Review passport & visa info", "Visit official portal"],
    links: [
      { label: "রোম দূতাবাস", labelBn: "রোম দূতাবাস", labelEn: "Embassy in Rome", href: "https://rome.mofa.gov.bd/", title: "Embassy of Bangladesh in Rome" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "malaysia",
    flag: "🇲🇾",
    nameBn: "মালয়েশিয়া",
    nameEn: "Malaysia",
    summaryBn: "কুয়ালালামপুর হাইকমিশন ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "High Commission in Kuala Lumpur and expatriate services.",
    stepsBn: ["কুয়ালালামপুর হাইকমিশন দেখুন", "ওয়ার্ক পারমিট ও ভিসা যাচাই করুন", "নিরাপদ চ্যানেলে সেবা নিন"],
    stepsEn: ["Check KL High Commission", "Verify work permit & visa", "Use secure channels"],
    links: [
      { label: "কুয়ালালামপুর হাইকমিশন", labelBn: "কুয়ালালামপুর হাইকমিশন", labelEn: "High Commission in Kuala Lumpur", href: "https://kualalumpur.mofa.gov.bd/", title: "High Commission of Bangladesh in Kuala Lumpur" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "oman",
    flag: "🇴🇲",
    nameBn: "ওমান",
    nameEn: "Oman",
    summaryBn: "মাসকাট দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Muscat and expatriate services.",
    stepsBn: ["মাসকাট দূতাবাস সেবা দেখুন", "ভিসা ও লেবার স্ট্যাটাস যাচাই করুন", "অফিসিয়াল লিংকে তথ্য দিন"],
    stepsEn: ["Check Muscat Embassy services", "Verify visa & labor status", "Provide info on official links"],
    links: [
      { label: "মাসকাট দূতাবাস", labelBn: "মাসকাট দূতাবাস", labelEn: "Embassy in Muscat", href: "https://muscat.mofa.gov.bd/", title: "Embassy of Bangladesh in Muscat" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "qatar",
    flag: "🇶🇦",
    nameBn: "কাতার",
    nameEn: "Qatar",
    summaryBn: "দোহা দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Doha and expatriate services.",
    stepsBn: ["দোহা দূতাবাস সেবা দেখুন", "কনস্যুলার তথ্য জানুন", "সরকারি পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check Doha Embassy services", "Review consular info", "Visit official portal"],
    links: [
      { label: "দোহা দূতাবাস", labelBn: "দোহা দূতাবাস", labelEn: "Embassy in Doha", href: "https://doha.mofa.gov.bd/", title: "Embassy of Bangladesh in Doha" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "kuwait",
    flag: "🇰🇼",
    nameBn: "কুয়েত",
    nameEn: "Kuwait",
    summaryBn: "কুয়েত দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Kuwait and expatriate services.",
    stepsBn: ["কুয়েত দূতাবাস সেবা দেখুন", "ভিসা ও লেবার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Kuwait Embassy services", "Review visa & labor info", "Visit official portal"],
    links: [
      { label: "কুয়েত দূতাবাস", labelBn: "কুয়েত দূতাবাস", labelEn: "Embassy in Kuwait", href: "https://kuwait.mofa.gov.bd/", title: "Embassy of Bangladesh in Kuwait" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "singapore",
    flag: "🇸🇬",
    nameBn: "সিঙ্গাপুর",
    nameEn: "Singapore",
    summaryBn: "সিঙ্গাপুর দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Singapore and expatriate services.",
    stepsBn: ["সিঙ্গাপুর দূতাবাস সেবা দেখুন", "ওয়ার্ক পাস ও কনস্যুলার তথ্য", "অফিসিয়াল লিংকে প্রবেশ করুন"],
    stepsEn: ["Check Singapore Embassy services", "Work pass & consular info", "Access official link"],
    links: [
      { label: "সিঙ্গাপুর দূতাবাস", labelBn: "সিঙ্গাপুর দূতাবাস", labelEn: "Embassy in Singapore", href: "https://singapore.mofa.gov.bd/", title: "Embassy of Bangladesh in Singapore" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "bahrain",
    flag: "🇧🇭",
    nameBn: "বাহরাইন",
    nameEn: "Bahrain",
    summaryBn: "মানামা দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Manama and expatriate services.",
    stepsBn: ["মানামা দূতাবাস সেবা দেখুন", "ভিসা ও লেবার তথ্য জানুন", "অফিসিয়াল পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check Manama Embassy services", "Review visa & labor info", "Visit official portal"],
    links: [
      { label: "বাহরাইন দূতাবাস", labelBn: "বাহরাইন দূতাবাস", labelEn: "Embassy in Bahrain", href: "https://manama.mofa.gov.bd/", title: "Embassy of Bangladesh in Bahrain" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "japan",
    flag: "🇯🇵",
    nameBn: "জাপান",
    nameEn: "Japan",
    summaryBn: "টোকিও দূতাবাস ও কনস্যুলার সেবা।",
    summaryEn: "Embassy in Tokyo and consular services.",
    stepsBn: ["টোকিও দূতাবাস সেবা দেখুন", "স্টাডি ও জব ভিসা তথ্য", "অফিসিয়াল লিংকে যান"],
    stepsEn: ["Check Tokyo Embassy services", "Study & job visa info", "Go to official link"],
    links: [
      { label: "টোকিও দূতাবাস", labelBn: "টোকিও দূতাবাস", labelEn: "Embassy in Tokyo", href: "https://tokyo.mofa.gov.bd/", title: "Embassy of Bangladesh in Tokyo" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "south-korea",
    flag: "🇰🇷",
    nameBn: "দক্ষিণ কোরিয়া",
    nameEn: "South Korea",
    summaryBn: "সিউল দূতাবাস ও ইপিএস (EPS) সেবা।",
    summaryEn: "Embassy in Seoul and EPS services.",
    stepsBn: ["সিউল দূতাবাস সেবা দেখুন", "EPS ও কর্মসংস্থান তথ্য", "অফিসিয়াল পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check Seoul Embassy services", "EPS & employment info", "Visit official portal"],
    links: [
      { label: "সিউল দূতাবাস", labelBn: "সিউল দূতাবাস", labelEn: "Embassy in Seoul", href: "https://seoul.mofa.gov.bd/", title: "Embassy of Bangladesh in Seoul" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "australia",
    flag: "🇦🇺",
    nameBn: "অস্ট্রেলিয়া",
    nameEn: "Australia",
    summaryBn: "ক্যানবেরা হাইকমিশন ও কনস্যুলার সেবা।",
    summaryEn: "High Commission in Canberra and consular services.",
    stepsBn: ["ক্যানবেরা হাইকমিশন দেখুন", "স্টাডি ও মাইগ্রেশন তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Canberra High Commission", "Study & migration info", "Visit official portal"],
    links: [
      { label: "ক্যানবেরা হাইকমিশন", labelBn: "ক্যানবেরা হাইকমিশন", labelEn: "High Commission in Canberra", href: "https://canberra.mofa.gov.bd/", title: "High Commission of Bangladesh in Canberra" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "france",
    flag: "🇫🇷",
    nameBn: "ফ্রান্স",
    nameEn: "France",
    summaryBn: "প্যারিস দূতাবাস ও কনস্যুলার সেবা।",
    summaryEn: "Embassy in Paris and consular services.",
    stepsBn: ["প্যারিস দূতাবাস সেবা দেখুন", "কনস্যুলার ও ভিসা তথ্য", "অফিসিয়াল লিংকে প্রবেশ করুন"],
    stepsEn: ["Check Paris Embassy services", "Consular & visa info", "Access official link"],
    links: [
      { label: "প্যারিস দূতাবাস", labelBn: "প্যারিস দূতাবাস", labelEn: "Embassy in Paris", href: "https://paris.mofa.gov.bd/", title: "Embassy of Bangladesh in Paris" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "germany",
    flag: "🇩🇪",
    nameBn: "জার্মানি",
    nameEn: "Germany",
    summaryBn: "বার্লিন দূতাবাস ও কনস্যুলার সেবা।",
    summaryEn: "Embassy in Berlin and consular services.",
    stepsBn: ["বার্লিন দূতাবাস সেবা দেখুন", "পাসপোর্ট ও স্টাডি তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Berlin Embassy services", "Passport & study info", "Visit official portal"],
    links: [
      { label: "বার্লিন দূতাবাস", labelBn: "বার্লিন দূতাবাস", labelEn: "Embassy in Berlin", href: "https://berlin.mofa.gov.bd/", title: "Embassy of Bangladesh in Berlin" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "spain",
    flag: "🇪🇸",
    nameBn: "স্পেন",
    nameEn: "Spain",
    summaryBn: "মাদ্রিদ দূতাবাস ও কনস্যুলার সেবা।",
    summaryEn: "Embassy in Madrid and consular services.",
    stepsBn: ["মাদ্রিদ দূতাবাস সেবা দেখুন", "কনস্যুলার ও ভিসা তথ্য", "অফিসিয়াল লিংকে প্রবেশ করুন"],
    stepsEn: ["Check Madrid Embassy services", "Consular & visa info", "Access official link"],
    links: [
      { label: "মাদ্রিদ দূতাবাস", labelBn: "মাদ্রিদ দূতাবাস", labelEn: "Embassy in Madrid", href: "https://madrid.mofa.gov.bd/", title: "Embassy of Bangladesh in Madrid" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "iraq",
    flag: "🇮🇶",
    nameBn: "ইরাক",
    nameEn: "Iraq",
    summaryBn: "বাগদাদ দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Baghdad and expatriate services.",
    stepsBn: ["বাগদাদ দূতাবাস সেবা দেখুন", "নিরাপত্তা ও কনস্যুলার তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Baghdad Embassy services", "Security & consular info", "Visit official portal"],
    links: [
      { label: "বাগদাদ দূতাবাস", labelBn: "বাগদাদ দূতাবাস", labelEn: "Embassy in Baghdad", href: "https://baghdad.mofa.gov.bd/", title: "Embassy of Bangladesh in Baghdad" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "lebanon",
    flag: "🇱🇧",
    nameBn: "লেবানন",
    nameEn: "Lebanon",
    summaryBn: "বৈরুত দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Beirut and expatriate services.",
    stepsBn: ["বৈরুত দূতাবাস সেবা দেখুন", "জরুরি সহায়তা ও কনস্যুলার তথ্য", "অফিসিয়াল লিংকে যান"],
    stepsEn: ["Check Beirut Embassy services", "Emergency & consular info", "Go to official link"],
    links: [
      { label: "বৈরুত দূতাবাস", labelBn: "বৈরুত দূতাবাস", labelEn: "Embassy in Beirut", href: "https://beirut.mofa.gov.bd/", title: "Embassy of Bangladesh in Beirut" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "maldives",
    flag: "🇲🇻",
    nameBn: "মালদ্বীপ",
    nameEn: "Maldives",
    summaryBn: "মালে দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Male and expatriate services.",
    stepsBn: ["মালে দূতাবাস সেবা দেখুন", "লেবার ও ওয়ার্ক পারমিট তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Male Embassy services", "Labor & work permit info", "Visit official portal"],
    links: [
      { label: "মালে দূতাবাস", labelBn: "মালে দূতাবাস", labelEn: "Embassy in Male", href: "https://male.mofa.gov.bd/", title: "Embassy of Bangladesh in Male" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "india",
    flag: "🇮🇳",
    nameBn: "ভারত",
    nameEn: "India",
    summaryBn: "নয়াদিল্লি হাইকমিশন ও উপ-হাইকমিশন সেবা।",
    summaryEn: "High Commission in New Delhi and deputy high commissions.",
    stepsBn: ["নয়াদিল্লি হাইকমিশন দেখুন", "মেডিকেল ও ট্যুরিস্ট ভিসা তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check New Delhi High Commission", "Medical & tourist visa info", "Visit official portal"],
    links: [
      { label: "নয়াদিল্লি হাইকমিশন", labelBn: "নয়াদিল্লি হাইকমিশন", labelEn: "High Commission in New Delhi", href: "https://newdelhi.mofa.gov.bd/", title: "High Commission of Bangladesh in New Delhi" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "pakistan",
    flag: "🇵🇰",
    nameBn: "পাকিস্তান",
    nameEn: "Pakistan",
    summaryBn: "ইসলামাবাদ হাইকমিশন ও কনস্যুলার সেবা।",
    summaryEn: "High Commission in Islamabad and consular services.",
    stepsBn: ["ইসলামাবাদ হাইকমিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check Islamabad High Commission", "Review consular info", "Visit official portal"],
    links: [
      { label: "ইসলামাবাদ হাইকমিশন", labelBn: "ইসলামাবাদ হাইকমিশন", labelEn: "High Commission in Islamabad", href: "https://islamabad.mofa.gov.bd/", title: "High Commission of Bangladesh in Islamabad" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "china",
    flag: "🇨🇳",
    nameBn: "চীন",
    nameEn: "China",
    summaryBn: "বেইজিং দূতাবাস ও কনস্যুলার সেবা।",
    summaryEn: "Embassy in Beijing and consular services.",
    stepsBn: ["বেইজিং দূতাবাস সেবা দেখুন", "স্টাডি ও বিজনেস ভিসা তথ্য", "অফিসিয়াল লিংকে যান"],
    stepsEn: ["Check Beijing Embassy services", "Study & business visa info", "Go to official link"],
    links: [
      { label: "বেইজিং দূতাবাস", labelBn: "বেইজিং দূতাবাস", labelEn: "Embassy in Beijing", href: "https://beijing.mofa.gov.bd/", title: "Embassy of Bangladesh in Beijing" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  {
    id: "indonesia",
    flag: "🇮🇩",
    nameBn: "ইন্দোনেশিয়া",
    nameEn: "Indonesia",
    summaryBn: "জাকার্তা দূতাবাস ও প্রবাসী কল্যাণ সেবা।",
    summaryEn: "Embassy in Jakarta and expatriate services.",
    stepsBn: ["জাকার্তা দূতাবাস সেবা দেখুন", "কনস্যুলার ও ভিসা তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Jakarta Embassy services", "Consular & visa info", "Visit official portal"],
    links: [
      { label: "জাকার্তা দূতাবাস", labelBn: "জাকার্তা দূতাবাস", labelEn: "Embassy in Jakarta", href: "https://jakarta.mofa.gov.bd/", title: "Embassy of Bangladesh in Jakarta" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" },
    ],
  },
  // All other world countries A-Z
  {
    id: "afghanistan", flag: "🇦🇫", nameBn: "আফগানিস্তান", nameEn: "Afghanistan",
    summaryBn: "আফগানিস্তান থেকে কনস্যুলার ও পররাষ্ট্র মন্ত্রণালয়ের তথ্য।", summaryEn: "Consular & MOFA information from Afghanistan.",
    stepsBn: ["পররাষ্ট্র মন্ত্রণালয়ের তথ্য দেখুন", "BMET নির্দেশনা জানুন", "অফিসিয়াল পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check MOFA info", "Review BMET guidelines", "Visit official portal"],
    links: [
      { label: "পররাষ্ট্র মন্ত্রণালয়", labelBn: "পররাষ্ট্র মন্ত্রণালয়", labelEn: "MOFA Bangladesh", href: "https://mofa.gov.bd/", title: "Ministry of Foreign Affairs Bangladesh" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "albania", flag: "🇦🇱", nameBn: "আলবেনিয়া", nameEn: "Albania",
    summaryBn: "আলবেনিয়া থেকে কনস্যুলার ও প্রবাসী কল্যাণ তথ্য।", summaryEn: "Consular & expatriate guidance from Albania.",
    stepsBn: ["পররাষ্ট্র মন্ত্রণালয়ের গাইডলাইন দেখুন", "BMET ও প্রবাসী কল্যাণ তথ্য জানুন", "অফিসিয়াল সাইট দেখুন"],
    stepsEn: ["Check MOFA guidelines", "Review BMET info", "Visit official site"],
    links: [
      { label: "পররাষ্ট্র মন্ত্রণালয়", labelBn: "পররাষ্ট্র মন্ত্রণালয়", labelEn: "MOFA Bangladesh", href: "https://mofa.gov.bd/", title: "Ministry of Foreign Affairs Bangladesh" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "algeria", flag: "🇩🇿", nameBn: "আলজেরিয়া", nameEn: "Algeria",
    summaryBn: "আলজেরিয়া থেকে আলজিয়ার্স দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Algiers and consular services.",
    stepsBn: ["আলজিয়ার্স দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Algiers Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "আলজিয়ার্স দূতাবাস", labelBn: "আলজিয়ার্স দূতাবাস", labelEn: "Embassy in Algiers", href: "https://algiers.mofa.gov.bd/", title: "Embassy of Bangladesh in Algiers" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "argentina", flag: "🇦🇷", nameBn: "আর্জেন্টিনা", nameEn: "Argentina",
    summaryBn: "বুয়েনস আইরেস দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Buenos Aires and consular services.",
    stepsBn: ["বুয়েনস আইরেস দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Buenos Aires Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "বুয়েনস আইরেস দূতাবাস", labelBn: "বুয়েনস আইরেস দূতাবাস", labelEn: "Embassy in Buenos Aires", href: "https://buenosaires.mofa.gov.bd/", title: "Embassy of Bangladesh in Buenos Aires" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "austria", flag: "🇦🇹", nameBn: "অস্ট্রিয়া", nameEn: "Austria",
    summaryBn: "ভিয়েনা দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Vienna and consular services.",
    stepsBn: ["ভিয়েনা দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Vienna Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ভিয়েনা দূতাবাস", labelBn: "ভিয়েনা দূতাবাস", labelEn: "Embassy in Vienna", href: "https://vienna.mofa.gov.bd/", title: "Embassy of Bangladesh in Vienna" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "azerbaijan", flag: "🇦🇿", nameBn: "আজারবাইজান", nameEn: "Azerbaijan",
    summaryBn: "আজারবাইজান থেকে কনস্যুলার ও পররাষ্ট্র মন্ত্রণালয়ের তথ্য।", summaryEn: "Consular & MOFA information from Azerbaijan.",
    stepsBn: ["পররাষ্ট্র মন্ত্রণালয়ের তথ্য দেখুন", "BMET নির্দেশনা জানুন", "অফিসিয়াল পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check MOFA info", "Review BMET guidelines", "Visit official portal"],
    links: [
      { label: "পররাষ্ট্র মন্ত্রণালয়", labelBn: "পররাষ্ট্র মন্ত্রণালয়", labelEn: "MOFA Bangladesh", href: "https://mofa.gov.bd/", title: "Ministry of Foreign Affairs Bangladesh" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "belgium", flag: "🇧🇪", nameBn: "বেলজিয়াম", nameEn: "Belgium",
    summaryBn: "ব্রাসেলস দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Brussels and consular services.",
    stepsBn: ["ব্রাসেলস দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Brussels Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ব্রাসেলস দূতাবাস", labelBn: "ব্রাসেলস দূতাবাস", labelEn: "Embassy in Brussels", href: "https://brussels.mofa.gov.bd/", title: "Embassy of Bangladesh in Brussels" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "brazil", flag: "🇧🇷", nameBn: "ব্রাজিল", nameEn: "Brazil",
    summaryBn: "ব্রাসিলিয়া দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Brasilia and consular services.",
    stepsBn: ["ব্রাসিলিয়া দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Brasilia Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ব্রাসিলিয়া দূতাবাস", labelBn: "ব্রাসিলিয়া দূতাবাস", labelEn: "Embassy in Brasilia", href: "https://brasilia.mofa.gov.bd/", title: "Embassy of Bangladesh in Brasilia" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "brunei", flag: "🇧🇳", nameBn: "ব্রুনাই", nameEn: "Brunei",
    summaryBn: "বন্দর সেরি বেগাওয়ান দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Bandar Seri Begawan and consular services.",
    stepsBn: ["ব্রুনাই দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Brunei Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ব্রুনাই দূতাবাস", labelBn: "ব্রুনাই দূতাবাস", labelEn: "Embassy in Brunei", href: "https://brunei.mofa.gov.bd/", title: "Embassy of Bangladesh in Brunei" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "egypt", flag: "🇪🇬", nameBn: "মিশর", nameEn: "Egypt",
    summaryBn: "কায়রো দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Cairo and consular services.",
    stepsBn: ["কায়রো দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Cairo Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "কায়রো দূতাবাস", labelBn: "কায়রো দূতাবাস", labelEn: "Embassy in Cairo", href: "https://cairo.mofa.gov.bd/", title: "Embassy of Bangladesh in Cairo" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "greece", flag: "🇬🇷", nameBn: "গ্রিস", nameEn: "Greece",
    summaryBn: "এথেন্স দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Athens and consular services.",
    stepsBn: ["এথেন্স দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Athens Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "এথেন্স দূতাবাস", labelBn: "এথেন্স দূতাবাস", labelEn: "Embassy in Athens", href: "https://athens.mofa.gov.bd/", title: "Embassy of Bangladesh in Athens" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "iran", flag: "🇮🇷", nameBn: "ইরান", nameEn: "Iran",
    summaryBn: "তেহরান দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Tehran and consular services.",
    stepsBn: ["তেহরান দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Tehran Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "তেহরান দূতাবাস", labelBn: "তেহরান দূতাবাস", labelEn: "Embassy in Tehran", href: "https://tehran.mofa.gov.bd/", title: "Embassy of Bangladesh in Tehran" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "jordan", flag: "🇯🇴", nameBn: "জর্ডান", nameEn: "Jordan",
    summaryBn: "আম্মান দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Amman and consular services.",
    stepsBn: ["আম্মান দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Amman Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "আম্মান দূতাবাস", labelBn: "আম্মান দূতাবাস", labelEn: "Embassy in Amman", href: "https://amman.mofa.gov.bd/", title: "Embassy of Bangladesh in Amman" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "kenya", flag: "🇰🇪", nameBn: "কেনিয়া", nameEn: "Kenya",
    summaryBn: "নাইরোবি হাইকমিশন ও কনস্যুলার সেবা।", summaryEn: "High Commission in Nairobi and consular services.",
    stepsBn: ["নাইরোবি হাইকমিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Nairobi High Commission", "Review consular info", "Visit official portal"],
    links: [
      { label: "নাইরোবি হাইকমিশন", labelBn: "নাইরোবি হাইকমিশন", labelEn: "High Commission in Nairobi", href: "https://nairobi.mofa.gov.bd/", title: "High Commission of Bangladesh in Nairobi" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "libya", flag: "🇱🇾", nameBn: "লিবিয়া", nameEn: "Libya",
    summaryBn: "ত্রিপোলি দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Tripoli and consular services.",
    stepsBn: ["ত্রিপোলি দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Tripoli Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ত্রিপোলি দূতাবাস", labelBn: "ত্রিপোলি দূতাবাস", labelEn: "Embassy in Tripoli", href: "https://tripoli.mofa.gov.bd/", title: "Embassy of Bangladesh in Tripoli" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "mauritius", flag: "🇲🇺", nameBn: "মরিশাস", nameEn: "Mauritius",
    summaryBn: "পোর্ট লুই হাইকমিশন ও কনস্যুলার সেবা।", summaryEn: "High Commission in Port Louis and consular services.",
    stepsBn: ["পোর্ট লুই হাইকমিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Port Louis High Commission", "Review consular info", "Visit official portal"],
    links: [
      { label: "পোর্ট লুই হাইকমিশন", labelBn: "পোর্ট লুই হাইকমিশন", labelEn: "High Commission in Port Louis", href: "https://portlouis.mofa.gov.bd/", title: "High Commission of Bangladesh in Port Louis" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "mexico", flag: "🇲🇽", nameBn: "মেক্সিকো", nameEn: "Mexico",
    summaryBn: "মেক্সিকো সিটি দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Mexico City and consular services.",
    stepsBn: ["মেক্সিকো সিটি দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Mexico City Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "মেক্সিকো সিটি দূতাবাস", labelBn: "মেক্সিকো সিটি দূতাবাস", labelEn: "Embassy in Mexico City", href: "https://mexicocity.mofa.gov.bd/", title: "Embassy of Bangladesh in Mexico City" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "morocco", flag: "🇲🇦", nameBn: "মরক্কো", nameEn: "Morocco",
    summaryBn: "রাবাত দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Rabat and consular services.",
    stepsBn: ["রাবাত দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Rabat Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "রাবাত দূতাবাস", labelBn: "রাবাত দূতাবাস", labelEn: "Embassy in Rabat", href: "https://rabat.mofa.gov.bd/", title: "Embassy of Bangladesh in Rabat" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "myanmar", flag: "🇲🇲", nameBn: "মিয়ানমার", nameEn: "Myanmar",
    summaryBn: "ইয়াঙ্গুন দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Yangon and consular services.",
    stepsBn: ["ইয়াঙ্গুন দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Yangon Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ইয়াঙ্গুন দূতাবাস", labelBn: "ইয়াঙ্গুন দূতাবাস", labelEn: "Embassy in Yangon", href: "https://yangon.mofa.gov.bd/", title: "Embassy of Bangladesh in Yangon" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "nepal", flag: "🇳🇵", nameBn: "নেপাল", nameEn: "Nepal",
    summaryBn: "কাঠমান্ডু দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Kathmandu and consular services.",
    stepsBn: ["কাঠমান্ডু দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Kathmandu Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "কাঠমান্ডু দূতাবাস", labelBn: "কাঠমান্ডু দূতাবাস", labelEn: "Embassy in Kathmandu", href: "https://kathmandu.mofa.gov.bd/", title: "Embassy of Bangladesh in Kathmandu" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "netherlands", flag: "🇳🇱", nameBn: "নেদারল্যান্ডস", nameEn: "Netherlands",
    summaryBn: "হেগ দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in The Hague and consular services.",
    stepsBn: ["হেগ দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check The Hague Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "হেগ দূতাবাস", labelBn: "হেগ দূতাবাস", labelEn: "Embassy in The Hague", href: "https://thehague.mofa.gov.bd/", title: "Embassy of Bangladesh in The Hague" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "new-zealand", flag: "🇳🇿", nameBn: "নিউজিল্যান্ড", nameEn: "New Zealand",
    summaryBn: "নিউজিল্যান্ডের জন্য পররাষ্ট্র মন্ত্রণালয় ও কনস্যুলার গাইড।", summaryEn: "Consular & MOFA guide for New Zealand.",
    stepsBn: ["পররাষ্ট্র মন্ত্রণালয়ের তথ্য দেখুন", "BMET নির্দেশনা জানুন", "অফিসিয়াল পোর্টালে ভিজিট করুন"],
    stepsEn: ["Check MOFA info", "Review BMET guidelines", "Visit official portal"],
    links: [
      { label: "পররাষ্ট্র মন্ত্রণালয়", labelBn: "পররাষ্ট্র মন্ত্রণালয়", labelEn: "MOFA Bangladesh", href: "https://mofa.gov.bd/", title: "Ministry of Foreign Affairs Bangladesh" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "nigeria", flag: "🇳🇬", nameBn: "নাইজেরিয়া", nameEn: "Nigeria",
    summaryBn: "আবুজা হাইকমিশন ও কনস্যুলার সেবা।", summaryEn: "High Commission in Abuja and consular services.",
    stepsBn: ["আবুজা হাইকমিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Abuja High Commission", "Review consular info", "Visit official portal"],
    links: [
      { label: "আবুজা হাইকমিশন", labelBn: "আবুজা হাইকমিশন", labelEn: "High Commission in Abuja", href: "https://abuja.mofa.gov.bd/", title: "High Commission of Bangladesh in Abuja" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "philippines", flag: "🇵🇭", nameBn: "ফিলিপাইন", nameEn: "Philippines",
    summaryBn: "ম্যানিলা দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Manila and consular services.",
    stepsBn: ["ম্যানিলা দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Manila Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ম্যানিলা দূতাবাস", labelBn: "ম্যানিলা দূতাবাস", labelEn: "Embassy in Manila", href: "https://manila.mofa.gov.bd/", title: "Embassy of Bangladesh in Manila" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "poland", flag: "🇵🇱", nameBn: "পোল্যান্ড", nameEn: "Poland",
    summaryBn: "ওয়ারশ দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Warsaw and consular services.",
    stepsBn: ["ওয়ারশ দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Warsaw Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "ওয়ারশ দূতাবাস", labelBn: "ওয়ারশ দূতাবাস", labelEn: "Embassy in Warsaw", href: "https://warsaw.mofa.gov.bd/", title: "Embassy of Bangladesh in Warsaw" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "portugal", flag: "🇵🇹", nameBn: "পর্তুগাল", nameEn: "Portugal",
    summaryBn: "লিসবন দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Lisbon and consular services.",
    stepsBn: ["লিসবন দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Lisbon Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "লিসবন দূতাবাস", labelBn: "লিসবন দূতাবাস", labelEn: "Embassy in Lisbon", href: "https://lisbon.mofa.gov.bd/", title: "Embassy of Bangladesh in Lisbon" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "romania", flag: "🇷🇴", nameBn: "রোমানিয়া", nameEn: "Romania",
    summaryBn: "বুখারেস্ট দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Bucharest and consular services.",
    stepsBn: ["বুখারেস্ট দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Bucharest Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "বুখারেস্ট দূতাবাস", labelBn: "বুখারেস্ট দূতাবাস", labelEn: "Embassy in Bucharest", href: "https://bucharest.mofa.gov.bd/", title: "Embassy of Bangladesh in Bucharest" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "russia", flag: "🇷🇺", nameBn: "রাশিয়া", nameEn: "Russia",
    summaryBn: "মস্কো দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Moscow and consular services.",
    stepsBn: ["মস্কো দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Moscow Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "মস্কো দূতাবাস", labelBn: "মস্কো দূতাবাস", labelEn: "Embassy in Moscow", href: "https://moscow.mofa.gov.bd/", title: "Embassy of Bangladesh in Moscow" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "south-africa", flag: "🇿🇦", nameBn: "দক্ষিণ আফ্রিকা", nameEn: "South Africa",
    summaryBn: "প্রিটোরিয়া হাইকমিশন ও কনস্যুলার সেবা।", summaryEn: "High Commission in Pretoria and consular services.",
    stepsBn: ["প্রিটোরিয়া হাইকমিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Pretoria High Commission", "Review consular info", "Visit official portal"],
    links: [
      { label: "প্রিটোরিয়া হাইকমিশন", labelBn: "প্রিটোরিয়া হাইকমিশন", labelEn: "High Commission in Pretoria", href: "https://pretoria.mofa.gov.bd/", title: "High Commission of Bangladesh in Pretoria" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "sri-lanka", flag: "🇱🇰", nameBn: "শ্রীলঙ্কা", nameEn: "Sri Lanka",
    summaryBn: "কলম্বো হাইকমিশন ও কনস্যুলার সেবা।", summaryEn: "High Commission in Colombo and consular services.",
    stepsBn: ["কলম্বো হাইকমিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Colombo High Commission", "Review consular info", "Visit official portal"],
    links: [
      { label: "কলম্বো হাইকমিশন", labelBn: "কলম্বো হাইকমিশন", labelEn: "High Commission in Colombo", href: "https://colombo.mofa.gov.bd/", title: "High Commission of Bangladesh in Colombo" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "sweden", flag: "🇸🇪", nameBn: "সুইডেন", nameEn: "Sweden",
    summaryBn: "স্টকহোম দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Stockholm and consular services.",
    stepsBn: ["স্টকহোম দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Stockholm Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "স্টকহোম দূতাবাস", labelBn: "স্টকহোম দূতাবাস", labelEn: "Embassy in Stockholm", href: "https://stockholm.mofa.gov.bd/", title: "Embassy of Bangladesh in Stockholm" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "switzerland", flag: "🇨🇭", nameBn: "সুইজারল্যান্ড", nameEn: "Switzerland",
    summaryBn: "জেনেভা মিশন ও দূতাবাস সেবা।", summaryEn: "Mission in Geneva and embassy services.",
    stepsBn: ["জেনেভা মিশন দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Geneva Mission", "Review consular info", "Visit official portal"],
    links: [
      { label: "জেনেভা মিশন / দূতাবাস", labelBn: "জেনেভা মিশন / দূতাবাস", labelEn: "Mission in Geneva", href: "https://geneva.mofa.gov.bd/", title: "Permanent Mission of Bangladesh in Geneva" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "thailand", flag: "🇹🇭", nameBn: "থাইল্যান্ড", nameEn: "Thailand",
    summaryBn: "ব্যাংকক দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Bangkok and consular services.",
    stepsBn: ["ব্যাংকক দূতাবাস দেখুন", "মেডিকেল ও ট্যুরিস্ট তথ্য", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Bangkok Embassy", "Medical & tourist info", "Visit official portal"],
    links: [
      { label: "ব্যাংকক দূতাবাস", labelBn: "ব্যাংকক দূতাবাস", labelEn: "Embassy in Bangkok", href: "https://bangkok.mofa.gov.bd/", title: "Embassy of Bangladesh in Bangkok" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "turkey", flag: "🇹🇷", nameBn: "তুরস্ক", nameEn: "Turkey",
    summaryBn: "আঙ্কারা দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Ankara and consular services.",
    stepsBn: ["আঙ্কারা দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Ankara Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "আঙ্কারা দূতাবাস", labelBn: "আঙ্কারা দূতাবাস", labelEn: "Embassy in Ankara", href: "https://ankara.mofa.gov.bd/", title: "Embassy of Bangladesh in Ankara" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "uzbekistan", flag: "🇺🇿", nameBn: "উজবেকিস্তান", nameEn: "Uzbekistan",
    summaryBn: "তাশখন্দ দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Tashkent and consular services.",
    stepsBn: ["তাশখন্দ দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Tashkent Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "তাশখন্দ দূতাবাস", labelBn: "তাশখন্দ দূতাবাস", labelEn: "Embassy in Tashkent", href: "https://tashkent.mofa.gov.bd/", title: "Embassy of Bangladesh in Tashkent" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "vietnam", flag: "🇻🇳", nameBn: "ভিয়েতনাম", nameEn: "Vietnam",
    summaryBn: "হ্যানয় দূতাবাস ও কনস্যুলার সেবা।", summaryEn: "Embassy in Hanoi and consular services.",
    stepsBn: ["হ্যানয় দূতাবাস দেখুন", "কনস্যুলার তথ্য জানুন", "অফিসিয়াল পোর্টালে যান"],
    stepsEn: ["Check Hanoi Embassy", "Review consular info", "Visit official portal"],
    links: [
      { label: "হ্যানয় দূতাবাস", labelBn: "হ্যানয় দূতাবাস", labelEn: "Embassy in Hanoi", href: "https://hanoi.mofa.gov.bd/", title: "Embassy of Bangladesh in Hanoi" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" }
    ]
  },
  {
    id: "other-world-country", flag: "🌍", nameBn: "অন্যান্য সকল দেশ (বিশ্বের বাকি দেশসমূহ)", nameEn: "All Other Countries Worldwide",
    summaryBn: "বিশ্বের যেকোনো দেশ থেকে বাংলাদেশ পররাষ্ট্র মন্ত্রণালয়ের মিশন ডিরেক্টরি ও BMET সেবা।", summaryEn: "Global MOFA mission directory & BMET services for all countries.",
    stepsBn: ["পররাষ্ট্র মন্ত্রণালয়ের মিশন তালিকা দেখুন", "সংশ্লিষ্ট দেশের বাংলাদেশ মিশন খুঁজুন", "অফিসিয়াল পোর্টালের মাধ্যমে যোগাযোগ করুন"],
    stepsEn: ["Check MOFA mission list", "Find Bangladesh mission in your country", "Contact via official portal"],
    links: [
      { label: "পররাষ্ট্র মন্ত্রণালয় মিশন ডিরেক্টরি", labelBn: "পররাষ্ট্র মন্ত্রণালয় মিশন ডিরেক্টরি", labelEn: "MOFA Mission Directory", href: "https://mofa.gov.bd/site/page/4fa7e8d6-410a-426c-8438-d699479b4c09", title: "Ministry of Foreign Affairs Bangladesh All Missions Directory" },
      { label: "BMET তথ্য", labelBn: "BMET তথ্য", labelEn: "BMET information", href: "https://bmet.gov.bd/", title: "BMET official website" },
      { label: "প্রবাসী মন্ত্রণালয়", labelBn: "প্রবাসী মন্ত্রণালয়", labelEn: "Expatriates ministry", href: "https://probashi.gov.bd/", title: "Ministry of Expatriates Welfare" }
    ]
  }
];

const priorityEmbassyQuickDials = [
  {
    id: "usa",
    flag: "🇺🇸",
    countryBn: "যুক্তরাষ্ট্র",
    countryEn: "United States",
    phone: "+1 202-244-0183",
    phoneHref: "tel:+12022440183",
    officialUrl: "https://washington.mofa.gov.bd/",
    titleBn: "ওয়াশিংটন বাংলাদেশ দূতাবাস",
    titleEn: "Bangladesh Embassy in Washington, DC",
  },
  {
    id: "saudi-arabia",
    flag: "🇸🇦",
    countryBn: "সৌদি আরব",
    countryEn: "Saudi Arabia",
    phone: "+966 11 419 5661",
    phoneHref: "tel:+966114195661",
    officialUrl: "https://riyadh.mofa.gov.bd/",
    titleBn: "রিয়াদ বাংলাদেশ দূতাবাস",
    titleEn: "Bangladesh Embassy in Riyadh",
  },
  {
    id: "uae",
    flag: "🇦🇪",
    countryBn: "সংযুক্ত আরব আমিরাত",
    countryEn: "United Arab Emirates",
    phone: "+971 2 446 5100",
    phoneHref: "tel:+97124465100",
    officialUrl: "https://abudhabi.mofa.gov.bd/",
    titleBn: "আবুধাবি বাংলাদেশ দূতাবাস",
    titleEn: "Bangladesh Embassy in Abu Dhabi",
  },
  {
    id: "italy",
    flag: "🇮🇹",
    countryBn: "ইতালি",
    countryEn: "Italy",
    phone: "+39 06 808 3595",
    phoneHref: "tel:+39068083595",
    officialUrl: "https://rome.mofa.gov.bd/",
    titleBn: "রোম বাংলাদেশ দূতাবাস",
    titleEn: "Bangladesh Embassy in Rome",
  },
] as const;

export const agricultureLinks = {
  dae: { label: "সেবা দেখুন", href: "https://dae.gov.bd/", title: "Department of Agricultural Extension official website" },
  farmerApply: { label: "আবেদন করুন", href: "https://fpo.dgf.gov.bd/farmer-app/", title: "DG Food official farmer application portal" },
  farmerRegister: { label: "নিবন্ধন / স্ট্যাটাস", href: "https://fsmms.dgf.gov.bd/portal/bn/farmer", title: "DG Food official farmer registration portal" },
  weather: { label: "আবহাওয়া দেখুন", href: "https://www.bamis.gov.bd/", title: "Bangladesh Agro-Meteorological Information Service official portal" },
  bmdWeather: { label: "আজকের আবহাওয়া", href: "https://www.bmd.gov.bd/", title: "Bangladesh Meteorological Department official forecast and warnings" },
  subsidy: { label: "যোগ্যতা দেখুন", href: "https://moa.gov.bd/", title: "Ministry of Agriculture official information portal" },
  forms: { label: "ফরম দেখুন", href: "https://dae.gov.bd/pages/miscellaneous-infos?filters=%7B%22miscellaneous_info_type%22%3A%20%226922d90181fc96cef9eb06f9%22%7D", title: "DAE official forms and application samples" },
} satisfies Record<string, OfficialLink>;

export const womenChildrenLinks = {
  mowca: { label: "মন্ত্রণালয়ের তথ্য দেখুন", href: "http://mowca.gov.bd/", title: "মহিলা ও শিশু বিষয়ক মন্ত্রণালয়ের অফিসিয়াল ওয়েবসাইট" },
  socialServices: { label: "সামাজিক সুরক্ষা দেখুন", href: "https://dss.gov.bd/", title: "সমাজসেবা অধিদপ্তরের অফিসিয়াল ওয়েবসাইট" },
  socialProtection: { label: "নীতিমালা ও কর্মসূচি", href: "https://socialprotection.gov.bd/", title: "বাংলাদেশের জাতীয় সামাজিক নিরাপত্তা কৌশল অফিসিয়াল পোর্টাল" },
  citizenPortal: { label: "সেবা খুঁজুন", href: "https://www.bangladesh.gov.bd/", title: "বাংলাদেশ জাতীয় তথ্য বাতায়ন" },
  womenHelpline: { label: "১০৯-এ কল করুন", href: "tel:109", title: "নারী ও শিশু সহায়তা হেল্পলাইন ১০৯" },
  childHelpline: { label: "১০৯৮-এ কল করুন", href: "tel:1098", title: "শিশু হেল্পলাইন ১০৯৮" },
  joyeeta: { label: "প্রশিক্ষণ / বাজার দেখুন", href: "http://joyeeta.portal.gov.bd/", title: "জয়িতা ফাউন্ডেশন সরকারি নারী উদ্যোক্তা সেবা" },
  bangladeshBankWomen: { label: "SME ঋণ তথ্য দেখুন", href: "https://www.bb.org.bd/smespd_portal/women-entrepreneur.html", title: "Bangladesh Bank women entrepreneur SME information" },
  maternityAllowance: { label: "ভাতা / আবেদন দেখুন", href: "https://dwa.gov.bd/pages/static-pages/6922df5b933eb65569e21713", title: "Department of Women Affairs maternity allowance official page" },
  healthFacility: { label: "হাসপাতাল লিস্ট দেখুন", href: "https://hrm.dghs.gov.bd/public/facility-registry", title: "DGHS official health facility registry" },
  healthInfo: { label: "স্বাস্থ্য তথ্য দেখুন", href: "https://dghs.gov.bd/", title: "Directorate General of Health Services official website" },
} satisfies Record<string, OfficialLink>;

const JUSTICE_LINK_LAST_VERIFIED = "১৯ আগস্ট ২০২৬";

export const citizenServicesLinks = {
  nid: { label: "NID সেবা খুলুন", href: "https://services.nidw.gov.bd/", title: "জাতীয় পরিচয়পত্র সেবার অফিসিয়াল পোর্টাল" },
  passport: { label: "ই-পাসপোর্ট খুলুন", href: "https://www.epassport.gov.bd/", title: "ই-পাসপোর্টের অফিসিয়াল আবেদন ও তথ্য পোর্টাল" },
  brta: { label: "BRTA সেবা খুলুন", href: "https://bsp.brta.gov.bd/", title: "বাংলাদেশ সড়ক পরিবহন কর্তৃপক্ষের অফিসিয়াল সেবা পোর্টাল" },
  land: { label: "ভূমি সেবা খুলুন", href: "https://land.gov.bd/", title: "ভূমি মন্ত্রণালয়ের অফিসিয়াল সেবা পোর্টাল" },
  birthDeath: { label: "নিবন্ধন সেবা খুলুন", href: "https://bdris.gov.bd/", title: "জন্ম ও মৃত্যু নিবন্ধনের অফিসিয়াল পোর্টাল" },
  barCouncil: { label: "বার কাউন্সিল খুলুন", href: "https://barcouncil.gov.bd/", title: "বাংলাদেশ বার কাউন্সিলের অফিসিয়াল পোর্টাল" },
  lawJusticeDivision: { label: "আইন বিভাগ খুলুন", href: "https://lawjusticediv.gov.bd/", title: "আইন ও বিচার বিভাগের অফিসিয়াল পোর্টাল" },
  internationalCrimesTribunal: { label: "সরকারি তথ্য খুলুন", href: "https://ictbdinvestigation.gov.bd/", title: "আন্তর্জাতিক অপরাধ ট্রাইব্যুনাল-সংশ্লিষ্ট তদন্ত সংস্থার অফিসিয়াল পোর্টাল" },
  judiciary: { label: "বিচার বিভাগ খুলুন", href: "https://judiciary.gov.bd/", title: "বাংলাদেশ বিচার বিভাগের অফিসিয়াল পোর্টাল" },
  eCourt: { label: "ই-কোর্ট খুলুন", href: "https://ecourt.gov.bd/", title: "বাংলাদেশের ই-কোর্ট সরকারি পোর্টাল" },
  legalAidDirectory: { label: "লিগ্যাল এইড পোর্টাল খুলুন", href: "https://nlaso.gov.bd/", title: "বাংলাদেশ জাতীয় আইনগত সহায়তা সংস্থার অফিসিয়াল পোর্টাল" },
  districtJudiciary: { label: "জেলা নির্বাচন করে খুঁজুন", href: "https://judiciary.gov.bd/bn", title: "বাংলাদেশ বিচার বিভাগের বিভাগ ও জেলা নির্বাচন পোর্টাল" },
} satisfies Record<string, OfficialLink>;

export const lawEnforcementLinks = {
  emergency: { label: "৯৯৯-এ কল করুন", href: "tel:999", title: "বাংলাদেশ জাতীয় জরুরি সেবা ৯৯৯" },
  policePortal: { label: "পুলিশ পোর্টাল", href: "http://police.portal.gov.bd/", title: "বাংলাদেশ পুলিশের অফিসিয়াল পোর্টাল" },
  onlineGd: { label: "অনলাইন জিডি করুন", href: "https://gd.police.gov.bd/", title: "বাংলাদেশ পুলিশের অনলাইন জিডি পোর্টাল" },
  policeClearance: { label: "পুলিশ ক্লিয়ারেন্স", href: "https://pcc.police.gov.bd/ords/r/pcc/pcc/login_desktop", title: "বাংলাদেশ পুলিশের পুলিশ ক্লিয়ারেন্স পোর্টাল" },
  cyberComplaint: { label: "সাইবার অভিযোগ তথ্য", href: "https://www.cid.gov.bd/hot-line-number-for-cyber-complain", title: "বাংলাদেশ পুলিশের CID সাইবার অভিযোগের অফিসিয়াল তথ্য" },
  rab: { label: "RAB পোর্টাল", href: "https://www.rab.gov.bd/", title: "Rapid Action Battalion official website" },
  cid: { label: "CID পোর্টাল", href: "https://www.cid.gov.bd/", title: "Criminal Investigation Department official website" },
  specialBranch: { label: "Special Branch", href: "https://specialbranch.gov.bd/", title: "Special Branch Bangladesh Police official website" },
  dmp: { label: "DMP পোর্টাল", href: "https://dmp.gov.bd/", title: "Dhaka Metropolitan Police official website" },
  fireService: { label: "ফায়ার সার্ভিস", href: "https://fireservice.gov.bd/", title: "Fire Service and Civil Defence Bangladesh official website" },
  ansarVdp: { label: "আনসার-ভিডিপি", href: "https://ansarvdp.gov.bd/", title: "Bangladesh Ansar and VDP official website" },
  coastGuard: { label: "কোস্ট গার্ড", href: "https://coastguard.gov.bd/", title: "Bangladesh Coast Guard official website" },
  bgb: { label: "BGB পোর্টাল", href: "http://bgb.gov.bd/", title: "Border Guard Bangladesh official website" },
  army: { label: "সেনাবাহিনী পোর্টাল", href: "https://www.army.mil.bd/", title: "বাংলাদেশ সেনাবাহিনীর অফিসিয়াল ওয়েবসাইট" },
  navy: { label: "নৌবাহিনী পোর্টাল", href: "https://www.navy.mil.bd/", title: "বাংলাদেশ নৌবাহিনীর অফিসিয়াল ওয়েবসাইট" },
  airForce: { label: "বিমানবাহিনী পোর্টাল", href: "https://baf.mil.bd/", title: "বাংলাদেশ বিমানবাহিনীর অফিসিয়াল ওয়েবসাইট" },
  antiCorruptionCommission: { label: "দুদক পোর্টাল খুলুন", href: "https://acc.org.bd/", title: "দুর্নীতি দমন কমিশনের অফিসিয়াল পোর্টাল" },
  } satisfies Record<string, OfficialLink>;

export const mediaLinks = {
  prothomAlo: { label: "প্রথম আলো", href: "https://www.prothomalo.com/", title: "Prothom Alo daily newspaper official website" },
  dailyStar: { label: "The Daily Star", href: "https://www.thedailystar.net/", title: "The Daily Star English newspaper official website" },
  kalerKantho: { label: "কালের কণ্ঠ", href: "https://www.kalerkantho.com/", title: "Kaler Kantho daily newspaper official website" },
  bdnews24: { label: "bdnews24.com", href: "https://bdnews24.com/", title: "bdnews24.com online news portal" },
  banglaTribune: { label: "বাংলা ট্রিবিউন", href: "https://www.banglatribune.com/", title: "Bangla Tribune news portal" },
  btv: { label: "বাংলাদেশ টেলিভিশন (BTV)", href: "https://btv.gov.bd/", title: "Bangladesh Television official government broadcaster portal" },
  channelI: { label: "চ্যানেল আই", href: "https://www.channelionline.com/", title: "Channel i online news and media portal" },
  independent: { label: "ইন্ডিপেন্ডেন্ট টেলিভিশন", href: "https://www.independent24.com/", title: "Independent Television news portal" },
  somoyTv: { label: "সময় টিভি", href: "https://www.somoynews.tv/", title: "Somoy TV official news portal" },
  ekattor: { label: "একাত্তর টিভি", href: "https://www.ekattor.tv/", title: "Ekattor TV official news portal" },
} satisfies Record<string, OfficialLink>;

type OfficialAgencyLogo = {
  src: string;
  alt: string;
  source: string;
};

export const officialAgencyLogos: Record<string, OfficialAgencyLogo> = {
  police: {
    src: "/manus-storage/bangladesh-police-emblem_cd996673.svg",
    alt: "বাংলাদেশ পুলিশের অফিসিয়াল প্রতীক",
    source: "https://commons.wikimedia.org/wiki/File:Bangladesh_Police_Emblem.svg",
  },
  policePortal: {
    src: "/manus-storage/police-official_eff1903b.webp",
    alt: "বাংলাদেশ পুলিশ অফিসিয়াল পোর্টাল চিহ্ন",
    source: "https://police.portal.gov.bd/",
  },
  cyber: {
    src: "/manus-storage/bangladesh-police-emblem_cd996673.svg",
    alt: "বাংলাদেশ পুলিশের CID সাইবার ইউনিটের জন্য ব্যবহৃত অফিসিয়াল পুলিশ প্রতীক",
    source: "https://commons.wikimedia.org/wiki/File:Bangladesh_Police_Emblem.svg",
  },
  cid: {
    src: "/manus-storage/bangladesh-police-emblem_cd996673.svg",
    alt: "বাংলাদেশ পুলিশের CID ইউনিটের অফিসিয়াল পুলিশ প্রতীক",
    source: "https://commons.wikimedia.org/wiki/File:Bangladesh_Police_Emblem.svg",
  },
  specialBranch: {
    src: "/manus-storage/special-branch_64c3869b.webp",
    alt: "বাংলাদেশ পুলিশের স্পেশাল ব্রাঞ্চের অফিসিয়াল চিহ্ন",
    source: "https://specialbranch.gov.bd/",
  },
  dmp: {
    src: "/manus-storage/dmp_5d9e2be7.webp",
    alt: "ঢাকা মেট্রোপলিটন পুলিশের অফিসিয়াল চিহ্ন",
    source: "https://dmp.gov.bd/",
  },
  fireService: {
    src: "/manus-storage/fire-service_9d008f31.webp",
    alt: "বাংলাদেশ ফায়ার সার্ভিস ও সিভিল ডিফেন্সের অফিসিয়াল প্রতীক",
    source: "https://commons.wikimedia.org/wiki/File:Flag_of_Bangladesh_Fire_Service_%26_Civil_Defence.png",
  },
  ansarVdp: {
    src: "/manus-storage/ansar-vdp_f37d615c.webp",
    alt: "বাংলাদেশ আনসার ও গ্রাম প্রতিরক্ষা বাহিনীর অফিসিয়াল পোর্টাল চিহ্ন",
    source: "https://ansarvdp.gov.bd/",
  },
  coastGuard: {
    src: "/manus-storage/coast-guard_b62d8684.webp",
    alt: "বাংলাদেশ কোস্ট গার্ডের অফিসিয়াল পোর্টাল চিহ্ন",
    source: "https://coastguard.gov.bd/",
  },
  narcotics: {
    src: "/manus-storage/dnc_cad21d96.webp",
    alt: "মাদকদ্রব্য নিয়ন্ত্রণ অধিদপ্তরের অফিসিয়াল চিহ্ন",
    source: "https://dnc.gov.bd/",
  },
  bgb: {
    src: "/manus-storage/bgb_509a7bfe.webp",
    alt: "বর্ডার গার্ড বাংলাদেশের অফিসিয়াল পোর্টাল চিহ্ন",
    source: "https://bgb.gov.bd/",
  },
  army: {
    src: "/manus-storage/bangladesh-army-emblem_9d28477e.svg",
    alt: "বাংলাদেশ সেনাবাহিনীর অফিসিয়াল প্রতীক",
    source: "https://commons.wikimedia.org/wiki/File:Flag_of_the_Bangladesh_Army.svg",
  },
  navy: {
    src: "/manus-storage/bangladesh-navy-emblem_5fccd0f7.svg",
    alt: "বাংলাদেশ নৌবাহিনীর অফিসিয়াল প্রতীক",
    source: "https://commons.wikimedia.org/wiki/File:Emblem_of_the_Bangladesh_Navy.svg",
  },
  airForce: {
    src: "/manus-storage/bangladesh-air-force-roundel_936dc045.svg",
    alt: "বাংলাদেশ বিমানবাহিনীর অফিসিয়াল রাউন্ডেল",
    source: "https://commons.wikimedia.org/wiki/File:Roundel_of_Bangladesh.svg",
  },
};

function OfficialAgencyMark({ logo, fallbackLabel }: { logo?: OfficialAgencyLogo; fallbackLabel?: string }) {
  const [imgError, setImgError] = useState(false);
  if (!logo || imgError) {
    return (
      <span className="utility-card-icon official-logo-fallback" aria-label={`${fallbackLabel ?? "সরকারি"} অফিসিয়াল পোর্টাল`}>
        <strong>{fallbackLabel ?? "সরকারি"}</strong>
        <small>অফিসিয়াল পোর্টাল</small>
      </span>
    );
  }

  return (
    <span className="utility-card-icon official-logo-icon" data-logo-source={logo.source}>
      <img 
        src={logo.src} 
        alt={logo.alt} 
        loading="lazy" 
        decoding="async" 
        onError={() => setImgError(true)} 
      />
    </span>
  );
}

const weatherSource: OfficialLink = {
  label: "BMD-এর সর্বশেষ বার্তা দেখুন",
  href: "https://www.bmd.gov.bd/",
  title: "বাংলাদেশ আবহাওয়া অধিদপ্তরের অফিসিয়াল পূর্বাভাস ও সতর্কতা",
};

function handleOfficialClick(link: OfficialLink, kind: string) {
  trackOutbound(link.title, link.href, kind);
  trackEvent("official_shortcut_click", { label: link.label, destination: link.href, shortcut_kind: kind });
}

function OfficialAction({ link, kind, className = "" }: { link: OfficialLink; kind: string; className?: string }) {
  return (
    <ExternalLinkWithFallback
      href={link.href}
      title={link.title}
      ariaLabel={`${link.title} খুলুন`}
      className={`utility-card-action ${className}`.trim()}
      wrapperClassName="utility-card-link-wrapper"
      showExternalIcon={false}
      onClick={() => handleOfficialClick(link, kind)}
    >
      <span>{link.label}</span>
      <ArrowUpRight size={15} aria-hidden="true" />
    </ExternalLinkWithFallback>
  );
}

function WeatherMessageCard() {
  const { isEnglish } = useLanguage();
  return (
    <article className="utility-card weather-message-card">
      <div className="utility-card-topline">
        <span className="bmd-weather-logo" aria-hidden="true">
          <span className="bmd-weather-logo-ring"><CloudSun size={20} /></span>
          <span className="bmd-weather-logo-label">BMD WEATHER</span>
        </span>
        <span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> {isEnglish ? "Official BMD Source" : "BMD অফিসিয়াল উৎস"}</span>
      </div>
      <h3>{isEnglish ? "Trusted Weather Bulletin" : "বিশ্বস্ত আবহাওয়া বার্তা"}</h3>
      <p>{isEnglish ? "Get the latest official forecasts on rainfall, storms, heatwaves, and cyclones from Bangladesh Meteorological Department." : "বৃষ্টি, ঝড়, তাপপ্রবাহ বা ঘূর্ণিঝড়ের সর্বশেষ পূর্বাভাস জানতে বাংলাদেশ আবহাওয়া অধিদপ্তরের অফিসিয়াল বুলেটিন দেখুন।"}</p>
      <div className="utility-safety-note">
        <strong>{isEnglish ? "Safety Notice:" : "নিরাপদ তথ্যের নিয়ম:"}</strong> {isEnglish ? "Weather updates may vary by region and time. Verify the latest official advisory before travel or agriculture work." : "আবহাওয়ার বার্তা এলাকা ও সময়ভেদে বদলাতে পারে। যাত্রা বা কৃষিকাজের আগে সর্বশেষ সরকারি পূর্বাভাস যাচাই করুন।"}
      </div>
      <OfficialAction link={weatherSource} kind="weather_forecast" />
      <small className="utility-card-note">{isEnglish ? "SahajContact does not issue weather forecasts; it provides direct access to official BMD sources." : "SahajContact নিজে আবহাওয়ার পূর্বাভাস প্রকাশ করে না; এটি অফিসিয়াল BMD উৎসে যাওয়ার সহজ পথ।"}</small>
    </article>
  );
}

function BillCardView({ card }: { card: BillCard }) {
  const { isEnglish } = useLanguage();
  const Icon = card.icon;
  return (
    <article className="utility-card bill-card bill-card-featured">
      <div className="utility-card-topline">
        <span className="bill-card-logo" aria-hidden="true">
          <Icon size={18} />
          <span>PAY PORTAL</span>
        </span>
        <span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> {isEnglish ? "Verified Portal" : "অফিসিয়াল পোর্টাল"}</span>
      </div>
      <h3>{card.title}</h3>
      <p>{card.description}</p>
      <div className="utility-provider-list" aria-label={`${card.title} প্রদানকারী`}>
        {card.providers.map((provider) => <span key={provider}>{provider}</span>)}
      </div>
      <div className="utility-card-actions">
        {card.links.map((link) => <OfficialAction key={link.href} link={link} kind="bill_payment" />)}
      </div>
      <small className="utility-card-note">{card.actionLabel} {isEnglish ? "will open the official portal in a new tab." : "চাপলে সংশ্লিষ্ট অফিসিয়াল সাইট নতুন ট্যাবে খুলবে।"}</small>
    </article>
  );
}

function RateReferenceCard() {
  const rateReference: OfficialLink = {
    label: "বাংলাদেশ ব্যাংকের রেট দেখুন",
    href: "https://www.bb.org.bd/en/index.php/econdata/exchangerate",
    title: "Bangladesh Bank exchange-rate reference",
  };
  const checkedDate = "১৩ আগস্ট ২০২৬";
  return (
    <article className="utility-card rate-card">
      <div className="utility-card-topline">
        <span className="utility-card-icon" aria-hidden="true"><Banknote size={22} /></span>
        <span className="utility-card-new-badge" aria-label="নতুন সেবা">নতুন</span>
        <span className="utility-card-source"><CheckCircle2 size={14} aria-hidden="true" /> রেফারেন্স রেট</span>
      </div>
      <h3>আজকের রেমিট্যান্স রেট</h3>
      <p>চূড়ান্ত payout rate প্রেরক বা MTO অনুযায়ী বদলাতে পারে। নিচের টেবিলটি সরকারি রেফারেন্স দেখার দ্রুত পথ।</p>
      <div className="rate-table-wrap">
        <table className="rate-table">
          <caption>রেট যাচাইয়ের টেবিল — সর্বশেষ দেখা: {checkedDate}</caption>
          <thead><tr><th scope="col">মুদ্রা</th><th scope="col">রেফারেন্স</th></tr></thead>
          <tbody>
            <tr><th scope="row">$1 USD</th><td><a href={rateReference.href} target="_blank" rel="noopener noreferrer" onClick={() => handleOfficialClick(rateReference, "exchange_rate")}>সরকারি পাতায় দেখুন ↗</a></td></tr>
            <tr><th scope="row">€1 EUR</th><td><a href={rateReference.href} target="_blank" rel="noopener noreferrer" onClick={() => handleOfficialClick(rateReference, "exchange_rate")}>সরকারি পাতায় দেখুন ↗</a></td></tr>
            <tr><th scope="row">১ SAR রিয়াল</th><td><a href={rateReference.href} target="_blank" rel="noopener noreferrer" onClick={() => handleOfficialClick(rateReference, "exchange_rate")}>সরকারি পাতায় দেখুন ↗</a></td></tr>
          </tbody>
        </table>
      </div>
      <OfficialAction link={rateReference} kind="exchange_rate" />
      <small className="utility-card-note">এটি reference information; bKash, Nagad, ব্যাংক বা MTO-এর হাতে পাওয়া রেট আলাদা হতে পারে।</small>
    </article>
  );
}

export default function UtilityAndExpatriateSections({ afterLawEnforcement }: { afterLawEnforcement?: ReactNode }) {
  const { isEnglish } = useLanguage();
  const [selectedRegion, setSelectedRegion] = useState<RegionalRegion>("bangladesh");
  const [isProbashiOpen, setIsProbashiOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    const hash = window.location.hash.replace(/^#/, "");
    return hash === "expatriates" || hash === "probashi-services";
  });
  const activeRegionalGuide = regionalGuides.find((guide) => guide.id === selectedRegion) ?? regionalGuides[0];

  useEffect(() => {
    const openFromHash = () => {
      const hash = window.location.hash.replace(/^#/, "");
      const isExpatriateHash = hash === "expatriates" || hash === "probashi-services";
      if (!isExpatriateHash) return;

      setIsProbashiOpen(true);
      window.setTimeout(() => {
        document.getElementById("probashi-services")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 60);
    };

    openFromHash();
    window.addEventListener("hashchange", openFromHash);
    return () => window.removeEventListener("hashchange", openFromHash);
  }, []);

  const handleRegionChange = (region: RegionalRegion) => {
    setSelectedRegion(region);
    trackEvent("regional_service_guide_select", { region, language: isEnglish ? "en" : "bn" });
  };

  const [hasSummaryArtError, setHasSummaryArtError] = useState<Record<string, boolean>>({});

  const handleSummaryArtError = (key: string) => {
    setHasSummaryArtError((prev) => ({ ...prev, [key]: true }));
  };

  if (isEnglish) return <UtilityAndExpatriateSectionsEnglish afterLawEnforcement={afterLawEnforcement} />;

  return (
    <>
      <div className="flex flex-col">
      <section id="weather-message" className="utility-section weather-section" aria-labelledby="weather-heading" style={{ order: 1 }}>
        <div className="container">
          <div className="utility-section-heading">
            <span className="section-number">০২ / নিরাপদ তথ্য</span>
            <h2 id="weather-heading">বিশ্বস্ত আবহাওয়া বার্তা</h2>
            <p>বাংলাদেশ আবহাওয়া অধিদপ্তরের অফিসিয়াল পূর্বাভাস ও সতর্কতা এক ক্লিকে দেখুন।</p>
          </div>
          <div className="utility-card-grid weather-card-grid">
            <WeatherMessageCard />
          </div>
        </div>
      </section>

      <section id="bill-payment" className="utility-section bill-payment-section" aria-labelledby="bill-payment-heading" style={{ order: 8 }}>
        <div className="container">
          <details className="utility-folder" data-utility-folder="bill-payment">
            <summary className="utility-folder-summary thematic-summary thematic-summary-bill" aria-controls="bill-payment-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker">
                  <span className="thematic-summary-icon" aria-hidden="true"><Smartphone size={22} /></span>
                  <span className="section-number">০২ / দৈনন্দিন বিল</span>
                </span>
                <span id="bill-payment-heading" className="utility-folder-title">বিল পে করুন ঘরে বসে</span>
                <span className="utility-section-lede">লাইনে দাঁড়ানো শেষ - এখন ঘরে বসে বিল দিন</span>
              </span>
              <span className="thematic-summary-art bill-payment-summary-art" aria-hidden="true">
                {hasSummaryArtError['bill'] ? (
                  <span className="thematic-summary-art-fallback" aria-hidden="true" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%', background: 'rgba(217,150,46,0.1)', color: '#d9962e', borderRadius: '12px' }}>📱</span>
                ) : (
                  <img src="/manus-storage/sahajcontact-bill-payment-customer_2d64369c.png" alt="" loading="lazy" onError={() => handleSummaryArtError('bill')} />
                )}
              </span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="bill-payment-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>প্রতিটি বাটন আপনাকে সংশ্লিষ্ট operator-এর অফিসিয়াল billing বা recharge পোর্টালে নিয়ে যাবে। সাহজসেবা নিজে পেমেন্ট তথ্য সংগ্রহ বা বিল প্রসেস করে না।</p>
              </div>
              <div className="utility-card-grid" aria-label="বিল পেমেন্টের অফিসিয়াল শর্টকাট">
                {billCards.map((card) => <BillCardView key={card.title} card={card} />)}
              </div>
            </div>
          </details>
        </div>
      </section>

      <section id="agriculture-services" className="utility-section agriculture-section" aria-labelledby="agriculture-heading" style={{ order: 2 }}>
        <div className="container">
          <details className="utility-folder" data-utility-folder="agriculture-services">
            <summary className="utility-folder-summary thematic-summary thematic-summary-agriculture" aria-controls="agriculture-services-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true"><Wheat size={22} /></span><span className="section-number">০৩ / কৃষকের সহায়তা</span></span>
                <span id="agriculture-heading" className="utility-folder-title">{isEnglish ? "Agriculture Services" : "কৃষি সেবা"}</span>
                <span className="utility-section-lede">{isEnglish ? "Get help for farmers, subsidies, and crop information" : "কৃষকের সরকারি আবেদন ও তথ্য এক জায়গায়"}</span>
              </span>
              <span className="thematic-summary-art" aria-hidden="true">
                {hasSummaryArtError['agri'] ? (
                  <span className="thematic-summary-art-fallback" aria-hidden="true" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%', background: 'rgba(15,118,110,0.1)', color: '#0f766e', borderRadius: '12px' }}>🌾</span>
                ) : (
                  <img src="/manus-storage/sahajcontact-agriculture-farmer_a0281eec.png" alt="" loading="lazy" onError={() => handleSummaryArtError('agri')} />
                )}
              </span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="agriculture-services-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>কৃষি সম্প্রসারণ অধিদপ্তর ও খাদ্য অধিদপ্তরের সরকারি পোর্টাল থেকে কৃষি সেবা, কৃষক আবেদন, নিবন্ধন, ফরম এবং আবহাওয়ার তথ্য দেখুন। সাহজসেবা কোনো সরকারি প্রতিনিধি নয় এবং আপনার হয়ে আবেদন বা সরকারি ফি গ্রহণ করে না।</p>
              </div>
              <div className="utility-card-grid agriculture-grid" aria-label="কৃষকদের সরকারি কৃষি সেবার অফিসিয়াল শর্টকাট">
                <article className="utility-card agriculture-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Sprout size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> সরকারি ডিরেক্টরি</span></div>
                  <h3>কৃষি সেবা ও পরামর্শ</h3>
                  <p>কৃষি সম্প্রসারণ অধিদপ্তরের সেবা, নোটিশ, নাগরিক ই-সার্ভিস ও কৃষি বিষয়ক পোর্টাল খুঁজুন।</p>
                  <OfficialAction link={agricultureLinks.dae} kind="agriculture_dae" />
                  <small className="utility-card-note">সেবা, যোগ্যতা ও সময়সীমা অফিসিয়াল সাইটে যাচাই করুন।</small>
                </article>

                <article className="utility-card agriculture-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><ClipboardCheck size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> খাদ্য অধিদপ্তর</span></div>
                  <h3>কৃষক আবেদন পোর্টাল</h3>
                  <p>খাদ্য অধিদপ্তরের কৃষকের অ্যাপ/আবেদন পোর্টালে কৃষক-সংক্রান্ত সরকারি কার্যক্রম দেখুন।</p>
                  <OfficialAction link={agricultureLinks.farmerApply} kind="agriculture_farmer_apply" />
                  <small className="utility-card-note">আবেদন খোলার সময়, ফসল ও এলাকার শর্ত পোর্টালে দেখুন।</small>
                </article>

                <article className="utility-card agriculture-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Landmark size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> কৃষক নিবন্ধন</span></div>
                  <h3>কৃষক নিবন্ধন / স্ট্যাটাস</h3>
                  <p>খাদ্য অধিদপ্তরের কৃষক তথ্য ব্যবস্থাপনা পোর্টালে নিবন্ধন ও বর্তমান নির্দেশনা যাচাই করুন।</p>
                  <OfficialAction link={agricultureLinks.farmerRegister} kind="agriculture_farmer_register" />
                  <small className="utility-card-note">NID, মোবাইল ও ব্যক্তিগত তথ্য শুধু সরকারি ডোমেইনেই দিন।</small>
                </article>

                                <article className="utility-card agriculture-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><CloudSun size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> BMD অফিসিয়াল</span></div>
                  <h3>আবহাওয়া ও কৃষি পরামর্শ</h3>
                  <p>৭ দিনের বৃষ্টি, ঝড়ের পূর্বাভাস + কোন সময় কোন ফসল লাগাবেন</p>
                  <OfficialAction link={agricultureLinks.bmdWeather} kind="agriculture_weather_advice" />
                  <small className="utility-card-note">আবহাওয়া ও কৃষি পরামর্শ এলাকা ও মৌসুমভেদে বদলাতে পারে—সর্বশেষ সরকারি বার্তা যাচাই করুন।</small>
                </article>
                <article className="utility-card agriculture-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><WalletCards size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> কৃষি মন্ত্রণালয়</span></div>
                  <h3>কৃষক কার্ড ও ভর্তুকি</h3>
                  <p>সার, বীজ, ৪% ঋণ ও প্রণোদনার আবেদন তথ্য</p>
                  <OfficialAction link={agricultureLinks.subsidy} kind="agriculture_farmer_card_subsidy" />
                  <small className="utility-card-note">ভর্তুকি, ঋণের হার, যোগ্যতা ও আবেদন-সময় খাতভেদে বদলাতে পারে—অফিসিয়াল ঘোষণাই চূড়ান্ত।</small>
                </article>
                <article className="utility-card agriculture-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><FileText size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> সরকারি ফরম</span></div>
                  <h3>সরকারি ফরম ও আবেদন</h3>
                  <p>কৃষি সম্প্রসারণ অধিদপ্তরের ফরম ও আবেদনের নমুনা পেজ থেকে প্রয়োজনীয় ফরম খুঁজুন।</p>
                  <OfficialAction link={agricultureLinks.forms} kind="agriculture_forms" />
                  <small className="utility-card-note">ফরমের সর্বশেষ সংস্করণ ও জমাদানের নিয়ম অফিসিয়াল সাইটে মিলিয়ে নিন।</small>
                </article>
              </div>
              <div className="utility-safety-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>নিরাপত্তা নোট:</strong> সাহজসেবা আবেদন জমা দেয় না, সরকারি ফি নেয় না এবং কোনো OTP/PIN চায় না। আবেদন করার আগে ঠিকানা যেন <strong>.gov.bd</strong> বা সংশ্লিষ্ট সরকারি পোর্টালের হয় তা যাচাই করুন।</p></div>
            </div>
          </details>
        </div>
      </section>

      <section id="probashi-services" className="utility-section probashi-section" aria-labelledby="probashi-heading" style={{ order: 3 }}>
        <span id="expatriates" className="utility-section-anchor" aria-hidden="true" />
        <div className="container">
          <details
            className="utility-folder"
            data-utility-folder="probashi-services"
            open={isProbashiOpen}
            onToggle={(event) => setIsProbashiOpen((event.currentTarget as HTMLDetailsElement).open)}
          >
            <summary className="utility-folder-summary thematic-summary thematic-summary-probashi" aria-controls="probashi-services-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true"><Plane size={22} /></span><span className="section-number">০৪ / বিশ্বজুড়ে বাংলাদেশ</span></span>
                <span id="probashi-heading" className="utility-folder-title">{isEnglish ? "Expatriate Services" : <>প্রবাসী সেবা <em>- Proudly Bangladeshi 🇧🇩</em></>}</span>
                <span className="utility-section-lede">{isEnglish ? "Passport, Visa, Remittance support for Bangladeshis abroad" : "দেশ থেকে হাজার মাইল দূরে, সেবা এক ক্লিকে"}</span>
              </span>
              <span className="thematic-summary-art" aria-hidden="true">
                {hasSummaryArtError['probashi'] ? (
                  <span className="thematic-summary-art-fallback" aria-hidden="true" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%', background: 'rgba(0,106,78,0.1)', color: '#006A4E', borderRadius: '12px' }}>✈️</span>
                ) : (
                  <img src="/manus-storage/sahajcontact-expatriate-family_ae6575fd.png" alt="" loading="lazy" onError={() => handleSummaryArtError('probashi')} />
                )}
              </span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="probashi-services-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>{isEnglish ? "Official entry points for Bangladeshi citizens abroad and their families, including BMET, visa status, remittance references, and family support in Bangladesh." : "বিদেশে থাকা বাংলাদেশি নাগরিক ও তাঁদের পরিবারের জন্য BMET, ভিসা-স্ট্যাটাস, রেমিট্যান্স রেফারেন্স এবং দেশে থাকা পরিবারের সেবা-পথ এক জায়গায়।"}</p>
              </div>

              {/* 5 Expat Guidelines moved to dedicated /expatriate-guide page as requested */}

              <section className="regional-service-guide" aria-labelledby="regional-service-guide-heading">
                <div className="regional-service-guide-header">
                  <div>
                    <span className="regional-service-guide-kicker">{isEnglish ? "REGIONAL WAYFINDING" : "আঞ্চলিক সেবা নির্দেশিকা"}</span>
                    <h3 id="regional-service-guide-heading">{isEnglish ? "Choose your current country" : "আপনি কোন দেশ থেকে সেবা খুঁজছেন?"}</h3>
                    <p>{isEnglish ? "Select a country to see the most relevant official routes for Bangladeshis." : "দেশ নির্বাচন করলে প্রবাসী বাংলাদেশিদের জন্য সবচেয়ে প্রাসঙ্গিক সরকারি পথগুলো দেখাবে।"}</p>
                  </div>
                  <label className="regional-service-guide-select-wrap" htmlFor="regional-service-guide-select">
                    <span>{isEnglish ? "Your country" : "আপনার দেশ"}</span>
                    <select id="regional-service-guide-select" value={selectedRegion} onChange={(event) => handleRegionChange(event.target.value as RegionalRegion)}>
                      {regionalGuides.map((guide) => <option key={guide.id} value={guide.id}>{guide.flag} {isEnglish ? guide.nameEn : guide.nameBn}</option>)}
                    </select>
                  </label>
                </div>

                <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 md:p-5" aria-labelledby="embassy-quick-dial-heading">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <span className="rounded-xl bg-primary/15 p-2.5 text-primary" aria-hidden="true"><Phone size={20} /></span>
                      <div>
                        <span className="text-[11px] font-bold uppercase tracking-wider text-primary">{isEnglish ? "PRIORITY CONTACTS" : "প্রবাসীদের দ্রুত যোগাযোগ"}</span>
                        <h4 id="embassy-quick-dial-heading" className="mt-1 text-base md:text-lg font-bold">{isEnglish ? "Embassy quick-dial directory" : "গুরুত্বপূর্ণ দূতাবাসের কুইক ডায়াল"}</h4>
                        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{isEnglish ? "Call the mission directly, then verify hours and service requirements on its official page." : "প্রয়োজনে সরাসরি ফোন করুন; কলের আগে অফিসিয়াল পেজে সময় ও সেবার নিয়ম যাচাই করুন।"}</p>
                      </div>
                    </div>
                    <span className="rounded-full border border-primary/20 bg-background px-3 py-1 text-[11px] font-semibold text-primary">{isEnglish ? "Official mission links" : "অফিসিয়াল মিশন লিংক"}</span>
                  </div>
                  <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    {priorityEmbassyQuickDials.map((embassy) => {
                      const phoneLink: OfficialLink = {
                        label: `${isEnglish ? "Call" : "কল করুন"} ${isEnglish ? embassy.countryEn : embassy.countryBn}`,
                        href: embassy.phoneHref,
                        title: isEnglish ? `${embassy.titleEn} phone` : `${embassy.titleBn} ফোন নম্বর`,
                      };
                      const officialLink: OfficialLink = {
                        label: isEnglish ? "Official page" : "অফিসিয়াল পেজ",
                        href: embassy.officialUrl,
                        title: isEnglish ? embassy.titleEn : embassy.titleBn,
                      };
                      return (
                        <div key={embassy.id} className="rounded-xl border border-border/70 bg-card/80 p-3 shadow-sm">
                          <div className="flex items-center gap-2 text-sm font-bold"><span aria-hidden="true">{embassy.flag}</span><span>{isEnglish ? embassy.countryEn : embassy.countryBn}</span></div>
                          <a href={phoneLink.href} aria-label={phoneLink.title} onClick={() => handleOfficialClick(phoneLink, "embassy_quick_dial")} className="mt-3 flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground transition hover:bg-primary/90"><Phone size={14} aria-hidden="true" /><span>{phoneLink.label}</span></a>
                          <a href={officialLink.href} target="_blank" rel="noopener noreferrer" aria-label={officialLink.title} onClick={() => handleOfficialClick(officialLink, "embassy_official_page")} className="mt-2 flex items-center justify-between gap-2 text-[11px] font-semibold text-primary underline-offset-2 hover:underline"><span>{officialLink.label}</span><ArrowUpRight size={13} aria-hidden="true" /></a>
                          <p className="mt-2 text-[11px] text-muted-foreground">{embassy.phone}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="regional-service-guide-content" aria-live="polite">
                  <div className="regional-service-guide-country">
                    <span className="regional-service-guide-flag" aria-hidden="true">{activeRegionalGuide.flag}</span>
                    <div>
                      <span className="regional-service-guide-country-label">{isEnglish ? "Selected guide" : "নির্বাচিত নির্দেশিকা"}</span>
                      <h4>{isEnglish ? activeRegionalGuide.nameEn : activeRegionalGuide.nameBn}</h4>
                      <p>{isEnglish ? activeRegionalGuide.summaryEn : activeRegionalGuide.summaryBn}</p>
                    </div>
                  </div>
                  <div className="regional-service-guide-steps" aria-label={isEnglish ? "Safe service steps" : "নিরাপদ সেবা ধাপ"}>
                    {(isEnglish ? activeRegionalGuide.stepsEn : activeRegionalGuide.stepsBn).map((step, index) => <span key={step}><b>{index + 1}</b>{step}</span>)}
                  </div>
                  <div className="regional-service-guide-actions">
                    {activeRegionalGuide.links.map((link) => <OfficialAction key={link.href} link={{ ...link, label: isEnglish ? link.labelEn : link.labelBn }} kind={`regional_${activeRegionalGuide.id}`} />)}
                  </div>
                </div>
                <p className="regional-service-guide-disclaimer">{isEnglish ? "SahajContact only provides navigation. Fees, eligibility, appointments, and decisions belong to the relevant authority." : "SahajContact শুধু official পথে পৌঁছানোর সহায়তা করে। ফি, যোগ্যতা, অ্যাপয়েন্টমেন্ট ও সিদ্ধান্ত সংশ্লিষ্ট কর্তৃপক্ষের বিষয়।"}</p>
              </section>

              <div className="utility-card-grid probashi-grid" aria-label={isEnglish ? "Official expatriate service shortcuts" : "প্রবাসী সেবার অফিসিয়াল শর্টকাট"}>
                <article className="utility-card probashi-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><FileText size={22} /></span><span className="utility-card-new-badge" aria-label="জরুরি সেবা">অফিসিয়াল</span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ১. পাসপোর্ট ও ভিসা সেবা</span></div>
                  <h3>পাসপোর্ট, পুলিশ ক্লিয়ারেন্স ও NOC</h3>
                  <p>MRP/E-Passport নবায়ন, পুলিশ ক্লিয়ারেন্স সার্টিফিকেট (PCC) এবং ওয়েজ আর্নার্স কার্ডের অফিসিয়াল আবেদন।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={{ label: "E-Passport", href: "https://www.epassport.gov.bd/", title: "MRP/E-Passport official portal" }} kind="probashi_passport" />
                    <OfficialAction link={{ label: "Police PCC", href: "https://pcc.police.gov.bd/", title: "Police Clearance Certificate online application" }} kind="probashi_pcc" />
                    <OfficialAction link={{ label: "ওয়েজ আর্নার্স কার্ড", href: "https://wewb.gov.bd/", title: "WEWB official portal for wage earner card" }} kind="probashi_wewb" />
                  </div>
                  <small className="utility-card-note">পাসপোর্ট ডেলিভারি স্ট্যাটাস ও পুলিশ ক্লিয়ারেন্সের আবেদন নিজ দায়িত্বে সরকারি সাইটে করুন।</small>
                </article>

                <article className="utility-card probashi-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><WalletCards size={22} /></span><span className="utility-card-new-badge" aria-label="ব্যাংকিং">নিরাপদ</span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ২. টাকা পাঠানো ও ব্যাংকিং</span></div>
                  <h3>প্রবাসী কল্যাণ ব্যাংক ও রেমিট্যান্স</h3>
                  <p>প্রবাসী কল্যাণ ব্যাংক লোন/সেবা, রেমিট্যান্স রেট এবং এনআরবি/প্রবাসী অ্যাকাউন্ট খোলার অফিশিয়াল লিংক।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={{ label: "প্রবাসী কল্যাণ ব্যাংক", href: "https://pkb.gov.bd/", title: "Probashi Kallyan Bank loan and services" }} kind="probashi_pkb" />
                    <OfficialAction link={{ label: "রেমিট্যান্স রেট", href: "https://www.bb.org.bd/en/index.php/econdata/exchangerate", title: "Bangladesh Bank exchange rate" }} kind="probashi_forex" />
                    <OfficialAction link={{ label: "NRB ব্যাংক", href: "https://www.nrbcommercialbank.com/", title: "NRB Commercial Bank services" }} kind="probashi_nrb" />
                  </div>
                  <small className="utility-card-note">বৈধ চ্যানেলে রেমিট্যান্স পাঠিয়ে দেশের অর্থনীতিতে অবদান রাখুন।</small>
                </article>

                <article className="utility-card probashi-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><HeartHandshake size={22} /></span><span className="utility-card-new-badge" aria-label="সহায়তা">সরকারি</span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ৩. সরকারি ভাতা ও সহায়তা</span></div>
                  <h3>প্রবাসী কল্যাণ ভাতা ও বিমা সেবা</h3>
                  <p>মৃত্যু বা অসুস্থতার জন্য প্রবাসী কল্যাণ ভাতা, এয়ারপোর্ট প্রবাসী লাউঞ্জ এবং বিমা সেবার অফিসিয়াল তথ্য।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={{ label: "প্রবাসী কল্যাণ ভাতা", href: "https://wewb.gov.bd/", title: "WEWB welfare grants and assistance" }} kind="probashi_welfare" />
                    <OfficialAction link={{ label: "এয়ারপোর্ট লাউঞ্জ", href: "https://probashi.gov.bd/", title: "Airport probashi lounge helpline" }} kind="probashi_lounge" />
                    <OfficialAction link={{ label: "বিমা সেবা", href: "https://probashi.gov.bd/", title: "Probashi insurance services" }} kind="probashi_insurance" />
                  </div>
                  <small className="utility-card-note">কল্যাণ বোর্ডের নিয়ম অনুযায়ী সহায়তা ও অনুদানের আবেদন করুন।</small>
                </article>

                <article className="utility-card probashi-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Phone size={22} /></span><span className="utility-card-new-badge" aria-label="হেল্পলাইন">জরুরি</span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ৪. জরুরি হেল্পলাইন ও টিকিট</span></div>
                  <h3>দূতাবাস, হেল্পলাইন ও বিমান টিকিট</h3>
                  <p>সৌদি, UAE, USA, মালয়েশিয়া ও কাতার দূতাবাস নম্বর, প্রবাসী কল্যাণ হেল্পলাইন (১৬১৩৫) এবং বিমান টিকিট।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={{ label: "হেল্পলাইন ১৬১৩৫", href: "tel:16135", title: "Probashi Kallyan Helpline 16135" }} kind="probashi_hotline" />
                    <OfficialAction link={{ label: "বাংলাদেশ বিমান", href: "https://www.biman-airlines.com/", title: "Biman Bangladesh Airlines" }} kind="probashi_biman" />
                    <OfficialAction link={{ label: "US-Bangla", href: "https://www.usbair.com/", title: "US-Bangla Airlines" }} kind="probashi_usbangla" />
                  </div>
                  <small className="utility-card-note">জরুরি প্রয়োজনে ১৬১৩৫ নাম্বারে কল করুন অথবা সংশ্লিষ্ট দেশের বাংলাদেশ দূতাবাসে যোগাযোগ করুন।</small>
                </article>

                <article className="utility-card probashi-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Globe2 size={22} /></span><span className="utility-card-new-badge" aria-label="অন্যান্য">সেবা</span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ৫. অন্যান্য জরুরি সেবা</span></div>
                  <h3>BMET, NID সংশোধন ও ভূমি সেবা</h3>
                  <p>BMET রেজিস্ট্রেশন, বিদেশ থেকে NID সংশোধন এবং জমি/ওয়ারিশ সেবা (অনলাইন খাজনা)।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={{ label: "BMET রেজিস্ট্রেশন", href: "https://bmet.gov.bd/", title: "BMET registration portal" }} kind="probashi_bmet_reg" />
                    <OfficialAction link={{ label: "NID সংশোধন", href: "https://services.nidw.gov.bd/", title: "NID online services for expatriates" }} kind="probashi_nid_ex" />
                    <OfficialAction link={{ label: "অনলাইন খাজনা", href: "https://land.gov.bd/", title: "Land development tax and records" }} kind="probashi_land" />
                  </div>
                  <small className="utility-card-note">বিদেশ থেকে অনলাইনে এনআইডি ও ভূমি কর পরিশোধের অফিশিয়াল লিংক।</small>
                </article>

                <RateReferenceCard />
              </div>
              <div className="utility-safety-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>নিরাপত্তা নোট:</strong> সরকারি বা operator-এর official domain ছাড়া কোনো লিংকে পাসপোর্ট, NID, OTP, PIN বা ব্যাংক তথ্য দেবেন না।</p></div>
            </div>
          </details>
        </div>
      </section>

      <section id="citizen-services" className="utility-section citizen-services-section" aria-labelledby="citizen-services-heading" style={{ order: 7 }}>
        <div className="container">
          <details className="utility-folder" data-utility-folder="citizen-services">
            <summary className="utility-folder-summary thematic-summary thematic-summary-citizen" aria-controls="citizen-services-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true"><Scale size={22} /></span><span className="section-number">০৫ / পরিচয় ও নাগরিকতা</span></span>
                <span id="citizen-services-heading" className="utility-folder-title">{isEnglish ? "Court & Legal Services" : "আদালত সেবা / নাগরিক সেবা"}</span>
                <span className="utility-section-lede">{isEnglish ? "Find lawyers, case status, and legal aid through official government portals" : "আদালত, আইন, NID, পাসপোর্ট, ভূমি ও নিবন্ধনের অফিসিয়াল পোর্টাল এক জায়গায়"}</span>
              </span>
              <span className="thematic-summary-art" aria-hidden="true"><img src="/manus-storage/sahajcontact-justice-court_8a9c1234.png" alt="" loading="lazy" /></span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="citizen-services-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>আদালত ও আইন-সংক্রান্ত প্রতিষ্ঠানসহ বাংলাদেশের বহুল ব্যবহৃত অনলাইন নাগরিক সেবার সরকারি entry point এখানে দেওয়া হলো। সাহজসেবা কোনো আবেদন জমা দেয় না, অনুমোদন নিশ্চিত করে না এবং সরকারি ফি/সময় নির্ধারণ করে না।</p>
                <p className="mt-2 text-xs text-slate-500">নিচের আদালত ও আইনসেবা সরকারি গন্তব্যগুলো সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED}। সেবার নিয়ম বা প্রাপ্যতা সংশ্লিষ্ট সরকারি পোর্টাল থেকে আবার মিলিয়ে নিন।</p>
              </div>
              <div className="utility-card-grid citizen-services-grid" aria-label="প্রয়োজনীয় অনলাইন নাগরিক সেবার অফিসিয়াল শর্টকাট">
                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Landmark size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> নির্বাচন কমিশন</span></div>
                  <h3>জাতীয় পরিচয়পত্র (NID)</h3>
                  <p>NID নিবন্ধন, তথ্য সংশোধন, পুনর্মুদ্রণ ও নাগরিক পরিচয়-সংক্রান্ত অফিসিয়াল সেবা দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.nid} kind="citizen_nid" />
                  <small className="utility-card-note">NID নম্বর, জন্মতারিখ ও OTP শুধু services.nidw.gov.bd-এর মতো অফিসিয়াল পোর্টালেই দিন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Scale size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> বাংলাদেশ বার কাউন্সিল</span></div>
                  <h3>বাংলাদেশ বার কাউন্সিল</h3>
                  <p>আইনজীবী, নোটিশ ও প্রকাশিত আইন-পেশাসংক্রান্ত সরকারি তথ্য বার কাউন্সিলের অফিসিয়াল পোর্টালে দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.barCouncil} kind="bangladesh_bar_council" />
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · আইনজীবী-সংক্রান্ত বর্তমান তথ্য ও নোটিশ কেবল বার কাউন্সিলের অফিসিয়াল পোর্টালে যাচাই করুন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Scale size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> আইন ও বিচার বিভাগ</span></div>
                  <h3>আইন ও বিচার বিভাগ</h3>
                  <p>আইন, বিচার বিভাগ, নোটিশ ও নাগরিকের জন্য প্রকাশিত সরকারি তথ্য সংশ্লিষ্ট বিভাগের পোর্টালে দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.lawJusticeDivision} kind="law_justice_division" />
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · কোনো আবেদন বা আইনি প্রক্রিয়ার শর্ত সংশ্লিষ্ট সরকারি নোটিশ থেকে চূড়ান্তভাবে যাচাই করুন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Scale size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> আন্তর্জাতিক অপরাধ ট্রাইব্যুনাল</span></div>
                  <h3>আন্তর্জাতিক অপরাধ ট্রাইব্যুনাল-সংশ্লিষ্ট সরকারি তথ্য</h3>
                  <p>আন্তর্জাতিক অপরাধ ট্রাইব্যুনাল-সংশ্লিষ্ট তদন্ত সংস্থার প্রকাশিত সরকারি তথ্য, নোটিশ ও আপডেট দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.internationalCrimesTribunal} kind="international_crimes_tribunal" />
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · এই কার্ডটি সংশ্লিষ্ট সরকারি তদন্ত সংস্থার তথ্যপোর্টালে নিয়ে যাবে; মামলার তথ্যের জন্য সরকারি প্রকাশনা যাচাই করুন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Landmark size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> বাংলাদেশ বিচার বিভাগ</span></div>
                  <h3>বাংলাদেশ বিচার বিভাগ</h3>
                  <p>বিচার বিভাগের নাগরিক সেবা, প্রকাশিত তথ্য, ই-কার্যতালিকা ও সহায়ক সরকারি লিংক দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.judiciary} kind="bangladesh_judiciary" />
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · আদালতের সময়সূচি, নোটিশ বা সেবা ব্যবহারের আগে সংশ্লিষ্ট আদালত বা বিচার বিভাগের নির্দেশনা মিলিয়ে নিন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Smartphone size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ই-কোর্ট</span></div>
                  <h3>ই-কোর্ট সরকারি সেবা</h3>
                  <p>ডিজিটাল আদালতসেবা ও ই-কোর্টের সরকারি তথ্য এক জায়গায় দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.eCourt} kind="bangladesh_ecourt" />
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · ই-কোর্টের সেবা, প্রাপ্যতা ও ব্যবহার নির্দেশনা পোর্টালের সর্বশেষ সরকারি তথ্য থেকে যাচাই করুন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Phone size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> জাতীয় আইনগত সহায়তা</span></div>
                  <h3>আইনগত সহায়তা Hotline — ১৬৬৯৯</h3>
                  <p>সরকারি জাতীয় লিগ্যাল এইড হেল্পলাইনে সহায়তার জন্য কল করুন। জরুরি চিকিৎসা বা জননিরাপত্তার ঘটনায় ৯৯৯ ব্যবহার করুন।</p>
                  <a href="tel:16699" className="utility-card-action" aria-label="জাতীয় আইনগত সহায়তা hotline ১৬৬৯৯-এ কল করুন" onClick={() => trackEvent("legal_aid_hotline_click", { hotline: "16699" })}>
                    <span>১৬৬৯৯-এ কল করুন</span><Phone size={15} aria-hidden="true" />
                  </a>
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · সরকারি পোর্টাল অনুযায়ী এটি আইনগত সহায়তার তথ্য ও দিকনির্দেশনার জন্য; কোনো মামলা-ফলাফল নিশ্চিত নয়।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Landmark size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> জেলা-ভিত্তিক সরকারি খোঁজ</span></div>
                  <h3>জেলা আদালত ও লিগ্যাল এইড খুঁজুন</h3>
                  <p>বিভাগ ও জেলা নির্বাচন করে সরকারি বিচার বিভাগে আপনার এলাকার আদালতসেবা খুঁজুন; লিগ্যাল এইড অফিসের সর্বশেষ তথ্যের জন্য জাতীয় পোর্টাল দেখুন।</p>
                  <div className="flex flex-wrap gap-2">
                    <OfficialAction link={citizenServicesLinks.districtJudiciary} kind="district_judiciary_directory" className="!w-auto" />
                    <OfficialAction link={citizenServicesLinks.legalAidDirectory} kind="legal_aid_directory" className="!w-auto" />
                  </div>
                  <small className="utility-card-note">সর্বশেষ যাচাই: {JUSTICE_LINK_LAST_VERIFIED} · পরিবর্তনশীল ৬৪ জেলার ফোন নম্বর hard-code না করে সরকারি directory ব্যবহার করা হয়েছে।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><FileText size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> পাসপোর্ট অধিদপ্তর</span></div>
                  <h3>ই-পাসপোর্ট</h3>
                  <p>ই-পাসপোর্ট আবেদন, ফি, অ্যাপয়েন্টমেন্ট ও আবেদন-স্ট্যাটাসের সরকারি তথ্য দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.passport} kind="citizen_epassport" />
                  <small className="utility-card-note">পাসপোর্টের তথ্য ও পেমেন্ট কেবল epassport.gov.bd-এর অফিসিয়াল নির্দেশনা অনুযায়ী করুন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Smartphone size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> BRTA</span></div>
                  <h3>ড্রাইভিং লাইসেন্স ও যানবাহন</h3>
                  <p>ড্রাইভিং লাইসেন্স, learner licence ও মোটরযান-সংক্রান্ত অনলাইন সেবা BRTA পোর্টালে দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.brta} kind="citizen_brta" />
                  <small className="utility-card-note">লাইসেন্স, ফি, পরীক্ষার সময় ও কাগজপত্রের বর্তমান নিয়ম BRTA পোর্টালেই চূড়ান্তভাবে যাচাই করুন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Globe2 size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ভূমি মন্ত্রণালয়</span></div>
                  <h3>ভূমি সেবা</h3>
                  <p>ই-নামজারি, ভূমি উন্নয়ন কর, খতিয়ান/রেকর্ড ও ভূমি-সংক্রান্ত সরকারি সেবার entry point খুঁজুন।</p>
                  <OfficialAction link={citizenServicesLinks.land} kind="citizen_land" />
                  <small className="utility-card-note">জমির রেকর্ড বা লেনদেনের আগে দাগ, খতিয়ান ও মালিকানার তথ্য সংশ্লিষ্ট অফিসিয়াল সিস্টেমে মিলিয়ে নিন।</small>
                </article>

                <article className="utility-card citizen-service-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><ClipboardCheck size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> রেজিস্ট্রার জেনারেল</span></div>
                  <h3>জন্ম ও মৃত্যু নিবন্ধন</h3>
                  <p>জন্মনিবন্ধন, মৃত্যুনিবন্ধন, সংশোধন ও যাচাই-সংক্রান্ত সরকারি পোর্টাল দেখুন।</p>
                  <OfficialAction link={citizenServicesLinks.birthDeath} kind="citizen_birth_death" />
                  <small className="utility-card-note">নাম, জন্মতারিখ ও পরিবারের তথ্য জমা দেওয়ার আগে স্থানীয় নিবন্ধক কার্যালয়ের নির্দেশনা যাচাই করুন।</small>
                </article>
              </div>
              <div className="utility-safety-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>নিরাপত্তা নোট:</strong> সরকারি সেবা সাধারণত নিজ নিজ দপ্তরের নিয়মে পরিচালিত হয়। সাহজসেবা কোনো সরকারি সংস্থা নয়; আমরা শুধু তথ্যভিত্তিক অফিসিয়াল entry point দেখাই এবং OTP/PIN চাই না।</p></div>
            </div>
          </details>
        </div>
      </section>

      <section id="women-children-services" className="utility-section women-children-section" aria-labelledby="women-children-heading" style={{ order: 4 }}>
        <div className="container">
          <details className="utility-folder" data-utility-folder="women-children-services">
            <summary className="utility-folder-summary thematic-summary thematic-summary-women" aria-controls="women-children-services-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true"><HeartHandshake size={22} /></span><span className="section-number">০৬ / নারী ও শিশু</span></span>
                <span id="women-children-heading" className="utility-folder-title">নারী ও শিশুদের সরকারি সুযোগ-সুবিধা</span>
                <span className="utility-section-lede">ভাতা, সামাজিক সুরক্ষা ও সহায়তার সরকারি তথ্য এক জায়গায়</span>
              </span>
              <span className="thematic-summary-art" aria-hidden="true"><img src="/manus-storage/sahajseva-women-children-theme_8bd11118.png" alt="" loading="lazy" /></span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="women-children-services-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>মহিলা ও শিশু বিষয়ক মন্ত্রণালয়, সমাজসেবা অধিদপ্তর, জাতীয় সামাজিক নিরাপত্তা পোর্টাল ও জাতীয় তথ্য বাতায়ন থেকে নারী ও শিশুদের জন্য প্রযোজ্য ভাতা, মাতৃত্ব/শিশু সহায়তা, সামাজিক সুরক্ষা ও আবেদন-পথ যাচাই করুন। যোগ্যতা, বরাদ্দ, আবেদন-সময় ও সেবার নিয়ম কর্মসূচি ও সময়ভেদে বদলাতে পারে।</p>
              </div>
              <div className="utility-card-grid women-children-grid" aria-label="নারী ও শিশুদের সরকারি সেবার অফিসিয়াল শর্টকাট">
                <article className="utility-card women-children-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><HeartHandshake size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> সরকারি মন্ত্রণালয়</span></div>
                  <h3>নারীর অধিকার ও সহায়তা</h3>
                  <p>নারী উন্নয়ন, সুরক্ষা, অধিকার, প্রশিক্ষণ ও সরকারি কর্মসূচির নোটিশ মহিলা ও শিশু বিষয়ক মন্ত্রণালয়ের অফিসিয়াল সাইটে দেখুন।</p>
                  <OfficialAction link={womenChildrenLinks.mowca} kind="women_children_mowca" />
                  <small className="utility-card-note">কোনো সুবিধা পাওয়ার আগে অফিসিয়াল যোগ্যতা ও আবেদন-নিয়ম মিলিয়ে নিন।</small>
                </article>

                <article className="utility-card women-children-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Landmark size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> সমাজসেবা অধিদপ্তর</span></div>
                  <h3>মা, শিশু ও সামাজিক সুরক্ষা</h3>
                  <p>মাতৃত্ব, শিশু, বিধবা বা অসহায় নারীর জন্য প্রযোজ্য সামাজিক সুরক্ষা কর্মসূচি ও স্থানীয় আবেদন নির্দেশনা যাচাই করুন।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={womenChildrenLinks.socialServices} kind="women_children_social_services" />
                    <OfficialAction link={womenChildrenLinks.socialProtection} kind="women_children_social_protection" />
                  </div>
                  <small className="utility-card-note">ভাতা বা অনুদানের পরিমাণ, নির্বাচন ও বিতরণ পদ্ধতি সরকারি ঘোষণার ওপর নির্ভরশীল।</small>
                </article>

                <article className="utility-card women-children-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><FileText size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> জাতীয় তথ্য বাতায়ন</span></div>
                  <h3>নিজের এলাকার সেবা খুঁজুন</h3>
                  <p>জেলা, উপজেলা ও স্থানীয় সরকারি অফিসের সেবা, ফরম, যোগাযোগ ও আবেদন-পথ জাতীয় তথ্য বাতায়ন থেকে খুঁজে নিন।</p>
                  <OfficialAction link={womenChildrenLinks.citizenPortal} kind="women_children_citizen_portal" />
                  <small className="utility-card-note">সরকারি সুবিধার জন্য দালালকে টাকা দেবেন না; প্রয়োজন হলে সংশ্লিষ্ট অফিসে সরাসরি যোগাযোগ করুন।</small>
                </article>

                <article className="utility-card women-children-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><Phone size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> সহায়তা হেল্পলাইন</span></div>
                  <h3>জরুরি নারী ও শিশু সহায়তা</h3>
                  <p>সহিংসতা, নির্যাতন, বাল্যবিবাহ বা শিশুর ঝুঁকিতে দ্রুত সরকারি হেল্পলাইনে যোগাযোগ করুন। তাৎক্ষণিক বিপদে ৯৯৯ ব্যবহার করুন।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={womenChildrenLinks.womenHelpline} kind="women_children_helpline" />
                    <OfficialAction link={womenChildrenLinks.childHelpline} kind="child_helpline" />
                  </div>
                  <small className="utility-card-note">হেল্পলাইনে কল করার সময় নিরাপদ জায়গায় থাকুন এবং নিজের অবস্থান/ঘটনার তথ্য যতটা সম্ভব পরিষ্কারভাবে জানান।</small>
                </article>

                <article className="utility-card women-children-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><BriefcaseBusiness size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> নারী উদ্যোক্তা</span></div>
                  <h3>নারী উদ্যোক্তা</h3>
                  <p>SME ঋণ, সরকারি প্রশিক্ষণ এবং নারী উদ্যোক্তাদের বাজার/মেলার সুযোগের বর্তমান তথ্য এক জায়গায় দেখুন।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={womenChildrenLinks.joyeeta} kind="women_entrepreneur_joyeeta" />
                    <OfficialAction link={womenChildrenLinks.bangladeshBankWomen} kind="women_entrepreneur_sme_finance" />
                  </div>
                  <small className="utility-card-note">ঋণের হার, জামানত, প্রশিক্ষণের আসন ও বাজারে অংশগ্রহণের শর্ত সরকারি নোটিশ ও সংশ্লিষ্ট প্রতিষ্ঠানের সিদ্ধান্তে নির্ভরশীল।</small>
                </article>

                <article className="utility-card women-children-card">
                  <div className="utility-card-topline"><span className="utility-card-icon" aria-hidden="true"><HeartHandshake size={22} /></span><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> মাতৃত্ব ও স্বাস্থ্য</span></div>
                  <h3>মাতৃত্ব ও স্বাস্থ্য</h3>
                  <p>মাতৃত্বকালীন ভাতা, স্বাস্থ্য কার্ড/সুবিধা সংক্রান্ত সরকারি ঘোষণা এবং সরকারি হাসপাতাল ও মাতৃ-শিশু স্বাস্থ্যকেন্দ্রের তালিকা খুঁজুন।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={womenChildrenLinks.maternityAllowance} kind="maternity_allowance" />
                    <OfficialAction link={womenChildrenLinks.healthFacility} kind="women_children_health_facilities" />
                    <OfficialAction link={womenChildrenLinks.healthInfo} kind="women_children_health_info" />
                  </div>
                  <small className="utility-card-note">ভাতা অনুমোদন, স্বাস্থ্য কার্ডের প্রাপ্যতা, হাসপাতালের সেবা/বেড ও ফি আগে অফিসিয়াল পোর্টালে যাচাই করুন।</small>
                </article>

              </div>
              <div className="utility-safety-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>স্বচ্ছতা ও নিরাপত্তা:</strong> সাহজসেবা কোনো সরকারি দপ্তর, হেল্পলাইন বা NGO-এর প্রতিনিধি নয়। আমরা সরকারি ভাতা অনুমোদন করি না, আবেদন নিশ্চিত করতে পারি না এবং OTP/PIN চাই না।</p></div>
            </div>
          </details>
        </div>
      </section>

      <section id="law-enforcement-services" className="utility-section law-enforcement-section" aria-labelledby="law-enforcement-heading" style={{ order: 5 }}>
        <div className="container">
          <details className="utility-folder" data-utility-folder="law-enforcement-services">
            <summary className="utility-folder-summary thematic-summary thematic-summary-army" aria-controls="law-enforcement-services-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true"><ShieldCheck size={22} /></span><span className="section-number">০৭ / নিরাপত্তা ও আইন</span></span>
                <span id="law-enforcement-heading" className="utility-folder-title">প্রধান আইন-শৃঙ্খলা বাহিনীর তথ্য ও সেবা</span>
                <span className="utility-section-lede">জরুরি নম্বর, পুলিশি সহায়তা ও সরকারি সংস্থার লিংক এক জায়গায়</span>
              </span>
              <span className="thematic-summary-art" aria-hidden="true"><img src="/manus-storage/sahajseva-army-security-theme_5351a739.png" alt="" loading="lazy" /></span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="law-enforcement-services-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>জরুরি বিপদে আগে ৯৯৯-এ কল করুন। নিচে বাংলাদেশের প্রধান আইন-শৃঙ্খলা ও জননিরাপত্তা সংস্থার অফিসিয়াল পোর্টাল, সাধারণ তথ্য, জিডি, পুলিশ ক্লিয়ারেন্স ও সাইবার সহায়তার পথ দেওয়া হলো। এটি প্রতিটি ইউনিট বা আঞ্চলিক অফিসের পূর্ণ তালিকা নয়; সাহজসেবা কোনো সরকারি প্রতিনিধি নয় এবং কোনো অভিযোগের ফলাফল বা সাড়া দেওয়ার সময় নিশ্চিত করতে পারে না।</p>
              </div>
              <div className="utility-card-grid law-enforcement-grid" aria-label="আইন-শৃঙ্খলা বাহিনীর সরকারি সেবার অফিসিয়াল শর্টকাট">
                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="৯৯৯" /><span className="utility-card-source"><ShieldAlert size={14} aria-hidden="true" /> জরুরি সেবা</span></div>
                  <h3>জাতীয় জরুরি সেবা ৯৯৯</h3>
                  <p>জীবন, নিরাপত্তা, অপরাধ, আগুন বা অ্যাম্বুলেন্স-সংক্রান্ত তাৎক্ষণিক জরুরিতে জাতীয় জরুরি সেবায় কল করুন।</p>
                  <OfficialAction link={lawEnforcementLinks.emergency} kind="national_emergency_999" />
                  <small className="utility-card-note">মিথ্যা বা অপ্রয়োজনীয় কল করবেন না; অবস্থান, ঘটনার ধরন ও যোগাযোগ নম্বর স্পষ্টভাবে জানান।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="দুদক" /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> দুর্নীতি দমন কমিশন</span></div>
                  <h3>দুর্নীতি দমন কমিশন (দুদক)</h3>
                  <p>দুর্নীতি প্রতিরোধ, অভিযোগ, আইন ও বিধিমালাসংক্রান্ত সরকারি তথ্য দুদকের অফিসিয়াল পোর্টালে দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.antiCorruptionCommission} kind="anti_corruption_commission" />
                  <small className="utility-card-note">অভিযোগ বা তথ্য দাখিলের বর্তমান শর্ত ও নিরাপত্তা নির্দেশনা শুধু দুদকের অফিসিয়াল পোর্টাল থেকে যাচাই করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.policePortal} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> বাংলাদেশ পুলিশ</span></div>
                  <h3>পুলিশি তথ্য ও অভিযোগের পথ</h3>
                  <p>বাংলাদেশ পুলিশের অফিসিয়াল পোর্টালে হটলাইন, নাগরিক সেবা, অভিযোগ ও সংশ্লিষ্ট ইউনিটের তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.policePortal} kind="police_portal" />
                  <small className="utility-card-note">অভিযোগের জন্য ঘটনার সময়, স্থান ও প্রমাণের তথ্য সংরক্ষণ করে সংশ্লিষ্ট থানায় যোগাযোগ করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.policePortal} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> অনলাইন পুলিশ সেবা</span></div>
                  <h3>অনলাইন জিডি ও পুলিশ ক্লিয়ারেন্স</h3>
                  <p>হারানো জিনিস, নথি বা সাধারণ ঘটনার জন্য অনলাইন জিডি এবং বিদেশযাত্রার প্রয়োজন হলে পুলিশ ক্লিয়ারেন্সের সরকারি পোর্টাল দেখুন।</p>
                  <div className="utility-card-actions utility-card-actions-three">
                    <OfficialAction link={lawEnforcementLinks.onlineGd} kind="online_gd" />
                    <OfficialAction link={lawEnforcementLinks.policeClearance} kind="police_clearance" />
                  </div>
                  <small className="utility-card-note">NID, পাসপোর্ট বা ব্যক্তিগত তথ্য কেবল police.gov.bd-সংশ্লিষ্ট অফিসিয়াল ডোমেইনে দিন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.cyber} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> সাইবার নিরাপত্তা</span></div>
                  <h3>সাইবার অভিযোগ ও সহায়তা</h3>
                  <p>অনলাইন প্রতারণা, হুমকি, হয়রানি বা সাইবার অপরাধের ঘটনায় বাংলাদেশ পুলিশের CID-এর অফিসিয়াল হটলাইন তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.cyberComplaint} kind="cyber_complaint" />
                  <small className="utility-card-note">স্ক্রিনশট, নম্বর, লিংক ও লেনদেনের প্রমাণ সংরক্ষণ করুন; OTP, PIN বা পাসওয়ার্ড কাউকে দেবেন না।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="RAB" /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> RAB</span></div>
                  <h3>র‍্যাপিড অ্যাকশন ব্যাটালিয়ন (RAB)</h3>
                  <p>RAB-এর পরিচিতি, নোটিশ ও জনসাধারণের জন্য প্রকাশিত সরকারি তথ্য তাদের অফিসিয়াল পোর্টালে দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.rab} kind="rab_official_portal" />
                  <small className="utility-card-note">জরুরি বিপদে ওয়েবসাইটের বদলে ৯৯৯-এ কল করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.cid} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> CID</span></div>
                  <h3>অপরাধ তদন্ত বিভাগ (CID)</h3>
                  <p>CID-এর তদন্ত-সংক্রান্ত তথ্য, নোটিশ ও সাইবার অপরাধ সহায়তার সরকারি তথ্য তাদের অফিসিয়াল পোর্টালে দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.cid} kind="cid_official_portal" />
                  <small className="utility-card-note">অভিযোগের প্রমাণ সংরক্ষণ করুন এবং কেবল অফিসিয়াল পোর্টাল ব্যবহার করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.specialBranch} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> Special Branch</span></div>
                  <h3>স্পেশাল ব্রাঞ্চ</h3>
                  <p>বাংলাদেশ পুলিশের Special Branch-এর অফিসিয়াল পরিচিতি, নোটিশ ও প্রাসঙ্গিক নাগরিক তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.specialBranch} kind="special_branch_portal" />
                  <small className="utility-card-note">সেবার যোগ্যতা ও প্রক্রিয়া সংশ্লিষ্ট সরকারি পোর্টালের নির্দেশনা অনুযায়ী যাচাই করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.dmp} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> DMP</span></div>
                  <h3>ঢাকা মেট্রোপলিটন পুলিশ (DMP)</h3>
                  <p>ঢাকা মহানগর এলাকার পুলিশি তথ্য, ট্রাফিক, জনসচেতনতা ও নাগরিক সেবার অফিসিয়াল তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.dmp} kind="dmp_official_portal" />
                  <small className="utility-card-note">ঢাকার বাইরে হলে সংশ্লিষ্ট জেলা বা মেট্রোপলিটন পুলিশের অফিসিয়াল পোর্টাল ব্যবহার করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.fireService} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> ফায়ার সার্ভিস</span></div>
                  <h3>ফায়ার সার্ভিস ও সিভিল ডিফেন্স</h3>
                  <p>আগুন, উদ্ধার, দুর্যোগ ও সিভিল ডিফেন্স-সংক্রান্ত সরকারি নির্দেশনা এবং প্রতিষ্ঠানভিত্তিক তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.fireService} kind="fire_service_official_portal" />
                  <small className="utility-card-note">আগুন বা উদ্ধার-সংক্রান্ত তাৎক্ষণিক বিপদে ৯৯৯-এ কল করুন এবং নিরাপদ স্থানে সরে যান।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.ansarVdp} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> আনসার-ভিডিপি</span></div>
                  <h3>বাংলাদেশ আনসার ও গ্রাম প্রতিরক্ষা বাহিনী</h3>
                  <p>আনসার ও ভিডিপির অফিসিয়াল পরিচিতি, জননিরাপত্তা-সম্পর্কিত তথ্য ও সরকারি নোটিশ দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.ansarVdp} kind="ansar_vdp_official_portal" />
                  <small className="utility-card-note">নিয়োগ বা সেবার নামে কোনো অননুমোদিত ব্যক্তিকে টাকা বা ব্যক্তিগত তথ্য দেবেন না।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.coastGuard} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> কোস্ট গার্ড</span></div>
                  <h3>বাংলাদেশ কোস্ট গার্ড</h3>
                  <p>সমুদ্র, উপকূল ও নৌপথের জননিরাপত্তা এবং কোস্ট গার্ডের অফিসিয়াল তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.coastGuard} kind="coast_guard_official_portal" />
                  <small className="utility-card-note">নৌপথে তাৎক্ষণিক বিপদে স্থানীয় কর্তৃপক্ষ বা ৯৯৯-এর সহায়তা নিন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.narcotics} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> মাদকদ্রব্য নিয়ন্ত্রণ</span></div>
                  <h3>মাদকদ্রব্য নিয়ন্ত্রণ অধিদপ্তর</h3>
                  <p>মাদকবিরোধী অভিযান, সচেতনতা, পুনর্বাসন তথ্য এবং স্বরাষ্ট্র মন্ত্রণালয়ের অধীন অধিদপ্তরের অফিসিয়াল সেবা দেখুন।</p>
                  <OfficialAction link={{ label: "সেবা দেখুন", href: "https://dnc.gov.bd", title: "Directorate of Narcotics Control official website" }} kind="narcotics_control_official_portal" />
                  <small className="utility-card-note">মাদক সংক্রান্ত যেকোনো তথ্য বা অভিযোগে গোপনীয়তা রক্ষা করা হয়; জরুরি সহায়তায় ৯৯৯-এ কল করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.bgb} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> BGB</span></div>
                  <h3>বর্ডার গার্ড বাংলাদেশ (BGB)</h3>
                  <p>সীমান্ত নিরাপত্তা ও BGB-এর অফিসিয়াল পরিচিতি, নোটিশ এবং জনসাধারণের জন্য প্রকাশিত তথ্য দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.bgb} kind="bgb_official_portal" />
                  <small className="utility-card-note">সীমান্ত এলাকায় স্থানীয় নির্দেশনা মেনে চলুন; জরুরি অবস্থায় ৯৯৯ বা সংশ্লিষ্ট সরকারি কর্তৃপক্ষকে জানান।</small>
                </article>

                <article className="utility-card law-enforcement-card defence-service-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.army} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> প্রতিরক্ষা বাহিনী</span></div>
                  <h3>বাংলাদেশ সেনাবাহিনী</h3>
                  <p>বাংলাদেশ সেনাবাহিনীর অফিসিয়াল পরিচিতি, জনসাধারণের জন্য প্রকাশিত তথ্য, নোটিশ ও নিয়োগ-সংক্রান্ত ঘোষণা দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.army} kind="army_official_portal" />
                  <small className="utility-card-note">এটি সাধারণ জরুরি পুলিশের বিকল্প নয়; তাৎক্ষণিক বিপদে ৯৯৯-এ কল করুন।</small>
                </article>

                <article className="utility-card law-enforcement-card defence-service-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.navy} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> প্রতিরক্ষা বাহিনী</span></div>
                  <h3>বাংলাদেশ নৌবাহিনী</h3>
                  <p>বাংলাদেশ নৌবাহিনীর অফিসিয়াল পরিচিতি, নোটিশ, সামুদ্রিক নিরাপত্তা-সংক্রান্ত প্রকাশিত তথ্য ও নিয়োগ ঘোষণা দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.navy} kind="navy_official_portal" />
                  <small className="utility-card-note">নৌপথে জরুরি বিপদে ৯৯৯ বা স্থানীয় সংশ্লিষ্ট কর্তৃপক্ষের সহায়তা নিন।</small>
                </article>

                <article className="utility-card law-enforcement-card defence-service-card">
                  <div className="utility-card-topline"><OfficialAgencyMark logo={officialAgencyLogos.airForce} /><span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> প্রতিরক্ষা বাহিনী</span></div>
                  <h3>বাংলাদেশ বিমানবাহিনী</h3>
                  <p>বাংলাদেশ বিমানবাহিনীর অফিসিয়াল পরিচিতি, নোটিশ, জনসাধারণের জন্য প্রকাশিত তথ্য ও নিয়োগ ঘোষণা দেখুন।</p>
                  <OfficialAction link={lawEnforcementLinks.airForce} kind="air_force_official_portal" />
                  <small className="utility-card-note">নিয়োগ বা সেবার জন্য কেবল baf.mil.bd-এর অফিসিয়াল নির্দেশনা অনুসরণ করুন।</small>
                </article>
              </div>
              <div className="utility-safety-note"><ShieldAlert size={17} aria-hidden="true" /><p><strong>জরুরি ব্যবহারের নিয়ম:</strong> চলমান বিপদে ওয়েবসাইট খোঁজার আগে ৯৯৯-এ কল করুন। এই তালিকা তথ্যের shortcut; এটি পুলিশি তদন্ত, আইনগত পরামর্শ বা জরুরি সাড়ার বিকল্প নয়।</p></div>
            </div>
          </details>
        </div>
      </section>

      </div>

      {afterLawEnforcement ? <div style={{ order: 6 }}>{afterLawEnforcement}</div> : null}

      {/* Legacy media cards are deliberately not mounted. The owner-managed Media Hub is the only public renderer. */}
      {false && <section id="bangladesh-media-services" className="utility-section media-section" aria-labelledby="bangladesh-media-heading">
        <div className="container">
          <details className="utility-folder" data-utility-folder="bangladesh-media-services">
            <summary className="utility-folder-summary thematic-summary thematic-summary-media" aria-controls="bangladesh-media-services-content">
              <span className="utility-folder-summary-copy thematic-summary-copy">
                <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true"><Globe2 size={22} /></span><span className="section-number">০৮ / সংবাদমাধ্যম</span></span>
                <span id="bangladesh-media-heading" className="utility-folder-title">বাংলাদেশের সংবাদমাধ্যম ও গণমাধ্যম</span>
                <span className="utility-section-lede">জাতীয় দৈনিক পত্রিকা ও টেলিভিশন চ্যানেলের অফিসিয়াল লিংক ডিরেক্টরি</span>
              </span>
              <span className="thematic-summary-art" aria-hidden="true"><img src="/manus-storage/sahajseva-citizen-hills-theme_5f091176.png" alt="" loading="lazy" /></span>
              <span className="utility-folder-toggle" aria-hidden="true">+</span>
            </summary>
            <div id="bangladesh-media-services-content" className="utility-folder-content">
              <div className="utility-folder-description">
                <p>দেশের প্রধান জাতীয় দৈনিক পত্রিকা ও টেলিভিশন চ্যানেলের অফিসিয়াল পোর্টালের তালিকা নিচে দেওয়া হলো। সাহজসেবা কোনো সংবাদ সংস্থা বা সম্পাদকীয় পরিচালনা পর্ষদ নয়; প্রকাশিত সংবাদ, মতামত বা সম্পাদকীয় নীতির সঙ্গে পোর্টালটির কোনো সম্পর্ক নেই। নাগরিক ও প্রবাসীদের সুবিধার্থে বহুল পঠিত নির্বাচিত সংবাদমাধ্যমের ডিরেক্টরি এখানে যুক্ত করা হয়েছে।</p>
              </div>
              <div className="utility-card-grid media-grid" aria-label="বাংলাদেশি সংবাদমাধ্যম ও গণমাধ্যমের অফিসিয়াল শর্টকাট">
                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="প্রথম আলো" /><span className="utility-card-source"><FileText size={14} aria-hidden="true" /> দৈনিক পত্রিকা</span></div>
                  <h3>প্রথম আলো (Prothom Alo)</h3>
                  <p>দেশের অন্যতম বহুল পঠিত বাংলা দৈনিক পত্রিকার অফিসিয়াল পোর্টাল ও অনলাইন সংবাদ আপডেট।</p>
                  <OfficialAction link={mediaLinks.prothomAlo} kind="prothom_alo_official" />
                  <small className="utility-card-note">যাচাইকৃত প্রধান দৈনিক পত্রিকার অফিসিয়াল ওয়েব ঠিকানা।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="Star" /><span className="utility-card-source"><FileText size={14} aria-hidden="true" /> Daily Newspaper</span></div>
                  <h3>The Daily Star</h3>
                  <p>বাংলাদেশের অন্যতম শীর্ষস্থানীয় ইংরেজি দৈনিক পত্রিকার অফিসিয়াল অনলাইন সংবাদ পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.dailyStar} kind="daily_star_official" />
                  <small className="utility-card-note">ইংরেজি ভাষার প্রধান জাতীয় দৈনিকের অফিসিয়াল পোর্টাল।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="কালের কণ্ঠ" /><span className="utility-card-source"><FileText size={14} aria-hidden="true" /> দৈনিক পত্রিকা</span></div>
                  <h3>কালের কণ্ঠ</h3>
                  <p>জাতীয় দৈনিক কালের কণ্ঠের অফিসিয়াল সংবাদ পোর্টাল ও সাম্প্রতিক খবরের পাতা।</p>
                  <OfficialAction link={mediaLinks.kalerKantho} kind="kaler_kantho_official" />
                  <small className="utility-card-note">জাতীয় দৈনিকের সংবাদ ও সাময়িকী তথ্য।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="bdnews24" /><span className="utility-card-source"><Globe2 size={14} aria-hidden="true" /> অনলাইন নিউজ পোর্টাল</span></div>
                  <h3>bdnews24.com</h3>
                  <p>বাংলাদেশের প্রথম ইন্টারনেটভিত্তিক ২৪ ঘণ্টার সংবাদ সংস্থা ও অনলাইন নিউজ পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.bdnews24} kind="bdnews24_official" />
                  <small className="utility-card-note">অনলাইন সংবাদ ও মাল্টিমিডিয়া পরিবেশনা।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="বাংলা ট্রিবিউন" /><span className="utility-card-source"><Globe2 size={14} aria-hidden="true" /> নিউজ পোর্টাল</span></div>
                  <h3>বাংলা ট্রিবিউন</h3>
                  <p>সারদেশের সংবাদ, মতামত এবং অনুসন্ধানী প্রতিবেদনের জন্য জনপ্রিয় অনলাইন সংবাদমাধ্যম।</p>
                  <OfficialAction link={mediaLinks.banglaTribune} kind="bangla_tribune_official" />
                  <small className="utility-card-note">সর্বশেষ সংবাদের অনলাইন গন্তব্য।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="BTV" /><span className="utility-card-source"><Smartphone size={14} aria-hidden="true" /> রাষ্ট্রীয় টেলিভিশন</span></div>
                  <h3>বাংলাদেশ টেলিভিশন (BTV)</h3>
                  <p>বাংলাদেশের রাষ্ট্রীয় টেলিভিশন সম্প্রচার কেন্দ্র ও সরকারি অনুষ্ঠান ও খবরের অফিসিয়াল পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.btv} kind="btv_official_portal" />
                  <small className="utility-card-note">রাষ্ট্রীয় টেলিভিশন সম্প্রচার ও প্রজ্ঞাপন তথ্য।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="চ্যানেল আই" /><span className="utility-card-source"><Smartphone size={14} aria-hidden="true" /> টেলিভিশন চ্যানেল</span></div>
                  <h3>চ্যানেল আই</h3>
                  <p>বেসরকারি স্যাটেলাইট টেলিভিশন চ্যানেল আই-এর অনলাইন সংবাদ ও সম্প্রচার পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.channelI} kind="channel_i_official" />
                  <small className="utility-card-note">খবর, কৃষি ও বিনোদনমূলক সংবাদ মাধ্যম।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="ইন্ডিপেন্ডেন্ট" /><span className="utility-card-source"><Smartphone size={14} aria-hidden="true" /> টেলিভিশন চ্যানেল</span></div>
                  <h3>ইন্ডিপেন্ডেন্ট টেলিভিশন</h3>
                  <p>নিরপেক্ষ সংবাদ সম্প্রচার এবং ২৪ ঘণ্টার সংবাদভিত্তিক টেলিভিশন চ্যানেলের অফিসিয়াল পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.independent} kind="independent_tv_official" />
                  <small className="utility-card-note">সংবাদভিত্তিক স্যাটেলাইট টেলিভিশন পোর্টাল।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="সময় টিভি" /><span className="utility-card-source"><Smartphone size={14} aria-hidden="true" /> টেলিভিশন চ্যানেল</span></div>
                  <h3>সময় টিভি (Somoy TV)</h3>
                  <p>বাংলাদেশের অন্যতম শীর্ষস্থানীয় ২৪ ঘণ্টার সংবাদভিত্তিক স্যাটেলাইট টিভি চ্যানেলের অনলাইন পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.somoyTv} kind="somoy_tv_official" />
                  <small className="utility-card-note">সর্বশেষ সংবাদ ও ভিডিও ক্লিপস।</small>
                </article>

                <article className="utility-card media-card">
                  <div className="utility-card-topline"><OfficialAgencyMark fallbackLabel="একাত্তর" /><span className="utility-card-source"><Smartphone size={14} aria-hidden="true" /> টেলিভিশন চ্যানেল</span></div>
                  <h3>একাত্তর টিভি (Ekattor TV)</h3>
                  <p>সংবাদভিত্তিক স্যাটেলাইট টেলিভিশন চ্যানেল একাত্তরের অফিসিয়াল অনলাইন সংবাদ ও লাইভ স্ট্রিম পোর্টাল।</p>
                  <OfficialAction link={mediaLinks.ekattor} kind="ekattor_tv_official" />
                  <small className="utility-card-note">সংবাদ ও টকশো ভিত্তিক টেলিভিশন পোর্টাল।</small>
                </article>
              </div>
              <div className="utility-safety-note"><Globe2 size={17} aria-hidden="true" /><p><strong>স্বচ্ছতা নোট:</strong> এই সংবাদমাধ্যম ডিরেক্টরি নাগরিকদের সহজে অফিসিয়াল সাইটে পৌঁছানোর জন্য তৈরি। সংবাদমাধ্যমের সম্পাদকীয় বা সম্পাদকীয় নীতির জন্য সাহজসেবা দায়ী নয়।</p></div>
            </div>
          </details>
        </div>
      </section>}

    </>
  );
}
