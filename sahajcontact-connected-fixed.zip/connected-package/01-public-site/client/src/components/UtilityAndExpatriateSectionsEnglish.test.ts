import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const englishRendererSource = readFileSync(new URL("./UtilityAndExpatriateSectionsEnglish.tsx", import.meta.url), "utf8");

describe("strict English utility renderer", () => {
  it("contains no Bengali Unicode characters", () => {
    expect(englishRendererSource).not.toMatch(/[\u0980-\u09FF]/);
  });

  it("keeps every active non-media utility folder in the English route", () => {
    for (const folderId of [
      "weather-message",
      "bill-payment",
      "agriculture-services",
      "probashi-services",
      "citizen-services",
      "women-children-services",
      "law-enforcement-services",
    ]) {
      expect(englishRendererSource).toContain(`id="${folderId}"`);
    }
  });

  it("does not mount a duplicate static media directory", () => {
    expect(englishRendererSource).not.toContain("EnglishMediaFolder");
    expect(englishRendererSource).not.toContain('id="bangladesh-media-services"');
  });

  it("uses official-link actions rather than local placeholder destinations", () => {
    expect(englishRendererSource).toContain("function EnglishAction");
    expect(englishRendererSource).toContain("trackOutbound(link.title, link.href, kind)");
    expect(englishRendererSource).toContain("ExternalLinkWithFallback");
  });
});
