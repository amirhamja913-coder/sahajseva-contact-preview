import { type ReactNode } from "react";
import { ArrowUpRight, Banknote, CheckCircle2, Globe2, Landmark, Plane, Scale, ShieldAlert, ShieldCheck, Smartphone, Sprout, WalletCards, Waves } from "lucide-react";
import { ExternalLinkWithFallback } from "./ExternalLinkWithFallback";
import { trackEvent, trackOutbound } from "../lib/analytics";
import {
  agricultureLinks,
  billCards,
  citizenServicesLinks,
  expatGuidelines,
  expatVisaLinks,
  lawEnforcementLinks,
  regionalGuides,
  womenChildrenLinks,
  remittanceLinks,
  type OfficialLink,
} from "./UtilityAndExpatriateSections";

type EnglishActionProps = {
  link: OfficialLink;
  label: string;
  kind: string;
};

function EnglishAction({ link, label, kind }: EnglishActionProps) {
  return (
    <ExternalLinkWithFallback
      href={link.href}
      title={`${label} official website`}
      ariaLabel={`Open ${label}`}
      className="utility-card-action"
      wrapperClassName="utility-card-link-wrapper"
      showExternalIcon={false}
      onClick={() => {
        trackOutbound(link.title, link.href, kind);
        trackEvent("official_shortcut_click", { label, destination: link.href, shortcut_kind: kind });
      }}
    >
      <span>{label}</span>
      <ArrowUpRight size={15} aria-hidden="true" />
    </ExternalLinkWithFallback>
  );
}

function EnglishFolder({
  id,
  number,
  icon,
  title,
  lede,
  description,
  children,
  className = "",
}: {
  id: string;
  number: string;
  icon: ReactNode;
  title: string;
  lede: string;
  description: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={`utility-section ${className}`.trim()} aria-labelledby={`${id}-heading`}>
      <div className="container">
        <details className="utility-folder" data-utility-folder={id}>
          <summary className="utility-folder-summary thematic-summary">
            <span className="utility-folder-summary-copy thematic-summary-copy">
              <span className="thematic-summary-kicker"><span className="thematic-summary-icon" aria-hidden="true">{icon}</span><span className="section-number">{number}</span></span>
              <span id={`${id}-heading`} className="utility-folder-title">{title}</span>
              <span className="utility-section-lede">{lede}</span>
            </span>
            <span className="utility-folder-toggle" aria-hidden="true">+</span>
          </summary>
          <div className="utility-folder-content">
            <div className="utility-folder-description"><p>{description}</p></div>
            {children}
          </div>
        </details>
      </div>
    </section>
  );
}

function EnglishUtilityCard({
  title,
  description,
  action,
  note,
  icon,
  className = "",
}: {
  title: string;
  description: string;
  action?: ReactNode;
  note?: string;
  icon?: ReactNode;
  className?: string;
}) {
  return (
    <article className={`utility-card ${className}`.trim()}>
      <div className="utility-card-topline">
        <span className="utility-card-icon" aria-hidden="true">{icon ?? <CheckCircle2 size={22} />}</span>
        <span className="utility-card-source"><ShieldCheck size={14} aria-hidden="true" /> Official shortcut</span>
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
      {note ? <small className="utility-card-note">{note}</small> : null}
    </article>
  );
}

function EnglishSafetyNote({ children }: { children: ReactNode }) {
  return <div className="utility-safety-note"><ShieldCheck size={17} aria-hidden="true" /><p>{children}</p></div>;
}

function EnglishBillFolder() {
  const copies = [
    { title: "Electricity bills", description: "Use official DPDC, DESCO, and NESCO bill or recharge portals.", action: "Pay or recharge" },
    { title: "Gas bills", description: "Open the Titas Gas customer portal to review your account and bill information.", action: "Open payment portal" },
    { title: "Water bills", description: "Use the Chattogram WASA e-bill entry point for bill and payment information.", action: "Open water bill" },
    { title: "Internet bills", description: "Use operator-owned billing portals for Link3, Circle, and Amber IT.", action: "Open internet payment" },
    { title: "Mobile recharge", description: "Open the official recharge pages for GP, Robi, and Banglalink.", action: "Recharge now" },
  ];
  return (
    <EnglishFolder id="bill-payment" number="02 / DAILY SERVICES" icon={<WalletCards size={22} />} title="Bills and everyday payments" lede="Reach the official payment entry point without searching." description="SahajContact only provides shortcuts to operator or government websites. Confirm the domain before entering account or payment information.">
      <div className="utility-card-grid bill-grid">
        {billCards.map((card, index) => {
          const copy = copies[index];
          const Icon = card.icon;
          return <EnglishUtilityCard key={copy.title} title={copy.title} description={copy.description} icon={<Icon size={22} />} action={<div className="utility-card-actions">{card.links.map((link, linkIndex) => <EnglishAction key={link.href} link={link} label={linkIndex === 0 && card.links.length > 1 ? `${copy.action}: ${card.providers[linkIndex]}` : copy.action} kind={`bill_payment_en_${index}_${linkIndex}`} />)}</div>} note="The official provider controls eligibility, fees, account status, and payment confirmation." />;
        })}
      </div>
      <EnglishSafetyNote><strong>Safety note:</strong> SahajContact does not submit applications, collect government fees, or request an OTP or PIN. Verify the official domain before continuing.</EnglishSafetyNote>
    </EnglishFolder>
  );
}

function EnglishAgricultureFolder() {
  const cards = [
    ["Agriculture services and advice", "Find notices, citizen e-services, and official agricultural information.", agricultureLinks.dae, "Open agriculture services"],
    ["Farmer application portal", "Review the Department of Food farmer application route and current instructions.", agricultureLinks.farmerApply, "Open farmer application"],
    ["Farmer registration and status", "Check the official farmer information management portal.", agricultureLinks.farmerRegister, "Check registration"],
    ["Agro-meteorological information", "Review crop, weather, and farm advisory information from the official portal.", agricultureLinks.weather, "Open agriculture weather"],
    ["Bangladesh weather forecast", "Open the Bangladesh Meteorological Department forecast and warning service.", agricultureLinks.bmdWeather, "Open weather forecast"],
    ["Agriculture subsidy information", "Review eligibility, programs, and current notices from the Ministry of Agriculture.", agricultureLinks.subsidy, "Review eligibility"],
    ["Government forms and applications", "Find official agriculture forms and application samples.", agricultureLinks.forms, "Open official forms"],
  ] as const;
  return (
    <EnglishFolder id="agriculture-services" number="03 / FARM SUPPORT" icon={<Sprout size={22} />} title="Agriculture services" lede="Official agriculture, farmer, and weather links." description="Use these official routes for farmer applications, registration, agricultural forms, subsidy information, and weather guidance. Check the current instructions on the destination website.">
      <div className="utility-card-grid agriculture-grid">
        {cards.map(([title, description, link, label]) => <EnglishUtilityCard key={title} title={title} description={description} icon={<Sprout size={22} />} action={<EnglishAction link={link} label={label} kind={`agriculture_en_${title.toLowerCase().replaceAll(" ", "_")}`} />} note="Review the latest eligibility, deadline, and submission rules on the official portal." className="agriculture-card" />)}
      </div>
      <EnglishSafetyNote><strong>Safety note:</strong> Enter NID, mobile, or personal information only on a verified government website.</EnglishSafetyNote>
    </EnglishFolder>
  );
}

function EnglishExpatFolder() {
  const visaCopies = ["Saudi visa information", "Qatar visa inquiry", "Dubai / UAE visa status"];
  const remittanceCopies = ["bKash remittance", "Nagad remittance", "Bangladesh Bank bank directory"];
  return (
    <EnglishFolder id="probashi-services" number="04 / BANGLADESH AROUND THE WORLD" icon={<Plane size={22} />} title="Expatriate services" lede="Passport, visa, remittance, and embassy support for Bangladeshis abroad." description="Official entry points for Bangladeshis abroad and their families, including visa references, remittance resources, BMET links, embassy routes, and practical safety guidance.">
      <div className="utility-card-grid">
        <EnglishUtilityCard title="Visa and immigration references" description="Use official government visa-status and inquiry services for common destinations." icon={<Plane size={22} />} action={<div className="utility-card-actions">{expatVisaLinks.map((link, index) => <EnglishAction key={link.href} link={link} label={visaCopies[index]} kind={`visa_reference_en_${index}`} />)}</div>} note="Visa rules and processing decisions belong to the relevant government authority." />
        <EnglishUtilityCard title="Legal remittance routes" description="Open official remittance information and Bangladesh Bank reference links." icon={<Banknote size={22} />} action={<div className="utility-card-actions">{remittanceLinks.map((link, index) => <EnglishAction key={link.href} link={link} label={remittanceCopies[index]} kind={`remittance_en_${index}`} />)}</div>} note="Compare fees and rates on the provider or bank website before sending money." />
      </div>
      <div className="utility-guideline-grid">
        {expatGuidelines.map((guideline) => <article className="utility-guideline-card" key={guideline.number}><span className="utility-guideline-number">{guideline.number}</span><h3>{guideline.titleEn}</h3><p><strong>Safer step:</strong> {guideline.safeEn}</p><p><strong>Be careful:</strong> {guideline.cautionEn}</p><small>{guideline.noteEn}</small></article>)}
      </div>
      <div className="regional-service-guide" aria-labelledby="regional-service-guide-heading-en">
        <div className="regional-service-guide-heading"><span className="utility-card-icon" aria-hidden="true"><Globe2 size={22} /></span><div><h3 id="regional-service-guide-heading-en">Choose a country or region</h3><p>Find the relevant official mission and service links.</p></div></div>
        <div className="regional-guide-tabs" role="tablist" aria-label="Regional service guide">
          {regionalGuides.map((guide) => <button key={guide.id} type="button" className="regional-guide-tab" onClick={() => { document.getElementById(`regional-guide-${guide.id}`)?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }}><span>{guide.flag}</span><span>{guide.nameEn}</span></button>)}
        </div>
        <div className="regional-guide-cards">
          {regionalGuides.map((guide) => <article className="regional-guide-card" id={`regional-guide-${guide.id}`} key={guide.id}><h4>{guide.flag} {guide.nameEn}</h4><p>{guide.summaryEn}</p><ol>{guide.stepsEn.map((step) => <li key={step}>{step}</li>)}</ol><div className="utility-card-actions">{guide.links.map((link) => <EnglishAction key={link.href} link={link} label={link.labelEn} kind={`regional_service_en_${guide.id}`} />)}</div></article>)}
        </div>
      </div>
      <EnglishSafetyNote><strong>Expatriate safety note:</strong> Do not give your passport, OTP, or money to an unverified agent. Contact the nearest Bangladesh mission in an emergency.</EnglishSafetyNote>
    </EnglishFolder>
  );
}

function EnglishCitizenFolder() {
  const cards = [
    ["National ID (NID)", "Access the official National ID service portal.", citizenServicesLinks.nid, "Open NID services"],
    ["E-passport", "Start from the official e-passport information and application portal.", citizenServicesLinks.passport, "Open e-passport"],
    ["BRTA services", "Use the official Bangladesh Road Transport Authority service portal.", citizenServicesLinks.brta, "Open BRTA services"],
    ["Land services", "Find official land records and land-service entry points.", citizenServicesLinks.land, "Open land services"],
    ["Birth and death registration", "Open the official registration information and application portal.", citizenServicesLinks.birthDeath, "Open registration portal"],
  ] as const;
  return <EnglishFolder id="citizen-services" number="05 / CITIZEN SERVICES" icon={<Landmark size={22} />} title="Citizen services" lede="Official application and information portals." description="Use the government service entry points below. SahajContact does not process applications or store your submitted information."><div className="utility-card-grid citizen-grid">{cards.map(([title, description, link, label]) => <EnglishUtilityCard key={title} title={title} description={description} icon={<Landmark size={22} />} action={<EnglishAction link={link} label={label} kind={`citizen_service_en_${title.toLowerCase().replaceAll(" ", "_")}`} />} note="Confirm the domain, requirements, fees, and receipt on the official portal." />)}</div><EnglishSafetyNote><strong>Official-service note:</strong> Save your application number and receipt after completing any government process.</EnglishSafetyNote></EnglishFolder>;
}

function EnglishWomenChildrenFolder() {
  const cards = [
    ["Women and children affairs", "Find official policy, support, and program information.", "mowca", "Open ministry information"],
    ["Social services and protection", "Review social protection programs and citizen support information.", "socialServices", "Open social services"],
    ["Women and children helpline", "Use the official helpline information for urgent support.", "womenHelpline", "Call women and children helpline"],
    ["Child helpline", "Contact the national child helpline when a child needs support.", "childHelpline", "Call child helpline"],
    ["Joyeeta entrepreneurship support", "Review official training and market information for women entrepreneurs.", "joyeeta", "Open Joyeeta services"],
    ["Health facilities", "Search the official health facility registry and health information portals.", "healthFacility", "Find health facilities"],
  ] as const;
  return <EnglishFolder id="women-children-services" number="06 / FAMILY SUPPORT" icon={<ShieldAlert size={22} />} title="Women, children, and family support" lede="Official protection, helpline, welfare, and health links." description="Use these government and public-service entry points for family support. In an emergency, contact the relevant emergency service directly."><div className="utility-card-grid women-children-grid">{cards.map(([title, description, key, label]) => <EnglishUtilityCard key={title} title={title} description={description} icon={<ShieldAlert size={22} />} action={<EnglishAction link={womenChildrenLinks[key]} label={label} kind={`women_children_en_${key}`} />} note="Check the official page for eligibility, service hours, and current contact information." />)}</div><EnglishSafetyNote><strong>Urgent support:</strong> Keep a trusted family member informed and call the official helpline or emergency service when immediate help is needed.</EnglishSafetyNote></EnglishFolder>;
}

function EnglishLawFolder() {
  const cards = [
    ["Emergency service 999", "Call Bangladesh National Emergency Service for urgent assistance.", "emergency", "Call 999"],
    ["Police portal", "Open the official Bangladesh Police information portal.", "policePortal", "Open police portal"],
    ["Online General Diary", "Use the official online GD service when eligible.", "onlineGd", "Open online GD"],
    ["Police clearance", "Start from the official police clearance portal.", "policeClearance", "Open police clearance"],
    ["Cyber complaint information", "Find official cyber complaint and contact information.", "cyberComplaint", "Open cyber complaint information"],
    ["Anti-Corruption Commission", "Open the official ACC portal for information and contact routes.", "antiCorruptionCommission", "Open ACC portal"],
  ] as const;
  return <EnglishFolder id="law-enforcement-services" number="07 / SAFETY AND JUSTICE" icon={<Scale size={22} />} title="Safety, law, and justice" lede="Official emergency, police, legal, and accountability routes." description="Use official sources for emergency support, police services, legal information, and complaint routes. SahajContact is not a law-enforcement or legal authority."><div className="utility-card-grid law-enforcement-grid">{cards.map(([title, description, key, label]) => <EnglishUtilityCard key={title} title={title} description={description} icon={<Scale size={22} />} action={<EnglishAction link={lawEnforcementLinks[key]} label={label} kind={`law_enforcement_en_${key}`} />} note="For immediate danger, call the emergency number directly instead of waiting for a web response." />)}</div><EnglishSafetyNote><strong>Legal note:</strong> Verify legal deadlines, fees, and case procedures with the relevant authority or a qualified professional.</EnglishSafetyNote></EnglishFolder>;
}

export default function UtilityAndExpatriateSectionsEnglish({ afterLawEnforcement }: { afterLawEnforcement?: ReactNode }) {
  return <>
    <div className="flex flex-col">
      <div style={{ order: 1 }}><EnglishFolder id="weather-message" number="01 / SAFETY INFORMATION" icon={<Waves size={22} />} title="Trusted weather updates" lede="Official forecasts and warnings for Bangladesh." description="Check the Bangladesh Meteorological Department for the latest forecast, warnings, and weather information."><div className="utility-card-grid"><EnglishUtilityCard title="Bangladesh Meteorological Department" description="Open the official forecast and warning service." action={<EnglishAction link={{ label: "Official weather updates", href: "https://www.bmd.gov.bd/", title: "Bangladesh Meteorological Department official website" }} label="Open weather updates" kind="weather_en" />} /></div></EnglishFolder></div>
      <div style={{ order: 7 }}><EnglishBillFolder /></div>
      <div style={{ order: 2 }}><EnglishAgricultureFolder /></div>
      <div style={{ order: 3 }}><EnglishExpatFolder /></div>
      <div style={{ order: 6 }}><EnglishCitizenFolder /></div>
      <div style={{ order: 4 }}><EnglishWomenChildrenFolder /></div>
      <div style={{ order: 5 }}><EnglishLawFolder /></div>
    </div>
    {afterLawEnforcement}
  </>;
}
