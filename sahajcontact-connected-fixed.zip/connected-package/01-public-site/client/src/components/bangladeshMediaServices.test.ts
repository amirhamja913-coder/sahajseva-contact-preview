import { describe, it, expect } from "vitest";
import { mediaLinks } from "./UtilityAndExpatriateSections";

describe("Bangladesh Media & News Links Registry", () => {
  it("contains verified official links for newspapers and television channels", () => {
    expect(mediaLinks.prothomAlo.href).toBe("https://www.prothomalo.com/");
    expect(mediaLinks.dailyStar.href).toBe("https://www.thedailystar.net/");
    expect(mediaLinks.kalerKantho.href).toBe("https://www.kalerkantho.com/");
    expect(mediaLinks.bdnews24.href).toBe("https://bdnews24.com/");
    expect(mediaLinks.banglaTribune.href).toBe("https://www.banglatribune.com/");
    expect(mediaLinks.btv.href).toBe("https://btv.gov.bd/");
    expect(mediaLinks.channelI.href).toBe("https://www.channelionline.com/");
    expect(mediaLinks.independent.href).toBe("https://www.independent24.com/");
    expect(mediaLinks.somoyTv.href).toBe("https://www.somoynews.tv/");
    expect(mediaLinks.ekattor.href).toBe("https://www.ekattor.tv/");
  });
});
