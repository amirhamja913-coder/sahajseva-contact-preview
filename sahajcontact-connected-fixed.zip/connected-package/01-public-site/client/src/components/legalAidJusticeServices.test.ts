import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const component = readFileSync(new URL("./UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");

describe("legal aid and justice discovery shortcuts", () => {
  it("keeps the official legal aid hotline and directory destinations discoverable", () => {
    expect(component).toContain('href="tel:16699"');
    expect(component).toContain("https://nlaso.gov.bd/");
    expect(component).toContain("https://judiciary.gov.bd/bn");
    expect(component).toContain("জেলা আদালত ও লিগ্যাল এইড খুঁজুন");
  });

  it("shows a transparent last-verified date for justice links", () => {
    expect(component).toContain('const JUSTICE_LINK_LAST_VERIFIED = "১৯ আগস্ট ২০২৬"');
    expect(component).toContain("সর্বশেষ যাচাই:");
  });
});
