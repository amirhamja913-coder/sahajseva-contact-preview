import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { citizenServicesLinks, lawEnforcementLinks } from "./UtilityAndExpatriateSections";

describe("official justice and accountability links", () => {
  it("uses verified official destinations for the court and legal cards", () => {
    expect(citizenServicesLinks.barCouncil.href).toBe("https://barcouncil.gov.bd/");
    expect(citizenServicesLinks.lawJusticeDivision.href).toBe("https://lawjusticediv.gov.bd/");
    expect(citizenServicesLinks.internationalCrimesTribunal.href).toBe("https://ictbdinvestigation.gov.bd/");
    expect(citizenServicesLinks.judiciary.href).toBe("https://judiciary.gov.bd/");
    expect(citizenServicesLinks.eCourt.href).toBe("https://ecourt.gov.bd/");
  });

  it("keeps the Anti-Corruption Commission in the law-enforcement service registry and renders all six cards", () => {
    const componentSource = readFileSync(new URL("./UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");
    expect(lawEnforcementLinks.antiCorruptionCommission.href).toBe("https://acc.org.bd/");
    expect(componentSource).toContain("বাংলাদেশ বার কাউন্সিল");
    expect(componentSource).toContain("আইন ও বিচার বিভাগ");
    expect(componentSource).toContain("আন্তর্জাতিক অপরাধ ট্রাইব্যুনাল");
    expect(componentSource).toContain("বাংলাদেশ বিচার বিভাগ");
    expect(componentSource).toContain("ই-কোর্ট সরকারি সেবা");
    expect(componentSource).toContain("দুর্নীতি দমন কমিশন (দুদক)");
  });
});
