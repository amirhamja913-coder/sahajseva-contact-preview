import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

const languageSource = readFileSync(new URL("../contexts/LanguageContext.tsx", import.meta.url), "utf8");
const gallerySource = readFileSync(new URL("./BangladeshGallery.tsx", import.meta.url), "utf8");

describe("public SahajContact Bengali labels", () => {
  it("uses the consistent Latin site name in the Bengali share label", () => {
    expect(languageSource).toContain('shareBangladesh: "SahajContact শেয়ার করুন"');
    expect(languageSource).not.toContain("সহজকন্টাক্ট শেয়ার করুন");
  });

  it("uses the consistent Latin site name in the Bengali archive label", () => {
    expect(gallerySource).toContain(': "SahajContact আর্কাইভ"');
    expect(gallerySource).not.toContain("সহজকন্টাক্ট আর্কাইভ");
  });
});
