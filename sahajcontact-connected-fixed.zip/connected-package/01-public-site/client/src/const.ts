import { OAUTH_STATE_COOKIE, encodeOAuthState } from "@shared/const";

export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Start the Manus OAuth login. Call this from an event handler or effect at the
// moment you want to navigate, e.g. `onClick={() => startLogin()}`.
//
// It has SIDE EFFECTS — it mints a one-time nonce, writes the __Host- state
// cookie, and navigates immediately — so the cookie nonce always matches the
// `state` it sends. Do NOT call it during render (no `href={startLogin()}` /
// `loginUrl={...}`): each call overwrites the cookie, so a stray render-phase
// call would desync it from an in-flight login and the callback would reject it
// with "invalid oauth state". It returns void by design, so there is no URL to
// stash across renders.
const createOAuthNonce = () => {
  const browserCrypto = globalThis.crypto;
  if (typeof browserCrypto?.randomUUID === "function") return browserCrypto.randomUUID();
  if (typeof browserCrypto?.getRandomValues === "function") {
    const bytes = new Uint8Array(16);
    browserCrypto.getRandomValues(bytes);
    return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  }
  throw new Error("এই ব্রাউজারে নিরাপদ লগইন শুরু করা যাচ্ছে না। Chrome বা Safari আপডেট করুন।");
};

export const startLogin = (returnTo?: string) => {
  const oauthPortalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;
  if (!oauthPortalUrl || !appId) {
    throw new Error("লগইন সেবা এখন প্রস্তুত নয়। পেজটি রিফ্রেশ করে আবার চেষ্টা করুন।");
  }

  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const nonce = createOAuthNonce();
  document.cookie = `${OAUTH_STATE_COOKIE}=${nonce}; Path=/; Max-Age=600; SameSite=None; Secure`;

  // Optionally store return destination in a short-lived cookie if returnTo is provided
  if (returnTo) {
    document.cookie = `sahaj_return_to=${encodeURIComponent(returnTo)}; Path=/; Max-Age=600; SameSite=Lax; Secure`;
  }

  const state = encodeOAuthState({ redirectUri, nonce });
  const url = new URL(`${oauthPortalUrl.replace(/\/+$/, "")}/app-auth`);
  url.searchParams.set("appId", appId);
  url.searchParams.set("redirectUri", redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", "signIn");

  // assign() is more reliable than mutating href in some Android WebViews and
  // still preserves the user gesture that started the navigation.
  window.location.assign(url.toString());
};
