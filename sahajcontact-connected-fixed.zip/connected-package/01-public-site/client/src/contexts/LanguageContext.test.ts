import { describe, expect, it } from "vitest";
import { detectBrowserLanguage } from "./LanguageContext";

describe("automatic browser language selection", () => {
  it("selects Bengali for a Bengali browser locale", () => {
    expect(detectBrowserLanguage({ locale: "bn-BD", languages: ["bn-BD", "en-US"], timeZone: "America/New_York" })).toBe("BN");
  });

  it("selects Bengali for Bangladesh timezone even when browser language is English", () => {
    expect(detectBrowserLanguage({ locale: "en-US", languages: ["en-US"], timeZone: "Asia/Dhaka" })).toBe("BN");
  });

  it("keeps Bengali for a non-Bengali foreign locale so expatriate workers are not forced into English", () => {
    expect(detectBrowserLanguage({ locale: "en-GB", languages: ["en-GB", "fr-FR"], timeZone: "Europe/London" })).toBe("BN");
  });

  it("recognizes Bengali in the browser language list", () => {
    expect(detectBrowserLanguage({ locale: "en-US", languages: ["en-US", "bn"], timeZone: "Europe/Berlin" })).toBe("BN");
  });
});
