import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type SiteLanguage = "BN" | "EN";

type LanguageContextValue = {
  language: SiteLanguage;
  isEnglish: boolean;
  setLanguage: (language: SiteLanguage) => void;
  applyManagedDefaultLanguage: (language: SiteLanguage) => void;
  toggleLanguage: () => void;
};

const STORAGE_KEY = "sahajcontact-language";
const MANUAL_PREFERENCE_KEY = "sahajcontact-language-manual-choice";

const LanguageContext = createContext<LanguageContextValue | null>(null);

type BrowserLanguageSignals = {
  locale?: string | null;
  languages?: readonly string[] | null;
  timeZone?: string | null;
};

/**
 * Keeps Bengali as the inclusive first-visit language for Bangladeshis,
 * including expatriate workers whose device may be used abroad. Browser
 * locale/timezone signals can confirm Bengali, but foreign location alone
 * must never force a Bangladeshi visitor into English. English is available
 * through the explicit language toggle and saved manual preference.
 * No GPS or geolocation permission is requested.
 */
export function detectBrowserLanguage({ locale, languages, timeZone }: BrowserLanguageSignals): SiteLanguage {
  const localeSignals = [locale, ...(languages ?? [])]
    .filter((value): value is string => Boolean(value))
    .map((value) => value.toLowerCase());
  const hasBengaliLocale = localeSignals.some((value) => value === "bn" || value.startsWith("bn-") || value.includes("-bd"));
  const isBangladeshTimezone = timeZone === "Asia/Dhaka";
  if (hasBengaliLocale || isBangladeshTimezone) return "BN";

  // Location cannot identify nationality, literacy, or a worker's language.
  // Bengali is therefore the safe and inclusive fallback for all new visitors.
  return "BN";
}

function readInitialLanguage(): SiteLanguage {
  if (typeof window === "undefined") return "BN";

  try {
    const savedLanguage = window.localStorage.getItem(STORAGE_KEY);
    const manualChoice = window.localStorage.getItem(MANUAL_PREFERENCE_KEY) === "1";
    if (manualChoice && (savedLanguage === "BN" || savedLanguage === "EN")) {
      return savedLanguage;
    }

    return detectBrowserLanguage({
      locale: window.navigator.language,
      languages: window.navigator.languages,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    });
  } catch {
    return "BN";
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<SiteLanguage>(readInitialLanguage);

  const setLanguage = useCallback((nextLanguage: SiteLanguage) => {
    try {
      window.localStorage.setItem(MANUAL_PREFERENCE_KEY, "1");
    } catch {
      // Storage may be unavailable in private browsing; the current session still works.
    }
    setLanguageState(nextLanguage);
  }, []);

  const applyManagedDefaultLanguage = useCallback((nextLanguage: SiteLanguage) => {
    try {
      if (window.localStorage.getItem(MANUAL_PREFERENCE_KEY) === "1") return;
    } catch {
      // When storage is unavailable, use the owner-managed default for this session.
    }
    setLanguageState(nextLanguage);
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, language);
    } catch {
      // Keep the language usable even when browser storage is blocked.
    }
    document.documentElement.lang = language === "EN" ? "en" : "bn";
  }, [language]);

  const value = useMemo<LanguageContextValue>(() => ({
    language,
    isEnglish: language === "EN",
    setLanguage,
    applyManagedDefaultLanguage,
    toggleLanguage: () => setLanguage(language === "BN" ? "EN" : "BN"),
  }), [applyManagedDefaultLanguage, language, setLanguage]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used inside LanguageProvider");
  return context;
}

export const languageCopy = {
  BN: {
    heroTitle: "সরকারি সেবা এবং তথ্য এখন প্রত্যেকটা মানুষের হাতের মুঠোয়",
    heroTitleMain: "সেবার পথ",
    heroTitleEmphasis: "পরিষ্কার করুন।",
    heroSubtitle: "সহজ জনসেবা মানুষকে নির্ভরযোগ্য সরকারি তথ্য খুঁজে পেতে সাহায্য করে—আর পরের ধাপটি বুঝতে একটি পরিষ্কার পথ দেখায়।",
    heroSearchLabel: "সেবা খুঁজুন",
    heroFeedback: "আমাদের মতামত জানান",
    shareLink: "লিংক শেয়ার করুন",
    shared: "শেয়ার করা হয়েছে",
    linkCopied: "লিংক কপি হয়েছে",
    aboutTitle: "বাংলাদেশকে জানুন",
    aboutText: "বাংলাদেশ - নদী, মানুষ, মুক্তিযুদ্ধের দেশ।\n১৭ কোটি মানুষের দেশ। আমরা ডিজিটাল বাংলাদেশ গড়ছি।\nবিশ্বের যেখানেই থাকুন, দেশের সব সরকারি সেবা এখন ১ ক্লিকে।",
    diasporaTitle: "প্রবাসী বাংলাদেশিদের কাছেও সহায়তা",
    diasporaDescription: "বাংলাদেশের পরিবার ও সরকারি সেবার তথ্য খুঁজতে বিশ্বের বিভিন্ন দেশ থেকে মানুষ এই পথ ব্যবহার করছেন।",
    shareBangladesh: "SahajContact শেয়ার করুন",
    shareCopied: "লিংক কপি হয়েছে",
    shareError: "আবার চেষ্টা করুন",
    footerRights: "সর্বস্বত্ব সংরক্ষিত। SahajContact ২০২৬",
  },
  EN: {
    heroTitle: "All Government Services in One Place",
    heroTitleMain: "Make the service path",
    heroTitleEmphasis: "clear.",
    heroSubtitle: "Proudly Bangladeshi. Serving citizens at home and abroad.",
    heroSearchLabel: "Find services",
    heroFeedback: "Share your feedback",
    shareLink: "Share link",
    shared: "Shared",
    linkCopied: "Link copied",
    aboutTitle: "Discover Bangladesh",
    aboutText: "Bangladesh - The land of rivers, people, and liberation war.\nA country of 170 million people. We are building Digital Bangladesh.\nWherever you are in the world, get all government services in 1 click.",
    diasporaTitle: "Bangladeshis Around the World",
    diasporaDescription: "People around the world use this path to find information for their families and government services in Bangladesh.",
    shareBangladesh: "Share SahajContact",
    shareCopied: "Link copied",
    shareError: "Please try again",
    footerRights: "All rights reserved. SahajContact 2026",
  },
} as const;

export function getLanguageCopy(language: SiteLanguage) {
  return languageCopy[language];
}
