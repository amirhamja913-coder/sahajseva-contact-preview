export interface GalleryItem {
  id: string;
  category: "development" | "nature" | "culture";
  categoryLabelBn: string;
  categoryLabelEn: string;
  titleBn: string;
  titleEn: string;
  captionBn: string;
  captionEn: string;
  imageUrl: string;
  creditBn?: string;
  creditEn?: string;
  creditUrl?: string;
}

export const BANGLADESH_GALLERY_ITEMS: GalleryItem[] = [
  // প্রথম ছবি: বাংলাদেশের জাতীয় স্মৃতিসৌধ
  {
    id: "culture-national-martyrs-memorial",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "জাতীয় স্মৃতিসৌধ",
    titleEn: "National Martyrs’ Memorial",
    captionBn: "সাভারের জাতীয় স্মৃতিসৌধ—মহান মুক্তিযুদ্ধে আত্মোৎসর্গকারী শহীদদের প্রতি বাংলাদেশের চিরন্তন শ্রদ্ধার প্রতীক।",
    captionEn: "Savar’s National Martyrs’ Memorial—a lasting symbol of Bangladesh’s respect for those who sacrificed their lives in the Liberation War.",
    imageUrl: "/manus-storage/national-martyrs-memorial_bde94f4f.webp",
    creditBn: "ছবি: Talat 99 / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Talat 99 / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:National_memorial_Savar.jpg"
  },
  {
    id: "nature-sajek-user-photo",
    category: "nature",
    categoryLabelBn: "প্রকৃতি",
    categoryLabelEn: "Nature",
    titleBn: "সাজেকের পাহাড়ি পথ",
    titleEn: "Sajek Hillside",
    captionBn: "সবুজ পাহাড়, নীল আকাশ ও শান্ত পথের মায়ায় সাজেকের অনন্য সৌন্দর্য।",
    captionEn: "Sajek's distinct beauty in green hills, blue skies, and peaceful winding paths.",
    imageUrl: "/manus-storage/sajek-landscape_33d990a4.webp"
  },
  {
    id: "nature-mustard-field-user-photo",
    category: "nature",
    categoryLabelBn: "প্রকৃতি",
    categoryLabelEn: "Nature",
    titleBn: "সরিষার হলুদ মাঠ",
    titleEn: "Golden Mustard Field",
    captionBn: "হলুদ সরিষাক্ষেতে বাংলার গ্রামীণ জীবনের উজ্জ্বল, শান্ত ও প্রাণবন্ত রূপ।",
    captionEn: "A bright, peaceful, and lively glimpse of rural Bengal across golden mustard fields.",
    imageUrl: "/manus-storage/mustard-field_93902a4c.webp"
  },

  // উন্নয়ন
  {
    id: "dev-padma-bridge",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "পদ্মা সেতু রাতের দৃশ্য",
    titleEn: "Padma Bridge at Night",
    captionBn: "পদ্মা সেতুর আলোকিত সৌন্দর্য ও আধুনিক যোগাযোগ ব্যবস্থার নতুন দিগন্ত।",
    captionEn: "The illuminated beauty of Padma Bridge and a new era of modern connectivity.",
    imageUrl: "/manus-storage/padma-bridge_60d5bee2.webp",
    creditBn: "ছবি: Abdulmominbd / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Abdulmominbd / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Padma_Bridge_03.jpg"
  },
  {
    id: "dev-karnafuli-tunnel",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "কর্ণফুলী টানেল",
    titleEn: "Karnafuli Tunnel",
    captionBn: "দক্ষিণ এশিয়ার প্রথম তলদেশীয় টানেল—স্মার্ট বাংলাদেশের এক অনন্য প্রকৌশল কীর্তি।",
    captionEn: "South Asia's first underwater tunnel—a remarkable engineering achievement of Smart Bangladesh.",
    imageUrl: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: "dev-jamuna-bridge",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "যমুনা সেতু",
    titleEn: "Jamuna Bridge",
    captionBn: "যমুনা নদীর ওপর নির্মিত বহুমুখী সেতু—উত্তর ও পশ্চিমাঞ্চলের যোগাযোগের গুরুত্বপূর্ণ দ্বার।",
    captionEn: "The multipurpose bridge over the Jamuna River, a vital gateway connecting northern and western Bangladesh.",
    imageUrl: "/manus-storage/jamuna-bridge_e8ca34a3.webp",
    creditBn: "ছবি: Mahbub Shaheed / Wikimedia Commons · CC BY-SA 2.0",
    creditEn: "Photo: Mahbub Shaheed / Wikimedia Commons · CC BY-SA 2.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Bangabandhu_Bridge_(Jamuna_Multi-purpose_Bridge).jpg"
  },
  {
    id: "dev-bhairab-bridge",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "ভৈরব সেতু",
    titleEn: "Bhairab Bridge",
    captionBn: "মেঘনা নদীর তীরে ভৈরবের ঐতিহাসিক সেতু—রেল ও আঞ্চলিক যোগাযোগের স্মারক।",
    captionEn: "Bhairab's historic bridge beside the Meghna, carrying the story of rail and regional connectivity.",
    imageUrl: "/manus-storage/bhairab-bridge_d2be02c3.webp",
    creditBn: "ছবি: Moheen Reeyad / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Moheen Reeyad / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Anderson_Bridge,_Bhairab_(01).jpg"
  },
  {
    id: "dev-hardinge-bridge",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "হার্ডিঞ্জ ব্রিজ",
    titleEn: "Hardinge Bridge",
    captionBn: "পাকশীর ঐতিহাসিক হার্ডিঞ্জ ব্রিজ—বাংলাদেশের রেল অবকাঠামোর এক অনন্য ঐতিহ্য।",
    captionEn: "Historic Hardinge Bridge at Pakshi, an enduring landmark of Bangladesh's railway infrastructure.",
    imageUrl: "/manus-storage/hardinge-bridge_e1d708fe.webp",
    creditBn: "ছবি: Abdulmominbd / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Abdulmominbd / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Hardinge_2.jpg"
  },
  {
    id: "culture-national-museum",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "বাংলাদেশ জাতীয় জাদুঘর",
    titleEn: "Bangladesh National Museum",
    captionBn: "ঢাকার শাহবাগে অবস্থিত বাংলাদেশ জাতীয় জাদুঘর—দেশের ইতিহাস, শিল্প, প্রত্নতত্ত্ব ও সাংস্কৃতিক ঐতিহ্য সংরক্ষণের অন্যতম প্রধান প্রতিষ্ঠান।",
    captionEn: "The Bangladesh National Museum in Shahbag, Dhaka—one of the country’s leading institutions for preserving history, art, archaeology, and cultural heritage.",
    imageUrl: "/manus-storage/bangladesh-national-museum_84610abf.webp",
    creditBn: "ছবি: Babul abdul malek / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Babul abdul malek / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:DG_91_-_09_NATIONAL_MUSEUM_DHAKA_IMG_3171.jpg"
  },
  {
    id: "dev-bibiyana-gas-field",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "বিবিয়ানা গ্যাস ফিল্ড",
    titleEn: "Bibiyana Gas Field",
    captionBn: "সিলেটের বিবিয়ানা গ্যাস ফিল্ড—দেশের জ্বালানি নিরাপত্তায় গুরুত্বপূর্ণ প্রাকৃতিক সম্পদ।",
    captionEn: "The Bibiyana gas field in Sylhet, an important natural resource supporting Bangladesh's energy security.",
    imageUrl: "/manus-storage/bibiyana-gas-field_323a0ddc.webp",
    creditBn: "ছবি: Shakir Ahmed / Wikimedia Commons · CC BY-SA 3.0",
    creditEn: "Photo: Shakir Ahmed / Wikimedia Commons · CC BY-SA 3.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Bibiyana_Gas_Field,.jpg"
  },
  {
    id: "dev-chattogram-port",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "চট্টগ্রাম বন্দর",
    titleEn: "Chattogram Port",
    captionBn: "বাংলাদেশের প্রধান সমুদ্রবন্দর—বাণিজ্য, আমদানি-রপ্তানি ও অর্থনীতির গুরুত্বপূর্ণ প্রবেশদ্বার।",
    captionEn: "Bangladesh's principal seaport and a key gateway for trade, imports, exports, and the wider economy.",
    imageUrl: "/manus-storage/chattogram-port_1f2f2214.webp",
    creditBn: "ছবি: Tazmeem / Wikimedia Commons · Public domain",
    creditEn: "Photo: Tazmeem / Wikimedia Commons · Public domain",
    creditUrl: "https://commons.wikimedia.org/wiki/File:PORT_CTG_TAZMEEM.JPG"
  },
  {
    id: "dev-shahjalal-airport",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দর",
    titleEn: "Hazrat Shahjalal International Airport",
    captionBn: "ঢাকার আন্তর্জাতিক বিমানবন্দর—বিশ্বের সঙ্গে বাংলাদেশের আকাশপথের গুরুত্বপূর্ণ সংযোগ।",
    captionEn: "Dhaka's international airport, an important air link connecting Bangladesh with the world.",
    imageUrl: "/manus-storage/shahjalal-airport_a9e9083c.webp",
    creditBn: "ছবি: Md Shaifuzzaman Ayon / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Md Shaifuzzaman Ayon / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Hazrat_Shahjalal_International_Airport,_Dhaka,_Bangladesh.jpg"
  },

  // প্রকৃতি
  {
    id: "nature-sundarbans",
    category: "nature",
    categoryLabelBn: "প্রকৃতি",
    categoryLabelEn: "Nature",
    titleBn: "সুন্দরবন",
    titleEn: "The Sundarbans",
    captionBn: "বিশ্বের বৃহত্তম ম্যানগ্রোভ বন ও বাংলাদেশের অমূল্য প্রাকৃতিক ঐতিহ্য।",
    captionEn: "The world's largest mangrove forest and one of Bangladesh's priceless natural treasures.",
    imageUrl: "/manus-storage/sundarban-bangladesh_062046e9.webp",
    creditBn: "ছবি: Ferdous / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Ferdous / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Sundarban_(6).jpg"
  },
  {
    id: "nature-coxs-bazar",
    category: "nature",
    categoryLabelBn: "প্রকৃতি",
    categoryLabelEn: "Nature",
    titleBn: "কক্সবাজার সমুদ্র সৈকত",
    titleEn: "Cox's Bazar Sea Beach",
    captionBn: "দিগন্তজোড়া সমুদ্র, বালুকাবেলা ও গোধূলির নরম আলোয় কক্সবাজার।",
    captionEn: "Cox's Bazar beneath an open horizon, sandy shores, and soft twilight light.",
    imageUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80"
  },

  // সংস্কৃতি (Extended with Muslim Eid, Hindu Puja, and Hill Indigenous Festivals)
  {
    id: "culture-eid-festival",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "মুসলিমদের পবিত্র ঈদ উৎসব",
    titleEn: "Eid Festival Celebration",
    captionBn: "আনন্দ, সৌহার্দ্য ও ভ্রাতৃত্বের মেলবন্ধনে পবিত্র ঈদুল ফিতর ও ঈদুল আজহার উৎসবমুখর পরিবেশ।",
    captionEn: "The joyous atmosphere of Eid-ul-Fitr and Eid-ul-Adha bringing unity, warmth, and brotherhood.",
    imageUrl: "https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: "culture-hindu-puja",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "সনাতন ধর্মাবলম্বীদের শারদীয় দুর্গোৎসব",
    titleEn: "Durga Puja Festival",
    captionBn: "রঙিন মণ্ডপ, আলোকসজ্জা ও ভক্তদের অংশগ্রহণে সর্বজনীন শারদীয় দুর্গোৎসবের উৎসবমুখর রূপ।",
    captionEn: "The vibrant celebration of Durga Puja with colorful pandals, lights, and devoted community gatherings.",
    imageUrl: "/manus-storage/durga-puja-bangladesh_064dca04.webp",
    creditBn: "ছবি: Naren marik / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Naren marik / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Durga_Puja_celebrations_in_Bangladesh.jpg"
  },
  {
    id: "dev-hill-tract-community-development",
    category: "development",
    categoryLabelBn: "উন্নয়ন",
    categoryLabelEn: "Development",
    titleBn: "পাহাড়ি জনগোষ্ঠীর উন্নয়ন",
    titleEn: "Indigenous Hill-Tract Development",
    captionBn: "রাঙামাটির পাহাড়ি জনগোষ্ঠীর শিশুদের শিক্ষা ও ভবিষ্যৎ গড়ার ইতিবাচক প্রতিচ্ছবি—সমতা, সুযোগ ও অন্তর্ভুক্তিমূলক উন্নয়নের বার্তা।",
    captionEn: "A positive portrait of indigenous children in Rangamati pursuing education and opportunity—reflecting inclusive development in the Hill Tracts.",
    imageUrl: "/manus-storage/hill-tract-indigenous-schoolgirls_564e9d0c.webp",
    creditBn: "ছবি: Adam Jones, Ph.D. / Global Photo Archive · CC BY-SA 2.0",
    creditEn: "Photo: Adam Jones, Ph.D. / Global Photo Archive · CC BY-SA 2.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Adivasi_(Indigenous)_Schoolgirls_-_Rangamati_-_Chittagong_Hill_Tracts_-_Bangladesh_(13241186474).jpg"
  },
  {
    id: "culture-rickshaw",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "মুক্তিযুদ্ধকালীন মুক্তিবাহিনী",
    titleEn: "Mukti Bahini, 1971",
    captionBn: "১৯৭১ সালের মুক্তিযুদ্ধের সময় মুক্তিবাহিনীর স্বাধীনতা উদযাপনের ঐতিহাসিক দৃশ্য।",
    captionEn: "A historic 1971 independence-celebration scene featuring Mukti Bahini freedom fighters.",
    imageUrl: "/manus-storage/mukti-bahini-1971-public-domain_7588ac83.jpg",
    creditBn: "ছবি: বাংলাদেশ প্রেস ইনফরমেশন ডিপার্টমেন্ট / Wikimedia Commons · Public domain",
    creditEn: "Photo: Press Information Department of Bangladesh / Wikimedia Commons · Public domain",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Bangladesh_Liberation_War_independence_celebration_Dohar_Dhaka_1971-12-16_(PID-h0039).jpg"
  },
  {
    id: "culture-liberation-monument",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "মুক্তিযুদ্ধ স্মৃতিস্তম্ভ",
    titleEn: "Liberation War Monument",
    captionBn: "মহান মুক্তিযুদ্ধে বীর শহীদদের স্মৃতির প্রতি চিরন্তন শ্রদ্ধা ও ভালোবাসা।",
    captionEn: "An eternal tribute of respect and love to the heroes of the Liberation War.",
    imageUrl: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: "culture-2024-victory-celebration",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "২০২৪-এর গণঅভ্যুত্থানের বিজয় উদযাপন",
    titleEn: "2024 Mass Uprising Victory Celebration",
    captionBn: "২০২৪ সালের গণঅভ্যুত্থানের বিজয় উদযাপনে ছাত্র-জনতার শান্তিপূর্ণ সমাবেশ—স্মরণ, সাহস ও আশার এক ঐতিহাসিক মুহূর্ত।",
    captionEn: "A peaceful public celebration of the 2024 mass uprising victory—an historic moment of remembrance, courage, and hope.",
    imageUrl: "/manus-storage/2024-victory-celebration_d65f5e26.webp",
    creditBn: "ছবি: Rayhan9d / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Rayhan9d / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:The_victory_celebration_of_Bangladeshi_student%27s_one_point_movement.jpg"
  },
  {
    id: "culture-2024-public-movement",
    category: "culture",
    categoryLabelBn: "সংস্কৃতি",
    categoryLabelEn: "Culture",
    titleBn: "২০২৪-এর ছাত্র-জনতার আন্দোলন",
    titleEn: "2024 Student-People Movement",
    captionBn: "কেন্দ্রীয় শহীদ মিনারে ২০২৪ সালের ছাত্র-জনতার আন্দোলনের শান্তিপূর্ণ দৃশ্য—জনতার কণ্ঠ ও ঐক্যের দলিল।",
    captionEn: "A peaceful scene from the 2024 student-people movement at Central Shaheed Minar—an image of public voice and solidarity.",
    imageUrl: "/manus-storage/2024-public-movement_03c0aa5f.webp",
    creditBn: "ছবি: Nahidhasan027 / Wikimedia Commons · CC BY-SA 4.0",
    creditEn: "Photo: Nahidhasan027 / Wikimedia Commons · CC BY-SA 4.0",
    creditUrl: "https://commons.wikimedia.org/wiki/File:Protest_in_Bangladesh_01.jpg"
  }
];
