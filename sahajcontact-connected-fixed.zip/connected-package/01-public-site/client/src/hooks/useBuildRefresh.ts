import { useEffect } from "react";

const VERSION_URL = "/__manus__/version.json";
const VERSION_STORAGE_KEY = "sahajseva:last-seen-build";

type BuildMetadata = {
  version?: string;
  timestamp?: number;
};

async function readBuildVersion(): Promise<string | null> {
  try {
    const response = await fetch(`${VERSION_URL}?t=${Date.now()}`, {
      cache: "no-store",
      headers: { Accept: "application/json" },
    });
    if (!response.ok) return null;
    const metadata = (await response.json()) as BuildMetadata;
    return typeof metadata.version === "string" && metadata.version ? metadata.version : null;
  } catch {
    return null;
  }
}

export function useBuildRefresh() {
  useEffect(() => {
    let active = true;
    let checking = false;

    const checkForApprovedBuild = async () => {
      if (!active || checking || document.visibilityState !== "visible") return;
      checking = true;
      const currentVersion = await readBuildVersion();
      checking = false;
      if (!active || !currentVersion) return;

      const lastSeenVersion = window.sessionStorage.getItem(VERSION_STORAGE_KEY);
      if (!lastSeenVersion) {
        window.sessionStorage.setItem(VERSION_STORAGE_KEY, currentVersion);
        return;
      }
      if (lastSeenVersion === currentVersion) return;

      window.sessionStorage.setItem(VERSION_STORAGE_KEY, currentVersion);
      window.location.reload();
    };

    void checkForApprovedBuild();
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") void checkForApprovedBuild();
    };
    const handleWindowFocus = () => void checkForApprovedBuild();

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("focus", handleWindowFocus);
    return () => {
      active = false;
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("focus", handleWindowFocus);
    };
  }, []);
}
