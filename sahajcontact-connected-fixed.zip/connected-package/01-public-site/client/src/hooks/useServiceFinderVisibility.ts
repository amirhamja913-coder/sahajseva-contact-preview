import { useEffect, useState } from "react";

export const SERVICE_FINDER_MEDIA_QUERY = "(max-width: 760px)";

export function shouldHideMobileFloatingActions(isCompactViewport: boolean, isServiceFinderVisible: boolean) {
  return isCompactViewport && isServiceFinderVisible;
}

export function useServiceFinderVisibility() {
  const [isCompactViewport, setIsCompactViewport] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia(SERVICE_FINDER_MEDIA_QUERY).matches;
  });
  const [isServiceFinderVisible, setIsServiceFinderVisible] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia(SERVICE_FINDER_MEDIA_QUERY);
    const handleMediaChange = () => setIsCompactViewport(mediaQuery.matches);

    handleMediaChange();
    mediaQuery.addEventListener?.("change", handleMediaChange);
    return () => mediaQuery.removeEventListener?.("change", handleMediaChange);
  }, []);

  useEffect(() => {
    const serviceFinder = document.getElementById("services");
    if (!serviceFinder || typeof IntersectionObserver === "undefined") return;

    const observer = new IntersectionObserver(
      ([entry]) => setIsServiceFinderVisible(entry.isIntersecting),
      { rootMargin: "-12% 0px -12% 0px", threshold: 0.01 },
    );

    observer.observe(serviceFinder);
    return () => observer.disconnect();
  }, []);

  return shouldHideMobileFloatingActions(isCompactViewport, isServiceFinderVisible);
}
