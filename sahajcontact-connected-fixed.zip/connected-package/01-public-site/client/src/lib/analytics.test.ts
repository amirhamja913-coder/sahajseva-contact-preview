import { beforeEach, describe, expect, it, vi } from "vitest";

describe("GA4 analytics helper", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.stubGlobal("window", {
      gtag: vi.fn(),
      location: { pathname: "/" },
    });
    vi.stubGlobal("document", { referrer: "" });
    vi.stubGlobal("navigator", { sendBeacon: vi.fn() });
  });

  it("forwards custom interaction events to GA4 gtag", async () => {
    const { trackEvent } = await import("./analytics");
    const gtag = (window as unknown as { gtag: ReturnType<typeof vi.fn> }).gtag;

    trackEvent("sahaj_chat_open", { source: "floating_button" });

    expect(gtag).toHaveBeenCalledWith("event", "sahaj_chat_open", {
      source: "floating_button",
    });
  });

  it("sends the footer WhatsApp event with its location parameter", async () => {
    const { trackEvent } = await import("./analytics");
    const gtag = (window as unknown as { gtag: ReturnType<typeof vi.fn> }).gtag;

    trackEvent("whatsapp_click", { button_location: "footer" });

    expect(gtag).toHaveBeenCalledWith("event", "whatsapp_click", {
      button_location: "footer",
    });
  });

  it("keeps outbound events compatible with the shared event contract", async () => {
    const { trackOutbound } = await import("./analytics");
    const gtag = (window as unknown as { gtag: ReturnType<typeof vi.fn> }).gtag;

    trackOutbound("সেবা CTA", "https://example.gov.bd", "official_link");

    expect(gtag).toHaveBeenCalledWith("event", "outbound_action", {
      label: "সেবা CTA",
      destination: "https://example.gov.bd",
      kind: "official_link",
    });
  });

  it("forwards growth CTA conversion metadata for acquisition reporting", async () => {
    const { trackEvent } = await import("./analytics");
    const gtag = (window as unknown as { gtag: ReturnType<typeof vi.fn> }).gtag;

    trackEvent("growth_cta_click", {
      label: "বিশেষ সেবা ও ফি দেখুন",
      destination: "#paid-assistance",
      conversion_location: "ai_banner",
    });

    expect(gtag).toHaveBeenCalledWith("event", "growth_cta_click", {
      label: "বিশেষ সেবা ও ফি দেখুন",
      destination: "#paid-assistance",
      conversion_location: "ai_banner",
    });
  });

  it("forwards WhatsApp conversion metadata for acquisition reporting", async () => {
    const { trackEvent } = await import("./analytics");
    const gtag = (window as unknown as { gtag: ReturnType<typeof vi.fn> }).gtag;

    trackEvent("whatsapp_click", {
      button_location: "ai_banner",
      conversion: true,
      conversion_location: "ai_banner",
    });

    expect(gtag).toHaveBeenCalledWith("event", "whatsapp_click", {
      button_location: "ai_banner",
      conversion: true,
      conversion_location: "ai_banner",
    });
  });
});
