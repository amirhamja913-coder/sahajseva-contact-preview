type AnalyticsProperties = Record<string, string | number | boolean | undefined>;

type GtagFunction = (
  command: "event",
  eventName: string,
  properties: AnalyticsProperties,
) => void;

type CampaignAttribution = {
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  landing_path?: string;
};

declare global {
  interface Window {
    gtag?: GtagFunction;
  }
}

const ANALYTICS_ENDPOINT = import.meta.env.VITE_ANALYTICS_ENDPOINT as string | undefined;
const WEBSITE_ID = import.meta.env.VITE_ANALYTICS_WEBSITE_ID as string | undefined;
const CAMPAIGN_STORAGE_KEY = "sahaj_campaign_attribution";
const CAMPAIGN_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content"] as const;
const OUTBOUND_UTM_SOURCE = "sahajcontact";
const OUTBOUND_UTM_MEDIUM = "button";

function isExternalUrl(url: URL): boolean {
  if (typeof window === "undefined") return false;
  return url.origin !== window.location.origin && (url.protocol === "http:" || url.protocol === "https:");
}

/** Add consistent campaign attribution to external civic-service links without changing internal navigation. */
export function buildOutboundUrl(destination: string, campaign = "official_link"): string {
  if (typeof window === "undefined") return destination;

  try {
    const url = new URL(destination, window.location.href);
    if (!isExternalUrl(url)) return destination;

    if (!url.searchParams.has("utm_source")) url.searchParams.set("utm_source", OUTBOUND_UTM_SOURCE);
    if (!url.searchParams.has("utm_medium")) url.searchParams.set("utm_medium", OUTBOUND_UTM_MEDIUM);
    if (!url.searchParams.has("utm_campaign")) url.searchParams.set("utm_campaign", campaign.slice(0, 80));
    return url.toString();
  } catch {
    return destination;
  }
}

/** Decorate every external anchor click once, including plain anchors outside the shared link component. */
export function installOutboundUtmTracking(): () => void {
  if (typeof document === "undefined") return () => undefined;

  const handleClick = (event: MouseEvent) => {
    if (event.defaultPrevented) return;
    const target = event.target;
    if (!(target instanceof Element)) return;
    const anchor = target.closest<HTMLAnchorElement>("a[href]");
    if (!anchor) return;
    const nextHref = buildOutboundUrl(anchor.href, anchor.dataset.utmCampaign || "external_link");
    if (nextHref !== anchor.href) anchor.href = nextHref;
  };

  document.addEventListener("click", handleClick, true);
  return () => document.removeEventListener("click", handleClick, true);
}

function readStoredAttribution(): CampaignAttribution {
  if (typeof window === "undefined") return {};

  try {
    const raw = sessionStorage.getItem(CAMPAIGN_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as CampaignAttribution;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

/** Capture UTM values once per browser session without storing any personal data. */
export function captureCampaignAttribution(): CampaignAttribution {
  if (typeof window === "undefined") return {};

  const params = new URLSearchParams(window.location.search);
  const current: CampaignAttribution = {};

  for (const key of CAMPAIGN_KEYS) {
    const value = params.get(key)?.trim();
    if (value) current[key] = value.slice(0, 120);
  }

  const stored = readStoredAttribution();
  const attribution = Object.keys(current).length
    ? { ...stored, ...current, landing_path: window.location.pathname }
    : stored;

  if (Object.keys(attribution).length) {
    try {
      sessionStorage.setItem(CAMPAIGN_STORAGE_KEY, JSON.stringify(attribution));
    } catch {
      // Attribution is optional and must never interrupt the customer journey.
    }
  }

  return attribution;
}

export function getCampaignAttribution(): CampaignAttribution {
  return captureCampaignAttribution();
}

export function trackEvent(name: string, properties: AnalyticsProperties = {}) {
  if (typeof window === "undefined") return;

  const enrichedProperties: AnalyticsProperties = {
    ...getCampaignAttribution(),
    ...properties,
  };

  // Send custom events to the user-provided GA4 property when gtag is available.
  // No names, phone numbers, NID values, or form contents are included here.
  window.gtag?.("event", name, enrichedProperties);

  // Preserve the existing first-party analytics stream as a fallback and for
  // project-level reporting in the Manus dashboard.
  if (!ANALYTICS_ENDPOINT || !WEBSITE_ID) return;

  const payload = JSON.stringify({
    websiteId: WEBSITE_ID,
    event: name,
    properties: enrichedProperties,
    path: window.location.pathname,
    referrer: document.referrer || undefined,
  });

  try {
    if (navigator.sendBeacon) {
      navigator.sendBeacon(ANALYTICS_ENDPOINT, new Blob([payload], { type: "application/json" }));
    } else {
      void fetch(ANALYTICS_ENDPOINT, {
        method: "POST",
        body: payload,
        headers: { "Content-Type": "application/json" },
        keepalive: true,
      });
    }
  } catch {
    // Measurement must never interrupt a citizen's service journey.
  }
}

export function trackOutbound(label: string, destination: string, kind = "official_link") {
  const decoratedDestination = buildOutboundUrl(destination, kind);
  // Keep the established GA4 event contract stable; the decorated URL is used
  // for navigation and remains available to callers without changing legacy
  // event payloads.
  trackEvent("outbound_action", {
    label,
    destination,
    kind,
  });
  return decoratedDestination;
}

export function trackConversion(name: string, location: string, extra: AnalyticsProperties = {}) {
  trackEvent(name, { conversion_location: location, ...extra });
}

export {};
