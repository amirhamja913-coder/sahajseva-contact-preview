export interface BangladeshMapDivision {
  id: string;
  name: string;
  summary: string;
  href: string;
  x: number;
  y: number;
}

/**
 * Approximate visual anchor points for the eight divisions on the supplied
 * editorial map artwork. The points are intentionally treated as interaction
 * anchors, not geographic boundary data.
 */
export const bangladeshMapDivisions: BangladeshMapDivision[] = [
  {
    id: "rangpur",
    name: "রংপুর বিভাগ",
    summary: "কৃষি, ভাতা ও সামাজিক সহায়তার সরকারি তথ্য খুঁজুন।",
    href: "https://rangpurdiv.gov.bd/",
    x: 30,
    y: 18,
  },
  {
    id: "rajshahi",
    name: "রাজশাহী বিভাগ",
    summary: "কৃষি, শিক্ষা ও জেলা প্রশাসনের সেবা এক জায়গায় দেখুন।",
    href: "https://rajshahidiv.gov.bd/",
    x: 24,
    y: 38,
  },
  {
    id: "mymensingh",
    name: "ময়মনসিংহ বিভাগ",
    summary: "কৃষি, শিক্ষা ও স্থানীয় প্রশাসনের সরকারি পথ দেখুন।",
    href: "https://mymensinghdiv.gov.bd/",
    x: 67,
    y: 28,
  },
  {
    id: "sylhet",
    name: "সিলেট বিভাগ",
    summary: "প্রবাসী, পর্যটন ও নাগরিক সেবার অফিসিয়াল তথ্য খুঁজুন।",
    href: "https://sylhetdiv.gov.bd/",
    x: 86,
    y: 34,
  },
  {
    id: "dhaka",
    name: "ঢাকা বিভাগ",
    summary: "জাতীয় সেবা, ভূমি ও প্রশাসনিক তথ্যের সরকারি উৎসে যান।",
    href: "https://dhakadiv.gov.bd/",
    x: 55,
    y: 48,
  },
  {
    id: "khulna",
    name: "খুলনা বিভাগ",
    summary: "উপকূলীয় সহায়তা, ভূমি ও কৃষি সেবার তথ্য দেখুন।",
    href: "https://khulnadiv.gov.bd/",
    x: 28,
    y: 67,
  },
  {
    id: "barishal",
    name: "বরিশাল বিভাগ",
    summary: "জেলা প্রশাসন, কৃষি ও নদীভিত্তিক সহায়তার পথ খুঁজুন।",
    href: "https://barisaldiv.gov.bd/",
    x: 55,
    y: 73,
  },
  {
    id: "chattogram",
    name: "চট্টগ্রাম বিভাগ",
    summary: "উপকূল, বন্দর ও নাগরিক সেবার অফিসিয়াল তথ্য দেখুন।",
    href: "https://chattogramdiv.gov.bd/",
    x: 79,
    y: 69,
  },
];

export const getBangladeshMapDivision = (id: string) =>
  bangladeshMapDivisions.find((division) => division.id === id);
