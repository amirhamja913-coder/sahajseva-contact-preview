import { describe, expect, it } from "vitest";
import { categoryById, serviceCategories, serviceCategoryByNumber } from "./categorizedServices";

const expectedCategoryNames = [
  "পরিচয় ও নিবন্ধন",
  "নাগরিক ও প্রশাসনিক সেবা",
  "ভাতা ও সমাজসেবা",
  "ভূমি ও ইউটিলিটি",
  "কৃষি ও কৃষক সেবা",
  "ব্যবসা ও কর",
  "যাতায়াত ও ভ্রমণ",
  "শিক্ষা ও চাকরি",
  "স্বাস্থ্য ও টিকা",
  "জরুরি ও অন্যান্য",
];

describe("categorized civic services", () => {
  it("defines the requested Bengali categories in a stable presentation order", () => {
    expect(serviceCategories.map((category) => category.name)).toEqual(expectedCategoryNames);
  });

  it("assigns every service number from 01 through 40 to a defined category", () => {
    const serviceNumbers = Array.from({ length: 40 }, (_, index) => String(index + 1).padStart(2, "0"));
    expect(Object.keys(serviceCategoryByNumber).sort()).toEqual(serviceNumbers);
    expect(Object.values(serviceCategoryByNumber).every((id) => Boolean(categoryById[id]))).toBe(true);
  });

  it("keeps the newly added civic services in their intended sections", () => {
    expect(serviceCategoryByNumber).toMatchObject({
      "31": "identity",
      "32": "identity",
      "33": "identity",
      "34": "land_utility",
      "35": "agriculture",
      "36": "social",
      "37": "business_tax",
      "38": "transport",
      "39": "education",
      "40": "education",
    });
  });
});
