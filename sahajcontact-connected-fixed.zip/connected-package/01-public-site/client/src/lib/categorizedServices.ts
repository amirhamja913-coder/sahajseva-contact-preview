export type ServiceCategoryId =
  | "identity"
  | "citizen"
  | "social"
  | "land_utility"
  | "agriculture"
  | "business_tax"
  | "transport"
  | "education"
  | "health"
  | "emergency";

export type ServiceCategory = {
  id: ServiceCategoryId;
  name: string;
  nameEn: string;
  description: string;
  descriptionEn: string;
  iconName: string;
};

export const serviceCategories: ServiceCategory[] = [
  {
    id: "identity",
    name: "পরিচয় ও নিবন্ধন",
    nameEn: "Identity & Registration",
    description: "জাতীয় পরিচয়পত্র, পাসপোর্ট, জন্ম-মৃত্যু নিবন্ধন ও পুলিশ ক্লিয়ারেন্স",
    descriptionEn: "National ID, passport, birth and death registration, and police clearance",
    iconName: "ShieldCheck",
  },
  {
    id: "citizen",
    name: "নাগরিক ও প্রশাসনিক সেবা",
    nameEn: "Citizen & Administrative Services",
    description: "স্থানীয় প্রশাসন, থানা, সরকারি আবেদন ও নাগরিক অধিকার সহায়তা",
    descriptionEn: "Local administration, police support, government applications, and civic rights assistance",
    iconName: "Landmark",
  },
  {
    id: "social",
    name: "ভাতা ও সমাজসেবা",
    nameEn: "Benefits & Social Services",
    description: "বয়স্ক, বিধবা, প্রতিবন্ধী ভাতা, লিগ্যাল এইড ও সামাজিক সুরক্ষা",
    descriptionEn: "Old-age, widow, disability benefits, legal aid, and social protection",
    iconName: "HeartHandshake",
  },
  {
    id: "land_utility",
    name: "ভূমি ও ইউটিলিটি",
    nameEn: "Land & Utilities",
    description: "জমির খতিয়ান/পর্চা, বিদ্যুৎ, গ্যাস, পানি ও পল্লী বিদ্যুৎ সেবা",
    descriptionEn: "Land records, electricity, gas, water, and rural electricity services",
    iconName: "Landmark",
  },
  {
    id: "agriculture",
    name: "কৃষি ও কৃষক সেবা",
    nameEn: "Agriculture & Farmer Services",
    description: "কৃষক কার্ড, সার, বীজ, প্রণোদনা ও কৃষি মন্ত্রণালয়ের সরকারি পথ",
    descriptionEn: "Farmer cards, fertilizer, seeds, incentives, and official agriculture services",
    iconName: "Sprout",
  },
  {
    id: "business_tax",
    name: "ব্যবসা ও কর",
    nameEn: "Business & Tax",
    description: "ট্রেড লাইসেন্স, eTIN সার্টিফিকেট ও সরকারি কর-সংক্রান্ত সেবা",
    descriptionEn: "Trade licences, e-TIN certificates, and government tax services",
    iconName: "BadgePercent",
  },
  {
    id: "transport",
    name: "যাতায়াত ও ভ্রমণ",
    nameEn: "Transport & Travel",
    description: "রেল, বাস, বিমান, ড্রাইভিং লাইসেন্স ও বিআরটিসি সেবা",
    descriptionEn: "Rail, bus, air travel, driving licence, and BRTC services",
    iconName: "Ticket",
  },
  {
    id: "education",
    name: "শিক্ষা ও চাকরি",
    nameEn: "Education & Employment",
    description: "শিক্ষা সার্টিফিকেট, বোর্ড ফলাফল, সরকারি চাকরি ও শিক্ষা অধিদপ্তর",
    descriptionEn: "Education certificates, board results, government jobs, and education services",
    iconName: "BookOpen",
  },
  {
    id: "health",
    name: "স্বাস্থ্য ও টিকা",
    nameEn: "Health & Vaccination",
    description: "স্বাস্থ্য অধিদপ্তর, টিকা সনদ এবং হাসপাতাল সেবা",
    descriptionEn: "Directorate of Health services, vaccination certificates, and hospitals",
    iconName: "HeartPulse",
  },
  {
    id: "emergency",
    name: "জরুরি ও অন্যান্য",
    nameEn: "Emergency & Other Services",
    description: "জরুরি সহায়তা, প্রবাসী কল্যাণ, সরকারি মিডিয়া ও অন্যান্য পোর্টাল",
    descriptionEn: "Emergency assistance, expatriate welfare, government media, and other portals",
    iconName: "Phone",
  },
];

/** Every existing service number is assigned exactly once so grouped rendering never drops an entry. */
export const serviceCategoryByNumber: Record<string, ServiceCategoryId> = {
  "01": "citizen",
  "02": "citizen",
  "03": "citizen",
  "04": "social",
  "05": "social",
  "06": "social",
  "07": "social",
  "08": "transport",
  "09": "transport",
  "10": "transport",
  "11": "health",
  "12": "health",
  "13": "citizen",
  "14": "citizen",
  "15": "land_utility",
  "16": "social",
  "17": "identity",
  "18": "identity",
  "19": "citizen",
  "20": "citizen",
  "21": "emergency",
  "22": "emergency",
  "23": "emergency",
  "24": "education",
  "25": "education",
  "26": "education",
  "27": "education",
  "28": "education",
  "29": "emergency",
  "30": "transport",
  "31": "identity",
  "32": "identity",
  "33": "identity",
  "34": "land_utility",
  "35": "agriculture",
  "36": "social",
  "37": "business_tax",
  "38": "transport",
  "39": "education",
  "40": "education",
};

export const categoryById = Object.fromEntries(
  serviceCategories.map((category) => [category.id, category]),
) as Record<ServiceCategoryId, ServiceCategory>;

export function getLocalizedServiceCategory(category: ServiceCategory, language: "BN" | "EN") {
  return {
    ...category,
    name: language === "EN" ? category.nameEn : category.name,
    description: language === "EN" ? category.descriptionEn : category.description,
  };
}
