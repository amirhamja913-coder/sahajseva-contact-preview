import type { CivicService } from "./newCivicServices";
import type { SiteLanguage } from "@/contexts/LanguageContext";

export type CivicServiceEnglishCopy = {
  title: string;
  tag: string;
  text: string;
};

/**
 * Explicit English copy for every homepage civic service. The homepage must
 * never fall back to a Bengali value when English is selected.
 */
export const civicServiceEnglishCopy: Record<string, CivicServiceEnglishCopy> = {
  "01": { title: "Civic Services", tag: "Official source", text: "Find the official path, preparation steps, and source for essential government services." },
  "02": { title: "Police Station Assistance", tag: "Citizen support", text: "Understand how to contact a police station, make a general complaint, and follow the next steps." },
  "03": { title: "Women and Children’s Rights", tag: "Rights support", text: "Reach the right path for women’s and children’s safety, rights, and assistance." },
  "04": { title: "Social Services", tag: "Social support", text: "Find relevant Department of Social Services programs and application paths in one place." },
  "05": { title: "Disability Allowance", tag: "Allowance service", text: "Find the essential information for disability allowance and related support." },
  "06": { title: "Old-Age and Widow Allowance", tag: "Allowance service", text: "Understand the path for old-age, widow, and deserted-women allowances." },
  "07": { title: "Other Government Allowances", tag: "Allowance service", text: "Find information about different government allowances for families and citizens." },
  "08": { title: "Air Tickets", tag: "Transport", text: "Review essential information, preparation steps, and ticket pathways before flying." },
  "09": { title: "Train Tickets", tag: "Transport", text: "Understand the essential steps for train tickets and rail travel." },
  "10": { title: "BRTC Bus and Tickets", tag: "BRTC public transport", text: "Find the official path for BRTC buses, routes, tickets, and contact information." },
  "11": { title: "Hospital Directory", tag: "Service directory", text: "Browse hospital and healthcare information in one organized directory." },
  "12": { title: "Health Information", tag: "Government source", text: "Reach official authorities and government sources for health information." },
  "13": { title: "Union and Local Office", tag: "Administrative support", text: "Find the path for local civic services, certificates, and administrative assistance." },
  "14": { title: "District Commissioner Office", tag: "Administrative support", text: "Find district administration offices, citizen applications, and essential official information." },
  "15": { title: "Electricity, Gas, and Water", tag: "Utility services", text: "Find the path for electricity, gas, and water connections, complaints, and citizen services." },
  "16": { title: "Government Support for People in Need", tag: "Social support", text: "Learn about government benefits, assistance, and application paths for people in need." },
  "17": { title: "National Identity Card (NID)", tag: "Official online service", text: "Use the official path for NID online services, new voters, corrections, duplicate cards, and smart cards." },
  "18": { title: "E-Passport Services", tag: "Official online application", text: "Visit the official portal for e-passport applications or reissue, guidance, fees, and required documents." },
  "19": { title: "Government Online Applications", tag: "National information portal", text: "Use the national information portal to find the correct government department and online application path." },
  "20": { title: "Free Legal Aid", tag: "Government legal aid", text: "Eligible people can learn about the government legal-aid application path and the 16430 toll-free helpline; eligibility and decisions are determined by the authority." },
  "21": { title: "Expatriate Services and Support", tag: "Expatriate welfare", text: "Find official paths for pre-departure preparation, expatriate welfare, complaints, and government assistance." },
  "22": { title: "Bangladesh Television (BTV)", tag: "Public media", text: "Visit the official BTV path for public programs, awareness content, news, and public-service information." },
  "23": { title: "Bangladesh Betar Public Radio", tag: "Public media", text: "Reach the official source for public radio programs, information, and online media navigation." },
  "24": { title: "Education Board Services", tag: "Official education service", text: "Find official education-board services, certificates, results, and examination information." },
  "25": { title: "School Education Services", tag: "Official education service", text: "Find official school-education information, notices, and service pathways." },
  "26": { title: "Madrasa Education Services", tag: "Official education service", text: "Find official madrasa-education information, notices, and service pathways." },
  "27": { title: "Official Government Job Circulars", tag: "Official recruitment", text: "Use the official recruitment portal for government job circulars and applications; verify every notice’s conditions yourself." },
  "28": { title: "Bangladesh Public Service Commission (BPSC)", tag: "Government recruitment", text: "Reach the official source for BCS and PSC notices, examinations, and application information." },
  "29": { title: "Bangladesh Telecommunications Company (BTCL)", tag: "BTCL public service", text: "Find the official path for BTCL customer service, telephone, internet, and domain-related services." },
  "30": { title: "Public Transport and Communications (BRTC)", tag: "BRTC service directory", text: "Reach the official BRTC portal for transport, communications, and citizen information." },
  "31": { title: "National Identity Card (NID) Online Application and Correction", tag: "Official online application", text: "Use the official service portal for voter registration, NID corrections, and replacement cards." },
  "32": { title: "E-Passport Online Application and Renewal", tag: "Official passport service", text: "Use the official portal for new e-passport applications, fees, appointments, and passport status checks." },
  "33": { title: "Birth and Death Registration Online Application", tag: "Official birth and death service", text: "Use the official registrar site for birth or death registration, certificate verification, and corrections." },
  "34": { title: "Land Development Tax and Mutation", tag: "Official land service", text: "Use the Ministry of Land portal for online land-development tax, mutation applications, khatiyan, and porcha services." },
  "35": { title: "Farmer Card, Fertilizer, Seed, and Incentive Applications", tag: "Official agriculture service", text: "Use the Ministry of Agriculture portal for farmer registration, agriculture cards, fertilizer and seed subsidies, and government incentives." },
  "36": { title: "Old-Age, Widow, and Disability Allowance Application", tag: "Official social service", text: "Use the government portal for old-age, widow, disability, and maternity allowance applications and information." },
  "37": { title: "Trade License Application and Renewal", tag: "Local government service", text: "Find information and online application services for trade licenses in city-corporation and municipality areas." },
  "38": { title: "BRTA Driving License and Motor Vehicle Services", tag: "Official BRTA service", text: "Use the BRTA portal for driving-license applications, learner permits, vehicle registration, and fee payments." },
  "39": { title: "Official Government Job Applications", tag: "Official job portal", text: "Use the Teletalk and government recruitment portals to review circulars and submit official applications online." },
  "40": { title: "Bangladesh Public Service Commission (BPSC) Applications", tag: "Official BCS and PSC", text: "Use the official portal for BCS and other government-grade examination applications and notices." },
};

export function localizeCivicService(service: CivicService, language: SiteLanguage): CivicService {
  if (language === "BN") return service;
  const english = civicServiceEnglishCopy[service.number];
  if (!english) {
    throw new Error(`Missing English civic-service copy for service ${service.number}`);
  }
  return { ...service, ...english };
}

export function localizeCivicServices(services: CivicService[], language: SiteLanguage): CivicService[] {
  return services.map((service) => localizeCivicService(service, language));
}
