import { describe, expect, it } from "vitest";
import { BANGLADESH_GALLERY_ITEMS } from "../data/bangladeshGallery";

describe("Culture Gallery Festival Additions", () => {
  it("includes Muslim Eid festival in culture category", () => {
    const eid = BANGLADESH_GALLERY_ITEMS.find((i) => i.id === "culture-eid-festival");
    expect(eid).toBeDefined();
    expect(eid?.category).toBe("culture");
    expect(eid?.titleBn).toContain("ঈদ");
  });

  it("includes Hindu Durga Puja festival in culture category", () => {
    const puja = BANGLADESH_GALLERY_ITEMS.find((i) => i.id === "culture-hindu-puja");
    expect(puja).toBeDefined();
    expect(puja?.category).toBe("culture");
    expect(puja?.titleBn).toContain("দুর্গোৎসব");
  });

  it("uses managed, attributed image assets for repaired nature and festival cards", () => {
    const sundarbans = BANGLADESH_GALLERY_ITEMS.find((i) => i.id === "nature-sundarbans");
    const puja = BANGLADESH_GALLERY_ITEMS.find((i) => i.id === "culture-hindu-puja");

    expect(sundarbans?.imageUrl).toMatch(/^\/manus-storage\/.*\.webp$/);
    expect(sundarbans?.creditUrl).toContain("commons.wikimedia.org");
    expect(puja?.imageUrl).toMatch(/^\/manus-storage\/.*\.webp$/);
    expect(puja?.creditUrl).toContain("commons.wikimedia.org");
  });

  it("includes an indigenous hill-tract development theme with bilingual metadata", () => {
    const hill = BANGLADESH_GALLERY_ITEMS.find((i) => i.id === "dev-hill-tract-community-development");
    expect(hill).toBeDefined();
    expect(hill?.category).toBe("development");
    expect(hill?.titleBn).toContain("পাহাড়ি");
    expect(hill?.titleEn).toContain("Indigenous");
    expect(hill?.creditUrl).toContain("commons.wikimedia.org");
  });
});
