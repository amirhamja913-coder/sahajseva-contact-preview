import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const homeSource = fs.readFileSync(
  path.resolve(process.cwd(), "client/src/pages/Home.tsx"),
  "utf8",
);

describe("diaspora country reach", () => {
  it("includes Italy and Indonesia in both language variants", () => {
    expect(homeSource).toContain('"🇮🇹 Italy"');
    expect(homeSource).toContain('"🇮🇩 Indonesia"');
    expect(homeSource).toContain('"🇮🇹 Italy"');
    expect(homeSource).toContain('"🇮🇩 ইন্দোনেশিয়া"');
  });

  it("keeps the existing primary visitor countries", () => {
    expect(homeSource).toContain('"🇧🇩 Bangladesh"');
    expect(homeSource).toContain('"🇸🇦 Saudi Arabia"');
    expect(homeSource).toContain('"🇧🇩 বাংলাদেশ"');
    expect(homeSource).toContain('"🇸🇦 সৌদি আরব"');
  });
});
