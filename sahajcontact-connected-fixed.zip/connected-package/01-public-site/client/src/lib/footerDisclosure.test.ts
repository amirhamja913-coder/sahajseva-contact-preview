import { describe, expect, it } from "vitest";
import { FOOTER_NAV_SECTIONS } from "@/components/SahajFooter";

describe("footer partner disclosure", () => {
  it("does not display named commercial providers or imply a commercial partner listing", () => {
    const serializedNavigation = JSON.stringify(FOOTER_NAV_SECTIONS);
    for (const namedProvider of ["Star Tech", "Ryans", "Daraz"]) {
      expect(serializedNavigation).not.toContain(namedProvider);
    }
    expect(serializedNavigation).toContain("/advertise");
    expect(serializedNavigation).toContain("/sponsor");
  });
});
