import { describe, expect, it } from "vitest";
import { FOOTER_LEGAL_LINKS } from "@/components/SahajFooter";

describe("footer legal destinations", () => {
  it("uses the detailed Bengali legal and security pages", () => {
    expect(FOOTER_LEGAL_LINKS).toEqual([
      { label: "প্রাইভেসি নীতি", labelEn: "Privacy Policy", href: "/privacy-policy" },
      { label: "শর্তাবলী", labelEn: "Terms & Safety", href: "/terms" },
      { label: "নিরাপত্তা পরামর্শ", labelEn: "Security Advice", href: "/security-policy" },
      { label: "অভিযোগ জানান", labelEn: "Submit a Complaint", href: "/complaint" },
    ]);
  });

  it("does not point legal links at the old placeholder routes", () => {
    const hrefs = FOOTER_LEGAL_LINKS.map((link) => link.href);
    expect(hrefs).not.toContain("/security-advice");
    expect(hrefs).not.toContain("/privacy-notice");
  });
});
