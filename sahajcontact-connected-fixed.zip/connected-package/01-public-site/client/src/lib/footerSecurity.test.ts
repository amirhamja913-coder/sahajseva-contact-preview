import { describe, it, expect } from "vitest";
import {
  FOOTER_SECURITY_LABEL,
  FOOTER_SSL_LABEL,
  FOOTER_LEGAL_LINKS,
  FOOTER_NAV_SECTIONS,
  FOOTER_ADMIN_ENTRY,
} from "@/components/SahajFooter";

describe("footer security and contact messaging", () => {
  it("includes the requested security and information labels", () => {
    expect(FOOTER_SSL_LABEL).toContain("SSL সিকিউর");
    expect(FOOTER_SECURITY_LABEL).toContain("OTP");
  });

  it("includes the requested legal links in the 'others' column", () => {
    const hrefs = FOOTER_LEGAL_LINKS.map((l) => l.href);
    expect(hrefs).toContain("/privacy-policy");
    expect(hrefs).toContain("/terms");
    expect(hrefs).toContain("/security-policy");
    expect(hrefs).toContain("/complaint");
  });

  it("routes help and business enquiries to the portal without a personal messaging CTA", () => {
    const serviceLinks = FOOTER_NAV_SECTIONS.find((section) => section.title === "সেবা")?.links ?? [];
    const businessLinks = FOOTER_NAV_SECTIONS.find((section) => section.title === "ব্যবসা")?.links ?? [];
    expect(serviceLinks.map((link) => link.href)).toContain("/contact");
    expect(businessLinks.map((link) => link.href)).toEqual(expect.arrayContaining(["/advertise", "/sponsor", "/ngo-partnership"]));
    expect(JSON.stringify(FOOTER_NAV_SECTIONS)).not.toContain("wa.me");
  });

  it("keeps the owner Admin entry discreet and protected by the existing route boundary", () => {
    expect(FOOTER_ADMIN_ENTRY.href).toBe("/admin/dashboard");
    expect(FOOTER_ADMIN_ENTRY.label).toContain("Admin Dashboard");
    expect(FOOTER_ADMIN_ENTRY.labelEn).toContain("Owner Admin Dashboard");
    expect(FOOTER_ADMIN_ENTRY.href).not.toContain("oauth");
    expect(FOOTER_ADMIN_ENTRY.href).not.toContain("password");
  });
});
