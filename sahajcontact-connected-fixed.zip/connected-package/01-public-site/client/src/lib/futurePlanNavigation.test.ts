import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const appSource = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
const headerSource = readFileSync(new URL("../components/SahajHeader.tsx", import.meta.url), "utf8");
const infoPageSource = readFileSync(new URL("../pages/FooterInfoPage.tsx", import.meta.url), "utf8");
const futurePlanMenuLabel = "নারী ও শিশু এবং সাধারণ মানুষের পরবর্তী পরিকল্পনা";
const futurePlanPageTitle = "নারী, শিশু, কৃষক ও সাধারণ মানুষের জন্য আমাদের পরবর্তী পরিকল্পনা";

describe("future plan navigation", () => {
  it("registers the future-plan route immediately before security policy", () => {
    expect(appSource).toContain('<Route path="/future-plan" component={() => <FooterInfoPage pageKey="future-plan" />} />');
    expect(appSource.indexOf('path="/future-plan"')).toBeLessThan(appSource.indexOf('path="/security-policy"'));
  });

  it("keeps future-plan available through the shared owner-managed desktop and mobile menu", () => {
    expect(headerSource).toContain('"/future-plan"');
    expect(headerSource).toContain(futurePlanMenuLabel);
    expect(headerSource.indexOf('"/future-plan"')).toBeGreaterThan(headerSource.indexOf('"/funding-guidance"'));
    expect(headerSource.indexOf('"/future-plan"')).toBeLessThan(headerSource.indexOf('"/security-policy"'));
    expect(headerSource).toContain("navigation.map");
  });

  it("provides the women, children, farmers, and public rights destination content", () => {
    expect(infoPageSource).toContain('"future-plan"');
    expect(infoPageSource).toContain(futurePlanPageTitle);
  });
});
