import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const homeSource = readFileSync(new URL("../pages/Home.tsx", import.meta.url), "utf8");
const utilitySource = readFileSync(new URL("../components/UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");

describe("homepage official service guidance", () => {
  it("renders an active, read-only guidance section rather than a public assistance-order folder", () => {
    expect(homeSource).toContain('id="service-guidance"');
    expect(homeSource).toContain('aria-labelledby="service-guidance-heading"');
    expect(homeSource).toContain("অফিসিয়াল পথে সেবা নিন");
    expect(homeSource).not.toContain('data-service-folder="paid-assistance"');
    expect(homeSource).not.toContain('className="paid-assistance-folder"');
  });

  it("keeps service guidance free of public orders, fees, payment collection, and personal contact escalation", () => {
    expect(homeSource).toContain("কোনো আবেদন, অর্ডার, payment, receipt বা ব্যক্তিগত তথ্য এই পোর্টালে নেওয়া হয় না");
    expect(homeSource).toContain("কোনো লেনদেন এই সাইটে হয় না");
    expect(homeSource).toContain("OTP, PIN, পাসওয়ার্ড, NID, payment number বা transaction ID এখানে দেবেন না");

    for (const unsafeMarker of [
      "DISCUSSION_BASED_FEE",
      "getServiceWhatsAppUrl",
      "PAID_ASSISTANCE_TEL_URL",
      "whatsapp_order_click",
      "paid-service-inline-whatsapp",
      "paid-service-inline-call",
      "price: \"৳",
    ]) {
      expect(homeSource).not.toContain(unsafeMarker);
    }
  });
});

describe("Bangladesh still-images folder", () => {
	it("renders as a closed-by-default details folder containing the restored heritage gallery", () => {
	  expect(homeSource).toContain('className="details-folder still-images-folder"');
	  expect(homeSource).toContain('data-section-folder="bangladesh-still-images"');
	  expect(homeSource).toContain("<summary");
	  expect(homeSource).not.toContain('<details open data-section-folder="bangladesh-still-images"');
	  expect(homeSource).toContain("বাংলাদেশের কিছু স্থিরচিত্র");
	  expect(homeSource).toContain('import { BangladeshGallery }');
	  expect(homeSource).toContain('<BangladeshGallery language={language} />');
	});
});

describe("expatriate card placement", () => {
  it("keeps the travel and expatriate welfare card inside the dedicated expatriate section", () => {
    expect(homeSource).not.toContain('title: "বিদেশযাত্রা ও প্রবাসী কল্যাণ"');
    expect(utilitySource).toContain('data-utility-folder="probashi-services"');
    expect(utilitySource).toContain("বিদেশযাত্রা ও প্রবাসী কল্যাণ");
    expect(utilitySource).toContain('href: "https://probashi.gov.bd/"');
  });
});

describe("homepage emergency-contact folder", () => {
  it("renders as a closed-by-default details folder", () => {
    expect(homeSource).toContain('className="emergency-folder"');
    expect(homeSource).toContain("জরুরী সময় দ্রুত যোগাযোগ করুন");
    expect(homeSource).toContain('data-service-folder="emergency-contacts"');
  });

  it("retains the existing emergency numbers inside the folder", () => {
    for (const emergencyNumber of ["999", "102", "333", "16263"]) {
      expect(homeSource).toContain(emergencyNumber);
    }
  });
});
