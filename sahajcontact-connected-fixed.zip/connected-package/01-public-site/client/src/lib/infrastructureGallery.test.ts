import { describe, expect, it } from "vitest";
import { BANGLADESH_GALLERY_ITEMS } from "../data/bangladeshGallery";

const developmentIds = [
  "dev-padma-bridge",
  "dev-jamuna-bridge",
  "dev-bhairab-bridge",
  "dev-hardinge-bridge",
  "dev-bibiyana-gas-field",
  "dev-chattogram-port",
  "dev-shahjalal-airport",
] as const;

describe("Bangladesh Development infrastructure gallery", () => {
  it("includes the requested infrastructure subjects in the Development category", () => {
    const developmentItems = BANGLADESH_GALLERY_ITEMS.filter(
      item => item.category === "development",
    );
    const developmentIdsInData = developmentItems.map(item => item.id);

    for (const id of developmentIds) {
      expect(developmentIdsInData).toContain(id);
    }
  });

  it("uses persistent local image paths and bilingual metadata for each infrastructure card", () => {
    for (const id of developmentIds) {
      const item = BANGLADESH_GALLERY_ITEMS.find(candidate => candidate.id === id);
      expect(item).toBeDefined();
      expect(item?.imageUrl).toMatch(/^\/manus-storage\//);
      expect(item?.titleBn.length).toBeGreaterThan(0);
      expect(item?.titleEn.length).toBeGreaterThan(0);
      expect(item?.captionBn.length).toBeGreaterThan(0);
      expect(item?.captionEn.length).toBeGreaterThan(0);
      expect(item?.creditUrl).toContain("commons.wikimedia.org");
    }
  });

  it("includes the indigenous hill-tract development theme with attribution", () => {
    const hillDevelopment = BANGLADESH_GALLERY_ITEMS.find(
      item => item.id === "dev-hill-tract-community-development",
    );
    expect(hillDevelopment?.titleBn).toBe("পাহাড়ি জনগোষ্ঠীর উন্নয়ন");
    expect(hillDevelopment?.imageUrl).toBe("/manus-storage/hill-tract-indigenous-schoolgirls_564e9d0c.webp");
    expect(hillDevelopment?.creditUrl).toContain("Adivasi_(Indigenous)_Schoolgirls");
    expect(hillDevelopment?.category).toBe("development");
  });

  it("includes the Bangladesh National Museum replacement with attribution", () => {
    const museum = BANGLADESH_GALLERY_ITEMS.find(
      item => item.id === "culture-national-museum",
    );
    expect(museum?.titleBn).toBe("বাংলাদেশ জাতীয় জাদুঘর");
    expect(museum?.titleEn).toBe("Bangladesh National Museum");
    expect(museum?.imageUrl).toBe("/manus-storage/bangladesh-national-museum_84610abf.webp");
    expect(museum?.creditUrl).toContain("DG_91_-_09_NATIONAL_MUSEUM_DHAKA_IMG_3171");
    expect(museum?.category).toBe("culture");
  });

  it("repairs the previously broken Padma Bridge image with the uploaded asset", () => {
    const padmaBridge = BANGLADESH_GALLERY_ITEMS.find(
      item => item.id === "dev-padma-bridge",
    );
    expect(padmaBridge?.imageUrl).toBe("/manus-storage/padma-bridge_60d5bee2.webp");
  });
});
