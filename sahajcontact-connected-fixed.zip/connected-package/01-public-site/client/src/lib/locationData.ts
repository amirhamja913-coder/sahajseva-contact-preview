export interface Upazila {
  id: string;
  name: string;
  bn_name: string;
}

export interface District {
  id: string;
  name: string;
  bn_name: string;
  upazilas: Upazila[];
}

export interface Division {
  id: string;
  name: string;
  bn_name: string;
  districts: District[];
}

/** Full Bangladesh administrative directory sourced from @bangladeshi/bangladesh-address.
 * English spellings are retained as a fallback where a Bengali label is not present in the local map.
 */
export const divisionsData: Division[] = [
  {
    id: "1",
    name: "Barisal",
    bn_name: "Barisal",
    districts: [
      {
        id: "1",
        name: "Barguna",
        bn_name: "Barguna",
        upazilas: [
          { id: "1", name: "Amtali", bn_name: "Amtali" },
          { id: "2", name: "Bamna", bn_name: "Bamna" },
          { id: "3", name: "Barguna Sadar", bn_name: "Barguna Sadar" },
          { id: "4", name: "Betagi", bn_name: "Betagi" },
          { id: "5", name: "Patharghata", bn_name: "Patharghata" },
          { id: "6", name: "Taltali", bn_name: "Taltali" }
        ]
      },
      {
        id: "2",
        name: "Barisal",
        bn_name: "Barisal",
        upazilas: [
          { id: "7", name: "Muladi", bn_name: "Muladi" },
          { id: "8", name: "Babuganj", bn_name: "বাবুগঞ্জ" },
          { id: "9", name: "Agailjhara", bn_name: "Agailjhara" },
          { id: "10", name: "Barisal Sadar", bn_name: "Barisal Sadar" },
          { id: "11", name: "Bakerganj", bn_name: "Bakerganj" },
          { id: "12", name: "Banaripara", bn_name: "Banaripara" },
          { id: "13", name: "Gaurnadi", bn_name: "Gaurnadi" },
          { id: "14", name: "Hizla", bn_name: "Hizla" },
          { id: "15", name: "Mehendiganj", bn_name: "Mehendiganj" },
          { id: "16", name: "Wazirpur", bn_name: "উজিরপুর" }
        ]
      },
      {
        id: "3",
        name: "Bhola",
        bn_name: "Bhola",
        upazilas: [
          { id: "17", name: "Bhola Sadar", bn_name: "Bhola Sadar" },
          { id: "18", name: "Burhanuddin", bn_name: "Burhanuddin" },
          { id: "19", name: "Char Fasson", bn_name: "Char Fasson" },
          { id: "20", name: "Daulatkhan", bn_name: "Daulatkhan" },
          { id: "21", name: "Lalmohan", bn_name: "Lalmohan" },
          { id: "22", name: "Manpura", bn_name: "Manpura" },
          { id: "23", name: "Tazumuddin", bn_name: "Tazumuddin" }
        ]
      },
      {
        id: "4",
        name: "Jhalokati",
        bn_name: "Jhalokati",
        upazilas: [
          { id: "24", name: "Jhalokati Sadar", bn_name: "Jhalokati Sadar" },
          { id: "25", name: "Kathalia", bn_name: "Kathalia" },
          { id: "26", name: "Nalchity", bn_name: "Nalchity" },
          { id: "27", name: "Rajapur", bn_name: "Rajapur" }
        ]
      },
      {
        id: "5",
        name: "Patuakhali",
        bn_name: "Patuakhali",
        upazilas: [
          { id: "28", name: "Bauphal", bn_name: "Bauphal" },
          { id: "29", name: "Dashmina", bn_name: "Dashmina" },
          { id: "30", name: "Galachipa", bn_name: "Galachipa" },
          { id: "31", name: "Kalapara", bn_name: "Kalapara" },
          { id: "32", name: "Mirzaganj", bn_name: "Mirzaganj" },
          { id: "33", name: "Patuakhali Sadar", bn_name: "Patuakhali Sadar" },
          { id: "34", name: "Dumki", bn_name: "Dumki" },
          { id: "35", name: "Rangabali", bn_name: "Rangabali" }
        ]
      },
      {
        id: "6",
        name: "Pirojpur",
        bn_name: "Pirojpur",
        upazilas: [
          { id: "36", name: "Bhandaria", bn_name: "Bhandaria" },
          { id: "37", name: "Kaukhali", bn_name: "Kaukhali" },
          { id: "38", name: "Mathbaria", bn_name: "Mathbaria" },
          { id: "39", name: "Nazirpur", bn_name: "Nazirpur" },
          { id: "40", name: "Nesarabad", bn_name: "Nesarabad" },
          { id: "41", name: "Pirojpur Sadar", bn_name: "Pirojpur Sadar" },
          { id: "42", name: "Zianagar", bn_name: "Zianagar" }
        ]
      }
    ]
  },
  {
    id: "2",
    name: "Chattogram",
    bn_name: "Chattogram",
    districts: [
      {
        id: "7",
        name: "Bandarban",
        bn_name: "Bandarban",
        upazilas: [
          { id: "43", name: "Bandarban Sadar", bn_name: "Bandarban Sadar" },
          { id: "44", name: "Thanchi", bn_name: "Thanchi" },
          { id: "45", name: "Lama", bn_name: "Lama" },
          { id: "46", name: "Naikhongchhari", bn_name: "Naikhongchhari" },
          { id: "47", name: "Ali kadam", bn_name: "Ali kadam" },
          { id: "48", name: "Rowangchhari", bn_name: "Rowangchhari" },
          { id: "49", name: "Ruma", bn_name: "Ruma" }
        ]
      },
      {
        id: "8",
        name: "Brahmanbaria",
        bn_name: "Brahmanbaria",
        upazilas: [
          { id: "50", name: "Brahmanbaria Sadar", bn_name: "Brahmanbaria Sadar" },
          { id: "51", name: "Ashuganj", bn_name: "Ashuganj" },
          { id: "52", name: "Nasirnagar", bn_name: "Nasirnagar" },
          { id: "53", name: "Nabinagar", bn_name: "Nabinagar" },
          { id: "54", name: "Sarail", bn_name: "Sarail" },
          { id: "55", name: "Shahbazpur Town", bn_name: "Shahbazpur Town" },
          { id: "56", name: "Kasba", bn_name: "Kasba" },
          { id: "57", name: "Akhaura", bn_name: "Akhaura" },
          { id: "58", name: "Bancharampur", bn_name: "Bancharampur" },
          { id: "59", name: "Bijoynagar", bn_name: "Bijoynagar" }
        ]
      },
      {
        id: "9",
        name: "Chandpur",
        bn_name: "Chandpur",
        upazilas: [
          { id: "60", name: "Chandpur Sadar", bn_name: "Chandpur Sadar" },
          { id: "61", name: "Faridganj", bn_name: "Faridganj" },
          { id: "62", name: "Haimchar", bn_name: "Haimchar" },
          { id: "63", name: "Haziganj", bn_name: "Haziganj" },
          { id: "64", name: "Kachua", bn_name: "Kachua" },
          { id: "65", name: "Matlab Uttar", bn_name: "Matlab Uttar" },
          { id: "66", name: "Matlab Dakkhin", bn_name: "Matlab Dakkhin" },
          { id: "67", name: "Shahrasti", bn_name: "Shahrasti" }
        ]
      },
      {
        id: "10",
        name: "Chattogram",
        bn_name: "Chattogram",
        upazilas: [
          { id: "68", name: "Anwara", bn_name: "আনোয়ারা" },
          { id: "69", name: "Banshkhali", bn_name: "Banshkhali" },
          { id: "70", name: "Boalkhali", bn_name: "বোয়ালখালী" },
          { id: "71", name: "Chandanaish", bn_name: "চন্দনাইশ" },
          { id: "72", name: "Fatikchhari", bn_name: "Fatikchhari" },
          { id: "73", name: "Hathazari", bn_name: "Hathazari" },
          { id: "74", name: "Lohagara", bn_name: "Lohagara" },
          { id: "75", name: "Mirsharai", bn_name: "Mirsharai" },
          { id: "76", name: "Patiya", bn_name: "পটিয়া" },
          { id: "77", name: "Rangunia", bn_name: "Rangunia" },
          { id: "78", name: "Raozan", bn_name: "Raozan" },
          { id: "79", name: "Sandwip", bn_name: "Sandwip" },
          { id: "80", name: "Satkania", bn_name: "সাতকানিয়া" },
          { id: "81", name: "Sitakunda", bn_name: "Sitakunda" }
        ]
      },
      {
        id: "11",
        name: "Comilla",
        bn_name: "Comilla",
        upazilas: [
          { id: "82", name: "Barura", bn_name: "Barura" },
          { id: "83", name: "Brahmanpara", bn_name: "Brahmanpara" },
          { id: "84", name: "Burichong", bn_name: "Burichong" },
          { id: "85", name: "Chandina", bn_name: "Chandina" },
          { id: "86", name: "Chauddagram", bn_name: "Chauddagram" },
          { id: "87", name: "Daudkandi", bn_name: "Daudkandi" },
          { id: "88", name: "Debidwar", bn_name: "Debidwar" },
          { id: "89", name: "Homna", bn_name: "Homna" },
          { id: "90", name: "Comilla Sadar", bn_name: "Comilla Sadar" },
          { id: "91", name: "Laksam", bn_name: "Laksam" },
          { id: "92", name: "Monohorgonj", bn_name: "Monohorgonj" },
          { id: "93", name: "Meghna", bn_name: "Meghna" },
          { id: "94", name: "Muradnagar", bn_name: "Muradnagar" },
          { id: "95", name: "Nangalkot", bn_name: "Nangalkot" },
          { id: "96", name: "Comilla Sadar South", bn_name: "Comilla Sadar South" },
          { id: "97", name: "Titas", bn_name: "Titas" }
        ]
      },
      {
        id: "12",
        name: "Cox's Bazar",
        bn_name: "Cox's Bazar",
        upazilas: [
          { id: "98", name: "Chakaria", bn_name: "চকরিয়া" },
          { id: "99", name: "Cox's Bazar Sadar", bn_name: "কক্সবাজার সদর" },
          { id: "100", name: "Kutubdia", bn_name: "কুতুবদিয়া" },
          { id: "101", name: "Maheshkhali", bn_name: "Maheshkhali" },
          { id: "102", name: "Ramu", bn_name: "Ramu" },
          { id: "103", name: "Teknaf", bn_name: "টেকনাফ" },
          { id: "104", name: "Ukhia", bn_name: "উখিয়া" },
          { id: "105", name: "Pekua", bn_name: "Pekua" },
          { id: "106", name: "Eidgaon", bn_name: "Eidgaon" }
        ]
      },
      {
        id: "13",
        name: "Feni",
        bn_name: "Feni",
        upazilas: [
          { id: "107", name: "Feni Sadar", bn_name: "Feni Sadar" },
          { id: "108", name: "Chagalnaiya", bn_name: "Chagalnaiya" },
          { id: "109", name: "Daganbhyan", bn_name: "Daganbhyan" },
          { id: "110", name: "Parshuram", bn_name: "Parshuram" },
          { id: "111", name: "Fhulgazi", bn_name: "Fhulgazi" },
          { id: "112", name: "Sonagazi", bn_name: "Sonagazi" }
        ]
      },
      {
        id: "14",
        name: "Khagrachari",
        bn_name: "Khagrachari",
        upazilas: [
          { id: "113", name: "Dighinala", bn_name: "Dighinala" },
          { id: "114", name: "Khagrachhari", bn_name: "Khagrachhari" },
          { id: "115", name: "Lakshmichhari", bn_name: "Lakshmichhari" },
          { id: "116", name: "Mahalchhari", bn_name: "Mahalchhari" },
          { id: "117", name: "Manikchhari", bn_name: "Manikchhari" },
          { id: "118", name: "Matiranga", bn_name: "Matiranga" },
          { id: "119", name: "Panchhari", bn_name: "Panchhari" },
          { id: "120", name: "Ramgarh", bn_name: "Ramgarh" }
        ]
      },
      {
        id: "15",
        name: "Lakshmipur",
        bn_name: "Lakshmipur",
        upazilas: [
          { id: "121", name: "Lakshmipur Sadar", bn_name: "Lakshmipur Sadar" },
          { id: "122", name: "Raipur", bn_name: "Raipur" },
          { id: "123", name: "Ramganj", bn_name: "Ramganj" },
          { id: "124", name: "Ramgati", bn_name: "Ramgati" },
          { id: "125", name: "Komol Nagar", bn_name: "Komol Nagar" }
        ]
      },
      {
        id: "16",
        name: "Noakhali",
        bn_name: "Noakhali",
        upazilas: [
          { id: "126", name: "Noakhali Sadar", bn_name: "Noakhali Sadar" },
          { id: "127", name: "Begumganj", bn_name: "Begumganj" },
          { id: "128", name: "Chatkhil", bn_name: "Chatkhil" },
          { id: "129", name: "Companyganj", bn_name: "Companyganj" },
          { id: "130", name: "Shenbag", bn_name: "Shenbag" },
          { id: "131", name: "Hatia", bn_name: "Hatia" },
          { id: "132", name: "Kobirhat", bn_name: "Kobirhat" },
          { id: "133", name: "Sonaimuri", bn_name: "Sonaimuri" },
          { id: "134", name: "Suborno Char", bn_name: "Suborno Char" }
        ]
      },
      {
        id: "17",
        name: "Rangamati",
        bn_name: "Rangamati",
        upazilas: [
          { id: "135", name: "Rangamati Sadar", bn_name: "Rangamati Sadar" },
          { id: "136", name: "Belaichhari", bn_name: "Belaichhari" },
          { id: "137", name: "Bagaichhari", bn_name: "Bagaichhari" },
          { id: "138", name: "Barkal", bn_name: "Barkal" },
          { id: "139", name: "Juraichhari", bn_name: "Juraichhari" },
          { id: "140", name: "Rajasthali", bn_name: "Rajasthali" },
          { id: "141", name: "Kaptai", bn_name: "Kaptai" },
          { id: "142", name: "Langadu", bn_name: "Langadu" },
          { id: "143", name: "Nannerchar", bn_name: "Nannerchar" },
          { id: "144", name: "Kaukhali", bn_name: "Kaukhali" }
        ]
      }
    ]
  },
  {
    id: "3",
    name: "Dhaka",
    bn_name: "Dhaka",
    districts: [
      {
        id: "18",
        name: "Dhaka",
        bn_name: "Dhaka",
        upazilas: [
          { id: "145", name: "Dhamrai", bn_name: "ধামরাই" },
          { id: "146", name: "Dohar", bn_name: "দোহার" },
          { id: "147", name: "Keraniganj", bn_name: "কেরানীগঞ্জ" },
          { id: "148", name: "Nawabganj", bn_name: "নবাবগঞ্জ" },
          { id: "149", name: "Savar", bn_name: "সাভার" }
        ]
      },
      {
        id: "19",
        name: "Faridpur",
        bn_name: "Faridpur",
        upazilas: [
          { id: "150", name: "Faridpur Sadar", bn_name: "Faridpur Sadar" },
          { id: "151", name: "Boalmari", bn_name: "Boalmari" },
          { id: "152", name: "Alfadanga", bn_name: "Alfadanga" },
          { id: "153", name: "Madhukhali", bn_name: "Madhukhali" },
          { id: "154", name: "Bhanga", bn_name: "Bhanga" },
          { id: "155", name: "Nagarkanda", bn_name: "Nagarkanda" },
          { id: "156", name: "Charbhadrasan", bn_name: "Charbhadrasan" },
          { id: "157", name: "Sadarpur", bn_name: "Sadarpur" },
          { id: "158", name: "Shaltha", bn_name: "Shaltha" }
        ]
      },
      {
        id: "20",
        name: "Gazipur",
        bn_name: "Gazipur",
        upazilas: [
          { id: "159", name: "Gazipur Sadar-Joydebpur", bn_name: "Gazipur Sadar-Joydebpur" },
          { id: "160", name: "Kaliakior", bn_name: "Kaliakior" },
          { id: "161", name: "Kapasia", bn_name: "কাপাসিয়া" },
          { id: "162", name: "Sripur", bn_name: "Sripur" },
          { id: "163", name: "Kaliganj", bn_name: "কালীগঞ্জ" },
          { id: "164", name: "Tongi", bn_name: "Tongi" }
        ]
      },
      {
        id: "21",
        name: "Gopalganj",
        bn_name: "Gopalganj",
        upazilas: [
          { id: "165", name: "Gopalganj Sadar", bn_name: "Gopalganj Sadar" },
          { id: "166", name: "Kashiani", bn_name: "Kashiani" },
          { id: "167", name: "Kotalipara", bn_name: "Kotalipara" },
          { id: "168", name: "Muksudpur", bn_name: "Muksudpur" },
          { id: "169", name: "Tungipara", bn_name: "Tungipara" }
        ]
      },
      {
        id: "22",
        name: "Kishoreganj",
        bn_name: "Kishoreganj",
        upazilas: [
          { id: "170", name: "Astagram", bn_name: "Astagram" },
          { id: "171", name: "Bajitpur", bn_name: "Bajitpur" },
          { id: "172", name: "Bhairab", bn_name: "Bhairab" },
          { id: "173", name: "Hossainpur", bn_name: "Hossainpur" },
          { id: "174", name: "Itna", bn_name: "Itna" },
          { id: "175", name: "Karimganj", bn_name: "Karimganj" },
          { id: "176", name: "Katiadi", bn_name: "Katiadi" },
          { id: "177", name: "Kishoreganj Sadar", bn_name: "Kishoreganj Sadar" },
          { id: "178", name: "Kuliarchar", bn_name: "Kuliarchar" },
          { id: "179", name: "Mithamain", bn_name: "Mithamain" },
          { id: "180", name: "Nikli", bn_name: "Nikli" },
          { id: "181", name: "Pakundia", bn_name: "Pakundia" },
          { id: "182", name: "Tarail", bn_name: "Tarail" }
        ]
      },
      {
        id: "23",
        name: "Madaripur",
        bn_name: "Madaripur",
        upazilas: [
          { id: "183", name: "Madaripur Sadar", bn_name: "Madaripur Sadar" },
          { id: "184", name: "Kalkini", bn_name: "Kalkini" },
          { id: "185", name: "Rajoir", bn_name: "Rajoir" },
          { id: "186", name: "Shibchar", bn_name: "Shibchar" },
          { id: "187", name: "Dasar", bn_name: "Dasar" }
        ]
      },
      {
        id: "24",
        name: "Manikganj",
        bn_name: "Manikganj",
        upazilas: [
          { id: "188", name: "Manikganj Sadar", bn_name: "Manikganj Sadar" },
          { id: "189", name: "Singair", bn_name: "Singair" },
          { id: "190", name: "Shibalaya", bn_name: "Shibalaya" },
          { id: "191", name: "Saturia", bn_name: "Saturia" },
          { id: "192", name: "Harirampur", bn_name: "Harirampur" },
          { id: "193", name: "Ghior", bn_name: "Ghior" },
          { id: "194", name: "Daulatpur", bn_name: "Daulatpur" }
        ]
      },
      {
        id: "25",
        name: "Munshiganj",
        bn_name: "Munshiganj",
        upazilas: [
          { id: "195", name: "Lohajang", bn_name: "Lohajang" },
          { id: "196", name: "Sreenagar", bn_name: "Sreenagar" },
          { id: "197", name: "Munshiganj Sadar", bn_name: "Munshiganj Sadar" },
          { id: "198", name: "Sirajdikhan", bn_name: "Sirajdikhan" },
          { id: "199", name: "Tongibari", bn_name: "Tongibari" },
          { id: "200", name: "Gazaria", bn_name: "Gazaria" }
        ]
      },
      {
        id: "26",
        name: "Narayanganj",
        bn_name: "Narayanganj",
        upazilas: [
          { id: "201", name: "Araihazar", bn_name: "আড়াইহাজার" },
          { id: "202", name: "Sonargaon", bn_name: "সোনারগাঁও" },
          { id: "203", name: "Bandar", bn_name: "বন্দর" },
          { id: "204", name: "Naryanganj Sadar", bn_name: "Naryanganj Sadar" },
          { id: "205", name: "Rupganj", bn_name: "রূপগঞ্জ" },
          { id: "206", name: "Siddirgonj", bn_name: "Siddirgonj" }
        ]
      },
      {
        id: "27",
        name: "Narsingdi",
        bn_name: "Narsingdi",
        upazilas: [
          { id: "207", name: "Belabo", bn_name: "Belabo" },
          { id: "208", name: "Monohardi", bn_name: "Monohardi" },
          { id: "209", name: "Narsingdi Sadar", bn_name: "Narsingdi Sadar" },
          { id: "210", name: "Palash", bn_name: "Palash" },
          { id: "211", name: "Raipura", bn_name: "Raipura" },
          { id: "212", name: "Shibpur", bn_name: "Shibpur" }
        ]
      },
      {
        id: "28",
        name: "Rajbari",
        bn_name: "Rajbari",
        upazilas: [
          { id: "213", name: "Baliakandi", bn_name: "Baliakandi" },
          { id: "214", name: "Goalandaghat", bn_name: "Goalandaghat" },
          { id: "215", name: "Pangsha", bn_name: "Pangsha" },
          { id: "216", name: "Kalukhali", bn_name: "Kalukhali" },
          { id: "217", name: "Rajbari Sadar", bn_name: "Rajbari Sadar" }
        ]
      },
      {
        id: "29",
        name: "Shariatpur",
        bn_name: "Shariatpur",
        upazilas: [
          { id: "218", name: "Shariatpur Sadar", bn_name: "Shariatpur Sadar" },
          { id: "219", name: "Damudya", bn_name: "Damudya" },
          { id: "220", name: "Naria", bn_name: "Naria" },
          { id: "221", name: "Jajira", bn_name: "Jajira" },
          { id: "222", name: "Bhedarganj", bn_name: "Bhedarganj" },
          { id: "223", name: "Gosairhat", bn_name: "Gosairhat" }
        ]
      },
      {
        id: "30",
        name: "Tangail",
        bn_name: "Tangail",
        upazilas: [
          { id: "224", name: "Tangail Sadar", bn_name: "টাঙ্গাইল সদর" },
          { id: "225", name: "Sakhipur", bn_name: "সখিপুর" },
          { id: "226", name: "Basail", bn_name: "বাসাইল" },
          { id: "227", name: "Madhupur", bn_name: "মধুপুর" },
          { id: "228", name: "Ghatail", bn_name: "ঘাটাইল" },
          { id: "229", name: "Kalihati", bn_name: "Kalihati" },
          { id: "230", name: "Nagarpur", bn_name: "Nagarpur" },
          { id: "231", name: "Mirzapur", bn_name: "Mirzapur" },
          { id: "232", name: "Gopalpur", bn_name: "Gopalpur" },
          { id: "233", name: "Delduar", bn_name: "Delduar" },
          { id: "234", name: "Bhuapur", bn_name: "Bhuapur" },
          { id: "235", name: "Dhanbari", bn_name: "Dhanbari" }
        ]
      }
    ]
  },
  {
    id: "4",
    name: "Mymensingh",
    bn_name: "Mymensingh",
    districts: [
      {
        id: "31",
        name: "Jamalpur",
        bn_name: "Jamalpur",
        upazilas: [
          { id: "236", name: "Dewanganj", bn_name: "Dewanganj" },
          { id: "237", name: "Baksiganj", bn_name: "Baksiganj" },
          { id: "238", name: "Islampur", bn_name: "Islampur" },
          { id: "239", name: "Jamalpur Sadar", bn_name: "Jamalpur Sadar" },
          { id: "240", name: "Madarganj", bn_name: "Madarganj" },
          { id: "241", name: "Melandaha", bn_name: "Melandaha" },
          { id: "242", name: "Sarishabari", bn_name: "Sarishabari" },
          { id: "243", name: "Narundi Police I.C", bn_name: "Narundi Police I.C" }
        ]
      },
      {
        id: "32",
        name: "Mymensingh",
        bn_name: "Mymensingh",
        upazilas: [
          { id: "244", name: "Bhaluka", bn_name: "Bhaluka" },
          { id: "245", name: "Trishal", bn_name: "ত্রিশাল" },
          { id: "246", name: "Haluaghat", bn_name: "Haluaghat" },
          { id: "247", name: "Muktagachha", bn_name: "মুক্তাগাছা" },
          { id: "248", name: "Dhobaura", bn_name: "Dhobaura" },
          { id: "249", name: "Fulbaria", bn_name: "Fulbaria" },
          { id: "250", name: "Gaffargaon", bn_name: "Gaffargaon" },
          { id: "251", name: "Gauripur", bn_name: "Gauripur" },
          { id: "252", name: "Ishwarganj", bn_name: "Ishwarganj" },
          { id: "253", name: "Mymensingh Sadar", bn_name: "ময়মনসিংহ সদর" },
          { id: "254", name: "Nandail", bn_name: "Nandail" },
          { id: "255", name: "Phulpur", bn_name: "Phulpur" },
          { id: "256", name: "Tarakanda", bn_name: "Tarakanda" }
        ]
      },
      {
        id: "33",
        name: "Netrokona",
        bn_name: "Netrokona",
        upazilas: [
          { id: "257", name: "Kendua", bn_name: "Kendua" },
          { id: "258", name: "Atpara", bn_name: "Atpara" },
          { id: "259", name: "Barhatta", bn_name: "Barhatta" },
          { id: "260", name: "Durgapur", bn_name: "দুর্গাপুর" },
          { id: "261", name: "Kalmakanda", bn_name: "Kalmakanda" },
          { id: "262", name: "Madan", bn_name: "Madan" },
          { id: "263", name: "Mohanganj", bn_name: "Mohanganj" },
          { id: "264", name: "Netrokona Sadar", bn_name: "Netrokona Sadar" },
          { id: "265", name: "Purbadhala", bn_name: "Purbadhala" },
          { id: "266", name: "Khaliajuri", bn_name: "Khaliajuri" }
        ]
      },
      {
        id: "34",
        name: "Sherpur",
        bn_name: "Sherpur",
        upazilas: [
          { id: "267", name: "Jhenaigati", bn_name: "Jhenaigati" },
          { id: "268", name: "Nakla", bn_name: "Nakla" },
          { id: "269", name: "Nalitabari", bn_name: "Nalitabari" },
          { id: "270", name: "Sherpur Sadar", bn_name: "Sherpur Sadar" },
          { id: "271", name: "Sreebardi", bn_name: "Sreebardi" }
        ]
      }
    ]
  },
  {
    id: "5",
    name: "Khulna",
    bn_name: "Khulna",
    districts: [
      {
        id: "35",
        name: "Bagerhat",
        bn_name: "Bagerhat",
        upazilas: [
          { id: "272", name: "Bagerhat Sadar", bn_name: "Bagerhat Sadar" },
          { id: "273", name: "Chitalmari", bn_name: "Chitalmari" },
          { id: "274", name: "Fakirhat", bn_name: "Fakirhat" },
          { id: "275", name: "Kachua", bn_name: "Kachua" },
          { id: "276", name: "Mollahat", bn_name: "Mollahat" },
          { id: "277", name: "Mongla", bn_name: "Mongla" },
          { id: "278", name: "Morrelganj", bn_name: "Morrelganj" },
          { id: "279", name: "Rampal", bn_name: "Rampal" },
          { id: "280", name: "Sarankhola", bn_name: "Sarankhola" }
        ]
      },
      {
        id: "36",
        name: "Chuadanga",
        bn_name: "Chuadanga",
        upazilas: [
          { id: "281", name: "Damurhuda", bn_name: "Damurhuda" },
          { id: "282", name: "Chuadanga Sadar", bn_name: "Chuadanga Sadar" },
          { id: "283", name: "Jibannagar", bn_name: "Jibannagar" },
          { id: "284", name: "Alamdanga", bn_name: "Alamdanga" }
        ]
      },
      {
        id: "37",
        name: "Jessore",
        bn_name: "Jessore",
        upazilas: [
          { id: "285", name: "Abhaynagar", bn_name: "Abhaynagar" },
          { id: "286", name: "Keshabpur", bn_name: "Keshabpur" },
          { id: "287", name: "Bagherpara", bn_name: "Bagherpara" },
          { id: "288", name: "Jessore Sadar", bn_name: "Jessore Sadar" },
          { id: "289", name: "Chaugachha", bn_name: "Chaugachha" },
          { id: "290", name: "Manirampur", bn_name: "Manirampur" },
          { id: "291", name: "Jhikargachha", bn_name: "Jhikargachha" },
          { id: "292", name: "Sharsha", bn_name: "Sharsha" }
        ]
      },
      {
        id: "38",
        name: "Jhenaidah",
        bn_name: "Jhenaidah",
        upazilas: [
          { id: "293", name: "Jhenaidah Sadar", bn_name: "Jhenaidah Sadar" },
          { id: "294", name: "Maheshpur", bn_name: "Maheshpur" },
          { id: "295", name: "Kaliganj", bn_name: "কালীগঞ্জ" },
          { id: "296", name: "Kotchandpur", bn_name: "Kotchandpur" },
          { id: "297", name: "Shailkupa", bn_name: "Shailkupa" },
          { id: "298", name: "Harinakunda", bn_name: "Harinakunda" }
        ]
      },
      {
        id: "39",
        name: "Khulna",
        bn_name: "Khulna",
        upazilas: [
          { id: "299", name: "Terokhada", bn_name: "তেরখাদা" },
          { id: "300", name: "Batiaghata", bn_name: "বটিয়াঘাটা" },
          { id: "301", name: "Dacope", bn_name: "দাকোপ" },
          { id: "302", name: "Dumuria", bn_name: "ডুমুরিয়া" },
          { id: "303", name: "Dighalia", bn_name: "Dighalia" },
          { id: "304", name: "Koyra", bn_name: "Koyra" },
          { id: "305", name: "Paikgachha", bn_name: "Paikgachha" },
          { id: "306", name: "Phultala", bn_name: "Phultala" },
          { id: "307", name: "Rupsa", bn_name: "Rupsa" }
        ]
      },
      {
        id: "40",
        name: "Kushtia",
        bn_name: "Kushtia",
        upazilas: [
          { id: "308", name: "Kushtia Sadar", bn_name: "Kushtia Sadar" },
          { id: "309", name: "Kumarkhali", bn_name: "Kumarkhali" },
          { id: "310", name: "Daulatpur", bn_name: "Daulatpur" },
          { id: "311", name: "Mirpur", bn_name: "মিরপুর" },
          { id: "312", name: "Bheramara", bn_name: "Bheramara" },
          { id: "313", name: "Khoksa", bn_name: "Khoksa" }
        ]
      },
      {
        id: "41",
        name: "Magura",
        bn_name: "Magura",
        upazilas: [
          { id: "314", name: "Magura Sadar", bn_name: "Magura Sadar" },
          { id: "315", name: "Mohammadpur", bn_name: "Mohammadpur" },
          { id: "316", name: "Shalikha", bn_name: "Shalikha" },
          { id: "317", name: "Sreepur", bn_name: "শ্রীপুর" }
        ]
      },
      {
        id: "42",
        name: "Meherpur",
        bn_name: "Meherpur",
        upazilas: [
          { id: "318", name: "Gangni", bn_name: "Gangni" },
          { id: "319", name: "Mujibnagar", bn_name: "Mujibnagar" },
          { id: "320", name: "Meherpur Sadar", bn_name: "Meherpur Sadar" }
        ]
      },
      {
        id: "43",
        name: "Narail",
        bn_name: "Narail",
        upazilas: [
          { id: "321", name: "Narail Sadar", bn_name: "Narail Sadar" },
          { id: "322", name: "Lohagara", bn_name: "Lohagara" },
          { id: "323", name: "Kalia", bn_name: "Kalia" }
        ]
      },
      {
        id: "44",
        name: "Satkhira",
        bn_name: "Satkhira",
        upazilas: [
          { id: "324", name: "Satkhira Sadar", bn_name: "Satkhira Sadar" },
          { id: "325", name: "Assasuni", bn_name: "Assasuni" },
          { id: "326", name: "Debhata", bn_name: "Debhata" },
          { id: "327", name: "Tala", bn_name: "Tala" },
          { id: "328", name: "Kalaroa", bn_name: "Kalaroa" },
          { id: "329", name: "Kaliganj", bn_name: "কালীগঞ্জ" },
          { id: "330", name: "Shyamnagar", bn_name: "Shyamnagar" }
        ]
      }
    ]
  },
  {
    id: "6",
    name: "Rajshahi",
    bn_name: "Rajshahi",
    districts: [
      {
        id: "45",
        name: "Bogra",
        bn_name: "Bogra",
        upazilas: [
          { id: "331", name: "Adamdighi", bn_name: "Adamdighi" },
          { id: "332", name: "Bogra Sadar", bn_name: "Bogra Sadar" },
          { id: "333", name: "Sherpur", bn_name: "Sherpur" },
          { id: "334", name: "Dhunat", bn_name: "Dhunat" },
          { id: "335", name: "Dhupchanchia", bn_name: "Dhupchanchia" },
          { id: "336", name: "Gabtali", bn_name: "Gabtali" },
          { id: "337", name: "Kahaloo", bn_name: "Kahaloo" },
          { id: "338", name: "Nandigram", bn_name: "Nandigram" },
          { id: "339", name: "Sahajanpur", bn_name: "Sahajanpur" },
          { id: "340", name: "Sariakandi", bn_name: "Sariakandi" },
          { id: "341", name: "Shibganj", bn_name: "Shibganj" },
          { id: "342", name: "Sonatala", bn_name: "Sonatala" }
        ]
      },
      {
        id: "46",
        name: "Joypurhat",
        bn_name: "Joypurhat",
        upazilas: [
          { id: "343", name: "Joypurhat Sadar", bn_name: "Joypurhat Sadar" },
          { id: "344", name: "Akkelpur", bn_name: "Akkelpur" },
          { id: "345", name: "Kalai", bn_name: "Kalai" },
          { id: "346", name: "Khetlal", bn_name: "Khetlal" },
          { id: "347", name: "Panchbibi", bn_name: "Panchbibi" }
        ]
      },
      {
        id: "47",
        name: "Naogaon",
        bn_name: "Naogaon",
        upazilas: [
          { id: "348", name: "Naogaon Sadar", bn_name: "Naogaon Sadar" },
          { id: "349", name: "Mohadevpur", bn_name: "Mohadevpur" },
          { id: "350", name: "Manda", bn_name: "Manda" },
          { id: "351", name: "Niamatpur", bn_name: "Niamatpur" },
          { id: "352", name: "Atrai", bn_name: "Atrai" },
          { id: "353", name: "Raninagar", bn_name: "Raninagar" },
          { id: "354", name: "Patnitala", bn_name: "Patnitala" },
          { id: "355", name: "Dhamoirhat", bn_name: "Dhamoirhat" },
          { id: "356", name: "Sapahar", bn_name: "Sapahar" },
          { id: "357", name: "Porsha", bn_name: "Porsha" },
          { id: "358", name: "Badalgachhi", bn_name: "Badalgachhi" }
        ]
      },
      {
        id: "48",
        name: "Natore",
        bn_name: "Natore",
        upazilas: [
          { id: "359", name: "Natore Sadar", bn_name: "Natore Sadar" },
          { id: "360", name: "Baraigram", bn_name: "Baraigram" },
          { id: "361", name: "Bagatipara", bn_name: "Bagatipara" },
          { id: "362", name: "Lalpur", bn_name: "Lalpur" },
          { id: "363", name: "Gurudaspur", bn_name: "Gurudaspur" },
          { id: "364", name: "Singra", bn_name: "Singra" }
        ]
      },
      {
        id: "49",
        name: "Chapainawabganj",
        bn_name: "Chapainawabganj",
        upazilas: [
          { id: "365", name: "Bholahat", bn_name: "Bholahat" },
          { id: "366", name: "Gomastapur", bn_name: "Gomastapur" },
          { id: "367", name: "Nachole", bn_name: "Nachole" },
          { id: "368", name: "Chapainawabganj Sadar", bn_name: "Chapainawabganj Sadar" },
          { id: "369", name: "Shibganj", bn_name: "Shibganj" }
        ]
      },
      {
        id: "50",
        name: "Pabna",
        bn_name: "Pabna",
        upazilas: [
          { id: "370", name: "Atgharia", bn_name: "Atgharia" },
          { id: "371", name: "Bera", bn_name: "Bera" },
          { id: "372", name: "Bhangura", bn_name: "Bhangura" },
          { id: "373", name: "Chatmohar", bn_name: "Chatmohar" },
          { id: "374", name: "Faridpur", bn_name: "Faridpur" },
          { id: "375", name: "Ishwardi", bn_name: "Ishwardi" },
          { id: "376", name: "Pabna Sadar", bn_name: "Pabna Sadar" },
          { id: "377", name: "Santhia", bn_name: "Santhia" },
          { id: "378", name: "Sujanagar", bn_name: "Sujanagar" }
        ]
      },
      {
        id: "51",
        name: "Rajshahi",
        bn_name: "Rajshahi",
        upazilas: [
          { id: "379", name: "Bagha", bn_name: "Bagha" },
          { id: "380", name: "Bagmara", bn_name: "Bagmara" },
          { id: "381", name: "Charghat", bn_name: "চারঘাট" },
          { id: "382", name: "Durgapur", bn_name: "দুর্গাপুর" },
          { id: "383", name: "Godagari", bn_name: "Godagari" },
          { id: "384", name: "Mohanpur", bn_name: "মোহনপুর" },
          { id: "385", name: "Paba", bn_name: "পবা" },
          { id: "386", name: "Puthia", bn_name: "পুঠিয়া" },
          { id: "387", name: "Tanore", bn_name: "Tanore" }
        ]
      },
      {
        id: "52",
        name: "Sirajganj",
        bn_name: "Sirajganj",
        upazilas: [
          { id: "388", name: "Sirajganj Sadar", bn_name: "Sirajganj Sadar" },
          { id: "389", name: "Belkuchi", bn_name: "Belkuchi" },
          { id: "390", name: "Chauhali", bn_name: "Chauhali" },
          { id: "391", name: "Kamarkhanda", bn_name: "Kamarkhanda" },
          { id: "392", name: "Kazipur", bn_name: "Kazipur" },
          { id: "393", name: "Raiganj", bn_name: "Raiganj" },
          { id: "394", name: "Shahjadpur", bn_name: "Shahjadpur" },
          { id: "395", name: "Tarash", bn_name: "Tarash" },
          { id: "396", name: "Ullahpara", bn_name: "Ullahpara" }
        ]
      }
    ]
  },
  {
    id: "7",
    name: "Rangpur",
    bn_name: "Rangpur",
    districts: [
      {
        id: "53",
        name: "Dinajpur",
        bn_name: "Dinajpur",
        upazilas: [
          { id: "397", name: "Birampur", bn_name: "Birampur" },
          { id: "398", name: "Birganj", bn_name: "Birganj" },
          { id: "399", name: "Biral", bn_name: "Biral" },
          { id: "400", name: "Bochaganj", bn_name: "Bochaganj" },
          { id: "401", name: "Chirirbandar", bn_name: "Chirirbandar" },
          { id: "402", name: "Phulbari", bn_name: "Phulbari" },
          { id: "403", name: "Ghoraghat", bn_name: "Ghoraghat" },
          { id: "404", name: "Hakimpur", bn_name: "Hakimpur" },
          { id: "405", name: "Kaharole", bn_name: "Kaharole" },
          { id: "406", name: "Khansama", bn_name: "Khansama" },
          { id: "407", name: "Dinajpur Sadar", bn_name: "Dinajpur Sadar" },
          { id: "408", name: "Nawabganj", bn_name: "নবাবগঞ্জ" },
          { id: "409", name: "Parbatipur", bn_name: "Parbatipur" }
        ]
      },
      {
        id: "54",
        name: "Gaibandha",
        bn_name: "Gaibandha",
        upazilas: [
          { id: "410", name: "Fulchhari", bn_name: "Fulchhari" },
          { id: "411", name: "Gaibandha Sadar", bn_name: "Gaibandha Sadar" },
          { id: "412", name: "Gobindaganj", bn_name: "Gobindaganj" },
          { id: "413", name: "Palashbari", bn_name: "Palashbari" },
          { id: "414", name: "Sadullapur", bn_name: "Sadullapur" },
          { id: "415", name: "Saghata", bn_name: "Saghata" },
          { id: "416", name: "Sundarganj", bn_name: "Sundarganj" }
        ]
      },
      {
        id: "55",
        name: "Kurigram",
        bn_name: "Kurigram",
        upazilas: [
          { id: "417", name: "Kurigram Sadar", bn_name: "Kurigram Sadar" },
          { id: "418", name: "Nageshwari", bn_name: "Nageshwari" },
          { id: "419", name: "Bhurungamari", bn_name: "Bhurungamari" },
          { id: "420", name: "Phulbari", bn_name: "Phulbari" },
          { id: "421", name: "Rajarhat", bn_name: "Rajarhat" },
          { id: "422", name: "Ulipur", bn_name: "Ulipur" },
          { id: "423", name: "Chilmari", bn_name: "Chilmari" },
          { id: "424", name: "Rowmari", bn_name: "Rowmari" },
          { id: "425", name: "Char Rajibpur", bn_name: "Char Rajibpur" }
        ]
      },
      {
        id: "56",
        name: "Lalmonirhat",
        bn_name: "Lalmonirhat",
        upazilas: [
          { id: "426", name: "Lalmonirhat Sadar", bn_name: "Lalmonirhat Sadar" },
          { id: "427", name: "Aditmari", bn_name: "Aditmari" },
          { id: "428", name: "Kaliganj", bn_name: "কালীগঞ্জ" },
          { id: "429", name: "Hatibandha", bn_name: "Hatibandha" },
          { id: "430", name: "Patgram", bn_name: "Patgram" }
        ]
      },
      {
        id: "57",
        name: "Nilphamari",
        bn_name: "Nilphamari",
        upazilas: [
          { id: "431", name: "Nilphamari Sadar", bn_name: "Nilphamari Sadar" },
          { id: "432", name: "Saidpur", bn_name: "Saidpur" },
          { id: "433", name: "Jaldhaka", bn_name: "Jaldhaka" },
          { id: "434", name: "Kishoreganj", bn_name: "Kishoreganj" },
          { id: "435", name: "Domar", bn_name: "Domar" },
          { id: "436", name: "Dimla", bn_name: "Dimla" }
        ]
      },
      {
        id: "58",
        name: "Panchagarh",
        bn_name: "Panchagarh",
        upazilas: [
          { id: "437", name: "Panchagarh Sadar", bn_name: "Panchagarh Sadar" },
          { id: "438", name: "Debiganj", bn_name: "Debiganj" },
          { id: "439", name: "Boda", bn_name: "Boda" },
          { id: "440", name: "Atwari", bn_name: "Atwari" },
          { id: "441", name: "Tetulia", bn_name: "Tetulia" }
        ]
      },
      {
        id: "59",
        name: "Rangpur",
        bn_name: "Rangpur",
        upazilas: [
          { id: "442", name: "Badarganj", bn_name: "Badarganj" },
          { id: "443", name: "Mithapukur", bn_name: "Mithapukur" },
          { id: "444", name: "Gangachara", bn_name: "গংগাচড়া" },
          { id: "445", name: "Kaunia", bn_name: "Kaunia" },
          { id: "446", name: "Rangpur Sadar", bn_name: "রংপুর সদর" },
          { id: "447", name: "Pirgachha", bn_name: "Pirgachha" },
          { id: "448", name: "Pirganj", bn_name: "Pirganj" },
          { id: "449", name: "Taraganj", bn_name: "তারাগঞ্জ" }
        ]
      },
      {
        id: "60",
        name: "Thakurgaon",
        bn_name: "Thakurgaon",
        upazilas: [
          { id: "450", name: "Thakurgaon Sadar", bn_name: "Thakurgaon Sadar" },
          { id: "451", name: "Pirganj", bn_name: "Pirganj" },
          { id: "452", name: "Baliadangi", bn_name: "Baliadangi" },
          { id: "453", name: "Haripur", bn_name: "Haripur" },
          { id: "454", name: "Ranisankail", bn_name: "Ranisankail" }
        ]
      }
    ]
  },
  {
    id: "8",
    name: "Sylhet",
    bn_name: "Sylhet",
    districts: [
      {
        id: "61",
        name: "Habiganj",
        bn_name: "Habiganj",
        upazilas: [
          { id: "455", name: "Ajmiriganj", bn_name: "Ajmiriganj" },
          { id: "456", name: "Baniachang", bn_name: "Baniachang" },
          { id: "457", name: "Bahubal", bn_name: "Bahubal" },
          { id: "458", name: "Chunarughat", bn_name: "Chunarughat" },
          { id: "459", name: "Habiganj Sadar", bn_name: "Habiganj Sadar" },
          { id: "460", name: "Lakhai", bn_name: "Lakhai" },
          { id: "461", name: "Madhabpur", bn_name: "Madhabpur" },
          { id: "462", name: "Nabiganj", bn_name: "Nabiganj" },
          { id: "463", name: "Shaistagonj", bn_name: "Shaistagonj" }
        ]
      },
      {
        id: "62",
        name: "Moulvibazar",
        bn_name: "Moulvibazar",
        upazilas: [
          { id: "464", name: "Moulvibazar Sadar", bn_name: "Moulvibazar Sadar" },
          { id: "465", name: "Barlekha", bn_name: "Barlekha" },
          { id: "466", name: "Juri", bn_name: "Juri" },
          { id: "467", name: "Kamalganj", bn_name: "Kamalganj" },
          { id: "468", name: "Kulaura", bn_name: "Kulaura" },
          { id: "469", name: "Rajnagar", bn_name: "Rajnagar" },
          { id: "470", name: "Sreemangal", bn_name: "Sreemangal" }
        ]
      },
      {
        id: "63",
        name: "Sunamganj",
        bn_name: "Sunamganj",
        upazilas: [
          { id: "471", name: "Bishwamvarpur", bn_name: "Bishwamvarpur" },
          { id: "472", name: "Chhatak", bn_name: "Chhatak" },
          { id: "473", name: "Derai", bn_name: "Derai" },
          { id: "474", name: "Dharampasha", bn_name: "Dharampasha" },
          { id: "475", name: "Dowarabazar", bn_name: "Dowarabazar" },
          { id: "476", name: "Jagannathpur", bn_name: "Jagannathpur" },
          { id: "477", name: "Jamalganj", bn_name: "Jamalganj" },
          { id: "478", name: "Sulla", bn_name: "Sulla" },
          { id: "479", name: "Sunamganj Sadar", bn_name: "Sunamganj Sadar" },
          { id: "480", name: "Shanthiganj", bn_name: "Shanthiganj" },
          { id: "481", name: "Tahirpur", bn_name: "Tahirpur" },
          { id: "482", name: "Madhyanagar", bn_name: "Madhyanagar" }
        ]
      },
      {
        id: "64",
        name: "Sylhet",
        bn_name: "Sylhet",
        upazilas: [
          { id: "483", name: "Sylhet Sadar", bn_name: "সিলেট সদর" },
          { id: "484", name: "Beanibazar", bn_name: "বিয়ানীবাজার" },
          { id: "485", name: "Bishwanath", bn_name: "Bishwanath" },
          { id: "486", name: "Dakshin Surma", bn_name: "Dakshin Surma" },
          { id: "487", name: "Balaganj", bn_name: "Balaganj" },
          { id: "488", name: "Companiganj", bn_name: "কোম্পানীগঞ্জ" },
          { id: "489", name: "Fenchuganj", bn_name: "Fenchuganj" },
          { id: "490", name: "Golapganj", bn_name: "গোলাপগঞ্জ" },
          { id: "491", name: "Gowainghat", bn_name: "Gowainghat" },
          { id: "492", name: "Jaintiapur", bn_name: "Jaintiapur" },
          { id: "493", name: "Kanaighat", bn_name: "Kanaighat" },
          { id: "494", name: "Zakiganj", bn_name: "Zakiganj" },
          { id: "495", name: "Osmaninagar", bn_name: "Osmaninagar" }
        ]
      }
    ]
  }
]; 

export const OFFICIAL_UNION_DIRECTORY_URL = "https://bangladesh.gov.bd/views/union-list";

export const allDistricts = divisionsData.flatMap((division) => division.districts);
export const allUpazilas = allDistricts.flatMap((district) => district.upazilas);

export function findDistrictById(districtId: string) {
  return allDistricts.find((district) => district.id === districtId);
}

export function findUpazilasByDistrictId(districtId: string) {
  return findDistrictById(districtId)?.upazilas ?? [];
}

export function findDivisionByDistrictId(districtId: string) {
  return divisionsData.find((division) => division.districts.some((district) => district.id === districtId));
}

