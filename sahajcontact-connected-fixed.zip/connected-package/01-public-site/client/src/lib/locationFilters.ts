export type ServiceLocationScope = "nationwide" | "district" | "upazila";

/**
 * Determines whether a service should remain visible for the selected
 * administrative level. Nationwide services are always useful; district-level
 * paths appear after a district is selected, while upazila-specific paths are
 * shown only after the user chooses an upazila.
 */
export function matchesLocationScope(
  scope: ServiceLocationScope,
  districtId: string,
  upazilaId: string,
): boolean {
  if (!districtId) return true;
  if (!upazilaId) return scope !== "upazila";
  return true;
}

/**
 * The official National Portal owns the union directory. SahajSeva enables the
 * handoff after a district and upazila are selected so rural users carry a
 * meaningful administrative context into that directory.
 */
export function canSearchUnion(districtId: string, upazilaId: string): boolean {
  return Boolean(districtId && upazilaId);
}
