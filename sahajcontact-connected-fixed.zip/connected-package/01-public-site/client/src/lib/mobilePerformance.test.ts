import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const homeSource = readFileSync(new URL("../pages/Home.tsx", import.meta.url), "utf8");
const indexSource = readFileSync(new URL("../../index.html", import.meta.url), "utf8");
const appSource = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
const deferredSource = readFileSync(new URL("../components/DeferredMount.tsx", import.meta.url), "utf8");
const stylesheetSource = readFileSync(new URL("../index.css", import.meta.url), "utf8");
const headerSource = readFileSync(new URL("../components/SahajHeader.tsx", import.meta.url), "utf8");

describe("mobile performance safeguards", () => {
  it("serves the clean river artwork for the responsive hero", () => {
    expect(homeSource).toContain('media="(max-width: 680px)"');
    expect(homeSource).toContain("/manus-storage/sahajseva-river-clean-hero-mobile_18eb3204.webp");
    expect(homeSource).toContain("/manus-storage/sahajseva-river-clean-hero_90dbd003.webp");
    expect(indexSource).toContain('href="/manus-storage/sahajseva-river-clean-hero-mobile_18eb3204.webp" media="(max-width: 680px)"');
    expect(indexSource).toContain('href="/manus-storage/sahajseva-river-clean-hero_90dbd003.webp" media="(min-width: 681px)"');
  });

  it("uses deferred responsive gallery images and low-priority below-the-fold artwork", () => {
    const gallerySource = readFileSync(new URL("../components/BangladeshGallery.tsx", import.meta.url), "utf8");
    expect(gallerySource).toContain('loading="lazy"');
    expect(gallerySource).toContain('fetchPriority="low"');
    expect(gallerySource).toContain("srcSet");
    expect(homeSource).toContain("sahajcontact-computer-support-illustration_30ca225d.webp");
    expect(homeSource).toContain('loading="lazy"');
  });

  it("keeps the hero wrapper block-sized for stable layout reservation", () => {
    expect(stylesheetSource).toContain(".hero-art picture");
    expect(stylesheetSource).toContain("display: block");
    expect(stylesheetSource).toContain("aspect-ratio: 960 / 430");
  });

  it("defers non-critical widgets with idle-time and timeout fallbacks", () => {
    expect(appSource).toContain("<DeferredMount delay={1200}>");
    expect(deferredSource).toContain("window.requestIdleCallback");
    expect(deferredSource).toContain("window.setTimeout(activate, delay)");
  });

  it("keeps the rural menu motif interactive and accessible", () => {
    expect(headerSource).toContain("ruralMotifPaused");
    expect(headerSource).toContain('aria-pressed={ruralMotifPaused}');
    expect(headerSource).toContain("ধানের শীষের নড়াচড়া");
    expect(stylesheetSource).toContain(".sahaj-rural-motif svg");
    expect(stylesheetSource).toContain("@keyframes sahaj-rice-sway");
    expect(stylesheetSource).toContain("prefers-reduced-motion");
  });

  it("uses the supplied paddy-field image while retaining the dynamic mobile menu and Probashi Help Box", () => {
    expect(stylesheetSource).toContain("sahajcontact-rural-paddy-menu_a8b9f63f.jpg");
    expect(headerSource).toContain("sahaj-mobile-link");
    expect(headerSource).toContain("probashiSubtitle");
    expect(headerSource).toContain("navigation.map");
    expect(headerSource).not.toContain("অ্যাডমিন ড্যাশবোর্ড (Admin Dashboard)");
  });

  it("keeps the paddy-field background smooth by avoiding repeated diagonal streak overlays", () => {
    const menuBefore = stylesheetSource.match(/\.sahaj-mobile-menu::before[^}]+}/)?.[0] ?? "";
    const menuAfter = stylesheetSource.match(/\.sahaj-mobile-menu::after[^}]+}/)?.[0] ?? "";
    expect(menuBefore).not.toContain("repeating-linear-gradient");
    expect(menuAfter).not.toContain("repeating-linear-gradient");
    expect(menuBefore).toContain("radial-gradient");
    expect(menuAfter).toContain("radial-gradient");
  });
});
