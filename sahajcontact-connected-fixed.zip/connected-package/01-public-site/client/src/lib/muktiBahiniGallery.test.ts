import { describe, expect, it } from "vitest";
import { BANGLADESH_GALLERY_ITEMS } from "../data/bangladeshGallery";

describe("Mukti Bahini culture gallery entry", () => {
  it("uses the requested historical subject and durable asset path", () => {
    const item = BANGLADESH_GALLERY_ITEMS.find(
      entry => entry.id === "culture-rickshaw",
    );

    expect(item).toBeDefined();
    expect(item?.titleBn).toBe("মুক্তিযুদ্ধকালীন মুক্তিবাহিনী");
    expect(item?.titleEn).toBe("Mukti Bahini, 1971");
    expect(item?.imageUrl).toBe(
      "/manus-storage/mukti-bahini-1971-public-domain_7588ac83.jpg",
    );
  });

  it("keeps a visible source credit for the archival image", () => {
    const item = BANGLADESH_GALLERY_ITEMS.find(
      entry => entry.id === "culture-rickshaw",
    );

    expect(item?.creditBn).toContain("Wikimedia Commons");
    expect(item?.creditBn).toContain("Public domain");
    expect(item?.creditUrl).toContain("commons.wikimedia.org/wiki/File");
  });
});
