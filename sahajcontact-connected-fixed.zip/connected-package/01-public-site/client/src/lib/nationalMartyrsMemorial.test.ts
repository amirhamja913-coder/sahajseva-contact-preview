import { describe, expect, it } from "vitest";
import { BANGLADESH_GALLERY_ITEMS } from "../data/bangladeshGallery";

describe("National Martyrs’ Memorial first gallery card", () => {
  it("uses the memorial as the first gallery image", () => {
    const firstItem = BANGLADESH_GALLERY_ITEMS[0];
    expect(firstItem.id).toBe("culture-national-martyrs-memorial");
    expect(firstItem.titleBn).toBe("জাতীয় স্মৃতিসৌধ");
    expect(firstItem.imageUrl).toContain("national-martyrs-memorial");
  });

  it("keeps bilingual memorial metadata in the Culture category", () => {
    const firstItem = BANGLADESH_GALLERY_ITEMS[0];
    expect(firstItem.category).toBe("culture");
    expect(firstItem.titleEn).toContain("National Martyrs");
    expect(firstItem.captionBn).toContain("সাভারের জাতীয় স্মৃতিসৌধ");
    expect(firstItem.captionEn).toContain("Savar");
    expect(firstItem.creditEn).toContain("Wikimedia Commons");
    expect(firstItem.creditUrl).toContain("commons.wikimedia.org");
  });
});
