import { describe, expect, it } from "vitest";
import { newCivicServices } from "./newCivicServices";

const expectedServices = [
  ["জাতীয় পরিচয়পত্র (NID) অনলাইন আবেদন ও সংশোধন", "https://services.nidw.gov.bd"],
  ["ই-পাসপোর্ট অনলাইন আবেদন ও রিনিউ", "https://www.epassport.gov.bd"],
  ["জন্ম ও মৃত্যু নিবন্ধন অনলাইন আবেদন", "https://bdris.gov.bd"],
  ["ভূমি উন্নয়ন কর ও নামজারি (Mutation)", "https://land.gov.bd"],
  ["কৃষক কার্ড, সার, বীজ ও প্রণোদনা আবেদন", "https://amis.dae.gov.bd"],
  ["বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতা আবেদন", "https://www.mygov.bd"],
  ["ট্রেড লাইসেন্স আবেদন ও নবায়ন", "https://www.etradelicense.gov.bd"],
  ["BRTA ড্রাইভিং লাইসেন্স ও মোটর যান সেবা", "https://bsp.brta.gov.bd"],
  ["সরকারি চাকরির অফিশিয়াল নিয়োগ আবেদন", "https://alljobs.teletalk.com.bd"],
  ["বাংলাদেশ সরকারি কর্ম কমিশন (BPSC) আবেদন", "https://bpsc.gov.bd"],
] as const;

describe("new civic service catalogue", () => {
  it("contains exactly the 10 requested services in numbered order", () => {
    expect(newCivicServices).toHaveLength(10);
    expect(newCivicServices.map(({ title, href }) => [title, href])).toEqual(expectedServices);
    expect(newCivicServices.map(({ number }) => number)).toEqual([
      "31",
      "32",
      "33",
      "34",
      "35",
      "36",
      "37",
      "38",
      "39",
      "40",
    ]);
  });

  it("keeps every new destination as an external link", () => {
    expect(newCivicServices.every(({ href }) => /^https?:\/\//.test(href))).toBe(true);
    expect(new Set(newCivicServices.map(({ href }) => href)).size).toBe(10);
  });
});
