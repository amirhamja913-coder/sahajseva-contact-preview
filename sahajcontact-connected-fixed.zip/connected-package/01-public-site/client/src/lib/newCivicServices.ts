import type { ServiceLocationScope } from "./locationFilters";

export type CivicService = {
  number: string;
  title: string;
  tag: string;
  text: string;
  href: string;
  locationScope: ServiceLocationScope;
};

/** User-requested civic destinations appended after the existing 30 services. */
export const newCivicServices: CivicService[] = [
  {
    number: "31",
    title: "জাতীয় পরিচয়পত্র (NID) অনলাইন আবেদন ও সংশোধন",
    tag: "অফিসিয়াল অনলাইন আবেদন",
    text: "ভোটার তালিকাভুক্তির আবেদন, NID তথ্য সংশোধন এবং হারানো কার্ড উত্তোলনের অফিসিয়াল সেবা পোর্টাল।",
    href: "https://services.nidw.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "32",
    title: "ই-পাসপোর্ট অনলাইন আবেদন ও রিনিউ",
    tag: "অফিসিয়াল পাসপোর্ট সেবা",
    text: "নতুন ই-পাসপোর্ট আবেদন, ফি প্রদান, অ্যাপয়েন্টমেন্ট ও পাসপোর্ট স্ট্যাটাস চেক করার অফিসিয়াল পোর্টাল।",
    href: "https://www.epassport.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "33",
    title: "জন্ম ও মৃত্যু নিবন্ধন অনলাইন আবেদন",
    tag: "অফিসিয়াল জন্ম-মৃত্যু সেবা",
    text: "নতুন জন্ম বা মৃত্যু নিবন্ধন আবেদন, সনদ যাচাই এবং সংশোধনের জন্য জন্ম-মৃত্যু নিবন্ধন রেজিস্ট্রার অফিসিয়াল সাইট।",
    href: "https://bdris.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "34",
    title: "ভূমি উন্নয়ন কর ও নামজারি (Mutation)",
    tag: "অফিসিয়াল ভূমি সেবা",
    text: "অনলাইন ভূমি উন্নয়ন কর পরিশোধ, নামজারি আবেদন, খতিয়ান ও পর্চা উত্তোলনের ভূমি মন্ত্রণালয়ের অফিসিয়াল পোর্টাল।",
    href: "https://land.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "35",
    title: "কৃষক কার্ড, সার, বীজ ও প্রণোদনা আবেদন",
    tag: "অফিসিয়াল কৃষি সেবা",
    text: "কৃষক নিবন্ধন, কৃষি কার্ড, সার ও বীজ ভর্তুকি এবং সরকারি প্রণোদনার জন্য কৃষি মন্ত্রণালয়ের অফিসিয়াল পোর্টাল।",
    href: "https://amis.dae.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "36",
    title: "বয়স্ক, বিধবা ও প্রতিবন্ধী ভাতা আবেদন",
    tag: "অফিসিয়াল সমাজসেবা",
    text: "বয়স্ক ভাতা, বিধবা ভাতা, প্রতিবন্ধী ভাতা ও মাতৃত্বকালীন ভাতার সরকারি অনলাইন আবেদন ও তথ্যের পোর্টাল।",
    href: "https://www.mygov.bd",
    locationScope: "nationwide",
  },
  {
    number: "37",
    title: "ট্রেড লাইসেন্স আবেদন ও নবায়ন",
    tag: "স্থানীয় সরকার সেবা",
    text: "সিটি কর্পোরেশন ও পৌরসভা এলাকার ট্রেড লাইসেন্স সংক্রান্ত তথ্য ও অনলাইন আবেদন সেবা পোর্টাল।",
    href: "https://www.etradelicense.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "38",
    title: "BRTA ড্রাইভিং লাইসেন্স ও মোটর যান সেবা",
    tag: "অফিসিয়াল BRTA সেবা",
    text: "ড্রাইভিং লাইসেন্স আবেদন, লার্নার পারমিট, মোটর যান রেজিস্ট্রেশন ও ফি পরিশোধের BRTA পোর্টাল।",
    href: "https://bsp.brta.gov.bd",
    locationScope: "nationwide",
  },
  {
    number: "39",
    title: "সরকারি চাকরির অফিশিয়াল নিয়োগ আবেদন",
    tag: "অফিসিয়াল চাকরি পোর্টাল",
    text: "সরকারি চাকরির বিভিন্ন দপ্তরের সার্কুলার ও অনলাইনে আবেদন করার জন্য Teletalk ও সরকারি নিয়োগ পোর্টাল।",
    href: "https://alljobs.teletalk.com.bd",
    locationScope: "nationwide",
  },
  {
    number: "40",
    title: "বাংলাদেশ সরকারি কর্ম কমিশন (BPSC) আবেদন",
    tag: "অফিসিয়াল বিসিএস ও পিএসসি",
    text: "বিসিএস এবং পিএসসি-র অধীনে অন্যান্য সরকারি গ্রেডের পরীক্ষার আবেদন ও বিজ্ঞপ্তির অফিসিয়াল পোর্টাল।",
    href: "https://bpsc.gov.bd",
    locationScope: "nationwide",
  },
];
