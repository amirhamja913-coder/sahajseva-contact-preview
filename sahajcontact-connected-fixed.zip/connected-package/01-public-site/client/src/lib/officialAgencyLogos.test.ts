import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { officialAgencyLogos } from "@/components/UtilityAndExpatriateSections";

const indexCss = readFileSync(new URL("../index.css", import.meta.url), "utf8");

describe("law-enforcement official agency marks", () => {
  it("maps every represented agency to a managed asset with traceable source metadata", () => {
    const agencyKeys = [
      "policePortal",
      "cyber",
      "cid",
      "specialBranch",
      "dmp",
      "fireService",
      "ansarVdp",
      "coastGuard",
      "narcotics",
      "bgb",
      "army",
      "navy",
      "airForce",
    ] as const;

    for (const key of agencyKeys) {
      const logo = officialAgencyLogos[key];
      expect(logo.src).toMatch(/^\/manus-storage\//);
      expect(logo.src).toMatch(/\.(webp|svg)$/);
      expect(logo.alt.length).toBeGreaterThan(12);
      expect(logo.source).toMatch(/^https:\/\//);
    }
  });

  it("uses a clearly labeled fallback for RAB instead of misrepresenting a generic seal as a RAB logo", () => {
    expect(officialAgencyLogos).not.toHaveProperty("rab");
  });

  it("keeps the official marks visibly larger on desktop and mobile", () => {
    expect(indexCss).toContain("width: 3.2rem;");
    expect(indexCss).toContain("height: 3.2rem;");
    expect(indexCss).toContain("width: 3.05rem;");
    expect(indexCss).toContain("height: 3.05rem;");
  });
});
