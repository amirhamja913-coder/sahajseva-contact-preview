import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(process.cwd());
const readContactPage = () => readFileSync(resolve(projectRoot, "client/src/pages/Contact.tsx"), "utf8");
const readFooter = () => readFileSync(resolve(projectRoot, "client/src/components/SahajFooter.tsx"), "utf8");
const readAboutPage = () => readFileSync(resolve(projectRoot, "client/src/pages/FooterInfoPage.tsx"), "utf8");

describe("owner contact and public identity", () => {
  it("uses the provided real contact identity and actionable phone/email links", () => {
    const source = readContactPage();
    expect(source).toContain('label: "নাম", value: "কাজী মোঃ আমির হামজা"');
    expect(source).toContain('label: "পিতা", value: "জয়নাল আবেদীন"');
    expect(source).toContain('value: "01965177538", href: "tel:01965177538"');
    expect(source).toContain('value: "amirhamja913@gmail.com", href: "mailto:amirhamja913@gmail.com"');
    expect(source).not.toContain("Amirhamja913@gmail.com");
    expect(source).not.toContain("ডেমো যোগাযোগ কেন্দ্র");
  });

  it("uses the provided Tiara Bazar map query and Bengali address description", () => {
    const source = readContactPage();
    expect(source).toContain('const OFFICE_MAP_QUERY = "টিয়ারা বাজার, নবীনগর, ব্রাহ্মণবাড়িয়া, বাংলাদেশ";');
    expect(source).toContain("initialCenter={OFFICE_LOCATION}");
    expect(source).toContain("গ্রাম: টিয়ারা বাজার");
    expect(source).toContain("ইউনিয়ন: বিটঘর, থানা: নবীনগর, জেলা: ব্রাহ্মণবাড়িয়া, বাংলাদেশ");
    expect(source).toContain("আমাদের অফিসের অবস্থান দেখানো হয়েছে");
    expect(source).toContain("encodeURIComponent(OFFICE_MAP_QUERY)");
  });

  it("keeps the public About identity separate and does not expose an Admin footer entry", () => {
    const footer = readFooter();
    const about = readAboutPage();
    expect(about).toContain("Name: Kazi Amir Hamja");
    expect(about).toContain("Title: Entrepreneur, SahajContact");
    expect(footer).not.toContain('data-testid="footer-admin-profile-entry"');
    expect(footer).not.toContain("/admin/dashboard");
    expect(footer).not.toContain("Private owner administration");
    expect(footer).not.toContain("Name: Kazi Amir Hamja");
    expect(about).toContain('data-testid="about-admin-identity"');
  });
});
