import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const skeletonSource = readFileSync(new URL("../components/SahajPageSkeleton.tsx", import.meta.url), "utf8");
const appSource = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
const stylesheetSource = readFileSync(new URL("../index.css", import.meta.url), "utf8");

describe("initial page Skeleton Screen", () => {
  it("uses accessible loading semantics and preserves the primary page geometry", () => {
    expect(skeletonSource).toContain('role="status"');
    expect(skeletonSource).toContain('aria-busy="true"');
    expect(skeletonSource).toContain('aria-label="পৃষ্ঠা লোড হচ্ছে"');
    expect(skeletonSource).toContain("page-skeleton-hero-art");
    expect(skeletonSource).toContain("page-skeleton-search");
    expect(skeletonSource).toContain("page-skeleton-card");
  });

  it("lazy-loads Home behind the Skeleton Screen route fallback", () => {
    expect(appSource).toContain('const Home = lazy(() => import("./pages/Home"));');
    expect(appSource).toContain("return <SahajPageSkeleton />;");
  });

  it("reserves responsive geometry and respects reduced motion", () => {
    expect(stylesheetSource).toContain("aspect-ratio: 960 / 430");
    expect(stylesheetSource).toContain("@media (max-width: 680px)");
    expect(stylesheetSource).toContain("@media (prefers-reduced-motion: reduce)");
    expect(stylesheetSource).toContain("animation: none");
  });
});
