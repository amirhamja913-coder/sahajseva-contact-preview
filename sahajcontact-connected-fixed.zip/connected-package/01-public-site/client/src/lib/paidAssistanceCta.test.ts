import { describe, expect, it } from "vitest";
import {
  PAID_ASSISTANCE_CONTACT_LABEL,
  PAID_ASSISTANCE_CTA_LABEL,
  PAID_ASSISTANCE_CTA_SCOPE,
  PAID_ASSISTANCE_PHONE,
  PAID_ASSISTANCE_TEL_URL,
  PAID_ASSISTANCE_WHATSAPP_URL,
} from "./paidAssistanceCta";

describe("paid assistance folder CTA", () => {
  it("keeps the WhatsApp CTA pointed at the configured service number", () => {
    expect(PAID_ASSISTANCE_WHATSAPP_URL).toContain("wa.me/8801965177538");
    expect(PAID_ASSISTANCE_WHATSAPP_URL).toContain("%E0%A6%B8");
  });

  it("keeps the phone CTA and Bengali labels consistent", () => {
    expect(PAID_ASSISTANCE_PHONE).toBe("01965177538");
    expect(PAID_ASSISTANCE_TEL_URL).toBe("tel:01965177538");
    expect(PAID_ASSISTANCE_CTA_LABEL).toBe("সার্ভিস নিন");
    expect(PAID_ASSISTANCE_CONTACT_LABEL).toBe("আমাদের সাথে যোগাযোগ করুন");
    expect(PAID_ASSISTANCE_CTA_SCOPE).toBe("paid_assistance_folder_cta");
  });
});
