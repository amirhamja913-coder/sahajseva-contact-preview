export const PAID_ASSISTANCE_PHONE = "01965177538";
export const PAID_ASSISTANCE_TEL_URL = `tel:${PAID_ASSISTANCE_PHONE}`;
export const PAID_ASSISTANCE_WHATSAPP_URL = `https://wa.me/8801965177538?text=${encodeURIComponent("আসসালামু আলাইকুম, SahajContact থেকে সহায়তা লাগবে")}`;
export const PAID_ASSISTANCE_CTA_LABEL = "সার্ভিস নিন";
export const PAID_ASSISTANCE_CONTACT_LABEL = "আমাদের সাথে যোগাযোগ করুন";
export const PAID_ASSISTANCE_CTA_SCOPE = "paid_assistance_folder_cta";
