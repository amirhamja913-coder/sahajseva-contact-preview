import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const homeSource = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
const stylesSource = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");

const illustrationPath = "/manus-storage/sahajcontact-computer-support-illustration_30ca225d.webp";

describe("official guidance support illustration", () => {
  it("renders the computer-support illustration inside the official-guidance summary", () => {
    expect(homeSource).toContain(illustrationPath);
    expect(homeSource).toContain('className="official-guidance-summary-art"');
    expect(homeSource).toContain("বিশেষ সহায়তা");
  });

  it("keeps the illustration responsive and readable without motion", () => {
    expect(stylesSource).toContain(".official-guidance-summary-art");
    expect(stylesSource).toContain("width: clamp");
    expect(stylesSource).toContain("object-fit: contain");
    expect(stylesSource).not.toContain("animation: official-guidance");
  });
});
