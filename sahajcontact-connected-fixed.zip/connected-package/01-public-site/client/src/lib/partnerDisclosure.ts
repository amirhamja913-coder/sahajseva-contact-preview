export const PARTNER_DISCLOSURE = "আমরা Star Tech, Ryans, Daraz এর অফিসিয়াল পার্টনার না। শুধু গ্রাহকদের সুবিধার জন্য লিংক দিয়েছি।";
