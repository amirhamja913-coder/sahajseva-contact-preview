import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const fundingPageSource = readFileSync(new URL("../pages/FundingGuidancePage.tsx", import.meta.url), "utf8");
const appSource = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
const headerSource = readFileSync(new URL("../components/SahajHeader.tsx", import.meta.url), "utf8");

describe("partnership outreach transparency", () => {
  it("lists all eight information-source organisations without presenting them as confirmed partners", () => {
    for (const org of [
      "bKash",
      "Nagad",
      "Star Tech",
      "Ryans Computers",
      "BRAC",
      "Grameenphone",
      "US-Bangla Airlines",
      "Daraz Bangladesh"
    ]) {
      expect(fundingPageSource).toContain(org);
    }

    expect(fundingPageSource).toContain("Partnership interest — not confirmed");
    expect(fundingPageSource).toContain("পার্টনারশিপ আগ্রহ — নিশ্চিত নয়");
    expect(fundingPageSource).toContain("not an official sponsor, partner or endorser");
    expect(fundingPageSource).toContain("অফিসিয়াল স্পন্সর, পার্টনার বা সমর্থনদাতা নয়");
  });

  it("links each emailed organisation to its verified official website", () => {
    for (const officialLink of [
      'url: "https://www.bkash.com/"',
      'url: "https://nagad.com.bd/"',
      'url: "https://www.startech.com.bd/"',
      'url: "https://www.ryans.com/"',
      'url: "https://www.brac.net/"',
      'url: "https://www.grameenphone.com/"',
      'url: "https://usbair.com/"',
      'url: "https://www.daraz.com.bd/"',
    ]) {
      expect(fundingPageSource).toContain(officialLink);
    }

    expect(fundingPageSource).toContain('target="_blank"');
    expect(fundingPageSource).toContain('rel="noopener noreferrer"');
    expect(fundingPageSource).toContain("officialWebsite");
  });

  it("links the NGO guidance cards to official sites without claiming affiliation", () => {
    for (const officialLink of [
      'url="https://www.brac.net/"',
      'url="https://asa.org.bd/"',
    ]) {
      expect(fundingPageSource).toContain(officialLink);
    }

    expect(fundingPageSource).toContain("not an official partner, representative or authorised agent");
    expect(fundingPageSource).toContain("অফিসিয়াল পার্টনার, প্রতিনিধি বা অনুমোদিত এজেন্ট নয়");
    expect(fundingPageSource).toContain("aria-label={`${name} — ${copy.officialWebsite} (${copy.external})`}");
  });

  it("keeps the advertising and funding guidance route active", () => {
    expect(fundingPageSource).toContain('href="/ngo-partnership"');
    expect(fundingPageSource).toContain('href="/contact"');
    expect(fundingPageSource).toContain("বিজ্ঞাপনের তথ্যের জন্য Contact পেজ ব্যবহার করুন");
    expect(fundingPageSource).toContain("An enquiry does not create a placement, invoice, payment request, endorsement, or approval.");
    expect(fundingPageSource).not.toContain("wa.me/");
    expect(appSource).toContain('<Route path="/funding-guidance" component={FundingGuidancePage} />');
  });

  it("keeps the funding guidance page available through the owner-managed desktop and mobile navigation", () => {
    expect(headerSource).toContain('"/funding-guidance"');
    expect(headerSource).toContain("পার্টনারশিপ ও NGO সহায়তা");
    expect(headerSource).toContain("navigation.map");
  });

  it("keeps the safety-policy link ordered below partnership navigation in the default owner-managed menu", () => {
    expect(headerSource).toContain('"/security-policy"');
    expect(headerSource).toContain("নিরাপত্তা নীতি");

    const partnershipIndex = headerSource.indexOf('"/funding-guidance"');
    const safetyIndex = headerSource.indexOf('"/security-policy"');
    expect(partnershipIndex).toBeGreaterThanOrEqual(0);
    expect(safetyIndex).toBeGreaterThan(partnershipIndex);
  });
});

export {};
