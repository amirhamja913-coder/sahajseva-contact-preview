export const BKASH_NUMBER = "01965177538";

export type BkashCopyStatus = "idle" | "copied" | "error";

export function getBkashCopyButtonLabel(status: BkashCopyStatus): string {
  if (status === "copied") return "কপি হয়েছে";
  if (status === "error") return "আবার চেষ্টা করুন";
  return "কপি করুন";
}

export function validateTransactionId(txId: string): boolean {
  const cleaned = txId.trim();
  // Standard bKash/Nagad Transaction IDs are alphanumeric and typically 8-15 characters long
  return cleaned.length >= 6 && /^[a-zA-Z0-9]+$/.test(cleaned);
}

export function buildWhatsAppPaymentUrl(serviceTitle: string, price: string, txId: string): string {
  const message = `আসসালামু আলাইকুম। আমি "${serviceTitle}" (${price}) সেবার জন্য পেমেন্ট করেছি।\nবিকাশ ট্রানজেকশন আইডি: ${txId.trim()}\nদয়া করে আমার আবেদনটি প্রসেস করুন।`;
  return `https://wa.me/8801965177538?text=${encodeURIComponent(message)}`;
}
