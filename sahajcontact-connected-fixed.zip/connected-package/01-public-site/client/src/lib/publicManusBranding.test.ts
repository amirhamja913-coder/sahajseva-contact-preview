import { existsSync, readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const projectRoot = new URL("../../../", import.meta.url);

const publicFiles = [
  "client/src/components/SahajFooter.tsx",
  "client/src/components/SahajHeader.tsx",
  "client/src/pages/SecurityPolicy.tsx",
  "client/src/pages/Home.tsx",
  "client/src/App.tsx",
  "client/index.html",
  "client/public/manifest.json",
];

describe("public Manus branding boundary", () => {
  it("does not expose Manus credit wording in visitor-facing files", () => {
    const combined = publicFiles
      .filter(file => existsSync(new URL(file, projectRoot)))
      .map(file => readFileSync(new URL(file, projectRoot), "utf8"))
      .join("\n");

    expect(combined).not.toMatch(/made\s+by\s+manus/i);
    expect(combined).not.toMatch(/manus\s+ai/i);
    expect(combined).not.toMatch(/made\s+by\s+মানুষ/i);
    expect(combined).not.toMatch(/মানুষ\s+ai/i);
  });
});

