import type { CivicService } from "./newCivicServices";

export type PublicSearchDestination = {
  id: string;
  href: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  aliases: readonly string[];
};

const normalizeSearchText = (value: string) =>
  value.toLocaleLowerCase("bn").replace(/[য়য়]/g, "য়").replace(/\s+/g, " ").trim();

/**
 * Public pages that are already registered in the application router. These are
 * internal discovery destinations only: official government actions continue to
 * be supplied by the matching civic-service card.
 */
export const publicSearchDestinations: readonly PublicSearchDestination[] = [
  {
    id: "services",
    href: "/#services",
    titleBn: "সকল নাগরিক সেবা",
    titleEn: "All civic services",
    descriptionBn: "সেবা তালিকা, প্রয়োজনীয় ধাপ এবং যাচাইকৃত অফিসিয়াল পোর্টালের পথ দেখুন।",
    descriptionEn: "Browse civic-service guidance and the verified official action on each service card.",
    aliases: ["সেবা", "সকল সেবা", "সরকারি সেবা", "নাগরিক সেবা", "service", "services", "government service"],
  },
  {
    id: "about",
    href: "/about",
    titleBn: "সাহজসেবা সম্পর্কে",
    titleEn: "About Sahajseba",
    descriptionBn: "পোর্টালের উদ্দেশ্য, ব্যবহারপদ্ধতি ও নাগরিক সহায়তার প্রেক্ষাপট জানুন।",
    descriptionEn: "Learn the portal purpose, use approach, and civic-support context.",
    aliases: ["সম্পর্কে", "আমাদের সম্পর্কে", "পরিচিতি", "about", "who we are", "sahajcontact"],
  },
  {
    id: "funding-guidance",
    href: "/funding-guidance",
    titleBn: "এনজিও, সহায়তা ও অংশীদারত্ব নির্দেশনা",
    titleEn: "NGO, assistance and partnership guidance",
    descriptionBn: "এনজিও তথ্য, সামাজিক সহায়তা, অংশীদারত্ব ও স্পনসরশিপের নির্দেশনা দেখুন।",
    descriptionEn: "Find NGO information, social-support guidance, partnership, and sponsorship notes.",
    aliases: ["এনজিও", "ngo", "সহায়তা", "funding", "অংশীদারত্ব", "partnership", "কমিউনিটি", "সামাজিক সহায়তা"],
  },
  {
    id: "future-plan",
    href: "/future-plan",
    titleBn: "ভবিষ্যৎ পরিকল্পনা",
    titleEn: "Future plan",
    descriptionBn: "সাহজসেবার পরিকল্পিত উন্নয়ন ও সেবার পরবর্তী দিকনির্দেশনা পড়ুন।",
    descriptionEn: "Read the portal's planned improvements and future service direction.",
    aliases: ["ভবিষ্যৎ", "পরিকল্পনা", "ভবিষ্যৎ পরিকল্পনা", "future plan", "roadmap", "পরবর্তী পরিকল্পনা"],
  },
  {
    id: "public-guidance",
    href: "/public-guidance",
    titleBn: "সাধারণ মানুষের জন্য করণীয়",
    titleEn: "Public guidance",
    descriptionBn: "সেবা নেওয়া, প্রতারণা এড়ানো ও নিরাপদভাবে তথ্য যাচাইয়ের ব্যবহারিক নির্দেশনা দেখুন।",
    descriptionEn: "Read practical steps for receiving services, avoiding fraud, and verifying information safely.",
    aliases: ["করণীয়", "সাধারণ মানুষের জন্য", "জনসাধারণ", "public guidance", "what to do", "নির্দেশনা", "সতর্কতা"],
  },
  {
    id: "security-policy",
    href: "/security-policy",
    titleBn: "নিরাপত্তা নীতি",
    titleEn: "Security policy",
    descriptionBn: "সাইট নিরাপত্তা, গোপনীয়তা, মালিকানা নিয়ন্ত্রণ ও ঘটনার সময় করণীয় পড়ুন।",
    descriptionEn: "Review site security, privacy, ownership control, and incident-response guidance.",
    aliases: ["নিরাপত্তা", "নিরাপত্তা নীতি", "সিকিউরিটি", "security", "security policy", "privacy", "গোপনীয়তা"],
  },
  {
    id: "contact",
    href: "/contact",
    titleBn: "যোগাযোগ",
    titleEn: "Contact",
    descriptionBn: "সাহজসেবার যোগাযোগের তথ্য ও বার্তা পাঠানোর পথ দেখুন।",
    descriptionEn: "View Sahajseba contact details and the message path.",
    aliases: ["যোগাযোগ", "contact", "phone", "ফোন", "ইমেইল", "email", "বার্তা"],
  },
  {
    id: "sponsor",
    href: "/sponsor",
    titleBn: "স্পনসর ও সহযোগিতা",
    titleEn: "Sponsor and support",
    descriptionBn: "স্পনসরশিপ ও সহযোগিতার জন্য পোর্টালের তথ্যপৃষ্ঠায় যান।",
    descriptionEn: "Visit the portal information page for sponsorship and support.",
    aliases: ["স্পনসর", "sponsor", "sponsorship", "সহযোগিতা করুন", "support us"],
  },
  {
    id: "business-directory",
    href: "/business-directory",
    titleBn: "Business Directory",
    titleEn: "Business Directory",
    descriptionBn: "মালিকের পর্যালোচনার পর প্রকাশিত ব্যবসা-তালিকা দেখুন বা নিজের তথ্য review-এর জন্য জমা দিন।",
    descriptionEn: "Browse owner-reviewed business listings or submit business information for review.",
    aliases: ["ব্যবসা", "ব্যবসার তালিকা", "বিজনেস", "business", "business directory", "directory", "listing", "তালিকাভুক্তি"],
  },
  {
    id: "tools",
    href: "/tools",
    titleBn: "ব্যবহারিক টুলস",
    titleEn: "Useful tools",
    descriptionBn: "পোর্টালে থাকা ব্যবহারিক টুলস ও সহায়ক নির্দেশনায় যান।",
    descriptionEn: "Open the portal's practical tools and supporting guidance.",
    aliases: ["টুল", "tools", "tool", "ক্যালকুলেটর", "সহায়ক টুল"],
  },
  {
    id: "tv-channels",
    href: "/tv-channels",
    titleBn: "বাংলাদেশ টিভি চ্যানেল",
    titleEn: "Bangladesh TV channels",
    descriptionBn: "মালিক-পরিচালিত টিভি চ্যানেল ডিরেক্টরি দেখুন।",
    descriptionEn: "Browse the owner-managed TV channel directory.",
    aliases: ["টিভি", "টেলিভিশন", "চ্যানেল", "tv", "television", "tv channels", "বাংলাদেশ টিভি"],
  },
  {
    id: "newspapers",
    href: "/newspapers",
    titleBn: "বাংলাদেশ পত্রিকা পোর্টাল",
    titleEn: "Bangladesh newspapers",
    descriptionBn: "মালিক-পরিচালিত পত্রিকা ও সংবাদপোর্টাল ডিরেক্টরি দেখুন।",
    descriptionEn: "Browse the owner-managed newspaper and news portal directory.",
    aliases: ["পত্রিকা", "সংবাদ", "সংবাদপত্র", "newspaper", "newspapers", "news", "মিডিয়া"],
  },
  {
    id: "bangladesh-guide",
    href: "/bangladesh",
    titleBn: "বাংলাদেশ ভ্রমণ ও স্থলপথে আগমনের নির্দেশনা",
    titleEn: "Bangladesh travel and land-arrival guidance",
    descriptionBn: "বাংলাদেশ ভ্রমণ, পর্যটন ও স্থলপথে বাংলাদেশে আগমনের তথ্যপৃষ্ঠায় যান।",
    descriptionEn: "Visit the Bangladesh travel, tourism, and land-arrival information page.",
    aliases: ["ভ্রমণ", "পর্যটন", "ট্যুরিস্ট", "tourism", "tourist", "travel", "ভারত", "india", "বর্ডার", "land port", "স্থলবন্দর"],
  },
  {
    id: "august-2026-report",
    href: "/reports/august-2026",
    titleBn: "আগস্ট ২০২৬ SEO ও অ্যানালিটিক্স রিপোর্ট",
    titleEn: "August 2026 SEO and analytics report",
    descriptionBn: "মালিক-প্রদত্ত আগস্ট ২০২৬ SEO ও অ্যানালিটিক্স রিপোর্ট পড়ুন।",
    descriptionEn: "Read the owner-provided August 2026 SEO and analytics report.",
    aliases: ["রিপোর্ট", "seo report", "analytics report", "আগস্ট রিপোর্ট", "august 2026", "seo", "অ্যানালিটিক্স", "analytics"],
  },
] as const;

const civicServiceAliasesByNumber: Record<string, readonly string[]> = {
  "01": ["সরকারি সেবা", "government service", "নাগরিক", "citizen service"],
  "02": ["পুলিশ", "থানা", "gd", "general diary", "police station"],
  "04": ["সমাজসেবা", "social service", "allowance"],
  "05": ["প্রতিবন্ধী", "disability allowance", "ভাতা"],
  "06": ["বয়স্ক ভাতা", "বিধবা ভাতা", "allowance"],
  "07": ["সরকারি ভাতা", "social allowance", "allowance"],
  "17": ["nid", "nid card", "জাতীয় পরিচয়পত্র", "ভোটার আইডি", "smart card"],
  "18": ["passport", "e passport", "ই পাসপোর্ট", "পাসপোর্ট রিনিউ"],
  "31": ["nid", "nid card", "জাতীয় পরিচয়পত্র", "ভোটার নিবন্ধন", "স্মার্ট কার্ড"],
  "32": ["passport", "e passport", "পাসপোর্ট", "renew passport"],
  "33": ["জন্ম নিবন্ধন", "birth registration", "মৃত্যু নিবন্ধন", "death registration"],
  "34": ["ভূমি", "land", "নামজারি", "mutation", "খতিয়ান", "পর্চা", "land tax"],
  "35": ["কৃষক", "কৃষি", "farmer", "fertilizer", "seed", "প্রণোদনা"],
  "36": ["ভাতা", "allowance", "বয়স্ক", "বিধবা", "প্রতিবন্ধী", "মাতৃত্বকালীন"],
  "37": ["ট্রেড লাইসেন্স", "trade licence", "trade license", "ব্যবসা লাইসেন্স"],
  "38": ["brta", "ড্রাইভিং লাইসেন্স", "driving licence", "motor vehicle"],
  "39": ["সরকারি চাকরি", "government jobs", "job circular", "চাকরি"],
  "40": ["bpsc", "বিসিএস", "bcs", "psc", "সরকারি কর্ম কমিশন"],
};

export function getCivicServiceSearchText(service: Pick<CivicService, "number" | "title" | "tag" | "text">) {
  return normalizeSearchText([
    service.title,
    service.tag,
    service.text,
    ...(civicServiceAliasesByNumber[service.number] ?? []),
  ].join(" "));
}

export function findPublicSearchDestinations(query: string) {
  const terms = normalizeSearchText(query).split(" ").filter(Boolean);
  if (terms.length === 0) return [];

  return publicSearchDestinations.filter((destination) => {
    const searchable = normalizeSearchText([
      destination.titleBn,
      destination.titleEn,
      destination.descriptionBn,
      destination.descriptionEn,
      ...destination.aliases,
    ].join(" "));
    return terms.every((term) => searchable.includes(term));
  });
}
