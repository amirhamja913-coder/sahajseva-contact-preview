import { describe, expect, it } from "vitest";
import { PUBLIC_SITE_BENGALI_NAME, PUBLIC_SITE_NAME, getPublicRouteSeo } from "./publicSeo";

describe("public SEO branding", () => {
  it("brands the Home title with SahajContact and the Bengali public name", () => {
    const homeSeo = getPublicRouteSeo("/");

    expect(homeSeo.title).toContain(PUBLIC_SITE_NAME);
    expect(homeSeo.title).toContain(PUBLIC_SITE_BENGALI_NAME);
    expect(homeSeo.canonical).toBe("https://sahajcontact-8xyxsefc.manus.space/");
  });

  it("keeps route-level public titles branded consistently", () => {
    expect(getPublicRouteSeo("/bangladesh").title).toContain(PUBLIC_SITE_NAME);
    expect(getPublicRouteSeo("/contact").title).toContain(PUBLIC_SITE_NAME);
  });

  it("frames Bangladesh tourism as an arrival guide, not outbound India travel", () => {
    const tourismSeo = getPublicRouteSeo("/bangladesh");

    expect(tourismSeo.title).toContain("স্থলপথে আগমনের গাইড");
    expect(tourismSeo.title).not.toContain("ভারত-সংযোগ");
    expect(tourismSeo.description).toContain("বাংলাদেশে আসার আগে");
  });
});
