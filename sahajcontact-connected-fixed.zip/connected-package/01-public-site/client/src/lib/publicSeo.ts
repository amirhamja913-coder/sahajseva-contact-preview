export const PUBLIC_SITE_ORIGIN = "https://sahajcontact-8xyxsefc.manus.space";
export const PUBLIC_SITE_NAME = "SahajContact";
export const PUBLIC_SITE_BENGALI_NAME = "সহজ জনসেবা পোর্টাল";

export type PublicRouteSeo = {
  title: string;
  description: string;
  canonical: string;
};

const makeSeo = (path: string, title: string, description: string): PublicRouteSeo => ({
  title: `${title} | ${PUBLIC_SITE_NAME}`,
  description,
  canonical: `${PUBLIC_SITE_ORIGIN}${path}`,
});

const homeSeo = makeSeo(
  "/",
  "সহজ জনসেবা পোর্টাল — সরকারি সেবা ও নাগরিক তথ্যের পথ",
  "NID, পাসপোর্ট, ভূমি, ভাতা, পুলিশ সহায়তা এবং যাচাইকৃত সরকারি সেবার পথ খুঁজুন।",
);

export const publicRouteSeo: Readonly<Record<string, PublicRouteSeo>> = {
  "/": homeSeo,
  "/about": makeSeo("/about", "সহজ জনসেবা পোর্টাল সম্পর্কে | নাগরিক তথ্যপথ", "সহজ জনসেবা পোর্টালের উদ্দেশ্য, ব্যবহারপদ্ধতি ও নাগরিক সহায়তার প্রেক্ষাপট জানুন।"),
  "/funding-guidance": makeSeo("/funding-guidance", "এনজিও ও সহায়তা নির্দেশনা | সহজ জনসেবা পোর্টাল", "এনজিও তথ্য, সামাজিক সহায়তা, অংশীদারত্ব ও স্পনসরশিপের নির্দেশনা দেখুন।"),
  "/ngo-partnership": makeSeo("/ngo-partnership", "NGO ও প্রাতিষ্ঠানিক সহযোগিতা | SahajContact", "সরকারি সংস্থা, নিবন্ধিত NGO, ফাউন্ডেশন ও দায়িত্বশীল প্রতিষ্ঠানের জন্য SahajContact-এর স্বচ্ছ সহযোগিতা প্রস্তাব ও আগ্রহপত্র।"),
  "/future-plan": makeSeo("/future-plan", "ভবিষ্যৎ পরিকল্পনা | সহজ জনসেবা পোর্টাল", "সহজ জনসেবা পোর্টালের পরিকল্পিত উন্নয়ন এবং নাগরিক সেবার পরবর্তী দিকনির্দেশনা পড়ুন।"),
  "/public-guidance": makeSeo("/public-guidance", "সাধারণ মানুষের জন্য করণীয় | সহজ জনসেবা পোর্টাল", "সেবা নেওয়া, তথ্য যাচাই এবং প্রতারণা এড়ানোর ব্যবহারিক নাগরিক নির্দেশনা দেখুন।"),
  "/security-policy": makeSeo("/security-policy", "নিরাপত্তা নীতি | সহজ জনসেবা পোর্টাল", "সাইট নিরাপত্তা, গোপনীয়তা, মালিকানা নিয়ন্ত্রণ এবং incident response-এর বাংলা নীতি পড়ুন।"),
  "/contact": makeSeo("/contact", "যোগাযোগ | সহজ জনসেবা পোর্টাল", "সহজ জনসেবা পোর্টালের যোগাযোগের তথ্য ও বার্তা পাঠানোর পথ দেখুন।"),
  "/sponsor": makeSeo("/sponsor", "স্পনসর ও সহযোগিতা | সহজ জনসেবা পোর্টাল", "সহজ জনসেবা পোর্টালের স্পনসরশিপ ও সহযোগিতার তথ্য দেখুন।"),
  "/business-directory": makeSeo("/business-directory", "Business Directory | সহজ জনসেবা পোর্টাল", "মালিকের পর্যালোচনার পর প্রকাশিত ব্যবসা-তালিকা দেখুন বা নিজের ব্যবসার তথ্য review-এর জন্য জমা দিন।"),
  "/tools": makeSeo("/tools", "ব্যবহারিক টুলস | সহজ জনসেবা পোর্টাল", "নাগরিক কাজের জন্য পোর্টালের ব্যবহারিক টুলস ও সহায়ক নির্দেশনায় যান।"),
  "/bangladesh": makeSeo("/bangladesh", "বাংলাদেশ ভ্রমণ ও স্থলপথে আগমনের গাইড", "বাংলাদেশ ভ্রমণ, পর্যটন এবং স্থলপথে বাংলাদেশে আসার আগে অফিসিয়াল উৎস যাচাইয়ের তথ্যপৃষ্ঠায় যান।"),
  "/tv-channels": makeSeo("/tv-channels", "বাংলাদেশ টিভি চ্যানেল | সহজ জনসেবা পোর্টাল", "মালিক-পরিচালিত বাংলাদেশ টিভি চ্যানেল ডিরেক্টরি দেখুন।"),
  "/newspapers": makeSeo("/newspapers", "বাংলাদেশ পত্রিকা পোর্টাল | সহজ জনসেবা পোর্টাল", "মালিক-পরিচালিত বাংলাদেশ পত্রিকা ও সংবাদপোর্টাল ডিরেক্টরি দেখুন।"),
  "/expatriate-guide": makeSeo("/expatriate-guide", "প্রবাসী সহায়তা নির্দেশনা | সহজ জনসেবা পোর্টাল", "প্রবাসী সেবা ও সহায়তার তথ্যপথ দেখুন।"),
  "/blog": makeSeo("/blog", "খবর ও নির্দেশনা | সহজ জনসেবা পোর্টাল", "সহজ জনসেবা পোর্টালের নাগরিক তথ্য ও নির্দেশনা পড়ুন।"),
  "/privacy-policy": makeSeo("/privacy-policy", "গোপনীয়তা নীতি | সহজ জনসেবা পোর্টাল", "সহজ জনসেবা পোর্টালের গোপনীয়তা নীতি পড়ুন。"),
};

export function getPublicRouteSeo(pathname: string) {
  return publicRouteSeo[pathname] ?? homeSeo;
}
