import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(process.cwd());
const readPublicFile = (name: string) => readFileSync(resolve(projectRoot, "client/public", name), "utf8");

describe("SahajSeva PWA setup", () => {
  it("defines installable Bengali standalone metadata and shortcuts", () => {
    const manifest = JSON.parse(readPublicFile("manifest.webmanifest")) as Record<string, unknown>;
    expect(manifest.name).toBe("SahajContact | সহজ জনসেবা পোর্টাল");
    expect(manifest.lang).toBe("bn-BD");
    expect(manifest.display).toBe("standalone");
    expect(manifest.start_url).toBe("/");
    expect(manifest.scope).toBe("/");
    expect(manifest.icons).toHaveLength(2);
    expect(manifest.icons).toEqual(expect.arrayContaining([
      expect.objectContaining({ sizes: "192x192", type: "image/png", src: "/manus-storage/sahajseva-pwa-icon-192_a8abdcbc.png" }),
      expect.objectContaining({ sizes: "512x512", type: "image/png", src: "/manus-storage/sahajseva-pwa-icon-512_6d7c8e20.png" }),
    ]));
    expect(manifest.shortcuts).toEqual(expect.arrayContaining([
      expect.objectContaining({ url: "/#services" }),
      expect.objectContaining({ url: "/contact" }),
    ]));
  });

  it("uses a versioned public-only service worker with offline navigation and safe official OAuth/Admin/API exclusions", () => {
    const worker = readPublicFile("sw.js");
    expect(worker).toContain('const CACHE_VERSION = "sahajseva-pwa-v19-map-verified-alpha"');
    expect(worker).toContain('"/manus-storage/sahajcontact-karnafuli-tunnel-clean_6b8249ee.png"');
    expect(worker).toContain('"/manus-storage/sahajcontact-map-tiger-waterlily-alpha-overlay-verified_5ad7e1cf.png"');
    expect(worker).not.toContain('sahajcontact-map-tiger-waterlily-alpha-overlay-v2_d32b4389.png');
    expect(worker).not.toContain('sahajcontact-map-river-tiger-waterlily-bridge-preserved_5e1cff06.png');
    expect(worker).not.toContain('sahajcontact-sundarbans-tiger-river-waterlily-map-accent_37915533.png');
    expect(worker).not.toContain('sahajcontact-karnafuli-tunnel-night_a02e4af7.webp');
    expect(worker).not.toContain('"/admin/dashboard"');
    expect(worker).toContain('"/admin-manifest.webmanifest"');
    expect(worker).toContain('cacheResponse(request, response.clone())');
    expect(worker).toContain('"/offline.html"');
    expect(worker).toContain('request.mode === "navigate"');
    expect(worker).toContain('url.pathname.startsWith("/api/")');
    expect(worker).toContain('url.pathname.startsWith("/oauth/")');
    expect(worker).toContain('url.pathname.startsWith("/admin")');
    expect(worker).toContain('if (shouldBypassPwaHandling(url)) return;');
    expect(worker).toContain("self.clients.claim()");
    expect(worker.indexOf('caches.match("/offline.html")')).toBeLessThan(worker.indexOf('caches.match("/")'));
    expect(worker).toContain('return offlinePage || cachedPage || caches.match("/")');
  });

  it("provides an offline fallback with Bengali retry guidance", () => {
    const offline = readPublicFile("offline.html");
    expect(offline).toContain('lang="bn"');
    expect(offline).toContain("আপনি এখন অফলাইনে আছেন");
    expect(offline).toContain("আবার চেষ্টা করুন");
    expect(offline).toContain("সহজ জনসেবা, সবার জন্য");
    expect(offline).toContain("ইন্টারনেট সংযোগ পাওয়া যাচ্ছে না");
    expect(offline).toContain("সংযোগ ফিরে এসেছে — এখন চেষ্টা করুন");
    expect(offline).toContain("prefers-reduced-motion");
  });

  it("declares iPhone home-screen metadata and platform-specific install guidance", () => {
    const index = readFileSync(resolve(projectRoot, "client/index.html"), "utf8");
    const installButton = readFileSync(resolve(projectRoot, "client/src/components/PwaInstallButton.tsx"), "utf8");
    const home = readFileSync(resolve(projectRoot, "client/src/pages/Home.tsx"), "utf8");
    const app = readFileSync(resolve(projectRoot, "client/src/App.tsx"), "utf8");
    const splash = readFileSync(resolve(projectRoot, "client/src/components/SahajSplashScreen.tsx"), "utf8");
    const customerGrowthModals = readFileSync(resolve(projectRoot, "client/src/components/CustomerGrowthModals.tsx"), "utf8");
    expect(index).toContain('name="apple-mobile-web-app-capable"');
    expect(index).toContain('name="apple-mobile-web-app-title"');
    expect(index).toContain('rel="apple-touch-icon"');
    expect(index).toContain('/manus-storage/sahajseva-pwa-icon-192_a8abdcbc.png');
    expect(installButton).toContain("beforeinstallprompt");
    expect(installButton).toContain('"standalone" in navigator');
    expect(installButton).toContain("Add to Home Screen");
    expect(installButton).toContain('role="dialog"');
    expect(installButton).toContain("beforeinstallprompt");
    expect(installButton).toContain("appinstalled");
    expect(installButton).toContain("sahajseva-pwa-install-dismissed-until");
    expect(installButton).toContain("window.sessionStorage.getItem(storageKey) === \"dismissed\"");
    expect(installButton).toContain('window.sessionStorage.setItem(storageKey, "dismissed")');
    expect(installButton).not.toContain("INSTALL_DISMISSAL_WINDOW_MS");
    expect(installButton).toContain("pwa-install-banner");
    expect(installButton).toContain("একবার ইনস্টল করলে হোমস্ক্রিন থেকে দ্রুত নাগরিক সেবা খুঁজে পাবেন");
    expect(home).toContain('className="hero-install-reminder"');
    expect(home).toContain("একবার ইনস্টল করুন, হোমস্ক্রিন থেকেই খুলুন");
    expect(home.indexOf("বাংলাদেশ-কেন্দ্রিক নাগরিক সহায়তা")).toBeLessThan(home.indexOf("একবার ইনস্টল করুন, হোমস্ক্রিন থেকেই খুলুন"));
    expect(app).toContain("<SahajSplashScreen />");
    expect(splash).toContain('(display-mode: standalone)');
    expect(splash).toContain('সহজসেবা লোড হচ্ছে');
    expect(splash).toContain('সহজ জনসেবা, সবার জন্য');
    expect(splash).toContain('is-exiting');
    expect(splash).toContain('prefers-reduced-motion');
    expect(home).not.toContain("৫ মিনিটে রিপ্লাই পাবেন");
    expect(customerGrowthModals).toContain("const WELCOME_POPUP_AUTO_OPEN_ENABLED = false;");
    expect(customerGrowthModals).toContain("if (!WELCOME_POPUP_AUTO_OPEN_ENABLED) return;");
  });

  it("exposes a persistent accessible dark-mode control and dark palette", () => {
    const theme = readFileSync(resolve(projectRoot, "client/src/contexts/ThemeContext.tsx"), "utf8");
    const header = readFileSync(resolve(projectRoot, "client/src/components/SahajHeader.tsx"), "utf8");
    const css = readFileSync(resolve(projectRoot, "client/src/index.css"), "utf8");
    const app = readFileSync(resolve(projectRoot, "client/src/App.tsx"), "utf8");
    expect(app).toContain('switchable>');
    expect(theme).toContain('localStorage.getItem("theme")');
    expect(theme).toContain('localStorage.setItem("theme", theme)');
    expect(header).toContain('className="sahaj-theme-toggle"');
    expect(header).toContain('aria-label={theme === "dark" ? "লাইট মোড চালু করুন" : "ডার্ক মোড চালু করুন"}');
    expect(header).toContain("ডার্ক");
    expect(css).toContain(".dark .paid-assistance-section");
    expect(css).toContain(".dark .home-search-banner");
    expect(css).toContain(".dark .faq-section");
  });

  it("registers the service worker only in production after the page loads", () => {
    const main = readFileSync(resolve(projectRoot, "client/src/main.tsx"), "utf8");
    expect(main).toContain("import.meta.env.PROD");
    expect(main).toContain('window.addEventListener("load"');
    expect(main).toContain('navigator.serviceWorker.register("/sw.js", { updateViaCache: "none" })');
    expect(main).toContain('void reg.update()');
  });

  it("switches the document manifest and title to the admin PWA on admin routes", () => {
    const app = readFileSync(resolve(projectRoot, "client/src/App.tsx"), "utf8");
    const html = readFileSync(resolve(projectRoot, "client/index.html"), "utf8");
    const adminManifest = readFileSync(resolve(projectRoot, "client/public/admin-manifest.webmanifest"), "utf8");
    const installButton = readFileSync(resolve(projectRoot, "client/src/components/PwaInstallButton.tsx"), "utf8");

    expect(html).toContain('id="pwa-manifest"');
    expect(app).toContain('"/admin-manifest.webmanifest"');
    expect(app).toContain('location.startsWith("/admin/dashboard")');
    expect(app).toContain("SahajContact Admin | GA4 ও গ্যালারি ব্যবস্থাপনা");
    expect(adminManifest).toContain('"start_url": "/admin/dashboard"');
    expect(adminManifest).toContain('"scope": "/admin/"');
    expect(installButton).toContain("ADMIN_INSTALL_DISMISSAL_KEY");
    expect(installButton).toContain("এটি শুধু অ্যাডমিন ড্যাশবোর্ডের আলাদা অ্যাপ হিসেবে ইনস্টল হবে");
  });

  it("opens the mobile Admin app behind the direct owner password gate, without OAuth", () => {
	const dashboard = readFileSync(resolve(projectRoot, "client/src/pages/AdminAnalyticsDashboard.tsx"), "utf8");

	expect(dashboard).toContain("<AdminSecurityGate>");
	expect(dashboard).toContain("independently verifies the signed HTTP-only session");
	expect(dashboard).not.toContain("passwordSessionQuery");
	expect(dashboard).not.toContain("/api/oauth/start");
  });
});
