import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const utilitySource = readFileSync(new URL("../components/UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");
const sponsorSource = readFileSync(new URL("../pages/SponsorUs.tsx", import.meta.url), "utf8");
const stylesheetSource = readFileSync(new URL("../index.css", import.meta.url), "utf8");
const expatriatePageSource = readFileSync(new URL("../pages/ExpatriateGuidePage.tsx", import.meta.url), "utf8");
const homeSource = readFileSync(new URL("../pages/Home.tsx", import.meta.url), "utf8");
const analyticsSource = readFileSync(new URL("./analytics.ts", import.meta.url), "utf8");
const adminAnalyticsSource = readFileSync(new URL("../pages/AdminAnalyticsDashboard.tsx", import.meta.url), "utf8");

describe("regional expatriate service guide", () => {
  it("offers all requested country options with bilingual labels", () => {
    for (const country of ["bangladesh", "saudi", "italy", "indonesia"]) {
      expect(utilitySource).toContain(`id: "${country}"`);
    }

    for (const label of ["বাংলাদেশ", "সৌদি আরব", "ইতালি", "ইন্দোনেশিয়া", "Bangladesh", "Saudi Arabia", "Italy", "Indonesia"]) {
      expect(utilitySource).toContain(label);
    }
  });

  it("adds the responsive USA and Saudi mission corner with click-to-call and official-source safeguards", () => {
    for (const city of ["Washington, DC", "New York", "Los Angeles", "Riyadh", "Jeddah"]) {
      expect(expatriatePageSource).toContain(`city: "${city}"`);
    }
    expect(expatriatePageSource).toContain("জরুরি প্রয়োজনে সরাসরি কল করুন");
    expect(expatriatePageSource).toContain("href={`tel:${phone.tel}`}");
    expect(expatriatePageSource).toContain("data-utm-campaign=\"embassy_contact\"");
    expect(expatriatePageSource).toContain("https://jeddah.mofa.gov.bd/");
    expect(expatriatePageSource).toContain("কোনো কনস্যুলার সেবা বা সরকারি প্রতিনিধিত্ব করে না");
  });

  it("keeps official guidance, safe-use copy, and tracked selection behavior", () => {
    expect(utilitySource).toContain('id="regional-service-guide-select"');
    expect(utilitySource).toContain('trackEvent("regional_service_guide_select"');
    expect(utilitySource).toContain("শুধু সরকারি ডোমেইনে তথ্য দিন");
    expect(utilitySource).toContain("Never share your passport or OTP with an agent");
    expect(utilitySource).toContain("https://probashi.gov.bd/");
    expect(utilitySource).toContain("https://rome.mofa.gov.bd/");
    expect(utilitySource).toContain("https://jakarta.mofa.gov.bd/");
    expect(utilitySource).toContain('id: "usa"');
    expect(utilitySource).toContain('id: "saudi-arabia"');
    expect(utilitySource).toContain('id: "uae"');
    expect(utilitySource).toContain('id: "italy"');
    expect(utilitySource).toContain("tel:+12022440183");
    expect(utilitySource).toContain("tel:+966114195661");
    expect(utilitySource).toContain("tel:+97124465100");
    expect(utilitySource).toContain("tel:+39068083595");
    expect(utilitySource).toContain('embassy_quick_dial');
    expect(stylesheetSource).toContain(".regional-service-guide");
    expect(stylesheetSource).toContain("@media (max-width: 700px)");
  });
});

describe("homepage story submission and automatic UTM tracking", () => {
  it("offers a real story submission path without fabricated testimonials", () => {
    expect(homeSource).toContain('aria-labelledby="your-story-title"');
    expect(homeSource).toContain("আপনার গল্প শেয়ার করুন");
    expect(homeSource).toContain("যাচাই ও অনুমোদনের পরই কোনো গল্প প্রকাশ করা হবে");
    expect(homeSource).toContain("কোনো ডেমো বা বানানো testimonial দেখানো হচ্ছে না");
    // amirhamja913@gmail.com is now correctly displayed in the contact and footer sections as requested by the owner.
  });

  it("decorates external links with the requested campaign parameters and explains them to the owner", () => {
    expect(analyticsSource).toContain("buildOutboundUrl");
    expect(analyticsSource).toContain('OUTBOUND_UTM_SOURCE = "sahajcontact"');
    expect(analyticsSource).toContain('OUTBOUND_UTM_MEDIUM = "button"');
    expect(analyticsSource).toContain("installOutboundUtmTracking");
    expect(adminAnalyticsSource).toContain("অটো UTM");
    expect(adminAnalyticsSource).toContain("utm_campaign");
  });
});

describe("public institutional collaboration route", () => {
  it("does not publish hard-coded GA4 snapshots or performance claims", () => {
    expect(sponsorSource).not.toContain('range: "আগস্ট ২০২৬"');
    expect(sponsorSource).not.toContain('views: "290"');
    expect(sponsorSource).not.toContain('events: "3,946"');
    expect(sponsorSource).not.toContain('sessions: "14"');
    expect(sponsorSource).not.toContain("Google Analytics স্ক্রিনশট থেকে নেওয়া");
    expect(sponsorSource).not.toContain("stats?.newUsers");
  });

  it("uses a review-first institutional inquiry path without direct payment collection", () => {
    expect(sponsorSource).toContain('href="/ngo-partnership"');
    expect(sponsorSource).toContain("review-first");
    expect(sponsorSource).toContain("কোনো অংশীদারিত্ব, অনুমোদন বা প্রকাশ্য তালিকাভুক্তি নয়");
    expect(sponsorSource).not.toContain('id="contact-form"');
    expect(sponsorSource).not.toContain("wa.me/8801965177538");
    expect(sponsorSource).not.toContain("bKash");
    expect(sponsorSource).not.toContain("Nagad");
  });
});
