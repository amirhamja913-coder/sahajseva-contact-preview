import { describe, expect, it } from "vitest";
import { SITE_WIDE_REVIEW_ID, siteWideReviewIds } from "./reviewScopes";

describe("site-wide review scope", () => {
  it("uses one reserved review ID for the consolidated feedback section", () => {
    expect(SITE_WIDE_REVIEW_ID).toBe("00");
    expect(siteWideReviewIds).toEqual(["00"]);
  });
});
