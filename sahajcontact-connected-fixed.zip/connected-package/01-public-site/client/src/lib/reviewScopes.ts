export const SITE_WIDE_REVIEW_ID = "00";
export const siteWideReviewIds = [SITE_WIDE_REVIEW_ID];
