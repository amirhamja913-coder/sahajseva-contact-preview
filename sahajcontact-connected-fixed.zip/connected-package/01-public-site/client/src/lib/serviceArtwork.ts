export type ServiceArtwork = {
  src: string;
  label: string;
};

const artwork = {
  passport: {
    src: "/manus-storage/sahaj-service-passport_d7a60e9f.png",
    label: "রঙিন পাসপোর্ট ও ভ্রমণ নথির চিত্র",
  },
  registration: {
    src: "/manus-storage/sahaj-service-registration_83ce66b3.png",
    label: "রঙিন জন্ম নিবন্ধন ও পরিচয় নথির চিত্র",
  },
  police: {
    src: "/manus-storage/sahaj-service-police_8d2fac40.png",
    label: "রঙিন থানা ও নাগরিক সহায়তা চিত্র",
  },
  health: {
    src: "/manus-storage/sahaj-service-health-social_192884ae.png",
    label: "রঙিন স্বাস্থ্য ও সামাজিক সহায়তা চিত্র",
  },
  civic: {
    src: "/manus-storage/sahaj-service-civic-office_4599be9d.png",
    label: "রঙিন নাগরিক ও সরকারি অফিস সেবার চিত্র",
  },
  transport: {
    src: "/manus-storage/sahaj-service-transport_a825203d.png",
    label: "রঙিন পরিবহন ও যাতায়াত সেবার চিত্র",
  },
  education: {
    src: "/manus-storage/sahaj-service-education-work_5623175b.png",
    label: "রঙিন শিক্ষা ও কর্মসংস্থান সেবার চিত্র",
  },
  land: {
    src: "/manus-storage/sahaj-service-land-utility-agri_e2c1a233.png",
    label: "রঙিন ভূমি, ইউটিলিটি ও কৃষি সেবার চিত্র",
  },
} satisfies Record<string, ServiceArtwork>;

export function getServiceArtwork(title: string, tag = ""): ServiceArtwork {
  const query = `${title} ${tag}`.toLocaleLowerCase("bn-BD");

  if (/(পাসপোর্ট|ই-পাসপোর্ট|ভিসা|প্রবাস|passport|visa)/i.test(query)) return artwork.passport;
  if (/(জন্ম|মৃত্যু|নিবন্ধন|জাতীয় পরিচয়|এনআইডি|nid|birth|registration)/i.test(query)) return artwork.registration;
  if (/(থানা|পুলিশ|অভিযোগ|নিরাপত্তা|police|station)/i.test(query)) return artwork.police;
  if (/(হাসপাতাল|স্বাস্থ্য|চিকিৎসা|প্রতিবন্ধী|সমাজসেবা|health|hospital|medical)/i.test(query)) return artwork.health;
  if (/(শিক্ষা|স্কুল|কলেজ|বিশ্ববিদ্যালয়|চাকরি|কর্মসংস্থান|education|job|work)/i.test(query)) return artwork.education;
  if (/(সিটি কর্পোরেশন|পৌরসভা|স্থানীয় সরকার|ট্রেড লাইসেন্স|trade licen[cs]e|city corporation|municipality|local government)/i.test(query)) return artwork.civic;
  if (/(ড্রাইভিং|গাড়ি|যানবাহন|পরিবহন|transport|vehicle|licen[cs]e)/i.test(query)) return artwork.transport;
  if (/(ভূমি|জমি|কৃষি|বিদ্যুৎ|গ্যাস|পানি|utility|land|agri|electric)/i.test(query)) return artwork.land;
  return artwork.civic;
}
