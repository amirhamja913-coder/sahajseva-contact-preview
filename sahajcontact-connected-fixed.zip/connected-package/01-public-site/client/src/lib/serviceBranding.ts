import type { CivicService } from "./newCivicServices";
import type { SiteLanguage } from "@/contexts/LanguageContext";
import { Banknote, BriefcaseBusiness, CheckCircle2, ClipboardCheck, CloudSun, FileText, Globe2, HeartHandshake, Landmark, Phone, Plane, Scale, ShieldAlert, ShieldCheck, Smartphone, Sprout, Ticket, WalletCards, Waves, Wheat } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export type ServiceBranding = {
  /** Short visual identifier, not an official logo. */
  mark: string;
  /** Human-readable source or responsible department. */
  departmentName: string;
  /** Stable CSS accent used to distinguish the service source. */
  accent: string;
  /** Soft tint used behind the identifier badge. */
  tint: string;
  /** Semantic visual mark; this is an interface icon, not an official government logo. */
  icon?: LucideIcon;
  /** Accessible Bengali description for the semantic icon. */
  iconLabel?: string;
};

const defaultBranding: ServiceBranding = {
  mark: "সেবা",
  departmentName: "বাংলাদেশ জাতীয় তথ্য বাতায়ন / সংশ্লিষ্ট দপ্তর",
  accent: "#0f766e",
  tint: "#e4f2ee",
  icon: Landmark,
  iconLabel: "সরকারি সেবা",
};

const brandingByNumber: Record<string, ServiceBranding> = {
  "01": { mark: "তথ্য", departmentName: "বাংলাদেশ জাতীয় তথ্য বাতায়ন", accent: "#0f766e", tint: "#e4f2ee" },
  "02": { mark: "পু", departmentName: "বাংলাদেশ পুলিশ", accent: "#123b63", tint: "#e8eef6" },
  "03": { mark: "নারী", departmentName: "মহিলা ও শিশু বিষয়ক মন্ত্রণালয়", accent: "#a21caf", tint: "#fae8ff" },
  "04": { mark: "সমাজ", departmentName: "সমাজসেবা অধিদপ্তর", accent: "#15803d", tint: "#e8f7ed" },
  "05": { mark: "সমাজ", departmentName: "সমাজসেবা অধিদপ্তর", accent: "#15803d", tint: "#e8f7ed" },
  "06": { mark: "সমাজ", departmentName: "সমাজসেবা অধিদপ্তর", accent: "#15803d", tint: "#e8f7ed" },
  "07": { mark: "ভাতা", departmentName: "সমাজকল্যাণ মন্ত্রণালয় / myGov", accent: "#0f766e", tint: "#e4f2ee" },
  "08": { mark: "বিমান", departmentName: "বিমান বাংলাদেশ এয়ারলাইন্স", accent: "#075985", tint: "#e0f2fe" },
  "09": { mark: "রেল", departmentName: "বাংলাদেশ রেলওয়ে", accent: "#b91c1c", tint: "#fee2e2" },
  "10": { mark: "BRTC", departmentName: "বাংলাদেশ সড়ক পরিবহন কর্পোরেশন", accent: "#1d4ed8", tint: "#dbeafe" },
  "11": { mark: "স্বাস্থ্য", departmentName: "স্বাস্থ্য অধিদপ্তর", accent: "#047857", tint: "#d1fae5" },
  "12": { mark: "স্বাস্থ্য", departmentName: "স্বাস্থ্য অধিদপ্তর", accent: "#047857", tint: "#d1fae5" },
  "13": { mark: "ইউপি", departmentName: "বাংলাদেশ জাতীয় তথ্য বাতায়ন / ইউনিয়ন পরিষদ", accent: "#0f766e", tint: "#e4f2ee" },
  "14": { mark: "জেলা", departmentName: "জেলা প্রশাসকের কার্যালয়", accent: "#1e3a8a", tint: "#e0e7ff" },
  "15": { mark: "ইউটি", departmentName: "সংশ্লিষ্ট বিদ্যুৎ, গ্যাস ও পানি সেবা দপ্তর", accent: "#a16207", tint: "#fef3c7" },
  "16": { mark: "সহায়তা", departmentName: "বাংলাদেশ জাতীয় তথ্য বাতায়ন / myGov", accent: "#0f766e", tint: "#e4f2ee" },
  "17": { mark: "NID", departmentName: "বাংলাদেশ নির্বাচন কমিশন — জাতীয় পরিচয় নিবন্ধন অনুবিভাগ", accent: "#c2410c", tint: "#ffedd5" },
  "18": { mark: "পাসপোর্ট", departmentName: "ইমিগ্রেশন ও পাসপোর্ট অধিদপ্তর", accent: "#9f1239", tint: "#ffe4e6" },
  "19": { mark: "আবেদন", departmentName: "বাংলাদেশ জাতীয় তথ্য বাতায়ন", accent: "#0f766e", tint: "#e4f2ee" },
  "20": { mark: "আইন", departmentName: "জাতীয় আইনগত সহায়তা সংস্থা (NLASO)", accent: "#7c3aed", tint: "#ede9fe" },
  "21": { mark: "প্রবাসী", departmentName: "প্রবাসী কল্যাণ ও বৈদেশিক কর্মসংস্থান মন্ত্রণালয়", accent: "#0369a1", tint: "#e0f2fe" },
  "22": { mark: "BTV", departmentName: "বাংলাদেশ টেলিভিশন", accent: "#b91c1c", tint: "#fee2e2" },
  "23": { mark: "বেতার", departmentName: "বাংলাদেশ বেতার", accent: "#9a3412", tint: "#ffedd5" },
  "24": { mark: "প্রাথমিক", departmentName: "প্রাথমিক শিক্ষা অধিদপ্তর", accent: "#15803d", tint: "#e8f7ed" },
  "25": { mark: "মাধ্যমিক", departmentName: "মাধ্যমিক ও উচ্চশিক্ষা অধিদপ্তর", accent: "#4338ca", tint: "#e0e7ff" },
  "26": { mark: "মাদ্রাসা", departmentName: "বাংলাদেশ মাদ্রাসা শিক্ষা বোর্ড", accent: "#0f766e", tint: "#e4f2ee" },
  "27": { mark: "চাকরি", departmentName: "বাংলাদেশ সরকারি নিয়োগের Teletalk পোর্টাল", accent: "#c2410c", tint: "#ffedd5" },
  "28": { mark: "BPSC", departmentName: "বাংলাদেশ সরকারি কর্ম কমিশন", accent: "#1e3a8a", tint: "#e0e7ff" },
  "29": { mark: "BTCL", departmentName: "বাংলাদেশ টেলিকমিউনিকেশন্স কোম্পানি লিমিটেড", accent: "#0369a1", tint: "#e0f2fe" },
  "30": { mark: "BRTC", departmentName: "বাংলাদেশ সড়ক পরিবহন কর্পোরেশন", accent: "#1d4ed8", tint: "#dbeafe" },
  "31": { mark: "NID", departmentName: "বাংলাদেশ নির্বাচন কমিশন — জাতীয় পরিচয় নিবন্ধন অনুবিভাগ", accent: "#c2410c", tint: "#ffedd5" },
  "32": { mark: "পাসপোর্ট", departmentName: "ইমিগ্রেশন ও পাসপোর্ট অধিদপ্তর", accent: "#9f1239", tint: "#ffe4e6" },
  "33": { mark: "জন্ম", departmentName: "জন্ম ও মৃত্যু নিবন্ধন রেজিস্ট্রার জেনারেলের কার্যালয়", accent: "#c2410c", tint: "#ffedd5" },
  "34": { mark: "ভূমি", departmentName: "ভূমি মন্ত্রণালয়", accent: "#4338ca", tint: "#e0e7ff" },
  "35": { mark: "কৃষি", departmentName: "কৃষি সম্প্রসারণ অধিদপ্তর", accent: "#15803d", tint: "#e8f7ed" },
  "36": { mark: "ভাতা", departmentName: "সমাজসেবা অধিদপ্তর", accent: "#15803d", tint: "#e8f7ed" },
  "37": { mark: "ট্রেড", departmentName: "স্থানীয় সরকার বিভাগ / সিটি কর্পোরেশন ও পৌরসভা", accent: "#0f766e", tint: "#e4f2ee" },
  "38": { mark: "BRTA", departmentName: "বাংলাদেশ সড়ক পরিবহন কর্তৃপক্ষ", accent: "#1d4ed8", tint: "#dbeafe" },
  "39": { mark: "চাকরি", departmentName: "বাংলাদেশ সরকারি নিয়োগের Teletalk পোর্টাল", accent: "#c2410c", tint: "#ffedd5" },
  "40": { mark: "BPSC", departmentName: "বাংলাদেশ সরকারি কর্ম কমিশন", accent: "#1e3a8a", tint: "#e0e7ff" },
};

const iconByNumber: Record<string, { icon: LucideIcon; iconLabel: string }> = {
  "01": { icon: Landmark, iconLabel: "নাগরিক সেবা" },
  "02": { icon: ShieldAlert, iconLabel: "থানা ও নিরাপত্তা" },
  "03": { icon: HeartHandshake, iconLabel: "নারী ও শিশু সহায়তা" },
  "04": { icon: WalletCards, iconLabel: "সমাজসেবা" },
  "05": { icon: WalletCards, iconLabel: "প্রতিবন্ধী ভাতা" },
  "06": { icon: WalletCards, iconLabel: "বয়স্ক ও বিধবা ভাতা" },
  "07": { icon: Banknote, iconLabel: "সরকারি ভাতা" },
  "08": { icon: Plane, iconLabel: "বিমান সেবা" },
  "09": { icon: Ticket, iconLabel: "রেল টিকেট" },
  "10": { icon: Landmark, iconLabel: "BRTC বাস সেবা" },
  "11": { icon: ShieldCheck, iconLabel: "হাসপাতাল ও স্বাস্থ্য" },
  "12": { icon: CloudSun, iconLabel: "স্বাস্থ্য তথ্য" },
  "13": { icon: Landmark, iconLabel: "ইউনিয়ন ও স্থানীয় সেবা" },
  "14": { icon: Landmark, iconLabel: "জেলা প্রশাসন" },
  "15": { icon: Waves, iconLabel: "বিদ্যুৎ গ্যাস পানি" },
  "16": { icon: HeartHandshake, iconLabel: "সরকারি সহায়তা" },
  "17": { icon: ClipboardCheck, iconLabel: "জাতীয় পরিচয়পত্র" },
  "18": { icon: FileText, iconLabel: "ই-পাসপোর্ট" },
  "19": { icon: FileText, iconLabel: "অনলাইন আবেদন" },
  "20": { icon: Scale, iconLabel: "আইনগত সহায়তা" },
  "21": { icon: Plane, iconLabel: "প্রবাসী সেবা" },
  "22": { icon: Globe2, iconLabel: "বাংলাদেশ টেলিভিশন" },
  "23": { icon: Waves, iconLabel: "বাংলাদেশ বেতার" },
  "24": { icon: FileText, iconLabel: "প্রাথমিক শিক্ষা" },
  "25": { icon: FileText, iconLabel: "মাধ্যমিক উচ্চশিক্ষা" },
  "26": { icon: FileText, iconLabel: "মাদ্রাসা শিক্ষা" },
  "27": { icon: BriefcaseBusiness, iconLabel: "সরকারি চাকরি" },
  "28": { icon: CheckCircle2, iconLabel: "সরকারি কর্ম কমিশন" },
  "29": { icon: Smartphone, iconLabel: "টেলিযোগাযোগ" },
  "30": { icon: Landmark, iconLabel: "সরকারি পরিবহন" },
  "31": { icon: ClipboardCheck, iconLabel: "জাতীয় পরিচয়পত্র" },
  "32": { icon: FileText, iconLabel: "ই-পাসপোর্ট" },
  "33": { icon: ClipboardCheck, iconLabel: "জন্ম ও মৃত্যু নিবন্ধন" },
  "34": { icon: Landmark, iconLabel: "ভূমি সেবা" },
  "35": { icon: Sprout, iconLabel: "কৃষি সেবা" },
  "36": { icon: WalletCards, iconLabel: "সামাজিক ভাতা" },
  "37": { icon: BriefcaseBusiness, iconLabel: "ট্রেড লাইসেন্স" },
  "38": { icon: Ticket, iconLabel: "ড্রাইভিং ও পরিবহন" },
  "39": { icon: BriefcaseBusiness, iconLabel: "সরকারি চাকরি" },
  "40": { icon: CheckCircle2, iconLabel: "সরকারি কর্ম কমিশন" },
};

const englishBrandingByNumber: Record<string, Pick<ServiceBranding, "mark" | "departmentName" | "iconLabel">> = {
  "01": { mark: "Info", departmentName: "Bangladesh National Information Portal", iconLabel: "Civic services" },
  "02": { mark: "Police", departmentName: "Bangladesh Police", iconLabel: "Police and safety" },
  "03": { mark: "Women", departmentName: "Ministry of Women and Children Affairs", iconLabel: "Women and children support" },
  "04": { mark: "Social", departmentName: "Department of Social Services", iconLabel: "Social services" },
  "05": { mark: "Disability", departmentName: "Department of Social Services", iconLabel: "Disability allowance" },
  "06": { mark: "Allowance", departmentName: "Department of Social Services", iconLabel: "Old-age and widow allowance" },
  "07": { mark: "Benefits", departmentName: "Ministry of Social Welfare / myGov", iconLabel: "Government allowance" },
  "08": { mark: "Air", departmentName: "Biman Bangladesh Airlines", iconLabel: "Air service" },
  "09": { mark: "Rail", departmentName: "Bangladesh Railway", iconLabel: "Train tickets" },
  "10": { mark: "BRTC", departmentName: "Bangladesh Road Transport Corporation", iconLabel: "BRTC bus service" },
  "11": { mark: "Health", departmentName: "Directorate General of Health Services", iconLabel: "Hospital and health" },
  "12": { mark: "Health", departmentName: "Directorate General of Health Services", iconLabel: "Health information" },
  "13": { mark: "Union", departmentName: "Bangladesh National Information Portal / Union Parishad", iconLabel: "Union and local services" },
  "14": { mark: "District", departmentName: "District Commissioner’s Office", iconLabel: "District administration" },
  "15": { mark: "Utilities", departmentName: "Electricity, gas, and water authorities", iconLabel: "Electricity, gas, and water" },
  "16": { mark: "Support", departmentName: "Bangladesh National Information Portal / myGov", iconLabel: "Government support" },
  "17": { mark: "NID", departmentName: "Bangladesh Election Commission — NID Wing", iconLabel: "National identity card" },
  "18": { mark: "Passport", departmentName: "Department of Immigration and Passports", iconLabel: "E-passport" },
  "19": { mark: "Apply", departmentName: "Bangladesh National Information Portal", iconLabel: "Online application" },
  "20": { mark: "Legal", departmentName: "National Legal Aid Services Organization (NLASO)", iconLabel: "Legal aid" },
  "21": { mark: "Expatriate", departmentName: "Ministry of Expatriates’ Welfare and Overseas Employment", iconLabel: "Expatriate services" },
  "22": { mark: "BTV", departmentName: "Bangladesh Television", iconLabel: "Bangladesh Television" },
  "23": { mark: "Radio", departmentName: "Bangladesh Betar", iconLabel: "Bangladesh Betar" },
  "24": { mark: "Primary", departmentName: "Directorate of Primary Education", iconLabel: "Primary education" },
  "25": { mark: "School", departmentName: "Directorate of Secondary and Higher Education", iconLabel: "Secondary and higher education" },
  "26": { mark: "Madrasa", departmentName: "Bangladesh Madrasah Education Board", iconLabel: "Madrasa education" },
  "27": { mark: "Jobs", departmentName: "Bangladesh government recruitment Teletalk portal", iconLabel: "Government jobs" },
  "28": { mark: "BPSC", departmentName: "Bangladesh Public Service Commission", iconLabel: "Public Service Commission" },
  "29": { mark: "BTCL", departmentName: "Bangladesh Telecommunications Company Limited", iconLabel: "Telecommunications" },
  "30": { mark: "BRTC", departmentName: "Bangladesh Road Transport Corporation", iconLabel: "Public transport" },
  "31": { mark: "NID", departmentName: "Bangladesh Election Commission — NID Wing", iconLabel: "National identity card" },
  "32": { mark: "Passport", departmentName: "Department of Immigration and Passports", iconLabel: "E-passport" },
  "33": { mark: "Birth", departmentName: "Office of the Registrar General, Birth and Death Registration", iconLabel: "Birth and death registration" },
  "34": { mark: "Land", departmentName: "Ministry of Land", iconLabel: "Land services" },
  "35": { mark: "Agriculture", departmentName: "Department of Agricultural Extension", iconLabel: "Agricultural services" },
  "36": { mark: "Allowance", departmentName: "Department of Social Services", iconLabel: "Social allowance" },
  "37": { mark: "Trade", departmentName: "Local Government Division / City corporations and municipalities", iconLabel: "Trade licence" },
  "38": { mark: "BRTA", departmentName: "Bangladesh Road Transport Authority", iconLabel: "Driving and transport" },
  "39": { mark: "Jobs", departmentName: "Bangladesh government recruitment Teletalk portal", iconLabel: "Government jobs" },
  "40": { mark: "BPSC", departmentName: "Bangladesh Public Service Commission", iconLabel: "Public Service Commission" },
};

const departmentColor = (branding: ServiceBranding): Pick<ServiceBranding, "accent" | "tint"> => {
  const departmentText = `${branding.departmentName} ${branding.mark}`;

  if (/(সমাজসেবা|সমাজকল্যাণ|ভাতা)/.test(departmentText)) {
    return { accent: "#006A4E", tint: "#E8F5E9" };
  }

  if (/(নির্বাচন কমিশন|NID)/i.test(departmentText)) {
    return { accent: "#D32F2F", tint: "#FFEBEE" };
  }

  if (/(পাসপোর্ট|পররাষ্ট্র|ইমিগ্রেশন)/.test(departmentText)) {
    return { accent: "#1976D2", tint: "#E3F2FD" };
  }

  if (/পুলিশ/.test(departmentText)) {
    return { accent: "#0D47A1", tint: "#E1F5FE" };
  }

  if (/(জন্ম|মৃত্যু নিবন্ধন)/.test(departmentText)) {
    return { accent: "#F57C00", tint: "#FFF3E0" };
  }

  return { accent: branding.accent, tint: branding.tint };
};

export function getServiceBranding(service: Pick<CivicService, "number">): ServiceBranding & { icon: LucideIcon; iconLabel: string } {
  const branding = brandingByNumber[service.number] ?? defaultBranding;
  const icon = iconByNumber[service.number] ?? { icon: defaultBranding.icon ?? Landmark, iconLabel: defaultBranding.iconLabel ?? "সরকারি সেবা" };
  return { ...branding, ...departmentColor(branding), ...icon };
}

export function getLocalizedServiceBranding(service: Pick<CivicService, "number">, language: SiteLanguage): ServiceBranding & { icon: LucideIcon; iconLabel: string } {
  const branding = getServiceBranding(service);
  if (language === "BN") return branding;
  const english = englishBrandingByNumber[service.number];
  if (!english) throw new Error(`Missing English branding for service ${service.number}`);
  return { ...branding, ...english };
}

export function hasServiceBranding(service: Pick<CivicService, "number">): boolean {
  return Boolean(brandingByNumber[service.number]);
}
