import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { shouldHideMobileFloatingActions } from "@/hooks/useServiceFinderVisibility";

const homeSource = readFileSync(new URL("../pages/Home.tsx", import.meta.url), "utf8");
const customerGrowthSource = readFileSync(new URL("../components/CustomerGrowthModals.tsx", import.meta.url), "utf8");
const chatWidgetSource = readFileSync(new URL("../components/SahajCivicChatWidget.tsx", import.meta.url), "utf8");
const serviceReviewsSource = readFileSync(new URL("../components/ServiceReviews.tsx", import.meta.url), "utf8");

describe("mobile Service Finder safety and review integration", () => {
  it("hides bottom floating actions only when a compact viewport is viewing the Service Finder", () => {
    expect(shouldHideMobileFloatingActions(true, true)).toBe(true);
    expect(shouldHideMobileFloatingActions(true, false)).toBe(false);
    expect(shouldHideMobileFloatingActions(false, true)).toBe(false);
  });

  it("targets the existing services anchor and gates both bottom widget families", () => {
    expect(homeSource).toContain('<section id="services" className="services-section section-paper">');
    expect(customerGrowthSource).toContain("useServiceFinderVisibility");
    expect(customerGrowthSource).toContain("!hideFloatingActions");
    expect(chatWidgetSource).toContain("useServiceFinderVisibility");
    expect(chatWidgetSource).toContain("!hideFloatingActions");
  });

  it("keeps the approved-review summary, authenticated submission gate, and moderation copy on each service", () => {
    expect(homeSource).toContain("trpc.reviews.listApproved.useQuery");
    expect(homeSource).toContain("<ServiceReviews");
    expect(serviceReviewsSource).toContain("মতামত জমা দিন");
    expect(serviceReviewsSource).toContain("অনুমোদনের পর এটি সবার জন্য দেখা যাবে");
    expect(serviceReviewsSource).toContain("বাস্তব অভিজ্ঞতা শেয়ার করুন। যাচাইয়ের পর প্রকাশিত হবে।");
  });
});
