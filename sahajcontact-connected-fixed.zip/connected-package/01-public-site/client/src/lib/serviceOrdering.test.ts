import { describe, expect, it } from "vitest";
import { getServiceSearchTerms, getServiceCountLabel, includesServiceTerm, orderServicesByNumber } from "./serviceOrdering";

describe("service directory ordering", () => {
  it("sorts numbered services numerically without mutating the source", () => {
    const source = [{ number: "10" }, { number: "02" }, { number: "30" }, { number: "01" }];

    expect(orderServicesByNumber(source).map((service) => service.number)).toEqual(["01", "02", "10", "30"]);
    expect(source.map((service) => service.number)).toEqual(["10", "02", "30", "01"]);
  });

  it("normalizes Bengali and Latin search terms consistently", () => {
    expect(getServiceSearchTerms(" BTCL  ডোমেইন ")).toEqual(["btcl", "ডোমেইন"]);
    expect(includesServiceTerm({ title: "BRTC বাস", tag: "সরকারি পরিবহন", text: "বাস সেবা" }, ["brtc"])).toBe(true);
    expect(getServiceCountLabel(30)).toBe("৩০টি সেবা");
  });
});
