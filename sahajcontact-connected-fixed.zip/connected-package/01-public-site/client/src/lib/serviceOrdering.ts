export type NumberedService = {
  number: string;
};

/** Keeps numbered civic-service entries in numeric order without mutating the source array. */
export function orderServicesByNumber<T extends NumberedService>(services: T[]): T[] {
  return [...services].sort((left, right) => Number(left.number) - Number(right.number));
}

export function getServiceCountLabel(count: number): string {
  const bengaliDigits = String(count).replace(/[0-9]/g, (digit) => "০১২৩৪৫৬৭৮৯"[Number(digit)]);
  return `${bengaliDigits}টি সেবা`;
}

export function includesServiceTerm(service: { title: string; tag: string; text: string }, terms: string[]): boolean {
  const searchText = `${service.title} ${service.tag} ${service.text}`.toLocaleLowerCase("bn").replace(/[য়য়]/g, "য়");
  return terms.every((term) => searchText.includes(term));
}

export function getServiceSearchTerms(query: string): string[] {
  return query.toLocaleLowerCase("bn").replace(/[য়য়]/g, "য়").split(/\s+/).filter(Boolean);
}
