import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const indexHtml = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");

describe("SahajContact share metadata", () => {
  it("declares current Bengali title and description for Open Graph and Twitter", () => {
    expect(indexHtml).toContain('property="og:title" content="SahajContact | সহজ জনসেবা পোর্টাল"');
    expect(indexHtml).toContain('name="twitter:title" content="SahajContact | সহজ জনসেবা পোর্টাল"');
    expect(indexHtml).toContain('property="og:description"');
    expect(indexHtml).toContain('name="twitter:description"');
  });

  it("uses the current Karnafuli preview image with a cache-busting version", () => {
    expect(indexHtml).toContain('property="og:image" content="https://sahajcontact-8xyxsefc.manus.space/manus-storage/sahajcontact-karnafuli-tunnel-night-title-only_746eb20e.png?v=20260820-title-only"');
    expect(indexHtml).toContain('name="twitter:image" content="https://sahajcontact-8xyxsefc.manus.space/manus-storage/sahajcontact-karnafuli-tunnel-night-title-only_746eb20e.png?v=20260820-title-only"');
  });
});
