import { describe, it, expect } from "vitest";
import { OUTBOUND_LINK_FALLBACK_PATH, PARTNER_DISCLOSURE, toolItems } from "@/pages/Tools";

describe("tools multi-merchant destinations", () => {
  it("includes reputable merchants and telecom operators across four categories", () => {
    expect(toolItems).toHaveLength(4);
    for (const item of toolItems) {
      expect(item.merchants.length).toBeGreaterThan(0);
      for (const m of item.merchants) {
        expect(m.url.startsWith("https://")).toBe(true);
        expect(m.name).toBeTruthy();
      }
    }
  });

  it("provides a safe help fallback for unavailable outbound links", () => {
    expect(OUTBOUND_LINK_FALLBACK_PATH).toBe("/help");
  });

  it("shows the requested non-affiliation disclosure", () => {
    expect(PARTNER_DISCLOSURE).toBe("আমরা Star Tech, Ryans, Daraz এর অফিসিয়াল পার্টনার না। শুধু গ্রাহকদের সুবিধার জন্য লিংক দিয়েছি।");
  });

  it("does not invent affiliate identifiers", () => {
    const allUrls = toolItems.flatMap((item) => item.merchants.map((m) => m.url));
    expect(allUrls.every((url) => !/[?&](aff|affiliate|utm_|ref)/i.test(url))).toBe(true);
  });
});
