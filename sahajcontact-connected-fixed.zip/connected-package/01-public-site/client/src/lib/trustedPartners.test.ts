import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const homeSource = readFileSync(new URL("../pages/Home.tsx", import.meta.url), "utf8");
const renderedSafetyPolicySource = homeSource.slice(
  homeSource.indexOf("trusted-partners-section"),
  homeSource.indexOf("<PublicSeoSnapshot")
);

describe("Public commercial safety policy", () => {
  it("renders a neutral safety policy instead of unverified commercial partner badges", () => {
    expect(renderedSafetyPolicySource).toContain("নিরাপদ সেবা নীতিমালা");
    expect(renderedSafetyPolicySource).toContain("কোনো payment gateway নেই");
    expect(renderedSafetyPolicySource).toContain("সরকারি ফি ব্যক্তিগত অ্যাকাউন্টে দেবেন না");
    expect(renderedSafetyPolicySource).not.toContain("SahajContact এর অফিসিয়াল ডিজিটাল সেবা পার্টনার");
    expect(renderedSafetyPolicySource).not.toContain("Western Union");
    expect(renderedSafetyPolicySource).not.toContain("Grameenphone");
  });

  it("discloses that named commercial affiliations require formal verification", () => {
    expect(renderedSafetyPolicySource).toContain("আনুষ্ঠানিকভাবে যাচাই ও প্রকাশ না করা পর্যন্ত SahajContact কোনো payment, remittance বা telecom provider-এর অংশীদারিত্বের দাবি করে না।");
  });

  it("is placed immediately before the footer component", () => {
    const partnerIndex = homeSource.indexOf("trusted-partners-section");
    const footerIndex = homeSource.indexOf("<SahajFooter />");
    expect(partnerIndex).toBeGreaterThan(-1);
    expect(footerIndex).toBeGreaterThan(partnerIndex);
  });
});
