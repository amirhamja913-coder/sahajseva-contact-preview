import { describe, expect, it } from "vitest";
import { BANGLADESH_GALLERY_ITEMS } from "../data/bangladeshGallery";

describe("2024 Bangladesh mass-uprising gallery update", () => {
  it("includes two respectful, bilingual 2024 victory and movement cards", () => {
    const items = BANGLADESH_GALLERY_ITEMS.filter(item =>
      item.id.startsWith("culture-2024-"),
    );

    expect(items.map(item => item.id)).toEqual([
      "culture-2024-victory-celebration",
      "culture-2024-public-movement",
    ]);

    for (const item of items) {
      expect(item.category).toBe("culture");
      expect(item.titleBn).toContain("২০২৪");
      expect(item.titleEn).toContain("2024");
      expect(item.captionBn.length).toBeGreaterThan(0);
      expect(item.captionEn.length).toBeGreaterThan(0);
      expect(item.imageUrl).toMatch(/^\/manus-storage\//);
      expect(item.creditUrl).toContain("commons.wikimedia.org");
    }
  });

  it("replaces the former Payra card with a Bangladesh National Museum image", () => {
    const museum = BANGLADESH_GALLERY_ITEMS.find(
      item => item.id === "culture-national-museum",
    );

    expect(museum?.imageUrl).toBe("/manus-storage/bangladesh-national-museum_84610abf.webp");
    expect(museum?.imageUrl).not.toContain("payra-thermal");
    expect(museum?.creditUrl).toContain("DG_91_-_09_NATIONAL_MUSEUM_DHAKA_IMG_3171");
  });

  it("does not retain a gallery title, caption, or image path naming the removed person", () => {
    const searchableText = BANGLADESH_GALLERY_ITEMS
      .map(item =>
        [item.titleBn, item.titleEn, item.captionBn, item.captionEn, item.imageUrl]
          .join(" ")
          .toLowerCase(),
      )
      .join(" ");

    expect(searchableText).not.toContain("sheikh hasina");
    expect(searchableText).not.toContain("শেখ হাসিনা");
  });
});
