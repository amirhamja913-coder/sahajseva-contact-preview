// Utility to append campaign UTM parameters to official government links
// Example: nid.gov.bd?utm_source=sahajsheba&utm_medium=usa&utm_campaign=citizen_services

export function getUtmUrl(baseUrl: string, serviceName: string, medium = "web"): string {
  try {
    const url = new URL(baseUrl.startsWith("http") ? baseUrl : `https://${baseUrl}`);
    
    // Detect visitor country or fallback to global/website source
    // medium can be 'usa', 'uae', 'it', 'id', 'bd', or region code
    url.searchParams.set("utm_source", "sahajsheba");
    url.searchParams.set("utm_medium", medium);
    url.searchParams.set("utm_campaign", serviceName.toLowerCase().replace(/\s+/g, "_"));
    
    return url.toString();
  } catch (e) {
    // Fallback if URL parsing fails
    const sep = baseUrl.includes("?") ? "&" : "?";
    return `${baseUrl}${sep}utm_source=sahajsheba&utm_medium=${medium}&utm_campaign=${encodeURIComponent(serviceName)}`;
  }
}
