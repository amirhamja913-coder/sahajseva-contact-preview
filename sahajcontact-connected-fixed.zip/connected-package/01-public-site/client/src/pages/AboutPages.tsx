import React from "react";
import { Link } from "wouter";
import SahajHeader from "@/components/SahajHeader";
import SahajFooter from "@/components/SahajFooter";
import { ArrowLeft, CheckCircle, ShieldCheck, TrendingUp, Users, HeartHandshake } from "lucide-react";

export function AboutProblem() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <SahajHeader />
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-blue-700 hover:text-blue-900 font-medium">
            <ArrowLeft size={16} className="mr-1" /> হোমে ফিরে যান
          </Link>
        </div>

        <article className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-10">
          <div className="inline-block bg-red-100 text-red-800 text-xs font-bold px-3 py-1 rounded-full mb-4">
            আমাদের সংকট ও সমস্যা
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-6">
            লাখো মানুষ NID, পাসপোর্ট, ভাতার জন্য দালালকে টাকা দেয়। গ্রামের মানুষ জানে না কোথায় আবেদন করবে
          </h1>

          <div className="prose prose-slate max-w-none space-y-4 text-lg text-slate-700 leading-relaxed">
            <p>
              বাংলাদেশের কোটি সাধারণ নাগরিক—বিশেষ করে গ্রামঞ্চলের কৃষক, দিনমজুর, প্রবাসীর পরিবার ও বয়স্ক নাগরিকগণ—জাতীয় পরিচয়পত্র (NID) সংশোধন, নতুন পাসপোর্ট তৈরি, সরকারি ভাতা বা জন্ম নিবন্ধনের সঠিক নিয়ম জানেন না।
            </p>
            <p>
              এই অজ্ঞতা ও জটিলতার সুযোগ নিয়ে এক শ্রেণির অসাধু দালাল ও সাইবার ক্যাফে সাধারণ মানুষের কাছ থেকে অতিরিক্ত কয়েক গুণ টাকা হাতিয়ে নেয়। অনেক সময় ভুল আবেদনের কারণে মাসের পর মাস হয়রানির শিকার হতে হয় সাধারণ মানুষকে।
            </p>
            <div className="bg-amber-50 border-l-4 border-amber-500 p-4 my-6 text-amber-900 text-base">
              <strong>মূল বাস্তবতা:</strong> সরকারি সেবাগুলো মূলত বিনামূল্যে বা নামমাত্র সরকার নির্ধারিত ফিতে পাওয়ার কথা থাকলেও তথ্যের অভাবে নাগরিকরা প্রতি বছর কোটি কোটি টাকা দালালের পেছনে অপচয় করছেন।
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 flex flex-wrap gap-4 items-center justify-between">
            <Link href="/about/solution" className="bg-blue-800 hover:bg-blue-900 text-white font-semibold px-6 py-3 rounded-lg shadow transition">
              আমাদের সমাধান দেখুন →
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-6 py-3 rounded-lg shadow transition">
              পোর্টালের যোগাযোগ পেজে যান
            </Link>
          </div>
        </article>
      </main>
      <SahajFooter />
    </div>
  );
}

export function AboutSolution() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <SahajHeader />
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-blue-700 hover:text-blue-900 font-medium">
            <ArrowLeft size={16} className="mr-1" /> হোমে ফিরে যান
          </Link>
        </div>

        <article className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-10">
          <div className="inline-block bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full mb-4">
            আমাদের সমাধান
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-6">
            এক জায়গায় সরকারি উৎসের লিংক ও নিরাপদ পরবর্তী ধাপ
          </h1>

          <div className="space-y-6 text-lg text-slate-700 leading-relaxed">
            <p>
              <strong>সহজসেবা (SahajSeva)</strong> পোর্টাল তৈরি করা হয়েছে যাতে কোনো নাগরিককে আর বিভ্রান্ত হতে না হয়। আমাদের প্ল্যাটফর্মে রয়েছে:
            </p>

            <div className="grid sm:grid-cols-2 gap-4 my-6">
              <div className="bg-blue-50/60 p-5 rounded-xl border border-blue-100">
                <h3 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
                  <ShieldCheck className="text-blue-700" size={20} /> ১. ফ্রি অফিশিয়াল লিংক
                </h3>
                <p className="text-sm text-slate-600">
                  বাংলাদেশ সরকারের সমস্ত নির্ভরযোগ্য সেবা পোর্টাল ও হেল্পলাইন (৯৯৯, ৩৩৩, ১৬২৬৩, NID, Passport, Vata) এক ঠিকানায়।
                </p>
              </div>

              <div className="bg-emerald-50/60 p-5 rounded-xl border border-emerald-100">
                <h3 className="font-bold text-emerald-900 mb-2 flex items-center gap-2">
                  <CheckCircle className="text-emerald-700" size={20} /> ২. স্বচ্ছ সেবা সহায়তা
                </h3>
                <p className="text-sm text-slate-600">
                  পোর্টালটি সঠিক সরকারি উৎস, প্রস্তুতির নির্দেশনা ও নিরাপদ পরবর্তী ধাপ দেখায়। এটি আবেদন জমা নেয় না, কোনো ফি নির্ধারণ করে না এবং পেমেন্ট গ্রহণ করে না।
                </p>
              </div>
            </div>

            <div className="bg-slate-100 p-5 rounded-xl text-center">
              <p className="font-semibold text-slate-800 mb-3">পরামর্শ বা তথ্যের জন্য পোর্টালের নিরাপদ যোগাযোগ পথ ব্যবহার করুন:</p>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-8 py-3.5 rounded-xl shadow-md transition text-lg"
              >
                যোগাযোগ পেজে যান
              </Link>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 flex justify-between">
            <Link href="/about/problem" className="text-blue-700 hover:underline font-medium">
              ← আগের পেজ: সমস্যা
            </Link>
            <Link href="/about/impact" className="bg-blue-800 hover:bg-blue-900 text-white font-semibold px-6 py-3 rounded-lg shadow transition">
              ইমপ্যাক্ট ও টার্গেট দেখুন →
            </Link>
          </div>
        </article>
      </main>
      <SahajFooter />
    </div>
  );
}

export function AboutImpact() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <SahajHeader />
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-blue-700 hover:text-blue-900 font-medium">
            <ArrowLeft size={16} className="mr-1" /> হোমে ফিরে যান
          </Link>
        </div>

        <article className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-10">
          <div className="inline-block bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full mb-4">
            আমাদের প্রভাব ও লক্ষ্য
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-6">
            আমাদের লক্ষ্য, জবাবদিহি ও সেবার দিকনির্দেশনা
          </h1>

          <div className="grid sm:grid-cols-2 gap-6 my-8">
            <div className="bg-gradient-to-br from-blue-900 to-blue-800 text-white p-6 rounded-2xl shadow-md text-center">
              <Users className="mx-auto mb-2 text-blue-200" size={36} />
              <div className="text-xl font-extrabold mb-1 tracking-tight">তথ্যভিত্তিক দিকনির্দেশনা</div>
              <div className="text-blue-100 text-sm font-medium">নাগরিককে যাচাইকৃত সরকারি উৎসের দিকে নিয়ে যাওয়ার অঙ্গীকার</div>
            </div>

            <div className="bg-gradient-to-br from-emerald-800 to-teal-900 text-white p-6 rounded-2xl shadow-md text-center">
              <TrendingUp className="mx-auto mb-2 text-emerald-200" size={36} />
              <div className="text-xl font-extrabold mb-1 tracking-tight">ধারাবাহিক উন্নয়ন</div>
              <div className="text-emerald-100 text-sm font-medium">বাস্তব যাচাই ছাড়া কোনো সেবা-সংখ্যা বা ফলাফল প্রকাশ করা হয় না</div>
            </div>
          </div>

          <div className="space-y-4 text-slate-700 leading-relaxed text-lg">
            <p>
              SahajContact নাগরিককে NID, পাসপোর্ট, ভাতা ও অন্যান্য বিষয়ে যাচাইকৃত সরকারি উৎস খুঁজে পেতে সহায়তা করে। প্রকাশযোগ্য, স্বাধীনভাবে যাচাইকৃত প্রভাবের তথ্য না থাকলে আমরা কোনো সেবা-সংখ্যা বা সফলতার ফল দাবি করি না।
            </p>
            <p>
              দালালমুক্ত ও তথ্যভিত্তিক সেবার পথে নির্দেশনা উন্নত করতে আপনার মতামত গুরুত্বপূর্ণ। যোগাযোগ পেজ বা মতামত ফর্মে তথ্য পাঠাতে পারেন; এতে কোনো আবেদন, পেমেন্ট বা অনুমোদন তৈরি হয় না।
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 flex justify-between">
            <Link href="/about/solution" className="text-blue-700 hover:underline font-medium">
              ← আগের পেজ: সমাধান
            </Link>
            <Link href="/about/partnership" className="bg-blue-800 hover:bg-blue-900 text-white font-semibold px-6 py-3 rounded-lg shadow transition">
              পার্টনারশিপ ও অনুদান দেখুন →
            </Link>
          </div>
        </article>
      </main>
      <SahajFooter />
    </div>
  );
}

export function AboutPartnership() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <SahajHeader />
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-blue-700 hover:text-blue-900 font-medium">
            <ArrowLeft size={16} className="mr-1" /> হোমে ফিরে যান
          </Link>
        </div>

        <article className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-10">
          <div className="inline-block bg-purple-100 text-purple-800 text-xs font-bold px-3 py-1 rounded-full mb-4">
            পার্টনারশিপ ও বিনিয়োগ
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-6">
            আমরা NGO, সরকার এবং বিনিয়োগকারীদের সাথে কাজ করতে চাই
          </h1>

          <div className="space-y-6 text-slate-700 leading-relaxed text-lg">
            <p>
              সহজসেবা (SahajSeva) প্রজেক্টটিকে সারা দেশের তৃণমূল পর্যায়ে ছড়িয়ে দেওয়ার জন্য আমরা সরকারি সংস্থা, এনজিও (NGO), সামাজিক উদ্যোক্তা এবং কৌশলগত বিনিয়োগকারীদের (Investors/CSR) সাথে অংশীদারিত্বে কাজ করতে উন্মুখ।
            </p>

            <div className="bg-blue-50/60 p-6 rounded-xl border border-blue-100">
              <h3 className="font-bold text-blue-900 mb-3 flex items-center gap-2 text-xl">
                <HeartHandshake className="text-blue-700" size={24} /> সহযোগিতার ক্ষেত্রসমূহ:
              </h3>
              <ul className="list-disc list-inside space-y-2 text-slate-700 text-base">
                <li>তৃণমূল পর্যায়ে ডিজিটাল লিটারেসি ক্যাম্পেইন ও হেল্পডেস্ক স্থাপন।</li>
                <li>সরকারি ই-গর্ভন্যান্স ও নাগরিক সেবা প্রচারণায় যৌথ উদ্যোগ।</li>
                <li>টেকসই সামাজিক স্টার্টআপ হিসেবে সিএসআর (CSR) অনুদান বা সিড ফান্ডিং।</li>
              </ul>
            </div>

            <div className="bg-slate-900 text-white p-8 rounded-2xl text-center space-y-4">
              <h3 className="text-2xl font-bold">প্রাতিষ্ঠানিক প্রস্তাব জমা দিন</h3>
              <p className="text-slate-300">
                সরকার, NGO বা প্রতিষ্ঠানের সহযোগিতা-প্রস্তাবের জন্য নির্ধারিত পোর্টাল ফর্ম ব্যবহার করুন। জমা দিলেই কোনো অংশীদারিত্ব, অনুমোদন বা প্রকাশ্য তালিকাভুক্তি তৈরি হয় না।
              </p>
              <div>
                <Link
                  href="/ngo-partnership"
                  className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-3.5 rounded-xl shadow-lg transition text-lg"
                >
                  NGO ও প্রাতিষ্ঠানিক সহযোগিতা পেজ
                </Link>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-100 flex justify-between">
            <Link href="/about/impact" className="text-blue-700 hover:underline font-medium">
              ← আগের পেজ: ইমপ্যাক্ট
            </Link>
            <Link href="/contact" className="bg-blue-800 hover:bg-blue-900 text-white font-semibold px-6 py-3 rounded-lg shadow transition">
              সরাসরি যোগাযোগ পেজ →
            </Link>
          </div>
        </article>
      </main>
      <SahajFooter />
    </div>
  );
}
