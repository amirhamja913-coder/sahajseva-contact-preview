import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { jsPDF } from "jspdf";
import { 
  BarChart3, Users, MessageSquare, Globe, ArrowUpRight, 
  RefreshCw, ShieldCheck, Calendar, Filter, Smartphone, Monitor, ChevronRight, CheckCircle2, Upload, FolderPlus, Image as ImageIcon, UserPlus, Trash2, Download, FileText, SlidersHorizontal, Settings2, Link2, Eye, Palette, Save, Plus, History, ExternalLink
} from "lucide-react";
import { Link } from "wouter";
import PwaInstallButton from "../components/PwaInstallButton";
import AdminSecurityGate from "../components/AdminSecurityGate";
import { useLanguage } from "@/contexts/LanguageContext";
import { HomepageBuilderPanel, JonosobhaPanel } from "../components/FullControlCmsPanels";
import { MenuHeaderManagerPanel } from "../components/MenuHeaderManagerPanel";
import { PricingSettingsPanel } from "../components/PricingSettingsPanel";
import { PremiumPhotoGalleryManager } from "../components/PremiumPhotoGalleryManager";
import { OwnerPersonalPhotoManager } from "../components/OwnerPersonalPhotoManager";
import { ServiceCardAssetManager } from "../components/ServiceCardAssetManager";
import { AppearanceControlPanel } from "../components/AppearanceControlPanel";
import { ThemeBackgroundManager } from "../components/ThemeBackgroundManager";
import { GA4LiveReportPanel } from "../components/GA4LiveReportPanel";
import { TransportIndiaManager } from "../components/TransportIndiaManager";
import { MainPageContentManager } from "../components/MainPageContentManager";
import { AdminControlDirectory } from "../components/AdminControlDirectory";
import { NgoPartnershipReviewPanel } from "../components/NgoPartnershipReviewPanel";
import { AdminWorkspaceNavigation } from "../components/AdminWorkspaceNavigation";
import { BusinessDirectoryClaimReviewPanel } from "../components/BusinessDirectoryClaimReviewPanel";
import { BusinessDirectoryReviewPanel } from "../components/BusinessDirectoryReviewPanel";

type TouristGalleryItem = { url: string; captionBn: string; captionEn: string; sourceUrl?: string };
const MAX_TOURIST_GALLERY_IMAGES = 50;
type TouristForm = {
  id: number | null;
  nameBn: string;
  nameEn: string;
  descBn: string;
  descEn: string;
  imageUrl: string;
  gallery: TouristGalleryItem[];
  category: "সমুদ্র" | "পাহাড়" | "ঐতিহাসিক" | "ধর্মীয়" | "প্রকৃতি";
  location: string;
  mapUrl: string;
  visible: boolean;
  displayOrder: number;
};

const emptyTouristForm: TouristForm = {
  id: null,
  nameBn: "",
  nameEn: "",
  descBn: "",
  descEn: "",
  imageUrl: "",
  gallery: [],
  category: "প্রকৃতি",
  location: "",
  mapUrl: "",
  visible: true,
  displayOrder: 0,
};

const publicStatsOptions = [
  { key: "showStatActiveUsers", bn: "সক্রিয় ব্যবহারকারী: ৪৫৫", en: "Show Active Users: 455" },
  { key: "showStatPageViews", bn: "পেজ ভিউ: ৩,০৯৭", en: "Show Page Views: 3,097" },
  { key: "showStatKeyEvents", bn: "মূল ইভেন্ট: ৪৩", en: "Show Key Events: 43" },
  { key: "showStatTopCountries", bn: "শীর্ষ দেশ: USA ২৪৭", en: "Show Top Countries: USA 247" },
  { key: "showStatEngagement", bn: "এনগেজমেন্ট: ১:০৩", en: "Show Engagement: 1:03" },
  { key: "showStatShares", bn: "শেয়ার: ১৬২", en: "Show Shares: 162" },
] as const;

type PublicStatsVisibility = Record<(typeof publicStatsOptions)[number]["key"], boolean>;

const defaultPublicStatsVisibility: PublicStatsVisibility = {
  showStatActiveUsers: true,
  showStatPageViews: true,
  showStatKeyEvents: false,
  showStatTopCountries: true,
  showStatEngagement: false,
  showStatShares: true,
};

export default function AdminAnalyticsDashboard() {
  const { language, setLanguage } = useLanguage();
  const [timeRange, setTimeRange] = useState<"7d" | "30d">("7d");
  const utils = trpc.useUtils();
  const [selectedFolder, setSelectedFolder] = useState<string>("General");
  const [newFolderName, setNewFolderName] = useState<string>("");
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadMessage, setUploadMessage] = useState<string>("");

  // The dashboard content is rendered only after AdminSecurityGate unlocks it.
  // Never use a second client-side session lookup to lock CMS fields: each
  // read/write procedure independently verifies the signed HTTP-only session.
  const isOwner = true;

  const { data: analytics } = trpc.utmAnalytics.getSummary.useQuery(
    { timeRange },
    { enabled: isOwner, retry: false }
  );
  const weeklySummaryQuery = trpc.adminAnalytics.getWeeklySummary.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const weeklyExportQuery = trpc.adminAnalytics.getWeeklyExport.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const dailySeoRefreshStatusQuery = trpc.adminAnalytics.getDailySeoRefreshStatus.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const mediaQuery = trpc.adminMedia.list.useQuery(undefined, {
    enabled: isOwner,
  });
  const touristPlacesQuery = trpc.siteManagement.management.getTouristPlaces.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const [touristForm, setTouristForm] = useState<TouristForm>(emptyTouristForm);
  const [touristMessage, setTouristMessage] = useState("");
  const [publicStatsDraft, setPublicStatsDraft] = useState<PublicStatsVisibility>(defaultPublicStatsVisibility);
  const siteWorkspaceQuery = trpc.siteManagement.getOwnerWorkspace.useQuery(undefined, {
    enabled: isOwner,
    retry: false,
  });
  const institutionalVerification = siteWorkspaceQuery.data?.institutionalVerification;
  const tradeLicenceRecordedDate = institutionalVerification?.confirmedAt
    ? new Date(institutionalVerification.confirmedAt).toLocaleDateString("bn-BD")
    : null;
  const seoSettingsQuery = trpc.siteManagement.management.getSeoSettings.useQuery(undefined, { enabled: isOwner, retry: false });
  const [seoMode, setSeoMode] = useState<"auto" | "manual">("auto");
  useEffect(() => {
    const settings = siteWorkspaceQuery.data?.settings as Record<string, unknown> | undefined;
    if (!settings) return;
    setPublicStatsDraft({
      showStatActiveUsers: settings.showStatActiveUsers !== 0,
      showStatPageViews: settings.showStatPageViews !== 0,
      showStatKeyEvents: settings.showStatKeyEvents === 1,
      showStatTopCountries: settings.showStatTopCountries !== 0,
      showStatEngagement: settings.showStatEngagement === 1,
      showStatShares: settings.showStatShares !== 0,
    });
  }, [siteWorkspaceQuery.data?.settings]);
  useEffect(() => {
    const persistedMode = seoSettingsQuery.data?.seoMode;
    if (persistedMode === "manual" || persistedMode === "auto") setSeoMode(persistedMode);
  }, [seoSettingsQuery.data?.seoMode]);
  const leadsQuery = trpc.siteManagement.management.getLeads.useQuery(undefined, { enabled: isOwner, retry: false });
  const announcementQuery = trpc.siteManagement.management.getAnnouncement.useQuery(undefined, { enabled: isOwner, retry: false });
  const blogPostsQuery = trpc.siteManagement.management.listBlogPosts.useQuery({ includeDrafts: true }, { enabled: isOwner, retry: false });
  const healthQuery = trpc.siteManagement.management.runHealthCheck.useQuery(undefined, { enabled: isOwner, retry: false });
  const siteLogsQuery = trpc.siteManagement.management.getSiteLogs.useQuery({ limit: 25 }, { enabled: isOwner, retry: false });
  const backupQuery = trpc.siteManagement.management.exportBackup.useQuery(undefined, { enabled: false, retry: false });
  const scheduledBackupStatusQuery = trpc.siteManagement.management.getScheduledBackupStatus.useQuery(undefined, { enabled: isOwner, retry: false });
  const investorLeadsQuery = trpc.adminAnalytics.investors.ownerList.useQuery(undefined, { enabled: isOwner, retry: false });
  const [siteManagementMessage, setSiteManagementMessage] = useState("");
  const [managementMessage, setManagementMessage] = useState("");
  const [restorePreview, setRestorePreview] = useState<any>(null);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [resetConfirmation, setResetConfirmation] = useState("");
  const [newBlogSlug, setNewBlogSlug] = useState("");
  const membersQuery = trpc.adminMembers.list.useQuery(undefined, {
    enabled: isOwner,
  });
  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  const featurePermissionsQuery = trpc.adminMembers.listFeaturePermissions.useQuery(
    { memberId: selectedMemberId ?? 0 },
    { enabled: isOwner && selectedMemberId !== null, retry: false },
  );
  const [newAdminEmail, setNewAdminEmail] = useState("");
  const [newAdminName, setNewAdminName] = useState("");
  const [newAdminRole, setNewAdminRole] = useState<"Viewer" | "Editor" | "Admin">("Viewer");
  const [memberMsg, setMemberMsg] = useState("");

  const addMemberMutation = trpc.adminMembers.add.useMutation({
    onSuccess: () => {
      membersQuery.refetch();
      setNewAdminEmail("");
      setNewAdminName("");
      setMemberMsg("নতুন অ্যাডমিন সফলভাবে যুক্ত করা হয়েছে!");
      setTimeout(() => setMemberMsg(""), 4000);
    },
    onError: (err) => {
      setMemberMsg("যোগ করতে ব্যর্থ: " + err.message);
    }
  });

  const removeMemberMutation = trpc.adminMembers.remove.useMutation({
    onSuccess: () => {
      membersQuery.refetch();
      setMemberMsg("অ্যাডমিন সদস্য সফলভাবে সরানো হয়েছে।");
      setTimeout(() => setMemberMsg(""), 4000);
    },
    onError: (err) => {
      setMemberMsg("সরাতে ব্যর্থ: " + err.message);
    }
  });
  const updateRoleMutation = trpc.adminMembers.updateRole.useMutation({
    onSuccess: () => {
      membersQuery.refetch();
      setMemberMsg("সদস্যের অনুমতি-স্তর হালনাগাদ হয়েছে।");
      setTimeout(() => setMemberMsg(""), 4000);
    },
    onError: (err) => setMemberMsg("অনুমতি পরিবর্তন করা যায়নি: " + err.message),
  });
  const setFeaturePermissionMutation = trpc.adminMembers.setFeaturePermission.useMutation({
    onSuccess: () => featurePermissionsQuery.refetch(),
    onError: (err) => setMemberMsg("ফিচার অনুমতি পরিবর্তন করা যায়নি: " + err.message),
  });
  const uploadMutation = trpc.adminMedia.upload.useMutation({
    onSuccess: () => {
      mediaQuery.refetch();
      setUploading(false);
      setUploadMessage("সফলভাবে ফাইল আপলোড ও ফোল্ডারে সংরক্ষিত হয়েছে!");
      setTimeout(() => setUploadMessage(""), 4000);
    },
    onError: (err) => {
      setUploading(false);
      setUploadMessage("আপলোড ব্যর্থ হয়েছে: " + err.message);
    }
  });

  const uploadBase64Mutation = trpc.gallery.uploadBase64.useMutation();
  const refreshSiteManagement = async (message: string) => {
    await Promise.all([
      siteWorkspaceQuery.refetch(),
      utils.siteManagement.getPublicContent.invalidate(),
    ]);
    setSiteManagementMessage(message);
    window.setTimeout(() => setSiteManagementMessage(""), 4_000);
  };
  const saveContentSettingsMutation = trpc.siteManagement.saveContentSettings.useMutation({
    onSuccess: () => refreshSiteManagement("সাইটের লেখা, section ও রঙের settings সংরক্ষণ হয়েছে।"),
    onError: (error) => setSiteManagementMessage(`Settings সংরক্ষণ করা যায়নি: ${error.message}`),
  });
  const savePublicStatsSettings = () => {
    const settings = siteWorkspaceQuery.data?.settings as Record<string, unknown> | undefined;
    if (!settings) {
      setSiteManagementMessage("বর্তমান Site Settings লোড হওয়ার পর আবার চেষ্টা করুন।");
      return;
    }
    saveContentSettingsMutation.mutate({
      heroTitleBn: (settings.heroTitleBn as string | null) ?? null,
      heroTitleEn: (settings.heroTitleEn as string | null) ?? null,
      heroSubtitleBn: (settings.heroSubtitleBn as string | null) ?? null,
      heroSubtitleEn: (settings.heroSubtitleEn as string | null) ?? null,
      heroBackgroundImageUrl: (settings.heroBackgroundImageUrl as string | null) ?? null,
      heroVideoUrl: (settings.heroVideoUrl as string | null) ?? null,
      siteNameBn: (settings.siteNameBn as string | null) ?? null,
      siteNameEn: (settings.siteNameEn as string | null) ?? null,
      headerTaglineBn: (settings.headerTaglineBn as string | null) ?? null,
      headerTaglineEn: (settings.headerTaglineEn as string | null) ?? null,
      contactPhone: (settings.contactPhone as string | null) ?? null,
      contactEmail: (settings.contactEmail as string | null) ?? null,
      socialLinksJson: (settings.socialLinksJson as string | null) ?? null,
      notFoundTitleBn: (settings.notFoundTitleBn as string | null) ?? null,
      notFoundTitleEn: (settings.notFoundTitleEn as string | null) ?? null,
      notFoundMessageBn: (settings.notFoundMessageBn as string | null) ?? null,
      notFoundMessageEn: (settings.notFoundMessageEn as string | null) ?? null,
      heroAccentMessageBn: (settings.heroAccentMessageBn as string | null) ?? null,
      heroAccentMessageEn: (settings.heroAccentMessageEn as string | null) ?? null,
      primaryCtaLabelBn: (settings.primaryCtaLabelBn as string | null) ?? null,
      primaryCtaLabelEn: (settings.primaryCtaLabelEn as string | null) ?? null,
      primaryCtaHref: (settings.primaryCtaHref as string | null) ?? null,
      ownerNoticeTitleBn: (settings.ownerNoticeTitleBn as string | null) ?? null,
      ownerNoticeTitleEn: (settings.ownerNoticeTitleEn as string | null) ?? null,
      ownerNoticeTextBn: (settings.ownerNoticeTextBn as string | null) ?? null,
      ownerNoticeTextEn: (settings.ownerNoticeTextEn as string | null) ?? null,
      noticeVisible: settings.noticeVisible === 1 || settings.noticeVisible === true,
      quickLinksVisible: settings.quickLinksVisible === 1 || settings.quickLinksVisible === true,
      ...publicStatsDraft,
      brandAccentColor: (settings.brandAccentColor as string) || "#0d5c56",
      brandHighlightColor: (settings.brandHighlightColor as string) || "#f2b84b",
      logoUrl: (settings.logoUrl as string | null) ?? null,
    }, { onSuccess: () => refreshSiteManagement("Public Stats Settings সফলভাবে আপডেট হয়েছে।") });
  };
  const createQuickLinkMutation = trpc.siteManagement.createQuickLink.useMutation({
    onSuccess: () => refreshSiteManagement("নতুন public link যুক্ত হয়েছে।"),
    onError: (error) => setSiteManagementMessage(`Link যোগ করা যায়নি: ${error.message}`),
  });
  const updateQuickLinkMutation = trpc.siteManagement.updateQuickLink.useMutation({
    onSuccess: () => refreshSiteManagement("Public link হালনাগাদ হয়েছে।"),
    onError: (error) => setSiteManagementMessage(`Link পরিবর্তন করা যায়নি: ${error.message}`),
  });
  const deleteQuickLinkMutation = trpc.siteManagement.deleteQuickLink.useMutation({
    onSuccess: () => refreshSiteManagement("Public link মুছে ফেলা হয়েছে।"),
    onError: (error) => setSiteManagementMessage(`Link মুছে ফেলা যায়নি: ${error.message}`),
  });
  const createMediaFolderMutation = trpc.siteManagement.createMediaFolder.useMutation({
    onSuccess: () => {
      refreshSiteManagement("নতুন media folder তৈরি হয়েছে।");
      setNewFolderName("");
    },
    onError: (error) => setSiteManagementMessage(`Folder তৈরি করা যায়নি: ${error.message}`),
  });
  const deleteMediaMutation = trpc.adminMedia.delete.useMutation({
    onSuccess: () => { mediaQuery.refetch(); setUploadMessage("Media record মুছে ফেলা হয়েছে।"); },
    onError: (error) => setUploadMessage(`Media মুছতে ব্যর্থ: ${error.message}`),
  });
  const replaceMediaMutation = trpc.adminMedia.replace.useMutation({
    onSuccess: () => { mediaQuery.refetch(); setUploadMessage("Media ফাইল replace হয়েছে।"); },
    onError: (error) => setUploadMessage(`Media replace ব্যর্থ: ${error.message}`),
  });
  const createTouristMutation = trpc.siteManagement.management.createTouristPlace.useMutation({
    onSuccess: () => { touristPlacesQuery.refetch(); setTouristForm(emptyTouristForm); setTouristMessage("নতুন Tourist Spot সংরক্ষণ হয়েছে।"); },
    onError: (error) => setTouristMessage(`Tourist Spot যোগ করা যায়নি: ${error.message}`),
  });
  const updateTouristMutation = trpc.siteManagement.management.updateTouristPlace.useMutation({
    onSuccess: () => { touristPlacesQuery.refetch(); setTouristForm(emptyTouristForm); setTouristMessage("Tourist Spot হালনাগাদ হয়েছে।"); },
    onError: (error) => setTouristMessage(`Tourist Spot হালনাগাদ করা যায়নি: ${error.message}`),
  });
  const deleteTouristMutation = trpc.siteManagement.management.deleteTouristPlace.useMutation({
    onSuccess: () => { touristPlacesQuery.refetch(); setTouristMessage("Tourist Spot মুছে ফেলা হয়েছে।"); },
    onError: (error) => setTouristMessage(`Tourist Spot মুছতে ব্যর্থ: ${error.message}`),
  });
  const saveSeoMutation = trpc.siteManagement.management.saveSeoSettings.useMutation({
    onSuccess: () => { seoSettingsQuery.refetch(); setManagementMessage("SEO settings সংরক্ষণ হয়েছে। "); },
    onError: (error) => setManagementMessage(`SEO সংরক্ষণ করা যায়নি: ${error.message}`),
  });
  const confirmTradeLicenceHeldMutation = trpc.siteManagement.confirmTradeLicenceHeld.useMutation({
    onSuccess: async () => {
      await siteWorkspaceQuery.refetch();
      setManagementMessage("Private trade-licence acknowledgement সংরক্ষণ হয়েছে। কোনো document বা licence number রাখা হয়নি।");
    },
    onError: (error) => setManagementMessage(`Private acknowledgement সংরক্ষণ করা যায়নি: ${error.message}`),
  });
  const updateLeadStatusMutation = trpc.siteManagement.management.updateLeadStatus.useMutation({ onSuccess: () => leadsQuery.refetch() });
  const deleteLeadMutation = trpc.siteManagement.management.deleteLead.useMutation({
    onSuccess: async () => {
      await leadsQuery.refetch();
      setManagementMessage("সফলভাবে ডিলেট হয়েছে।");
    },
    onError: (error) => setManagementMessage(`Lead ডিলেট করা যায়নি: ${error.message}`),
  });
  const saveAnnouncementMutation = trpc.siteManagement.management.saveAnnouncement.useMutation({ onSuccess: () => { announcementQuery.refetch(); setManagementMessage("Announcement banner সংরক্ষণ হয়েছে।"); } });
  const createBlogMutation = trpc.siteManagement.management.createBlogPost.useMutation({ onSuccess: () => { blogPostsQuery.refetch(); setManagementMessage("Blog/News post সংরক্ষণ হয়েছে।"); } });
  const deleteBlogMutation = trpc.siteManagement.management.deleteBlogPost.useMutation({ onSuccess: () => { blogPostsQuery.refetch(); setManagementMessage("Blog post মুছে ফেলা হয়েছে।"); } });
  const clearCacheMutation = trpc.siteManagement.management.clearCache.useMutation({ onSuccess: (result) => { siteLogsQuery.refetch(); setManagementMessage(result.message); } });
  const optimizeImagesMutation = trpc.siteManagement.management.optimizeAllImages.useMutation({ onSuccess: (result) => { siteLogsQuery.refetch(); setManagementMessage(`${result.reviewed}টি image record review করা হয়েছে।`); } });
  const restoreBackupMutation = trpc.siteManagement.management.restoreBackup.useMutation({ onSuccess: () => { setRestorePreview(null); siteWorkspaceQuery.refetch(); blogPostsQuery.refetch(); announcementQuery.refetch(); setManagementMessage("Backup snapshot restore হয়েছে।"); } });
  const resetToLastBackupMutation = trpc.siteManagement.management.resetToLastScheduledBackup.useMutation({
    onSuccess: async (result) => {
      setShowResetDialog(false);
      setResetConfirmation("");
      await Promise.all([siteWorkspaceQuery.refetch(), blogPostsQuery.refetch(), announcementQuery.refetch(), scheduledBackupStatusQuery.refetch()]);
      setManagementMessage(`সর্বশেষ ${result.restoredDayKey ?? "available"} backup থেকে site management content পুনরুদ্ধার হয়েছে।`);
    },
    onError: (error) => setManagementMessage(`Reset সম্পন্ন করা যায়নি: ${error.message}`),
  });
  const updateInvestorLeadMutation = trpc.adminAnalytics.investors.updateStatus.useMutation({ onSuccess: () => investorLeadsQuery.refetch() });

  const handleTouristImageUpload = async (event: React.ChangeEvent<HTMLInputElement>, mode: "cover" | "gallery") => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file || !file.type.startsWith("image/")) return;
    if (mode === "gallery" && touristForm.gallery.length >= MAX_TOURIST_GALLERY_IMAGES) {
      setTouristMessage(`একটি জায়গায় সর্বোচ্চ ${MAX_TOURIST_GALLERY_IMAGES}টি gallery image রাখা যাবে।`);
      return;
    }
    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("ইমেজ পড়া যায়নি"));
        reader.readAsDataURL(file);
      });
      const uploaded = await uploadBase64Mutation.mutateAsync({ base64Data: base64, fileName: file.name, contentType: file.type });
      if (mode === "cover") setTouristForm((current) => ({ ...current, imageUrl: uploaded.url }));
      else setTouristForm((current) => ({ ...current, gallery: [...current.gallery, { url: uploaded.url, captionBn: "", captionEn: "" }] }));
      setTouristMessage(mode === "cover" ? "Cover image আপলোড হয়েছে।" : "Gallery image যুক্ত হয়েছে।");
    } catch (error) {
      setTouristMessage(`ইমেজ আপলোড ব্যর্থ: ${error instanceof Error ? error.message : "অজানা ত্রুটি"}`);
    }
  };

  const moveTouristGalleryImage = (fromIndex: number, toIndex: number) => {
    setTouristForm((current) => {
      if (toIndex < 0 || toIndex >= current.gallery.length) return current;
      const gallery = [...current.gallery];
      const [moved] = gallery.splice(fromIndex, 1);
      gallery.splice(toIndex, 0, moved);
      return { ...current, gallery };
    });
  };

  const removeTouristGalleryImage = (index: number) => {
    if (!window.confirm("এই ছবিটি শুধু বর্তমান সম্পাদনা তালিকা থেকে সরানো হবে। স্থায়ী করতে Save Changes চাপতে হবে। আপনি কি নিশ্চিত?")) return;
    setTouristForm((current) => ({ ...current, gallery: current.gallery.filter((_, galleryIndex) => galleryIndex !== index) }));
    setTouristMessage("ছবিটি সম্পাদনা তালিকা থেকে সরানো হয়েছে। স্থায়ী করতে Save Changes চাপুন।");
  };

  const removeTouristCoverImage = () => {
    if (!window.confirm("Cover image সরালে তা বর্তমান সম্পাদনা তালিকা থেকে বাদ যাবে। স্থায়ী করতে Save Changes চাপতে হবে। আপনি কি নিশ্চিত?")) return;
    setTouristForm((current) => ({ ...current, imageUrl: "" }));
    setTouristMessage("Cover image সম্পাদনা তালিকা থেকে সরানো হয়েছে। স্থায়ী করতে Save Changes চাপুন।");
  };

  const handleMediaReplace = async (event: React.ChangeEvent<HTMLInputElement>, fileRecord: any) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("ফাইল পড়া যায়নি"));
        reader.readAsDataURL(file);
      });
      const uploaded = await uploadBase64Mutation.mutateAsync({ base64Data: base64, fileName: file.name, contentType: file.type });
      replaceMediaMutation.mutate({ id: fileRecord.id, fileName: file.name, fileUrl: uploaded.url, fileType: file.type.startsWith("image/") ? "image" : "file", folderName: fileRecord.folderName ?? "General", fileSize: `${(file.size / 1024).toFixed(1)} KB` });
    } catch (error) {
      setUploadMessage(`Media replace ব্যর্থ: ${error instanceof Error ? error.message : "অজানা ত্রুটি"}`);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadMessage("ফাইল আপলোড হচ্ছে...");

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64String = reader.result as string;
        const res = await uploadBase64Mutation.mutateAsync({
          base64Data: base64String,
          fileName: `admin_${Date.now()}_${file.name}`,
          contentType: file.type || "image/jpeg",
        });

        await uploadMutation.mutateAsync({
          fileName: file.name,
          fileUrl: res.url,
          fileType: file.type.startsWith("image/") ? "image" : "document",
          folderName: selectedFolder,
          fileSize: `${(file.size / 1024).toFixed(1)} KB`,
        });
      } catch (err: any) {
        setUploading(false);
        setUploadMessage("আপলোড ত্রুটি: " + err.message);
      }
    };
    reader.readAsDataURL(file);
  };

  const folders = Array.from(new Set([
    "General",
    "Campaigns",
    "Expatriate Guidance",
    "CEO Reports",
    "Official Banners",
    ...(siteWorkspaceQuery.data?.folders || []).map((folder: any) => folder.name),
  ]));
  const mediaFiles = mediaQuery.data || [];
  const filteredFiles = mediaFiles.filter((f: any) => selectedFolder === "All" || f.folderName === selectedFolder);
  const selectedMember = (membersQuery.data || []).find((member: any) => member.id === selectedMemberId);
  const hasFeaturePermission = (feature: "analytics" | "media" | "exports") =>
    Boolean((featurePermissionsQuery.data || []).find((item: any) => item.feature === feature && item.enabled === 1));

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 500);
  };

  const downloadWeeklyCsv = () => {
    const report = weeklyExportQuery.data;
    if (!report?.metrics) return;
    const rows = [
      ["Metric", "Value"],
      ["Total events", String(report.metrics.totalEvents)],
      ["Page views", String(report.metrics.pageViews)],
      ["Active users", String(report.metrics.activeUsers)],
      ["Sessions", String(report.metrics.sessions)],
      ["Source", report.source],
      ["Captured", report.capturedAt ? new Date(report.capturedAt).toLocaleString("en-GB") : "N/A"],
    ];
    const csv = "\ufeff" + rows.map(row => row.map(value => `\"${value.replace(/\"/g, '\"\"')}\"`).join(",")).join("\n");
    downloadBlob(new Blob([csv], { type: "text/csv;charset=utf-8" }), `sahajcontact-weekly-analytics-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  const downloadWeeklyPdf = () => {
    const report = weeklyExportQuery.data;
    if (!report?.metrics) return;
    const pdf = new jsPDF({ unit: "pt", format: "a4" });
    pdf.setFontSize(18);
    pdf.text("SahajContact Weekly Analytics Report", 48, 64);
    pdf.setFontSize(11);
    [
      `Source: ${report.source}`,
      `Captured: ${report.capturedAt ? new Date(report.capturedAt).toLocaleString("en-GB") : "N/A"}`,
      `Total events: ${report.metrics.totalEvents}`,
      `Page views: ${report.metrics.pageViews}`,
      `Active users: ${report.metrics.activeUsers}`,
      `Sessions: ${report.metrics.sessions}`,
    ].forEach((line, index) => pdf.text(line, 48, 104 + index * 26));
    pdf.setFontSize(9);
    pdf.text("Generated from the SahajContact Admin Dashboard.", 48, 292);
    pdf.save(`sahajcontact-weekly-analytics-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const downloadLeadsCsv = () => {
    const rows = [["Name", "Mobile", "Email", "Subject", "Message", "Status", "Submitted"], ...(leadsQuery.data || []).map((lead: any) => [lead.name, lead.mobile, lead.email, lead.subject, lead.message, lead.status, new Date(lead.createdAt).toLocaleString("en-GB")])];
    const csv = "\ufeff" + rows.map(row => row.map(value => `\"${String(value ?? "").replace(/\"/g, '\"\"')}\"`).join(",")).join("\n");
    downloadBlob(new Blob([csv], { type: "text/csv;charset=utf-8" }), `sahajcontact-leads-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  const downloadBackup = async () => {
    const result = await backupQuery.refetch();
    if (!result.data) { setManagementMessage("Backup তৈরি করা যায়নি। আবার চেষ্টা করুন।"); return; }
    downloadBlob(new Blob([JSON.stringify(result.data, null, 2)], { type: "application/json" }), `sahajcontact-site-backup-${new Date().toISOString().slice(0, 10)}.json`);
    setManagementMessage("Site data backup download শুরু হয়েছে। ZIP archive final delivery-তে দেওয়া হবে।");
  };

  const loadRestorePreview = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        setRestorePreview(parsed.snapshot ?? parsed);
      } catch {
        setManagementMessage("এই backup file-টি সঠিক JSON নয়।");
      }
    };
    reader.readAsText(file);
  };

  return (
    <AdminSecurityGate>
      <div className="min-h-screen bg-slate-50 text-slate-950 font-sans pb-16">
        {/* Top Header */}
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 font-bold text-white shadow-sm">
                SJ
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-950">SahajContact Control Center</h1>
                <p className="text-xs text-slate-500">Owner-only পরিচালনা ও প্রকাশনা workspace</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="sahaj-language-toggle inline-flex rounded-xl border border-slate-200 bg-slate-50 px-2 py-1 text-xs text-slate-600" role="group" aria-label="ভাষা নির্বাচন">
                <button
                  type="button"
                  className={`px-2 py-1 rounded transition ${language === "BN" ? "bg-blue-600 text-white font-semibold" : "text-slate-500 hover:text-slate-950"}`}
                  onClick={() => setLanguage("BN")}
                >বাংলা</button>
                <span className="px-1 text-slate-300">|</span>
                <button
                  type="button"
                  className={`px-2 py-1 rounded transition ${language === "EN" ? "bg-blue-600 text-white font-semibold" : "text-slate-500 hover:text-slate-950"}`}
                  onClick={() => setLanguage("EN")}
                >English</button>
              </div>
              <div className="hidden items-center space-x-1 rounded-xl border border-slate-200 bg-slate-50 p-1 sm:flex">
                <button
                  onClick={() => setTimeRange("7d")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    timeRange === "7d" ? "bg-blue-600 text-white shadow" : "text-slate-500 hover:text-slate-950"
                  }`}
                >
                  শেষ ৭ দিন
                </button>
                <button
                  onClick={() => setTimeRange("30d")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                    timeRange === "30d" ? "bg-blue-600 text-white shadow" : "text-slate-500 hover:text-slate-950"
                  }`}
                >
                  শেষ ৩০ দিন
                </button>
              </div>
            </div>
          </div>
        </header>

	        <main className="max-w-[96rem] mx-auto px-4 sm:px-6 lg:px-8 py-6">
		          <div className="grid items-start gap-5 lg:grid-cols-[17rem_minmax(0,1fr)]">
	            <AdminWorkspaceNavigation />
	            <div className="min-w-0 space-y-8">
			  <section id="admin-overview" className="scroll-mt-24 rounded-[1.4rem] border border-blue-100 bg-gradient-to-br from-blue-50 via-white to-cyan-50 p-5 shadow-[0_20px_55px_-35px_rgba(30,64,175,0.34)]">
		    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
			      <div>
			        <p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-700">Dashboard overview</p>
			        <h2 className="mt-2 text-2xl font-bold text-slate-950">এক জায়গায় আপনার সাইট পরিচালনা করুন</h2>
			        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">বাম পাশের মেনু বা নিচের দ্রুত পথ ব্যবহার করে কাজের জায়গায় যান। কোনো public তথ্য, পেমেন্ট, partner বা analytics ফলাফল এখানে বানিয়ে দেখানো হয় না।</p>
		      </div>
			      <a href="#cms-homepage-builder" onClick={(event) => { event.preventDefault(); document.getElementById("cms-homepage-builder")?.scrollIntoView({ behavior: "smooth", block: "start" }); }} className="inline-flex shrink-0 items-center justify-center rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-blue-500">হোমপেজ সম্পাদনা করুন</a>
		    </div>
		    <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
		      {[
		        ["হোমপেজ ও মেনু", "Hero, লেখা, navigation", "cms-homepage-builder"],
		        ["ছবি ও গ্যালারি", "Public photo ও file folders", "cms-photo-galleries"],
		        ["NGO ও প্রতিষ্ঠান", "Review-first আবেদন", "cms-ngo-partnership"],
		        ["রিপোর্ট ও সিস্টেম", "GA4, SEO, সদস্য ও backup", "cms-analytics-security"],
		      ].map(([label, hint, target]) => (
			        <button key={target} type="button" onClick={() => document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" })} className="rounded-xl border border-slate-200 bg-white p-3 text-left shadow-sm transition hover:border-blue-300 hover:bg-blue-50">
			          <span className="block text-sm font-bold text-slate-800">{label}</span><span className="mt-1 block text-xs text-slate-500">{hint}</span>
		        </button>
		      ))}
		    </div>
		  </section>
		  <details className="rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
		    <summary className="cursor-pointer list-none px-5 py-4 text-sm font-bold text-slate-100 [&::-webkit-details-marker]:hidden">সব control-এর directory ও দ্রুত খোঁজার তালিকা <span className="ml-2 text-xs font-normal text-slate-400">প্রয়োজনে খুলুন</span></summary>
		    <div className="border-t border-slate-800 p-4"><AdminControlDirectory /></div>
		  </details>
		  <details id="cms-homepage-builder" className="scroll-mt-24 rounded-2xl border border-emerald-500/25 bg-slate-900 shadow-xl">
		    <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">হোমপেজ, মেনু ও সেবার নিয়ন্ত্রণ</span><span className="mt-1 block text-xs font-normal text-slate-400">Banner, লেখা, menu, appearance ও service-card এক জায়গায়</span></summary>
		    <div className="space-y-8 border-t border-slate-800 p-4 sm:p-6">
		      <HomepageBuilderPanel isOwner={isOwner} />
		      <div id="cms-main-content" className="scroll-mt-24"><MainPageContentManager isOwner={isOwner} /></div>
		      <div id="cms-menu-header-manager" className="scroll-mt-24"><MenuHeaderManagerPanel isOwner={isOwner} /></div>
			      <div id="cms-appearance-controls" className="scroll-mt-24"><AppearanceControlPanel isOwner={isOwner} /></div>
			      <ThemeBackgroundManager isOwner={isOwner} />
			      <div id="cms-service-card-assets" className="scroll-mt-24"><ServiceCardAssetManager isOwner={isOwner} /></div>
		    </div>
		  </details>
		  <details id="cms-transport-india" className="scroll-mt-24 rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
		    <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">সেবা ও ভ্রমণ তথ্য</span><span className="mt-1 block text-xs font-normal text-slate-400">ভারত যাতায়াত, border ও travel guide পরিচালনা করুন</span></summary>
		    <div className="border-t border-slate-800 p-4 sm:p-6"><TransportIndiaManager isOwner={isOwner} /></div>
		  </details>
	          <PricingSettingsPanel isOwner={isOwner} />
	          <details id="cms-photo-galleries" className="scroll-mt-24 rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
	            <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">Public gallery ও ছবি</span><span className="mt-1 block text-xs font-normal text-slate-400">Owner-managed gallery, ব্যক্তিগত folder ও প্রদর্শন নিয়ন্ত্রণ</span></summary>
	            <div className="space-y-8 border-t border-slate-800 p-4 sm:p-6"><PremiumPhotoGalleryManager isOwner={isOwner} /><OwnerPersonalPhotoManager isOwner={isOwner} /></div>
	          </details>
		  <details id="cms-ngo-partnership" className="scroll-mt-24 rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
		    <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">NGO ও প্রতিষ্ঠান</span><span className="mt-1 block text-xs font-normal text-slate-400">Review-first enquiry ও community management</span></summary>
			    <div className="space-y-8 border-t border-slate-800 p-4 sm:p-6"><div id="cms-site-management" className="scroll-mt-24"><JonosobhaPanel isOwner={isOwner} /></div><NgoPartnershipReviewPanel isOwner={isOwner} /><BusinessDirectoryReviewPanel isOwner={isOwner} /><BusinessDirectoryClaimReviewPanel isOwner={isOwner} /></div>
		  </details>
		  <details id="cms-analytics-security" className="scroll-mt-24 rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
		    <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">রিপোর্ট ও অ্যানালিটিক্স</span><span className="mt-1 block text-xs font-normal text-slate-400">সংরক্ষিত GA4, SEO status ও export—কোনো সংখ্যা অনুমান করা হয় না</span></summary>
		    <div className="space-y-8 border-t border-slate-800 p-4 sm:p-6"><GA4LiveReportPanel isOwner={isOwner} />

		  {/* Analytics Summary */}
		          <div className="rounded-2xl border border-slate-800 bg-slate-950/45 p-4 shadow-xl sm:p-6">
	            <h2 className="text-xl font-bold mb-2 flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-emerald-400" />
              <span>GA4 ও সিইও পারফরম্যান্স রিপোর্ট (অটো UTM ও ট্র্যাকিং)</span>
	            </h2>
	            <p className="text-slate-400 text-sm mb-3">সর্বশেষ সংরক্ষিত GA4 রিপোর্ট থেকে ৭ দিনের সারাংশ। বাহিরের সরকারি লিংকে <code className="text-emerald-300">utm_campaign</code> যুক্ত থাকায় এই রিপোর্টে প্রচারণার উৎস বোঝা যায়। Live GA4 সংযোগ না থাকলে কোনো সংখ্যা অনুমান করা হয় না।</p>
	            <div className={`mb-4 rounded-xl border p-3 text-xs ${dailySeoRefreshStatusQuery.data?.lastError ? "border-amber-500/30 bg-amber-950/30 text-amber-100" : "border-teal-500/30 bg-teal-950/25 text-teal-100"}`} aria-live="polite">
	              <p className="font-bold">২৪ ঘণ্টার স্বয়ংক্রিয় SEO/GA4 snapshot</p>
	              {dailySeoRefreshStatusQuery.isLoading ? <p className="mt-1 text-slate-400">Scheduler status লোড হচ্ছে…</p> : dailySeoRefreshStatusQuery.data?.scheduleConfigured ? <p className="mt-1 leading-5">{dailySeoRefreshStatusQuery.data.lastError ? `শেষ চেষ্টা ব্যর্থ: ${dailySeoRefreshStatusQuery.data.lastError}` : `চালু আছে • শেষ সফল আপডেট: ${dailySeoRefreshStatusQuery.data.lastSuccessfulRunAt ? new Date(dailySeoRefreshStatusQuery.data.lastSuccessfulRunAt).toLocaleString("bn-BD") : "এখনও প্রথম update হয়নি"}`}{dailySeoRefreshStatusQuery.data.latestSnapshotDayKey ? ` • Snapshot: ${dailySeoRefreshStatusQuery.data.latestSnapshotDayKey}` : ""}</p> : <p className="mt-1 leading-5">Scheduler এখনো configure হয়নি। প্রকাশিত daily job চালু হলে প্রতি ২৪ ঘণ্টায় GA4 snapshot সংরক্ষণ হবে।</p>}
	            </div>
	            <div className={`mb-6 rounded-xl border px-3 py-2 text-xs ${weeklySummaryQuery.data?.availability === "snapshot" ? "border-emerald-500/30 bg-emerald-950/30 text-emerald-200" : "border-amber-500/30 bg-amber-950/30 text-amber-200"}`}>
              {weeklySummaryQuery.isLoading
                ? "সাপ্তাহিক রিপোর্ট লোড হচ্ছে…"
                : weeklySummaryQuery.data?.availability === "snapshot"
                  ? `${weeklySummaryQuery.data.source}${weeklySummaryQuery.data.capturedAt ? ` • আপডেট: ${new Date(weeklySummaryQuery.data.capturedAt).toLocaleString("bn-BD")}` : ""}`
                  : "GA4-এর সংরক্ষিত সাপ্তাহিক রিপোর্ট এখনো পাওয়া যায়নি।"}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400">মোট ইভেন্ট</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">{weeklySummaryQuery.data?.metrics?.totalEvents?.toLocaleString("bn-BD") ?? "—"}</p>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400">পেজ ভিউ</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">{weeklySummaryQuery.data?.metrics?.pageViews?.toLocaleString("bn-BD") ?? "—"}</p>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400">সক্রিয় ব্যবহারকারী</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">{weeklySummaryQuery.data?.metrics?.activeUsers?.toLocaleString("bn-BD") ?? "—"}</p>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <p className="text-xs text-slate-400">সেশন সংখ্যা</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">{weeklySummaryQuery.data?.metrics?.sessions?.toLocaleString("bn-BD") ?? "—"}</p>
              </div>
            </div>
            <div className="mt-5">
              <div className="rounded-xl border border-sky-500/25 bg-sky-950/20 p-4">
                <div className="mb-2 flex items-center gap-2 text-sm font-bold text-sky-200"><Download className="h-4 w-4" /> সাপ্তাহিক রিপোর্ট এক্সপোর্ট</div>
                <p className="text-xs leading-5 text-slate-400">সর্বশেষ সংরক্ষিত GA4 snapshot থেকে CSV spreadsheet অথবা PDF summary ডাউনলোড করুন।</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" onClick={downloadWeeklyCsv} disabled={!weeklyExportQuery.data?.metrics} className="inline-flex items-center gap-1.5 rounded-lg bg-sky-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-sky-500 disabled:cursor-not-allowed disabled:opacity-50"><Download className="h-3.5 w-3.5" /> CSV ডাউনলোড</button>
                  <button type="button" onClick={downloadWeeklyPdf} disabled={!weeklyExportQuery.data?.metrics} className="inline-flex items-center gap-1.5 rounded-lg border border-sky-400/40 px-3 py-2 text-xs font-bold text-sky-200 transition hover:bg-sky-500/10 disabled:cursor-not-allowed disabled:opacity-50"><FileText className="h-3.5 w-3.5" /> PDF রিপোর্ট</button>
                </div>
	              </div>
	            </div>
	          </div>
	        </div>
	      </details>

	          <details id="cms-tourist-spots" className="scroll-mt-24 rounded-2xl border border-emerald-500/20 bg-slate-900 shadow-xl">
	            <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">দর্শনীয় স্থান ও ভ্রমণ guide</span><span className="mt-1 block text-xs font-normal text-slate-400">Tourist spot, cover image ও gallery পরিচালনা করুন</span></summary>
	            <div className="border-t border-slate-800 p-4 sm:p-6"><section className="space-y-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h2 className="text-xl font-bold flex items-center gap-2"><Globe className="w-5 h-5 text-emerald-400" /> Tourist Spots CRUD ও Gallery Manager</h2>
                <p className="text-slate-400 text-sm mt-1">নতুন দর্শনীয় স্থান যোগ করুন, বাংলা/English তথ্য সম্পাদনা করুন, cover ও সব heritage gallery image-এর ক্রম/শিরোনাম নিয়ন্ত্রণ করুন। কোনো বদল Save করার আগে স্থায়ী হবে না।</p>
              </div>
              <button type="button" onClick={() => { setTouristForm(emptyTouristForm); setTouristMessage(""); }} className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-semibold text-slate-200 hover:border-emerald-500/50">নতুন Spot</button>
            </div>

            {touristMessage && <p className="rounded-xl border border-emerald-500/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200">{touristMessage}</p>}

            <form onSubmit={(event) => { event.preventDefault(); const { id, ...raw } = touristForm; const payload = { ...raw, imageUrl: raw.imageUrl || null, mapUrl: raw.mapUrl.trim() || null }; if (id) updateTouristMutation.mutate({ id, ...payload }); else createTouristMutation.mutate(payload); }} className="grid gap-4 rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
              <div className="flex items-center justify-between gap-3"><h3 className="font-bold text-slate-100">{touristForm.id ? "Tourist Spot সম্পাদনা" : "নতুন Tourist Spot যোগ করুন"}</h3><label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={touristForm.visible} onChange={(event) => setTouristForm((current) => ({ ...current, visible: event.target.checked }))} /> Public-এ দেখান</label></div>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="text-xs text-slate-300">নাম (বাংলা)<input required value={touristForm.nameBn} onChange={(event) => setTouristForm((current) => ({ ...current, nameBn: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <label className="text-xs text-slate-300">Name (English)<input required value={touristForm.nameEn} onChange={(event) => setTouristForm((current) => ({ ...current, nameEn: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <label className="text-xs text-slate-300 sm:col-span-2">লোকেশন / Location<input required value={touristForm.location} onChange={(event) => setTouristForm((current) => ({ ...current, location: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <label className="text-xs text-slate-300 sm:col-span-2">Google Maps Link / মানচিত্রের লিংক<input type="url" value={touristForm.mapUrl} onChange={(event) => setTouristForm((current) => ({ ...current, mapUrl: event.target.value }))} placeholder="https://maps.google.com/..." className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <label className="text-xs text-slate-300">বর্ণনা (বাংলা)<textarea required value={touristForm.descBn} onChange={(event) => setTouristForm((current) => ({ ...current, descBn: event.target.value }))} rows={3} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <label className="text-xs text-slate-300">Description (English)<textarea required value={touristForm.descEn} onChange={(event) => setTouristForm((current) => ({ ...current, descEn: event.target.value }))} rows={3} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <label className="text-xs text-slate-300">Category<select value={touristForm.category} onChange={(event) => setTouristForm((current) => ({ ...current, category: event.target.value as TouristForm["category"] }))} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white"><option value="সমুদ্র">সমুদ্র / Sea</option><option value="পাহাড়">পাহাড় / Hill</option><option value="ঐতিহাসিক">ঐতিহাসিক / Historical</option><option value="ধর্মীয়">ধর্মীয় / Religious</option><option value="প্রকৃতি">প্রকৃতি / Nature</option></select></label>
                <label className="text-xs text-slate-300">Display order<input type="number" min={0} value={touristForm.displayOrder} onChange={(event) => setTouristForm((current) => ({ ...current, displayOrder: Number(event.target.value) || 0 }))} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
                <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-sm font-semibold text-slate-100">Cover Image</p><p className="text-xs text-slate-500">বর্তমান image URL দেখা ও নতুন ছবি upload করুন।</p></div><label className="cursor-pointer rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-500">Cover upload<input type="file" accept="image/*" className="hidden" onChange={(event) => handleTouristImageUpload(event, "cover")} /></label></div>
                {touristForm.imageUrl ? <div className="mt-3 flex items-center gap-3"><img src={touristForm.imageUrl} alt={touristForm.nameEn || "Tourist cover"} className="h-20 w-28 rounded-lg object-cover" /><button type="button" onClick={removeTouristCoverImage} className="text-xs font-semibold text-rose-300 hover:text-rose-200">Cover remove</button></div> : <p className="mt-3 text-xs text-slate-500">কোনো cover image নেই।</p>}
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
                <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-sm font-semibold text-slate-100">Gallery ({touristForm.gallery.length}/{MAX_TOURIST_GALLERY_IMAGES})</p><p className="text-xs text-slate-500">সব বিদ্যমান ছবি রাখা, caption সম্পাদনা, ক্রম বদল ও নিশ্চিতভাবে তালিকা থেকে সরানো যায়।</p></div><label className={`cursor-pointer rounded-lg px-3 py-2 text-xs font-bold text-white ${touristForm.gallery.length >= MAX_TOURIST_GALLERY_IMAGES ? "bg-slate-700 cursor-not-allowed" : "bg-sky-600 hover:bg-sky-500"}`}>Gallery upload<input type="file" accept="image/*" className="hidden" disabled={touristForm.gallery.length >= MAX_TOURIST_GALLERY_IMAGES} onChange={(event) => handleTouristImageUpload(event, "gallery")} /></label></div>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">{touristForm.gallery.map((item, index) => <div key={`${item.url}-${index}`} className="rounded-lg border border-slate-800 bg-slate-950 p-2"><div className="flex gap-2"><img src={item.url} alt={item.captionEn || `Gallery ${index + 1}`} className="h-16 w-20 rounded object-cover" /><div className="min-w-0 flex-1 space-y-1"><p className="text-[11px] font-semibold text-slate-400">ছবি {index + 1}</p><input value={item.captionBn} onChange={(event) => setTouristForm((current) => ({ ...current, gallery: current.gallery.map((galleryItem, galleryIndex) => galleryIndex === index ? { ...galleryItem, captionBn: event.target.value } : galleryItem) }))} placeholder="বাংলা caption" className="w-full rounded border border-slate-800 bg-slate-900 px-2 py-1 text-xs text-white" /><input value={item.captionEn} onChange={(event) => setTouristForm((current) => ({ ...current, gallery: current.gallery.map((galleryItem, galleryIndex) => galleryIndex === index ? { ...galleryItem, captionEn: event.target.value } : galleryItem) }))} placeholder="English caption" className="w-full rounded border border-slate-800 bg-slate-900 px-2 py-1 text-xs text-white" /></div></div><div className="mt-2 flex flex-wrap items-center gap-2"><button type="button" disabled={index === 0} onClick={() => moveTouristGalleryImage(index, index - 1)} className="rounded border border-slate-700 px-2 py-1 text-[11px] font-semibold text-slate-200 disabled:cursor-not-allowed disabled:opacity-40">আগে</button><button type="button" disabled={index === touristForm.gallery.length - 1} onClick={() => moveTouristGalleryImage(index, index + 1)} className="rounded border border-slate-700 px-2 py-1 text-[11px] font-semibold text-slate-200 disabled:cursor-not-allowed disabled:opacity-40">পরে</button><button type="button" onClick={() => removeTouristGalleryImage(index)} className="text-xs font-semibold text-rose-300 hover:text-rose-200">মুছুন</button></div></div>)}</div>
              </div>
              <div className="flex flex-wrap gap-2"><button type="submit" disabled={createTouristMutation.isPending || updateTouristMutation.isPending} className="rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-500 disabled:opacity-50">{touristForm.id ? "Save Changes" : "Add Tourist Spot"}</button>{touristForm.id && <button type="button" onClick={() => setTouristForm(emptyTouristForm)} className="rounded-xl border border-slate-700 px-4 py-2.5 text-sm font-semibold text-slate-300 hover:border-slate-500">Cancel</button>}</div>
            </form>

            <div className="grid gap-3 md:grid-cols-2">{touristPlacesQuery.isLoading ? <p className="text-sm text-slate-400">Tourist Spots লোড হচ্ছে…</p> : (touristPlacesQuery.data ?? []).map((place: any) => <article key={place.id} className="rounded-xl border border-slate-800 bg-slate-950/60 p-3"><div className="flex gap-3"><img src={place.imageUrl || "https://placehold.co/160x100/0f172a/94a3b8?text=No+Image"} alt={place.nameEn} className="h-20 w-28 rounded-lg object-cover" /><div className="min-w-0 flex-1"><h3 className="truncate font-bold text-slate-100">{place.nameBn} <span className="font-normal text-slate-400">/ {place.nameEn}</span></h3><p className="mt-1 text-xs text-slate-500">{place.location} · {place.category} · {place.visible ? "Visible" : "Hidden"}</p><div className="mt-2 flex flex-wrap gap-2"><button type="button" onClick={() => { let gallery: TouristGalleryItem[] = []; try { gallery = JSON.parse(place.galleryJson || "[]"); } catch { gallery = []; } setTouristForm({ id: place.id, nameBn: place.nameBn ?? "", nameEn: place.nameEn ?? "", descBn: place.descBn ?? "", descEn: place.descEn ?? "", imageUrl: place.imageUrl ?? "", gallery, category: place.category, location: place.location ?? "", mapUrl: place.mapUrl ?? "", visible: Boolean(place.visible), displayOrder: place.displayOrder ?? 0 }); }} className="rounded-lg border border-sky-500/40 px-2.5 py-1.5 text-xs font-semibold text-sky-200 hover:bg-sky-500/10">Edit</button><button type="button" onClick={() => { if (window.confirm("আপনি কি নিশ্চিত? এই Tourist Spot মুছে ফেলা হবে।")) deleteTouristMutation.mutate({ id: place.id }); }} className="rounded-lg border border-rose-500/40 px-2.5 py-1.5 text-xs font-semibold text-rose-200 hover:bg-rose-500/10">Delete</button></div></div></div></article>)}</div>
	          </section></div>
	          </details>

	          {/* Mobile Media & Folder Management Section */}
	          <details id="cms-mobile-media" className="scroll-mt-24 rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
	            <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">মোবাইল ছবি ও ফাইল</span><span className="mt-1 block text-xs font-normal text-slate-400">Folder, upload, replace ও delete পরিচালনা করুন</span></summary>
	            <div className="space-y-6 border-t border-slate-800 p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold flex items-center space-x-2">
                  <ImageIcon className="w-5 h-5 text-emerald-400" />
                  <span>মোবাইল ছবি ও ফোল্ডার ম্যানেজার</span>
                </h2>
                <p className="text-slate-400 text-sm">আপনার মোবাইল বা কম্পিউটার থেকে যেকোনো ছবি ও ফোল্ডার আপলোড করুন এবং ড্যাশবোর্ডে সংরক্ষণ করুন।</p>
              </div>
              <div className="flex items-center space-x-3">
                <label className="cursor-pointer bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white px-4 py-2.5 rounded-xl text-sm font-medium transition shadow-lg flex items-center space-x-2">
                  <Upload className="w-4 h-4" />
                  <span>{uploading ? "আপলোড হচ্ছে..." : "নতুন ছবি/ফাইল আপলোড"}</span>
                  <input type="file" accept="image/*,application/pdf,.zip" onChange={handleFileUpload} className="hidden" disabled={uploading} />
                </label>
              </div>
            </div>

            {uploadMessage && (
              <div className="bg-emerald-950/60 border border-emerald-800 text-emerald-300 px-4 py-3 rounded-xl text-sm flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{uploadMessage}</span>
              </div>
            )}

            {/* Folder Tabs */}
            <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-4">
              <button
                onClick={() => setSelectedFolder("All")}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition ${
                  selectedFolder === "All" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}
              >
                সব ফোল্ডার ({mediaFiles.length})
              </button>
              {folders.map((folder) => {
                const count = mediaFiles.filter((f: any) => f.folderName === folder).length;
                return (
                  <button
                    key={folder}
                    onClick={() => setSelectedFolder(folder)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition flex items-center space-x-1.5 ${
                      selectedFolder === folder ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                    }`}
                  >
                    <span>{folder}</span>
                    <span className="bg-slate-900/60 px-1.5 py-0.5 rounded text-[10px]">{count}</span>
                  </button>
                );
              })}
            </div>

            {/* Folder Contents Grid */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-slate-300">
                  বর্তমান ফোল্ডার: <span className="text-emerald-400">{selectedFolder}</span> ({filteredFiles.length}টি ফাইল)
                </h3>
              </div>

              {filteredFiles.length === 0 ? (
                <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-12 text-center text-slate-400 space-y-3">
                  <ImageIcon className="w-12 h-12 text-slate-600 mx-auto" />
                  <p className="text-sm font-medium">এই ফোল্ডারে এখনো কোনো ছবি বা ফাইল আপলোড করা হয়নি।</p>
                  <p className="text-xs text-slate-500">উপরের "নতুন ছবি/ফাইল আপলোড" বাটনে ক্লিক করে আপনার মোবাইল গ্যালারি থেকে ছবি যুক্ত করুন।</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {filteredFiles.map((file: any) => (
                    <div key={file.id} className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow group hover:border-emerald-500/50 transition">
                      <div className="aspect-video bg-slate-900 relative overflow-hidden flex items-center justify-center">
                        {file.fileType === "image" ? (
                          <img src={file.fileUrl} alt={file.fileName} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                        ) : (
                          <div className="text-xs text-slate-400 font-mono p-2 text-center truncate">{file.fileName}</div>
                        )}
                        <span className="absolute top-2 right-2 bg-slate-900/80 backdrop-blur text-[10px] text-emerald-400 px-2 py-0.5 rounded font-medium">
                          {file.folderName}
                        </span>
                      </div>
                      <div className="p-3">
                        <p className="text-xs font-medium text-slate-200 truncate" title={file.fileName}>{file.fileName}</p>
                        <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400">
                          <span>{file.fileSize || "ফাইল"}</span>
                          <a href={file.fileUrl} target="_blank" rel="noopener noreferrer" className="text-emerald-400 hover:underline">
                            দেখুন ↗
                          </a>
                        </div>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <label className="cursor-pointer rounded-lg border border-sky-500/40 px-2 py-1.5 text-[11px] font-semibold text-sky-200 hover:bg-sky-500/10">Replace<input type="file" accept="image/*,application/pdf,.zip" className="hidden" onChange={(event) => handleMediaReplace(event, file)} /></label>
                          <button type="button" onClick={() => { if (window.confirm("আপনি কি নিশ্চিত? এই media file মুছে ফেলা হবে।")) deleteMediaMutation.mutate({ id: file.id }); }} className="rounded-lg border border-rose-500/40 px-2 py-1.5 text-[11px] font-semibold text-rose-200 hover:bg-rose-500/10">Delete</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
	          </div>
	          </details>

	          <details id="cms-operations" className="scroll-mt-24 rounded-2xl border border-sky-500/20 bg-slate-900 shadow-xl">
	            <summary className="cursor-pointer list-none px-5 py-4 [&::-webkit-details-marker]:hidden"><span className="block text-lg font-bold text-slate-100">সিস্টেম, নিরাপত্তা ও সেটিংস</span><span className="mt-1 block text-xs font-normal text-slate-400">Private verification, report, SEO, backup এবং owner tools</span></summary>
	            <div className="border-t border-slate-800 p-4 sm:p-6"><section className="space-y-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><h2 className="flex items-center gap-2 text-xl font-bold"><Settings2 className="h-5 w-5 text-sky-300" /> Final Site Controls</h2><p className="mt-1 text-sm leading-6 text-slate-400">SEO, lead, announcement, blog, backup, health ও speed controls শুধুমাত্র owner session-এ কাজ করে।</p></div><span className="rounded-full border border-sky-400/25 bg-sky-950/40 px-3 py-1 text-xs font-semibold text-sky-200">বাংলা default · English optional</span></div>
            {managementMessage && <p className="rounded-xl border border-emerald-500/30 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-200">{managementMessage}</p>}

            <section aria-labelledby="private-trade-licence-heading" className="rounded-2xl border border-emerald-400/25 bg-emerald-950/15 p-4">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="max-w-3xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 id="private-trade-licence-heading" className="flex items-center gap-2 font-bold text-emerald-100"><ShieldCheck className="h-4 w-4" /> Private institutional verification</h3>
                    <span className="rounded-full border border-emerald-400/25 bg-emerald-400/10 px-2.5 py-1 text-[11px] font-bold text-emerald-100">Owner only · Not public</span>
                  </div>
                  <p className="mt-2 text-sm leading-6 text-slate-300">
                    {institutionalVerification?.tradeLicenceStatus === "owner_confirms_held"
                      ? `Owner acknowledgement recorded${tradeLicenceRecordedDate ? ` on ${tradeLicenceRecordedDate}` : ""}.`
                      : "No owner acknowledgement has been recorded yet."}
                  </p>
                  <p className="mt-1 text-xs leading-5 text-slate-400">এই registry কেবল private status রাখে। লাইসেন্সের ছবি, নম্বর, স্বাক্ষর, ঠিকানা বা অন্য ব্যক্তিগত document এখানে বা public site-এ রাখা হয় না। এটি কোনো public verification badge, partnership approval বা payment permission নয়।</p>
                </div>
                <button
                  type="button"
                  disabled={institutionalVerification?.tradeLicenceStatus === "owner_confirms_held" || confirmTradeLicenceHeldMutation.isPending || !siteWorkspaceQuery.data}
                  onClick={() => {
                    if (window.confirm("আমি নিশ্চিত করছি যে বৈধ ট্রেড লাইসেন্স আমার কাছে আছে। কোনো লাইসেন্স ছবি বা নম্বর এই সিস্টেমে সংরক্ষণ হবে না।")) {
                      confirmTradeLicenceHeldMutation.mutate();
                    }
                  }}
                  className="shrink-0 rounded-xl border border-emerald-400/35 bg-emerald-400/10 px-4 py-2.5 text-sm font-bold text-emerald-100 transition hover:bg-emerald-400/20 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {institutionalVerification?.tradeLicenceStatus === "owner_confirms_held" ? "Acknowledged" : confirmTradeLicenceHeldMutation.isPending ? "সংরক্ষণ হচ্ছে…" : "Private acknowledgement"}
                </button>
              </div>
            </section>

            <div className="grid gap-5 xl:grid-cols-2">
              <form className="space-y-3 rounded-2xl border border-slate-800 bg-slate-950/50 p-4" onSubmit={(event) => { event.preventDefault(); const form = new FormData(event.currentTarget); const text = (name: string) => form.get(name)?.toString().trim() || null; saveSeoMutation.mutate({ seoMode: form.get("seoMode") === "manual" ? "manual" : "auto", seoSiteTitleBn: text("seoSiteTitleBn"), seoSiteTitleEn: text("seoSiteTitleEn"), seoMetaDescriptionBn: text("seoMetaDescriptionBn"), seoMetaDescriptionEn: text("seoMetaDescriptionEn"), seoKeywords: text("seoKeywords"), seoOgImageUrl: text("seoOgImageUrl"), seoFaviconUrl: text("seoFaviconUrl"), googleVerificationCode: text("googleVerificationCode"), googleAnalyticsId: text("googleAnalyticsId"), facebookPixelId: text("facebookPixelId"), robotsDirectives: text("robotsDirectives") }); }}>
                <div><h3 className="font-bold text-slate-100">SEO Settings</h3><p className="mt-1 text-xs leading-5 text-slate-400">Auto mode-এ public content থেকে SEO fallback নেওয়া হয়; Manual mode-এ নিচের values অগ্রাধিকার পায়। Sitemap public content publish হলে automatic refresh policy অনুসরণ করে।</p></div>
                <label className="block text-xs text-slate-300">SEO mode<select name="seoMode" value={seoMode} onChange={(event) => setSeoMode(event.target.value === "manual" ? "manual" : "auto")} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white"><option value="auto">Auto SEO</option><option value="manual">Manual SEO</option></select></label>
                <div className="grid gap-3 sm:grid-cols-2"><label className="text-xs text-slate-300">Meta Title (বাংলা)<input name="seoSiteTitleBn" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoSiteTitleBn ?? ""} maxLength={255} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label><label className="text-xs text-slate-300">Meta Title (English)<input name="seoSiteTitleEn" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoSiteTitleEn ?? ""} maxLength={255} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label></div>
                <div className="grid gap-3 sm:grid-cols-2"><label className="text-xs text-slate-300">Meta Description (বাংলা)<textarea name="seoMetaDescriptionBn" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoMetaDescriptionBn ?? ""} maxLength={320} rows={3} className="mt-1.5 w-full resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label><label className="text-xs text-slate-300">Meta Description (English)<textarea name="seoMetaDescriptionEn" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoMetaDescriptionEn ?? ""} maxLength={320} rows={3} className="mt-1.5 w-full resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label></div>
                <label className="block text-xs text-slate-300">Keywords<input name="seoKeywords" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoKeywords ?? ""} maxLength={500} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" placeholder="Bangladesh, civic services" /></label>
                <div className="grid gap-3 sm:grid-cols-2"><label className="text-xs text-slate-300">OG Image URL<input name="seoOgImageUrl" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoOgImageUrl ?? ""} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label><label className="text-xs text-slate-300">Favicon URL<input name="seoFaviconUrl" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.seoFaviconUrl ?? ""} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label></div>
                <label className="block text-xs text-slate-300">Google verification code<input name="googleVerificationCode" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.googleVerificationCode ?? ""} maxLength={255} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label><div className="grid gap-3 sm:grid-cols-2"><label className="text-xs text-slate-300">GA4 Measurement ID<input name="googleAnalyticsId" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.googleAnalyticsId ?? ""} maxLength={120} placeholder="G-XXXXXXXXXX" className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label><label className="text-xs text-slate-300">Facebook Pixel ID<input name="facebookPixelId" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.facebookPixelId ?? ""} maxLength={120} placeholder="Pixel ID" className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label></div><label className="block text-xs text-slate-300">Robots directives<textarea name="robotsDirectives" readOnly={seoMode !== "manual"} defaultValue={seoSettingsQuery.data?.robotsDirectives ?? ""} rows={2} className="mt-1.5 w-full resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></label>
                <button type="submit" disabled={saveSeoMutation.isPending} className="rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-sky-500 disabled:opacity-60">{saveSeoMutation.isPending ? "সংরক্ষণ হচ্ছে…" : "SEO সংরক্ষণ করুন"}</button>
              </form>

              <div className="space-y-5">
                <section className="rounded-2xl border border-violet-400/25 bg-violet-950/15 p-4" aria-labelledby="public-stats-settings-heading">
                  <div className="flex flex-wrap items-start justify-between gap-3"><div><h3 id="public-stats-settings-heading" className="font-bold text-violet-100">{language === "EN" ? "Public Stats Settings" : "পাবলিক স্ট্যাটস সেটিংস"}</h3><p className="mt-1 text-xs leading-5 text-slate-400">{language === "EN" ? "Choose which analytics cards are visible to public visitors. These choices are saved in Site Settings." : "পাবলিক ভিজিটরদের জন্য কোন analytics card দেখা যাবে তা বেছে নিন। পছন্দগুলো Site Settings-এ সংরক্ষিত হবে।"}</p></div><span className="rounded-full border border-violet-400/25 bg-violet-400/10 px-2.5 py-1 text-[11px] font-bold text-violet-100">{language === "EN" ? "Owner only" : "শুধু Owner"}</span></div>
                  <div className="mt-4 grid gap-2 sm:grid-cols-2">{publicStatsOptions.map((option) => <label key={option.key} className="flex cursor-pointer items-center gap-3 rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-2.5 text-sm text-slate-200 transition hover:border-violet-400/35"><input type="checkbox" checked={publicStatsDraft[option.key]} onChange={(event) => setPublicStatsDraft((current) => ({ ...current, [option.key]: event.target.checked }))} className="h-4 w-4 accent-violet-500" /><span>{language === "EN" ? option.en : option.bn}</span></label>)}</div>
                  <button type="button" onClick={savePublicStatsSettings} disabled={saveContentSettingsMutation.isPending || !siteWorkspaceQuery.data?.settings} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-violet-500 disabled:cursor-not-allowed disabled:opacity-60"><Save className="h-4 w-4" />{saveContentSettingsMutation.isPending ? (language === "EN" ? "Saving…" : "সংরক্ষণ হচ্ছে…") : (language === "EN" ? "Save Changes" : "পরিবর্তন সংরক্ষণ করুন")}</button>
                </section>
                <form className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4" onSubmit={(event) => { event.preventDefault(); const form = new FormData(event.currentTarget); const text = (name: string) => form.get(name)?.toString().trim() || null; saveAnnouncementMutation.mutate({ messageBn: String(form.get("messageBn") || "").trim(), messageEn: text("messageEn"), linkUrl: text("linkUrl"), color: announcementQuery.data?.color ?? "#0d5c56", enabled: form.get("enabled") === "on" }); }}><h3 className="font-bold text-slate-100">Announcement Banner</h3><p className="mt-1 text-xs text-slate-400">সাইটের এক লাইনের উপরের নোটিশ।</p><div className="mt-3 grid gap-3"><input name="messageBn" required defaultValue={announcementQuery.data?.messageBn ?? ""} maxLength={300} placeholder="বার্তা (বাংলা)" className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><input name="messageEn" defaultValue={announcementQuery.data?.messageEn ?? ""} maxLength={300} placeholder="Message (English)" className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><input name="linkUrl" defaultValue={announcementQuery.data?.linkUrl ?? ""} placeholder="ঐচ্ছিক নিরাপদ link" className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><label className="flex items-center gap-2 text-sm text-slate-300"><input name="enabled" type="checkbox" defaultChecked={announcementQuery.data?.enabled === 1} /> Public site-এ দেখান</label><button type="submit" disabled={saveAnnouncementMutation.isPending} className="rounded-xl border border-amber-400/30 bg-amber-500/10 px-4 py-2.5 text-sm font-bold text-amber-200">Banner সংরক্ষণ করুন</button></div></form>
                <div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><h3 className="font-bold text-slate-100">Leads Management</h3><p className="mt-1 text-xs text-slate-400">Complaint/contact form থেকে আসা বার্তা।</p></div><button type="button" onClick={downloadLeadsCsv} className="rounded-lg border border-emerald-400/30 px-3 py-2 text-xs font-bold text-emerald-200">CSV Export</button></div><div className="mt-3 max-h-48 overflow-auto rounded-xl border border-slate-800"><table className="w-full text-left text-xs"><thead className="bg-slate-900 text-slate-400"><tr><th className="p-2">নাম</th><th className="p-2">বিষয়</th><th className="p-2">অবস্থা ও কাজ</th></tr></thead><tbody>{(leadsQuery.data || []).slice(0, 12).map((lead: any) => <tr key={lead.id} className="border-t border-slate-800"><td className="p-2 text-slate-200">{lead.name}<div className="text-slate-500">{lead.mobile}</div></td><td className="p-2 text-slate-300">{lead.subject || "—"}</td><td className="p-2"><div className="flex flex-wrap items-center gap-2"><select value={lead.status} onChange={(event) => updateLeadStatusMutation.mutate({ id: lead.id, status: event.target.value as "new" | "reviewed" | "closed" })} className="rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-200"><option value="new">নতুন</option><option value="reviewed">পড়া হয়েছে</option><option value="closed">বন্ধ</option></select><button type="button" disabled={deleteLeadMutation.isPending} onClick={() => { if (window.confirm("আপনি কি নিশ্চিত? এই spam lead টি স্থায়ীভাবে ডিলেট হবে।")) deleteLeadMutation.mutate({ id: lead.id }); }} className="rounded border border-rose-500/45 px-2 py-1 text-xs font-bold text-rose-200 transition hover:bg-rose-500/10 disabled:opacity-50">ডিলেট</button></div></td></tr>)}</tbody></table></div></div>
              </div>
            </div>

            <div className="grid gap-5 xl:grid-cols-2">
              <form className="space-y-3 rounded-2xl border border-slate-800 bg-slate-950/50 p-4" onSubmit={(event) => { event.preventDefault(); const form = new FormData(event.currentTarget); createBlogMutation.mutate({ titleBn: String(form.get("titleBn") || "").trim(), titleEn: form.get("titleEn")?.toString().trim() || null, slug: newBlogSlug.trim(), excerptBn: String(form.get("excerptBn") || "").trim(), excerptEn: form.get("excerptEn")?.toString().trim() || null, contentBn: String(form.get("contentBn") || "").trim(), contentEn: form.get("contentEn")?.toString().trim() || null, coverImageUrl: form.get("coverImageUrl")?.toString().trim() || null, pdfUrl: null, isPinned: false, status: form.get("status") === "draft" ? "draft" : "published" }); event.currentTarget.reset(); setNewBlogSlug(""); }}><h3 className="font-bold text-slate-100">Blog / News</h3><div className="grid gap-3 sm:grid-cols-2"><input name="titleBn" required placeholder="শিরোনাম (বাংলা)" className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><input name="titleEn" placeholder="Title (English)" className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></div><input value={newBlogSlug} onChange={(event) => setNewBlogSlug(event.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, ""))} required placeholder="slug যেমন: service-update" className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><div className="grid gap-3 sm:grid-cols-2"><textarea name="excerptBn" required rows={2} placeholder="সংক্ষিপ্ত বিবরণ (বাংলা)" className="resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><textarea name="excerptEn" rows={2} placeholder="Excerpt (English)" className="resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></div><div className="grid gap-3 sm:grid-cols-2"><textarea name="contentBn" required rows={4} placeholder="মূল লেখা (বাংলা)" className="resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><textarea name="contentEn" rows={4} placeholder="Main content (English)" className="resize-y rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /></div><input name="coverImageUrl" placeholder="Cover image URL (ঐচ্ছিক)" className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white" /><select name="status" className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white"><option value="published">Publish now</option><option value="draft">Draft</option></select><button type="submit" disabled={createBlogMutation.isPending} className="rounded-xl bg-fuchsia-700 px-4 py-2.5 text-sm font-bold text-white">{createBlogMutation.isPending ? "সংরক্ষণ হচ্ছে…" : "Blog সংরক্ষণ করুন"}</button><div className="max-h-36 space-y-2 overflow-auto">{(blogPostsQuery.data || []).map((post: any) => <div key={post.id} className="flex items-center justify-between gap-3 rounded-lg bg-slate-900 px-3 py-2 text-xs"><span className="truncate text-slate-200">{post.titleBn}</span><button type="button" onClick={() => confirm("এই post মুছবেন?") && deleteBlogMutation.mutate({ id: post.id })} className="text-rose-300">মুছুন</button></div>)}</div></form>
              <div className="space-y-5"><div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><h3 className="font-bold text-slate-100">Backup & Restore</h3><p className="mt-1 text-xs leading-5 text-slate-400">Site content JSON backup download করুন। Restore করার আগে preview ও confirmation বাধ্যতামূলক। Media file bytes বা private credentials backup-এ থাকে না।</p><div className="mt-3 flex flex-wrap gap-2"><button type="button" onClick={downloadBackup} className="rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white">Backup Now</button><label className="cursor-pointer rounded-xl border border-slate-600 px-4 py-2.5 text-sm font-bold text-slate-200">Restore preview<input type="file" accept="application/json,.json" onChange={(event) => loadRestorePreview(event.target.files?.[0])} className="hidden" /></label></div>{restorePreview && <div className="mt-3 rounded-xl border border-amber-400/30 bg-amber-950/20 p-3 text-xs text-amber-100"><p>Preview: {restorePreview.blogPosts?.length ?? 0} posts, {restorePreview.quickLinks?.length ?? 0} links, {restorePreview.folders?.length ?? 0} folders.</p><button type="button" onClick={() => confirm("Preview করা content দিয়ে বর্তমান site management data replace করবেন?") && restoreBackupMutation.mutate(restorePreview)} disabled={restoreBackupMutation.isPending} className="mt-2 rounded-lg bg-amber-500 px-3 py-2 font-bold text-slate-950">Confirm Restore</button></div>}<div className="mt-4 rounded-xl border border-rose-500/25 bg-rose-950/15 p-3"><div className="flex flex-wrap items-start justify-between gap-3"><div><h4 className="font-semibold text-rose-100">২৪ ঘণ্টার Auto Backup ও Reset</h4><p className="mt-1 text-xs leading-5 text-slate-400">শুধু owner-managed public content reset হবে। Password, login, biometric data, leads, payment বা file bytes কখনো restore-এর অংশ নয়।</p></div><span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${scheduledBackupStatusQuery.data?.automation.enabled ? "bg-emerald-500/15 text-emerald-200" : "bg-amber-500/15 text-amber-200"}`}>{scheduledBackupStatusQuery.data?.automation.taskConfigured ? scheduledBackupStatusQuery.data?.automation.enabled ? "Daily schedule active" : "Schedule paused" : "Schedule setup pending"}</span></div><div className="mt-3 space-y-1 text-xs text-slate-300">{scheduledBackupStatusQuery.isLoading ? <p>Backup status লোড হচ্ছে…</p> : scheduledBackupStatusQuery.data?.available ? <p>সর্বশেষ recovery snapshot: <b className="text-emerald-200">{scheduledBackupStatusQuery.data.dayKey}</b> · {scheduledBackupStatusQuery.data.createdAt ? new Date(scheduledBackupStatusQuery.data.createdAt).toLocaleString("bn-BD") : "সময় পাওয়া যায়নি"}</p> : <p className="text-amber-200">এখনও কোনো recovery snapshot নেই। প্রথম automated run-এর পরে Reset চালু হবে।</p>}<p>সর্বশেষ automated run: {scheduledBackupStatusQuery.data?.automation.lastSuccessfulRunAt ? new Date(scheduledBackupStatusQuery.data.automation.lastSuccessfulRunAt).toLocaleString("bn-BD") : "এখনও সম্পন্ন হয়নি"}</p></div><div className="mt-3 flex flex-wrap gap-2"><button type="button" onClick={() => scheduledBackupStatusQuery.refetch()} className="rounded-lg border border-slate-600 px-3 py-2 text-xs font-bold text-slate-200">Status refresh</button><button type="button" onClick={() => { setResetConfirmation(""); setShowResetDialog(true); }} disabled={!scheduledBackupStatusQuery.data?.available || resetToLastBackupMutation.isPending} className="rounded-lg bg-rose-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-rose-500 disabled:cursor-not-allowed disabled:opacity-50">Reset to Last Backup</button></div></div></div><div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4"><h3 className="font-bold text-slate-100">Site Health & Performance Tools</h3><div className="mt-3 grid gap-2 sm:grid-cols-2">{(healthQuery.data?.checks || []).map((check: any) => <div key={check.key} className={`rounded-xl border p-3 text-xs ${check.status === "pass" ? "border-emerald-500/25 bg-emerald-950/20 text-emerald-100" : "border-amber-500/25 bg-amber-950/20 text-amber-100"}`}><b>{check.label}</b><p className="mt-1 opacity-85">{check.detail}</p></div>)}</div><div className="mt-3 flex flex-wrap gap-2"><button type="button" onClick={() => clearCacheMutation.mutate()} disabled={clearCacheMutation.isPending} className="rounded-lg border border-sky-400/30 px-3 py-2 text-xs font-bold text-sky-200">Clear Cache</button><button type="button" onClick={() => optimizeImagesMutation.mutate()} disabled={optimizeImagesMutation.isPending} className="rounded-lg border border-fuchsia-400/30 px-3 py-2 text-xs font-bold text-fuchsia-200">Optimize All Images</button><button type="button" onClick={() => { healthQuery.refetch(); siteLogsQuery.refetch(); scheduledBackupStatusQuery.refetch(); }} className="rounded-lg border border-slate-600 px-3 py-2 text-xs font-bold text-slate-200">Refresh checks</button></div><div className="mt-3 max-h-32 overflow-auto rounded-xl border border-slate-800 bg-slate-900/60 p-2 text-xs">{(siteLogsQuery.data || []).map((log: any) => <p key={log.id} className="border-b border-slate-800 py-1.5 text-slate-300"><span className={log.level === "error" ? "text-rose-300" : "text-sky-300"}>{log.level}</span> · {log.operation} · {log.message}</p>)}{!siteLogsQuery.data?.length && <p className="p-1 text-slate-500">কোনো stored site log নেই।</p>}</div></div></div>
            </div>
          </section>

          <section className="grid gap-5 xl:grid-cols-2">
            <section className="rounded-2xl border border-amber-400/25 bg-amber-950/20 p-5 shadow-xl" aria-labelledby="commercial-activation-heading">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 id="commercial-activation-heading" className="font-bold text-amber-100">বিজ্ঞাপন ও ব্যবসায়িক সহযোগিতা</h2>
                  <p className="mt-1 max-w-3xl text-sm leading-6 text-slate-300">Public rate card, invoice, order status এবং payment confirmation এখন নিষ্ক্রিয়। যাচাইকৃত ব্যবসায়িক শর্ত, নিবন্ধন ও payment provider ছাড়া কোনো বিজ্ঞাপন স্থান, sponsor placement বা আয়ের ফলাফল নিশ্চিত করা হয় না।</p>
                </div>
                <span className="rounded-full border border-amber-400/35 bg-amber-400/10 px-2.5 py-1 text-[11px] font-bold text-amber-100">Review-first · payment unavailable</span>
              </div>
              <div className="mt-4 rounded-xl border border-amber-400/20 bg-slate-950/40 p-3 text-xs leading-5 text-slate-300">
                প্রতিষ্ঠানের আগ্রহী প্রতিনিধি নিরাপদ public inquiry route দিয়ে প্রস্তাব পাঠাতে পারেন। Owner review ছাড়া কোনো প্রকাশ, মূল্য, invoice, payment request, campaign activation বা partner endorsement হবে না।
              </div>
            </section>
            <div className="rounded-2xl border border-teal-500/20 bg-slate-900 p-5 shadow-xl"><h2 className="font-bold text-slate-100">Investor Leads</h2><p className="mt-1 text-sm leading-6 text-slate-400">Public Investors page থেকে পাঠানো যোগাযোগ বার্তা। Public page-এ কেবল available analytics snapshot ও plan info দেখানো হবে—কোনো fabricated revenue বা traffic নয়।</p><div className="mt-4 max-h-64 overflow-auto rounded-xl border border-slate-800"><table className="w-full text-left text-xs"><thead className="bg-slate-950 text-slate-400"><tr><th className="p-2">নাম</th><th className="p-2">Organisation</th><th className="p-2">বার্তা</th><th className="p-2">অবস্থা</th></tr></thead><tbody>{(investorLeadsQuery.data || []).map((lead: any) => <tr key={lead.id} className="border-t border-slate-800 align-top"><td className="p-2 text-slate-200">{lead.name}<div className="text-slate-500">{lead.email}</div></td><td className="p-2 text-slate-300">{lead.organisation || "—"}</td><td className="max-w-44 p-2 text-slate-300">{lead.message}</td><td className="p-2"><select value={lead.status} onChange={(event) => updateInvestorLeadMutation.mutate({ id: lead.id, status: event.target.value as "new" | "reviewed" | "closed" })} className="rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-200"><option value="new">New</option><option value="reviewed">Reviewed</option><option value="closed">Closed</option></select></td></tr>)}</tbody></table>{!investorLeadsQuery.data?.length && <p className="p-4 text-center text-xs text-slate-500">এখনও কোনো investor lead নেই।</p>}</div></div>
          </section>

          {showResetDialog && <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/80 p-4 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="reset-backup-title"><div className="w-full max-w-md rounded-2xl border border-rose-500/40 bg-slate-900 p-5 shadow-2xl"><h2 id="reset-backup-title" className="text-lg font-bold text-rose-100">সর্বশেষ backup থেকে Reset করবেন?</h2><p className="mt-2 text-sm leading-6 text-slate-300">এই কাজটি বর্তমান owner-managed লেখা, links, announcement, blog ও media folder configuration-কে সর্বশেষ scheduled snapshot-এর অবস্থায় ফিরিয়ে দেবে। এটি ফিরিয়ে নেওয়া যাবে না।</p><label className="mt-4 block text-xs font-semibold text-slate-300">নিশ্চিত করতে <span className="font-mono text-rose-200">RESET_TO_LAST_BACKUP</span> লিখুন<input autoFocus value={resetConfirmation} onChange={(event) => setResetConfirmation(event.target.value)} className="mt-2 w-full rounded-xl border border-slate-600 bg-slate-950 px-3 py-2.5 text-sm text-white outline-none focus:border-rose-400" /></label><div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" onClick={() => { setShowResetDialog(false); setResetConfirmation(""); }} disabled={resetToLastBackupMutation.isPending} className="rounded-xl border border-slate-600 px-4 py-2.5 text-sm font-bold text-slate-200">বাতিল</button><button type="button" onClick={() => resetToLastBackupMutation.mutate({ confirmation: "RESET_TO_LAST_BACKUP" })} disabled={resetConfirmation !== "RESET_TO_LAST_BACKUP" || resetToLastBackupMutation.isPending} className="rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-rose-500 disabled:cursor-not-allowed disabled:opacity-50">{resetToLastBackupMutation.isPending ? "Reset হচ্ছে…" : "হ্যাঁ, Reset করুন"}</button></div></div></div>}

          {/* User Management System */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-xl font-bold flex items-center space-x-2">
                  <Users className="w-5 h-5 text-emerald-400" />
                  <span>অ্যাডমিন ইউজার ম্যানেজমেন্ট (সুপার অ্যাডমিন কট্রোল)</span>
                </h2>
                <p className="text-slate-400 text-sm mt-1">
                  শুধুমাত্র আপনি (Primary Owner) নতুন অ্যাডমিন যুক্ত বা বাদ দিতে পারবেন। আপনার সুপার অ্যাডমিন অধিকার সম্পূর্ণ সুরক্ষিত।
                </p>
              </div>
              <div className="bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-xs text-emerald-300 font-medium flex items-center space-x-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>মালিকানা সুরক্ষিত (Protected Super Admin)</span>
              </div>
            </div>

            {memberMsg && (
              <div className="mb-6 bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 px-4 py-3 rounded-xl text-sm font-medium">
                {memberMsg}
              </div>
            )}

            {/* Add Member Form */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 mb-6">
              <h3 className="text-sm font-semibold text-slate-200 mb-3 flex items-center space-x-2">
                <UserPlus className="w-4 h-4 text-emerald-400" />
                <span>নতুন অ্যাডমিন সদস্য যুক্ত করুন</span>
              </h3>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newAdminEmail || !newAdminName) return;
                  addMemberMutation.mutate({
                    email: newAdminEmail,
                    name: newAdminName,
                    role: newAdminRole,
                  });
                }}
                className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end"
              >
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">সদস্যের নাম</label>
                  <input
                    type="text"
                    placeholder="যেমন: রাহিম আহমেদ"
                    value={newAdminName}
                    onChange={(e) => setNewAdminName(e.target.value)}
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">ইমেইল ঠিকানা</label>
                  <input
                    type="email"
                    placeholder="admin@example.com"
                    value={newAdminEmail}
                    onChange={(e) => setNewAdminEmail(e.target.value)}
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">ভূমিকা (Role)</label>
                  <select
                    value={newAdminRole}
                    onChange={(e) => setNewAdminRole(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Viewer">Viewer (শুধু দেখা)</option>
                    <option value="Editor">Editor (কনটেন্ট/ফাইল সম্পাদনা)</option>
                    <option value="Admin">Admin (দৈনন্দিন প্রশাসন)</option>
                  </select>
                </div>
                <div>
                  <button
                    type="submit"
                    disabled={addMemberMutation.isPending}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-medium py-2 px-4 rounded-lg text-sm transition flex items-center justify-center space-x-1.5 shadow"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>{addMemberMutation.isPending ? "যোগ হচ্ছে..." : "অ্যাডমিন যুক্ত করুন"}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Members Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-300">
                <thead className="bg-slate-950 text-xs uppercase text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="px-4 py-3">নাম ও ইমেইল</th>
                    <th className="px-4 py-3">ভূমিকা (Role)</th>
                    <th className="px-4 py-3">স্ট্যাটাস</th>
                    <th className="px-4 py-3">যুক্ত করেছেন</th>
                    <th className="px-4 py-3 text-right">কার্যক্রম</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {/* Primary Owner Permanent Row */}
                  <tr className="bg-emerald-950/20">
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-100">Primary Super Owner</div>
                      <div className="text-xs text-slate-400">গোপনীয় মালিকের অ্যাকাউন্ট</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="bg-emerald-600/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-1 rounded-full font-medium">
                        Super Owner (প্রধান মালিক)
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-emerald-400 text-xs flex items-center space-x-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                        <span>Active (সুরক্ষিত)</span>
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">System Built-in</td>
                    <td className="px-4 py-3 text-right">
                      <span className="text-xs text-slate-500 italic">অপরিবর্তনযোগ্য (Protected)</span>
                    </td>
                  </tr>

                  {/* Dynamic Members */}
                  {(membersQuery.data || []).map((member: any) => (
                    <tr key={member.id} className="hover:bg-slate-950/40 transition">
                      <td className="px-4 py-3">
                        <div className="font-medium text-slate-100">{member.name}</div>
                        <div className="text-xs text-slate-400">{member.email}</div>
                      </td>
                      <td className="px-4 py-3">
                        <select value={member.role === "Moderator" ? "Viewer" : member.role} onChange={(event) => updateRoleMutation.mutate({ id: member.id, role: event.target.value as "Viewer" | "Editor" | "Admin" })} disabled={updateRoleMutation.isPending} className="bg-slate-800 text-slate-200 border border-slate-700 text-xs px-2.5 py-1 rounded-lg focus:outline-none focus:border-emerald-500 disabled:opacity-50"><option value="Viewer">Viewer</option><option value="Editor">Editor</option><option value="Admin">Admin</option></select>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-emerald-400 text-xs">{member.status}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-400">{member.addedBy}</td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex flex-wrap justify-end gap-2">
                          <button type="button" onClick={() => setSelectedMemberId(member.id)} className="inline-flex items-center gap-1 rounded-lg border border-sky-500/30 bg-sky-950/20 px-2.5 py-1 text-xs font-medium text-sky-300 transition hover:bg-sky-950/50"><SlidersHorizontal className="h-3.5 w-3.5" /> ফিচার</button>
                          <button
                            onClick={() => {
                              if (confirm(`আপনি কি নিশ্চিত যে ${member.name}-কে অ্যাডমিন তালিকা থেকে বাদ দিতে চান?`)) {
                                removeMemberMutation.mutate({ id: member.id });
                              }
                            }}
                            className="bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 px-3 py-1 rounded-lg text-xs font-medium transition inline-flex items-center space-x-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>রিমুভ করুন</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}

                  {(!membersQuery.data || membersQuery.data.length === 0) && (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-slate-500 text-xs">
                        কোনো অতিরিক্ত অ্যাডমিন সদস্য যুক্ত করা হয়নি। আপনি চাইলে উপরের ফর্ম থেকে নতুন সদস্য যুক্ত করতে পারেন।
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
	            {selectedMember && (
	              <div className="mt-5 rounded-xl border border-sky-500/25 bg-sky-950/20 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2"><div><h3 className="text-sm font-bold text-sky-100">{selectedMember.name}-এর ফিচার অনুমতি</h3><p className="mt-1 text-xs text-slate-400">Role-এর মৌলিক সীমা অতিক্রম করা যাবে না; Viewer শুধু analytics/export, Editor media-ও ব্যবহার করতে পারবেন।</p></div><button type="button" onClick={() => setSelectedMemberId(null)} className="text-xs text-slate-400 hover:text-white">বন্ধ করুন</button></div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  {([ ["analytics", "Analytics দেখা"], ["media", "ছবি ও ফাইল"], ["exports", "রিপোর্ট ডাউনলোড"] ] as const).map(([feature, label]) => (
                    <label key={feature} className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-700 bg-slate-900/70 px-3 py-2 text-sm text-slate-200"><input type="checkbox" checked={hasFeaturePermission(feature)} disabled={setFeaturePermissionMutation.isPending || featurePermissionsQuery.isLoading} onChange={(event) => setFeaturePermissionMutation.mutate({ memberId: selectedMember.id, feature, enabled: event.target.checked })} /> {label}</label>
                  ))}
                </div>
	              </div>
	            )}
	          </div>
	          </div>
	          </details>
	        </div>
	        </div>
	        </main>
	      </div>
	    </AdminSecurityGate>
  );
}
