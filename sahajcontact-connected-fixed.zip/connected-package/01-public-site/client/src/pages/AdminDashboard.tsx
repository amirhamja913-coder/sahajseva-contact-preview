import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import SahajHeader from "@/components/SahajHeader";
import SahajFooter from "@/components/SahajFooter";
import { 
  ShieldCheck, 
  ShieldAlert, 
  Download, 
  Search, 
  Users, 
  Award, 
  Building2, 
  Mail, 
  Phone, 
  Calendar, 
  FileText, 
  ExternalLink,
  CheckCircle2,
  Globe,
  RefreshCcw,
  Layers,
  HelpCircle
} from "lucide-react";

export default function AdminDashboard() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<"sponsors" | "applications">("sponsors");
  const [searchTerm, setSearchTerm] = useState("");

  const { 
    data: inquiriesData, 
    isLoading: inquiriesLoading, 
    error: inquiriesError,
    refetch: refetchInquiries 
  } = trpc.sponsors.getInquiries.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const { 
    data: applicationsData, 
    isLoading: appsLoading, 
    error: appsError,
    refetch: refetchApps 
  } = trpc.serviceApplications.getApplications.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const inquiries = Array.isArray(inquiriesData) ? inquiriesData : [];
  const applications = Array.isArray(applicationsData) ? applicationsData : [];

  const filteredInquiries = inquiries.filter((item: any) => 
    item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.organization?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.interest?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredApplications = applications.filter((item: any) => 
    item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.serviceNeeded?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const exportSponsorsCSV = () => {
    const headers = ["ID", "CreatedAt", "Name", "Organization", "Email", "Phone", "Interest", "Message"];
    const rows = inquiries.map((i: any) => [
      i.id,
      new Date(i.createdAt).toISOString(),
      `"${(i.name || "").replace(/"/g, '""')}"`,
      `"${(i.organization || "").replace(/"/g, '""')}"`,
      `"${(i.email || "").replace(/"/g, '""')}"`,
      `"${(i.phone || "").replace(/"/g, '""')}"`,
      `"${(i.interest || "").replace(/"/g, '""')}"`,
      `"${(i.message || "").replace(/"/g, '""')}"`,
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e: any[]) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sahajcontact_sponsor_leads_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportApplicationsCSV = () => {
    const headers = ["ID", "CreatedAt", "Name", "Phone", "ServiceNeeded"];
    const rows = applications.map((a: any) => [
      a.id,
      new Date(a.createdAt).toISOString(),
      `"${(a.name || "").replace(/"/g, '""')}"`,
      `"${(a.phone || "").replace(/"/g, '""')}"`,
      `"${(a.serviceNeeded || "").replace(/"/g, '""')}"`,
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e: any[]) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sahajcontact_service_applications_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col">
        <SahajHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-3">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-sm font-medium text-muted-foreground">যাচাই করা হচ্ছে...</p>
          </div>
        </div>
        <SahajFooter />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col">
        <SahajHeader />
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-card border border-border/80 rounded-2xl p-8 text-center shadow-lg space-y-6">
            <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-black">অ্যাডমিন লগইন প্রয়োজন</h2>
              <p className="text-sm text-muted-foreground">
                সহজসেবা অ্যাডমিন ড্যাশবোর্ডে প্রবেশ করতে আপনার অ্যাকাউন্ট দিয়ে লগইন করুন।
              </p>
            </div>
            <button
              onClick={() => startLogin()}
              className="w-full py-3 px-4 rounded-xl bg-primary text-primary-foreground font-bold shadow-md hover:bg-primary/90 transition-all"
            >
              লগইন করুন (Manus OAuth)
            </button>
          </div>
        </div>
        <SahajFooter />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col">
        <SahajHeader />
        <div className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-card border border-border/80 rounded-2xl p-8 text-center shadow-lg space-y-6">
            <div className="w-16 h-16 rounded-full bg-destructive/10 text-destructive flex items-center justify-center mx-auto">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-black">অনুমতি অস্বীকৃত (Forbidden)</h2>
              <p className="text-sm text-muted-foreground">
                এই ড্যাশবোর্ডটি শুধুমাত্র সহজসেবা অ্যাডমিনদের জন্য সংরক্ষিত। আপনার অ্যাকাউন্টটি অ্যাডমিন হিসেবে তালিকাভুক্ত নয়।
              </p>
              <p className="text-xs font-mono bg-muted py-1.5 px-3 rounded-md text-muted-foreground inline-block">
                User: {user?.name || user?.openId}
              </p>
            </div>
            <a
              href="/"
              className="inline-block w-full py-3 px-4 rounded-xl bg-primary text-primary-foreground font-bold shadow-md hover:bg-primary/90 transition-all text-center"
            >
              হোমপেজে ফিরে যান
            </a>
          </div>
        </div>
        <SahajFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <SahajHeader />
      
      <main className="flex-1 container max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Header & Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border/60 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                অ্যাডমিন প্যানেল
              </span>
              <span className="text-xs text-muted-foreground">Owner: যাচাইকৃত মালিক</span>
            </div>
            <h1 className="text-3xl font-black tracking-tight">SahajContact Management</h1>
            <p className="text-sm text-muted-foreground">
              প্রাতিষ্ঠানিক অনুসন্ধান ও সংরক্ষিত সেবা-অনুরোধের private review dashboard; এটি কোনো payment, campaign বা partner approval দেয় না।
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                refetchInquiries();
                refetchApps();
              }}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-secondary text-secondary-foreground text-xs font-semibold hover:bg-secondary/80 transition-all"
            >
              <RefreshCcw className="w-3.5 h-3.5" /> রিফ্রেশ ডেটা
            </button>
            <button
              onClick={activeTab === "sponsors" ? exportSponsorsCSV : exportApplicationsCSV}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-xs font-bold shadow-sm hover:bg-primary/90 transition-all"
            >
              <Download className="w-4 h-4" /> Export CSV ({activeTab === "sponsors" ? inquiries.length : applications.length})
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-border/60 gap-8">
          <button
            onClick={() => setActiveTab("sponsors")}
            className={`pb-3 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === "sponsors"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Award className="w-4 h-4" /> প্রাতিষ্ঠানিক ইনকোয়ারি ({inquiries.length})
          </button>
          <button
            onClick={() => setActiveTab("applications")}
            className={`pb-3 text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
              activeTab === "applications"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <FileText className="w-4 h-4" /> সংরক্ষিত সেবা-অনুরোধ ({applications.length})
          </button>
        </div>

        {/* Summary Metrics */}
        {activeTab === "sponsors" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">প্রাতিষ্ঠানিক ইনকোয়ারি</p>
              <h3 className="text-2xl font-black text-foreground">{inquiries.length}</h3>
              <p className="text-xs text-muted-foreground font-medium">শুধু private review-এর জন্য</p>
            </div>
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">প্রকাশিত মূল্য</p>
              <h3 className="text-2xl font-black text-foreground">সক্রিয় নয়</h3>
              <p className="text-xs text-muted-foreground">কোনো rate card বা payment flow চালু নেই</p>
            </div>
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">অনুমোদিত placement</p>
              <h3 className="text-2xl font-black text-foreground">ঘোষিত নয়</h3>
              <p className="text-xs text-muted-foreground">ইনকোয়ারি কোনো partnership বা placement নয়</p>
            </div>
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">আর্থিক ফলাফল</p>
              <h3 className="text-2xl font-black text-foreground">রেকর্ড করা হয়নি</h3>
              <p className="text-xs text-muted-foreground">এই dashboard invoice বা payment সম্পন্ন করে না</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">সংরক্ষিত সেবা-অনুরোধ</p>
              <h3 className="text-2xl font-black text-foreground">{applications.length}</h3>
              <p className="text-xs text-muted-foreground font-medium">ঐতিহাসিক রেকর্ড; নতুন public order বন্ধ</p>
            </div>
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">রিভিউয়ের জন্য রেকর্ড</p>
              <h3 className="text-2xl font-black text-foreground">{applications.length}</h3>
              <p className="text-xs text-muted-foreground">শুধু private Admin তালিকায় দেখা যায়</p>
            </div>
            <div className="bg-card border border-border/85 rounded-xl p-5 shadow-sm space-y-1">
              <p className="text-xs font-semibold text-muted-foreground">বাহ্যিক বিজ্ঞপ্তি</p>
              <h3 className="text-2xl font-black text-foreground">ঘোষিত নয়</h3>
              <p className="text-xs text-muted-foreground">SMS বা email alert-এর কোনো outcome claim নেই</p>
            </div>
          </div>
        )}

        {/* Search and Table Section */}
        <div className="bg-card border border-border/85 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-4 border-b border-border/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder={activeTab === "sponsors" ? "নাম, প্রতিষ্ঠান বা ইমেইল দিয়ে খুঁজুন..." : "নাম বা সেবা দিয়ে খুঁজুন..."}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>
            <div className="text-xs text-muted-foreground">
              {activeTab === "sponsors" ? `মোট ${filteredInquiries.length} টি ইনকোয়ারি` : `মোট ${filteredApplications.length} টি সংরক্ষিত অনুরোধ`}
            </div>
          </div>

          {activeTab === "sponsors" ? (
            inquiriesLoading ? (
              <div className="p-16 text-center text-muted-foreground space-y-3">
                <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p>লিড লোড হচ্ছে...</p>
              </div>
            ) : inquiriesError ? (
              <div className="p-12 text-center text-destructive space-y-2">
                <ShieldAlert className="w-8 h-8 mx-auto" />
                <p className="font-semibold">লিড লোড করতে সমস্যা হয়েছে।</p>
                <p className="text-xs text-muted-foreground">{inquiriesError.message}</p>
              </div>
            ) : filteredInquiries.length === 0 ? (
              <div className="p-16 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto text-muted-foreground">
                  <Users className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-base">কোনো প্রাতিষ্ঠানিক ইনকোয়ারি পাওয়া যায়নি</h3>
                <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                  {searchTerm ? "আপনার সার্চের সাথে মিলে এমন কোনো ইনকোয়ারি নেই।" : "review-first যোগাযোগপথে এখনও কোনো record নেই।"}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-muted/50 border-b border-border/60 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      <th className="py-3 px-4">তারিখ ও সময়</th>
                      <th className="py-3 px-4">যোগাযোগকারীর নাম</th>
                      <th className="py-3 px-4">প্রতিষ্ঠান (Company)</th>
                      <th className="py-3 px-4">ইমেইল ও ফোন</th>
                      <th className="py-3 px-4">বিষয় / আগ্রহ</th>
                      <th className="py-3 px-4">বার্তা (Message)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/40">
                    {filteredInquiries.map((item: any) => (
                      <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                        <td className="py-3.5 px-4 whitespace-nowrap text-xs text-muted-foreground">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-primary" />
                            {new Date(item.createdAt).toLocaleString("bn-BD", {
                              dateStyle: "medium",
                              timeStyle: "short",
                            })}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-foreground">
                          {item.name}
                        </td>
                        <td className="py-3.5 px-4 font-medium text-foreground">
                          <div className="flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-primary" />
                            {item.organization}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 space-y-1">
                          <a href={`mailto:${item.email}`} className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1">
                            <Mail className="w-3 h-3" /> {item.email}
                          </a>
                          {item.phone && (
                            <a href={`tel:${item.phone}`} className="text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1">
                              <Phone className="w-3 h-3" /> {item.phone}
                            </a>
                          )}
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-primary/10 text-primary">
                            <Award className="w-3 h-3" /> {item.interest}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 max-w-xs truncate text-xs text-muted-foreground" title={item.message}>
                          {item.message}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          ) : (
            appsLoading ? (
              <div className="p-16 text-center text-muted-foreground space-y-3">
                <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p>সংরক্ষিত অনুরোধ লোড হচ্ছে...</p>
              </div>
            ) : appsError ? (
              <div className="p-12 text-center text-destructive space-y-2">
                <ShieldAlert className="w-8 h-8 mx-auto" />
                <p className="font-semibold">সংরক্ষিত অনুরোধ লোড করতে সমস্যা হয়েছে।</p>
                <p className="text-xs text-muted-foreground">{appsError.message}</p>
              </div>
            ) : filteredApplications.length === 0 ? (
              <div className="p-16 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto text-muted-foreground">
                  <FileText className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-base">কোনো সংরক্ষিত সেবা-অনুরোধ পাওয়া যায়নি</h3>
                <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                  {searchTerm ? "আপনার সার্চের সাথে মিলে এমন কোনো সংরক্ষিত অনুরোধ নেই।" : "নতুন public order বা application flow বন্ধ; এখানে কেবল আগের private records দেখা যায়।"}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-muted/50 border-b border-border/60 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      <th className="py-3 px-4">তারিখ ও সময়</th>
                      <th className="py-3 px-4">রেকর্ডকৃত নাম</th>
                      <th className="py-3 px-4">মোবাইল নম্বর</th>
                      <th className="py-3 px-4">প্রয়োজনীয় সেবা (Service Needed)</th>
                      <th className="py-3 px-4">স্ট্যাটাস</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/40">
                    {filteredApplications.map((item: any) => (
                      <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                        <td className="py-3.5 px-4 whitespace-nowrap text-xs text-muted-foreground">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-primary" />
                            {new Date(item.createdAt).toLocaleString("bn-BD", {
                              dateStyle: "medium",
                              timeStyle: "short",
                            })}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-foreground">
                          {item.name}
                        </td>
                        <td className="py-3.5 px-4 font-medium text-emerald-600 dark:text-emerald-400">
                          <a href={`tel:${item.phone}`} className="hover:underline flex items-center gap-1.5">
                            <Phone className="w-3.5 h-3.5" /> {item.phone}
                          </a>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-foreground">
                          {item.serviceNeeded}
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3 h-3" /> সংরক্ষিত — manual review প্রয়োজন
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          )}
        </div>
      </main>

      <SahajFooter />
    </div>
  );
}
