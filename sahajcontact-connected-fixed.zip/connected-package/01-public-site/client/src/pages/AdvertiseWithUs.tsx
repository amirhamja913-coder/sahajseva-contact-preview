import { Link } from "wouter";
import { ArrowLeft, Building2, ClipboardCheck, ShieldCheck } from "lucide-react";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";

const bn = {
  eyebrow: "প্রতিষ্ঠান ও বিজ্ঞাপন-সংক্রান্ত আগ্রহ",
  title: "দায়িত্বশীল বিজ্ঞাপন ও ব্যবসায়িক সহযোগিতা",
  lead: "SahajContact-এ কোনো public rate card, ad order, invoice, payment, click report বা automatic placement চালু নেই। প্রতিষ্ঠান বা ব্যবসার জনস্বার্থভিত্তিক প্রস্তাব স্বাধীনভাবে review করা হয়।",
  notice: "একটি inquiry পাঠালেই বিজ্ঞাপন, sponsorship, partnership বা public listing নিশ্চিত হয় না। কোনো financial detail, payment credential বা sensitive business document এই পেজে জমা দেবেন না।",
  stepsTitle: "পর্যালোচনার পথ",
  steps: [["১", "সাধারণ যোগাযোগ", "প্রতিষ্ঠানের নাম, উদ্দেশ্য এবং যোগাযোগের প্রেক্ষাপট সংক্ষেপে Contact পেজে লিখুন।"], ["২", "স্বতন্ত্র review", "জনস্বার্থ, প্রাসঙ্গিকতা, নিরাপত্তা ও আইনসম্মততার প্রাথমিক মূল্যায়ন হবে।"], ["৩", "অনুমোদিত উত্তর", "উপযুক্ত হলে অনুমোদিত অফিসিয়াল যোগাযোগ মাধ্যমে উত্তর দেওয়া হবে; কোনো ফল স্বয়ংক্রিয় নয়।"]],
  cta: "সাধারণ যোগাযোগ খুলুন",
  ngo: "NGO/প্রতিষ্ঠান প্রস্তাব",
  back: "হোমে ফিরুন",
  safeguards: [["কোনো মূল্য বা প্যাকেজ নয়", "Review শেষ হওয়ার আগে rate, placement বা paid outcome দেখানো বা প্রতিশ্রুতি দেওয়া হয় না।"], ["কোনো public payment নয়", "এই পোর্টাল কোনো টাকা নেয় না, payment verification করে না এবং receipt দেয় না।"], ["কোনো অযাচাইকৃত দাবি নয়", "কোনো ব্যবসা, sponsor বা বিজ্ঞাপনদাতাকে approved partner হিসেবে public-এ দেখানো হয় না।"]],
};

const en = {
  eyebrow: "Institutional and advertising interest",
  title: "Responsible advertising and business collaboration",
  lead: "SahajContact has no public rate card, ad order, invoice, payment, click report, or automatic placement. Public-interest proposals from institutions and businesses are reviewed independently.",
  notice: "An inquiry does not confirm an advertisement, sponsorship, partnership, or public listing. Do not submit financial details, payment credentials, or sensitive business documents on this page.",
  stepsTitle: "Review path",
  steps: [["1", "General contact", "Briefly describe the organisation, purpose, and contact context on the Contact page."], ["2", "Independent review", "Public interest, relevance, safety, and baseline compliance are assessed."], ["3", "Approved response", "Where suitable, a response follows through an approved official channel; no outcome is automatic."]],
  cta: "Open general contact",
  ngo: "NGO/institution proposal",
  back: "Return home",
  safeguards: [["No prices or packages", "No rate, placement, or paid outcome is shown or promised before review."], ["No public payment", "This portal does not collect money, verify payments, or issue receipts."], ["No unverified claims", "No business, sponsor, or advertiser is presented publicly as an approved partner."]],
};

export default function AdvertiseWithUs() {
  const { language } = useLanguage();
  const copy = language === "EN" ? en : bn;

  return (
    <div className="min-h-screen bg-[#f8f3e8] text-[#102b3e]">
      <SahajHeader />
      <main className="overflow-hidden">
        <section className="relative border-b border-[#173c4f]/10 bg-[#f1eadb] py-16 sm:py-20">
          <div className="container relative z-10 max-w-5xl">
            <Link href="/" className="mb-8 inline-flex items-center gap-2 text-sm font-semibold text-[#176b67] hover:underline"><ArrowLeft className="h-4 w-4" /> {copy.back}</Link>
            <div className="grid items-end gap-8 lg:grid-cols-[1fr_auto]">
              <div className="max-w-3xl"><p className="mb-4 flex items-center gap-2 text-sm font-extrabold tracking-[0.14em] text-[#176b67]"><span className="h-2 w-2 rounded-full bg-[#d9901e]" /> {copy.eyebrow}</p><h1 className="font-bangla-serif text-4xl font-black leading-tight text-[#102b3e] sm:text-5xl">{copy.title}</h1><p className="mt-5 max-w-2xl text-lg leading-8 text-[#405461]">{copy.lead}</p></div>
              <div className="hidden h-28 w-28 items-center justify-center rounded-[2rem] border border-[#176b67]/20 bg-[#e4f2e9] text-[#176b67] lg:flex"><Building2 className="h-12 w-12" aria-hidden="true" /></div>
            </div>
          </div>
          <div className="pointer-events-none absolute bottom-0 left-0 h-2 w-full bg-[linear-gradient(90deg,#176b67_0%,#176b67_40%,#d9901e_40%,#d9901e_48%,#176b67_48%,#176b67_100%)]" />
        </section>

        <section className="container py-12 lg:py-16">
          <div className="rounded-[1.8rem] border border-[#d9901e]/35 bg-[#fff8e8] p-7 shadow-[0_18px_45px_rgba(16,43,62,0.08)]"><ShieldCheck className="mb-4 h-9 w-9 text-[#176b67]" aria-hidden="true" /><h2 className="font-bangla-serif text-2xl font-black text-[#102b3e]">স্বচ্ছতা ও নিরাপত্তা আগে</h2><p className="mt-3 max-w-4xl leading-7 text-[#405461]">{copy.notice}</p></div>
          <div className="mt-7 rounded-[1.8rem] border border-[#173c4f]/10 bg-white p-7 shadow-[0_18px_45px_rgba(16,43,62,0.06)] sm:p-9"><h2 className="font-bangla-serif text-2xl font-black text-[#102b3e]">{copy.stepsTitle}</h2><ol className="mt-7 grid gap-6 sm:grid-cols-3">{copy.steps.map(([number, title, body]) => <li key={number} className="relative border-l-2 border-[#d9901e]/70 pl-4"><span className="text-sm font-black text-[#d9901e]">{number}</span><h3 className="mt-1 font-bold text-[#102b3e]">{title}</h3><p className="mt-2 text-sm leading-6 text-[#536873]">{body}</p></li>)}</ol></div>
          <div className="mt-7 grid gap-4 md:grid-cols-3">{copy.safeguards.map(([title, body]) => <article key={title} className="rounded-2xl border border-[#173c4f]/10 bg-white p-5"><h3 className="font-bold text-[#102b3e]">{title}</h3><p className="mt-2 text-sm leading-6 text-[#536873]">{body}</p></article>)}</div>
        </section>

        <section className="container pb-16 lg:pb-20"><div className="rounded-[2rem] bg-[#102b3e] px-7 py-9 text-white shadow-[0_24px_65px_rgba(16,43,62,0.2)] sm:px-10 sm:py-11"><div className="flex flex-col gap-7 sm:flex-row sm:items-center sm:justify-between"><div className="max-w-2xl"><div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#176b67]"><ClipboardCheck className="h-6 w-6" aria-hidden="true" /></div><h2 className="font-bangla-serif text-2xl font-black sm:text-3xl">প্রস্তাব পাঠানোর আগে পরিচ্ছন্ন তথ্য প্রস্তুত করুন</h2><p className="mt-3 leading-7 text-[#d9e5e5]">শুধু উদ্দেশ্য ও প্রতিষ্ঠানের সাধারণ পরিচিতি দিন। sensitive document, payment বা ব্যক্তিগত credential দেবেন না।</p></div><div className="flex flex-wrap gap-3"><Link href="/contact" className="inline-flex shrink-0 items-center justify-center rounded-xl bg-[#63deb7] px-6 py-4 font-bold text-[#102b3e] transition hover:bg-[#83e9c9]">{copy.cta}</Link><Link href="/ngo-partnership" className="inline-flex shrink-0 items-center justify-center rounded-xl border border-white/30 px-6 py-4 font-bold text-white transition hover:bg-white/10">{copy.ngo}</Link></div></div></div></section>
      </main>
      <SahajFooter />
    </div>
  );
}
