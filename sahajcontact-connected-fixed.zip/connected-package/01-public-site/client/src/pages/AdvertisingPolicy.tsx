/* Design reminder: “নদীর পথ” — commercial paths stay visibly separate from civic guidance, with honest labels and calm hierarchy. */
import { BadgePercent, CheckCircle2, ShieldCheck } from "lucide-react";
import { useEffect } from "react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { trackEvent } from "@/lib/analytics";

export default function AdvertisingPolicy() {
  useEffect(() => {
    trackEvent("page_view", { page: "advertising_policy" });
    const previousTitle = document.title;
    document.title = "বিজ্ঞাপন ও স্পনসরশিপ নীতি | সহজ জনসেবা";
    return () => { document.title = previousTitle; };
  }, []);

  return (
    <div className="site-shell public-civic-page public-policy-page">
      <SahajHeader />
      <main>
        <section className="security-hero">
          <div className="route-motif route-motif-hero" aria-hidden="true"><span /><i /><b /></div>
          <div className="container security-hero-inner">
            <div className="security-title reveal-up">
              <div className="eyebrow"><span className="eyebrow-dot" />০৭ / বাণিজ্যিক স্বচ্ছতা</div>
              <h1>সহযোগিতার পথ<br /><em>লেবেলসহ খোলা।</em></h1>
              <p>সাহজসেবার বিজ্ঞাপন, sponsor, referral ও partner content কীভাবে civic information থেকে আলাদা থাকবে—এই নীতি সেই সীমা নির্ধারণ করে।</p>
              <Link href="/" className="back-link">← হোমে ফিরে যান</Link>
            </div>
            <aside className="security-status-card reveal-up" style={{ animationDelay: "100ms" }}>
              <div className="security-status-icon"><BadgePercent size={25} /></div>
              <span className="section-number">প্রকাশ্য নিয়ম</span>
              <h2>পেমেন্ট নয়,<br /><em>আগে বিশ্বাস।</em></h2>
              <p>কোনো sponsor-কে সরকারি অনুমোদন, চাকরি, loan, visa বা service outcome-এর নিশ্চয়তা হিসেবে দেখানো যাবে না।</p>
              <div className="security-status-list"><span><CheckCircle2 size={15} />Sponsored label বাধ্যতামূলক</span><span><CheckCircle2 size={15} />editorial independence</span><span><ShieldCheck size={15} />user-first review</span></div>
            </aside>
          </div>
        </section>
        <section className="security-workspace section-paper">
          <div className="container security-layout">
            <aside className="policy-index" aria-label="বিজ্ঞাপন নীতির বিষয়সূচি"><span className="section-number">পথনির্দেশ</span><h2>চুক্তির আগে<br /><em>যা দেখুন।</em></h2><nav><a href="#allowed">গ্রহণযোগ্য</a><a href="#blocked">নিষিদ্ধ</a><a href="#disclosure">লেবেল ও disclosure</a><a href="#review">review ও অভিযোগ</a></nav><div className="policy-index-note"><ShieldCheck size={16} /><span>বিজ্ঞাপন কোনো সরকারি endorsement নয়—প্রতিটি sponsor নিজ দায়িত্বে যাচাই করুন।</span></div></aside>
            <div className="policy-content">
              <section className="policy-section" id="allowed"><div className="policy-section-heading"><span>০১</span><h2>গ্রহণযোগ্য সহযোগিতা</h2></div><div className="policy-section-body"><p>স্থানীয় ব্যবসা, শিক্ষা/প্রশিক্ষণ, বই ও তথ্যসেবা, responsible technology, অনুমোদিত ticket/referral partner এবং public-interest campaign বিবেচনা করা যেতে পারে—যদি দাবি যাচাইযোগ্য এবং ব্যবহারকারীর জন্য পরিষ্কার হয়।</p></div></section>
              <section className="policy-section" id="blocked"><div className="policy-section-heading"><span>০২</span><h2>নিষিদ্ধ বা প্রত্যাখ্যানযোগ্য</h2></div><div className="policy-section-body"><ul className="policy-list"><li>ভুয়া সরকারি পরিচয়, guaranteed চাকরি/ভিসা/loan বা দ্রুত অনুমোদনের দাবি</li><li>জুয়া, প্রতারণা, pyramid scheme, অবৈধ financial offer, counterfeit বা malware</li><li>ব্যক্তিগত তথ্য, OTP, PIN বা sensitive document চাওয়া বিজ্ঞাপন</li><li>ভয়, জরুরি পরিস্থিতি বা অসহায় মানুষের দুর্বলতা ব্যবহার করে চাপ সৃষ্টি</li></ul></div></section>
              <section className="policy-section" id="disclosure"><div className="policy-section-heading"><span>০৩</span><h2>লেবেল, মূল্য ও disclosure</h2></div><div className="policy-section-body"><p>Paid placement হলে “বিজ্ঞাপন”, “স্পনসরড” বা “অংশীদার লিংক” স্পষ্টভাবে দেখাতে হবে। referral commission, partner identity, service price, refund শর্ত, contact এবং দায়িত্বসীমা ব্যবহারকারীর সামনে রাখতে হবে। Sponsored placement service listing-এর official status বদলাবে না।</p><div className="policy-callout policy-callout-saffron"><BadgePercent size={18} /><p><strong>কপি উদাহরণ:</strong> “স্পনসরড কনটেন্ট — এটি সাহজসেবার সরকারি অনুমোদন বা সেবার নিশ্চয়তা নয়; সিদ্ধান্তের আগে provider-এর official তথ্য যাচাই করুন।”</p></div></div></section>
              <section className="policy-section" id="review"><div className="policy-section-heading"><span>০৪</span><h2>যাচাই, invoice ও অভিযোগ</h2></div><div className="policy-section-body"><p>প্রতিটি sponsor-এর identity, business registration/প্রযোজ্য licence, landing page, claim evidence, payment record ও written agreement সংরক্ষণ করুন। ভুল বা ক্ষতিকর বিজ্ঞাপনের অভিযোগ পেলে placement pause, evidence review এবং প্রয়োজন হলে takedown করুন। বিজ্ঞাপন আয় থেকে কর, invoice ও bookkeeping-এর দায়িত্ব owner-এর।</p><p className="policy-muted">বিজ্ঞাপন বা sponsorship নিতে বাস্তব payment account, tax record, legal review ও partner contract owner-কে নিজে সম্পন্ন করতে হবে।</p><Link href="/contact" className="back-link">বিজ্ঞাপন বিষয়ে যোগাযোগ করুন →</Link></div></section>
            </div>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
