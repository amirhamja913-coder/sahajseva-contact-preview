import { Activity, ArrowUpRight, BarChart3, CheckCircle2, FileBarChart, Globe2, Target, UsersRound } from "lucide-react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";

const metricCards = [
  { label: "সক্রিয় ব্যবহারকারী", english: "Active users", value: "614", note: "611 জন নতুন ব্যবহারকারী" },
  { label: "সেশন", english: "Sessions", value: "748", note: "প্রতি ব্যবহারকারীতে 1.22 সেশন" },
  { label: "পেজ ভিউ", english: "Page views", value: "3,902", note: "প্রতি সেশনে 5.22 পেজ ভিউ" },
  { label: "মূল event / lead", english: "Key events / leads", value: "73", note: "সেশনের প্রায় 9.8%" },
];

const trafficSources = [
  { label: "Direct", value: 485, share: "70.6%", tone: "#0f766e" },
  { label: "Organic Social", value: 186, share: "27.1%", tone: "#d97706" },
  { label: "Referral", value: 16, share: "2.3%", tone: "#475569" },
];

const countryRows = [
  ["যুক্তরাষ্ট্র / USA", "365"],
  ["বাংলাদেশ / Bangladesh", "167"],
  ["সৌদি আরব / Saudi Arabia", "27"],
  ["সংযুক্ত আরব আমিরাত, ওমান ও অন্যান্য", "উল্লেখিত"],
] as const;

const septemberTargets = [
  ["সক্রিয় ব্যবহারকারী", "800+"],
  ["সেশন", "950+"],
  ["পেজ ভিউ", "4,800+"],
  ["মূল event / lead", "90+"],
  ["গড় engagement time", "1m 15s+"],
  ["Week 1 retention", "10%+"],
  ["Organic Social visits", "250+"],
] as const;

const cardStyle = {
  border: "1px solid #d9e5df",
  borderRadius: "1.4rem",
  background: "#fffefa",
  boxShadow: "0 16px 35px rgba(15, 42, 67, 0.07)",
} as const;

export default function August2026SeoAnalyticsReport() {
  return (
    <div className="site-shell august-seo-report" style={{ background: "#fffdf6", color: "#102a43" }}>
      <SahajHeader />
      <main>
        <section aria-labelledby="august-report-title" style={{ padding: "clamp(3.2rem, 7vw, 6rem) 0 3rem", background: "radial-gradient(circle at 9% 12%, rgba(15,118,110,0.19) 0, transparent 24rem), radial-gradient(circle at 90% 18%, rgba(217,119,6,0.16) 0, transparent 22rem), linear-gradient(135deg, #fffdf4, #f1f8f4 56%, #fff7df)" }}>
          <div className="container">
            <Link href="/" style={{ display: "inline-flex", alignItems: "center", gap: "0.4rem", color: "#0f766e", fontWeight: 800, textDecoration: "none" }}>← হোমপেজে ফিরে যান</Link>
            <div style={{ maxWidth: "900px", marginTop: "1.7rem" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", padding: "0.45rem 0.75rem", borderRadius: "999px", background: "#0f766e", color: "#fff", fontSize: "0.78rem", fontWeight: 900, letterSpacing: "0.07em" }}><FileBarChart size={15} aria-hidden="true" /> MONTHLY PERFORMANCE REPORT</span>
              <h1 id="august-report-title" style={{ margin: "1rem 0 0", fontSize: "clamp(2.25rem, 6vw, 4.7rem)", lineHeight: 1.04, letterSpacing: "-0.045em", fontWeight: 950 }}>SahajContact<br /><em style={{ color: "#0f766e", fontStyle: "normal" }}>SEO + Analytics Report</em></h1>
              <p style={{ maxWidth: "730px", margin: "1rem 0 0", color: "#415a68", fontSize: "clamp(1rem, 2vw, 1.18rem)", lineHeight: 1.75 }}>আগস্ট ২০২৬-এর সাইট পারফরম্যান্স, দর্শক আচরণ, কনভার্সন ও সেপ্টেম্বরের বাস্তবভিত্তিক লক্ষ্য।</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.75rem", marginTop: "1.35rem" }}>
                <span style={{ padding: "0.5rem 0.8rem", borderRadius: "999px", background: "#fff", border: "1px solid #c8ded4", fontSize: "0.86rem", fontWeight: 750 }}>Reporting period: August 2026</span>
                <span style={{ padding: "0.5rem 0.8rem", borderRadius: "999px", background: "#fff", border: "1px solid #c8ded4", fontSize: "0.86rem", fontWeight: 750 }}>Prepared: 23 August 2026</span>
              </div>
            </div>
          </div>
        </section>

        <section aria-label="Report provenance" style={{ background: "#102a43", color: "#e7f5ef", padding: "1rem 0" }}>
          <div className="container" style={{ display: "flex", alignItems: "flex-start", gap: "0.65rem", fontSize: "0.9rem", lineHeight: 1.55 }}>
            <CheckCircle2 size={18} aria-hidden="true" style={{ flex: "0 0 auto", marginTop: "0.1rem", color: "#fbbf24" }} />
            <p style={{ margin: 0 }}><strong>রিপোর্টের উৎস:</strong> এটি মালিক-প্রদত্ত August 2026 metrics-এর সাজানো public report। এটি live automated GA4/SEO card নয়; সেই card-এ স্বয়ংক্রিয় snapshot না আসা পর্যন্ত waiting state অপরিবর্তিত থাকবে।</p>
          </div>
        </section>

        <section style={{ padding: "clamp(2.8rem, 5vw, 4.6rem) 0" }}>
          <div className="container" style={{ display: "grid", gap: "1.5rem" }}>
            <div style={{ display: "grid", gap: "1rem", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
              {metricCards.map((metric, index) => (
                <article key={metric.label} style={{ ...cardStyle, padding: "1.25rem", borderTop: `4px solid ${index % 2 === 0 ? "#0f766e" : "#d97706"}` }}>
                  <p style={{ margin: 0, color: "#0f766e", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.06em" }}>{metric.english.toUpperCase()}</p>
                  <p style={{ margin: "0.45rem 0 0", fontSize: "2.1rem", lineHeight: 1, fontWeight: 950 }}>{metric.value}</p>
                  <h2 style={{ margin: "0.6rem 0 0", fontSize: "1rem" }}>{metric.label}</h2>
                  <p style={{ margin: "0.35rem 0 0", color: "#526575", fontSize: "0.84rem", lineHeight: 1.5 }}>{metric.note}</p>
                </article>
              ))}
            </div>

            <section aria-labelledby="executive-summary-title" style={{ ...cardStyle, padding: "clamp(1.4rem, 4vw, 2.35rem)" }}>
              <span style={{ color: "#d97706", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.09em" }}>01 / EXECUTIVE SUMMARY</span>
              <div style={{ display: "grid", gap: "1.6rem", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", marginTop: "0.75rem" }}>
                <div>
                  <h2 id="executive-summary-title" style={{ margin: 0, fontSize: "1.5rem" }}>নির্বাহী সারাংশ</h2>
                  <p style={{ margin: "0.65rem 0 0", color: "#405666", lineHeight: 1.78 }}>আগস্টে SahajContact 614 জন সক্রিয় ব্যবহারকারী, 748টি সেশন এবং 3,902টি পেজ ভিউ পেয়েছে। 611 জন নতুন ব্যবহারকারী হওয়া নতুন দর্শক পৌঁছানোর শক্তিশালী ইঙ্গিত। “সন্তানকে শিক্ষিত করুন” ও “NID পাসপোর্ট” পেজ দুটিতে মোট পেজ ভিউয়ের প্রায় 78.4% এসেছে—তাই এই দুই বিষয়কে আগামী মাসের content ও conversion পরিকল্পনার কেন্দ্রে রাখা উচিত।</p>
                </div>
                <div style={{ borderLeft: "2px solid #c8ded4", paddingLeft: "1.3rem" }}>
                  <h2 style={{ margin: 0, fontSize: "1.1rem" }}>Executive Summary</h2>
                  <p style={{ margin: "0.65rem 0 0", color: "#405666", lineHeight: 1.78 }}>SahajContact recorded 614 active users, 748 sessions and 3,902 page views in August. The high share of new users indicates strong first-time reach. Education and NID/passport content together accounted for approximately 78.4% of page views, making them the clearest priorities for content depth, service pathways and conversion improvement in September.</p>
                </div>
              </div>
            </section>

            <section aria-labelledby="metrics-title" style={{ ...cardStyle, padding: "clamp(1.4rem, 4vw, 2.35rem)" }}>
              <span style={{ color: "#0f766e", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.09em" }}>02 / KEY METRICS</span>
              <h2 id="metrics-title" style={{ margin: "0.5rem 0 1.15rem", fontSize: "1.5rem" }}>মূল সূচক</h2>
              <div style={{ overflowX: "auto" }}>
                <table className="august-seo-report-table" style={{ width: "100%", minWidth: "560px", borderCollapse: "collapse", fontSize: "0.94rem" }}>
                  <thead><tr style={{ background: "#eff7f3", color: "#164e48", textAlign: "left" }}><th style={{ padding: "0.8rem" }}>Metric</th><th style={{ padding: "0.8rem" }}>August 2026</th><th style={{ padding: "0.8rem" }}>Interpretation</th></tr></thead>
                  <tbody>
                    {[
                      ["Active Users", "614", "611 new users; প্রায় 99.5% নতুন দর্শক"],
                      ["Sessions", "748", "প্রতি active user-এ প্রায় 1.22 session"],
                      ["Page Views", "3,902", "প্রতি session-এ প্রায় 5.22 page views"],
                      ["Engagement Time", "1m 1s", "পরবর্তী মাসে সময় বাড়ানোর সুযোগ আছে"],
                      ["Week 1 Retention", "8.5%", "নতুন দর্শককে ফিরিয়ে আনার সুযোগ"],
                      ["Shares", "189", "প্রতি 100 active user-এ প্রায় 31 share"],
                    ].map(([metric, value, note]) => <tr key={metric} style={{ borderBottom: "1px solid #e0e9e5" }}><td style={{ padding: "0.85rem", fontWeight: 800 }}>{metric}</td><td style={{ padding: "0.85rem", color: "#0f766e", fontWeight: 900 }}>{value}</td><td style={{ padding: "0.85rem", color: "#516473" }}>{note}</td></tr>)}
                  </tbody>
                </table>
              </div>
            </section>

            <div style={{ display: "grid", gap: "1.25rem", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
              <section aria-labelledby="pages-title" style={{ ...cardStyle, padding: "1.5rem" }}>
                <span style={{ color: "#d97706", fontSize: "0.78rem", fontWeight: 900, letterSpacing: "0.08em" }}>03 / TOP PERFORMING PAGES</span>
                <h2 id="pages-title" style={{ margin: "0.5rem 0 1.1rem", fontSize: "1.35rem" }}>সর্বাধিক দেখা পেজ</h2>
                {[{ label: "সন্তানকে শিক্ষিত করুন", views: "1,967 views", width: "100%", share: "50.4%" }, { label: "NID পাসপোর্ট", views: "1,093 views", width: "56%", share: "28.0%" }].map((page) => <div key={page.label} style={{ marginTop: "1rem" }}><div style={{ display: "flex", justifyContent: "space-between", gap: "1rem", fontWeight: 800 }}><span>{page.label}</span><span style={{ color: "#0f766e" }}>{page.views}</span></div><div style={{ height: "0.65rem", marginTop: "0.45rem", overflow: "hidden", borderRadius: "999px", background: "#e8f0ec" }}><div style={{ width: page.width, height: "100%", borderRadius: "inherit", background: "linear-gradient(90deg, #0f766e, #22a879)" }} /></div><p style={{ margin: "0.3rem 0 0", color: "#64748b", fontSize: "0.82rem" }}>মোট page views-এর {page.share}</p></div>)}
                <p style={{ margin: "1.2rem 0 0", paddingTop: "1rem", borderTop: "1px solid #e0e9e5", color: "#405666", lineHeight: 1.65 }}>দুই পেজ মিলিয়ে 78.4% views এসেছে। FAQ, official source, related service link এবং সহজ next-step যোগ করলে এগুলো আরও কার্যকর হবে।</p>
              </section>

              <section aria-labelledby="traffic-title" style={{ ...cardStyle, padding: "1.5rem" }}>
                <span style={{ color: "#0f766e", fontSize: "0.78rem", fontWeight: 900, letterSpacing: "0.08em" }}>04 / TRAFFIC SOURCES</span>
                <h2 id="traffic-title" style={{ margin: "0.5rem 0 0.35rem", fontSize: "1.35rem" }}>ট্রাফিক উৎস</h2>
                <p style={{ margin: "0 0 1rem", color: "#64748b", fontSize: "0.86rem" }}>উল্লেখিত তিনটি source-এর মোট 687 visit-এর ভাগ</p>
                {trafficSources.map((source) => <div key={source.label} style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: "0.45rem 0.8rem", marginTop: "0.9rem" }}><strong>{source.label}</strong><strong style={{ color: source.tone }}>{source.value} · {source.share}</strong><div style={{ gridColumn: "1 / -1", height: "0.65rem", overflow: "hidden", borderRadius: "999px", background: "#edf1ef" }}><div style={{ width: source.share, height: "100%", borderRadius: "inherit", background: source.tone }} /></div></div>)}
                <p style={{ margin: "1.2rem 0 0", color: "#405666", lineHeight: 1.65 }}>Direct traffic শক্তিশালী। সেপ্টেম্বরের কাজ হবে organic social নিয়মিত বাড়ানো এবং referral partnership-এর সুযোগ তৈরি করা।</p>
              </section>
            </div>

            <div style={{ display: "grid", gap: "1.25rem", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
              <section aria-labelledby="countries-title" style={{ ...cardStyle, padding: "1.5rem" }}>
                <span style={{ color: "#0f766e", fontSize: "0.78rem", fontWeight: 900, letterSpacing: "0.08em" }}>05 / USERS BY COUNTRY</span>
                <h2 id="countries-title" style={{ margin: "0.5rem 0 1rem", fontSize: "1.35rem" }}>দেশভিত্তিক ব্যবহারকারী</h2>
                <div style={{ display: "grid", gap: "0.6rem" }}>{countryRows.map(([country, users]) => <div key={country} style={{ display: "flex", justifyContent: "space-between", gap: "1rem", padding: "0.8rem 0.9rem", borderRadius: "0.85rem", background: "#f3f8f5" }}><span>{country}</span><strong style={{ color: "#0f766e" }}>{users}</strong></div>)}</div>
                <p style={{ margin: "1rem 0 0", color: "#64748b", fontSize: "0.84rem", lineHeight: 1.6 }}>সংখ্যা দেওয়া দেশগুলো report snapshot থেকে নেওয়া; UAE, Oman ও অন্যান্য দেশের পূর্ণ বিভাজিত সংখ্যা দেওয়া হয়নি।</p>
              </section>

              <section aria-labelledby="conversions-title" style={{ ...cardStyle, padding: "1.5rem" }}>
                <span style={{ color: "#d97706", fontSize: "0.78rem", fontWeight: 900, letterSpacing: "0.08em" }}>06 / KEY CONVERSIONS</span>
                <h2 id="conversions-title" style={{ margin: "0.5rem 0 1rem", fontSize: "1.35rem" }}>মূল কনভার্সন</h2>
                <div style={{ display: "grid", gap: "0.8rem" }}>
                  <div style={{ padding: "1rem", borderRadius: "1rem", background: "#eff8f4" }}><strong style={{ display: "block", fontSize: "1.6rem", color: "#0f766e" }}>73</strong><span>মোট Key Events / Leads</span></div>
                  <div style={{ padding: "1rem", borderRadius: "1rem", background: "#fff6e4" }}><strong style={{ display: "block", fontSize: "1.35rem", color: "#b45309" }}>65 · 89.0%</strong><span>Contact_Us</span></div>
                  <div style={{ padding: "1rem", borderRadius: "1rem", background: "#f1f5f9" }}><strong style={{ display: "block", fontSize: "1.35rem", color: "#334155" }}>8 · 11.0%</strong><span>Phone_Click</span></div>
                </div>
                <p style={{ margin: "1rem 0 0", color: "#405666", lineHeight: 1.65 }}>সেশনের তুলনায় lead rate প্রায় 9.8%। Contact_Us সবচেয়ে কার্যকর পথ—form completion ও response process নিয়মিত পর্যবেক্ষণ করা দরকার।</p>
              </section>
            </div>

            <section aria-labelledby="growth-title" style={{ ...cardStyle, padding: "clamp(1.4rem, 4vw, 2.35rem)", background: "linear-gradient(135deg, #f0f8f5, #fffaf0)" }}>
              <span style={{ color: "#0f766e", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.09em" }}>07 / GROWTH TREND</span>
              <div style={{ display: "grid", gap: "1.4rem", gridTemplateColumns: "minmax(0, 1.5fr) minmax(220px, 0.8fr)", marginTop: "0.65rem" }}>
                <div><h2 id="growth-title" style={{ margin: 0, fontSize: "1.5rem" }}>Growth baseline, forecast নয়</h2><p style={{ margin: "0.65rem 0 0", color: "#405666", lineHeight: 1.75 }}>এই report-এ August-এর একটি মাত্র snapshot দেওয়া হয়েছে; তাই month-on-month বা week-on-week growth দাবি করা ঠিক হবে না। তবে 99.5% নতুন ব্যবহারকারী, 5.22 views per session এবং 189 share ইঙ্গিত দেয় যে নতুন দর্শক পাওয়া ও content discovery শক্তিশালী। September-এ একই metrics ধারাবাহিকভাবে পরিমাপ করলে এই report-টি reliable comparison baseline হবে।</p></div>
                <aside style={{ padding: "1.1rem", borderRadius: "1rem", background: "#102a43", color: "#f0faf5" }}><Globe2 size={22} aria-hidden="true" style={{ color: "#fbbf24" }} /><p style={{ margin: "0.75rem 0 0", fontWeight: 900 }}>Measurement note</p><p style={{ margin: "0.35rem 0 0", fontSize: "0.87rem", lineHeight: 1.6, color: "#c7d8d2" }}>পরবর্তী রিপোর্টে একই date range, একই source definition ও একই event naming রাখুন।</p></aside>
              </div>
            </section>

            <section aria-labelledby="targets-title" style={{ ...cardStyle, padding: "clamp(1.4rem, 4vw, 2.35rem)" }}>
              <span style={{ color: "#d97706", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.09em" }}>08 / SEPTEMBER TARGET</span>
              <div style={{ display: "flex", alignItems: "start", gap: "0.75rem", marginTop: "0.55rem" }}><Target size={25} aria-hidden="true" style={{ color: "#0f766e", flex: "0 0 auto", marginTop: "0.18rem" }} /><div><h2 id="targets-title" style={{ margin: 0, fontSize: "1.5rem" }}>September-এর বাস্তবভিত্তিক লক্ষ্য</h2><p style={{ margin: "0.35rem 0 0", color: "#64748b", lineHeight: 1.65 }}>এগুলো management target—কোনো নিশ্চিত ফলাফলের প্রতিশ্রুতি নয়।</p></div></div>
              <div style={{ display: "grid", gap: "0.7rem", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", marginTop: "1.25rem" }}>{septemberTargets.map(([target, value]) => <div key={target} style={{ display: "flex", justifyContent: "space-between", gap: "0.75rem", padding: "0.85rem 0.95rem", borderRadius: "0.9rem", background: "#f0f8f5", border: "1px solid #d6e7df" }}><span>{target}</span><strong style={{ color: "#0f766e" }}>{value}</strong></div>)}</div>
            </section>

            <section aria-labelledby="conclusion-title" style={{ padding: "clamp(1.5rem, 4vw, 2.5rem)", borderRadius: "1.5rem", background: "#102a43", color: "#f6fbf8" }}>
              <span style={{ color: "#fbbf24", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.09em" }}>09 / CONCLUSION</span>
              <h2 id="conclusion-title" style={{ margin: "0.55rem 0 0", fontSize: "clamp(1.4rem, 3vw, 2rem)" }}>আগামী মাসের অগ্রাধিকার: content depth, conversion clarity ও return visit</h2>
              <p style={{ maxWidth: "850px", margin: "0.85rem 0 0", color: "#d3e2db", lineHeight: 1.8 }}>SahajContact-এর প্রধান শক্তি হলো নতুন দর্শক পাওয়া এবং শিক্ষাবিষয়ক ও NID/পাসপোর্ট তথ্যের ব্যবহার। সেপ্টেম্বরের জন্য সবচেয়ে কার্যকর পদক্ষেপ হবে: এই দুই পেজের তথ্য আরও পরিষ্কার করা, official next-step ও Contact_Us path দৃশ্যমান রাখা, সামাজিক মাধ্যমে নিয়মিত সহায়ক content ছড়ানো এবং আগের দর্শককে ফেরাতে related-guide journey তৈরি করা।</p>
              <p style={{ margin: "1.25rem 0 0", color: "#fbbf24", fontWeight: 850 }}>Prepared by SahajSheba Team, Date: 23 August 2026</p>
            </section>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
