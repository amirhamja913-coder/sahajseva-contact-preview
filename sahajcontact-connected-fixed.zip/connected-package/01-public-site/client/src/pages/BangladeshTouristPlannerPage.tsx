import { useState, useMemo } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Bus, FileText, FolderPlus, Globe, IdCard, Landmark, MapPin, Phone, Plane, Search, ShieldCheck, Ship, Train } from "lucide-react";
import { Link } from "wouter";
import SahajHeader from "@/components/SahajHeader";
import SahajFooter from "@/components/SahajFooter";
import TravelImageGallery from "@/components/TravelImageGallery";
import { trackEvent } from "@/lib/analytics";

const touristGuideLogoUrl = "/manus-storage/sahajcontact-tourist-guide-logo_cd853d46.png";

const categoryLabels: Record<string, { bn: string; en: string }> = {
  sea: { bn: "সমুদ্র", en: "Sea" },
  hill: { bn: "পাহাড়", en: "Hills" },
  historic: { bn: "ঐতিহাসিক", en: "Historic" },
  religious: { bn: "ধর্মীয়", en: "Religious" },
  nature: { bn: "প্রকৃতি", en: "Nature" },
};

function getCategoryId(value?: string | null) {
  const normalized = (value || "").trim().toLowerCase();
  if (["সমুদ্র", "sea"].includes(normalized)) return "sea";
  if (["পাহাড়", "hill", "hills"].includes(normalized)) return "hill";
  if (["ঐতিহাসিক", "historic"].includes(normalized)) return "historic";
  if (["ধর্মীয়", "religious"].includes(normalized)) return "religious";
  if (["প্রকৃতি", "nature"].includes(normalized)) return "nature";
  return normalized || "nature";
}

function getCategoryLabel(value: string | null | undefined, isEn: boolean) {
  const label = categoryLabels[getCategoryId(value)] || categoryLabels.nature;
  return isEn ? label.en : label.bn;
}

function TransportGuideIcon({ name, className = "w-5 h-5" }: { name?: string | null; className?: string }) {
  const icons: Record<string, typeof Landmark> = { Bus, Train, Plane, Ship, MapPin, Landmark, ShieldCheck, FileText, IdCard };
  const Icon = icons[name ?? ""] ?? Landmark;
  return <Icon className={className} />;
}


export default function BangladeshTouristPlannerPage() {
  const { language } = useLanguage();
  const isEn = language === "EN";
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");

  const travelQuery = trpc.siteManagement.getTravelContent.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });

  const touristPlaces = travelQuery.data?.touristPlaces || [];
  const borderPorts = travelQuery.data?.borderPorts || [];
  const transportIndiaGuides = travelQuery.data?.transportIndiaGuides || [];
  const embassies = travelQuery.data?.embassies || [];

  const filteredPlaces = useMemo(() => {
    return touristPlaces.filter((p: any) => {
      const name = (isEn ? p.nameEn : p.nameBn) || p.nameBn || "";
      const cat = getCategoryId(p.category);
      const matchCat = selectedCategory === "all" || cat === selectedCategory;
      const matchSearch = searchTerm.trim() === "" || name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [touristPlaces, selectedCategory, searchTerm, isEn]);

  return (
    <div className="civic-tourist-page min-h-screen bg-background text-foreground flex flex-col font-sans">
      <SahajHeader />
      <main className="flex-1 container max-w-6xl mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-medium text-emerald-600 hover:text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1.5 rounded-full transition-colors">
            <ArrowLeft className="w-4 h-4" />
            {isEn ? 'Back to Home' : 'হোম পেজে ফিরে যান'}
          </Link>
          <div className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
            {isEn ? 'Verified Official Guide' : 'যাচাইকৃত অফিসিয়াল গাইড'}
          </div>
        </div>

        {/* Hero Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-6 sm:p-10 mb-8 shadow-lg relative overflow-hidden">
          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
            <div className="max-w-2xl">
              <span className="inline-block bg-emerald-500/30 text-emerald-100 text-xs font-semibold px-3 py-1 rounded-full mb-3 border border-emerald-400/30">
                {isEn ? 'Explore Bangladesh' : 'ঘুরে দেখুন সুন্দর বাংলাদেশ'}
              </span>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mb-3">
                {isEn ? 'Discover Bangladesh & Land-Arrival Guide' : 'বাংলাদেশের সেরা টুরিস্ট স্পট ও স্থলপথে আগমনের গাইড'}
              </h1>
              <p className="text-emerald-100 text-sm sm:text-base leading-relaxed">
                {isEn
                  ? 'Explore Bangladesh’s hills, sea and Sundarbans, then use labelled official sources to plan a land arrival into Bangladesh.'
                  : 'পাহাড়, সমুদ্র, সুন্দরবন—বাংলাদেশের সেরা টুরিস্ট স্পট দেখুন এবং স্থলপথে বাংলাদেশে আসার আগে লেবেলযুক্ত অফিসিয়াল উৎস যাচাই করুন।'}
              </p>
            </div>
            <img src={touristGuideLogoUrl} alt={isEn ? "Bangladesh Tourist Guide emblem" : "বাংলাদেশ টুরিস্ট গাইডের প্রতীক"} loading="lazy" className="h-28 w-28 sm:h-36 sm:w-36 self-center object-contain drop-shadow-2xl" />
          </div>
        </div>

        <details className="group mb-12 overflow-hidden rounded-2xl border border-emerald-100 bg-white shadow-sm" aria-labelledby="tourism-folder-title">
          <summary className="tourism-folder-entry flex min-h-[5.25rem] cursor-pointer list-none items-center justify-between gap-2 bg-white px-4 py-3 marker:content-none sm:min-h-[5.5rem] sm:gap-4 sm:px-5 sm:py-3.5" aria-label={isEn ? "Open the Bangladesh tourism folder" : "বাংলাদেশ টুরিস্ট ফোল্ডার খুলুন"}>
            <div className="flex min-w-0 items-center gap-3.5">
              <span className="relative inline-flex h-12 w-[4.25rem] shrink-0 items-center justify-center overflow-hidden rounded-lg border-2 border-emerald-900/35 bg-[#006a4e] shadow-md ring-2 ring-emerald-100" aria-label={isEn ? "Bangladesh flag" : "বাংলাদেশের পতাকা"} role="img">
                <span className="h-7 w-7 rounded-full bg-[#f42a41] shadow-[0_0_0_3px_rgba(244,42,65,0.16)]" />
              </span>
              <div className="min-w-0">
                <span className="mb-0.5 block text-[10px] font-black uppercase tracking-[0.14em] text-emerald-700">{isEn ? "Bangladesh tourism" : "বাংলাদেশ টুরিজম"}</span>
                <h2 id="tourism-folder-title" className="text-base font-black leading-tight text-slate-900 sm:text-xl">{isEn ? "Explore Bangladesh" : "বাংলাদেশকে ঘুরে দেখুন"}</h2>
                <p className="mt-0.5 text-sm font-bold leading-tight text-emerald-800 sm:text-base">{isEn ? "Know Bangladesh, experience Bangladesh" : "বাংলাদেশকে জানুন, অনুভব করুন"}</p>
              </div>
            </div>
              <span className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border-2 border-emerald-600/45 bg-emerald-50 px-2.5 py-2.5 text-xs font-black text-emerald-900 shadow-sm sm:gap-2 sm:px-3" aria-label={isEn ? "Tourism folder with more content" : "আরও কনটেন্টসহ টুরিস্ট ফোল্ডার"}>
                <FolderPlus size={28} aria-hidden="true" strokeWidth={2.6} />
                <span className="hidden sm:inline">{isEn ? "Open folder" : "ফোল্ডার খুলুন"}</span>
              <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-emerald-700 text-lg font-black leading-none text-white shadow-sm" aria-hidden="true">+</span>
            </span>
          </summary>

        {/* Tourist Places Section */}
        <div id="tourist-destinations" className="border-t border-emerald-100 bg-emerald-50/40 px-5 py-6 sm:px-7 sm:py-8">
          <h2 className="text-xl sm:text-2xl font-bold mb-6 flex items-center gap-2">
            <MapPin className="w-6 h-6 text-emerald-600" />
            {isEn ? 'Top Tourist Destinations in Bangladesh' : 'বাংলাদেশের সেরা দর্শনীয় স্থানসমূহ'}
          </h2>

          {/* Search & Category Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder={isEn ? 'Search tourist spots...' : 'দর্শনীয় স্থান খুঁজুন...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0">
              {[
                { id: "all", labelBn: "সব", labelEn: "All" },
                { id: "sea", labelBn: "সমুদ্র", labelEn: "Sea" },
                { id: "hill", labelBn: "পাহাড়", labelEn: "Hills" },
                { id: "historic", labelBn: "ঐতিহাসিক", labelEn: "Historic" },
                { id: "nature", labelBn: "প্রকৃতি", labelEn: "Nature" },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === cat.id
                      ? "bg-emerald-600 text-white shadow-sm"
                      : "bg-card border hover:bg-muted text-muted-foreground"
                  }`}
                >
                  {isEn ? cat.labelEn : cat.labelBn}
                </button>
              ))}
            </div>
          </div>

          {travelQuery.isLoading ? (
            <div className="text-center py-12 text-muted-foreground">
              {isEn ? 'Loading tourist destinations...' : 'তথ্য লোড হচ্ছে...'}
            </div>
          ) : filteredPlaces.length === 0 ? (
            <div className="text-center py-12 bg-card border rounded-xl text-muted-foreground">
              {isEn ? 'No tourist spots found matching your search.' : 'আপনার অনুসন্ধানের সাথে মিলে এমন কোনো টুরিস্ট স্পট পাওয়া যায়নি।'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPlaces.map((place: any) => {
                const name = (isEn ? place.nameEn : place.nameBn) || place.nameBn;
                const location = place.location || (isEn ? place.locationEn : place.locationBn) || place.locationBn || "";
                const description = (isEn ? place.descEn : place.descBn) || place.descBn || place.descriptionBn || "";

                return (
                  <div key={place.id} className="bg-card border rounded-xl overflow-hidden shadow-sm flex flex-col hover:shadow-md transition-shadow">
                    <TravelImageGallery
                      coverUrl={place.imageUrl}
                      galleryJson={place.galleryJson}
                      title={name}
                      language={language}
                    />
                    <div className="p-5 flex-1 flex flex-col">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-full">{location}</span>
                        <span className="text-xs text-muted-foreground">{getCategoryLabel(place.category, isEn)}</span>
                      </div>
                      <h3 className="text-lg font-bold mb-2">{name}</h3>
                      <p className="text-sm text-muted-foreground mb-4 flex-1 leading-relaxed">{description}</p>
                      {place.mapUrl ? (
                        <a
                          href={place.mapUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => trackEvent('tourist_spot_map_click')}
                          className="mb-2 w-full inline-flex items-center justify-center gap-2 rounded-lg border border-teal-600/40 px-4 py-2 text-sm font-semibold text-teal-700 transition-colors hover:bg-teal-50 dark:text-teal-300 dark:hover:bg-teal-950/30"
                        >
                          <MapPin className="w-4 h-4" />
                          {isEn ? 'Open Map' : 'মানচিত্রে দেখুন'}
                        </a>
                      ) : null}
                      <Link
                        href="/contact"
                        onClick={() => trackEvent('tourist_spot_contact_click')}
                        className="w-full inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-2 px-4 rounded-lg text-sm transition-colors shadow-sm"
                      >
                        {isEn ? 'Use the portal contact page' : 'যোগাযোগ পেজে যান'}
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        </details>

        {/* Border Ports Section */}
        <div className="mb-12">
          <h2 className="text-xl sm:text-2xl font-bold mb-6 flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-teal-600" />
            {isEn ? 'Land Arrival into Bangladesh: Ports & Official Sources' : 'বাংলাদেশে স্থলপথে আগমন: প্রবেশপথ ও অফিসিয়াল উৎস'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {borderPorts.map((port: any) => {
              const name = (isEn ? port.nameEn : port.nameBn) || port.nameBn;
              const location = (isEn ? port.locationEn : port.locationBn) || port.locationBn;
              const address = (isEn ? port.bangladeshAddressEn : port.bangladeshAddressBn) || port.bangladeshAddressBn || location;
              const counterpart = (isEn ? port.indiaCounterpartEn : port.indiaCounterpartBn) || port.indiaCounterpartBn;
              const info = (isEn ? port.infoEn : port.infoBn) || port.infoBn || "";
              const officialLabel = (isEn ? port.officialSourceLabelEn : port.officialSourceLabelBn) || port.officialSourceLabelBn || (isEn ? "View official source" : "অফিসিয়াল উৎস দেখুন");

              return (
                <div key={port.id} className="civic-route-card bg-card border rounded-xl overflow-hidden shadow-sm flex flex-col">
                  <TravelImageGallery
                    coverUrl={port.imageUrl}
                    galleryJson={port.galleryJson}
                    title={name}
                    language={language}
                  />
                  <div className="p-5 flex-1 flex flex-col">
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 dark:text-teal-300 mb-1"><MapPin className="h-3.5 w-3.5" />{location}</span>
                    <h3 className="text-lg font-bold mb-2">{name}</h3>
                    <div className="mb-3 rounded-lg border border-teal-100 bg-teal-50/65 px-3 py-2 text-xs leading-5 text-slate-700 dark:border-teal-800/70 dark:bg-teal-950/30 dark:text-slate-200"><p><strong>{isEn ? "Bangladesh-side location:" : "বাংলাদেশ অংশের অবস্থান:"}</strong> {address}</p>{counterpart && <p className="mt-1"><strong>{isEn ? "Adjacent border reference:" : "সংলগ্ন সীমান্তের তথ্য:"}</strong> {counterpart}</p>}</div>
                    <p className="text-sm text-muted-foreground mb-4 flex-1">{info}</p>
                    <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-2">{port.officialSourceUrl && <a href={port.officialSourceUrl} target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("bangladesh_land_arrival_official_source_click")} className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-teal-700 px-3 py-2 text-xs font-semibold text-teal-800 transition-colors hover:bg-teal-50 dark:text-teal-200 dark:hover:bg-teal-950/40"><Globe className="h-3.5 w-3.5" />{officialLabel}</a>}{port.mapUrl && <a href={port.mapUrl} target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("bangladesh_land_arrival_map_click")} className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"><MapPin className="h-3.5 w-3.5" />{isEn ? "Map / directions" : "ম্যাপ / দিকনির্দেশ"}</a>}</div>
                    <Link
                      href="/contact"
                      onClick={() => trackEvent('border_route_contact_click')}
                      className="w-full inline-flex items-center justify-center gap-2 border border-emerald-600 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 font-medium py-2 px-4 rounded-lg text-sm transition-colors"
                    >
                      {isEn ? 'Use the portal contact page' : 'যোগাযোগ পেজে যান'}
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Owner-managed Bangladesh arrival and local travel official guidance */}
        <div className="mb-12">
          <h2 className="text-xl sm:text-2xl font-bold mb-2 flex items-center gap-2">
            <Landmark className="w-6 h-6 text-sky-600" />
            {isEn ? "Bangladesh Arrival & Local Travel Guidance" : "বাংলাদেশে আগমন ও স্থানীয় ভ্রমণ নির্দেশনা"}
          </h2>
          <p className="mb-5 max-w-4xl text-sm leading-6 text-muted-foreground">{isEn ? "Before travelling, use the labelled official source to confirm current requirements and practical information for entering Bangladesh and continuing local travel. SahajContact does not decide eligibility or guarantee entry, route availability, or transport." : "ভ্রমণের আগে বাংলাদেশে প্রবেশ ও পরবর্তী স্থানীয় যাত্রা-সংক্রান্ত বর্তমান শর্ত ও ব্যবহারিক তথ্য লেবেলযুক্ত অফিসিয়াল উৎসে যাচাই করুন। SahajContact যোগ্যতা নির্ধারণ করে না এবং প্রবেশ, রুটের প্রাপ্যতা বা পরিবহন নিশ্চিত করে না।"}</p>
          {transportIndiaGuides.length === 0 ? <div className="rounded-xl border bg-card p-5 text-sm text-muted-foreground">{isEn ? "Official guidance is being prepared." : "অফিসিয়াল নির্দেশনা প্রস্তুত করা হচ্ছে।"}</div> : <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {transportIndiaGuides.map((guide: any) => {
              const title = (isEn ? guide.titleEn : guide.titleBn) || guide.titleBn;
              const description = (isEn ? guide.descriptionEn : guide.descriptionBn) || guide.descriptionBn;
              const label = (isEn ? guide.officialLabelEn : guide.officialLabelBn) || guide.officialLabelBn;
              const checklist = ((isEn ? guide.checklistEn : guide.checklistBn) || "").split("\n").map((line: string) => line.trim()).filter(Boolean);
              return <article key={guide.id} className="overflow-hidden rounded-xl border bg-card shadow-sm flex flex-col">
                <div className="relative flex h-32 items-center justify-center overflow-hidden bg-gradient-to-br from-sky-100 via-teal-50 to-amber-50 text-sky-700 dark:from-sky-950/70 dark:via-teal-950/40 dark:to-amber-950/30 dark:text-sky-300">
                  <span className="rounded-2xl border border-current/15 bg-background/70 p-3 shadow-sm"><TransportGuideIcon name={guide.iconName} /></span>
                  {guide.coverImageUrl && <img src={guide.coverImageUrl} alt="" className="absolute inset-0 h-full w-full object-cover" onError={(event) => { event.currentTarget.classList.add("hidden"); }} />}
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <div className="mb-3 flex items-start gap-3"><div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-sky-100 text-sky-700 dark:bg-sky-950/45 dark:text-sky-300"><TransportGuideIcon name={guide.iconName} />{guide.iconImageUrl && <img src={guide.iconImageUrl} alt="" className="absolute inset-0 h-full w-full object-cover" onError={(event) => { event.currentTarget.classList.add("hidden"); }} />}</div><div><p className="text-xs font-semibold uppercase tracking-wide text-sky-700 dark:text-sky-300">{guide.kind === "transport" ? (isEn ? "Local travel" : "স্থানীয় যাত্রা") : (isEn ? "Bangladesh arrival" : "বাংলাদেশে আগমন")}</p><h3 className="text-lg font-bold">{title}</h3></div></div>
                  <p className="text-sm leading-6 text-muted-foreground">{description}</p>
                  {checklist.length > 0 && <ul className="mt-3 space-y-1.5 text-xs leading-5 text-muted-foreground">{checklist.map((item: string, index: number) => <li key={index} className="flex gap-2"><ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-600" /><span>{item.replace(/^[-•]\s*/, "")}</span></li>)}</ul>}
                  <div className="mt-4 flex-1" />
                  <p className="mb-2 text-[11px] text-muted-foreground">{isEn ? "Source:" : "উৎস:"} {guide.sourceName}{guide.lastVerifiedAt ? ` · ${isEn ? "Reviewed" : "পর্যালোচনা"} ${new Date(guide.lastVerifiedAt).toLocaleDateString(isEn ? "en-GB" : "bn-BD")}` : ""}</p>
                  <a href={guide.officialUrl} target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("bangladesh_arrival_official_source_click")} className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-sky-600 px-4 py-2 text-sm font-medium text-sky-700 transition-colors hover:bg-sky-50 dark:text-sky-300 dark:hover:bg-sky-950/40"><Globe className="h-4 w-4" />{label}</a>
                </div>
              </article>;
            })}
          </div>}
        </div>

        {/* Embassies Section */}
        <div className="mb-8">
          <h2 className="text-xl sm:text-2xl font-bold mb-6 flex items-center gap-2">
            <Globe className="w-6 h-6 text-blue-600" />
            {isEn ? 'Foreign Embassies & High Commissions in Dhaka' : 'বাংলাদেশে অবস্থিত বিদেশি দূতাবাসসমূহ'}
          </h2>
          <p className="text-sm text-muted-foreground mb-6">
            {isEn
              ? 'Top 20 diplomatic missions in Dhaka with verified addresses, contact numbers, and official websites for visa and consular inquiries.'
              : 'ঢাকার শীর্ষ ২০টি বিদেশি দূতাবাসের যাচাইকৃত ঠিকানা, ফোন নম্বর এবং ভিসা সংক্রান্ত তথ্যের অফিসিয়াল লিংক।'}
          </p>

          {embassies.length === 0 ? (
            <div className="text-center py-12 bg-card border rounded-xl text-muted-foreground">
              {isEn ? 'Loading embassies directory...' : 'দূতাবাস তালিকা লোড হচ্ছে...'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {embassies.map((emb: any) => {
                const name = (isEn ? emb.countryNameEn : emb.countryNameBn) || emb.countryNameEn || emb.countryNameBn;
                const address = (isEn ? emb.addressEn : emb.addressBn) || emb.addressBn;
                const phone = emb.phone || "+880-2-988xxxx";
                const websiteUrl = emb.websiteUrl || "#";

                return (
                  <div key={emb.id} className="bg-card border rounded-xl p-5 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-7 bg-emerald-100 dark:bg-emerald-950/40 rounded flex items-center justify-center text-xl shadow-sm border" aria-label={`${name} flag`}>
                          {emb.flagEmoji || emb.countryCode || "🌐"}
                        </div>
                        <div>
                          <span className="text-xs font-semibold text-muted-foreground">{isEn ? emb.countryNameEn : emb.countryNameBn}</span>
                          <h3 className="text-base font-bold text-foreground leading-tight">{name}</h3>
                        </div>
                      </div>

                      <div className="space-y-2 text-xs text-muted-foreground mb-4">
                        <p className="flex items-start gap-1.5">
                          <MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0 text-emerald-600" />
                          <span><strong>{isEn ? "Address:" : "ঠিকানা:"}</strong> {address}</span>
                        </p>
                        <p className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 shrink-0 text-teal-600" />
                          <span><strong>{isEn ? "Phone:" : "ফোন:"}</strong> {phone}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 pt-3 border-t">
                      {websiteUrl && websiteUrl !== "#" && (
                        <a
                          href={websiteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => trackEvent('embassy_website_click')}
                          className="w-full inline-flex items-center justify-center gap-1.5 bg-muted hover:bg-muted/80 text-foreground font-medium py-1.5 px-3 rounded-lg text-xs transition-colors"
                        >
                          <Globe className="w-3.5 h-3.5 text-blue-600" />
                          {isEn ? 'Official Website' : 'অফিসিয়াল ওয়েবসাইট'}
                        </a>
                      )}
                      <Link
                        href="/contact"
                        onClick={() => trackEvent('embassy_contact_click')}
                        className="w-full inline-flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-2 px-3 rounded-lg text-xs transition-colors shadow-sm"
                      >
                        {isEn ? 'Use the portal contact page' : 'যোগাযোগ পেজে যান'}
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
      <SahajFooter />
    </div>
  );
}
