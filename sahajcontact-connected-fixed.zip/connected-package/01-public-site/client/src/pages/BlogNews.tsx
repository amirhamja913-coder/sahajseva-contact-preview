import { CalendarDays, FileText, Newspaper, Pin } from "lucide-react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

function formatPublishedDate(value: Date | string | null | undefined, language: "BN" | "EN") {
  if (!value) return language === "EN" ? "Recently published" : "সাম্প্রতিক প্রকাশনা";
  const date = new Date(value);
  return date.toLocaleDateString(language === "EN" ? "en-US" : "bn-BD", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export default function BlogNews() {
  const { language } = useLanguage();
  const postsQuery = trpc.siteManagement.management.listBlogPosts.useQuery({ includeDrafts: false }, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const sidebarAdsQuery = trpc.adminAnalytics.advertising.live.useQuery({ slot: "sidebar" }, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const blogAdsQuery = trpc.adminAnalytics.advertising.live.useQuery({ slot: "blog" }, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const trackAdClickMutation = trpc.adminAnalytics.advertising.trackClick.useMutation();
  const isEnglish = language === "EN";
  const posts = postsQuery.data ?? [];
  const sidebarAds = sidebarAdsQuery.data ?? [];
  const blogAds = blogAdsQuery.data ?? [];

  return (
    <div className="site-shell min-h-screen bg-[#f8faf8] text-slate-900">
      <SahajHeader />
      <main className="container py-10 sm:py-14">
        <section className="overflow-hidden rounded-[2rem] border border-teal-900/10 bg-gradient-to-br from-teal-950 via-teal-800 to-emerald-700 px-6 py-10 text-white shadow-xl sm:px-10 sm:py-14">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-3 py-1 text-xs font-bold tracking-wide">
              <Newspaper size={15} aria-hidden="true" /> {isEnglish ? "OFFICIAL UPDATES" : "অফিসিয়াল আপডেট"}
            </span>
            <h1 className="mt-5 text-3xl font-black tracking-tight sm:text-5xl">{isEnglish ? "Blog & News" : "ব্লগ ও সংবাদ"}</h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-teal-50 sm:text-lg">
              {isEnglish
                ? "Service updates and helpful public-information articles published by the SahajContact team."
                : "SahajContact টিমের প্রকাশিত সেবা-আপডেট ও সহায়ক জনতথ্যের লেখা।"}
            </p>
          </div>
        </section>

        <section className="mt-8" aria-live="polite">
          {postsQuery.isLoading && <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-slate-600">{isEnglish ? "Loading updates…" : "আপডেট লোড হচ্ছে…"}</div>}
          {postsQuery.isError && <div className="rounded-2xl border border-rose-200 bg-rose-50 p-6 text-rose-800">{isEnglish ? "Updates could not be loaded. Please try again shortly." : "আপডেট লোড করা যায়নি। অনুগ্রহ করে একটু পরে আবার চেষ্টা করুন।"}</div>}
          {!postsQuery.isLoading && !postsQuery.isError && posts.length === 0 && (
            <div className="rounded-2xl border border-dashed border-teal-700/30 bg-white p-10 text-center">
              <FileText className="mx-auto h-9 w-9 text-teal-700" aria-hidden="true" />
              <h2 className="mt-3 text-lg font-bold">{isEnglish ? "No published updates yet" : "এখনও কোনো প্রকাশিত আপডেট নেই"}</h2>
              <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-600">{isEnglish ? "New service information will appear here after it is published." : "নতুন সেবা-সংক্রান্ত তথ্য প্রকাশ হলে এখানে দেখা যাবে।"}</p>
              <Link href="/" className="mt-5 inline-flex rounded-xl bg-teal-800 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-teal-700">{isEnglish ? "Return home" : "হোমে ফিরে যান"}</Link>
            </div>
          )}
          <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_17rem]">
            <div className="grid gap-5 md:grid-cols-2">
              {posts.map((post) => {
              const title = isEnglish ? post.titleEn || post.titleBn : post.titleBn;
              const excerpt = isEnglish ? post.excerptEn || post.excerptBn : post.excerptBn;
              const content = isEnglish ? post.contentEn || post.contentBn : post.contentBn;
              return (
                <article key={post.id} className="flex min-h-72 flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition duration-200 hover:-translate-y-0.5 hover:shadow-lg">
                  {post.coverImageUrl && <img src={post.coverImageUrl} alt="" className="h-44 w-full object-cover" loading="lazy" decoding="async" />}
                  <div className="flex flex-1 flex-col p-5">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-teal-800"><CalendarDays size={14} aria-hidden="true" /> {formatPublishedDate(post.publishedAt, language)}{post.isPinned === 1 && <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-amber-900"><Pin size={12} aria-hidden="true" />{isEnglish ? "Pinned" : "পিন করা"}</span>}</div>
                    <h2 className="mt-3 text-xl font-black leading-7 text-slate-900">{title}</h2>
                    <p className="mt-3 text-sm leading-6 text-slate-600">{excerpt || content}</p>
                    {post.pdfUrl && <a href={post.pdfUrl} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex w-fit items-center gap-2 rounded-lg border border-teal-200 px-3 py-2 text-sm font-bold text-teal-800 transition hover:bg-teal-50"><FileText size={15} aria-hidden="true" />{isEnglish ? "Open PDF notice" : "PDF নোটিশ খুলুন"}</a>}
                  </div>
                </article>
              );
              })}
            </div>
            {sidebarAds.length > 0 && (
              <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-4 shadow-sm" aria-label={isEnglish ? "Sponsored sidebar" : "স্পন্সরকৃত সাইডবার"}>
                <p className="text-xs font-bold uppercase tracking-wide text-slate-500">{isEnglish ? "Sponsored" : "স্পন্সরকৃত"}</p>
                <div className="mt-3 space-y-3">
                  {sidebarAds.map((ad) => <a key={ad.id} href={ad.adUrl} target="_blank" rel="sponsored noopener noreferrer" onClick={() => trackAdClickMutation.mutate({ orderId: ad.id })} className="block rounded-xl border border-teal-900/10 bg-teal-50 p-3 text-sm font-bold leading-5 text-teal-950 transition hover:bg-teal-100">{isEnglish ? ad.adTitleEn || ad.adTitleBn : ad.adTitleBn}</a>)}
                </div>
              </aside>
            )}
          </div>
          {blogAds.length > 0 && (
            <aside className="mt-8 rounded-2xl border border-amber-200 bg-amber-50 p-5" aria-label={isEnglish ? "Sponsored blog placement" : "স্পন্সরকৃত ব্লগ স্থান"}>
              <p className="text-xs font-bold uppercase tracking-wide text-amber-800">{isEnglish ? "Sponsored blog placement" : "স্পন্সরকৃত ব্লগ স্থান"}</p>
              <div className="mt-3 flex flex-wrap gap-3">
                {blogAds.map((ad) => <a key={ad.id} href={ad.adUrl} target="_blank" rel="sponsored noopener noreferrer" onClick={() => trackAdClickMutation.mutate({ orderId: ad.id })} className="rounded-xl bg-white px-4 py-3 text-sm font-bold text-amber-950 shadow-sm transition hover:bg-amber-100">{isEnglish ? ad.adTitleEn || ad.adTitleBn : ad.adTitleBn}</a>)}
              </div>
            </aside>
          )}
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
