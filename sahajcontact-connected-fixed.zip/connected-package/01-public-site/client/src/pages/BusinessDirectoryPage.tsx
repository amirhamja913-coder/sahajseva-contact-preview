import { useMemo, useState, type FormEvent } from "react";
import { ArrowLeft, Building2, CheckCircle2, ExternalLink, Loader2, MapPin, Search, Send, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import SahajCivicChatWidget from "@/components/SahajCivicChatWidget";
import { BusinessDirectoryClaimRequest } from "@/components/BusinessDirectoryClaimRequest";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

type DirectoryForm = {
  businessName: string;
  category: string;
  district: string;
  publicWebsiteUrl: string;
  publicDescription: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  consentAccepted: boolean;
};

const initialForm: DirectoryForm = {
  businessName: "",
  category: "",
  district: "",
  publicWebsiteUrl: "",
  publicDescription: "",
  contactName: "",
  contactEmail: "",
  contactPhone: "",
  consentAccepted: false,
};

export default function BusinessDirectoryPage() {
  const { language } = useLanguage();
  const isEnglish = language === "EN";
  const [form, setForm] = useState<DirectoryForm>(initialForm);
  const [query, setQuery] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const listings = trpc.businessDirectory.listPublished.useQuery();
  const submit = trpc.businessDirectory.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setForm(initialForm);
    },
  });

  const filteredListings = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    if (!normalized) return listings.data ?? [];
    return (listings.data ?? []).filter((listing) =>
      [listing.businessName, listing.category, listing.district, listing.publicDescription]
        .some((value) => value.toLocaleLowerCase().includes(normalized)),
    );
  }, [listings.data, query]);

  const copy = isEnglish
    ? {
        back: "Back to home",
        eyebrow: "Owner-reviewed directory",
        title: "Business Directory",
        intro: "A public information directory for businesses that the site owner has deliberately approved for listing. Publication is not a licence check, government approval, endorsement, rating or paid placement.",
        safeguard: "Contact details submitted for review remain private. Visitors see only the business information deliberately published by the owner.",
        search: "Search by name, category or district",
        loading: "Loading published listings…",
        empty: "No business listing has been published yet.",
        emptySearch: "No published listing matches this search.",
        website: "Official website",
        requestTitle: "Request a listing review",
        requestLead: "A request starts in private pending review. It does not create a public listing, verification, partnership, payment obligation or commercial approval.",
        businessName: "Business or organisation name",
        category: "Type of work or category",
        district: "District or service area",
        websiteField: "Public website (optional)",
        description: "Short public description",
        contactName: "Contact person",
        email: "Contact email",
        phone: "Contact phone",
        consent: "I confirm that I may share these contact details for private owner review. I will not submit financial details, government ID, passwords, OTPs or payment information.",
        submit: "Send for owner review",
        submitting: "Saving…",
        successTitle: "Your request has been saved for private review.",
        successText: "It will remain unpublished unless the owner deliberately approves a public listing.",
        another: "Submit another request",
        errorPrefix: "We could not save the request:",
      }
    : {
        back: "হোমপেজে ফিরে যান",
        eyebrow: "Owner-review করা তথ্যভান্ডার",
        title: "ব্যবসা ও প্রতিষ্ঠানের তথ্যভান্ডার",
        intro: "যে ব্যবসা বা প্রতিষ্ঠানকে site owner সচেতনভাবে প্রকাশের অনুমোদন দিয়েছেন, শুধু তাদের জন্য এটি একটি public তথ্যভান্ডার। প্রকাশ হওয়া মানে লাইসেন্স পরীক্ষা, সরকারি অনুমোদন, সমর্থন, rating বা paid placement নয়।",
        safeguard: "Review-এর জন্য দেওয়া যোগাযোগের তথ্য private থাকে। Visitor কেবল owner সচেতনভাবে প্রকাশ করা ব্যবসায়িক তথ্যই দেখবেন।",
        search: "নাম, ধরন বা জেলা লিখে খুঁজুন",
        loading: "প্রকাশিত তালিকা লোড হচ্ছে…",
        empty: "এখনও কোনো ব্যবসায়িক তথ্য প্রকাশ করা হয়নি।",
        emptySearch: "এই খোঁজের সঙ্গে মেলে এমন কোনো প্রকাশিত তথ্য নেই।",
        website: "অফিসিয়াল ওয়েবসাইট",
        requestTitle: "তালিকাভুক্তির জন্য review অনুরোধ দিন",
        requestLead: "প্রতিটি অনুরোধ private pending review হিসেবে শুরু হয়। এতে public listing, যাচাই, partnership, payment obligation বা বাণিজ্যিক অনুমোদন তৈরি হয় না।",
        businessName: "ব্যবসা বা প্রতিষ্ঠানের নাম",
        category: "কাজের ধরন বা category",
        district: "জেলা বা সেবার এলাকা",
        websiteField: "Public ওয়েবসাইট (ঐচ্ছিক)",
        description: "Public-এর জন্য সংক্ষিপ্ত পরিচিতি",
        contactName: "যোগাযোগকারী ব্যক্তির নাম",
        email: "যোগাযোগের ইমেইল",
        phone: "যোগাযোগের ফোন",
        consent: "আমি নিশ্চিত করছি যে private owner review-এর জন্য এই যোগাযোগের তথ্য দেওয়ার অনুমতি আমার আছে। আমি আর্থিক তথ্য, সরকারি পরিচয়পত্র, পাসওয়ার্ড, OTP বা payment তথ্য দেব না।",
        submit: "Owner review-এর জন্য পাঠান",
        submitting: "সংরক্ষণ হচ্ছে…",
        successTitle: "আপনার অনুরোধটি private review-এর জন্য সংরক্ষিত হয়েছে।",
        successText: "Owner সচেতনভাবে অনুমোদন না দেওয়া পর্যন্ত এটি public-এ প্রকাশ হবে না।",
        another: "আরেকটি অনুরোধ দিন",
        errorPrefix: "অনুরোধটি সংরক্ষণ করা যায়নি:",
      };

  const update = <Key extends keyof DirectoryForm>(key: Key, value: DirectoryForm[Key]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(false);
    submit.mutate(form);
  };

  return (
    <div className="public-civic-page min-h-screen bg-slate-950 text-slate-100">
      <SahajHeader />
      <main className="container mx-auto max-w-6xl px-4 py-8 sm:py-12">
        <Link href="/" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-teal-300 transition hover:text-teal-100"><ArrowLeft className="h-4 w-4" />{copy.back}</Link>

        <section className="relative overflow-hidden rounded-3xl border border-teal-300/20 bg-[radial-gradient(circle_at_top_right,_rgba(45,212,191,0.18),_transparent_42%),linear-gradient(135deg,_rgba(15,118,110,0.24),_rgba(15,23,42,0.94))] p-6 shadow-2xl shadow-teal-950/30 sm:p-10">
          <div className="relative max-w-4xl space-y-5">
            <p className="inline-flex items-center gap-2 rounded-full border border-teal-300/20 bg-teal-300/10 px-3 py-1.5 text-xs font-bold tracking-wide text-teal-100"><Building2 className="h-3.5 w-3.5" />{copy.eyebrow}</p>
            <h1 className="text-3xl font-black leading-tight text-white sm:text-5xl">{copy.title}</h1>
            <p className="max-w-3xl text-base leading-8 text-slate-200 sm:text-lg">{copy.intro}</p>
            <div className="flex items-start gap-3 rounded-2xl border border-amber-300/25 bg-amber-300/10 p-4 text-sm leading-6 text-amber-100"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" /><p>{copy.safeguard}</p></div>
          </div>
        </section>

        <section className="mt-8" aria-labelledby="directory-results-heading">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div><h2 id="directory-results-heading" className="text-2xl font-bold text-white">{isEnglish ? "Published listings" : "প্রকাশিত তথ্য"}</h2><p className="mt-1 text-sm text-slate-300">{isEnglish ? "Only owner-published details are visible here." : "শুধু owner প্রকাশ করা তথ্যই এখানে দেখা যায়।"}</p></div>
            <label className="relative block sm:w-80"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={copy.search} className="w-full rounded-xl border border-slate-700 bg-slate-900 py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-slate-500 focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
          </div>
          {listings.isLoading ? <div className="mt-5 rounded-2xl border border-slate-800 bg-slate-900/60 p-6 text-sm text-slate-300">{copy.loading}</div> : filteredListings.length ? <div className="mt-5 grid gap-4 md:grid-cols-2">{filteredListings.map((listing) => <article key={listing.id} className="rounded-2xl border border-slate-700 bg-slate-900/80 p-5 shadow-lg"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[0.14em] text-teal-300">{listing.category}</p><h3 className="mt-1 text-xl font-bold text-white">{listing.businessName}</h3></div><MapPin className="h-5 w-5 shrink-0 text-teal-300" /></div><p className="mt-1 text-sm text-slate-300">{listing.district}</p><p className="mt-4 text-sm leading-7 text-slate-200">{listing.publicDescription}</p>{listing.publicWebsiteUrl ? <a href={listing.publicWebsiteUrl} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-teal-300 transition hover:text-teal-100">{copy.website}<ExternalLink className="h-4 w-4" /></a> : null}</article>)}</div> : <div className="mt-5 rounded-2xl border border-dashed border-slate-700 bg-slate-900/50 p-8 text-center"><Building2 className="mx-auto h-8 w-8 text-slate-500" /><p className="mt-3 text-sm text-slate-300">{query ? copy.emptySearch : copy.empty}</p></div>}
        </section>

        <BusinessDirectoryClaimRequest />

        <section className="mt-10 rounded-3xl border border-slate-700 bg-slate-900 p-6 shadow-2xl sm:p-9" aria-labelledby="directory-request-heading">
          <div className="max-w-3xl"><div className="flex items-center gap-3"><span className="rounded-xl bg-teal-400/10 p-3 text-teal-300"><Send className="h-6 w-6" /></span><h2 id="directory-request-heading" className="text-2xl font-bold text-white">{copy.requestTitle}</h2></div><p className="mt-3 text-sm leading-7 text-slate-300">{copy.requestLead}</p></div>
          {submitted ? <div className="mt-6 rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-5"><div className="flex gap-3"><CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-300" /><div><h3 className="font-bold text-emerald-100">{copy.successTitle}</h3><p className="mt-1 text-sm leading-6 text-emerald-50/80">{copy.successText}</p></div></div><button type="button" onClick={() => setSubmitted(false)} className="mt-4 text-sm font-bold text-emerald-200 underline underline-offset-4">{copy.another}</button></div> : <form onSubmit={handleSubmit} className="mt-7 grid gap-5 sm:grid-cols-2">
            <label className="text-sm font-semibold text-slate-200">{copy.businessName}<input required maxLength={180} value={form.businessName} onChange={(event) => update("businessName", event.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="text-sm font-semibold text-slate-200">{copy.category}<input required maxLength={120} value={form.category} onChange={(event) => update("category", event.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="text-sm font-semibold text-slate-200">{copy.district}<input required maxLength={120} value={form.district} onChange={(event) => update("district", event.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="text-sm font-semibold text-slate-200">{copy.websiteField}<input type="url" maxLength={500} value={form.publicWebsiteUrl} onChange={(event) => update("publicWebsiteUrl", event.target.value)} placeholder="https://" className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white placeholder:text-slate-600 focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="sm:col-span-2 text-sm font-semibold text-slate-200">{copy.description}<textarea required minLength={20} maxLength={2_000} rows={4} value={form.publicDescription} onChange={(event) => update("publicDescription", event.target.value)} className="mt-2 w-full resize-y rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="text-sm font-semibold text-slate-200">{copy.contactName}<input required maxLength={160} value={form.contactName} onChange={(event) => update("contactName", event.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="text-sm font-semibold text-slate-200">{copy.email}<input required type="email" maxLength={320} value={form.contactEmail} onChange={(event) => update("contactEmail", event.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="text-sm font-semibold text-slate-200">{copy.phone}<input required minLength={10} maxLength={32} value={form.contactPhone} onChange={(event) => update("contactPhone", event.target.value)} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-white focus:border-teal-400 focus:outline-none focus:ring-2 focus:ring-teal-400/30" /></label>
            <label className="sm:col-span-2 flex items-start gap-3 rounded-xl border border-slate-700 bg-slate-950/80 p-4 text-sm leading-6 text-slate-300"><input required type="checkbox" checked={form.consentAccepted} onChange={(event) => update("consentAccepted", event.target.checked)} className="mt-1 h-4 w-4 accent-teal-400" /><span>{copy.consent}</span></label>
            {submit.error ? <p className="sm:col-span-2 rounded-xl border border-rose-400/25 bg-rose-400/10 p-3 text-sm text-rose-100">{copy.errorPrefix} {submit.error.message}</p> : null}
            <div className="sm:col-span-2"><button type="submit" disabled={submit.isPending} className="inline-flex items-center gap-2 rounded-xl bg-teal-400 px-5 py-3 text-sm font-black text-slate-950 transition hover:bg-teal-300 disabled:cursor-not-allowed disabled:opacity-60">{submit.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}{submit.isPending ? copy.submitting : copy.submit}</button></div>
          </form>}
        </section>
      </main>
      <SahajFooter />
      <SahajCivicChatWidget />
    </div>
  );
}
