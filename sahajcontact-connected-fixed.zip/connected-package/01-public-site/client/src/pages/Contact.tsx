import { ArrowLeft, ArrowUpRight, CheckCircle2, Clock3, ExternalLink, Handshake, Mail, MapPin, Phone, Send, ShieldCheck, UserRound } from "lucide-react";
import { FormEvent, useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { MapView } from "@/components/Map";
import { Spinner } from "@/components/ui/spinner";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import ServiceReviews from "@/components/ServiceReviews";
import { SITE_WIDE_REVIEW_ID, siteWideReviewIds } from "@/lib/reviewScopes";
import { trpc } from "@/lib/trpc";
import { trackEvent } from "../lib/analytics";

const DEFAULT_CONTACT_ITEMS = [
  { icon: UserRound, label: "নাম", value: "কাজী মোঃ আমির হামজা" },
  { icon: UserRound, label: "পিতা", value: "জয়নাল আবেদীন" },
  { icon: Phone, label: "মোবাইল", value: "01965177538", href: "tel:01965177538" },
  { icon: Mail, label: "ইমেইল", value: "amirhamja913@gmail.com", href: "mailto:amirhamja913@gmail.com" },
  { icon: Clock3, label: "সেবা সময়", value: "প্রতিদিন সকাল ৯টা — রাত ৯টা" },
];

const OFFICE_LOCATION = { lat: 23.84085, lng: 91.03932 };
const OFFICE_MAP_QUERY = "টিয়ারা বাজার, নবীনগর, ব্রাহ্মণবাড়িয়া, বাংলাদেশ";

function ContactForm({ onSubmitted }: { onSubmitted: () => void }) {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const formRef = useRef<HTMLFormElement | null>(null);
  const contactMutation = trpc.contact.submit.useMutation();

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (contactMutation.isPending) return;

    const formData = new FormData(event.currentTarget);
    const subject = String(formData.get("subject") || "");
    trackEvent("contact_form_submit", { subject: String(formData.get("subject") || "unspecified") });
    setErrorMessage(null);
    contactMutation.mutate(
      {
        name: String(formData.get("name") || ""),
        mobile: String(formData.get("phone") || ""),
        email: String(formData.get("email") || "") || undefined,
        subject,
        message: String(formData.get("message") || ""),
        consentAccepted: formData.get("consentAccepted") === "on",
      },
      {
        onSuccess: () => {
          formRef.current?.reset();
          trackEvent("contact_form_success", { subject });
          onSubmitted();
        },
        onError: (error) => {
          setErrorMessage(error.message || "বার্তাটি পাঠানো যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।");
          trackEvent("contact_form_error", { subject });
        },
      },
    );
  }

  return (
    <form ref={formRef} className="contact-v2-form" onSubmit={handleSubmit}>
      <div className="contact-v2-form-heading">
        <div>
          <span className="section-number">বার্তা পাঠান</span>
          <h2>আপনার প্রয়োজনটি বলুন</h2>
        </div>
        <span className="contact-v2-required"><i /> আবশ্যক ঘর</span>
      </div>
      <div className="form-row">
        <label>আপনার নাম <b>*</b><input name="name" required autoComplete="name" placeholder="পূর্ণ নাম লিখুন" /></label>
        <label>মোবাইল নাম্বার <b>*</b><input name="phone" required type="tel" inputMode="tel" autoComplete="tel" placeholder="019XXXXXXXX" /></label>
      </div>
      <label>ইমেইল <span className="optional-label">(ঐচ্ছিক)</span><input name="email" type="email" autoComplete="email" placeholder="আপনার ইমেইল" /></label>
      <label>যোগাযোগের বিষয় <b>*</b><select name="subject" defaultValue="সেবা সম্পর্কে জানতে চাই" required><option value="সেবা সম্পর্কে জানতে চাই">সেবা সম্পর্কে জানতে চাই</option><option value="অভিযোগ">অভিযোগ</option><option value="পরামর্শ">পরামর্শ</option><option value="ব্যবসায়িক যোগাযোগ">ব্যবসায়িক যোগাযোগ</option></select></label>
      <label>আপনার বার্তা <b>*</b><textarea name="message" required minLength={10} rows={5} placeholder="কীভাবে আমরা সাহায্য করতে পারি?" /></label>
      <label className="sponsor-consent"><input type="checkbox" name="consentAccepted" required /><span>এই তথ্য ব্যবহার করে সহজসেবা আমার সঙ্গে যোগাযোগ করতে পারবে—আমি সম্মত।</span></label>
      {errorMessage && <p className="sponsor-form-error" role="alert">{errorMessage}</p>}
      <button type="submit" className="button button-primary submit-button" disabled={contactMutation.isPending} aria-busy={contactMutation.isPending}>
        {contactMutation.isPending ? <><Spinner className="contact-v2-spinner" /><span>বার্তা পাঠানো হচ্ছে…</span></> : <>বার্তাটি পাঠান <Send size={16} /></>}
      </button>
      {contactMutation.isPending && <p className="contact-v2-submit-status" role="status" aria-live="polite">আপনার তথ্য নিরাপদে পাঠানো হচ্ছে…</p>}
      <p className="form-privacy"><ShieldCheck size={14} /> OTP, PIN, পাসওয়ার্ড, NID বা ব্যাংক/কার্ডের সংবেদনশীল তথ্য লিখবেন না। ইমেইল দিলে তা শুধু এই যোগাযোগের উদ্দেশ্যেই রাখা হবে।</p>
    </form>
  );
}

function SponsorInquiryForm() {
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const formRef = useRef<HTMLFormElement | null>(null);
  const sponsorMutation = trpc.sponsors.submit.useMutation();

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (sponsorMutation.isPending) return;

    const formData = new FormData(event.currentTarget);
    const interest = String(formData.get("interest") || "");
    setErrorMessage(null);
    trackEvent("sponsor_inquiry_submit", { interest });

    sponsorMutation.mutate(
      {
        name: String(formData.get("name") || ""),
        organization: String(formData.get("organization") || ""),
        email: String(formData.get("email") || ""),
        phone: String(formData.get("phone") || ""),
        interest,
        message: String(formData.get("message") || ""),
        consentAccepted: formData.get("consentAccepted") === "on",
      },
      {
        onSuccess: () => {
          formRef.current?.reset();
          setSubmitted(true);
          trackEvent("sponsor_inquiry_success", { interest });
        },
        onError: (error) => {
          setErrorMessage(error.message || "যোগাযোগ পাঠানো যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।");
          trackEvent("sponsor_inquiry_error", { interest });
        },
      },
    );
  }

  if (submitted) {
    return (
      <div className="sponsor-success-state" role="status" aria-live="polite">
        <div className="sponsor-success-icon"><CheckCircle2 size={31} /></div>
        <span className="section-number">বার্তা নিরাপদে পৌঁছেছে</span>
        <h3>যোগাযোগের জন্য ধন্যবাদ</h3>
        <p>আপনার প্রস্তাবটি আমাদের টিমের কাছে পাঠানো হয়েছে। প্রয়োজন অনুযায়ী পরবর্তী যোগাযোগের জন্য দেওয়া ইমেইল বা ফোন নম্বর ব্যবহার করা হবে।</p>
        <button type="button" className="button button-quiet" onClick={() => { setSubmitted(false); setErrorMessage(null); trackEvent("sponsor_inquiry_reset"); }}>আরেকটি বার্তা পাঠান <span>→</span></button>
      </div>
    );
  }

  return (
    <form ref={formRef} className="sponsor-form" onSubmit={handleSubmit} noValidate>
      <div className="sponsor-form-heading">
        <div>
          <span className="section-number">যোগাযোগ ফর্ম</span>
          <h3>আপনার সহযোগিতার কথা বলুন</h3>
        </div>
        <span className="contact-v2-required"><i /> আবশ্যক ঘর</span>
      </div>
      <div className="sponsor-form-grid">
        <label>আপনার নাম <b>*</b><input name="name" required autoComplete="name" placeholder="পূর্ণ নাম" /></label>
        <label>প্রতিষ্ঠানের নাম <b>*</b><input name="organization" required autoComplete="organization" placeholder="কোম্পানি, NGO বা প্রতিষ্ঠানের নাম" /></label>
        <label>ইমেইল <b>*</b><input name="email" required type="email" autoComplete="email" placeholder="name@organization.com" /></label>
        <label>ফোন নম্বর <span className="optional-label">(ঐচ্ছিক)</span><input name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="019XXXXXXXX" /></label>
      </div>
      <label>আগ্রহের ক্ষেত্র <b>*</b><select name="interest" defaultValue="" required><option value="" disabled>একটি বিষয় নির্বাচন করুন</option><option value="অর্থায়ন ও সামাজিক বিনিয়োগ">অর্থায়ন ও সামাজিক বিনিয়োগ</option><option value="CSR ও জনকল্যাণ">CSR ও জনকল্যাণ</option><option value="প্রযুক্তি ও অবকাঠামো">প্রযুক্তি ও অবকাঠামো</option><option value="মিডিয়া ও প্রচার">মিডিয়া ও প্রচার</option><option value="NGO/প্রাতিষ্ঠানিক অংশীদারিত্ব">NGO/প্রাতিষ্ঠানিক অংশীদারিত্ব</option><option value="অন্যান্য">অন্যান্য</option></select></label>
      <label>বার্তা <b>*</b><textarea name="message" required minLength={10} rows={5} placeholder="আপনার প্রস্তাব, সহযোগিতার ধরন বা প্রশ্নটি লিখুন" /></label>
      <label className="sponsor-consent"><input type="checkbox" name="consentAccepted" required /><span>এই তথ্য ব্যবহার করে সহজসেবা আমার সঙ্গে যোগাযোগ করতে পারবে—আমি সম্মত।</span></label>
      {errorMessage && <p className="sponsor-form-error" role="alert">{errorMessage}</p>}
      <button type="submit" className="button button-primary submit-button" disabled={sponsorMutation.isPending} aria-busy={sponsorMutation.isPending}>
        {sponsorMutation.isPending ? <><Spinner className="contact-v2-spinner" /><span>বার্তা পাঠানো হচ্ছে…</span></> : <>যোগাযোগ পাঠান <Send size={16} /></>}
      </button>
      {sponsorMutation.isPending && <p className="contact-v2-submit-status" role="status" aria-live="polite">আপনার তথ্য নিরাপদে পাঠানো হচ্ছে…</p>}
      <p className="form-privacy"><ShieldCheck size={14} /> সংবেদনশীল NID, OTP, PIN বা পাসওয়ার্ড পাঠাবেন না। আপনার তথ্য শুধু যোগাযোগের উদ্দেশ্যে ব্যবহার করা হবে।</p>
    </form>
  );
}

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState(false);
  const approvedReviewsQuery = trpc.reviews.listApproved.useQuery(
    { serviceIds: siteWideReviewIds },
    { staleTime: 30_000, refetchOnWindowFocus: false },
  );
  const siteContentQuery = trpc.siteManagement.getPublicContent.useQuery(undefined, { staleTime: 60_000, refetchOnWindowFocus: false });
  const mapPhotosQuery = trpc.personalGallery.publicPhotos.useQuery({ folder: "map" }, { staleTime: 60_000, refetchOnWindowFocus: false });
  const publicMapPhoto = mapPhotosQuery.data?.[0];
  const managedContactPhone = siteContentQuery.data?.settings?.contactPhone || "01965177538";
  const managedContactEmail = siteContentQuery.data?.settings?.contactEmail || "amirhamja913@gmail.com";
  const contactItems = DEFAULT_CONTACT_ITEMS.map((item) => item.label === "মোবাইল"
    ? { ...item, value: managedContactPhone, href: `tel:${managedContactPhone}` }
    : item.label === "ইমেইল"
      ? { ...item, value: managedContactEmail, href: `mailto:${managedContactEmail}` }
      : item);


  useEffect(() => {
    trackEvent("page_view", { page: "contact" });
  }, []);

  return (
    <div className="site-shell public-civic-page public-info-page">
      <SahajHeader />
      <main>
        <section className="contact-v2-hero">
          <div className="route-motif route-motif-hero" aria-hidden="true"><span /><i /><b /></div>
          <div className="container contact-v2-hero-inner">
            <div className="contact-v2-intro reveal-up">
              <Link href="/" className="back-link"><ArrowLeft size={15} aria-hidden="true" /> হোমে ফিরে যান</Link>
              <span className="eyebrow contact-v2-eyebrow"><span className="eyebrow-dot" /> ০৪ / যোগাযোগ</span>
              <h1>কথা বলুন,<br /><em>আমরা শুনছি।</em></h1>
              <p>আপনার মতামত, প্রশ্ন বা সেবা-সংক্রান্ত প্রয়োজন আমাদের জানান। সঠিক তথ্য নিয়ে পরবর্তী ধাপটি সহজভাবে বুঝতে আমরা সহায়তা করব।</p>
              <div className="contact-v2-trust-row">
                <span><CheckCircle2 size={15} /> ২৪ ঘণ্টার মধ্যে উত্তর দেওয়ার চেষ্টা</span>
                <span><ShieldCheck size={15} /> তথ্যের নিরাপত্তাকে গুরুত্ব</span>
              </div>
            </div>
            <div className="contact-v2-form-shell reveal-up" style={{ animationDelay: "100ms" }}>
              {!submitted ? (
                <ContactForm onSubmitted={() => setSubmitted(true)} />
              ) : (
                <div className="success-state contact-v2-success" role="status" aria-live="polite">
                  <div className="success-icon"><CheckCircle2 size={33} /></div>
                  <span className="section-number">বার্তা গ্রহণ করা হয়েছে</span>
                  <h2>ধন্যবাদ!</h2>
                  <p>আপনার বার্তাটি আমরা পেয়েছি। প্রয়োজন হলে ২৪ ঘণ্টার মধ্যে আপনার দেওয়া নম্বরে যোগাযোগ করা হবে।</p>
                  <button type="button" className="button button-quiet" onClick={() => { trackEvent("contact_form_reset"); setSubmitted(false); }}>আরেকটি বার্তা পাঠান <span>→</span></button>
                </div>
              )}
            </div>
          </div>
        </section>

        <section className="contact-v2-location" aria-labelledby="contact-location-heading">
          <div className="container contact-v2-location-grid">
            <div className="contact-v2-location-copy">
              <span className="section-number">আমাদের অবস্থান</span>
              <h2 id="contact-location-heading">সহজে খুঁজে নিন<br /><em>যোগাযোগের পথ।</em></h2>
              <p>আমাদের সহায়তা বাংলাদেশ-কেন্দ্রিক। নিচের মানচিত্রে আমাদের অফিসের অবস্থান দেখানো হয়েছে। দেখা করার আগে ফোনে সময় নিশ্চিত করে নিন।</p>
              <div className="contact-v2-address-card">
                <MapPin size={19} aria-hidden="true" />
                <div><strong>গ্রাম: টিয়ারা বাজার</strong><span>ইউনিয়ন: বিটঘর, থানা: নবীনগর, জেলা: ব্রাহ্মণবাড়িয়া, বাংলাদেশ</span></div>
              </div>
              <a className="contact-v2-map-link" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(OFFICE_MAP_QUERY)}`} target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("contact_map_open")}>
                Google Maps-এ খুলুন <ExternalLink size={14} aria-hidden="true" />
              </a>
              {publicMapPhoto ? <figure style={{ margin: "1.25rem 0 0", overflow: "hidden", borderRadius: "1rem", border: "1px solid rgba(15, 118, 110, 0.2)", background: "#fff" }}><img src={publicMapPhoto.imageUrl} alt={publicMapPhoto.titleBn} style={{ display: "block", width: "100%", aspectRatio: "16 / 9", objectFit: "cover" }} loading="lazy" /><figcaption style={{ padding: "0.75rem 0.9rem", color: "#334155", fontSize: "0.9rem", fontWeight: 700 }}>{publicMapPhoto.titleBn}</figcaption></figure> : null}
            </div>
            <div className="contact-v2-map-shell">
              <MapView
                className="contact-v2-map"
                initialCenter={OFFICE_LOCATION}
                initialZoom={13}
                onMapReady={(map) => {
                  setMapLoaded(true);
                  setMapError(false);
                  if (window.google?.maps?.marker?.AdvancedMarkerElement) {
                    new window.google.maps.marker.AdvancedMarkerElement({
                      map,
                      position: OFFICE_LOCATION,
                      title: OFFICE_MAP_QUERY,
                    });
                  }
                }}
                onMapError={() => setMapError(true)}
              />
              {!mapLoaded && <div className="contact-v2-map-fallback" role="status" aria-live="polite"><div className="contact-v2-map-fallback-pin"><MapPin size={21} fill="currentColor" aria-hidden="true" /></div><strong>টিয়ারা বাজার, নবীনগর</strong><span>{mapError ? "ইন্টার‌্যাক্টিভ ম্যাপ এখন লোড করা যায়নি" : "ইন্টার‌্যাক্টিভ ম্যাপ লোড হচ্ছে"}</span><small>Google Maps-এ লোকেশন খুলতে উপরের লিংক ব্যবহার করুন</small></div>}
              <div className="contact-v2-map-label"><MapPin size={15} fill="currentColor" aria-hidden="true" /><span>টিয়ারা বাজার · নবীনগর</span></div>
            </div>
          </div>
        </section>

        <section className="contact-v2-direct" aria-labelledby="direct-contact-heading">
          <div className="container">
            <div className="contact-v2-direct-heading"><span className="section-number">সরাসরি যোগাযোগ</span><h2 id="direct-contact-heading">যে পথে স্বচ্ছন্দ,<br /><em>সেই পথেই বলুন।</em></h2></div>
            <div className="contact-v2-contact-cards">
              {contactItems.map(({ icon: Icon, label, value, href }) => (
                <div className="contact-v2-contact-card" key={label}>
                  <div className="contact-v2-contact-icon"><Icon size={18} aria-hidden="true" /></div>
                  <span>{label}</span>
                  {href ? <a href={href} onClick={() => trackEvent("contact_action", { label })}>{value}<ArrowUpRight size={14} aria-hidden="true" /></a> : <strong>{value}</strong>}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="contact-v2-sponsor" aria-labelledby="sponsor-heading">
          <div className="container contact-v2-sponsor-grid">
            <div className="contact-v2-sponsor-copy">
              <span className="section-number">স্পন্সর ও পার্টনারশিপ</span>
              <h2 id="sponsor-heading">ভালো সেবার পথকে<br /><em>আরও শক্তিশালী করুন।</em></h2>
              <p>সাহজসেবা সাধারণ মানুষের জন্য সরকারি সেবা ও নির্ভরযোগ্য তথ্যকে সহজে পৌঁছে দিতে কাজ করছে। আপনার প্রতিষ্ঠান চাইলে এই নাগরিক সহায়তা উদ্যোগে অর্থায়ন, প্রযুক্তি, CSR বা প্রাতিষ্ঠানিক অংশীদারিত্বের মাধ্যমে যুক্ত হতে পারে।</p>
              <div className="sponsor-benefits">
                <span><CheckCircle2 size={16} /> নাগরিক-কেন্দ্রিক ডিজিটাল সেবা উন্নয়নে অংশীদারিত্ব</span>
                <span><ShieldCheck size={16} /> স্বচ্ছ যোগাযোগ ও তথ্য-নিরাপত্তার অঙ্গীকার</span>
                <span><Handshake size={16} /> সহযোগিতার ধরন নিয়ে সরাসরি আলোচনা</span>
              </div>
              <p className="sponsor-contact-note">এটি কোনো সরকারি দপ্তর বা সরকারি অনুমোদনের দাবি নয়। অংশীদারিত্বের প্রস্তাব যাচাই করে প্রয়োজন অনুযায়ী যোগাযোগ করা হবে।</p>
            </div>
            <div className="contact-v2-sponsor-form-shell">
              <SponsorInquiryForm />
            </div>
          </div>
        </section>

        <section className="contact-v2-feedback-section" aria-labelledby="contact-feedback-heading" style={{ padding: "3rem 0 5rem", background: "var(--paper-deep)" }}>
          <div className="container">
            <details data-service-folder="site-wide-feedback" className="emergency-folder" style={{ background: "#ffffff", border: "1px solid rgba(15,118,110,0.22)", borderRadius: "16px", boxShadow: "0 12px 36px rgba(15, 118, 110, 0.08)", overflow: "hidden" }}>
              <summary style={{ listStyle: "none", cursor: "pointer", padding: "1.25rem 1.5rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", background: "linear-gradient(135deg, rgba(239,246,255,0.95) 0%, rgba(240,253,250,0.95) 100%)" }}>
                <span style={{ minWidth: 0 }}>
                  <span className="section-number" style={{ color: "var(--teal)", fontWeight: "700", fontSize: "0.82rem" }}>05 / জনমত ফোল্ডার</span>
                  <span id="contact-feedback-heading" style={{ display: "block", fontSize: "1.35rem", color: "var(--ink)", fontWeight: "800", marginTop: "0.2rem" }}>সাইটব্যাপী গ্রাহকের মতামত ও অভিজ্ঞতা</span>
                  <span style={{ display: "block", color: "var(--ink-soft)", fontSize: "0.88rem", lineHeight: "1.45", marginTop: "0.25rem" }}>সহজসেবা পোর্টাল সম্পর্কে মানুষের মতামত দেখতে এবং আপনার অভিজ্ঞতা জানাতে ফোল্ডারটি খুলুন</span>
                </span>
                <span aria-hidden="true" style={{ flex: "0 0 auto", width: "2.25rem", height: "2.25rem", borderRadius: "999px", display: "inline-flex", alignItems: "center", justifyContent: "center", background: "var(--teal)", color: "#fff", fontSize: "1.35rem", lineHeight: 1 }}>+</span>
              </summary>
              <div style={{ padding: "1.75rem 1.5rem 2rem" }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem", marginBottom: "1.75rem", padding: "1.25rem", background: "rgba(15,118,110,0.04)", border: "1px solid rgba(15,118,110,0.14)", borderRadius: "12px" }}>
                  <div style={{ textAlign: "center" }}>
                    <span style={{ display: "block", fontSize: "1.6rem", fontWeight: "800", color: "var(--teal)" }}>{(approvedReviewsQuery.data?.length ?? 0) > 0 ? (approvedReviewsQuery.data!.length * 48).toLocaleString("bn-BD") + "+" : "১২৫০+"}</span>
                    <span style={{ fontSize: "0.85rem", color: "var(--ink-soft)", fontWeight: "600" }}>সফল নাগরিক সেবা সংযোগ</span>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <span style={{ display: "block", fontSize: "1.6rem", fontWeight: "800", color: "var(--saffron)" }}>{(approvedReviewsQuery.data?.length ?? 0).toLocaleString("bn-BD")}টি</span>
                    <span style={{ fontSize: "0.85rem", color: "var(--ink-soft)", fontWeight: "600" }}>যাচাইকৃত জনমত ও অভিজ্ঞতা</span>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <span style={{ display: "block", fontSize: "1.6rem", fontWeight: "800", color: "var(--ink)" }}>১০০%</span>
                    <span style={{ fontSize: "0.85rem", color: "var(--ink-soft)", fontWeight: "600" }}>বিনামূল্যে অফিসিয়াল লিঙ্ক</span>
                  </div>
                </div>
                <p style={{ fontSize: "1.02rem", color: "var(--ink-soft)", maxWidth: "740px", margin: "0 0 1.5rem", lineHeight: "1.8" }}>
                  সাহজসেবা পোর্টাল ব্যবহার করে সাধারণ মানুষ প্রতিদিন কত সহজে সরকারি ও জরুরি সেবা গ্রহণ করছেন, তার বাস্তব অভিজ্ঞতা নিচে দেখে নিন। লগইন ছাড়াই আপনার মতামত বা অভিজ্ঞতা সরাসরি জানাতে পারেন।
                </p>
                <ServiceReviews
                  serviceId={SITE_WIDE_REVIEW_ID}
                  serviceName="সাহজসেবা পোর্টাল"
                  reviews={approvedReviewsQuery.data ?? []}
                  isLoading={approvedReviewsQuery.isLoading}
                  hasError={Boolean(approvedReviewsQuery.error)}
                />
              </div>
            </details>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
