import React from "react";
import SahajHeader from "@/components/SahajHeader";
import SahajFooter from "@/components/SahajFooter";
import SahajCivicChatWidget from "@/components/SahajCivicChatWidget";
import { ShieldAlert, Lock, FileText, CheckCircle2, AlertTriangle, Key } from "lucide-react";

export default function CopyrightSecurityPolicy() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <SahajHeader />
      
      <main className="flex-1 container max-w-4xl py-10 px-4 space-y-8">
        <div className="bg-card border border-border rounded-xl p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center gap-3 text-primary">
            <ShieldAlert className="w-8 h-8" />
            <h1 className="text-2xl sm:text-3xl font-bold">কপিরাইট, ব্র্যান্ড ও অ্যাডমিন নিরাপত্তা নীতি</h1>
          </div>
          <p className="text-muted-foreground leading-relaxed">
            sahajcontact-8xyxsefc.manus.space পোর্টালের সমস্ত স্বত্ব, সোর্স কোড, টেক্সট কন্টেন্ট, ডিজাইন লেআউট এবং লোগো আইনগতভাবে সুরক্ষিত। এই দলিলটি সাইটের মেধাস্বত্ব রক্ষা, অননুমোদিত অনুলিপি প্রতিরোধ এবং অ্যাডমিন অ্যাকাউন্টের সর্বোচ্চ নিরাপত্তা নিশ্চিত করার নির্দেশিকা প্রদান করে।
          </p>
        </div>

        <div className="space-y-6">
          <section className="bg-card border border-border rounded-xl p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" /> ১. মেধাস্বত্ব ও কপিরাইট সুরক্ষা
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              এই ওয়েবসাইটের ইউজার ইন্টারফেস, বাংলা কন্টেন্ট, বাংলা চ্যাটবট স্ক্রিপ্ট, নির্দেশিকা এবং ডাটা স্ট্রাকচার সাহজসেবা (SahajSeva / SahajContact) পোর্টালের মালিকানাধীন। বাংলাদেশ কপিরাইট আইন ও আন্তর্জাতিক মেধাস্বত্ব চুক্তি অনুযায়ী পূর্বানুমতি ছাড়া এই সাইটের কোড, ডিজাইন বা লেখা হুবহু বা আংশিক অনুলিপি করা সম্পূর্ণ নিষিদ্ধ।
            </p>
            <div className="bg-muted/50 p-4 rounded-lg border border-border/50 text-sm space-y-2">
              <p className="font-medium text-foreground">AI বা অটোমেটেড টুল দিয়ে ক্লোন করার বিরুদ্ধে আইনি নোটিশ:</p>
              <p className="text-muted-foreground">
                কোনো ব্যক্তি বা প্রতিষ্ঠান যদি এআই (AI) টুল, স্ক্রিপ্ট বা অন্য কোনো উপায়ে এই সাইটের ডিজাইন বা কন্টাক্ট সিস্টেম হুবহু নকল বা ক্লোন করার চেষ্টা করে, তবে তার বিরুদ্ধে ডিজিটাল নিরাপত্তা আইন এবং কপিরাইট আইনের অধীনে আইনগত ব্যবস্থা নেওয়া হবে।
              </p>
            </div>
          </section>

          <section className="bg-card border border-border rounded-xl p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" /> ২. অ্যাডমিন অ্যাকাউন্ট ও নিয়ন্ত্রণ নিরাপত্তা
            </h2>
            <p className="text-muted-foreground">
              সাইটের সম্পূর্ণ নিয়ন্ত্রণ এবং মালিকানা কেবল নির্ধারিত মূল অ্যাডমিনের হাতে থাকবে। অ্যাকাউন্ট ও সার্ভার সুরক্ষায় নিম্নলিখিত নিয়মগুলো বাধ্যতামূলক:
            </p>
            <ul className="space-y-2 text-muted-foreground list-disc pl-5">
              <li><strong className="text-foreground">অফিশিয়াল account সুরক্ষা:</strong> Admin dashboard-এর জন্য আলাদা site password ব্যবহার করা হয় না। Official Manus account-এর শক্তিশালী পাসওয়ার্ড ও MFA ব্যবহার করুন; sign-in শেষে server-side owner access যাচাই হয়।</li>
              <li><strong className="text-foreground">টু-ফ্যাক্টর অথেন্টিকেশন (2FA):</strong> অ্যাকাউন্টে সর্বদা মাল্টি-ফ্যাক্টর অথেন্টিকেশন বা MFA চালু রাখুন।</li>
              <li><strong className="text-foreground">ব্যক্তিগত তথ্য গোপনীয়তা:</strong> বিকাশ PIN, ব্যাংক পাসওয়ার্ড, OTP বা API সিক্রেট কখনো কারো সাথে শেয়ার করবেন না।</li>
              <li><strong className="text-foreground">নিয়মিত ব্যাকআপ:</strong> প্রতিটি চেকপয়েন্ট এবং গিট ডিপোজিট নিয়মিত সংরক্ষণ করুন।</li>
            </ul>
          </section>

          <section className="bg-card border border-border rounded-xl p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Key className="w-5 h-5 text-primary" /> ৩. পেমেন্ট ও লেনদেন সংক্রান্ত সতর্কতা
            </h2>
            <p className="text-muted-foreground">
              SahajContact বর্তমানে কোনো পেমেন্ট গ্রহণ, লেনদেন যাচাই, রসিদ বা ইনভয়েস প্রদান করে না। এই পোর্টালে কোনো ব্যক্তিগত পেমেন্ট নম্বর, PIN, OTP, ব্যাংক তথ্য বা transaction ID দেবেন না। কোনো সরকারি ফি প্রয়োজন হলে কেবল সংশ্লিষ্ট সরকারি পোর্টালের নির্দেশনা অনুসরণ করুন।
            </p>
          </section>

          <section className="bg-card border border-border rounded-xl p-6 space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" /> ৪. ভায়োলেশন ও রিপোর্ট করার পদ্ধতি
            </h2>
            <p className="text-muted-foreground">
              যদি আপনার নজরে আসে যে অন্য কেউ এই সাইটের ভুয়া বা ক্লোন কপি তৈরি করেছে অথবা প্রতারণা করার চেষ্টা করছে, তবে তাৎক্ষণিকভাবে আমাদের কমপ্লেইন্ট সেল বা অফিসিয়াল অভিযোগ ফর্মে প্রমাণসহ রিপোর্ট করুন।
            </p>
          </section>
        </div>

        <div className="flex justify-center pt-4">
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-lg bg-primary text-primary-foreground px-6 py-3 font-medium hover:bg-primary/95 transition-colors"
          >
            হোমপেজে ফিরে যান
          </a>
        </div>
      </main>

      <SahajFooter />
      <SahajCivicChatWidget />
    </div>
  );
}
