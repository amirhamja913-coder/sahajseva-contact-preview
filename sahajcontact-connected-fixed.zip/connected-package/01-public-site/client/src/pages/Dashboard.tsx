import { startLogin } from "@/const";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, ClipboardList, LogIn, LogOut, ShieldCheck, UserRound } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, loading, error, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen bg-[#f8f4e9] text-[#17343b]">
      <SahajHeader />
      <main className="container py-12 md:py-20">
        <div className="mx-auto max-w-4xl">
          <Link href="/" className="back-link mb-8 inline-flex items-center gap-2">
            <ArrowLeft size={16} aria-hidden="true" /> হোমে ফিরে যান
          </Link>

          <section className="dashboard-hero mb-8">
            <div className="eyebrow"><span className="eyebrow-dot" />ব্যক্তিগত সেবা পথ</div>
            <h1>আপনার <em>সেবা ড্যাশবোর্ড</em></h1>
            <p>লগইন করলে আপনার পরিচয়-সংক্রান্ত account status দেখা যাবে। সাহজসেবা কোনো সরকারি আবেদন বা ব্যক্তিগত service outcome নিজের কাছে সংরক্ষণ করে না।</p>
          </section>

          {loading ? (
            <section className="dashboard-panel" aria-live="polite">
              <div className="dashboard-panel-icon"><UserRound size={22} /></div>
              <h2>অ্যাকাউন্ট যাচাই হচ্ছে…</h2>
              <p>আপনার Manus account-এর session নিরাপদভাবে পরীক্ষা করা হচ্ছে।</p>
            </section>
          ) : isAuthenticated && user ? (
            <div className="dashboard-grid">
              <section className="dashboard-panel dashboard-panel-primary">
                <div className="dashboard-panel-icon"><UserRound size={22} /></div>
                <span className="section-number">০১ / পরিচয়</span>
                <h2>স্বাগতম, {user.name || "সাহজসেবা ব্যবহারকারী"}</h2>
                <p>আপনার Manus OAuth account সফলভাবে সংযুক্ত আছে।</p>
                <dl className="dashboard-details">
                  <div><dt>নাম</dt><dd>{user.name || "তথ্য দেওয়া হয়নি"}</dd></div>
                  <div><dt>ইমেইল</dt><dd>{user.email || "তথ্য দেওয়া হয়নি"}</dd></div>
                  <div><dt>লগইন পদ্ধতি</dt><dd>{user.loginMethod || "Manus OAuth"}</dd></div>
                </dl>
                <Button type="button" variant="outline" onClick={() => void logout()} className="mt-6">
                  <LogOut size={16} aria-hidden="true" /> লগআউট
                </Button>
              </section>

              <section className="dashboard-panel">
                <div className="dashboard-panel-icon"><ShieldCheck size={22} /></div>
                <span className="section-number">০২ / গোপনীয়তা</span>
                <h2>ডেটা ব্যবহারে স্বচ্ছতা</h2>
                <p>অ্যাকাউন্ট সংযোগটি শুধু login identity ও session পরিচালনার জন্য। NID, OTP, PIN, কার্ড তথ্য বা সরকারি সেবার ব্যক্তিগত ফলাফল এখানে চাইবে না।</p>
                <Link href="/privacy-policy" className="support-card-link mt-5 inline-flex">গোপনীয়তা নীতি পড়ুন →</Link>
              </section>

              <section className="dashboard-panel dashboard-panel-wide">
                <div className="dashboard-panel-icon"><ClipboardList size={22} /></div>
                <span className="section-number">০৩ / পরবর্তী পথ</span>
                <h2>সেবা খুঁজে নিন</h2>
                <p>ড্যাশবোর্ডে এখন account status ও privacy guidance রাখা হয়েছে। সরকারি সেবা নিতে সংশ্লিষ্ট official portal-এ সরাসরি যান এবং আবেদন/ফি/ফলাফল সেখানে যাচাই করুন।</p>
                <Link href="/#services" className="support-card-link mt-5 inline-flex">সেবা directory খুলুন →</Link>
              </section>
            </div>
          ) : (
            <section className="dashboard-panel dashboard-panel-login">
              <div className="dashboard-panel-icon"><LogIn size={22} /></div>
              <span className="section-number">০১ / নিরাপদ প্রবেশ</span>
              <h2>ড্যাশবোর্ড দেখতে লগইন করুন</h2>
              <p>Manus OAuth-এর মাধ্যমে login করলে account identity নিরাপদে যাচাই হবে। সাহজসেবা আপনার পাসওয়ার্ড বা OAuth credential দেখে না।</p>
              {error ? <p className="dashboard-error" role="alert">লগইন status যাচাই করা যায়নি। আবার চেষ্টা করুন।</p> : null}
              <Button type="button" onClick={() => startLogin()} className="mt-6">
                <LogIn size={16} aria-hidden="true" /> Manus দিয়ে লগইন
              </Button>
            </section>
          )}
        </div>
      </main>
      <SahajFooter />
    </div>
  );
}
