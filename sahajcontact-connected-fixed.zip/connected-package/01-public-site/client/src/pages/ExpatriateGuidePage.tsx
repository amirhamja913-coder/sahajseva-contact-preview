import SahajHeader from "@/components/SahajHeader";
import SahajFooter from "@/components/SahajFooter";
import { Link } from "wouter";
import { ArrowLeft, CheckCircle2, ExternalLink, Mail, MapPin, Phone, ShieldAlert } from "lucide-react";
import { expatGuidelines } from "@/components/UtilityAndExpatriateSections";
import { trackEvent, trackOutbound } from "@/lib/analytics";

type MissionContact = {
  country: "USA" | "Saudi Arabia";
  city: string;
  mission: string;
  address: string;
  phones: Array<{ label: string; number: string; tel: string; urgent?: boolean }>;
  emails: string[];
  source: string;
  sourceLabel: string;
};

const missionContacts: MissionContact[] = [
  {
    country: "USA",
    city: "Washington, DC",
    mission: "Embassy of Bangladesh",
    address: "3510 International Drive NW, Washington, DC 20008, U.S.A.",
    phones: [{ label: "মিশন ফোন", number: "+1 202-244-0183", tel: "+12022440183", urgent: true }],
    emails: ["mission.washington@mofa.gov.bd"],
    source: "https://washington.mofa.gov.bd/pages/static-pages/695266a835ce18e1c05aa9e7",
    sourceLabel: "Washington mission contact",
  },
  {
    country: "USA",
    city: "New York",
    mission: "Consulate General of Bangladesh",
    address: "31-10 37th Avenue, Suite 201, Long Island City, NY 11101",
    phones: [
      { label: "মেইন ফোন", number: "+1 212-599-6767", tel: "+12125996767", urgent: true },
      { label: "অফিস-পরবর্তী জরুরি", number: "+1 646-645-7242", tel: "+16466457242", urgent: true },
    ],
    emails: ["contact@bdcgny.org"],
    source: "https://www.bdcgny.org/phone-fax",
    sourceLabel: "New York consulate contact",
  },
  {
    country: "USA",
    city: "Los Angeles",
    mission: "Consulate General of Bangladesh",
    address: "501 South Fairfax Ave, Los Angeles, CA 90036",
    phones: [{ label: "কনস্যুলেট ফোন", number: "+1 323-381-9157", tel: "+13233819157", urgent: true }],
    emails: ["bcgla09@gmail.com", "mission.losangeles@mofa.gov.bd"],
    source: "https://losangeles.mofa.gov.bd/pages/static-pages/695266b835ce18e1c05aaf72",
    sourceLabel: "Los Angeles consulate contact",
  },
  {
    country: "Saudi Arabia",
    city: "Riyadh",
    mission: "Embassy of Bangladesh",
    address: "8039 Dareen Street, Diplomatic Quarter, Riyadh",
    phones: [
      { label: "মেইন ফোন", number: "+966 11 419 5300", tel: "+966114195300", urgent: true },
      { label: "Diplomatic toll-free", number: "+966 800 100 0124", tel: "+9668001000124", urgent: true },
      { label: "Labour Welfare toll-free", number: "+966 800 100 0125", tel: "+9668001000125", urgent: true },
      { label: "Passport & Visa toll-free", number: "+966 800 100 0126", tel: "+9668001000126", urgent: true },
    ],
    emails: ["mission.riyadh@mofa.gov.bd"],
    source: "https://www.bangladeshembassy.org.sa/contact.html",
    sourceLabel: "Riyadh embassy contact",
  },
  {
    country: "Saudi Arabia",
    city: "Jeddah",
    mission: "Consulate General of Bangladesh",
    address: "বর্তমান ঠিকানা ও অফিস সময় অফিসিয়াল মিশন ওয়েবসাইটে যাচাই করুন।",
    phones: [
      { label: "Consular wing", number: "+966 508 636 943", tel: "+966508636943" },
      { label: "Head of Chancery", number: "+966 543 974 848", tel: "+966543974848" },
      { label: "Probashi welfare", number: "+966 501 365 198", tel: "+966501365198" },
    ],
    emails: ["consular.jeddah@mofa.gov.bd", "hoc.jeddah@mofa.gov.bd", "counselorjeddah@probashi.gov.bd"],
    source: "https://jeddah.mofa.gov.bd/",
    sourceLabel: "Jeddah mission contact",
  },
];

function MissionCard({ contact }: { contact: MissionContact }) {
  return (
    <article className="rounded-2xl border border-slate-700/80 bg-slate-800/90 p-5 shadow-xl shadow-slate-950/20 sm:p-6">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <span className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-400">{contact.country}</span>
          <h2 className="mt-1 text-xl font-extrabold text-white">{contact.city}</h2>
          <p className="mt-1 text-sm text-slate-300">{contact.mission}</p>
        </div>
        <span className="rounded-full border border-emerald-400/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300">অফিসিয়াল তথ্য</span>
      </div>

      <div className="space-y-3 text-sm text-slate-300">
        <div className="flex items-start gap-2.5">
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-sky-300" aria-hidden="true" />
          <span>{contact.address}</span>
        </div>

        <div className="space-y-2 border-t border-slate-700/70 pt-3">
          {contact.phones.map((phone) => (
            <a
              key={phone.tel}
              href={`tel:${phone.tel}`}
              onClick={() => trackEvent("embassy_call_click", { country: contact.country, city: contact.city, phone_label: phone.label })}
              className="flex min-h-11 items-center justify-between gap-3 rounded-xl border border-emerald-400/20 bg-emerald-950/30 px-3 py-2.5 text-emerald-200 transition hover:border-emerald-300/50 hover:bg-emerald-900/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300"
              aria-label={`${contact.city} ${phone.label}: ${phone.number} — কল করুন`}
            >
              <span className="flex items-center gap-2">
                <Phone className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span><span className="block text-[11px] text-emerald-300/80">{phone.label}{phone.urgent ? " • জরুরি প্রয়োজনে" : ""}</span><span className="font-bold tracking-wide">{phone.number}</span></span>
              </span>
              <span className="rounded-lg bg-emerald-500 px-2.5 py-1 text-xs font-extrabold text-slate-950">কল</span>
            </a>
          ))}
        </div>

        <div className="flex items-start gap-2.5 border-t border-slate-700/70 pt-3">
          <Mail className="mt-0.5 h-4 w-4 shrink-0 text-sky-300" aria-hidden="true" />
          <div className="space-y-1">
            {contact.emails.map((email) => <a key={email} href={`mailto:${email}`} className="block break-all text-sky-200 underline-offset-2 hover:underline">{email}</a>)}
          </div>
        </div>
      </div>

      <a
        href={contact.source}
        target="_blank"
        rel="noopener noreferrer"
        data-utm-campaign="embassy_contact"
        onClick={() => trackOutbound(`${contact.city} official contact`, contact.source, "embassy_contact")}
        className="mt-5 inline-flex min-h-10 items-center gap-2 rounded-xl border border-slate-600 bg-slate-900/70 px-3.5 py-2 text-xs font-bold text-slate-200 transition hover:border-sky-300/50 hover:text-sky-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300"
      >
        অফিসিয়াল পেজ যাচাই করুন <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
      </a>
    </article>
  );
}

export default function ExpatriateGuidePage() {
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans public-civic-page public-expat-page">
      <SahajHeader />

      <main className="flex-1">
        <section className="border-b border-sky-900/50 bg-gradient-to-br from-slate-950 via-sky-950/60 to-emerald-950/40 px-4 py-10 sm:py-14">
          <div className="container mx-auto max-w-6xl">
            <Link href="/" className="mb-5 inline-flex items-center gap-2 text-sm font-medium text-emerald-300 hover:text-emerald-200">
              <ArrowLeft className="h-4 w-4" /> হোমপেজে ফিরে যান
            </Link>
            <div className="max-w-3xl">
              <div className="mb-3 inline-flex rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-300">🌍 প্রবাসী কর্নার</div>
              <h1 className="text-3xl font-extrabold leading-tight text-white sm:text-5xl">জরুরি প্রয়োজনে সরাসরি কল করুন</h1>
              <p className="mt-4 text-base leading-relaxed text-slate-300 sm:text-lg">USA ও Saudi Arabia-তে থাকা বাংলাদেশি ভাই-বোনদের জন্য দূতাবাস ও কনস্যুলেটের যাচাই করা যোগাযোগের পথ এক জায়গায়। ফোন নম্বরে চাপ দিলেই মোবাইল থেকে কল শুরু হবে।</p>
              <p className="mt-3 text-sm leading-relaxed text-amber-200/90">যোগাযোগের আগে অফিসিয়াল পেজে নম্বর, অফিস সময় ও জরুরি নির্দেশনা আবার যাচাই করুন। SahajContact কোনো কনস্যুলার সেবা বা সরকারি প্রতিনিধিত্ব করে না।</p>
            </div>
          </div>
        </section>

        <section className="container mx-auto max-w-6xl px-4 py-8 sm:py-12" aria-labelledby="mission-directory-title">
          <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-sky-300">Mission directory</span>
              <h2 id="mission-directory-title" className="mt-1 text-2xl font-extrabold text-white sm:text-3xl">USA ও Saudi দূতাবাস গাইড</h2>
            </div>
            <span className="text-sm text-slate-400">সর্বশেষ যাচাই: ১৮ আগস্ট ২০২৬</span>
          </div>
          <div className="grid gap-5 md:grid-cols-2">
            {missionContacts.map((contact) => <MissionCard key={`${contact.country}-${contact.city}`} contact={contact} />)}
          </div>
        </section>

        <section className="container mx-auto max-w-6xl px-4 pb-8 sm:pb-12" aria-labelledby="guideline-title">
          <div className="mb-6 rounded-2xl border border-emerald-400/20 bg-emerald-950/20 p-5 sm:p-6">
            <div className="flex items-start gap-3"><ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-emerald-300" aria-hidden="true" /><div><h2 id="guideline-title" className="text-xl font-extrabold text-white sm:text-2xl">প্রবাসীদের জন্য ৫টি জরুরি গাইডলাইন</h2><p className="mt-2 text-sm leading-relaxed text-slate-300">শুধু অফিসিয়াল ওয়েবসাইট ব্যবহার করুন, গুরুত্বপূর্ণ কাগজ নিরাপদে রাখুন, বৈধ পথে রেমিট্যান্স পাঠান এবং বিপদে দূতাবাসে যোগাযোগ করুন।</p></div></div>
          </div>
          <div className="space-y-5">
            {expatGuidelines.map((guideline) => (
              <article className="rounded-2xl border border-slate-700/80 bg-slate-800/90 p-5 shadow-lg sm:p-7" key={guideline.number}>
                <div className="flex items-center gap-3"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-500 text-lg font-bold text-slate-950">{guideline.number}</div><div><span className="block text-xs font-semibold uppercase tracking-wider text-emerald-400">গাইডলাইন {guideline.number}</span><h3 className="text-xl font-bold text-white">{guideline.titleBn}</h3></div></div>
                <div className="mt-4 space-y-3 text-slate-300"><div className="flex items-start gap-3 rounded-xl border border-emerald-500/20 bg-emerald-950/30 p-3.5"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-400" /><span className="text-sm sm:text-base">{guideline.safeBn}</span></div>{guideline.cautionBn && <div className="flex items-start gap-3 rounded-xl border border-rose-500/20 bg-rose-950/30 p-3.5"><ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-rose-400" /><span className="text-sm sm:text-base">{guideline.cautionBn}</span></div>}</div>
                <div className="mt-3 rounded-xl border border-slate-700/60 bg-slate-900/80 p-3.5 text-sm font-medium text-emerald-300">👉 {guideline.noteBn}</div>
              </article>
            ))}
          </div>
        </section>

        <section className="container mx-auto max-w-6xl px-4 pb-12 sm:pb-16">
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5 sm:p-7">
            <div className="flex items-start gap-3"><ShieldAlert className="mt-0.5 h-6 w-6 shrink-0 text-amber-400" aria-hidden="true" /><div><h2 className="text-xl font-bold text-amber-300">সতর্কবার্তা</h2><p className="mt-2 leading-relaxed text-slate-300">SahajContact একটি তথ্যমূলক পোর্টাল। আমরা কোনো ফি নিই না, আবেদন করি না এবং কোনো ব্যক্তিগত তথ্য সংগ্রহ করি না। সকল সেবা পেতে সংশ্লিষ্ট অফিসিয়াল লিংক ব্যবহার করুন।</p></div></div>
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-3"><Link href="/#expatriates" className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-sm font-bold text-white transition hover:bg-emerald-500">দেশভিত্তিক গাইড দেখুন <ExternalLink className="h-4 w-4" /></Link><Link href="/" className="inline-flex min-h-11 items-center rounded-xl border border-slate-700 bg-slate-800 px-5 py-3 text-sm font-bold text-slate-200 transition hover:bg-slate-700">হোম পেজে ফিরে যান</Link></div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
