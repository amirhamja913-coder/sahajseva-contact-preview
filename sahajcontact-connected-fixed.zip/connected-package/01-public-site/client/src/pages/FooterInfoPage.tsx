import { ArrowLeft, ArrowUpRight, Baby, CircleCheck, HeartHandshake, UsersRound, Wheat } from "lucide-react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";

export type FooterPageKey =
  | "campaign"
  | "help"
  | "complaint"
  | "about"
  | "careers"
  | "supplier"
  | "merchant"
  | "digital-services"
  | "terms"
  | "faq"
  | "security-advice"
  | "privacy-notice"
  | "future-plan"
  | "public-guidance";

type FooterPageContent = {
  eyebrow: string;
  title: string;
  summary: string;
  points: string[];
};

/** Bengali source content is kept as the default language and remains part of the public contract. */
export const footerPageContent: Record<FooterPageKey, FooterPageContent> = {
  campaign: {
    eyebrow: "সেবা / ক্যাম্পেইন",
    title: "সবার জন্য সহজ সেবা",
    summary: "নাগরিকদের প্রয়োজনীয় সেবা সম্পর্কে সচেতনতা বাড়াতে এই তথ্যপাতায় প্রাসঙ্গিক দিকনির্দেশনা দেওয়া হয়। কোনো সেবা, চুক্তি বা ফলাফলের দাবি এই পেজ থেকে তৈরি হয় না।",
    points: ["সেবা সম্পর্কে সহজ ভাষায় তথ্য", "স্থানীয় মানুষের কাছে সহায়তার বার্তা", "স্বচ্ছতা ও দায়িত্বশীল যোগাযোগ"],
  },
  help: {
    eyebrow: "সেবা / হেল্প",
    title: "আপনার প্রশ্নের সহজ উত্তর",
    summary: "কোনো সরকারি সেবা শুরু করার আগে কী লাগবে, কোথায় যেতে হবে বা কীভাবে আবেদন করবেন—এই পেজে ধাপে ধাপে সহায়তার কাঠামো দেওয়া হবে।",
    points: ["সেবা বাছাইয়ে সহায়তা", "আবেদনের প্রস্তুতি তালিকা", "পোর্টালের যোগাযোগ ফর্মের নিরাপদ পথ"],
  },
  complaint: {
    eyebrow: "সেবা / কমপ্লেইন্ট সেল",
    title: "আপনার অভিযোগ আমাদের কাছে গুরুত্বপূর্ণ",
    summary: "সেবা গ্রহণে সমস্যা হলে সংশ্লিষ্ট সরকারি কর্তৃপক্ষের অফিসিয়াল অভিযোগ চ্যানেল ব্যবহার করুন। SahajContact কোনো সরকারি অভিযোগ নিষ্পত্তি বা অগ্রগতি জানানোর প্রতিশ্রুতি দেয় না।",
    points: ["সমস্যার সংক্ষিপ্ত বিবরণ প্রস্তুত করুন", "সংশ্লিষ্ট অফিসিয়াল অভিযোগ চ্যানেল যাচাই করুন", "রেফারেন্স নম্বর নিজে সংরক্ষণ করুন"],
  },
  about: {
    eyebrow: "কোম্পানি / আমাদের সম্পর্কে",
    title: "💞 এডমিনের কিছু কথা ও আমার মিনতি 💞",
    summary: "আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহ।\n\nনিজের চারপাশে মানুষকে এনআইডি, ভাতা, পাসপোর্ট ও অন্যান্য সরকারি সেবার জন্য অপ্রয়োজনীয় হয়রানি পোহাতে দেখেছি। প্রবাসী ভাইয়েরাও দূরদেশে বসে পুলিশ ক্লিয়ারেন্স বা পাসপোর্ট রিনিউয়ের জন্য অসহায় বোধ করেন। এই অভিজ্ঞতা থেকেই SahajContact-এর পথচলা।\n\nআমাদের লক্ষ্য ৩টি:\n• গ্রামের মানুষের জন্য: ঘরে বসেই সরকারি সেবার অফিসিয়াল লিংক পাওয়া।\n• প্রবাসীদের জন্য: প্রয়োজনীয় দূতাবাস ও সরকারি সেবার পথ এক জায়গায় রাখা।\n• বিদেশি বন্ধুদের জন্য: বাংলাদেশকে জানার সহজ ও নির্ভরযোগ্য গাইড দেওয়া।\n\nকোনো ভুল-ত্রুটি চোখে পড়লে, নতুন কোনো লিংক লাগলে বা পরামর্শ থাকলে অফিসিয়াল যোগাযোগ ফর্মে জানান।\n\nআপনার পাশে আছি, আপনার সেবায় আছি।\n\nভালোবাসা ও দোয়া সহ,\nSahajContact টিম",
    points: [
      "গ্রামের মানুষের জন্য সহজ সেবা ও অফিসিয়াল লিংক",
      "প্রবাসীদের জন্য বিশ্বব্যাপী দূতাবাস ও সেবা সহায়তা",
      "অফিসিয়াল যোগাযোগ ফর্মে নিরাপদে বার্তা পাঠানোর ব্যবস্থা",
    ],
  },
  careers: {
    eyebrow: "কোম্পানি / ক্যারিয়ার",
    title: "আমাদের সঙ্গে কাজ করুন",
    summary: "বর্তমানে SahajContact কোনো খালি পদ বা নিয়োগ আবেদন গ্রহণ করছে না। ভবিষ্যতে যাচাইকৃত সুযোগ থাকলে এই পেজে স্পষ্টভাবে প্রকাশ করা হবে।",
    points: ["কাস্টমার সাপোর্ট", "ডিজিটাল সেবা সহায়তা", "কনটেন্ট ও কমিউনিটি কাজ"],
  },
  supplier: {
    eyebrow: "ব্যবসা / সাপ্লায়ার",
    title: "সাপ্লায়ার হোন",
    summary: "সরবরাহকারী বা সেবা অংশীদার সম্পর্কিত কোনো খোলা আবেদন বর্তমানে চালু নেই। কোনো প্রস্তাব নিজে থেকে অংশীদারিত্ব, অনুমোদন বা প্রকাশ্য তালিকাভুক্তি তৈরি করে না।",
    points: ["স্বচ্ছ অংশীদারিত্ব", "যাচাইযোগ্য ব্যবসায়িক তথ্য", "নিরাপদ যোগাযোগ ব্যবস্থা"],
  },
  merchant: {
    eyebrow: "ব্যবসা / মার্চেন্ট",
    title: "মার্চেন্ট হোন",
    summary: "মার্চেন্ট অনবোর্ডিং, বিক্রয়, বিজ্ঞাপন প্যাকেজ বা পেমেন্ট ব্যবস্থা বর্তমানে চালু নেই। যাচাইকৃত ভবিষ্যৎ কর্মসূচি হলে তার শর্ত আলাদা করে প্রকাশ করা হবে।",
    points: ["ব্যবসার পরিচিতি প্রকাশ", "সেবা ও পণ্যের তথ্য সাজানো", "গ্রাহকের সঙ্গে সহজ যোগাযোগ"],
  },
  "digital-services": {
    eyebrow: "ব্যবসা / ডিজিটাল সার্ভিস",
    title: "ডিজিটাল সেবা সহায়তা",
    summary: "ওয়েবসাইট, SEO ও ডিজিটাল মার্কেটিং সম্পর্কে এই তথ্যপাতায় প্রাথমিক ধারণা দেওয়া হয়েছে। এটি কোনো সেবা-চুক্তি, মূল্যতালিকা বা পেমেন্ট প্রস্তাব নয়।",
    points: ["ওয়েবসাইট তৈরি", "সার্চে দৃশ্যমানতা বাড়ানোর পরিকল্পনা", "ডিজিটাল প্রচারের পরামর্শ"],
  },
  terms: {
    eyebrow: "অন্যান্য / শর্তাবলী",
    title: "ব্যবহারের শর্তাবলী",
    summary: "এই তথ্যপাতায় সাইট ব্যবহার, সেবা-দিকনির্দেশনা ও যোগাযোগের সাধারণ নীতিগুলো ব্যাখ্যা করা হয়েছে। এটি আইনগত পরামর্শ, সেবা-চুক্তি বা সরকারি সিদ্ধান্তের নিশ্চয়তা নয়।",
    points: ["সেবা ফি ও সরকারি ফি আলাদা", "ব্যবহারকারীর দেওয়া তথ্য সঠিক হওয়া প্রয়োজন", "সরকারি সিদ্ধান্তের নিশ্চয়তা প্রদান করা হয় না"],
  },
  faq: {
    eyebrow: "অন্যান্য / সাধারণ জিজ্ঞাসা",
    title: "সাধারণ জিজ্ঞাসার উত্তর",
    summary: "সেবা, ফি, সময় এবং প্রয়োজনীয় কাগজপত্র নিয়ে ব্যবহারকারীদের সাধারণ প্রশ্নের উত্তর এই পেজে ধীরে ধীরে যুক্ত করা হবে।",
    points: ["কোন তথ্য ও সরকারি লিংক পাওয়া যায়?", "কীভাবে অফিসিয়াল সেবা-পথ ব্যবহার করবেন?", "সরকারি ফি কোথায় যাচাই করবেন?"],
  },
  "security-advice": {
    eyebrow: "অন্যান্য / নিরাপত্তা পরামর্শ",
    title: "নিরাপদে সেবা নিন",
    summary: "অনলাইনে সেবা নেওয়ার সময় OTP, PIN, পাসওয়ার্ড এবং অপ্রয়োজনীয় ব্যক্তিগত তথ্য কাউকে না দেওয়ার বিষয়ে এই পেজে পরামর্শ দেওয়া হবে।",
    points: ["OTP ও PIN কখনো শেয়ার করবেন না", "অচেনা লিংকে পেমেন্ট করবেন না", "প্রয়োজনে অফিসিয়াল উৎস যাচাই করুন"],
  },
  "privacy-notice": {
    eyebrow: "অন্যান্য / প্রাইভেসি নোটিশ",
    title: "আপনার তথ্যের গোপনীয়তা",
    summary: "ফর্ম ও যোগাযোগের সময় প্রয়োজনের অতিরিক্ত তথ্য না দেওয়ার অনুরোধ করা হয়। এই নোটিশে তথ্য ব্যবহারের সাধারণ ন্যূনতম নীতি দেওয়া হয়েছে; কোনো ব্যক্তিগত নথি, OTP বা পেমেন্ট তথ্য পাঠাবেন না।",
    points: ["প্রয়োজনীয় তথ্যই সংগ্রহ করার নীতি", "ব্যক্তিগত তথ্য বিক্রি না করার অঙ্গীকার", "তথ্য ব্যবহারের বিষয়ে স্বচ্ছ যোগাযোগ"],
  },
  "future-plan": {
    eyebrow: "আমাদের পরবর্তী পরিকল্পনা",
    title: "নারী, শিশু, কৃষক ও সাধারণ মানুষের জন্য আমাদের পরবর্তী পরিকল্পনা",
    summary: "নারী, শিশু, কৃষক এবং সাধারণ মানুষের সামাজিক সুরক্ষা, অধিকার রক্ষা ও সচেতনতা বৃদ্ধির লক্ষ্যে আমাদের ভবিষ্যৎ পরিকল্পনা ও জনকল্যাণমূলক উদ্যোগসমূহ।",
    points: [
      "বাল্যবিবাহ প্রতিরোধ ও আইনি সচেতনতা বৃদ্ধি",
      "নারীর শিক্ষা, অধিকার ও অর্থনৈতিক ভূমিকা",
      "শিশু সুরক্ষা ও নিরাপদ বেড়ে ওঠার পরিবেশ",
      "কৃষকের ন্যায্য সেবা, তথ্য ও আবেদন সহায়তা",
      "সাধারণ মানুষের ডিজিটাল সেবা ও অধিকার",
    ],
  },
  "public-guidance": {
    eyebrow: "নাগরিক গাইডলাইন",
    title: "সাধারণ মানুষের জন্য নির্দেশনা",
    summary: "SahajContact চায় প্রতিটি মানুষ যেন হয়রানি ছাড়া দ্রুত সেবা পায়। সেবা গ্রহণের ৫টি সহজ ধাপ, প্রতারণা থেকে বাঁচার উপায় এবং আমাদের অঙ্গীকার।",
    points: ["৫টি সহজ ধাপে সেবা গ্রহণ", "যোগাযোগ ফর্মে তথ্যভিত্তিক প্রশ্ন পাঠানোর পথ", "প্রতারণা ও দালাল থেকে সাবধানতা", "ডিজিটাল সচেতনতা ও অধিকার"],
  },
};

const footerPageContentEn: Record<FooterPageKey, FooterPageContent> = {
  campaign: {
    eyebrow: "Services / Campaigns",
    title: "Simple services for everyone",
    summary: "This informational page offers relevant guidance for awareness about essential civic services. It does not create a service, contract, or claimed outcome.",
    points: ["Clear information about services", "Helpful messages for local communities", "Transparent and responsible communication"],
  },
  help: {
    eyebrow: "Services / Help",
    title: "Simple answers to your questions",
    summary: "Before starting a government service, learn what you need, where to go, and how to apply. This page will provide step-by-step guidance.",
    points: ["Help choosing the right service", "Application preparation checklist", "A safe route through the portal contact form"],
  },
  complaint: {
    eyebrow: "Services / Complaint Cell",
    title: "Your complaint matters to us",
    summary: "If you face a service problem, use the responsible public authority’s official complaint channel. SahajContact does not resolve official complaints or promise progress updates.",
    points: ["Prepare a concise description of the issue", "Verify the relevant official complaint channel", "Keep your own reference number"],
  },
  about: {
    eyebrow: "Company / About Us",
    title: "💞 A personal note from the Admin 💞",
    summary: "Assalamu Alaikum Warahmatullahi Wabarakatuh.\n\nI have seen people around me face unnecessary harassment when seeking NIDs, allowances, passports, and other government services. Expatriate Bangladeshis can also feel helpless abroad when they need police clearance or passport renewal. These experiences inspired SahajContact.\n\nOur three goals:\n• For rural citizens: Find official government service links from home.\n• For expatriates: Keep essential embassy and government service pathways in one place.\n• For international visitors: Offer a simple and reliable guide to Bangladesh.\n\nIf you find an error, need a new link, or have feedback, please use our official contact form.\n\nStanding by you and serving you.\n\nWith love and prayers,\nSahajContact Team",
    points: ["Accessible civic services and official links for rural citizens", "Embassy and service guidance for expatriate Bangladeshis", "A secure way to send a message through the official contact form"],
  },
  careers: {
    eyebrow: "Company / Careers",
    title: "Work with us",
    summary: "SahajContact is not currently accepting vacancy or recruitment applications. Any verified future opportunity will be clearly published on this page.",
    points: ["Customer support", "Digital service assistance", "Content and community work"],
  },
  supplier: {
    eyebrow: "Business / Suppliers",
    title: "Become a supplier",
    summary: "No supplier or service-partner intake is currently open. A proposal does not by itself create a partnership, approval, or public listing.",
    points: ["Transparent partnerships", "Verifiable business information", "Secure communication channels"],
  },
  merchant: {
    eyebrow: "Business / Merchants",
    title: "Become a merchant",
    summary: "Merchant onboarding, sales, advertising packages, and payment collection are not currently active. Any verified future programme will publish its terms separately.",
    points: ["Publish your business profile", "Organize service and product information", "Make it easier for customers to contact you"],
  },
  "digital-services": {
    eyebrow: "Business / Digital Services",
    title: "Digital service support",
    summary: "This informational page provides an initial overview of websites, SEO, and digital marketing. It is not a service contract, price list, or payment offer.",
    points: ["Website development", "Plans to improve search visibility", "Digital promotion guidance"],
  },
  terms: {
    eyebrow: "Other / Terms",
    title: "Terms of use",
    summary: "This page explains general principles for using the site, receiving guidance, and communicating with us. It is not legal advice, a service contract, or a guarantee of a public decision.",
    points: ["Service fees and government fees are separate", "Information supplied by users should be accurate", "No government decision is guaranteed"],
  },
  faq: {
    eyebrow: "Other / FAQ",
    title: "Answers to common questions",
    summary: "Answers about services, fees, timing, and required documents will be added to this page gradually.",
    points: ["What information and official links are available?", "How do I use an official service pathway?", "Where can I verify government fees?"],
  },
  "security-advice": {
    eyebrow: "Other / Security Advice",
    title: "Use services safely",
    summary: "This page will explain why you should never share OTPs, PINs, passwords, or unnecessary personal information while using online services.",
    points: ["Never share an OTP or PIN", "Do not pay through an unfamiliar link", "Verify information with an official source when needed"],
  },
  "privacy-notice": {
    eyebrow: "Other / Privacy Notice",
    title: "Your information and privacy",
    summary: "Please do not provide more information than necessary in forms or messages. This notice sets out the minimum general approach; do not send personal documents, OTPs, or payment information.",
    points: ["Collect only information that is needed", "A commitment not to sell personal information", "Transparent communication about data use"],
  },
  "future-plan": {
    eyebrow: "Future Vision",
    title: "Our action plan for women, children, farmers, and citizens",
    summary: "Our future plans and public-interest initiatives focus on social protection, rights, and awareness for women, children, farmers, and the wider community.",
    points: ["Preventing child marriage and improving legal awareness", "Women’s education, rights, and economic participation", "Child protection and safe development", "Fair agricultural services, information, and application guidance", "Digital services and rights for all citizens"],
  },
  "public-guidance": {
    eyebrow: "Citizen Guide",
    title: "Guidance for everyone",
    summary: "SahajContact wants everyone to receive services quickly and without harassment. Learn five simple steps, ways to avoid fraud, and our commitment to citizens.",
    points: ["Five simple steps to receive a service", "Information-based guidance through the portal contact form", "Protection from fraud and middlemen", "Digital awareness and citizen rights"],
  },
};

type PlanItem = { lead: string; text: string };
type PlanSection = { label: string; title: string; description: string; items: PlanItem[] };

const futurePlanSections: Record<"BN" | "EN", PlanSection[]> = {
  BN: [
    {
      label: "১. নারীদের জন্য আমাদের ভূমিকা",
      title: "নারীদের ক্ষমতায়ন ও নিরাপত্তা",
      description: "নারীদের ক্ষমতায়ন ও নিরাপত্তাকে আমরা সর্বোচ্চ গুরুত্ব দিই। সমাজের প্রতিটি ক্ষেত্রে তাদের অংশগ্রহণ নিশ্চিত করতে আমাদের পরিকল্পনাগুলো সাজানো হয়েছে:",
      items: [
        { lead: "২৪ ঘণ্টা জরুরি সাপোর্ট", text: "হয়রানি, সহিংসতা বা আইনি সহায়তা প্রয়োজনে দ্রুত সংযোগের ব্যবস্থা।" },
        { lead: "দক্ষতা উন্নয়ন", text: "ফ্রিল্যান্সিং, উদ্যোক্তা ও ডিজিটাল সেবার উপর বিনামূল্যে প্রশিক্ষণ ও রিসোর্স।" },
        { lead: "স্বাস্থ্য সেবা তথ্য", text: "মা ও শিশু স্বাস্থ্য, নারী স্বাস্থ্য বিষয়ক নির্ভরযোগ্য তথ্য ও হেল্পলাইন।" },
      ],
    },
    {
      label: "২. শিশুদের জন্য আমাদের ভূমিকা",
      title: "শিশুর সুরক্ষা ও নিরাপদ ভবিষ্যৎ",
      description: "আমাদের ভবিষ্যৎ শিশুদের নিরাপদ ও শিক্ষিত করে তোলা আমাদের নৈতিক দায়িত্ব। শিশুদের জন্য আমাদের পরিকল্পনা:",
      items: [
        { lead: "শিশু সুরক্ষা হেল্পডেস্ক", text: "শিশু নির্যাতন, নিখোঁজ বা শিক্ষা সংক্রান্ত সমস্যায় দ্রুত রিপোর্ট ও সহায়তা।" },
        { lead: "ডিজিটাল শিক্ষা", text: "বিনামূল্যে অনলাইন লার্নিং রিসোর্স ও স্কুল ভর্তি তথ্য সহজলভ্য করা।" },
        { lead: "সচেতনতা", text: "শিশু অধিকার ও সাইবার নিরাপত্তা নিয়ে অভিভাবকদের জন্য গাইডলাইন।" },
      ],
    },
    {
      label: "৩. কৃষকদের জন্য আমাদের ভূমিকা",
      title: "কৃষকের অধিকার ও সহজ কৃষি সেবা",
      description: "দেশের খাদ্যনিরাপত্তায় কৃষকদের অবদান গুরুত্বপূর্ণ। কৃষি-সংক্রান্ত সরকারি তথ্য, আবেদন ও সহায়তা যেন সহজে পাওয়া যায়—এ জন্য আমরা নির্ভরযোগ্য উৎসে পৌঁছানোর পথ দেখাব।",
      items: [
        { lead: "সেবা পাওয়ার সমান সুযোগ", text: "কৃষি নিবন্ধন, সরকারি সহায়তা ও প্রয়োজনীয় আবেদনের তথ্য সহজ ভাষায় খুঁজে পাওয়া।" },
        { lead: "স্বচ্ছ আবেদন সহায়তা", text: "অফিসিয়াল লিংক, প্রয়োজনীয় কাগজপত্র ও আবেদনের অগ্রগতি সংরক্ষণের বিষয়ে দিকনির্দেশনা।" },
        { lead: "তথ্য ও অভিযোগের পথ", text: "কৃষি পরামর্শ, আবহাওয়া ও সরকারি সহায়তা সংক্রান্ত তথ্যের জন্য সংশ্লিষ্ট অফিসিয়াল উৎস যাচাই করা।" },
      ],
    },
    {
      label: "৪. সাধারণ মানুষের জন্য আমাদের ভূমিকা",
      title: "সবার জন্য সহজ সেবা",
      description: "সবার জন্য সমান সুযোগ ও সহজ সেবা নিশ্চিত করাই আমাদের অঙ্গীকার। সাধারণ নাগরিকদের দৈনন্দিন নাগরিক জীবন সহজ করতে আমাদের উদ্যোগ:",
      items: [
        { lead: "ওয়ান-ক্লিক সেবা", text: "সরকারি-বেসরকারি সেবা, হাসপাতাল, আইনি সহায়তা এক জায়গায়।" },
        { lead: "দ্রুত কনট্যাক্ট", text: "প্রয়োজনের সময় ১ ক্লিকেই সঠিক মানুষের সাথে যোগাযোগ।" },
        { lead: "সম্প্রদায় সহায়তা", text: "স্থানীয় NGO ও স্বেচ্ছাসেবী সংগঠনের সাথে যুক্ত করে সহায়তা পৌঁছে দেওয়া।" },
      ],
    },
  ],
  EN: [
    {
      label: "1. Our role for women",
      title: "Women’s empowerment and safety",
      description: "We give the highest priority to women’s empowerment and safety. Our plans are designed to support their participation in every part of society:",
      items: [
        { lead: "24-hour emergency support", text: "A rapid connection point for harassment, violence, or urgent legal assistance." },
        { lead: "Skills development", text: "Free training and resources for freelancing, entrepreneurship, and digital services." },
        { lead: "Health information", text: "Reliable maternal, child, and women’s health information and helplines." },
      ],
    },
    {
      label: "2. Our role for children",
      title: "Child protection and a safe future",
      description: "Keeping children safe and helping them learn is our ethical responsibility. Our plans for children include:",
      items: [
        { lead: "Child protection helpdesk", text: "Rapid reporting and assistance for abuse, missing-child cases, or education problems." },
        { lead: "Digital education", text: "Accessible free online learning resources and school admission information." },
        { lead: "Awareness", text: "Guidance for parents on children’s rights and cyber safety." },
      ],
    },
    {
      label: "3. Our role for farmers",
      title: "Farmers’ rights and accessible agricultural services",
      description: "Farmers make an important contribution to the country’s food security. We will help people find reliable sources for agricultural information, applications, and support:",
      items: [
        { lead: "Equal access to services", text: "Find agricultural registration, government support, and application information in clear language." },
        { lead: "Transparent application guidance", text: "Guidance on official links, required documents, and tracking an application’s progress." },
        { lead: "Information and complaint pathways", text: "Verify agricultural advice, weather information, and public support through the relevant official source." },
      ],
    },
    {
      label: "4. Our role for everyone",
      title: "Simple services for all",
      description: "Our commitment is to provide equal opportunity and simpler services. We want to make everyday civic life easier through:",
      items: [
        { lead: "One-click service access", text: "Government and private services, hospitals, and legal support in one place." },
        { lead: "Quick contact", text: "Connect with the right person in one click when you need help." },
        { lead: "Community support", text: "Connect people with local NGOs and volunteer organizations so support can reach them." },
      ],
    },
  ],
};

type GuidanceStep = { number: string; title: string; body: string; categories?: string[] };
type GuidanceWarning = { lead: string; text: string };

const publicGuidanceSteps: Record<"BN" | "EN", GuidanceStep[]> = {
  BN: [
    { number: "১", title: "সমস্যা চিহ্নিত করুন", body: "আপনার সমস্যাটা কী? তা স্পষ্টভাবে বুঝুন। যেমন: জমির কাগজ, হাসপাতাল, পুলিশ, ভাতা, কৃষক কার্ড, নারী নির্যাতন, কিংবা শিশু শিক্ষা।" },
    { number: "২", title: "সঠিক সেবা খুঁজুন", body: "আমাদের ওয়েবসাইটে ক্যাটাগরি অনুযায়ী সেবা খুঁজুন:", categories: ["নারী ও শিশু সুরক্ষা", "কৃষক সেবা", "স্বাস্থ্য ও আইনি সহায়তা", "সরকারি ভাতা ও অনুদান"] },
    { number: "৩", title: "অনলাইনে আবেদন করুন", body: "বেশিরভাগ সেবা এখন ঘরে বসেই করা যায়। প্রয়োজনীয় কাগজপত্র হাতে রাখুন (NID, মোবাইল নাম্বার, ছবি)। ফরমের লাল তারকা ঘরগুলো অবশ্যই পূরণ করুন এবং আবেদনের পর ট্র্যাকিং নাম্বার সংরক্ষণ করুন।" },
    { number: "৪", title: "তথ্যভিত্তিক পরামর্শ নিন", body: "কোনো কিছু বুঝতে সমস্যা হলে পোর্টালের যোগাযোগ ফর্মে প্রশ্ন পাঠান বা সংশ্লিষ্ট সরকারি অফিসিয়াল চ্যানেল ব্যবহার করুন। SahajContact কলব্যাক, আবেদন নিষ্পত্তি বা সময়সীমার নিশ্চয়তা দেয় না। মনে রাখবেন, কোনো দালাল বা ঘুষ লাগবে না।" },
    { number: "৫", title: "প্রতারণা থেকে সাবধান থাকুন", body: "" },
  ],
  EN: [
    { number: "1", title: "Identify the problem", body: "Be clear about the problem you are trying to solve. Examples include land documents, hospitals, police services, allowances, farmer cards, violence against women, or a child’s education." },
    { number: "2", title: "Find the right service", body: "Browse services on our website by category:", categories: ["Women and child protection", "Farmer services", "Health and legal support", "Government allowances and grants"] },
    { number: "3", title: "Apply online", body: "Many services can now be completed from home. Keep the required documents ready, including your NID, mobile number, and photograph. Complete every required field and save the tracking number after applying." },
    { number: "4", title: "Seek information-based guidance", body: "If something is unclear, send a question through the portal contact form or use the responsible public authority’s official channel. SahajContact does not promise a callback, application resolution, or a timeframe. Remember: you do not need a middleman or a bribe." },
    { number: "5", title: "Stay alert to fraud", body: "" },
  ],
};

const publicGuidanceWarnings: Record<"BN" | "EN", GuidanceWarning[]> = {
  BN: [
    { lead: "মনে রাখবেন", text: "" },
    { lead: "কোনো অতিরিক্ত ফি নয়", text: "সরকারি সেবায় সরকারি নির্ধারিত ফি না থাকলে কাউকে অতিরিক্ত টাকা দেবেন না। ফি প্রযোজ্য হলে শুধু অফিসিয়াল পোর্টালে প্রকাশিত পরিমাণ অনুসরণ করুন।" },
    { lead: "OTP শেয়ার করবেন না", text: "ফোনে আসা OTP বা যাচাইকরণ কোড কাউকে বলবেন না—SahajContact টিমও কখনো OTP চাইবে না।" },
    { lead: "দালাল ধরবেন না", text: "নিজেই আবেদন করুন অথবা প্রয়োজন হলে আমাদের নির্দেশনা নিন; কোনো দালাল বা ঘুষের মাধ্যমে কাজ করার পরামর্শ আমরা দিই না।" },
    { lead: "অফিসিয়াল লিংক ব্যবহার করুন", text: "SahajContact-এর অফিসিয়াল সাইট থেকে নির্দেশনা নিয়ে সেখান থেকে দেওয়া যাচাই করা সরকারি লিংকেই আবেদন করুন। লিংকের ঠিকানা ও ডোমেইন দেখে তারপর ব্যক্তিগত তথ্য দিন।" },
  ],
  EN: [
    { lead: "Remember", text: "" },
    { lead: "No extra fee", text: "Do not pay anyone more than the government-set fee for a public service. When a fee applies, follow only the amount published on the official portal." },
    { lead: "Never share an OTP", text: "Do not tell anyone an OTP or verification code sent to your phone. The SahajContact team will never ask for your OTP." },
    { lead: "Do not use a middleman", text: "Apply yourself or follow our guidance when needed. We do not recommend using a middleman or paying a bribe." },
    { lead: "Use official links", text: "Follow guidance from the official SahajContact site and apply through the verified government link provided there. Check the address and domain before entering personal information." },
  ],
};

const publicGuidanceTakeaways: Record<"BN" | "EN", { title: string; body: string; href?: string; cta?: string }[]> = {
  BN: [
    { title: "তথ্য জানুন", body: "অধিকার সম্পর্কে জানলে কেউ আপনাকে ঠকাতে পারবে না।", href: "/future-plan", cta: "আমার অধিকার জানুন" },
    { title: "ডিজিটাল হোন", body: "লাইনে না দাঁড়িয়ে ঘরে বসেই অনলাইনে কাজ সারুন।" },
    { title: "তথ্যভিত্তিক পরামর্শ নিন", body: "প্রয়োজনে পোর্টালের যোগাযোগ ফর্ম ব্যবহার করুন বা সংশ্লিষ্ট সরকারি অফিসিয়াল চ্যানেল যাচাই করুন।" },
  ],
  EN: [
    { title: "Know the facts", body: "Knowing your rights makes it harder for anyone to deceive you.", href: "/future-plan", cta: "Learn about my rights" },
    { title: "Go digital", body: "Complete services online from home instead of waiting in a line." },
    { title: "Seek information-based guidance", body: "When needed, use the portal contact form or verify the responsible public authority’s official channel." },
  ],
};

const pageUiCopy = {
  BN: {
    home: "হোমে ফিরে যান",
    demo: "তথ্যমূলক পৃষ্ঠা — এখানে কোনো সেবা, চুক্তি বা লেনদেন তৈরি হয় না",
    noteLabel: "সহজসেবা নোট",
    noteTitle: "পরিষ্কার তথ্য, সহজ পরবর্তী ধাপ",
    contact: "যোগাযোগ করুন",
    futureEyebrow: "আমাদের ভবিষ্যৎ পরিকল্পনা",
    futureTitle: "নারী, শিশু, কৃষক ও সাধারণ মানুষের জন্য আমাদের পরিকল্পনা",
    futureIntro: "SahajContact বিশ্বাস করে, একটি শক্তিশালী সমাজ গড়ে উঠে নারী, শিশু, কৃষক ও সাধারণ মানুষের নিরাপত্তা এবং অধিকার নিশ্চিত করার মাধ্যমে। আমাদের পরবর্তী পরিকল্পনার মূল লক্ষ্য হলো সবার জন্য সহজ, নিরাপদ ও দ্রুত জনসেবা নিশ্চিত করা।",
    pledgeTitle: "আমাদের অঙ্গীকার",
    pledge: "কোনো নারী যেন অসহায় বোধ না করে, কোনো শিশু যেন শিক্ষা থেকে বঞ্চিত না হয়, কোনো কৃষক যেন তথ্য ও সেবা থেকে বঞ্চিত না হন, এবং কোনো সাধারণ মানুষ যেন সেবা পেতে হয়রানির শিকার না হন—এটাই SahajContact-এর মূল লক্ষ্য।",
    slogan: "সহজ জনসেবা, সবার জন্য",
    supportContact: "পরামর্শ বা সহায়তার জন্য যোগাযোগ করুন",
    homePage: "হোম পেজে ফিরে যান",
    guidanceEyebrow: "নাগরিক গাইডলাইন",
    guidanceTitle: "সাধারণ মানুষের জন্য নির্দেশনা",
    guidanceIntro: "SahajContact চায় প্রতিটি মানুষ যেন হয়রানি ছাড়া দ্রুত সেবা পায়। তাই এই ৫টি সহজ ধাপ ও সতর্কতাগুলো অনুসরণ করুন:",
    guidancePledge: "কোনো নারী যেন অসহায় বোধ না করে, কোনো শিশু যেন শিক্ষা থেকে বঞ্চিত না হয়, এবং কোনো সাধারণ মানুষ যেন সেবা পেতে হয়রানির শিকার না হয় - এটাই SahajContact এর মূল লক্ষ্য।",
  },
  EN: {
    home: "Back to home",
    demo: "Informational page — no service, contract, or transaction is created here",
    noteLabel: "SahajContact note",
    noteTitle: "Clear information, simple next steps",
    contact: "Contact us",
    futureEyebrow: "Our future plan",
    futureTitle: "Our plan for women, children, farmers, and citizens",
    futureIntro: "SahajContact believes a strong society is built by protecting the safety, dignity, and rights of women, children, farmers, and all citizens. Our next goal is to make public services easier, safer, and faster for everyone.",
    pledgeTitle: "Our commitment",
    pledge: "No woman should feel helpless, no child should be denied education, no farmer should be denied information or services, and no citizen should face harassment while seeking help. This is SahajContact’s central mission.",
    slogan: "Simple civic services, for everyone",
    supportContact: "Contact us for advice or assistance",
    homePage: "Return to the home page",
    guidanceEyebrow: "Citizen guidance",
    guidanceTitle: "Guidance for everyone",
    guidanceIntro: "SahajContact wants everyone to receive services quickly and without harassment. Follow these five simple steps and safety reminders:",
    guidancePledge: "No woman should feel helpless, no child should be denied education, and no citizen should face harassment while seeking a service. This is SahajContact’s central mission.",
  },
} as const;

export default function FooterInfoPage({ pageKey }: { pageKey: FooterPageKey }) {
  const { language } = useLanguage();
  const isEn = language === "EN";
  const locale = isEn ? "EN" : "BN";
  const baseContent = footerPageContent[pageKey] || footerPageContent.about;
  const content = isEn ? footerPageContentEn[pageKey] : baseContent;
  const ui = pageUiCopy[locale];

  return (
    <div className="site-shell">
      <SahajHeader />
      <main>
        <section className="footer-info-hero">
          <div className="container footer-info-hero-inner">
            <div>
              <Link href="/" className="back-link"><ArrowLeft size={15} aria-hidden="true" /> {ui.home}</Link>
              <span className="eyebrow footer-info-eyebrow">{content.eyebrow}</span>
              <h1>{content.title}</h1>
              <p>{content.summary}</p>
              <span className="footer-demo-badge">{ui.demo}</span>
            </div>
            <div className="footer-info-card">
              <span className="section-number">{ui.noteLabel}</span>
              <h2>{ui.noteTitle}</h2>
              <div className="footer-info-points">
                {content.points.map((point) => (
                  <p key={point}><CircleCheck size={16} aria-hidden="true" />{point}</p>
                ))}
              </div>
              {pageKey === "about" && (
                <div className="mt-5 pt-4 border-t border-border/60 text-center" data-testid="about-admin-identity">
                  <p className="font-semibold text-foreground">Name: Kazi Amir Hamja</p>
                  <p className="text-sm text-muted-foreground">Title: Entrepreneur, SahajContact</p>
                </div>
              )}
              <Link href="/contact" className="button button-primary">{ui.contact} <ArrowUpRight size={16} aria-hidden="true" /></Link>
            </div>
          </div>
        </section>

        {pageKey === "future-plan" && (
          <section className="container py-12 md:py-16">
            <div className="max-w-4xl mx-auto space-y-8">
              <div className="bg-card border border-border/60 rounded-2xl p-6 md:p-8 shadow-sm space-y-4">
                <span className="text-xs font-semibold uppercase tracking-wider text-primary block">{ui.futureEyebrow}</span>
                <h2 className="text-3xl font-extrabold text-foreground">{ui.futureTitle}</h2>
                <p className="text-muted-foreground leading-relaxed">{ui.futureIntro}</p>
              </div>

              {futurePlanSections[locale].map((section, index) => {
                const Icon = [HeartHandshake, Baby, Wheat, UsersRound][index];
                const toneClasses = [
                  "border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700",
                  "border-sky-200 bg-sky-50 text-sky-700",
                  "border-lime-200 bg-lime-50 text-lime-700",
                  "border-amber-200 bg-amber-50 text-amber-700",
                ][index];
                return (
                  <div key={section.title} className="bg-card border border-border/60 rounded-2xl p-6 md:p-8 shadow-sm space-y-4">
                    <div className="flex items-center gap-4">
                      <div className={`flex size-12 shrink-0 items-center justify-center rounded-2xl border shadow-sm ${toneClasses}`} aria-hidden="true">
                        <Icon size={24} strokeWidth={1.8} />
                      </div>
                      <span className="text-xs font-semibold uppercase tracking-wider text-primary">{section.label}</span>
                    </div>
                    <h3 className="text-2xl font-bold text-foreground">{section.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{section.description}</p>
                    <ul className="space-y-3 text-sm text-foreground/90">
                      {section.items.map((item) => (
                        <li key={item.lead} className="flex items-start gap-3">
                          <span className="text-primary font-bold">•</span>
                          <div><strong>{item.lead}:</strong> {item.text}</div>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}

              <div className="bg-card border border-border/60 rounded-2xl p-6 md:p-8 shadow-sm space-y-4">
                <h3 className="text-xl font-bold text-foreground">{ui.pledgeTitle}</h3>
                <blockquote className="border-l-4 border-primary pl-4 italic text-muted-foreground leading-relaxed">“{ui.pledge}”</blockquote>
                <p className="text-sm font-semibold text-primary pt-2">“{ui.slogan}”</p>
                <div className="flex flex-wrap gap-4 mt-6 pt-6 border-t border-border/50">
                  <Link href="/contact" className="button button-primary">{ui.supportContact} <ArrowUpRight size={16} /></Link>
                  <Link href="/" className="button button-outline">{ui.homePage}</Link>
                </div>
              </div>
            </div>
          </section>
        )}

        {pageKey === "public-guidance" && (
          <section className="container py-12 md:py-16">
            <div className="max-w-4xl mx-auto space-y-8">
              <div className="bg-card border border-border/60 rounded-2xl p-6 md:p-8 shadow-sm space-y-4">
                <span className="text-xs font-semibold uppercase tracking-wider text-primary block">{ui.guidanceEyebrow}</span>
                <h2 className="text-3xl font-extrabold text-foreground">{ui.guidanceTitle}</h2>
                <p className="text-muted-foreground leading-relaxed">{ui.guidanceIntro}</p>
              </div>

              {publicGuidanceSteps[locale].map((step, index) => (
                <div key={step.number} className={`bg-card border border-border/60 rounded-2xl p-6 md:p-8 shadow-sm space-y-3 ${index === 4 ? "border-l-4 border-l-amber-500" : ""}`}>
                  <div className="flex items-center gap-3">
                    <div className={`flex size-10 shrink-0 items-center justify-center rounded-xl ${index === 4 ? "bg-amber-500" : "bg-primary"} text-primary-foreground font-bold text-base shadow-sm`}>{step.number}</div>
                    <h3 className="text-xl font-bold text-foreground">{step.title}</h3>
                  </div>
                  {step.body && <p className="text-muted-foreground leading-relaxed pl-13">{step.body}</p>}
                  {step.categories && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-0 sm:pl-13 pt-2">
                      {step.categories.map((category) => (
                        <div key={category} className="p-3 rounded-xl bg-accent/50 border border-border/40 text-sm font-medium text-foreground">• {category}</div>
                      ))}
                    </div>
                  )}
                  {index === 4 && (
                    <div className="space-y-2 text-muted-foreground leading-relaxed pl-0 sm:pl-13 pt-1">
                      {publicGuidanceWarnings[locale].map((warning) => (
                        <p key={warning.lead}>{warning.text ? <><strong>{warning.lead}:</strong> {warning.text}</> : <strong>{warning.lead}:</strong>}</p>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                {publicGuidanceTakeaways[locale].map((takeaway) => (
                  <div key={takeaway.title} className="bg-card border border-border/60 rounded-2xl p-6 shadow-sm text-center space-y-3">
                    <div className="text-primary font-extrabold text-lg">{takeaway.title}</div>
                    <p className="text-sm text-muted-foreground">{takeaway.body}</p>
                    {takeaway.href && takeaway.cta && (
                      <div className="pt-2">
                        <Link href={takeaway.href} className="inline-flex items-center gap-1.5 text-xs font-bold text-primary bg-primary/10 hover:bg-primary/20 transition-colors px-3 py-2 rounded-xl">
                          {takeaway.cta} <ArrowUpRight size={14} />
                        </Link>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 md:p-8 text-center space-y-4">
                <h3 className="text-xl font-bold text-foreground">{ui.pledgeTitle}</h3>
                <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">{ui.guidancePledge}</p>
                <p className="text-lg font-extrabold text-primary pt-2">“{ui.slogan}”</p>
                <div className="flex flex-wrap justify-center gap-4 pt-4">
                  <Link href="/contact" className="button button-primary">{ui.supportContact} <ArrowUpRight size={16} /></Link>
                  <Link href="/" className="button button-outline">{ui.homePage}</Link>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>
      <SahajFooter />
    </div>
  );
}
