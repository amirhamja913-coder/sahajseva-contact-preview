import { ArrowLeft, Building2, ExternalLink, Megaphone, Wallet } from "lucide-react";
import type { ReactNode } from "react";
import { Link } from "wouter";
import SahajCivicChatWidget from "@/components/SahajCivicChatWidget";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";

const partnerLinks = [
  { name: "bKash", url: "https://www.bkash.com/", tone: "pink", bnType: "ফিনটেক ও পেমেন্ট", enType: "Fintech & payments", bnDescription: "নিরাপদ মার্চেন্ট পেমেন্ট ও সেবা ফি আদান-প্রদানের তথ্য।", enDescription: "Information about secure merchant payments and service-fee collection." },
  { name: "Nagad", url: "https://nagad.com.bd/", tone: "orange", bnType: "ফিনটেক ও মোবাইল ব্যাংকিং", enType: "Fintech & mobile banking", bnDescription: "ডিজিটাল পেমেন্ট ও সরকারি সেবা ফি সম্পর্কিত তথ্য।", enDescription: "Information about digital payments and government service fees." },
  { name: "Star Tech", url: "https://www.startech.com.bd/", tone: "cyan", bnType: "প্রযুক্তি ও গ্যাজেট", enType: "Technology & devices", bnDescription: "সহায়ক ডিভাইস ও ডিজিটাল এক্সেসরিজ তথ্য।", enDescription: "Information about assistive devices and digital accessories." },
  { name: "Ryans Computers", url: "https://www.ryans.com/", tone: "blue", bnType: "প্রযুক্তি ও সার্ভিস", enType: "Technology & services", bnDescription: "ডিজিটাল সেবা কেন্দ্র ও হার্ডওয়্যার সম্পর্কিত তথ্য।", enDescription: "Information about digital service centres and hardware." },
  { name: "BRAC", url: "https://www.brac.net/", tone: "green", bnType: "সামাজিক উন্নয়ন", enType: "Social development", bnDescription: "গ্রামীণ উন্নয়ন ও প্রান্তিক নাগরিক সহায়তা বিষয়ে তথ্য।", enDescription: "Information about rural development and community support." },
  { name: "Grameenphone", url: "https://www.grameenphone.com/", tone: "indigo", bnType: "টেলিকম ও কানেক্টিভিটি", enType: "Telecom & connectivity", bnDescription: "ডিজিটাল নোটিফিকেশন ও ব্যবহারকারী সংযোগের তথ্য।", enDescription: "Information about digital notifications and user connectivity." },
  { name: "US-Bangla Airlines", url: "https://usbair.com/", tone: "emerald", bnType: "ভ্রমণ ও টিকেট", enType: "Travel & tickets", bnDescription: "প্রবাসী ও অভ্যন্তরীণ টিকেট-সংক্রান্ত তথ্য।", enDescription: "Information about expatriate and domestic travel tickets." },
  { name: "Daraz Bangladesh", url: "https://www.daraz.com.bd/", tone: "red", bnType: "ই-কমার্স", enType: "E-commerce", bnDescription: "অনলাইন শপিং ও প্রয়োজনীয় সরঞ্জাম সম্পর্কিত তথ্য।", enDescription: "Information about online shopping and essential supplies." },
] as const;

const toneClass = {
  pink: "text-pink-400 bg-pink-500/10",
  orange: "text-orange-400 bg-orange-500/10",
  cyan: "text-cyan-400 bg-cyan-500/10",
  blue: "text-blue-400 bg-blue-500/10",
  green: "text-green-400 bg-green-500/10",
  indigo: "text-indigo-400 bg-indigo-500/10",
  emerald: "text-emerald-400 bg-emerald-500/10",
  red: "text-red-400 bg-red-500/10",
} as const;

export default function FundingGuidancePage() {
  const { language } = useLanguage();
  const isEnglish = language === "EN";
  const copy = isEnglish
    ? {
        back: "Back to home", tag: "Transparency & guidance portal", warning: "We are not an official representative of any government agency or NGO.",
        title: "Advertising, sponsorship, NGO support & public-assistance guide", intro: "This page explains opportunities and practical information about services, financial support, advertising and sponsorship on the SahajSeba portal.",
        governmentTitle: "1. Government assistance & social-security allowances", governmentSubtitle: "Senior, widow and disability allowances, and public-grant applications",
        governmentText: "Bangladesh government ministries and relevant offices administer social-security support for eligible communities. SahajSeba provides general guidance on online application steps, status checking and supporting documents.",
        documentsTitle: "Application guidance and common documents", documents: ["A valid National ID (NID) or birth-registration number.", "An active mobile number for official SMS messages.", "A local-council or municipality certificate when required.", "Income proof or an attestation where applicable."],
        cautionLabel: "Important:", caution: "SahajSeba is not a government office. We only provide general process guidance; final decisions are made by the responsible government authority.",
        ngoTitle: "2. NGO & community support", ngoSubtitle: "Microfinance, educational support and local social-welfare information",
        ngoText: "Registered NGOs and foundations may offer vocational training, microfinance, scholarships or emergency-support programmes. Availability, eligibility and terms are set by each organisation.",
        roleTitle: "Our role", roleText: "We offer initial, free information to help visitors identify how to contact an organisation and what questions to ask. We do not approve benefits, submit applications, or represent any organisation.",
        referenceTitle: "Official information sources", officialWebsite: "Official website", external: "opens in a new tab", ngoNote: "These links are provided for information only. SahajSeba is not an official partner, representative or authorised agent of BRAC, ASA or another organisation.", ngoCtaTitle: "Are you an NGO, public body or responsible institution?", ngoCtaText: "Read the public institutional collaboration proposal and submit an expression of interest for private owner review. Submission does not create a partnership or public listing.", ngoCtaAction: "Open NGO Partnership page",
        outreachTitle: "3. Partnership & sponsorship information", outreachSubtitle: "Organisations relevant to practical civic services", outreachText: "SahajSeba may explore transparent partnerships that improve practical information and access to services. The organisations below are listed as information sources and are not confirmed sponsors or exclusive partners.",
        interest: "Partnership interest — not confirmed", transparencyLabel: "Transparency note:", transparency: "A listed organisation is not an official sponsor, partner or endorser of SahajSeba unless a written agreement is publicly confirmed on this site. Organisations interested in a partnership can use the NGO Partnership page for private owner review.",
        adTitle: "4. Advertising & business sponsorship", adSubtitle: "Share your organisation’s information through a review-first portal route", adText: "Local businesses, entrepreneurs, training centres and digital-service providers can use the Contact page to express interest in transparent advertising or sponsored-content options. An enquiry does not create a placement, invoice, payment request, endorsement, or approval.",
        bannerTitle: "Banner advertising", bannerText: "A future, clearly labelled banner placement may be considered only after review and a verified written agreement.", sponsoredTitle: "Sponsored content", sponsoredText: "A future clearly labelled article or news-feed placement may be considered only after review; no placement is guaranteed from this page.", contactAd: "Use the Contact page for advertising information", questionTitle: "Have a specific question?", questionText: "Use the AI assistant or the portal Contact page. A message does not create an application, payment, or guaranteed response.", contact: "Contact us",
      }
    : {
        back: "হোমপেজে ফিরে যান", tag: "স্বচ্ছতা ও দিকনির্দেশনা পোর্টাল", warning: "আমরা কোনো সরকারি বা NGO-এর অফিসিয়াল প্রতিনিধি নই।",
        title: "বিজ্ঞাপন, স্পন্সরশিপ, NGO সহায়তা ও সরকারি অর্থসহায়তা গাইড", intro: "সহজসেবা পোর্টালে বিভিন্ন ধরনের সেবা, আর্থিক সহায়তা, বিজ্ঞাপন এবং স্পন্সরশিপের সুযোগ ও নিয়মাচার সম্পর্কে বিস্তারিত তথ্য নিচে দেওয়া হলো।",
        governmentTitle: "১. সরকারি অর্থসহায়তা ও সামাজিক নিরাপত্তা ভাতা", governmentSubtitle: "বয়স্ক ভাতা, বিধবা ভাতা, প্রতিবন্ধী ভাতা ও সরকারি অনুদান আবেদন",
        governmentText: "বাংলাদেশ সরকারের সংশ্লিষ্ট মন্ত্রণালয় ও দপ্তর যোগ্য জনগোষ্ঠীর জন্য সামাজিক নিরাপত্তা সহায়তা পরিচালনা করে। সহজসেবা অনলাইন আবেদনপ্রক্রিয়া, স্ট্যাটাস দেখা এবং প্রয়োজনীয় কাগজপত্র সম্পর্কে সাধারণ দিকনির্দেশনা দেয়।",
        documentsTitle: "আবেদনের নিয়ম ও সাধারণ কাগজপত্র", documents: ["সঠিক জাতীয় পরিচয়পত্র (NID) বা জন্ম নিবন্ধন নম্বর।", "সচল মোবাইল নম্বর, যেখানে সরকারি SMS আসবে।", "প্রয়োজনে ইউনিয়ন পরিষদ বা পৌরসভার নাগরিক সনদ।", "প্রযোজ্য ক্ষেত্রে আয়ের প্রমাণপত্র বা প্রত্যয়নপত্র।"],
        cautionLabel: "সতর্কবার্তা:", caution: "সহজসেবা কোনো সরকারি দপ্তর নয়। আমরা কেবল প্রক্রিয়া সম্পর্কে সাধারণ সহায়তা দিই; চূড়ান্ত সিদ্ধান্ত সংশ্লিষ্ট সরকারি কর্তৃপক্ষের।",
        ngoTitle: "২. এনজিও (NGO) ও সামাজিক সহায়তা", ngoSubtitle: "ক্ষুদ্রঋণ, শিক্ষাবৃত্তি এবং স্থানীয় সমাজকল্যাণ তথ্য",
        ngoText: "নিবন্ধিত NGO ও ফাউন্ডেশন বৃত্তিমূলক প্রশিক্ষণ, ক্ষুদ্রঋণ, শিক্ষাবৃত্তি বা জরুরি সহায়তা দিতে পারে। সহায়তার প্রাপ্যতা, শর্ত ও সিদ্ধান্ত প্রতিটি সংস্থার নিজস্ব।",
        roleTitle: "আমাদের ভূমিকা", roleText: "কোন সংস্থার সঙ্গে কীভাবে যোগাযোগ করবেন এবং কী প্রশ্ন করবেন—সে বিষয়ে আমরা বিনামূল্যে প্রাথমিক তথ্য দিই। আমরা কোনো সুবিধা অনুমোদন করি না, আবেদন জমা দিই না এবং কোনো সংস্থার প্রতিনিধি নই।",
        referenceTitle: "তথ্যসূত্র হিসেবে অফিসিয়াল ওয়েবসাইট", officialWebsite: "অফিসিয়াল ওয়েবসাইট", external: "নতুন ট্যাবে খুলবে", ngoNote: "এগুলো কেবল তথ্যের সুবিধার জন্য দেওয়া বাহ্যিক লিংক। সহজসেবা BRAC, ASA বা অন্য কোনো সংস্থার অফিসিয়াল পার্টনার, প্রতিনিধি বা অনুমোদিত এজেন্ট নয়।", ngoCtaTitle: "আপনি কি NGO, সরকারি সংস্থা বা দায়িত্বশীল প্রতিষ্ঠান?", ngoCtaText: "সবার জন্য উন্মুক্ত প্রাতিষ্ঠানিক সহযোগিতা প্রস্তাবটি দেখুন এবং private owner review-এর জন্য আগ্রহপত্র জমা দিন। আবেদন জমা মানে পার্টনারশিপ বা public listing তৈরি হওয়া নয়।", ngoCtaAction: "NGO Partnership পেজ খুলুন",
        outreachTitle: "৩. পার্টনারশিপ ও স্পন্সরশিপ তথ্য", outreachSubtitle: "প্রয়োজনীয় নাগরিকসেবা-সংক্রান্ত প্রতিষ্ঠানসমূহ", outreachText: "সহজসেবা নাগরিক তথ্য ও সেবাপ্রাপ্তি উন্নত করতে স্বচ্ছ পার্টনারশিপের সম্ভাবনা অনুসন্ধান করতে পারে। নিচের প্রতিষ্ঠানগুলো তথ্যসূত্র হিসেবে দেওয়া; তারা নিশ্চিত স্পন্সর বা এক্সক্লুসিভ পার্টনার নয়।",
        interest: "পার্টনারশিপ আগ্রহ — নিশ্চিত নয়", transparencyLabel: "স্বচ্ছতা নোট:", transparency: "লিখিত চুক্তি এই সাইটে প্রকাশ্যে নিশ্চিত না হওয়া পর্যন্ত তালিকাভুক্ত কোনো প্রতিষ্ঠান সহজসেবার অফিসিয়াল স্পন্সর, পার্টনার বা সমর্থনদাতা নয়। পার্টনারশিপে আগ্রহী প্রতিষ্ঠান private owner review-এর জন্য NGO Partnership পেজ ব্যবহার করতে পারে।",
        adTitle: "৪. বিজ্ঞাপন ও ব্যবসায়িক স্পন্সরশিপ", adSubtitle: "Review-first পোর্টাল পথে প্রতিষ্ঠানের তথ্য দিন", adText: "স্থানীয় ব্যবসা, উদ্যোক্তা, কোচিং সেন্টার ও ডিজিটাল সার্ভিস প্রদানকারী প্রতিষ্ঠান স্বচ্ছ বিজ্ঞাপন বা স্পন্সরড কনটেন্টের আগ্রহ জানাতে Contact পেজ ব্যবহার করতে পারেন। আগ্রহ জানালেই কোনো placement, invoice, payment request, endorsement বা অনুমোদন তৈরি হয় না।",
        bannerTitle: "ব্যানার বিজ্ঞাপন", bannerText: "ভবিষ্যতে স্পষ্টভাবে চিহ্নিত ব্যানার placement কেবল review ও যাচাইকৃত লিখিত চুক্তির পরে বিবেচিত হতে পারে।", sponsoredTitle: "স্পন্সরড কনটেন্ট", sponsoredText: "ভবিষ্যতে স্পষ্টভাবে চিহ্নিত নিবন্ধ বা নিউজ-ফিড placement কেবল review-এর পরে বিবেচিত হতে পারে; এই পেজ কোনো placement নিশ্চিত করে না।", contactAd: "বিজ্ঞাপনের তথ্যের জন্য Contact পেজ ব্যবহার করুন", questionTitle: "আপনার কোনো নির্দিষ্ট প্রশ্ন আছে?", questionText: "AI সহকারী বা পোর্টালের Contact পেজ ব্যবহার করুন। বার্তা দিলেই কোনো আবেদন, পেমেন্ট বা নিশ্চিত উত্তর তৈরি হয় না।", contact: "যোগাযোগ করুন",
      };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans public-civic-page public-funding-page">
      <SahajHeader />
      <main className="container mx-auto max-w-5xl flex-1 px-4 py-8">
        <header className="mb-6">
          <Link href="/" className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-teal-400 hover:text-teal-300"><ArrowLeft className="h-4 w-4" />{copy.back}</Link>
          <div className="mb-3 inline-block rounded-full border border-teal-500/20 bg-teal-500/10 px-3 py-1 text-xs font-semibold text-teal-400">{copy.tag}</div>
          <div className="mb-4 flex items-center gap-3 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm font-medium text-amber-300 sm:text-base"><span className="text-xl">⚠️</span><span>{copy.warning}</span></div>
          <h1 className="mb-3 text-3xl font-extrabold text-white sm:text-4xl">{copy.title}</h1>
          <p className="text-base leading-relaxed text-slate-300 sm:text-lg">{copy.intro}</p>
        </header>

        <div className="space-y-8">
          <section className="rounded-2xl border border-slate-700/80 bg-slate-800/80 p-6 shadow-lg sm:p-8">
            <SectionHeading icon={<Wallet className="h-6 w-6" />} title={copy.governmentTitle} subtitle={copy.governmentSubtitle} tone="teal" />
            <div className="space-y-4 text-sm leading-relaxed text-slate-300 sm:text-base"><p>{copy.governmentText}</p><div className="space-y-2 rounded-xl border border-slate-700 bg-slate-900/60 p-4"><p className="font-semibold text-white">{copy.documentsTitle}</p><ul className="list-disc space-y-1 pl-5 text-sm text-slate-300">{copy.documents.map((item) => <li key={item}>{item}</li>)}</ul></div><Notice label={copy.cautionLabel} text={copy.caution} /></div>
          </section>

          <section className="rounded-2xl border border-slate-700/80 bg-slate-800/80 p-6 shadow-lg sm:p-8">
            <SectionHeading icon={<Building2 className="h-6 w-6" />} title={copy.ngoTitle} subtitle={copy.ngoSubtitle} tone="blue" />
            <div className="space-y-4 text-sm leading-relaxed text-slate-300 sm:text-base"><p>{copy.ngoText}</p><div className="rounded-xl border border-slate-700 bg-slate-900/60 p-4"><p className="font-semibold text-white">{copy.roleTitle}</p><p className="mt-2 text-sm text-slate-300">{copy.roleText}</p></div><div><p className="mb-3 font-semibold text-white">{copy.referenceTitle}</p><div className="grid grid-cols-1 gap-3 sm:grid-cols-2"><OfficialCard name="BRAC" description={isEnglish ? "Information on education, health, livelihoods and social development." : "শিক্ষা, স্বাস্থ্য, জীবিকা ও সামাজিক উন্নয়ন বিষয়ে তথ্য।"} url="https://www.brac.net/" copy={copy} /><OfficialCard name="ASA" description={isEnglish ? "Organisation-led information on microfinance and social support." : "ক্ষুদ্রঋণ ও সামাজিক সহায়তা বিষয়ে সংস্থার নিজস্ব তথ্য।"} url="https://asa.org.bd/" copy={copy} /></div><p className="mt-3 text-xs text-amber-300">{copy.ngoNote}</p></div></div>
          </section>

          <section className="rounded-2xl border border-teal-400/30 bg-teal-950/35 p-6 shadow-lg sm:p-8"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center"><div><h2 className="text-xl font-bold text-white">{copy.ngoCtaTitle}</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-200">{copy.ngoCtaText}</p></div><Link href="/ngo-partnership" className="shrink-0 rounded-xl bg-teal-400 px-5 py-3 text-center text-sm font-bold text-slate-950 transition hover:bg-teal-300">{copy.ngoCtaAction}</Link></div></section>

          <section className="rounded-2xl border border-slate-700/80 bg-slate-800/80 p-6 shadow-lg sm:p-8">
            <SectionHeading icon={<Building2 className="h-6 w-6" />} title={copy.outreachTitle} subtitle={copy.outreachSubtitle} tone="purple" />
            <div className="space-y-4 text-sm leading-relaxed text-slate-300 sm:text-base"><p>{copy.outreachText}</p><div className="grid grid-cols-1 gap-3 pt-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">{partnerLinks.map((partner) => <div key={partner.name} className="flex flex-col justify-between rounded-xl border border-slate-700 bg-slate-900/70 p-4"><div><span className={`mb-2 inline-block rounded-md px-2.5 py-1 text-xs font-bold uppercase tracking-wider ${toneClass[partner.tone]}`}>{isEnglish ? partner.enType : partner.bnType}</span><h3 className="text-base font-bold text-white">{partner.name}</h3><p className="mt-1 text-xs text-slate-400">{isEnglish ? partner.enDescription : partner.bnDescription}</p><a href={partner.url} target="_blank" rel="noopener noreferrer" aria-label={`${partner.name} — ${copy.officialWebsite} (${copy.external})`} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-teal-300 underline underline-offset-4 hover:text-teal-200">{copy.officialWebsite}<ExternalLink className="h-3.5 w-3.5" /></a></div><div className="mt-3 flex items-center gap-1.5 border-t border-slate-800 pt-3 text-xs font-medium text-amber-300"><span className="h-2 w-2 rounded-full bg-amber-400" />{copy.interest}</div></div>)}</div><Notice label={copy.transparencyLabel} text={copy.transparency} /></div>
          </section>

          <section className="rounded-2xl border border-slate-700/80 bg-slate-800/80 p-6 shadow-lg sm:p-8">
            <SectionHeading icon={<Megaphone className="h-6 w-6" />} title={copy.adTitle} subtitle={copy.adSubtitle} tone="pink" />
            <div className="space-y-4 text-sm leading-relaxed text-slate-300 sm:text-base"><p>{copy.adText}</p><div className="grid grid-cols-1 gap-4 sm:grid-cols-2"><InfoCard title={copy.bannerTitle} text={copy.bannerText} /><InfoCard title={copy.sponsoredTitle} text={copy.sponsoredText} /></div><Link href="/contact" className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-md transition hover:bg-emerald-500">{copy.contactAd}</Link></div>
          </section>

          <section className="flex flex-col items-center justify-between gap-6 rounded-2xl border border-teal-500/30 bg-teal-950/40 p-6 sm:flex-row sm:p-8"><div className="space-y-2 text-center sm:text-left"><h2 className="text-xl font-bold text-white">{copy.questionTitle}</h2><p className="text-sm text-slate-300">{copy.questionText}</p></div><div className="flex flex-wrap justify-center gap-3"><Link href="/contact" className="rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-bold text-white shadow transition hover:bg-teal-500">{copy.contact}</Link></div></section>
        </div>
      </main>
      <SahajCivicChatWidget />
      <SahajFooter />
    </div>
  );
}

function SectionHeading({ icon, title, subtitle, tone }: { icon: ReactNode; title: string; subtitle: string; tone: "teal" | "blue" | "purple" | "pink" }) {
  const colors = { teal: "bg-teal-500/20 text-teal-400", blue: "bg-blue-500/20 text-blue-400", purple: "bg-purple-500/20 text-purple-400", pink: "bg-pink-500/20 text-pink-400" };
  return <div className="mb-4 flex items-center gap-3"><div className={`flex h-12 w-12 items-center justify-center rounded-xl text-xl font-bold ${colors[tone]}`}>{icon}</div><div><h2 className="text-xl font-bold text-white sm:text-2xl">{title}</h2><p className="text-sm font-medium text-slate-300">{subtitle}</p></div></div>;
}

function Notice({ label, text }: { label: string; text: string }) {
  return <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-300 sm:text-sm"><strong>{label}</strong> {text}</div>;
}

function InfoCard({ title, text }: { title: string; text: string }) {
  return <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-4"><h3 className="mb-1 font-bold text-white">{title}</h3><p className="text-sm text-slate-400">{text}</p></div>;
}

function OfficialCard({ name, description, url, copy }: { name: string; description: string; url: string; copy: { officialWebsite: string; external: string } }) {
  return <div className="rounded-xl border border-slate-700 bg-slate-900/70 p-4"><h3 className="text-base font-bold text-white">{name}</h3><p className="mt-1 text-xs text-slate-400">{description}</p><a href={url} target="_blank" rel="noopener noreferrer" aria-label={`${name} — ${copy.officialWebsite} (${copy.external})`} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-teal-300 underline underline-offset-4 hover:text-teal-200">{copy.officialWebsite}<ExternalLink className="h-3.5 w-3.5" /></a></div>;
}
