import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

const homeSource = readFileSync(new URL("./Home.tsx", import.meta.url), "utf8");

describe("Home footer-adjacent FAQ layout", () => {
  it("keeps the compact FAQ after the public gallery and immediately before the footer", () => {
    const galleryIndex = homeSource.indexOf('id="open-photo-gallery"');
    const faqIndex = homeSource.indexOf('id="faq"');
    const footerIndex = homeSource.indexOf("<SahajFooter />");

    expect(galleryIndex).toBeGreaterThan(-1);
    expect(faqIndex).toBeGreaterThan(galleryIndex);
    expect(footerIndex).toBeGreaterThan(faqIndex);
    expect(homeSource.slice(faqIndex, footerIndex)).toContain("footer-faq-section");
  });

  it("uses compact accessible question disclosures rather than a long standalone FAQ surface", () => {
    expect(homeSource).toContain('aria-label={isEnglish ? "Frequently asked questions" : "সাধারণ জিজ্ঞাসা"}');
    expect(homeSource).toContain('grid gap-3 md:grid-cols-2');
    expect(homeSource).toContain('className="footer-faq-section border-t');
  });
});
