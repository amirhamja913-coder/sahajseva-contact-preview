// Design philosophy: “নদীর পথ” — every service is a clear next stop, with calm Bangla editorial hierarchy and practical civic wayfinding.
/* Design reminder: “নদীর পথ” — শান্ত কাগজ-ভিত্তিক বাংলা civic wayfinding, teal ink, saffron markers, editorial spacing. Monetization UI must stay transparent and service-first. */
import { lazy, Suspense, useEffect, useMemo, useState, type CSSProperties, type FormEvent, type ReactNode } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowUpRight, BadgeCheck, BadgePercent, BookOpen, BriefcaseBusiness, CarFront, Check, Copy, FileCheck2, FileText, Flame, Globe2, HandCoins, Handshake, HeartHandshake, IdCard, Info, Landmark, Link2, Mail, MapPin, MessageCircle, Phone, HeartPulse, RadioTower, ReceiptText, RotateCcw, Search, SearchCheck, Share2, ShieldCheck, Ticket, X, Zap } from "lucide-react";
import { Link } from "wouter";
import { divisionsData, findDistrictById, findUpazilasByDistrictId, OFFICIAL_UNION_DIRECTORY_URL } from "../lib/locationData";
import { canSearchUnion, matchesLocationScope, type ServiceLocationScope } from "../lib/locationFilters";
import PwaInstallButton from "../components/PwaInstallButton";
import { ExternalLinkWithFallback } from "../components/ExternalLinkWithFallback";
import SahajFooter from "@/components/SahajFooter";
import SahajHelpPopup from "@/components/SahajHelpPopup";
import SahajHeader from "@/components/SahajHeader";
import { ServiceShareButton } from "@/components/ServiceShareButton";
import { trackEvent, trackOutbound } from "../lib/analytics";
import { trpc } from "@/lib/trpc";
import ServiceReviews from "@/components/ServiceReviews";
import { orderServicesByNumber } from "../lib/serviceOrdering";
import { newCivicServices, type CivicService } from "../lib/newCivicServices";
import { getLocalizedServiceCategory, serviceCategories, serviceCategoryByNumber } from "../lib/categorizedServices";
import DeferredMount from "../components/DeferredMount";
import { SITE_WIDE_REVIEW_ID, siteWideReviewIds } from "../lib/reviewScopes";
import { getLocalizedServiceBranding } from "../lib/serviceBranding";
import { getServiceArtwork } from "../lib/serviceArtwork";
import BangladeshMapInteractive from "../components/BangladeshMapInteractive";
import { BangladeshGallery } from "../components/BangladeshGallery";
import EducationHubSection from "../components/EducationHubSection";
import FinancialServicesSection from "../components/FinancialServicesSection";
import MediaHubSection from "../components/MediaHubSection";
import PublicSeoSnapshot from "../components/PublicSeoSnapshot";
import { getLanguageCopy, useLanguage } from "@/contexts/LanguageContext";
import { localizeCivicServices } from "@/lib/civicServiceTranslations";
import GovernmentHospitalDirectory from "../components/GovernmentHospitalDirectory";
import { findPublicSearchDestinations, getCivicServiceSearchText } from "@/lib/publicSearchDestinations";
import { parseHomeSectionLayout, type HomeSectionLayoutItem } from "@shared/homeSectionLayout";

const UtilityAndExpatriateSections = lazy(() => import("../components/UtilityAndExpatriateSections"));
// These cards sit at the very end of Home. Deferring them keeps the primary
// civic-service search and the automatic report anchor responsive on first paint.
const OpenPhotoGallery = lazy(() => import("../components/PremiumPhotoGallery"));

function ManagedHomeSection({ layout, children }: { layout: HomeSectionLayoutItem; children: ReactNode }) {
  if (!layout.visible) return null;

  return (
    <div
      className={`home-layout-managed home-layout-surface-${layout.surface}`}
      data-mobile-density={layout.mobileDensity}
      style={{ order: layout.order } as CSSProperties}
    >
      {children}
    </div>
  );
}

/* One recognizable visual per application type. These are decorative cues—the
   service title remains the accessible source of the card's meaning. */
const serviceIcons = [
  IdCard,
  BookOpen,
  FileText,
  BriefcaseBusiness,
  ShieldCheck,
  CarFront,
  BadgeCheck,
  SearchCheck,
  HandCoins,
  Landmark,
  Zap,
  ReceiptText,
  HeartPulse,
  RadioTower,
  Globe2,
] as const;

const services: CivicService[] = [
  { number: "01", title: "নাগরিক সেবা", tag: "অফিসিয়াল উৎস", text: "প্রয়োজনীয় সরকারি সেবার পথ, প্রস্তুতি ও অফিসিয়াল উৎস খুঁজে নিন।", href: "https://bangladesh.gov.bd/", locationScope: "nationwide" },
  { number: "02", title: "থানা সহায়তা", tag: "নাগরিক সহায়তা", text: "থানায় যোগাযোগ, সাধারণ অভিযোগ ও প্রয়োজনীয় পরবর্তী ধাপ বুঝে নিন।", href: "https://www.police.gov.bd/", locationScope: "district" },
  { number: "03", title: "নারী ও শিশু অধিকার", tag: "অধিকার সহায়তা", text: "নারী ও শিশুর নিরাপত্তা, অধিকার এবং সহায়তার সঠিক পথে পৌঁছান।", href: "https://mowca.gov.bd/", locationScope: "nationwide" },
  { number: "04", title: "সমাজসেবা", tag: "সামাজিক সহায়তা", text: "সমাজসেবা অধিদপ্তরের প্রাসঙ্গিক সেবা ও আবেদনপথ এক জায়গায় দেখুন।", href: "http://dss.gov.bd/", locationScope: "nationwide" },
  { number: "05", title: "প্রতিবন্ধী ভাতা", tag: "ভাতা সেবা", text: "প্রতিবন্ধী ব্যক্তিদের ভাতা ও সহায়তা পাওয়ার প্রয়োজনীয় তথ্য খুঁজে নিন।", href: "http://dss.gov.bd/", locationScope: "nationwide" },
  { number: "06", title: "বয়স্ক ও বিধবা ভাতা", tag: "ভাতা সেবা", text: "বয়স্ক, বিধবা ও স্বামী নিগৃহীতা নারীদের ভাতা-সংক্রান্ত পথ বুঝে নিন।", href: "http://dss.gov.bd/", locationScope: "nationwide" },
  { number: "07", title: "অন্যান্য সরকারি ভাতা", tag: "ভাতা সেবা", text: "পরিবার ও নাগরিক জীবনের বিভিন্ন সরকারি ভাতার তথ্য একসঙ্গে খুঁজুন।", href: "https://www.mygov.bd/", locationScope: "nationwide" },
  { number: "08", title: "এয়ার টিকেট", tag: "যাতায়াত", text: "বিমান ভ্রমণের আগে প্রয়োজনীয় তথ্য, প্রস্তুতি ও টিকিটের পথ দেখুন।", href: "https://www.biman-airlines.com/", locationScope: "nationwide" },
  { number: "09", title: "রেল টিকেট", tag: "যাতায়াত", text: "রেলযাত্রার টিকিট ও ভ্রমণ-সংক্রান্ত প্রয়োজনীয় ধাপ সহজে বুঝে নিন।", href: "https://eticket.railway.gov.bd/", locationScope: "nationwide" },
  { number: "10", title: "বাংলাদেশ সড়ক পরিবহন কর্পোরেশন (BRTC) বাস ও টিকেট", tag: "BRTC সরকারি পরিবহন", text: "বাংলাদেশ সড়ক পরিবহন কর্পোরেশনের বাস, রুট, টিকেট ও যোগাযোগের official পথ দেখুন।", href: "https://brtc.gov.bd/", locationScope: "nationwide" },
  { number: "11", title: "হাসপাতাল ডিরেক্টরি", tag: "সেবা ডিরেক্টরি", text: "হাসপাতাল ও স্বাস্থ্যসেবার তথ্য এক জায়গায় গুছিয়ে দেখুন।", href: "https://hrm.dghs.gov.bd/public/facility-registry", locationScope: "district" },
  { number: "12", title: "স্বাস্থ্য তথ্য", tag: "সরকারি উৎস", text: "স্বাস্থ্যসংক্রান্ত সরকারি তথ্য ও কর্তৃপক্ষের উৎসে পৌঁছান।", href: "https://dghs.gov.bd/", locationScope: "district" },
  { number: "13", title: "টিউন অফিস / ইউনিয়ন অফিস", tag: "প্রশাসনিক সহায়তা", text: "স্থানীয় পর্যায়ের নাগরিক সেবা, প্রত্যয়ন ও প্রশাসনিক সহায়তার পথ খুঁজে নিন।", href: "https://bangladesh.gov.bd/", locationScope: "upazila" },
  { number: "14", title: "জেলা প্রশাসক / ডিসি অফিস", tag: "প্রশাসনিক সহায়তা", text: "জেলা প্রশাসকের কার্যালয়, নাগরিক আবেদন ও প্রয়োজনীয় দাপ্তরিক তথ্য এক জায়গায় দেখুন।", href: "https://bangladesh.gov.bd/", locationScope: "district" },
  { number: "15", title: "বিদ্যুৎ, গ্যাস ও পানি", tag: "ইউটিলিটি সেবা", text: "বিদ্যুৎ, গ্যাস ও পানি সংযোগ, অভিযোগ এবং নাগরিক সেবার প্রয়োজনীয় পথ খুঁজুন।", href: "https://grs.gov.bd/", locationScope: "district" },
  { number: "16", title: "অসহায় ও দরিদ্র মানুষের সরকারি সহায়তা", tag: "সামাজিক সহায়তা", text: "অসহায় ও গরিব মানুষের জন্য সরকারি সুযোগ-সুবিধা, সহায়তা ও আবেদনপথ সম্পর্কে জানুন।", href: "https://www.mygov.bd/", locationScope: "nationwide" },
  { number: "17", title: "জাতীয় পরিচয়পত্র (NID)", tag: "অফিসিয়াল অনলাইন সেবা", text: "NID অনলাইন সেবা, নতুন ভোটার, সংশোধন, ডুপ্লিকেট কার্ড ও স্মার্ট কার্ডের অফিসিয়াল পথে যান।", href: "https://services.nidw.gov.bd/", locationScope: "nationwide" },
  { number: "18", title: "ই-পাসপোর্ট সেবা", tag: "অফিসিয়াল অনলাইন আবেদন", text: "ই-পাসপোর্ট আবেদন বা রিইস্যু, নির্দেশনা, ফি ও প্রয়োজনীয় ডকুমেন্টের অফিসিয়াল পোর্টাল দেখুন।", href: "https://www.epassport.gov.bd/", locationScope: "nationwide" },
  { number: "19", title: "সরকারি অনলাইন আবেদন", tag: "জাতীয় তথ্য বাতায়ন", text: "বিভিন্ন সরকারি দপ্তর ও অনলাইন আবেদনের সঠিক পোর্টাল খুঁজে নিতে জাতীয় তথ্য বাতায়নে যান।", href: "https://bangladesh.gov.bd/", locationScope: "nationwide" },
  { number: "20", title: "বিনামূল্যে আইনগত সহায়তা (লিগ্যাল এইড)", tag: "সরকারি আইনগত সহায়তা", text: "যোগ্য ব্যক্তিরা সরকারি লিগ্যাল এইডের আবেদনপথ ও ১৬৪৩০ টোল-ফ্রি হেল্পলাইন সম্পর্কে জানুন; যোগ্যতা ও সিদ্ধান্ত কর্তৃপক্ষ নির্ধারণ করে।", href: "https://nlaso.gov.bd/", locationScope: "nationwide" },
  { number: "21", title: "প্রবাসী সেবা ও সহযোগিতা", tag: "প্রবাসী কল্যাণ", text: "বিদেশযাত্রার পূর্বপ্রস্তুতি, প্রবাসী কল্যাণ, অভিযোগ ও সরকারি সহায়তার official পথ খুঁজে নিন।", href: "https://probashi.gov.bd/", locationScope: "nationwide" },
  { number: "22", title: "বাংলাদেশ টেলিভিশন (BTV) সরকারি মিডিয়া", tag: "সরকারি মিডিয়া", text: "সরকারি অনুষ্ঠান, জনসচেতনতা, সংবাদ ও public-service content-এর official BTV পথ দেখুন।", href: "https://btv.gov.bd/", locationScope: "nationwide" },
  { number: "23", title: "বাংলাদেশ বেতার সরকারি রেডিও সেবা", tag: "সরকারি মিডিয়া", text: "সরকারি বেতার অনুষ্ঠান, তথ্য ও online media navigation-এর official source-এ যান।", href: "https://betar.gov.bd/", locationScope: "nationwide" },
  { number: "27", title: "সরকারি চাকরির অফিশিয়াল নিয়োগ বিজ্ঞপ্তি", tag: "official recruitment", text: "সরকারি চাকরির circular ও আবেদনপথের জন্য official recruitment portal দেখুন; প্রতিটি notice-এর শর্ত নিজে যাচাই করুন।", href: "https://alljobs.teletalk.com.bd/jobs/government", locationScope: "nationwide" },
  { number: "28", title: "বাংলাদেশ সরকারি কর্ম কমিশন (BPSC)", tag: "সরকারি নিয়োগ", text: "BCS ও PSC-সংক্রান্ত বিজ্ঞপ্তি, পরীক্ষা ও আবেদন-তথ্যের official source-এ পৌঁছান।", href: "https://bpsc.gov.bd/", locationScope: "nationwide" },
  { number: "29", title: "বাংলাদেশ টেলিকমিউনিকেশন্স কোম্পানি (BTCL)", tag: "BTCL সরকারি সেবা", text: "বাংলাদেশ টেলিকমিউনিকেশন্স কোম্পানি লিমিটেডের customer service, টেলিফোন/ইন্টারনেট এবং domain-related official পথ দেখুন।", href: "https://mybtcl.btcl.gov.bd/", locationScope: "nationwide" },
  { number: "30", title: "সরকারি পরিবহন ও যোগাযোগ (BRTC)", tag: "BRTC সেবা ডিরেক্টরি", text: "BRTC-এর পরিবহন, যোগাযোগ ও নাগরিক তথ্যের official portal-এ পৌঁছান।", href: "https://brtc.gov.bd/", locationScope: "nationwide" },
  ...newCivicServices,
];

const serviceShortcuts = [
  { label: "সব সেবা", query: "", hint: "৪০টি পথ", accent: "#006A4E", tint: "#E8F5E9" },
  { label: "থানা ও জরুরি সহায়তা", query: "থানা", hint: "নাগরিক সহায়তা", accent: "#0D47A1", tint: "#E1F5FE" },
  { label: "ভাতা ও সমাজসেবা", query: "ভাতা", hint: "৪টি পথ", accent: "#006A4E", tint: "#E8F5E9" },
  { label: "টিকেট ও যাতায়াত", query: "টিকেট", hint: "৩টি পথ", accent: "#1976D2", tint: "#E3F2FD" },
  { label: "BRTC সেবা", query: "brtc", hint: "বাস ও পরিবহন", accent: "#1976D2", tint: "#E3F2FD" },
  { label: "BTCL সেবা", query: "btcl", hint: "টেলিফোন, ইন্টারনেট ও ডোমেইন", accent: "#1565C0", tint: "#E3F2FD" },
  { label: "অনলাইন আবেদন", query: "অনলাইন", hint: "৩টি পথ", accent: "#D32F2F", tint: "#FFEBEE" },
  { label: "স্বাস্থ্য ও হাসপাতাল", query: "স্বাস্থ্য", hint: "৩টি পথ", accent: "#C62828", tint: "#FFEBEE" },
  { label: "অভিযোগের পথ", query: "অভিযোগ", hint: "২টি পথ", accent: "#D32F2F", tint: "#FFEBEE" },
  { label: "বিদ্যুৎ, গ্যাস ও পানি", query: "বিদ্যুৎ", hint: "৩টি পথ", accent: "#F57C00", tint: "#FFF3E0" },
  { label: "প্রবাসী সেবা", query: "প্রবাসী", hint: "কল্যাণ ও সহযোগিতা", accent: "#1976D2", tint: "#E3F2FD" },
  { label: "সরকারি মিডিয়া", query: "মিডিয়া", hint: "বিটিভি ও বেতার", accent: "#F57C00", tint: "#FFF3E0" },
  { label: "সরকারি চাকরি", query: "চাকরি", hint: "নিয়োগ বিজ্ঞপ্তি", accent: "#006A4E", tint: "#E8F5E9" },
];

const serviceShortcutsEn = [
  { label: "All services", query: "", hint: "40 pathways", accent: "#006A4E", tint: "#E8F5E9" },
  { label: "Police and emergency help", query: "police", hint: "Citizen support", accent: "#0D47A1", tint: "#E1F5FE" },
  { label: "Allowances and social services", query: "allowance", hint: "4 pathways", accent: "#006A4E", tint: "#E8F5E9" },
  { label: "Tickets and transport", query: "ticket", hint: "3 pathways", accent: "#1976D2", tint: "#E3F2FD" },
  { label: "BRTC services", query: "brtc", hint: "Bus and transport", accent: "#1976D2", tint: "#E3F2FD" },
  { label: "BTCL services", query: "btcl", hint: "Telephone, internet, and domains", accent: "#1565C0", tint: "#E3F2FD" },
  { label: "Online applications", query: "online", hint: "3 pathways", accent: "#D32F2F", tint: "#FFEBEE" },
  { label: "Health and hospitals", query: "health", hint: "3 pathways", accent: "#C62828", tint: "#FFEBEE" },
  { label: "Complaint pathways", query: "complaint", hint: "2 pathways", accent: "#D32F2F", tint: "#FFEBEE" },
  { label: "Electricity, gas, and water", query: "electricity", hint: "3 pathways", accent: "#F57C00", tint: "#FFF3E0" },
  { label: "Expatriate services", query: "expatriate", hint: "Welfare and support", accent: "#1976D2", tint: "#E3F2FD" },
  { label: "Government media", query: "media", hint: "BTV and Betar", accent: "#F57C00", tint: "#FFF3E0" },
  { label: "Government jobs", query: "jobs", hint: "Recruitment notices", accent: "#006A4E", tint: "#E8F5E9" },
];

const emergencyNumbers = [
  {
    number: "৯৯৯",
    phone: "999",
    title: "জাতীয় জরুরি সেবা",
    text: "জরুরি পুলিশ, ফায়ার সার্ভিস বা অ্যাম্বুলেন্স সহায়তার জন্য সংশ্লিষ্ট সরকারি হেল্পলাইনে যোগাযোগ করুন।",
    icon: Phone,
    officialHref: "https://www.police.gov.bd/en/hot_line_number",
    officialLabel: "পুলিশের অফিসিয়াল তথ্য",
  },
  {
    number: "১০২",
    phone: "102",
    title: "ফায়ার সার্ভিস",
    text: "আগুন, উদ্ধার বা ফায়ার সার্ভিস-সংক্রান্ত জরুরি সহায়তার জন্য ফায়ার সার্ভিসের hotline ব্যবহার করুন।",
    icon: Flame,
    officialHref: "https://fireservice.gov.bd/",
    officialLabel: "ফায়ার সার্ভিস পোর্টাল",
  },
  {
    number: "৩৩৩",
    phone: "333",
    title: "সরকারি তথ্য ও সেবা",
    text: "সরকারি তথ্য, সেবা ও নাগরিক সহায়তার বিষয়ে সংশ্লিষ্ট national helpline-এ যোগাযোগ করুন।",
    icon: Info,
    officialHref: "https://333.gov.bd/",
    officialLabel: "৩৩৩ অফিসিয়াল পোর্টাল",
  },
  {
    number: "১৬২৬৩",
    phone: "16263",
    title: "স্বাস্থ্য পরামর্শ",
    text: "স্বাস্থ্যসংক্রান্ত পরামর্শের জন্য DGHS health call centre-এর সরকারি hotline ব্যবহার করুন।",
    icon: HeartPulse,
    officialHref: "https://dghs.gov.bd/",
    officialLabel: "DGHS অফিসিয়াল পোর্টাল",
  },
];

const scheduledBankCategories = [
  { label: "রাষ্ট্রীয় মালিকানাধীন বাণিজ্যিক", count: "৭টি" },
  { label: "বিশেষায়িত", count: "৩টি" },
  { label: "বেসরকারি বাণিজ্যিক", count: "৪৩টি" },
  { label: "ডিজিটাল বাণিজ্যিক", count: "১টি" },
  { label: "বিদেশি বাণিজ্যিক", count: "৯টি" },
];

const nonScheduledBanks = "Ansar VDP Unnayan Bank, Karmashangosthan Bank, Grameen Bank, Jubilee Bank ও Palli Sanchay Bank";
const bangladeshBankDirectoryUrl = "https://www.bb.org.bd/en/index.php/financialactivity/bankfi";

const healthcareContacts = [
  {
    icon: HeartPulse,
    kicker: "হাসপাতাল খোঁজার official পথ",
    title: "DGHS Facility Registry",
    text: "সরকারি ও তালিকাভুক্ত healthcare facility খুঁজতে division/district ভিত্তিক official registry ব্যবহার করুন।",
    href: "https://hrm.dghs.gov.bd/public/facility-registry",
    linkLabel: "হাসপাতাল directory খুলুন",
  },
  {
    icon: Phone,
    kicker: "অ্যাম্বুলেন্স তথ্য ভাণ্ডার",
    title: "লোকেশনভিত্তিক অ্যাম্বুলেন্স তথ্য",
    text: "DGHS-linked ambulance directory-তে facility ও location-based তথ্য দেখুন। access বা mobile verification চাইতে পারে।",
    href: "https://16263.dghs.gov.bd/ambulance/ambulance/index.php",
    linkLabel: "অ্যাম্বুলেন্স directory খুলুন",
  },
  {
    icon: Info,
    kicker: "স্বাস্থ্য পরামর্শ",
    title: "১৬২৬৩ স্বাস্থ্য বাতায়ন",
    text: "স্বাস্থ্য পরামর্শ ও সংশ্লিষ্ট সরকারি health information-এর জন্য DGHS health call centre-এর official পথ ব্যবহার করুন।",
    href: "https://dghs.gov.bd/",
    phone: "16263",
    linkLabel: "DGHS portal খুলুন",
  },
];

const civicGuides = [
  {
    icon: Info,
    kicker: "সরকারি মিডিয়া",
    title: "বিটিভি ও বাংলাদেশ বেতার",
    text: "সরকারি অনুষ্ঠান, জনসচেতনতা, সংবাদ ও online media navigation-এর official source একসঙ্গে দেখুন।",
    links: [
      { label: "বিটিভি", href: "https://btv.gov.bd/" },
      { label: "বাংলাদেশ বেতার", href: "https://betar.gov.bd/" },
    ],
  },
  {
    icon: ShieldCheck,
    kicker: "সরকারি চাকরি",
    title: "নিয়োগ বিজ্ঞপ্তির official পথ",
    text: "সরকারি চাকরির circular, eligibility ও আবেদন-নির্দেশনা প্রতিটি official notice থেকে নিজে যাচাই করুন।",
    links: [
      { label: "Alljobs government", href: "https://alljobs.teletalk.com.bd/jobs/government" },
      { label: "BPSC portal", href: "https://bpsc.gov.bd/" },
    ],
  },
];

const emergencyEnglishCopy: Record<string, { number: string; title: string; text: string; officialLabel: string }> = {
  "999": { number: "999", title: "National emergency service", text: "Contact the relevant government helpline for urgent police, fire, or ambulance assistance.", officialLabel: "Police official information" },
  "102": { number: "102", title: "Fire Service", text: "Use the Fire Service hotline for urgent fire, rescue, or fire-service assistance.", officialLabel: "Fire Service portal" },
  "333": { number: "333", title: "Government information and services", text: "Contact the national helpline for government information, services, and citizen support.", officialLabel: "333 official portal" },
  "16263": { number: "16263", title: "Health advice", text: "Use the DGHS health call centre hotline for government health advice.", officialLabel: "DGHS official portal" },
};

const healthcareEnglishCopy: Record<string, { kicker: string; title: string; text: string; linkLabel: string }> = {
  "https://hrm.dghs.gov.bd/public/facility-registry": { kicker: "Official hospital directory", title: "DGHS Facility Registry", text: "Use the official division- and district-based registry to find listed healthcare facilities.", linkLabel: "Open hospital directory" },
  "https://16263.dghs.gov.bd/ambulance/ambulance/index.php": { kicker: "Ambulance information", title: "Location-based ambulance information", text: "View facility and location-based information in the DGHS-linked ambulance directory. Access or mobile verification may be required.", linkLabel: "Open ambulance directory" },
  "https://dghs.gov.bd/": { kicker: "Health advice", title: "16263 health portal", text: "Use the official DGHS health call centre for health advice and related government information.", linkLabel: "Open DGHS portal" },
};

const verifiedGovernmentHospitals = [
  {
    nameBn: "ঢাকা মেডিকেল কলেজ হাসপাতাল",
    nameEn: "Dhaka Medical College Hospital",
    addressBn: "সচিবালয় রোড, ঢাকা",
    addressEn: "Secretariat Road, Dhaka",
  },
  {
    nameBn: "কুর্মিটোলা জেনারেল হাসপাতাল",
    nameEn: "Kurmitola General Hospital",
    addressBn: "নিউ এয়ারপোর্ট রোড, কুর্মিটোলা, ঢাকা ক্যান্টনমেন্ট, ঢাকা-১২০৬",
    addressEn: "New Airport Road, Kurmitola, Dhaka Cantonment, Dhaka-1206",
  },
  {
    nameBn: "সিলেট এম এ জি ওসমানী মেডিকেল কলেজ হাসপাতাল",
    nameEn: "Sylhet MAG Osmani Medical College Hospital",
    addressBn: "মেডিকেল রোড, কাজলশাহ, সিলেট",
    addressEn: "Medical Road, Kajolshah, Sylhet",
  },
] as const;

const dghsFacilityRegistryUrl = "https://hrm.dghs.gov.bd/public/facility-registry";

const civicEnglishCopy: Record<string, { kicker: string; title: string; text: string; links: Record<string, string> }> = {
  "বিটিভি ও বাংলাদেশ বেতার": { kicker: "Government media", title: "BTV and Bangladesh Betar", text: "Find official sources for government programmes, public awareness, news, and online media navigation in one place.", links: { "বিটিভি": "BTV", "বাংলাদেশ বেতার": "Bangladesh Betar" } },
  "নিয়োগ বিজ্ঞপ্তির official পথ": { kicker: "Government jobs", title: "Official recruitment notices", text: "Verify government job circulars, eligibility, and application instructions directly from each official notice.", links: { "Alljobs government": "Alljobs government", "BPSC portal": "BPSC portal" } },
};

const paidAssistanceItemsEn = [
  { serial: "01", title: "NID new application or correction", price: "Discussed in advance", desc: "Support for new applications, corrections, and duplicate cards." },
  { serial: "02", title: "E-passport application", price: "Discussed in advance", desc: "Support for new or re-issue applications and form completion." },
  { serial: "03", title: "Birth registration", price: "Discussed in advance", desc: "Support for new applications or information corrections." },
  { serial: "04", title: "Trade licence", price: "Discussed in advance", desc: "Support for online applications and document preparation." },
  { serial: "05", title: "Police clearance", price: "Discussed in advance", desc: "Support with forms, information checks, and application completion." },
  { serial: "06", title: "Driving licence application", price: "Discussed in advance", desc: "Support for learner, test, and smart-card applications." },
  { serial: "07", title: "BSTI application support", price: "Discussed in advance", desc: "Support for BSTI certification or approval applications and documents." },
  { serial: "08", title: "Passport status check", price: "Discussed in advance", desc: "Check Police Verification, Printing, and Ready status." },
  { serial: "09", title: "Old-age or widow allowance", price: "Discussed in advance", desc: "Support for applications under social safety-net programmes." },
  { serial: "10", title: "Land record or porcha collection", price: "Discussed in advance", desc: "Find land records and collect online copies." },
  { serial: "11", title: "Electricity bill or new connection", price: "Discussed in advance", desc: "Online support for bills, complaints, or new connections." },
  { serial: "12", title: "eTIN certificate", price: "Discussed in advance", desc: "Support for eTIN registration and certificate download." },
  { serial: "13", title: "Vaccination certificate download", price: "Discussed in advance", desc: "Information checks and online vaccination certificate download." },
  { serial: "14", title: "Rural electricity service", price: "Discussed in advance", desc: "Online support for bills, complaints, or new connections." },
  { serial: "15", title: "BMET registration and smart card", price: "Discussed in advance", desc: "Support for BMET registration and expatriate smart-card applications." },
];

export default function Home() {
  // The useAuth hook provides authentication state.
  // To implement login/logout, call logout(), or start login from an event
  // handler: onClick={() => startLogin()} (imported from "@/const"). Never call
  // startLogin() during render (no href={startLogin()}) — it mints a one-time
  // nonce cookie and must run only at the moment of navigation.
  let { user, loading, error, isAuthenticated, logout } = useAuth();
  const { language } = useLanguage();
  const isEnglish = language === "EN";
  const localizedServiceShortcuts = isEnglish ? serviceShortcutsEn : serviceShortcuts;
  const localizedEmergencyNumbers = isEnglish
    ? emergencyNumbers.map((item) => ({ ...item, ...emergencyEnglishCopy[item.phone] }))
    : emergencyNumbers;
  const localizedHealthcareContacts = isEnglish
    ? healthcareContacts.map((item) => ({ ...item, ...healthcareEnglishCopy[item.href] }))
    : healthcareContacts;
  const localizedCivicGuides = isEnglish
    ? civicGuides.map((guide) => {
        const copy = civicEnglishCopy[guide.title];
        return copy ? { ...guide, kicker: copy.kicker, title: copy.title, text: copy.text, links: guide.links.map((link) => ({ ...link, label: copy.links[link.label] ?? link.label })) } : guide;
      })
    : civicGuides;
    const copy = getLanguageCopy(language);
  const homeUi = isEnglish ? {
    civicSafety: "Verify safely:",
    civicSafetyText: "If anyone asks for money, OTP, or a password for a job, expatriate service, or government benefit, compare the official domain and notice conditions before proceeding.",
    trustStamp: <>SOURCE<br />VERIFIED</>,
    trustNumber: "04 / TRUST RULES",
    trustTitle: <>Separate the information,<br /><em>make trust visible.</em></>,
    trustText: "Official website links are marked separately, and the last verification date for each information item will remain visible.",
    feedback: "Share your feedback",
    supportNumber: "05 / TRANSPARENT SUPPORT",
    supportTitle: <>Good service,<br /><em>moving forward honestly.</em></>,
    supportIntro: "SahajContact may add advertising, approved partners, and optional support in the future. Commercial and informational items will always be clearly identified.",
    supportPotential: "Potential income",
    supportAds: "Advertising and sponsorship",
    supportAdsText: "A separate, clearly marked space may be kept for local organisations or responsible advertisers.",
    supportAdsStatus: "Reserved space · advertising is not active",
    supportPartner: "Approved partner",
    supportTickets: "Tickets and referrals",
    supportTicketsText: "If approved air, rail, or bus ticket partners are added, the commission policy will be disclosed in advance.",
    supportPartnerStatus: "Partner link required",
    supportOptional: "Optional support",
    supportKeepRunning: "Help keep the service running",
    supportKeepRunningText: "Users may support the continuity of this information service. No payment is active yet.",
    supportTellUs: "Tell us about support",
    supportNote: "Safety note: there is no additional fee for government-service information. If paid support becomes active, the price and terms will be disclosed in advance.",
    faqLabel: "FAQ / FREQUENTLY ASKED QUESTIONS",
    faqTitle: <>Questions<br /><em>you may often have.</em></>,
    faqIntro: "Here are answers to common questions about SahajContact information use and safety.",
    faq1q: "1. Is SahajContact a government website?",
    faq1a: "No. SahajContact is not a government office or portal. It is an independent citizen-information platform that helps you find the correct official website and understand public processes.",
    faq2q: "2. Do you charge government fees?",
    faq2a: "No. We do not collect government fees or provide paid assistance. If a government fee applies, pay it only through the relevant official portal.",
    faq3q: "3. How can I ask a question?",
    faq3a: "Use the Contact page for a general question. SahajContact does not operate online payment, personal-account payment instructions, payment confirmation, or receipt services.",
    faq4q: "4. When will I hear back?",
    faq4a: "The Contact page records no promise of a callback, response time, service completion, or application outcome.",
    contactNumber: "05 / TALK TO US",
    contactTitle: <>Your words<br /><em>can make the path clearer.</em></>,
    contactButton: "Go to contact page",
    officeNumber: "06 / OUR LOCATION & CONTACT",
    officeTitle: "Visit or contact SahajContact",
    officeMapTitle: "SahajContact office map at Tiara Bazar",
    officeLocation: "Village: Tiara Bazar, Union: Bitghar, Police Station: Nabinagar, District: Brahmanbaria, Bangladesh",
    officeDescription: "Our support is Bangladesh-focused. The map below shows our office location. Please confirm a convenient time by phone before visiting.",
    officeContactHeading: "Contact person",
    officeName: "Name: Kazi Amir Hamja",
    officeFather: "Father: Zainal Abedin",
    officePhoneLabel: "Phone",
    officeEmailLabel: "Email",
    officeDirections: "Open location in Google Maps",
    officeCall: "Call now",
    officeEmail: "Email now",
    storyNumber: "06 / YOUR STORY",
    storyTitle: <>Your story<br /><em>can make someone else’s path easier.</em></>,
    storyIntro: "Tell us about a real experience. A story will be considered for publication only after review and approval—there are no demo or fabricated testimonials here.",
    storyWrite: "Write about your experience",
    storyWriteText: "Briefly tell us which official link or guide helped you.",
    privacyFirst: "Privacy first",
    privacyText: "Do not send NID, passwords, OTPs, or unnecessary personal information.",
    storyShare: "Share after verification",
    storyShareText: "After your consent and the necessary checks, your story may be considered for publication.",
    shareStory: "Share your story",
    partnersLabel: "Official digital service partners of SahajContact",
    partnersTitle: "SahajContact’s official digital service partners",
    paymentPartner: "Payment partner",
    digitalTransactions: "Digital transactions",
    remittanceService: "Remittance service",
    connectivityPartner: "Connectivity partner",
    partnersDisclaimer: "These services are operated by the respective organisations. SahajContact only provides information.",
    applicationLabel: "SahajContact application",
    applicationTitle: "Apply for a service",
    selectedService: "Selected service:",
    submittedTitle: "Application submitted successfully!",
    submittedText: "Your name and phone number were saved successfully and a notification was sent to the responsible team. Our team will contact you soon.",
    close: "Close",
    nameLabel: "Your name (Name) *",
    namePlaceholder: "Example: Md. Rahim Uddin",
    phoneLabel: "Mobile number (Phone) *",
    serviceNeeded: "Requested service (Service Needed)",
    cancel: "Cancel",
    submitting: "Submitting...",
    submitApplication: "Submit application",
    dataNote: "Your information will be sent securely to the responsible team.",
    invalidApplication: "Please enter your name and phone number.",
    applicationError: "There was a problem submitting the application: ",
  } : {
    civicSafety: "নিরাপদে যাচাই করুন:", civicSafetyText: "চাকরি, প্রবাসী সেবা বা কোনো সরকারি সুবিধার জন্য টাকা/OTP/পাসওয়ার্ড চাওয়া হলে official domain ও notice-এর শর্ত মিলিয়ে নিন.",
    trustStamp: <>উৎস যাচাই<br />জরুরি</>, trustNumber: "04 / বিশ্বাসের নিয়ম", trustTitle: <>তথ্যকে আলাদা করি,<br /><em>বিশ্বাসকে দৃশ্যমান করি।</em></>, trustText: "সরকারি ওয়েবসাইটের লিংক আলাদা চিহ্নে দেখানো হবে এবং তথ্য সর্বশেষ কবে দেখা হয়েছে, তা প্রকাশ্যে থাকবে।", feedback: "আপনার মতামত জানান",
    supportNumber: "05 / স্বচ্ছ সহযোগিতা", supportTitle: <>ভালো সেবা,<br /><em>সৎভাবে এগিয়ে যাক।</em></>, supportIntro: "সাহজসেবা পরিচালনায় ভবিষ্যতে বিজ্ঞাপন, অনুমোদিত পার্টনার ও ঐচ্ছিক সহায়তা যুক্ত হতে পারে। কোনটি বাণিজ্যিক এবং কোনটি তথ্য—তা স্পষ্টভাবে জানানো হবে।", supportPotential: "সম্ভাব্য আয়", supportAds: "বিজ্ঞাপন ও স্পনসরশিপ", supportAdsText: "স্থানীয় প্রতিষ্ঠান বা দায়িত্বশীল বিজ্ঞাপনদাতার জন্য আলাদা, পরিষ্কারভাবে চিহ্নিত জায়গা রাখা যেতে পারে।", supportAdsStatus: "প্রস্তুত স্থান · বিজ্ঞাপন এখনো চালু নয়", supportPartner: "অনুমোদিত পার্টনার", supportTickets: "টিকিট ও রেফারেল", supportTicketsText: "এয়ার, রেল বা বাস টিকিটের জন্য অনুমোদিত পার্টনারের লিংক যোগ করা হলে কমিশনের নিয়ম আগেই জানানো হবে।", supportPartnerStatus: "পার্টনার লিংক প্রয়োজন", supportOptional: "ঐচ্ছিক সহযোগিতা", supportKeepRunning: "সেবা সচল রাখতে সহায়তা", supportKeepRunningText: "ব্যবহারকারী চাইলে সাইটের তথ্যসেবা সচল রাখতে সহায়তা করতে পারেন। কোনো অর্থপ্রদান এখনো সক্রিয় করা হয়নি।", supportTellUs: "সহযোগিতা সম্পর্কে জানান", supportNote: "নিরাপত্তা নোট: সরকারি সেবার তথ্যের জন্য কোনো অতিরিক্ত ফি নয়; পেইড সহায়তা চালু হলে আগে থেকেই মূল্য ও শর্ত জানানো হবে।",
    faqLabel: "FAQ / সাধারণ জিজ্ঞাসা", faqTitle: <>আপনার মনে প্রায়ই আসত<br /><em>যে প্রশ্নগুলো।</em></>, faqIntro: "সহজ জনসেবা পোর্টালের তথ্য ব্যবহার ও নিরাপত্তা সংক্রান্ত সাধারণ কিছু প্রশ্নের উত্তর নিচে দেওয়া হলো।", faq1q: "১. সহজ জনসেবা কি কোনো সরকারি ওয়েবসাইট?", faq1a: "না। সহজ জনসেবা কোনো সরকারি অফিস বা পোর্টাল নয়। এটি একটি স্বাধীন নাগরিক তথ্যপ্ল্যাটফর্ম যা সঠিক সরকারি ওয়েবসাইট খুঁজে পেতে এবং ফর্ম ও প্রক্রিয়া বুঝতে সাহায্য করে।", faq2q: "২. আপনারা কি সরকারি ফি নেন?", faq2a: "না। আমরা কোনো সরকারি ফি সংগ্রহ করি না এবং কোনো পেইড সহায়তা দিই না। সরকারি ফি থাকলে কেবল সংশ্লিষ্ট সরকারি পোর্টালেই পরিশোধ করুন।", faq3q: "৩. সাধারণ প্রশ্ন কীভাবে পাঠাব?", faq3a: "সাধারণ প্রশ্নের জন্য Contact পেজ ব্যবহার করুন। SahajContact-এ online payment, personal-account payment instruction, payment confirmation বা receipt service চালু নেই।", faq4q: "৪. কখন উত্তর পাব?", faq4a: "Contact পেজে কোনো কলব্যাক, উত্তর দেওয়ার সময়, সেবা সম্পন্ন হওয়া বা আবেদনের ফলাফলের নিশ্চয়তা দেওয়া হয় না।",
    contactNumber: "05 / কথা বলুন", contactTitle: <>আপনার কথায়<br /><em>পথ আরও পরিষ্কার হবে।</em></>, contactButton: "যোগাযোগ পেজে যান",
    officeNumber: "06 / আমাদের অবস্থান ও যোগাযোগ",
    officeTitle: "সাহজসেবার সঙ্গে দেখা করুন বা যোগাযোগ করুন",
    officeMapTitle: "টিয়ারা বাজারে সাহজসেবার অফিসের মানচিত্র",
    officeLocation: "গ্রাম: টিয়ারা বাজার, ইউনিয়ন: বিটঘর, থানা: নবীনগর, জেলা: ব্রাহ্মণবাড়িয়া, বাংলাদেশ",
    officeDescription: "আমাদের সহায়তা বাংলাদেশ-কেন্দ্রিক। নিচের মানচিত্রে আমাদের অফিসের অবস্থান দেখানো হয়েছে। দেখা করার আগে ফোনে সময় নিশ্চিত করে নিন।",
    officeContactHeading: "যোগাযোগের ব্যক্তি",
    officeName: "নাম: কাজী মোঃ আমির হামজা",
    officeFather: "পিতা: জয়নাল আবেদীন",
    officePhoneLabel: "ফোন",
    officeEmailLabel: "ইমেইল",
    officeDirections: "Google Maps-এ অবস্থান খুলুন",
    officeCall: "ফোন করুন",
    officeEmail: "ইমেইল করুন", storyNumber: "06 / আপনার গল্প", storyTitle: <>আপনার গল্প<br /><em>অন্যের পথ সহজ করতে পারে।</em></>, storyIntro: "বাস্তব অভিজ্ঞতা আমাদের জানান। যাচাই ও অনুমোদনের পরই কোনো গল্প প্রকাশ করা হবে—এই মুহূর্তে এখানে কোনো ডেমো বা বানানো testimonial দেখানো হচ্ছে না।", storyWrite: "আপনার অভিজ্ঞতা লিখুন", storyWriteText: "কোন সরকারি লিংক বা গাইড আপনার কাজে লেগেছে, সংক্ষেপে জানান।", privacyFirst: "গোপনীয়তা আগে", privacyText: "NID, পাসওয়ার্ড, OTP বা অপ্রয়োজনীয় ব্যক্তিগত তথ্য পাঠাবেন না।", storyShare: "যাচাইয়ের পর শেয়ার", storyShareText: "আপনার সম্মতি ও প্রয়োজনীয় যাচাই শেষ হলে গল্পটি প্রকাশের জন্য বিবেচনা করা হবে।", shareStory: "আপনার গল্প শেয়ার করুন", partnersLabel: "অফিসিয়াল ডিজিটাল সেবা পার্টনার", partnersTitle: "SahajContact এর অফিসিয়াল ডিজিটাল সেবা পার্টনার", paymentPartner: "পেমেন্ট পার্টনার", digitalTransactions: "ডিজিটাল লেনদেন", remittanceService: "রেমিট্যান্স সেবা", connectivityPartner: "কানেক্টিভিটি পার্টনার", partnersDisclaimer: "এই সেবাগুলো সংশ্লিষ্ট প্রতিষ্ঠান কর্তৃক পরিচালিত। SahajContact শুধু তথ্য প্রদান করে।", applicationLabel: "সহজসেবা আবেদন", applicationTitle: "সেবার জন্য আবেদন করুন", selectedService: "নির্বাচিত সেবা:", submittedTitle: "আবেদন সফলভাবে জমা হয়েছে!", submittedText: "আপনার নাম ও ফোন নম্বর সফলভাবে সংরক্ষিত হয়েছে এবং দায়িত্বপ্রাপ্ত টিমকে নোটিফিকেশন পাঠানো হয়েছে। খুব শীঘ্রই আমাদের টিম আপনার সাথে যোগাযোগ করবে।", close: "বন্ধ করুন", nameLabel: "আপনার নাম (Name) *", namePlaceholder: "যেমন: মো. রহিম উদ্দিন", phoneLabel: "মোবাইল নম্বর (Phone) *", serviceNeeded: "কাঙ্ক্ষিত সেবা (Service Needed)", cancel: "বাতিল", submitting: "জমা হচ্ছে...", submitApplication: "আবেদন জমা দিন", dataNote: "আপনার তথ্য সুরক্ষিতভাবে দায়িত্বপ্রাপ্ত টিমের কাছে পাঠানো হবে।", invalidApplication: "দয়া করে আপনার নাম ও ফোন নম্বর লিখুন।", applicationError: "আবেদন জমা দিতে সমস্যা হয়েছে: ",
  };
  const homeFlowUi = isEnglish ? {
    touristBadge: "EXPLORE BEAUTIFUL BANGLADESH",
    touristHeading: "Hills, sea, the Sundarbans and arriving Bangladesh by land",
    touristText: "Explore Bangladesh tourism and land-arrival information. Before travelling, verify current entry and journey guidance with the relevant government or official source.",
    touristButton: "Choose your preferred destination",
    touristWhatsapp: "Send a travel question via Contact",
    touristSpots: "Top tourist spots",
    landPorts: "Land-arrival guidance",
    howToNumber: "EASY START / 3 STEPS",
    howToHeading: <>Reach the right service in<br /><em>three simple steps.</em></>,
    howToIntro: "SahajContact guides you to government information and official portals. Choose the service you need and submit your information only to the relevant official destination.",
    step1: "01", step1Title: "Write what you need", step1Text: "Type words such as “rail ticket”, “old-age allowance”, or your own need in the service search box.", step1Link: "Go to the service list",
    step2: "02", step2Title: "Verify the source", step2Text: "Selecting the arrow on a card opens the relevant government or official portal in a new tab.", step2Status: "Prefer the official route",
    step3: "03", step3Title: "Finish safely", step3Text: "Follow the government portal’s instructions. Never share an OTP, password, or NID information with an unknown person.", step3Link: "Get help or share feedback",
    howToNoteStrong: "What does SahajContact do?", howToNote: "We show the way and take you to the official source; we do not guarantee government approval, application results, or payment outcomes.",
    servicesNumber: "01 / CIVIC PATH", servicesTitle: <>Start where<br /><em>you need to go.</em></>, servicesIntro: "Police, administration, rights, social services, legal aid, allowances, utilities, and transport are arranged clearly so the next step is easy to understand.",
    shortcutsTitle: "Quick paths", shortcutsIntro: "Choose the department closest to your need.", locationKicker: "Search by area", locationTitle: "Choose your district and upazila", currentPath: "Current path:", district: "District", allDistricts: "All districts", upazila: "Upazila", allUpazilas: "All upazilas", union: "Union / ward", unionPlaceholder: "Enter a name", chooseUpazila: "Choose an upazila first", resetFilters: "Clear filters", selectDistrict: "Select a district", selectUpazila: "Select an upazila",
    unionReady: (query: string, location: string) => query ? `Local paths for “${query}” in ${location} are shown here. Verify the correct office and address in the National Information Portal directory.` : "Enter a union or ward name to remember the local context; verify the office name and address in the official directory.",
    unionLocked: "Choose a district and upazila first to search for a union or ward. The official union list is available through the National Information Portal.", officialUnion: "Official union directory", searchLabel: "Find the service you need", searchPlaceholder: "Example: rail ticket, DC office, or electricity", searchClear: "Clear search", searchHint: "Type a name, topic, or service type to filter the list.", serviceCount: (count: number) => `${count} service${count === 1 ? "" : "s"}`, routeGuide: "Route", routeGuideText: "From your need to the official portal", categoryPrefix: "SERVICE CATEGORY /", categoryCount: (count: number) => `${count} item${count === 1 ? "" : "s"}`, officialPortal: "Official government portal", visit: "Visit", info: "Information", apply: "Apply now", emptyTitle: "No service was found for this search.", emptyText: "Try “legal aid”, “rail ticket”, “DC office”, “electricity”, or “old-age allowance”.",
    emergencyNumber: "02 / EMERGENCY PATH", emergencyHeading: "Contact emergency services quickly", emergencyHint: "Open this folder to view emergency numbers", emergencyIntro: "In an emergency, do not lose time on SahajContact—call the relevant government hotline directly. The numbers below are arranged with official-source pathways.", call: "Call", emergencyWarning: "SahajContact is not an emergency dispatcher, police, fire, ambulance, or medical service provider. Number availability, service scope, and call charges may vary by operator or situation. Follow the relevant government authority’s instructions in an emergency.",
    healthcareNumber: "03 / HEALTHCARE PATH", healthcareTitle: <>Find nearby healthcare<br /><em>through the official route.</em></>, healthcareIntro: "Use the DGHS official directory to find local hospitals, healthcare facilities, and ambulances. SahajContact does not guarantee facility availability, beds, fares, or response times.", call16263: "Call 16263", healthcareUsageStrong: "How to use:", healthcareUsage: "The ambulance directory may request registration or mobile verification. In an immediate life-threatening situation, contact 999 first; do not use the healthcare directory as an emergency dispatcher. Information changes, so verify the latest details at the official source.",
    civicNumber: "04 / MORE OFFICIAL PATHS", civicTitle: <>Support beyond borders,<br /><em>and support at home.</em></>, civicIntro: "Go directly to the relevant official portal for expatriate welfare, government media, and job notices. SahajContact only shows the way; applications, recruitment, and benefit decisions belong to the relevant authorities.",
  } : {
    touristBadge: "ঘুরে দেখুন সুন্দর বাংলাদেশ", touristHeading: "পাহাড়, সমুদ্র, সুন্দরবন ও বাংলাদেশে স্থলপথে আসার গাইড", touristText: "বাংলাদেশের টুরিস্ট স্পট ও স্থলপথে আগমনের তথ্য দেখুন। যাত্রার আগে প্রবেশসংক্রান্ত বর্তমান নির্দেশনা সংশ্লিষ্ট সরকারি বা অফিসিয়াল উৎসে মিলিয়ে নিন।", touristButton: "বাংলাদেশ ভ্রমণের জন্য আপনার পছন্দের স্থান বেছে নিন", touristWhatsapp: "ভ্রমণ-প্রশ্নে যোগাযোগ পেজ", touristSpots: "সেরা টুরিস্ট স্পট", landPorts: "স্থলপথে বাংলাদেশে আসার গাইড",
    howToNumber: "সহজ শুরু / ৩ ধাপ", howToHeading: <>সঠিক সেবায়<br /><em>তিনটি সহজ ধাপ।</em></>, howToIntro: "সাহজসেবা আপনাকে সরকারি তথ্য ও অফিসিয়াল পোর্টালের পথে নিয়ে যায়। প্রয়োজনীয় সেবা বেছে নিয়ে নিজের তথ্য নিরাপদে সংশ্লিষ্ট সরকারি জায়গাতেই দিন।", step1: "০১", step1Title: "প্রয়োজন লিখুন", step1Text: "সেবা খোঁজার ঘরে “রেল টিকেট”, “বয়স্ক ভাতা” বা আপনার প্রয়োজনের শব্দ লিখুন।", step1Link: "সেবা তালিকায় যান", step2: "০২", step2Title: "উৎস মিলিয়ে নিন", step2Text: "কার্ডের তীর চিহ্নে চাপলে সংশ্লিষ্ট সরকারি বা অফিসিয়াল পোর্টাল নতুন ট্যাবে খুলবে।", step2Status: "অফিসিয়াল পথকে অগ্রাধিকার দিন", step3: "০৩", step3Title: "নিরাপদে কাজ শেষ করুন", step3Text: "সরকারি পোর্টালের নির্দেশনা অনুসরণ করুন। OTP, পাসওয়ার্ড বা NID তথ্য অচেনা কারও সঙ্গে শেয়ার করবেন না।", step3Link: "সহায়তা বা মতামত দিন", howToNoteStrong: "সাহজসেবা কী করে?", howToNote: "আমরা পথ দেখাই ও official source-এ পৌঁছে দিই; কোনো সরকারি অনুমোদন, আবেদন-ফল বা পেমেন্টের নিশ্চয়তা দিই না।",
    servicesNumber: "01 / নাগরিক পথ", servicesTitle: <>যা দরকার,<br /><em>সেখানেই শুরু।</em></>, servicesIntro: "থানা, প্রশাসন, অধিকার, সমাজসেবা, লিগ্যাল এইড, ভাতা, ইউটিলিটি ও যাতায়াত—প্রতিটি পথ পরিষ্কারভাবে সাজানো, যাতে পরের ধাপটি বুঝতে সহজ হয়।", shortcutsTitle: "দ্রুত পথ", shortcutsIntro: "আপনার প্রয়োজনের কাছাকাছি বিভাগ বেছে নিন।", locationKicker: "এলাকা অনুযায়ী খুঁজুন", locationTitle: "আপনার জেলা ও উপজেলা বেছে নিন", currentPath: "বর্তমান পথ:", district: "জেলা", allDistricts: "সব জেলা", upazila: "উপজেলা", allUpazilas: "সব উপজেলা", union: "ইউনিয়ন / ওয়ার্ড", unionPlaceholder: "নাম লিখুন", chooseUpazila: "আগে উপজেলা বাছুন", resetFilters: "ফিল্টার মুছুন", selectDistrict: "জেলা নির্বাচন করুন", selectUpazila: "উপজেলা নির্বাচন করুন",
    unionReady: (query: string, location: string) => query ? `“${query}” ইউনিয়ন/ওয়ার্ডের জন্য ${location}-এর স্থানীয় পথ দেখানো হচ্ছে। সঠিক অফিস ও ঠিকানা জাতীয় তথ্য বাতায়নের তালিকায় মিলিয়ে নিন।` : "ইউনিয়ন বা ওয়ার্ডের নাম লিখে স্থানীয় কাজের প্রসঙ্গ মনে রাখুন; সঠিক অফিসের নাম ও ঠিকানা official তালিকায় যাচাই করুন.", unionLocked: "ইউনিয়ন বা ওয়ার্ড খুঁজতে আগে জেলা ও উপজেলা বেছে নিন। ইউনিয়নের সরকারি তালিকা জাতীয় তথ্য বাতায়নে খোলা যাবে।", officialUnion: "অফিসিয়াল ইউনিয়ন তালিকা", searchLabel: "আপনার প্রয়োজনীয় সেবা খুঁজুন", searchPlaceholder: "যেমন: রেল টিকেট, ডিসি অফিস বা বিদ্যুৎ", searchClear: "সার্চ মুছে ফেলুন", searchHint: "নাম, বিষয় বা সেবার ধরন লিখলেই তালিকা ছেঁকে দেখাবে।", serviceCount: (count: number) => `${count}টি সেবা`, routeGuide: "পথচিহ্ন", routeGuideText: "প্রয়োজন থেকে official পোর্টাল পর্যন্ত", categoryPrefix: "সেবা বিভাগ /", categoryCount: (count: number) => `${count}টি`, officialPortal: "অফিসিয়াল সরকারি পোর্টাল", visit: "ভিজিট", info: "তথ্য", apply: "আবেদন করুন", emptyTitle: "এই নামে কোনো সেবা পাওয়া যায়নি।", emptyText: "“লিগ্যাল এইড”, “রেল টিকেট”, “ডিসি অফিস”, “বিদ্যুৎ” বা “বয়স্ক ভাতা” লিখে আবার চেষ্টা করুন।",
    emergencyNumber: "02 / জরুরি পথ", emergencyHeading: "জরুরী সময় দ্রুত যোগাযোগ করুন", emergencyHint: "জরুরি নম্বরগুলো দেখতে ফোল্ডারটি খুলুন", emergencyIntro: "জরুরি পরিস্থিতিতে সাহজসেবা দেখে সময় নষ্ট না করে সংশ্লিষ্ট সরকারি hotline-এ সরাসরি ফোন করুন। নিচের নম্বরগুলো official source-এর পথসহ সাজানো হয়েছে।", call: "ফোন করুন", emergencyWarning: "সাহজসেবা নিজে কোনো emergency dispatch, পুলিশ, ফায়ার, অ্যাম্বুলেন্স বা চিকিৎসা সেবা প্রদানকারী নয়। নম্বরের availability, service scope ও call charge অপারেটর বা পরিস্থিতি অনুযায়ী বদলাতে পারে—জরুরি অবস্থায় সংশ্লিষ্ট সরকারি কর্তৃপক্ষের নির্দেশনা অনুসরণ করুন।",
    healthcareNumber: "03 / স্বাস্থ্যপথ", healthcareTitle: <>কাছের স্বাস্থ্যসেবা,<br /><em>official পথে খুঁজুন।</em></>, healthcareIntro: "স্থানীয় হাসপাতাল, healthcare facility ও অ্যাম্বুলেন্সের তথ্য খুঁজতে DGHS-এর official directory-তে যান। সাহজসেবা কোনো facility-এর availability, bed, fare বা response time নিশ্চিত করে না।", call16263: "১৬২৬৩-এ ফোন", healthcareUsageStrong: "ব্যবহারের নিয়ম:", healthcareUsage: "ambulance directory-তে registration বা mobile verification চাইতে পারে। তাৎক্ষণিক জীবনঝুঁকিতে আগে ৯৯৯-এ যোগাযোগ করুন; healthcare directory-কে emergency dispatch হিসেবে ব্যবহার করবেন না। তথ্য পরিবর্তনশীল—official source-এ সর্বশেষ তথ্য মিলিয়ে নিন।",
    civicNumber: "04 / আরও কিছু official পথ", civicTitle: <>দেশের বাইরে,<br /><em>দেশের ভেতরেও সহায়তা।</em></>, civicIntro: "প্রবাসী কল্যাণ, সরকারি মিডিয়া ও চাকরির বিজ্ঞপ্তির জন্য সরাসরি সংশ্লিষ্ট official portal-এ যান। সাহজসেবা কেবল পথ দেখায়; আবেদন, নিয়োগ বা সুবিধা পাওয়ার সিদ্ধান্ত সংশ্লিষ্ট কর্তৃপক্ষের.",
  };
  const localizedPaidAssistanceItems = isEnglish ? [
    { serial: "01", title: "NID new application / correction", desc: "Use the preparation checklist, then verify requirements on the official portal." },
    { serial: "02", title: "e-Passport application", desc: "Review the official requirements and complete the application only on the official portal." },
    { serial: "03", title: "Birth registration", desc: "Check the required documents and use the relevant official registration route." },
    { serial: "04", title: "Trade licence", desc: "Check local authority requirements and prepare documents before using the official route." },
    { serial: "05", title: "Police clearance", desc: "Review the form and official eligibility information before applying." },
    { serial: "06", title: "Driving licence application", desc: "Confirm learner, test, and smart-card requirements with the official authority." },
    { serial: "07", title: "BSTI application guidance", desc: "Review the relevant official certificate or approval requirements first." },
    { serial: "08", title: "Passport status check", desc: "Use the official passport portal to check application status." },
    { serial: "09", title: "Old-age / widow allowance", desc: "Verify programme eligibility and the correct local-government route." },
    { serial: "10", title: "Land khatian / porcha", desc: "Use the official land-record service after checking the required identifiers." },
    { serial: "11", title: "Electricity bill / new connection", desc: "Use the relevant utility's official customer service route." },
    { serial: "12", title: "eTIN certificate", desc: "Use the tax authority's official registration and certificate service." },
    { serial: "13", title: "Vaccination certificate download", desc: "Verify your details through the authorised certificate service." },
    { serial: "14", title: "Rural electricity service", desc: "Check the official rural electricity provider's current service instructions." },
    { serial: "15", title: "BMET registration and smart card", desc: "Verify the current BMET process and use the official route for submission." },
  ] : [
    { serial: "০১", title: "NID নতুন আবেদন/সংশোধন", desc: "প্রস্তুতি নির্দেশিকা দেখে তারপর অফিসিয়াল পোর্টালে শর্ত মিলিয়ে নিন।" },
    { serial: "০২", title: "ই-পাসপোর্ট আবেদন", desc: "অফিসিয়াল শর্ত দেখে কেবল সরকারি পোর্টালেই আবেদন সম্পন্ন করুন।" },
    { serial: "০৩", title: "জন্মনিবন্ধন", desc: "প্রয়োজনীয় কাগজপত্র মিলিয়ে সংশ্লিষ্ট সরকারি নিবন্ধন পথে যান।" },
    { serial: "০৪", title: "ট্রেড লাইসেন্স", desc: "স্থানীয় কর্তৃপক্ষের শর্ত যাচাই করে অফিসিয়াল পথে যাওয়ার আগে কাগজপত্র গুছিয়ে নিন।" },
    { serial: "০৫", title: "পুলিশ ক্লিয়ারেন্স", desc: "আবেদনের আগে ফরম ও অফিসিয়াল যোগ্যতার তথ্য যাচাই করুন।" },
    { serial: "০৬", title: "ড্রাইভিং লাইসেন্স আবেদন", desc: "লার্নার, পরীক্ষা ও স্মার্ট কার্ডের শর্ত সংশ্লিষ্ট কর্তৃপক্ষের কাছে মিলিয়ে নিন।" },
    { serial: "০৭", title: "বিএসটিআই আবেদন নির্দেশিকা", desc: "সনদ বা অনুমোদনের প্রাসঙ্গিক অফিসিয়াল শর্ত আগে দেখে নিন।" },
    { serial: "০৮", title: "পাসপোর্ট স্ট্যাটাস চেক", desc: "স্ট্যাটাস জানতে অফিসিয়াল পাসপোর্ট পোর্টাল ব্যবহার করুন।" },
    { serial: "০৯", title: "বয়স্ক/বিধবা ভাতা", desc: "কর্মসূচির যোগ্যতা ও সঠিক স্থানীয়-সরকারি পথ মিলিয়ে নিন।" },
    { serial: "১০", title: "জমির খতিয়ান/পর্চা", desc: "প্রয়োজনীয় পরিচিতি তথ্য যাচাই করে সরকারি ভূমি-তথ্য সেবা ব্যবহার করুন।" },
    { serial: "১১", title: "বিদ্যুৎ বিল/নতুন সংযোগ", desc: "সংশ্লিষ্ট বিদ্যুৎ প্রতিষ্ঠানের অফিসিয়াল গ্রাহকসেবা পথ ব্যবহার করুন।" },
    { serial: "১২", title: "eTIN সার্টিফিকেট", desc: "কর কর্তৃপক্ষের অফিসিয়াল নিবন্ধন ও সার্টিফিকেট সেবা ব্যবহার করুন।" },
    { serial: "১৩", title: "টিকা সনদ ডাউনলোড", desc: "অনুমোদিত সনদসেবায় নিজের তথ্য যাচাই করুন।" },
    { serial: "১৪", title: "পল্লী বিদ্যুৎ সেবা", desc: "পল্লী বিদ্যুৎ কর্তৃপক্ষের সর্বশেষ অফিসিয়াল নির্দেশনা দেখুন।" },
    { serial: "১৫", title: "BMET রেজিস্ট্রেশন ও স্মার্ট কার্ড", desc: "চলতি BMET প্রক্রিয়া যাচাই করে অফিসিয়াল পথে আবেদন করুন।" },
  ];
  const localizedServices = useMemo(() => localizeCivicServices(services, language), [language]);
  const localizedCategories = useMemo(
    () => serviceCategories.map((category) => getLocalizedServiceCategory(category, language)),
    [language],
  );
  const [query, setQuery] = useState("");
  const [selectedDistrictId, setSelectedDistrictId] = useState("");
  const [selectedUpazilaId, setSelectedUpazilaId] = useState("");
  const [unionQuery, setUnionQuery] = useState("");
  const [shareMessage, setShareMessage] = useState<string>(copy.shareLink);
  const [aboutShareMessage, setAboutShareMessage] = useState<string>(copy.shareBangladesh);
  const [prioritizeExpatriate, setPrioritizeExpatriate] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.location.hash === "#expatriates" || window.location.hash === "#probashi-services";
  });

  useEffect(() => {
    const syncExpatriatePriority = () => {
      const hash = window.location.hash;
      setPrioritizeExpatriate(hash === "#expatriates" || hash === "#probashi-services");
    };
    window.addEventListener("hashchange", syncExpatriatePriority);
    return () => window.removeEventListener("hashchange", syncExpatriatePriority);
  }, []);

  useEffect(() => {
    if (!prioritizeExpatriate || typeof window === "undefined") return;

    let attempts = 0;
    let timer: number | undefined;
    const revealExpatriateGuide = () => {
      const target = document.getElementById("probashi-services");
      if (target) {
        target.scrollIntoView({ behavior: "smooth", block: "start" });
        return;
      }
      if (attempts < 12) {
        attempts += 1;
        timer = window.setTimeout(revealExpatriateGuide, 150);
      }
    };

    timer = window.setTimeout(revealExpatriateGuide, 0);
    return () => {
      if (timer !== undefined) window.clearTimeout(timer);
    };
  }, [prioritizeExpatriate]);

  useEffect(() => {
    // Vite's client render can finish after the browser's initial native hash
    // lookup. Re-apply only these stable public anchors after mount so a shared
    // report or Gallery link lands on its section without changing content.
    const scrollToDeferredPublicAnchor = () => {
      const targetId = window.location.hash.replace(/^#/, "");
      if (targetId !== "public-seo-report" && targetId !== "open-photo-gallery") return;

      let attempts = 0;
      let timer: number | undefined;
      const revealTarget = () => {
        const target = document.getElementById(targetId);
        if (target) {
          target.scrollIntoView({ behavior: "auto", block: "start" });
          return;
        }
        if (attempts < 12) {
          attempts += 1;
          timer = window.setTimeout(revealTarget, 150);
        }
      };

      timer = window.setTimeout(revealTarget, 0);
      return () => {
        if (timer !== undefined) window.clearTimeout(timer);
      };
    };

    let stopCurrentAttempt = scrollToDeferredPublicAnchor();
    const handleHashChange = () => {
      stopCurrentAttempt?.();
      stopCurrentAttempt = scrollToDeferredPublicAnchor();
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => {
      stopCurrentAttempt?.();
      window.removeEventListener("hashchange", handleHashChange);
    };
  }, []);

  // The public portal provides official guidance only; it does not accept an
  // application, order, phone number, payment, or transaction reference.
  const [guidanceModalOpen, setGuidanceModalOpen] = useState(false);
  const [selectedServiceForGuidance, setSelectedServiceForGuidance] = useState("");

  const approvedReviewsQuery = trpc.reviews.listApproved.useQuery(
    { serviceIds: siteWideReviewIds },
    { staleTime: 30_000, refetchOnWindowFocus: false },
  );
  const publicSiteContentQuery = trpc.siteManagement.getPublicContent.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const announcementQuery = trpc.siteManagement.management.getAnnouncement.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const headerAdsQuery = trpc.adminAnalytics.advertising.live.useQuery({ slot: "header" }, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const trackAdClickMutation = trpc.adminAnalytics.advertising.trackClick.useMutation();
  const publicSiteSettings = publicSiteContentQuery.data?.settings;
  const publicQuickLinks = publicSiteContentQuery.data?.quickLinks ?? [];
  const homeSectionLayout = useMemo(
    () => parseHomeSectionLayout(publicSiteSettings?.homeSectionLayoutJson),
    [publicSiteSettings?.homeSectionLayoutJson],
  );
  const travelContentQuery = trpc.siteManagement.getTravelContent.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const educationHubCards = travelContentQuery.data?.educationHubCards ?? [];
  const financialServiceCards = travelContentQuery.data?.financialServiceCards ?? [];
  const mediaHubSettings = travelContentQuery.data?.mediaHubSettings;
  const mediaHubChannels = travelContentQuery.data?.mediaHubChannels ?? [];
  const managedHeroTitle = language === "BN" ? publicSiteSettings?.heroTitleBn : publicSiteSettings?.heroTitleEn;
  const managedHeroSubtitle = language === "BN" ? publicSiteSettings?.heroSubtitleBn : publicSiteSettings?.heroSubtitleEn;
  const managedHeroAccent = language === "BN" ? publicSiteSettings?.heroAccentMessageBn : publicSiteSettings?.heroAccentMessageEn;
  const managedPrimaryCtaLabel = language === "BN" ? publicSiteSettings?.primaryCtaLabelBn : publicSiteSettings?.primaryCtaLabelEn;
  const managedHeroBackground = publicSiteSettings?.heroBackgroundImageUrl || "";
  const managedHeroVideo = publicSiteSettings?.heroVideoUrl || "";
  const managedSiteName = language === "BN" ? publicSiteSettings?.siteNameBn : publicSiteSettings?.siteNameEn;
  const ownerAppearanceStyle: CSSProperties = {
    "--owner-primary": publicSiteSettings?.brandAccentColor ?? "#0d5c56",
    "--owner-highlight": publicSiteSettings?.brandHighlightColor ?? "#f2b84b",
    "--owner-page-background": "var(--public-theme-background-color, #f3faf6)",
    "--owner-page-background-image": "var(--public-theme-background-image, none)",
    "--owner-text": publicSiteSettings?.siteTextColor ?? "#173b32",
  } as CSSProperties;
  const announcement = announcementQuery.data;
  const announcementText = language === "EN" ? announcement?.messageEn || announcement?.messageBn : announcement?.messageBn;
  const headerAds = headerAdsQuery.data ?? [];
  useEffect(() => {
    trackEvent("page_view", { page: "home" });
  }, []);

  useEffect(() => {
    setShareMessage(copy.shareLink);
    setAboutShareMessage(copy.shareBangladesh);
  }, [copy.shareBangladesh, copy.shareLink]);

  const normalizedQuery = query.toLocaleLowerCase("bn").replace(/[য়য়]/g, "য়").trim();
  const selectedDistrict = useMemo(() => findDistrictById(selectedDistrictId), [selectedDistrictId]);
  const availableUpazilas = useMemo(() => findUpazilasByDistrictId(selectedDistrictId), [selectedDistrictId]);
  const selectedUpazila = useMemo(
    () => availableUpazilas.find((upazila) => upazila.id === selectedUpazilaId),
    [availableUpazilas, selectedUpazilaId],
  );
  const selectedLocationLabel = selectedUpazila?.bn_name || selectedDistrict?.bn_name || "সারা বাংলাদেশ";
  const unionSearchReady = canSearchUnion(selectedDistrictId, selectedUpazilaId);
  const normalizedUnionQuery = unionQuery.toLocaleLowerCase("bn").replace(/[য়য়]/g, "য়").trim();
  const filteredServices = useMemo(() => {
    const terms = normalizedQuery.split(/\s+/).filter(Boolean);
    const matchingServices = localizedServices.filter((service) => {
      const searchText = getCivicServiceSearchText(service);
      const matchesQuery = terms.every((term) => searchText.includes(term));
      const matchesLocation = matchesLocationScope(service.locationScope, selectedDistrictId, selectedUpazilaId);
      return matchesQuery && matchesLocation;
    });
    return orderServicesByNumber(matchingServices);
  }, [localizedServices, normalizedQuery, selectedDistrictId, selectedUpazilaId]);
  const filteredServiceGroups = useMemo(
    () => localizedCategories
      .map((category) => ({
        ...category,
        services: filteredServices.filter((service) => serviceCategoryByNumber[service.number] === category.id),
      }))
      .filter((category) => category.services.length > 0),
    [filteredServices, localizedCategories],
  );
  const internalSearchDestinations = useMemo(
    () => findPublicSearchDestinations(normalizedQuery),
    [normalizedQuery],
  );

  const handleDistrictChange = (districtId: string) => {
    setSelectedDistrictId(districtId);
    setSelectedUpazilaId("");
    setUnionQuery("");
    if (districtId) {
      const district = findDistrictById(districtId);
      trackEvent("location_filter_change", { level: "district", value: district?.name || districtId });
    } else {
      trackEvent("location_filter_reset", { level: "district" });
    }
  };

  const handleUpazilaChange = (upazilaId: string) => {
    setSelectedUpazilaId(upazilaId);
    setUnionQuery("");
    if (upazilaId) {
      const upazila = availableUpazilas.find((item) => item.id === upazilaId);
      trackEvent("location_filter_change", { level: "upazila", value: upazila?.name || upazilaId });
    } else {
      trackEvent("location_filter_reset", { level: "upazila" });
    }
  };

  const resetLocationFilters = () => {
    setSelectedDistrictId("");
    setSelectedUpazilaId("");
    setUnionQuery("");
    trackEvent("location_filter_reset", { level: "all" });
  };

  const handleShortcut = (shortcutQuery: string) => {
    trackEvent("service_shortcut_click", { query: shortcutQuery || "all" });
    setQuery(shortcutQuery);
    window.requestAnimationFrame(() => {
      document.getElementById("services")?.scrollIntoView({ behavior: "smooth", block: "start" });
      document.getElementById("service-search-input")?.focus({ preventScroll: true });
    });
  };

  const handleSearchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const value = query.trim();
    if (value) trackEvent("service_search_submit", { query_length: value.length });
    document.getElementById("services")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: "সাহজসেবা — সহজে সরকারি সেবা খুঁজুন",
          text: "NID, ই-পাসপোর্ট, ভাতা ও নাগরিক সেবার অফিসিয়াল পথ এক জায়গায় খুঁজে নিন।",
          url: window.location.href,
        });
        trackEvent("share_completed", { method: "native" });
        setShareMessage(copy.shared);
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(window.location.href);
        trackEvent("share_completed", { method: "clipboard" });
        setShareMessage(copy.linkCopied);
      } else {
        const fallbackInput = document.createElement("textarea");
        fallbackInput.value = window.location.href;
        fallbackInput.setAttribute("readonly", "");
        fallbackInput.style.position = "fixed";
        fallbackInput.style.opacity = "0";
        document.body.appendChild(fallbackInput);
        fallbackInput.select();
        document.execCommand("copy");
        fallbackInput.remove();
        trackEvent("share_completed", { method: "fallback_copy" });
        setShareMessage(copy.linkCopied);
      }
      window.setTimeout(() => setShareMessage(copy.shareLink), 2600);
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
        setShareMessage(language === "EN" ? "Please try again" : "আবার চেষ্টা করুন");
      window.setTimeout(() => setShareMessage(copy.shareLink), 2600);
    }
  };


  const handleAboutShare = async () => {
    const shareUrl = window.location.href;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareUrl);
      } else {
        const fallbackInput = document.createElement("textarea");
        fallbackInput.value = shareUrl;
        fallbackInput.setAttribute("readonly", "");
        fallbackInput.style.position = "fixed";
        fallbackInput.style.opacity = "0";
        document.body.appendChild(fallbackInput);
        fallbackInput.select();
        document.execCommand("copy");
        fallbackInput.remove();
      }
      trackEvent("about_bangladesh_share_click", { method: "copy_link" });
      setAboutShareMessage(copy.shareCopied);
      window.setTimeout(() => setAboutShareMessage(copy.shareBangladesh), 2600);
    } catch {
      setAboutShareMessage(copy.shareError);
      window.setTimeout(() => setAboutShareMessage(copy.shareBangladesh), 2600);
    }
  };

  const officialGuidanceSection = (
    <section id="official-guidance" className="official-guidance-section" aria-labelledby="official-guidance-heading" style={{ background: "#f0f4f8", padding: "3.5rem 0", borderBottom: "1px solid #d0d7de" }}>
      <div className="container">
        <details data-service-folder="official-guidance" className="official-guidance-folder" style={{ background: "#ffffff", border: "1px solid #cce0ff", borderRadius: "16px", boxShadow: "0 8px 24px rgba(13, 71, 161, 0.08)", overflow: "hidden" }}>
          <summary style={{ listStyle: "none", cursor: "pointer", padding: "1.1rem 1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", background: "linear-gradient(135deg, #eff6ff 0%, #f0fdfa 100%)" }}>
            <span style={{ minWidth: 0, flex: "1 1 auto" }}>
              <span className="section-number" style={{ color: "#0D47A1", fontWeight: "700", fontSize: "0.82rem" }}>বিশেষ সহায়তা</span>
              <span id="official-guidance-heading" style={{ display: "block", fontSize: "1.35rem", color: "#0D47A1", fontWeight: "800", marginTop: "0.2rem" }}>সরকারি পথে প্রস্তুতি</span>
              <span style={{ display: "block", color: "#475569", fontSize: "0.88rem", lineHeight: "1.45", marginTop: "0.25rem" }}>
                ১. সরকারি সেবা বাছুন → ২. অফিসিয়াল লিংক ও প্রয়োজনীয় প্রস্তুতি দেখুন → ৩. শুধু সরকারি পোর্টালে নিজে আবেদন করুন
              </span>
            </span>
            <span className="official-guidance-summary-art" aria-hidden="true">
              <img src="/manus-storage/sahajcontact-computer-support-illustration_30ca225d.webp" alt="" width={180} height={135} loading="lazy" fetchPriority="low" decoding="async" />
            </span>
            <span aria-hidden="true" style={{ flex: "0 0 auto", width: "2.25rem", height: "2.25rem", borderRadius: "999px", display: "inline-flex", alignItems: "center", justifyContent: "center", background: "#0D47A1", color: "#fff", fontSize: "1.35rem", lineHeight: 1 }}>+</span>
          </summary>
          <div className="services-intro" style={{ margin: "0", padding: "1.5rem 1.25rem 0" }}>
            <div>
              <span className="section-number" style={{ color: "#0D47A1", fontWeight: "700" }}>বিশেষ সেবা</span>
              <h2 style={{ fontSize: "2rem", color: "#0D47A1", fontWeight: "800", marginTop: "0.5rem" }}>সরকারি সেবার প্রস্তুতি নির্দেশিকা</h2>
            </div>
            <p style={{ fontSize: "1.05rem", color: "#333", maxWidth: "700px" }}>এখানে অফিসিয়াল আবেদনপথ, প্রয়োজনীয় কাগজপত্রের প্রাথমিক প্রস্তুতি ও নিরাপত্তা নির্দেশনা এক জায়গায় সাজানো আছে। SahajContact আবেদন জমা নেয় না, ফি নির্ধারণ করে না এবং কোনো পেমেন্ট গ্রহণ করে না।</p>
          </div>
          <div className="online-application-note" role="note">
            <strong>নিরাপদ অনলাইন প্রস্তুতি:</strong> NID, ই-পাসপোর্ট, জন্মনিবন্ধন, ট্রেড লাইসেন্স, পুলিশ ক্লিয়ারেন্স, ড্রাইভিং লাইসেন্স, eTIN, ভাতা, জমি, বিদ্যুৎ ও অন্যান্য অনলাইন সেবার অফিসিয়াল তথ্য ধারাবাহিকভাবে সাজানো আছে। সরকারি ফি থাকলে কেবল সংশ্লিষ্ট সরকারি পোর্টালেই পরিশোধ করুন।
          </div>
          <section className="official-application-links" aria-labelledby="official-application-heading">
            <div className="official-application-heading-row">
              <div>
                <span className="section-number" style={{ color: "#0D47A1", fontWeight: "700" }}>নিজে আবেদন করার সরকারি পথ</span>
                <h3 id="official-application-heading">অফিসিয়াল অনলাইন আবেদন লিংক</h3>
              </div>
              <span className="official-application-badge">সরকারি পোর্টাল</span>
            </div>
            <p className="official-application-intro">প্রথমে সরকারি পোর্টালে নিজে আবেদন করার চেষ্টা করুন। প্রতিটি সেবার জন্য অফিসিয়াল উৎস, প্রয়োজনীয় প্রস্তুতি এবং নিরাপত্তা নোট নিচে দেওয়া আছে।</p>
            <div className="official-application-grid" role="list" aria-label="অফিসিয়াল অনলাইন আবেদন লিংকের তালিকা">
              {newCivicServices.map((service) => {
                const branding = getLocalizedServiceBranding(service, language);
                const ServiceIcon = branding.icon;
                return (
                  <article className="official-application-card" key={`paid-official-${service.number}`} role="listitem" style={{ "--service-accent": branding.accent, "--service-tint": branding.tint } as CSSProperties}>
                    <span className="official-application-side-logo" aria-hidden="true"><ServiceIcon size={58} strokeWidth={1.55} /></span>
                    <div className="official-application-card-topline"><span className="official-application-number">{service.number}</span><span className="official-application-tag">{service.tag}</span></div>
                    <div className="official-application-brandline">
                      <span className="service-icon-badge" role="img" aria-label={branding.iconLabel} title={branding.iconLabel}><ServiceIcon size={24} strokeWidth={2.2} aria-hidden="true" /></span>
                      <span className="service-brand-mark" aria-hidden="true">{branding.mark}</span>
                      <span className="official-application-department">{branding.departmentName}</span>
                    </div>
                    <strong className="official-application-title">{service.title}</strong>
                    <span className="official-application-desc">{service.text}</span>
                    <ExternalLinkWithFallback href={service.href} title={service.title} className="official-application-action" wrapperClassName="official-application-action-wrap" ariaLabel={language === "EN" ? `${service.title} official portal` : `${service.title} সরকারি পোর্টাল খুলুন`} showExternalIcon={false} onClick={() => trackOutbound(service.title, service.href, "assistance_official_application")}>
                      {language === "EN" ? "Official link" : "সরকারি লিংক"} <ArrowUpRight size={14} aria-hidden="true" />
                    </ExternalLinkWithFallback>
                  </article>
                );
              })}
            </div>
            <p className="official-application-safety" role="note"><ShieldCheck size={15} aria-hidden="true" /> {language === "EN" ? "Never share your OTP, NID number, or password. Pay any government fee only on the official portal." : "OTP, NID নম্বর ও পাসওয়ার্ড কাউকে দেবেন না। সরকারি ফি থাকলে শুধু সরকারি পোর্টালেই পরিশোধ করুন।"}</p>
          </section>
          <div className="paid-service-grid-wrap" role="region" aria-label="সরকারি সেবা প্রস্তুতি নির্দেশিকার তালিকা">
            <div className="paid-service-grid" role="list" aria-label="সরকারি সেবার প্রস্তুতি নির্দেশিকার তালিকা">
              {localizedPaidAssistanceItems.map((item, index) => {
                const ServiceIcon = serviceIcons[index] ?? FileCheck2;
                return (
                  <article className="paid-service-cell" key={`relocated-${item.serial}`} role="listitem">
                    <div className="paid-service-cell-topline">
                      <span className="paid-service-number" aria-label={`সিরিয়াল ${item.serial}`}>{item.serial}</span>
                      <span className="paid-service-fee-contact"><span className="paid-service-price">অফিসিয়াল প্রস্তুতি</span></span>
                    </div>
                    <span className="paid-service-card-icon" aria-hidden="true"><ServiceIcon strokeWidth={1.8} /></span>
                    <strong className="paid-service-title">{item.title}</strong>
                    <span className="paid-service-desc">{item.desc}</span>
                    <button type="button" className="paid-service-action" onClick={() => { setSelectedServiceForGuidance(item.title); setGuidanceModalOpen(true); }}>প্রস্তুতি নির্দেশিকা</button>
                  </article>
                );
              })}
            </div>
          </div>
          <div className="paid-service-payment-note" role="note"><strong>নিরাপদ ব্যবহারের নির্দেশিকা:</strong> SahajContact কোনো আবেদন জমা নেয় না, payment gateway চালায় না, পেমেন্ট নিশ্চিত করে না এবং রসিদ দেয় না। সরকারি ফি থাকলে কেবল সংশ্লিষ্ট সরকারি পোর্টালেই পরিশোধ করুন। কারও কাছে OTP, পাসওয়ার্ড, NID নম্বর, ব্যাংক/মোবাইল-ফাইন্যান্স তথ্য বা transaction ID দেবেন না।</div>
        </details>
        <div className="official-guidance-cta" role="group" aria-label="প্রাতিষ্ঠানিক যোগাযোগের পরবর্তী পদক্ষেপ" style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "center", gap: "0.75rem", marginTop: "1.25rem" }}>
          <Link href="/contact" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.5rem", minHeight: "2.9rem", padding: "0.75rem 1.25rem", borderRadius: "999px", background: "#0f766e", color: "#ffffff", fontWeight: "800", fontSize: "0.98rem", textDecoration: "none", boxShadow: "0 8px 18px rgba(15, 118, 110, 0.2)", transition: "transform 160ms ease, background-color 160ms ease" }}>প্রাতিষ্ঠানিক যোগাযোগের নিয়ম <ArrowUpRight size={16} aria-hidden="true" /></Link>
          <Link href="/ngo-partnership" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.5rem", minHeight: "2.9rem", padding: "0.75rem 1.25rem", borderRadius: "999px", background: "#ffffff", color: "#0D47A1", border: "1px solid #9bb8e8", fontWeight: "800", fontSize: "0.98rem", textDecoration: "none", boxShadow: "0 6px 16px rgba(13, 71, 161, 0.1)", transition: "transform 160ms ease, background-color 160ms ease" }}>সহযোগিতা প্রস্তাব <ArrowUpRight size={16} aria-hidden="true" /></Link>
        </div>
      </div>
    </section>
  );

  return (
    <div className="site-shell" style={ownerAppearanceStyle} data-font-scale={publicSiteSettings?.fontScale ?? "standard"} data-layout-density={publicSiteSettings?.layoutDensity ?? "standard"}>
      <SahajHeader />
      {announcement?.enabled === 1 && announcementText && (
        <div className="border-b border-amber-300/40 bg-amber-50 px-4 py-2 text-center text-sm font-semibold text-amber-950" role="status">
          {announcement.linkUrl ? <a href={announcement.linkUrl} className="underline decoration-amber-700 underline-offset-2">{announcementText}</a> : announcementText}
        </div>
      )}
      {headerAds.length > 0 && (
        <aside className="border-b border-slate-200 bg-white px-4 py-2" aria-label={language === "EN" ? "Sponsored placement" : "স্পন্সরকৃত বিজ্ঞাপন"}>
          <div className="container flex flex-wrap items-center justify-center gap-2 text-sm text-slate-700">
            <span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-bold uppercase tracking-wide text-slate-500">{language === "EN" ? "Sponsored" : "স্পন্সরকৃত"}</span>
            {headerAds.map((ad) => <a key={ad.id} href={ad.adUrl} target="_blank" rel="sponsored noopener noreferrer" onClick={() => trackAdClickMutation.mutate({ orderId: ad.id })} className="font-bold text-teal-800 underline decoration-teal-300 underline-offset-2 hover:text-teal-600">{language === "EN" ? ad.adTitleEn || ad.adTitleBn : ad.adTitleBn}</a>)}
          </div>
        </aside>
      )}
      <main>
        <section
          className="home-hero"
          style={{
            ...(publicSiteSettings ? {
              borderBottom: `4px solid ${publicSiteSettings.brandHighlightColor}`,
              boxShadow: `inset 0 -2px 0 ${publicSiteSettings.brandAccentColor}22`,
            } : {}),
            ...(managedHeroBackground ? {
              backgroundImage: `linear-gradient(90deg, rgba(5, 35, 33, 0.92), rgba(5, 35, 33, 0.45)), url(${managedHeroBackground})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            } : {}),
          }}
        >
          <div className="container hero-layout">
            <div className="hero-copy reveal-up">
              <div className="eyebrow"><span className="eyebrow-dot" />{language === "EN" ? "Bangladesh-focused civic support" : "বাংলাদেশ-কেন্দ্রিক নাগরিক সহায়তা"}</div>
              <div className="hero-install-reminder" role="note"><span className="hero-install-reminder-icon" aria-hidden="true">⌂</span><span>{language === "EN" ? "Install once, open from your home screen" : "একবার ইনস্টল করুন, হোমস্ক্রিন থেকেই খুলুন"}</span></div>
              <h1 className="hero-title"><span className="hero-title-message">{managedHeroTitle ?? copy.heroTitle}</span>{language === "BN" && !managedHeroTitle && <span className="hero-title-main">সেবার পথ<br /><em>পরিষ্কার করুন।</em></span>}</h1>
              <p>{managedHeroSubtitle ?? copy.heroSubtitle}</p>
              <p className="hero-accent-message" role="note">{managedHeroAccent ?? (language === "EN" ? "Educate your child; bring government services within reach." : "সন্তানকে শিক্ষিত করুন, সরকারি সেবা হাতের মুঠোয় আসবে")}</p>
              <div className="hero-actions">
                {publicSiteSettings?.primaryCtaHref ? (
                  <a href={publicSiteSettings.primaryCtaHref} className="button button-primary" target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("owner_primary_cta_click", { destination: publicSiteSettings.primaryCtaHref ?? "" })}>{managedPrimaryCtaLabel ?? copy.heroSearchLabel} <ArrowUpRight size={17} /></a>
                ) : (
                  <Link href="/#services" className="button button-primary" onClick={() => trackEvent("navigation_click", { label: managedPrimaryCtaLabel ?? copy.heroSearchLabel, destination: "/#services" })}>{managedPrimaryCtaLabel ?? copy.heroSearchLabel} <ArrowUpRight size={17} /></Link>
                )}
                <Link href="/contact" className="button button-quiet" onClick={() => trackEvent("navigation_click", { label: copy.heroFeedback, destination: "/contact" })}>{copy.heroFeedback} <span aria-hidden="true">→</span></Link>
                <PwaInstallButton />
                <button type="button" className="button button-share" onClick={() => { trackEvent("share_click"); void handleShare(); }}><Share2 size={16} />{shareMessage}</button>
              </div>
              <div className="hero-notes">
                <span><Check size={14} />{language === "EN" ? "Sources are clearly identified" : "উৎস আলাদা করে দেখানো হয়"}</span>
                <span><Check size={14} />{language === "EN" ? "Verification dates are shown" : "যাচাইয়ের তারিখ থাকবে"}</span>
              </div>
            </div>
            <div className="hero-art reveal-up" style={{ animationDelay: "100ms" }}>
              {managedHeroVideo ? (
                <video className="h-full w-full rounded-2xl object-cover" controls muted playsInline poster={managedHeroBackground || undefined} preload="metadata">
                  <source src={managedHeroVideo} />
                </video>
              ) : (
                <picture>
                  <source
                    media="(max-width: 680px)"
                    srcSet={managedHeroBackground || "/manus-storage/sahajseva-river-clean-hero-mobile_18eb3204.webp"}
                    width="640"
                    height="380"
                  />
                  <img
                    src={managedHeroBackground || "/manus-storage/sahajseva-river-clean-hero_90dbd003.webp"}
                    alt={managedSiteName || (language === "EN" ? "Civic support for Bangladesh" : "বাংলাদেশের নাগরিক সহায়তা")}
                    width={960}
                    height={430}
                    sizes="(max-width: 680px) 100vw, 55vw"
                    loading="eager"
                    fetchPriority="high"
                    decoding="async"
                  />
                </picture>
              )}
              <BangladeshMapInteractive />
            </div>
          </div>
        </section>

        {publicSiteSettings?.noticeVisible === 1 && (language === "EN" ? (publicSiteSettings.ownerNoticeTitleEn || publicSiteSettings.ownerNoticeTextEn) : (publicSiteSettings.ownerNoticeTitleBn || publicSiteSettings.ownerNoticeTextBn)) && (
          <section aria-label={language === "EN" ? "Published Emergency Notice" : "প্রকাশিত জরুরি নোটিশ"} style={{ background: "#fff8e8", borderBottom: `1px solid ${publicSiteSettings.brandHighlightColor}` }}>
            <div className="container" style={{ paddingTop: "1rem", paddingBottom: "1rem", display: "flex", gap: "0.8rem", alignItems: "flex-start" }}>
              <Info size={21} aria-hidden="true" style={{ color: publicSiteSettings.brandAccentColor, marginTop: "0.1rem", flexShrink: 0 }} />
              <div>
                {(language === "EN" ? publicSiteSettings.ownerNoticeTitleEn : publicSiteSettings.ownerNoticeTitleBn) && <strong style={{ color: "var(--ink)", display: "block", marginBottom: "0.2rem" }}>{language === "EN" ? (publicSiteSettings.ownerNoticeTitleEn || publicSiteSettings.ownerNoticeTitleBn) : publicSiteSettings.ownerNoticeTitleBn}</strong>}
                {(language === "EN" ? publicSiteSettings.ownerNoticeTextEn : publicSiteSettings.ownerNoticeTextBn) && <p style={{ margin: 0, color: "var(--ink-soft)", lineHeight: 1.6, whiteSpace: "pre-line" }}>{language === "EN" ? (publicSiteSettings.ownerNoticeTextEn || publicSiteSettings.ownerNoticeTextBn) : publicSiteSettings.ownerNoticeTextBn}</p>}
              </div>
            </div>
          </section>
        )}

        {publicSiteSettings?.quickLinksVisible === 1 && publicQuickLinks.length > 0 && (
          <ManagedHomeSection layout={homeSectionLayout.quickLinks}>
          <section aria-labelledby="owner-quick-links-heading" style={{ background: "#f7faf9", borderBottom: "1px solid rgba(13,92,86,0.12)", padding: "2.25rem 0" }}>
            <div className="container">
              <div style={{ display: "flex", alignItems: "end", justifyContent: "space-between", gap: "1rem", marginBottom: "1rem" }}>
                <div>
                  <span className="section-number" style={{ color: publicSiteSettings.brandAccentColor }}>{language === "EN" ? "Featured Links" : "নির্বাচিত লিংক"}</span>
                  <h2 id="owner-quick-links-heading" style={{ margin: "0.3rem 0 0", color: "var(--ink)", fontSize: "clamp(1.35rem, 3vw, 2rem)" }}>{language === "EN" ? "Quick Essential Paths" : "দ্রুত প্রয়োজনীয় পথ"}</h2>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "0.85rem" }}>
                {publicQuickLinks.map((quickLink) => {
                  const linkTitle = language === "EN" ? (quickLink.titleEn || quickLink.titleBn) : quickLink.titleBn;
                  const linkDesc = language === "EN" ? (quickLink.descriptionEn || quickLink.descriptionBn) : quickLink.descriptionBn;
                  return (
                    <a key={quickLink.id} href={quickLink.url} target={quickLink.openInNewTab === 1 ? "_blank" : undefined} rel={quickLink.openInNewTab === 1 ? "noopener noreferrer" : undefined} onClick={() => trackEvent("owner_quick_link_click", { label: linkTitle, destination: quickLink.url })} style={{ display: "block", textDecoration: "none", padding: "1rem", borderRadius: "12px", background: "#fff", border: `1px solid ${publicSiteSettings.brandAccentColor}28`, boxShadow: "0 4px 14px rgba(13,92,86,0.06)" }}>
                      <strong style={{ color: publicSiteSettings.brandAccentColor, display: "flex", alignItems: "center", gap: "0.4rem" }}>{quickLink.iconImageUrl ? <img src={quickLink.iconImageUrl} alt="" aria-hidden="true" style={{ width: 22, height: 22, borderRadius: 5, objectFit: "cover" }} /> : <Link2 size={17} aria-hidden="true" />}{linkTitle} <ArrowUpRight size={15} aria-hidden="true" /></strong>
                      {linkDesc && <span style={{ color: "var(--ink-soft)", display: "block", lineHeight: 1.5, fontSize: "0.9rem", marginTop: "0.35rem" }}>{linkDesc}</span>}
                    </a>
                  );
                })}
              </div>
            </div>
          </section>
          </ManagedHomeSection>
        )}

        <ManagedHomeSection layout={homeSectionLayout.bangladesh}>
        <section className="still-images-folder-section" aria-labelledby="still-images-folder-heading">
          <div className="container">
            <details className="details-folder still-images-folder" data-section-folder="bangladesh-still-images">
              <summary className="details-folder-summary">
                <span className="details-folder-summary-copy">
                <span className="details-folder-kicker">{language === "EN" ? "A visual journey through Bangladesh" : "বাংলাদেশকে জানুন, অনুভব করুন"}</span>
                  <span id="still-images-folder-heading" className="details-folder-title">
                    {language === "EN" ? "Bangladesh in Still Images" : "বাংলাদেশের কিছু স্থিরচিত্র"}
                  </span>
                  <span className="details-folder-lede">
                    {language === "EN" ? "Open this folder to discover Bangladesh, its people, and the stories behind the images." : "ফোল্ডারটি খুলে বাংলাদেশ, দেশের মানুষ এবং ছবিগুলোর গল্প একসঙ্গে দেখুন।"}
                  </span>
                </span>
                <span className="details-folder-toggle" aria-hidden="true" />
              </summary>

	              <div className="details-folder-content">
	                <section className="about-bangladesh-section" aria-labelledby="about-bangladesh-heading">
                  <div className="container">
                    <div className="about-bangladesh-layout">
                      <div className="about-bangladesh-visual">
                        <img
                          src="/manus-storage/sahajseva-about-bangladesh_1209dfe6.webp"
                          alt="পদ্মা সেতু, সবুজ ধানক্ষেত, নদী ও বাংলাদেশের মানুষের সমন্বিত চিত্র"
                          width={1200}
                          height={800}
                          loading="lazy"
                          decoding="async"
                        />
                        <span className="about-bangladesh-visual-label">নদী • মানুষ • সম্ভাবনা</span>
                      </div>
                      <div className="about-bangladesh-copy">
                        <span className="about-bangladesh-kicker">{language === "EN" ? "Discover Bangladesh" : "বাংলাদেশকে জানুন"}</span>
                        <h2 id="about-bangladesh-heading">{copy.aboutTitle}</h2>
                        <p style={{ whiteSpace: "pre-line" }}>{copy.aboutText}</p>
                        <button type="button" className="about-bangladesh-share" onClick={() => void handleAboutShare()}>
                          <Share2 size={17} aria-hidden="true" />
                          {aboutShareMessage}
                        </button>
                        <nav className="about-bangladesh-official-links" aria-label={language === "EN" ? "SahajContact, science and nuclear-power links" : "সহজসেবা, বিজ্ঞান ও পারমাণবিক বিদ্যুৎ লিংক"}>
                          <a href="/" onClick={() => trackEvent("about_bangladesh_link_click", { destination: "/" })}>SahajContact <ArrowUpRight size={14} aria-hidden="true" /></a>
                          <Link href="/invest-bangladesh" onClick={() => trackEvent("about_bangladesh_link_click", { destination: "/invest-bangladesh" })}>
                            {language === "EN" ? "Invest Bangladesh" : "ইনভেস্ট বাংলাদেশ"} <ArrowUpRight size={14} aria-hidden="true" />
                          </Link>
                          <a href="https://baec.gov.bd/" target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("about_bangladesh_link_click", { destination: "baec.gov.bd" })}>
                            {language === "EN" ? "BAEC (Nuclear Energy)" : "বাংলাদেশ পরমাণু শক্তি কমিশন"} <ArrowUpRight size={14} aria-hidden="true" />
                          </a>
                          <a href="https://baera.gov.bd/" target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("about_bangladesh_link_click", { destination: "baera.gov.bd" })}>
                            {language === "EN" ? "BAERA (Nuclear Safety)" : "পরমাণু শক্তি নিয়ন্ত্রণ কর্তৃপক্ষ"} <ArrowUpRight size={14} aria-hidden="true" />
                          </a>
                          <a href="https://sparrso.gov.bd/" target="_blank" rel="noopener noreferrer" onClick={() => trackEvent("about_bangladesh_link_click", { destination: "sparrso.gov.bd" })}>
                            {language === "EN" ? "SPARRSO (Space Research)" : "বাংলাদেশ মহাকাশ গবেষণা (SPARRSO)"} <ArrowUpRight size={14} aria-hidden="true" />
                          </a>
                        </nav>
                      </div>
                    </div>
                    <section className="about-diaspora-map" aria-labelledby="about-diaspora-heading">
                      <div className="about-diaspora-heading">
                        <span className="about-bangladesh-kicker">{language === "EN" ? "From Bangladesh to the world / diaspora reach" : "দেশ থেকে বিশ্বে / প্রবাসী পৌঁছানো"}</span>
                        <h3 id="about-diaspora-heading">{copy.diasporaTitle}</h3>
                        <p>{copy.diasporaDescription}</p>
                      </div>
                      <div className="about-diaspora-countries" role="list" aria-label={language === "EN" ? "Countries reached" : "সেবা পৌঁছানো দেশসমূহ"}>
                        {(language === "EN" ? ["🇧🇩 Bangladesh", "🇸🇦 Saudi Arabia", "🇺🇸 USA", "🇸🇬 Singapore", "🇮🇪 Ireland", "🇲🇻 Maldives", "🇳🇱 Netherlands", "🇸🇪 Sweden", "🇮🇹 Italy", "🇮🇩 Indonesia"] : ["🇧🇩 বাংলাদেশ", "🇸🇦 সৌদি আরব", "🇺🇸 USA", "🇸🇬 Singapore", "🇮🇪 Ireland", "🇲🇻 Maldives", "🇳🇱 Netherlands", "🇸🇪 Sweden", "🇮🇹 Italy", "🇮🇩 ইন্দোনেশিয়া"]).map((country) => (
                          <span className="about-diaspora-country" role="listitem" key={country}>{country}</span>
                        ))}
                      </div>
                    </section>
                  </div>
	                </section>
	                <BangladeshGallery language={language} />
	              </div>
            </details>
          </div>
        </section>
        </ManagedHomeSection>

        {/* Prominent Long Bengali Search Bar Section with Subtle Bangladeshi Cultural Folk-Art / Alpana Motif */}
        <section className="home-search-banner" style={{ background: "linear-gradient(135deg, rgba(13,92,86,0.95) 0%, rgba(9,56,52,0.97) 100%), url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"120\" height=\"120\" viewBox=\"0 0 120 120\" opacity=\"0.07\"><path d=\"M60 0 C70 30 90 50 120 60 C90 70 70 90 60 120 C50 90 30 70 0 60 C30 50 50 30 60 0 Z\" fill=\"%23f2b84b\"/><circle cx=\"60\" cy=\"60\" r=\"15\" fill=\"none\" stroke=\"%23ffffff\" stroke-width=\"2\"/><circle cx=\"60\" cy=\"60\" r=\"35\" fill=\"none\" stroke=\"%23f2b84b\" stroke-width=\"1\" stroke-dasharray=\"4 4\"/></svg>')", backgroundSize: "140px 140px", padding: "2.25rem 0", color: "#ffffff", borderBottom: "4px solid #f2b84b", boxShadow: "inset 0 10px 20px rgba(0,0,0,0.15)" }}>
          <div className="container" style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
            <div style={{ textAlign: "center", maxWidth: "740px", margin: "0 auto" }}>
              <div style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", background: "rgba(242,184,75,0.2)", color: "#f2b84b", padding: "0.25rem 0.85rem", borderRadius: "9999px", fontSize: "0.85rem", fontWeight: "700", marginBottom: "0.5rem", border: "1px solid rgba(242,184,75,0.4)" }}>
                <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#10b981", display: "inline-block", boxShadow: "0 0 8px #10b981" }} />
                লাইভ ট্রাফিক ও তাৎক্ষণিক সেবা ফাইন্ডার
              </div>
              <h2 style={{ fontSize: "1.75rem", fontWeight: "900", color: "#ffffff", margin: "0 0 0.4rem", letterSpacing: "-0.01em" }}>🔍 নাগরিক সেবা ও সরকারি তথ্য অনুসন্ধান</h2>
              <p style={{ fontSize: "0.98rem", color: "#e2ede9", margin: 0, lineHeight: 1.5 }}>NID, ই-পাসপোর্ট, ভূমি, ভাতা, পুলিশ ক্লিয়ারেন্স বা যেকোনো সেবার নাম লিখে মুহূর্তের মধ্যে সঠিক তথ্য ও লিংক খুঁজে পান।</p>
            </div>
            
            <form onSubmit={handleSearchSubmit} style={{ maxWidth: "800px", width: "100%", margin: "0 auto", position: "relative" }}>
              <div style={{ display: "flex", alignItems: "center", background: "#ffffff", borderRadius: "16px", padding: "0.5rem 0.6rem 0.5rem 1.25rem", boxShadow: "0 10px 30px rgba(0,0,0,0.25)", border: "3px solid #f2b84b" }}>
                <Search size={22} style={{ color: "#0d5c56", flexShrink: 0, marginRight: "0.85rem" }} />
                <input
                  id="service-search-input"
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="সেবার নাম বা কিওয়ার্ড লিখুন (যেমন: NID, পাসপোর্ট, ভূমি, ভাতা, পুলিশ)..."
                  style={{ flex: 1, border: "none", outline: "none", fontSize: "1.1rem", color: "#0f172a", background: "transparent", padding: "0.5rem 0", fontWeight: "500" }}
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery("")}
                    style={{ background: "#e2e8f0", border: "none", borderRadius: "9999px", width: "28px", height: "28px", display: "inline-flex", alignItems: "center", justifyContent: "center", cursor: "pointer", marginRight: "0.6rem", color: "#334155", fontSize: "0.85rem", fontWeight: "700" }}
                    title="রিসেট করুন"
                  >
                    ✕
                  </button>
                )}
                <button
                  type="submit"
                  style={{ background: "linear-gradient(135deg, #10b981 0%, #059669 100%)", color: "#ffffff", padding: "0.75rem 1.5rem", borderRadius: "12px", fontWeight: "800", fontSize: "1rem", textDecoration: "none", boxShadow: "0 4px 14px rgba(16,185,129,0.4)", display: "inline-flex", alignItems: "center", gap: "0.4rem" }}
                >
                  খুঁজুন ↗
                </button>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "0.5rem", marginTop: "0.75rem" }}>
                <span style={{ fontSize: "0.82rem", color: "#cbd5e1", alignSelf: "center", marginRight: "0.25rem" }}>জনপ্রিয় খোঁজ:</span>
                {[
                  { label: "NID কার্ড", q: "NID" },
                  { label: "পাসপোর্ট", q: "পাসপোর্ট" },
                  { label: "ভূমি সেবা", q: "ভূমি" },
                  { label: "সামাজিক ভাতা", q: "ভাতা" },
                  { label: "পুলিশ ক্লিয়ারেন্স", q: "পুলিশ" }
                ].map((item) => (
                  <button
                    key={item.q}
                    type="button"
                    onClick={() => handleShortcut(item.q)}
                    style={{ background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.25)", color: "#ffffff", padding: "0.2rem 0.65rem", borderRadius: "6px", fontSize: "0.82rem", cursor: "pointer", fontWeight: "600", transition: "all 0.2s" }}
                  >
                    {item.q}
                  </button>
                ))}
              </div>
            </form>

            <a
              href="#public-seo-report"
              data-testid="home-public-seo-report-shortcut"
              style={{ alignItems: "center", background: "rgba(15, 118, 110, 0.28)", border: "1px solid rgba(153, 246, 228, 0.46)", borderRadius: "12px", color: "#f0fdfa", display: "inline-flex", gap: "0.55rem", justifyContent: "center", margin: "0.85rem auto 0", maxWidth: "34rem", padding: "0.58rem 0.85rem", textAlign: "left", textDecoration: "none", width: "100%" }}
            >
              <span aria-hidden="true" style={{ color: "#99f6e4", fontSize: "1.05rem" }}>◌</span>
              <span style={{ minWidth: 0 }}>
                <strong style={{ display: "block", fontSize: "0.88rem" }}>{language === "EN" ? "Automatic SEO & GA4 report" : "স্বয়ংক্রিয় SEO ও GA4 রিপোর্ট"}</strong>
                <span style={{ color: "#ccfbf1", display: "block", fontSize: "0.76rem", lineHeight: 1.35 }}>{language === "EN" ? "View stored aggregate data only — no estimated figures" : "শুধু সংরক্ষিত সমষ্টিগত তথ্য দেখুন — কোনো অনুমিত সংখ্যা নয়"}</span>
              </span>
              <span aria-hidden="true" style={{ color: "#99f6e4", fontSize: "1rem", marginLeft: "auto" }}>↓</span>
            </a>

            <div style={{ display: "flex", gap: "0.5rem", justifyContent: "center", flexWrap: "wrap", paddingTop: "0.25rem" }}>
              {[
                { label: "সব সেবা", q: "" },
                { label: "🪪 NID", q: "NID" },
                { label: "🛂 পাসপোর্ট", q: "পাসপোর্ট" },
                { label: "🌾 কৃষক ও কৃষি", q: "কৃষি" },
                { label: "🏠 ভূমি সেবা", q: "ভূমি" },
                { label: "💰 ভাতা", q: "ভাতা" },
                { label: "🛡️ আইনশৃঙ্খলা", q: "পুলিশ" },
                { label: "🏥 স্বাস্থ্য", q: "স্বাস্থ্য" },
              ].map((shortcut, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleShortcut(shortcut.q)}
                  style={{ background: query === shortcut.q ? "#f2b84b" : "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.25)", color: query === shortcut.q ? "#123d42" : "#ffffff", padding: "0.35rem 0.85rem", borderRadius: "9999px", fontSize: "0.8rem", fontWeight: "600", cursor: "pointer", transition: "all 0.2s" }}
                >
                  {shortcut.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        <Suspense fallback={<div className="utility-sections-fallback" aria-hidden="true" />}>
          <UtilityAndExpatriateSections
            afterLawEnforcement={
              <EducationHubSection
                cards={educationHubCards}
                language={language}
              />
            }
          />
        </Suspense>

        {officialGuidanceSection}
        <MediaHubSection
          settings={mediaHubSettings}
          channels={mediaHubChannels}
          language={language}
          homeDirectory
        />

        {/* Bangladesh Tourist & Land Travel Planner Section */}
        <ManagedHomeSection layout={homeSectionLayout.tourism}>
        <section id="bangladesh-tourist-section" className="py-12 bg-emerald-950/5 dark:bg-emerald-900/10 border-y border-emerald-900/10 my-8" aria-labelledby="tourist-planner-heading">
          <div className="container max-w-7xl mx-auto px-4">
            <div className="rounded-2xl p-6 sm:p-10 bg-gradient-to-r from-emerald-800 to-teal-900 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="max-w-2xl">
                <span className="inline-block px-3 py-1 mb-3 text-xs font-bold uppercase tracking-wider bg-emerald-700/80 rounded-full text-emerald-100">
                  {homeFlowUi.touristBadge}
                </span>
                <h2 id="tourist-planner-heading" className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
                  {homeFlowUi.touristHeading}
                </h2>
                <p className="text-emerald-100 text-sm sm:text-base leading-relaxed mb-4">
                  {homeFlowUi.touristText}
                </p>
                <div className="flex flex-wrap items-center gap-3">
                  <Link
                    href="/bangladesh"
                    className="inline-flex items-center gap-2 bg-white text-emerald-900 hover:bg-emerald-50 font-bold px-6 py-3 rounded-xl shadow-lg transition-all text-sm"
                  >
                    <MapPin size={16} /> {homeFlowUi.touristButton}
                  </Link>
                  <Link
                    href="/contact"
                    className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-3 rounded-xl shadow-lg transition-all text-sm"
                  >
                    <MessageCircle size={16} /> {homeFlowUi.touristWhatsapp}
                  </Link>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl text-center min-w-[220px]">
                <span className="text-3xl font-extrabold text-emerald-300 block mb-1">৫০+</span>
                  <span className="text-xs text-emerald-100 font-medium block">{homeFlowUi.touristSpots}</span>
                <div className="my-3 border-t border-white/20" />
                <span className="text-3xl font-extrabold text-teal-300 block mb-1">৬টি</span>
                  <span className="text-xs text-emerald-100 font-medium block">{homeFlowUi.landPorts}</span>
              </div>
            </div>
          </div>
        </section>
        </ManagedHomeSection>

        <ManagedHomeSection layout={homeSectionLayout.howTo}>
        <section id="how-to-use" className="how-to-section" aria-labelledby="how-to-heading" style={{ position: "relative", backgroundImage: "linear-gradient(135deg, rgba(237,246,241,0.94) 0%, rgba(248,249,250,0.96) 100%), url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"400\" height=\"200\" viewBox=\"0 0 400 200\" opacity=\"0.06\"><path d=\"M200 40 L220 200 L180 200 Z M170 80 L190 200 L150 200 Z M230 80 L250 200 L210 200 Z M140 120 L160 200 L120 200 Z M260 120 L280 200 L240 200 Z\" fill=\"%23006A4E\"/></svg>')", backgroundSize: "cover", backgroundPosition: "center" }}>
          <div className="container">
            <div className="how-to-intro">
              <div>
                <div className="section-route-mark" aria-hidden="true"><img
                    src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                    decoding="async"
                  /><span /></div>
                <span className="section-number">{homeFlowUi.howToNumber}</span>
                <h2 id="how-to-heading">{homeFlowUi.howToHeading}</h2>
              </div>
              <p>{homeFlowUi.howToIntro}</p>
            </div>
            <div className="how-to-grid">
              <article className="how-to-card">
                <span className="how-to-step">{homeFlowUi.step1}</span>
                <div className="how-to-card-icon"><Search size={20} aria-hidden="true" /></div>
                <h3>{homeFlowUi.step1Title}</h3>
                <p>{homeFlowUi.step1Text}</p>
                <a className="how-to-card-link" href="#services" onClick={() => trackEvent("navigation_click", { label: homeFlowUi.step1Link, destination: "/#services" })}>{homeFlowUi.step1Link} <ArrowUpRight size={15} /></a>
              </article>
              <article className="how-to-card">
                <span className="how-to-step">{homeFlowUi.step2}</span>
                <div className="how-to-card-icon"><ShieldCheck size={20} aria-hidden="true" /></div>
                <h3>{homeFlowUi.step2Title}</h3>
                <p>{homeFlowUi.step2Text}</p>
                <span className="how-to-card-status"><Check size={15} /> {homeFlowUi.step2Status}</span>
              </article>
              <article className="how-to-card">
                <span className="how-to-step">{homeFlowUi.step3}</span>
                <div className="how-to-card-icon"><Check size={20} aria-hidden="true" /></div>
                <h3>{homeFlowUi.step3Title}</h3>
                <p>{homeFlowUi.step3Text}</p>
                <Link className="how-to-card-link" href="/contact" onClick={() => trackEvent("navigation_click", { label: homeFlowUi.step3Link, destination: "/contact" })}>{homeFlowUi.step3Link} <ArrowUpRight size={15} /></Link>
              </article>
            </div>
            <div className="how-to-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>{homeFlowUi.howToNoteStrong}</strong> {homeFlowUi.howToNote}</p></div>
          </div>
        </section>
        </ManagedHomeSection>

        <section id="services" className="services-section section-paper">
          <div className="container">
            <div className="section-intro">
              <span className="section-number">{homeFlowUi.servicesNumber}</span>
              <div><div className="section-route-mark" aria-hidden="true"><img
                    src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                    decoding="async"
                  /><span /></div><h2>{homeFlowUi.servicesTitle}</h2></div>
              <p>{homeFlowUi.servicesIntro}</p>
            </div>
            <div className="service-shortcuts" aria-label="জনপ্রিয় সেবার দ্রুত পথ">
              <div className="service-shortcuts-heading">
                <span>{homeFlowUi.shortcutsTitle}</span>
                <p>{homeFlowUi.shortcutsIntro}</p>
              </div>
              <div className="service-shortcut-list">
                {localizedServiceShortcuts.map((shortcut) => (
                  <button
                    className="service-shortcut"
                    type="button"
                    key={shortcut.label}
                    style={{ "--shortcut-accent": shortcut.accent, "--shortcut-tint": shortcut.tint } as CSSProperties}
                    aria-pressed={normalizedQuery === shortcut.query}
                    onClick={() => handleShortcut(shortcut.query)}
                  >
                    <span>{shortcut.label}</span>
                    <small>{shortcut.hint}</small>
                    <ArrowUpRight size={14} aria-hidden="true" />
                  </button>
                ))}
              </div>
            </div>
            <div className="location-filter-panel" aria-labelledby="location-filter-heading">
              <div className="location-filter-heading">
                <div>
                  <span className="location-filter-kicker"><MapPin size={14} aria-hidden="true" /> {homeFlowUi.locationKicker}</span>
                  <h3 id="location-filter-heading">{homeFlowUi.locationTitle}</h3>
                </div>
                <span className="location-filter-status" aria-live="polite">{homeFlowUi.currentPath} <strong>{selectedLocationLabel}</strong></span>
              </div>
              <div className="location-filter-grid">
                <label className="location-filter-field">
                  <span>{homeFlowUi.district}</span>
                  <select value={selectedDistrictId} onChange={(event) => handleDistrictChange(event.target.value)} aria-label={homeFlowUi.selectDistrict}>
                    <option value="">{homeFlowUi.allDistricts}</option>
                    {divisionsData.flatMap((division) => division.districts.map((district) => (
                      <option key={district.id} value={district.id}>{isEnglish ? district.name : district.bn_name} — {isEnglish ? division.name : division.bn_name}</option>
                    )))}
                  </select>
                </label>
                <label className="location-filter-field">
                  <span>{homeFlowUi.upazila}</span>
                  <select value={selectedUpazilaId} onChange={(event) => handleUpazilaChange(event.target.value)} disabled={!selectedDistrictId} aria-label={homeFlowUi.selectUpazila}>
                    <option value="">{homeFlowUi.allUpazilas}</option>
                    {availableUpazilas.map((upazila) => (
                      <option key={upazila.id} value={upazila.id}>{isEnglish ? upazila.name : upazila.bn_name}</option>
                    ))}
                  </select>
                </label>
                <label className="location-filter-field">
                  <span>{homeFlowUi.union}</span>
                  <input
                    value={unionQuery}
                    onChange={(event) => setUnionQuery(event.target.value)}
                    disabled={!unionSearchReady}
                    placeholder={unionSearchReady ? homeFlowUi.unionPlaceholder : homeFlowUi.chooseUpazila}
                    aria-label={homeFlowUi.union}
                    aria-describedby="union-search-help"
                    autoComplete="off"
                  />
                </label>
                {(selectedDistrictId || selectedUpazilaId || unionQuery) && (
                  <button className="location-filter-reset" type="button" onClick={resetLocationFilters}>
                    <RotateCcw size={15} aria-hidden="true" /> {homeFlowUi.resetFilters}
                  </button>
                )}
              </div>
              <div className="location-filter-union-handoff">
                <p id="union-search-help" className="location-filter-note">
                  {unionSearchReady
                    ? normalizedUnionQuery
                      ? `“${unionQuery.trim()}” ইউনিয়ন/ওয়ার্ডের জন্য ${selectedLocationLabel}-এর স্থানীয় পথ দেখানো হচ্ছে। সঠিক অফিস ও ঠিকানা জাতীয় তথ্য বাতায়নের তালিকায় মিলিয়ে নিন।`
                      : "ইউনিয়ন বা ওয়ার্ডের নাম লিখে স্থানীয় কাজের প্রসঙ্গ মনে রাখুন; সঠিক অফিসের নাম ও ঠিকানা official তালিকায় যাচাই করুন।"
                    : "ইউনিয়ন বা ওয়ার্ড খুঁজতে আগে জেলা ও উপজেলা বেছে নিন। ইউনিয়নের সরকারি তালিকা জাতীয় তথ্য বাতায়নে খোলা যাবে।"}
                </p>
                <a
                  className="location-filter-union-link"
                  href={OFFICIAL_UNION_DIRECTORY_URL}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => trackOutbound("official_union_directory", OFFICIAL_UNION_DIRECTORY_URL)}
                >
                  <MapPin size={14} aria-hidden="true" /> অফিসিয়াল ইউনিয়ন তালিকা <ArrowUpRight size={14} aria-hidden="true" />
                </a>
              </div>
            </div>
            <form className="service-search" role="search" onSubmit={handleSearchSubmit}>
              <label className="service-search-label" htmlFor="service-search-input">আপনার প্রয়োজনীয় সেবা খুঁজুন</label>
              <div className="service-search-field">
                <Search className="service-search-icon" size={21} aria-hidden="true" />
                <input
                  id="service-search-input"
                  className="service-search-input"
                  type="search"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  onBlur={(event) => {
                    const value = event.currentTarget.value.trim();
                    if (value) trackEvent("service_search", { query_length: value.length });
                  }}
                  placeholder="যেমন: রেল টিকেট, ডিসি অফিস বা বিদ্যুৎ"
                  autoComplete="off"
                  aria-describedby="service-search-hint"
                />
                {query && (
                  <button className="service-search-clear" type="button" onClick={() => { trackEvent("service_search_clear"); setQuery(""); }} aria-label="সার্চ মুছে ফেলুন">
                    <X size={18} />
                  </button>
                )}
              </div>
              <div className="service-search-meta">
                <span id="service-search-hint">নাম, বিষয় বা সেবার ধরন লিখলেই তালিকা ছেঁকে দেখাবে।</span>
                <strong>{filteredServices.length}টি সেবা{internalSearchDestinations.length ? ` · ${internalSearchDestinations.length}টি পৃষ্ঠা` : ""}</strong>
              </div>
            </form>
            {internalSearchDestinations.length > 0 && (
              <section aria-label="সাইটের সঠিক পৃষ্ঠার ফলাফল" style={{ margin: "0 0 1.25rem", padding: "1rem", borderRadius: "16px", background: "linear-gradient(135deg, #effcf8, #fff8e7)", border: "1px solid #b8ddd0" }}>
                <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "0.75rem", flexWrap: "wrap", marginBottom: "0.75rem" }}>
                  <div>
                    <p style={{ margin: 0, color: "#0d5c56", fontSize: "0.78rem", fontWeight: 800, letterSpacing: "0.06em" }}>{language === "EN" ? "SITE PAGES" : "সাইটের সঠিক পৃষ্ঠা"}</p>
                    <h3 style={{ margin: "0.15rem 0 0", color: "#173b32", fontSize: "1.1rem" }}>{language === "EN" ? "Go directly to the relevant SahajContact page" : "প্রাসঙ্গিক সাহজকনট্যাক্ট পৃষ্ঠায় সরাসরি যান"}</h3>
                  </div>
                  <span style={{ color: "#47665e", fontSize: "0.82rem" }}>{language === "EN" ? "Official actions stay on matching service cards" : "অফিসিয়াল কাজের লিংক মিল থাকা সেবা কার্ডে আছে"}</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "0.75rem" }}>
                  {internalSearchDestinations.map((destination) => (
                    <Link
                      key={destination.id}
                      href={destination.href}
                      onClick={() => trackEvent("internal_search_destination_click", { destination: destination.id, query_length: normalizedQuery.length })}
                      style={{ display: "block", minWidth: 0, padding: "0.9rem", borderRadius: "12px", background: "#ffffff", color: "#173b32", textDecoration: "none", border: "1px solid #d8e9e2", boxShadow: "0 3px 10px rgba(16, 77, 67, 0.06)" }}
                    >
                      <span style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.5rem", fontWeight: 800 }}>
                        {language === "EN" ? destination.titleEn : destination.titleBn}<ArrowUpRight size={16} aria-hidden="true" />
                      </span>
                      <span style={{ display: "block", marginTop: "0.4rem", color: "#55736b", fontSize: "0.85rem", lineHeight: 1.45 }}>
                        {language === "EN" ? destination.descriptionEn : destination.descriptionBn}
                      </span>
                    </Link>
                  ))}
                </div>
              </section>
            )}
            <div className="service-route-guide" aria-label="সেবা খোঁজার পথ">
              <span className="service-route-guide-marker" aria-hidden="true" />
              <div><strong>পথচিহ্ন</strong><span>প্রয়োজন থেকে official পোর্টাল পর্যন্ত</span></div>
              <span className="service-route-guide-line" aria-hidden="true" />
            </div>
            <div className="service-list">
              {filteredServiceGroups.map((category) => (
                <section className="service-category-block" key={category.id} aria-labelledby={`service-category-${category.id}`}>
                  <div className="service-category-heading">
                    <div>
                      <span className="service-category-kicker">সেবা বিভাগ / {category.name}</span>
                      <h3 id={`service-category-${category.id}`}>{category.name}</h3>
                    </div>
                    <span className="service-category-count">{category.services.length}টি</span>
                  </div>
                  <div className="service-category-list">
	                    {category.services.map((service) => {
	                      const branding = getLocalizedServiceBranding(service, language);
	                      const serviceArtwork = getServiceArtwork(service.title, service.tag);
	                      return (
	                      <article id={`service-${service.number}`} className="service-row" key={service.number} style={{ "--service-accent": branding.accent, "--service-tint": branding.tint } as CSSProperties}>
	                        <div className="service-row-main">
	                          <span className="service-number" aria-label={`সেবা নম্বর ${service.number}`}>{service.number}</span>
	                          <div className="service-card-body">
	                            <div className="service-illustration" aria-hidden="true">
	                              <span className="service-illustration-fallback">{branding.mark}</span>
	                              <img
	                                src={serviceArtwork.src}
	                                alt=""
	                                loading="eager"
	                                decoding="async"
	                                onError={(event) => {
	                                  event.currentTarget.style.display = "none";
	                                  event.currentTarget.parentElement?.setAttribute("data-artwork-fallback", "true");
	                                }}
	                              />
	                              <span className="service-illustration-mark">{branding.mark}</span>
	                            </div>
	                            <div className="service-content">
	                              <div className="service-title-block">
	                                <div className="service-brand-line">
	                                  <span className="service-department-name">{branding.departmentName}</span>
	                                </div>
                                <h3 title={service.title}>{service.title}</h3>
                              </div>
                              <span>{service.tag}</span>
                              <p>{service.text}</p>
                            </div>
                            <div className="service-actions">
                            <span className="service-action-badge">অফিসিয়াল সরকারি পোর্টাল</span>
                            {service.href ? (
                              <ExternalLinkWithFallback
                                href={service.href}
                                title={`${service.title} অফিসিয়াল পোর্টাল`}
                                className="service-portal-btn"
                                wrapperClassName="service-arrow-wrapper"
                                ariaLabel={`${service.title} অফিসিয়াল পোর্টাল খুলুন`}
                                showExternalIcon={false}
                                onClick={() => trackOutbound(service.title, service.href, "service_link")}
                              >
                                <span>ভিজিট</span>
                                <ArrowUpRight className="service-arrow" size={14} />
                              </ExternalLinkWithFallback>
                            ) : (
                              <span className="service-portal-disabled">তথ্য</span>
                            )}
                            <button
                              type="button"
                              className="service-apply-btn"
                              onClick={() => {
                                setSelectedServiceForGuidance(service.title);
                                setGuidanceModalOpen(true);
                                trackEvent("service_guidance_open", { service_title: service.title });
                              }}
                            >
                              নির্দেশনা
                            </button>
                            </div>
                          </div>
                        </div>
                      </article>
                      );
                    })}
                  </div>
                </section>
              ))}
              {filteredServices.length === 0 && (
                <div className="service-empty" role="status">
                  <Search size={24} aria-hidden="true" />
                  <strong>এই নামে কোনো সেবা পাওয়া যায়নি।</strong>
                  <p>“লিগ্যাল এইড”, “রেল টিকেট”, “ডিসি অফিস”, “বিদ্যুৎ” বা “বয়স্ক ভাতা” লিখে আবার চেষ্টা করুন।</p>
                </div>
              )}
            </div>
            <ServiceReviews
              serviceId={SITE_WIDE_REVIEW_ID}
              serviceName="সহজসেবা পোর্টাল"
              reviews={approvedReviewsQuery.data ?? []}
              isLoading={approvedReviewsQuery.isLoading}
              hasError={Boolean(approvedReviewsQuery.error)}
            />
          </div>
        </section>

        <section id="emergency" className="emergency-section" aria-labelledby="emergency-heading">
          <div className="container">
            <details data-service-folder="emergency-contacts" className="emergency-folder" style={{ background: "#ffffff", border: "1px solid #cce0ff", borderRadius: "16px", boxShadow: "0 8px 24px rgba(13, 71, 161, 0.08)", overflow: "hidden" }}>
              <summary style={{ listStyle: "none", cursor: "pointer", padding: "1.1rem 1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", background: "linear-gradient(135deg, #eff6ff 0%, #f0fdfa 100%)" }}>
                <span style={{ minWidth: 0 }}>
                  <span className="section-number" style={{ color: "#0D47A1", fontWeight: "700", fontSize: "0.82rem" }}>02 / জরুরি পথ</span>
                  <span id="emergency-heading" style={{ display: "block", fontSize: "1.35rem", color: "#0D47A1", fontWeight: "800", marginTop: "0.2rem" }}>জরুরী সময় দ্রুত যোগাযোগ করুন</span>
                  <span style={{ display: "block", color: "#475569", fontSize: "0.88rem", lineHeight: "1.45", marginTop: "0.25rem" }}>জরুরি নম্বরগুলো দেখতে ফোল্ডারটি খুলুন</span>
                </span>
                <span aria-hidden="true" style={{ flex: "0 0 auto", width: "2.25rem", height: "2.25rem", borderRadius: "999px", display: "inline-flex", alignItems: "center", justifyContent: "center", background: "#0D47A1", color: "#fff", fontSize: "1.35rem", lineHeight: 1 }}>+</span>
              </summary>
              <div style={{ padding: "1.5rem 1.25rem 0" }}>
                <p style={{ fontSize: "1.05rem", color: "#333", maxWidth: "700px", margin: "0 0 1.5rem" }}>জরুরি পরিস্থিতিতে সাহজসেবা দেখে সময় নষ্ট না করে সংশ্লিষ্ট সরকারি hotline-এ সরাসরি ফোন করুন। নিচের নম্বরগুলো official source-এর পথসহ সাজানো হয়েছে।</p>
                <div className="emergency-grid">
                  {localizedEmergencyNumbers.map(({ icon: Icon, ...emergency }) => (
                    <article className="emergency-card" key={emergency.number}>
                      <div className="emergency-card-top">
                        <div className="emergency-icon"><Icon size={20} aria-hidden="true" /></div>
                        <span className="emergency-number">{emergency.number}</span>
                      </div>
                      <h3>{emergency.title}</h3>
                      <p>{emergency.text}</p>
                      <div className="emergency-actions">
                        <a className="emergency-call" href={`tel:${emergency.phone}`} aria-label={`${emergency.number} নম্বরে ফোন করুন`} onClick={() => trackEvent("phone_click", { label: emergency.title, category: "emergency" })}>
                          <Phone size={15} aria-hidden="true" /> ফোন করুন
                        </a>
                        <ExternalLinkWithFallback
                          href={emergency.officialHref}
                          title={emergency.officialLabel}
                          className="emergency-source"
                          showExternalIcon={false}
                          onClick={() => trackOutbound(emergency.title, emergency.officialHref, "emergency_source")}
                        >
                          {emergency.officialLabel} <ArrowUpRight size={14} aria-hidden="true" />
                        </ExternalLinkWithFallback>
                      </div>
                    </article>
                  ))}
                </div>
                <div className="emergency-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>সতর্কতা:</strong> সাহজসেবা নিজে কোনো emergency dispatch, পুলিশ, ফায়ার, অ্যাম্বুলেন্স বা চিকিৎসা সেবা প্রদানকারী নয়। নম্বরের availability, service scope ও call charge অপারেটর বা পরিস্থিতি অনুযায়ী বদলাতে পারে—জরুরি অবস্থায় সংশ্লিষ্ট সরকারি কর্তৃপক্ষের নির্দেশনা অনুসরণ করুন।</p></div>
              </div>
            </details>
          </div>
        </section>

        <section id="healthcare" className="healthcare-section" aria-labelledby="healthcare-heading">
          <div className="container">
            <details data-service-folder="healthcare-services" className="healthcare-folder" style={{ background: "#ffffff", border: "1px solid #bae6fd", borderRadius: "20px", boxShadow: "0 12px 28px rgba(14, 116, 144, 0.09)", overflow: "hidden" }}>
              <summary aria-label="স্বাস্থ্যসেবা খুলুন" style={{ listStyle: "none", cursor: "pointer", padding: "1.15rem 1.25rem", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", background: "linear-gradient(135deg, #ecfeff 0%, #ffffff 65%, #eff6ff 100%)" }}>
                <span style={{ minWidth: 0 }}>
                  <span className="section-number" style={{ display: "block", color: "#0e7490", fontWeight: 800 }}>03 / স্বাস্থ্যপথ</span>
                  <span id="healthcare-heading" style={{ display: "block", marginTop: "0.3rem", color: "#164e63", fontSize: "clamp(1.35rem, 4vw, 2.35rem)", lineHeight: 1.08, fontWeight: 900 }}>কাছের স্বাস্থ্যসেবা,<br /><em>official পথে খুঁজুন।</em></span>
                  <span style={{ display: "block", marginTop: "0.4rem", color: "#475569", fontSize: "0.88rem", lineHeight: 1.45 }}>তথ্য ও অফিসিয়াল সহায়তার পথ দেখতে ট্যাপ করুন</span>
                </span>
                <span aria-hidden="true" style={{ flex: "0 0 auto", width: "2.4rem", height: "2.4rem", borderRadius: "999px", display: "inline-flex", alignItems: "center", justifyContent: "center", background: "#0e7490", color: "#fff", fontSize: "1.45rem", lineHeight: 1 }}>+</span>
              </summary>
              <div style={{ padding: "1.25rem" }}>
                <div className="healthcare-intro">
                  <div>
                    <div className="section-route-mark" aria-hidden="true"><img
                        src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                        alt=""
                        width={20}
                        height={20}
                        loading="lazy"
                        decoding="async"
                      /><span /></div>
                  </div>
                  <p>স্থানীয় হাসপাতাল, healthcare facility ও অ্যাম্বুলেন্সের তথ্য খুঁজতে DGHS-এর official directory-তে যান। সাহজসেবা কোনো facility-এর availability, bed, fare বা response time নিশ্চিত করে না।</p>
                </div>
                <div className="healthcare-grid">
              {localizedHealthcareContacts.map(({ icon: Icon, ...contact }) => (
                <article className="healthcare-card" key={contact.title}>
                  <div className="healthcare-card-top"><div className="healthcare-icon"><Icon size={20} aria-hidden="true" /></div><span className="support-card-kicker">{contact.kicker}</span></div>
                  <h3>{contact.title}</h3>
                  <p>{contact.text}</p>
                  <div className="healthcare-actions">
                    {contact.phone ? <a className="healthcare-call" href={`tel:${contact.phone}`} aria-label={`${contact.phone} নম্বরে স্বাস্থ্য পরামর্শের জন্য ফোন করুন`} onClick={() => trackEvent("phone_click", { label: contact.title, category: "healthcare" })}><Phone size={15} aria-hidden="true" /> ১৬২৬৩-এ ফোন</a> : null}
                    <ExternalLinkWithFallback
                      href={contact.href}
                      title={contact.linkLabel}
                      className="healthcare-source"
                      showExternalIcon={false}
                      onClick={() => trackOutbound(contact.title, contact.href, "healthcare_source")}
                    >
                      {contact.linkLabel} <ArrowUpRight size={14} aria-hidden="true" />
                    </ExternalLinkWithFallback>
                  </div>
                </article>
              ))}
                </div>
                <section aria-labelledby="government-hospital-examples" style={{ marginTop: "1.2rem", borderTop: "1px solid #bae6fd", paddingTop: "1.15rem" }}>
                  <div style={{ display: "flex", flexWrap: "wrap", alignItems: "baseline", justifyContent: "space-between", gap: "0.65rem", marginBottom: "0.8rem" }}>
                    <div>
                      <p className="support-card-kicker" style={{ margin: 0 }}>{isEnglish ? "Verified public-hospital examples" : "কিছু যাচাইকৃত সরকারি হাসপাতাল"}</p>
                      <h3 id="government-hospital-examples" style={{ margin: "0.22rem 0 0", color: "#164e63", fontSize: "1.08rem" }}>{isEnglish ? "Names and address context" : "নাম ও ঠিকানার প্রাথমিক তথ্য"}</h3>
                    </div>
                    <ExternalLinkWithFallback href={dghsFacilityRegistryUrl} title={isEnglish ? "Search the official DGHS Facility Registry" : "DGHS-এর official হাসপাতাল directory-তে খুঁজুন"} className="healthcare-source" showExternalIcon={false} onClick={() => trackOutbound("DGHS government hospital registry", dghsFacilityRegistryUrl, "healthcare_source")}>
                      {isEnglish ? "Search all hospitals" : "সব হাসপাতাল খুঁজুন"} <ArrowUpRight size={14} aria-hidden="true" />
                    </ExternalLinkWithFallback>
                  </div>
                  <div className="healthcare-grid">
                    {verifiedGovernmentHospitals.map((hospital) => (
                      <article className="healthcare-card" key={hospital.nameEn}>
                        <div className="healthcare-card-top"><div className="healthcare-icon"><MapPin size={20} aria-hidden="true" /></div><span className="support-card-kicker">{isEnglish ? "Government hospital" : "সরকারি হাসপাতাল"}</span></div>
                        <h3>{isEnglish ? hospital.nameEn : hospital.nameBn}</h3>
                        <p><strong>{isEnglish ? "Address:" : "ঠিকানা:"}</strong> {isEnglish ? hospital.addressEn : hospital.addressBn}</p>
                      </article>
                    ))}
                  </div>
                  <p style={{ margin: "0.8rem 0 0", color: "#475569", fontSize: "0.84rem", lineHeight: 1.55 }}>{isEnglish ? "This is not a complete national list. Confirm current location, service availability, and contact details in the official DGHS Facility Registry before travel." : "এটি বাংলাদেশের পূর্ণ তালিকা নয়। যাত্রার আগে বর্তমান অবস্থান, সেবা-প্রাপ্যতা ও যোগাযোগের তথ্য DGHS-এর official Facility Registry-তে যাচাই করুন।"}</p>
                </section>
                <GovernmentHospitalDirectory
                  isEnglish={isEnglish}
                  exportUrl="/manus-storage/dghs-government-hospitals-2026-08-22_0a7a097a.xlsx"
                  registryUrl={dghsFacilityRegistryUrl}
                  onOpenOfficialRegistry={() => trackOutbound("DGHS nationwide government hospital registry", dghsFacilityRegistryUrl, "healthcare_source")}
                />
                <div className="healthcare-note"><Info size={17} aria-hidden="true" /><p><strong>ব্যবহারের নিয়ম:</strong> ambulance directory-তে registration বা mobile verification চাইতে পারে। তাৎক্ষণিক জীবনঝুঁকিতে আগে ৯৯৯-এ যোগাযোগ করুন; healthcare directory-কে emergency dispatch হিসেবে ব্যবহার করবেন না। তথ্য পরিবর্তনশীল—official source-এ সর্বশেষ তথ্য মিলিয়ে নিন।</p></div>
              </div>
            </details>
          </div>
        </section>

        <section id="civic-guides" className="civic-guides-section" aria-labelledby="civic-guides-heading">
          <div className="container">
            <details className="sahaj-folder civic-guides-folder" data-service-folder="civic-guidance">
              <summary className="sahaj-folder-summary">
                <span>
                  <span className="section-number">04 / আরও কিছু official পথ</span>
                  <strong id="civic-guides-heading">দেশের বাইরে, দেশের ভেতরেও সহায়তা</strong>
                  <small>প্রবাসী, সরকারি মিডিয়া ও চাকরির গুরুত্বপূর্ণ official পথ দেখতে খুলুন</small>
                </span>
                <span className="sahaj-folder-toggle" aria-hidden="true">+</span>
              </summary>
              <div className="sahaj-folder-content">
            <div className="civic-guides-intro">
              <div>
                <div className="section-route-mark" aria-hidden="true"><img
                    src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                    decoding="async"
                  /><span /></div>
                <span className="section-number">04 / আরও কিছু official পথ</span>
                <h2 id="civic-guides-heading">দেশের বাইরে,<br /><em>দেশের ভেতরেও সহায়তা।</em></h2>
              </div>
              <p>প্রবাসী কল্যাণ, সরকারি মিডিয়া ও চাকরির বিজ্ঞপ্তির জন্য সরাসরি সংশ্লিষ্ট official portal-এ যান। সাহজসেবা কেবল পথ দেখায়; আবেদন, নিয়োগ বা সুবিধা পাওয়ার সিদ্ধান্ত সংশ্লিষ্ট কর্তৃপক্ষের।</p>
            </div>
            <div className="civic-guides-grid">
              {localizedCivicGuides.map(({ icon: Icon, ...guide }) => (
                <article className="civic-guide-card" key={guide.title}>
                  <div className="civic-guide-top"><div className="civic-guide-icon"><Icon size={20} aria-hidden="true" /></div><span className="support-card-kicker">{guide.kicker}</span></div>
                  <h3>{guide.title}</h3>
                  <p>{guide.text}</p>
                  <div className="civic-guide-links">
                    {guide.links.map((link) => (
                      <ExternalLinkWithFallback
                        key={link.href}
                        href={link.href}
                        title={link.label}
                        className="civic-guide-source"
                        showExternalIcon={false}
                        onClick={() => trackOutbound(`${guide.title}: ${link.label}`, link.href, "civic_source")}
                      >
                        {link.label} <ArrowUpRight size={14} aria-hidden="true" />
                      </ExternalLinkWithFallback>
                    ))}
                  </div>
                </article>
              ))}
            </div>
            <div className="civic-guides-note"><ShieldCheck size={17} aria-hidden="true" /><p><strong>{homeUi.civicSafety}</strong> {homeUi.civicSafetyText}</p></div>
              </div>
            </details>
          </div>
        </section>

        <FinancialServicesSection cards={financialServiceCards} language={language} />

        {/* The real owner-managed financial card above is the only public bank-directory entry. */}

        <section id="trust" className="trust-section">
          <div className="container trust-layout">
            <div className="trust-stamp"><ShieldCheck size={22} /><span>{homeUi.trustStamp}</span></div>
            <div><div className="section-route-mark" aria-hidden="true"><img
                    src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                    decoding="async"
                  /><span /></div><span className="section-number">{homeUi.trustNumber}</span><h2>{homeUi.trustTitle}</h2></div>
            <div className="trust-points"><p>{homeUi.trustText}</p><Link href="/contact" className="text-link" onClick={() => trackEvent("navigation_click", { label: homeUi.feedback, destination: "/contact" })}>{homeUi.feedback} <ArrowUpRight size={15} /></Link></div>
          </div>
        </section>

        <section className="support-section" aria-labelledby="support-heading">
          <div className="container">
            <details className="sahaj-folder support-folder" data-service-folder="support-information">
              <summary className="sahaj-folder-summary">
                <span>
                  <span className="section-number">{homeUi.supportNumber}</span>
                  <strong id="support-heading">{homeUi.supportTitle}</strong>
                  <small>{language === "EN" ? "Open partnership and support information" : "অংশীদারত্ব ও সহায়তার তথ্য দেখতে খুলুন"}</small>
                </span>
                <span className="sahaj-folder-toggle" aria-hidden="true">+</span>
              </summary>
              <div className="sahaj-folder-content">
            <div className="support-intro">
              <div>
                <div className="section-route-mark" aria-hidden="true"><img
                    src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                    decoding="async"
                  /><span /></div>
                <span className="section-number">{homeUi.supportNumber}</span>
                <h2 id="support-heading">{homeUi.supportTitle}</h2>
              </div>
              <p>{homeUi.supportIntro}</p>
            </div>
            <div className="support-grid">
              <article className="support-card">
                <div className="support-card-icon"><BadgePercent size={21} /></div>
                <span className="support-card-kicker">{homeUi.supportPotential}</span>
                <h3>{homeUi.supportAds}</h3>
                <p>{homeUi.supportAdsText}</p>
                <span className="support-status">{homeUi.supportAdsStatus}</span>
              </article>
              <article className="support-card">
                <div className="support-card-icon"><Ticket size={21} /></div>
                <span className="support-card-kicker">{homeUi.supportPartner}</span>
                <h3>{homeUi.supportTickets}</h3>
                <p>{homeUi.supportTicketsText}</p>
                <span className="support-status">{homeUi.supportPartnerStatus}</span>
              </article>
              <article className="support-card">
                <div className="support-card-icon"><HeartHandshake size={21} /></div>
                <span className="support-card-kicker">{homeUi.supportOptional}</span>
                <h3>{homeUi.supportKeepRunning}</h3>
                <p>{homeUi.supportKeepRunningText}</p>
                <Link href="/contact" className="support-card-link" onClick={() => trackEvent("navigation_click", { label: homeUi.supportTellUs, destination: "/contact" })}>{homeUi.supportTellUs} <ArrowUpRight size={15} /></Link>
              </article>
            </div>
            <div className="support-note"><Handshake size={17} /><span>{homeUi.supportNote}</span></div>
              </div>
            </details>
          </div>
        </section>

        <section id="service-guidance" className="payment-preview-section" aria-labelledby="service-guidance-heading" tabIndex={-1}>
          <div className="container">
            <div className="payment-preview-intro">
              <div>
                <div className="section-route-mark" aria-hidden="true"><img
                    src="/manus-storage/sahajseva-logo-optimized_3ff0d912.webp"
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                    decoding="async"
                  /><span /></div>
                <span className="section-number">নিরাপদ সেবা নির্দেশনা</span>
                <h2 id="service-guidance-heading">অফিসিয়াল পথে সেবা নিন</h2>
              </div>
              <p>সহজ সেবা তথ্য ও official route দেখায়। কোনো আবেদন, অর্ডার, payment, receipt বা ব্যক্তিগত তথ্য এই পোর্টালে নেওয়া হয় না।</p>
            </div>
            <div
              id="service-guidance-notice"
              role="note"
              style={{ margin: "0 0 1.25rem", padding: "0.9rem 1rem", borderRadius: "12px", border: "1px solid #d7b76d", background: "#fffbeb", color: "#6b4f00", display: "flex", flexWrap: "wrap", alignItems: "center", gap: "0.65rem" }}
            >
              <strong style={{ fontSize: "1rem" }}>কোনো লেনদেন এই সাইটে হয় না</strong>
              <span style={{ fontWeight: 700 }}>OTP, PIN, পাসওয়ার্ড, NID, payment number বা transaction ID এখানে দেবেন না।</span>
            </div>
            <div className="payment-preview-grid">
              <article className="pricing-preview-card">
                <span className="support-card-kicker">কী পাবেন</span>
                <h3>তথ্য ও official link</h3>
                <div className="price-lines">
                  <div className="price-line"><span>সেবাভিত্তিক সরকারি পোর্টাল</span><strong>ভিজিট করুন</strong></div>
                  <div className="price-line"><span>প্রস্তুতি checklist</span><strong>পড়ুন</strong></div>
                  <div className="price-line"><span>সাধারণ যোগাযোগ</span><strong>পর্যালোচনাভিত্তিক</strong></div>
                </div>
              </article>

              <article className="receipt-preview-card">
                <div className="receipt-preview-heading"><div><span className="support-card-kicker">পরবর্তী ধাপ</span><h3>সরকারি উৎস যাচাই</h3></div><Ticket size={22} /></div>
                <div className="receipt-meta"><span>সেবা নির্বাচন করুন</span><strong>হোমের service card থেকে</strong></div>
                <div className="receipt-lines">
                  <div><span>Official portal</span><strong>নির্দেশনা অনুযায়ী খুলুন</strong></div>
                  <div><span>তথ্য যাচাই</span><strong>সংশ্লিষ্ট কর্তৃপক্ষ থেকে</strong></div>
                  <div><span>সাধারণ প্রশ্ন</span><strong>Contact page ব্যবহার করুন</strong></div>
                </div>
                <div className="receipt-status"><Info size={14} /> এই পোর্টাল কোনো payment নেয় বা payment status দেখায় না।</div>
                <p style={{ marginTop: "1rem", padding: "0.9rem", borderRadius: "12px", border: "1px solid #d7b76d", background: "#fffbeb", color: "#6b4f00", fontSize: "0.85rem", lineHeight: 1.55 }}>এটি সরকারি fee notice বা receipt নয়। সব ফি ও আবেদন-শর্ত সংশ্লিষ্ট অফিসিয়াল উৎস থেকে যাচাই করুন।</p>
              </article>

              <article className="terms-preview-card">
                <span className="support-card-kicker">নিরাপত্তা</span>
                <h3>শুরু করার আগে</h3>
                <div className="terms-list">
                  <p><Check size={15} /><span>সরকারি ওয়েব ঠিকানা যাচাই করুন</span></p>
                  <p><Check size={15} /><span>নিজের প্রয়োজনীয় কাগজপত্র নিজের কাছে রাখুন</span></p>
                  <p><Check size={15} /><span>OTP, PIN ও পাসওয়ার্ড গোপন রাখুন</span></p>
                  <p><Check size={15} /><span>লেনদেন বা পরিচয়পত্রের sensitive তথ্য এই site-এ লিখবেন না</span></p>
                </div>
              </article>
            </div>
          </div>
        </section>

        <section className="home-contact-cta">
          <div className="container home-contact-inner"><div><span className="section-number">{homeUi.contactNumber}</span><h2>{homeUi.contactTitle}</h2></div><Link href="/contact" className="button button-primary" onClick={() => trackEvent("navigation_click", { label: homeUi.contactButton, destination: "/contact" })}>{homeUi.contactButton} <ArrowUpRight size={17} /></Link></div>
        </section>

        {/* Verified story submission section — no fabricated testimonials */}
        <ManagedHomeSection layout={homeSectionLayout.story}>
        <section className="your-story-section" aria-labelledby="your-story-title">
          <div className="your-story-container">
            <div className="your-story-heading">
              <span className="section-number">{homeUi.storyNumber}</span>
              <h2 id="your-story-title">{homeUi.storyTitle}</h2>
              <p>{homeUi.storyIntro}</p>
            </div>
            <div className="your-story-grid">
              <article className="your-story-card"><MessageCircle size={21} aria-hidden="true" /><h3>{homeUi.storyWrite}</h3><p>{homeUi.storyWriteText}</p></article>
              <article className="your-story-card"><ShieldCheck size={21} aria-hidden="true" /><h3>{homeUi.privacyFirst}</h3><p>{homeUi.privacyText}</p></article>
              <article className="your-story-card"><Share2 size={21} aria-hidden="true" /><h3>{homeUi.storyShare}</h3><p>{homeUi.storyShareText}</p></article>
            </div>
            <a
              href="/contact?topic=story"
              className="button button-primary your-story-button"
              onClick={() => trackEvent("story_submission_click", { destination: "/contact?topic=story", location: "homepage_story_section" })}
            >{homeUi.shareStory} <ArrowUpRight size={17} />
            </a>
          </div>
        </section>
        </ManagedHomeSection>

        <section className="trusted-partners-section" aria-label={isEnglish ? "Safe service policy" : "নিরাপদ সেবা নীতিমালা"}>
          <div className="trusted-partners-container">
            <h2 className="trusted-partners-title">{isEnglish ? "Safe service policy" : "নিরাপদ সেবা নীতিমালা"}</h2>
            <div className="trusted-partners-grid">
              <div className="trusted-partner-badge">
                <span className="trusted-partner-name">{isEnglish ? "No payment gateway" : "কোনো payment gateway নেই"}</span>
                <span className="trusted-partner-sub">{isEnglish ? "No money collection through this site" : "এই সাইটে টাকা গ্রহণ করা হয় না"}</span>
              </div>
              <div className="trusted-partner-badge">
                <span className="trusted-partner-name">{isEnglish ? "Official fees only" : "সরকারি ফি শুধু অফিসিয়াল পোর্টালে"}</span>
                <span className="trusted-partner-sub">{isEnglish ? "Never use a personal account for government fees" : "সরকারি ফি ব্যক্তিগত অ্যাকাউন্টে দেবেন না"}</span>
              </div>
              <div className="trusted-partner-badge">
                <span className="trusted-partner-name">{isEnglish ? "Protect personal information" : "ব্যক্তিগত তথ্য সুরক্ষিত রাখুন"}</span>
                <span className="trusted-partner-sub">{isEnglish ? "Do not share OTP, passwords, or NID details" : "OTP, পাসওয়ার্ড বা NID-এর তথ্য শেয়ার করবেন না"}</span>
              </div>
              <div className="trusted-partner-badge">
                <span className="trusted-partner-name">{isEnglish ? "Review before collaboration" : "সহযোগিতার আগে review"}</span>
                <span className="trusted-partner-sub">{isEnglish ? "NGO and institutional applications require owner verification" : "NGO ও প্রাতিষ্ঠানিক আবেদন owner verification সাপেক্ষ"}</span>
              </div>
            </div>
            <p className="trusted-partners-disclaimer">
              {isEnglish ? "SahajContact does not claim affiliation with any named payment, remittance, or telecom provider unless it is formally verified and disclosed." : "আনুষ্ঠানিকভাবে যাচাই ও প্রকাশ না করা পর্যন্ত SahajContact কোনো payment, remittance বা telecom provider-এর অংশীদারিত্বের দাবি করে না।"}
            </p>
          </div>
        </section>
        <PublicSeoSnapshot />
        <ManagedHomeSection layout={homeSectionLayout.gallery}>
        <section id="open-photo-gallery" aria-label={language === "EN" ? "Open public photo gallery" : "উন্মুক্ত পাবলিক ফটো গ্যালারি"}>
          <DeferredMount delay={1200}>
            <Suspense fallback={<p className="container py-8 text-sm text-slate-600" role="status">{language === "EN" ? "Loading the open photo gallery…" : "উন্মুক্ত ফটো গ্যালারি লোড হচ্ছে…"}</p>}>
              <OpenPhotoGallery />
            </Suspense>
          </DeferredMount>
        </section>
        </ManagedHomeSection>

        <ManagedHomeSection layout={homeSectionLayout.faq}>
        <section id="faq" className="footer-faq-section border-t border-[#d9e4dd] bg-[#f8fcf8] py-7 sm:py-9" aria-label={isEnglish ? "Frequently asked questions" : "সাধারণ জিজ্ঞাসা"}>
          <div className="container max-w-6xl">
            <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <span className="text-xs font-black uppercase tracking-[0.14em] text-[#0f766e]">{homeUi.faqLabel}</span>
                <h2 className="mt-1 font-serif text-2xl font-black leading-tight text-[#0d2b3e] sm:text-3xl">{homeUi.faqTitle}</h2>
              </div>
              <p className="max-w-2xl text-sm leading-6 text-slate-600">{homeUi.faqIntro}</p>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              {[
                [homeUi.faq1q, homeUi.faq1a],
                [homeUi.faq2q, homeUi.faq2a],
                [homeUi.faq3q, homeUi.faq3a],
                [homeUi.faq4q, homeUi.faq4a],
              ].map(([question, answer]) => <details key={question} className="rounded-xl border border-[#d9e4dd] bg-white px-4 py-3 shadow-sm">
                <summary className="cursor-pointer pr-5 text-sm font-black leading-6 text-[#0d2b3e] marker:text-[#0f766e]">{question}</summary>
                <p className="mt-2 text-sm leading-6 text-slate-600">{answer}</p>
              </details>)}
            </div>
          </div>
        </section>
        </ManagedHomeSection>
      </main>
      <SahajFooter />
      <SahajHelpPopup />

      {/* Apply Now Modal Dialog */}
      {guidanceModalOpen && (
        <div style={{ position: "fixed", inset: 0, zIndex: 9999, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}>
          <div style={{ background: "#ffffff", color: "#0f172a", borderRadius: "16px", maxWidth: "480px", width: "100%", padding: "2rem", boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)", position: "relative" }}>
            <button
              type="button"
              onClick={() => setGuidanceModalOpen(false)}
              style={{ position: "absolute", top: "1rem", right: "1rem", background: "none", border: "none", fontSize: "1.25rem", cursor: "pointer", color: "#64748b" }}
            >
              ✕
            </button>
            
            <div style={{ marginBottom: "1.5rem" }}>
              <span style={{ fontSize: "0.75rem", fontWeight: "700", textTransform: "uppercase", letterSpacing: "0.05em", color: "#0D47A1" }}>READ-ONLY GUIDANCE</span>
              <h3 style={{ fontSize: "1.5rem", fontWeight: "800", marginTop: "0.25rem", color: "#0f172a" }}>সেবার সরকারি নির্দেশনা</h3>
              <p style={{ fontSize: "0.9rem", color: "#475569", marginTop: "0.25rem" }}>
                নির্বাচিত সেবা: <strong style={{ color: "#0D47A1" }}>{selectedServiceForGuidance}</strong>
              </p>
            </div>
            <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: "12px", padding: "1rem", display: "grid", gap: "0.75rem" }}>
              <p style={{ margin: 0, color: "#334155", lineHeight: 1.6 }}>এই পোর্টালটি আপনার হয়ে আবেদন বা order তৈরি করে না এবং নাম, ফোন নম্বর, payment বা transaction তথ্য চায় না। উপরের <strong>ভিজিট</strong> button থেকে সংশ্লিষ্ট অফিসিয়াল পোর্টাল খুলুন।</p>
              <p style={{ margin: 0, color: "#6b4f00", fontSize: "0.9rem", lineHeight: 1.55 }}>সতর্কতা: OTP, PIN, পাসওয়ার্ড, পূর্ণ NID নম্বর বা payment number কখনো কারও সঙ্গে শেয়ার করবেন না।</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.75rem", marginTop: "0.25rem" }}>
                <Link href="/contact" className="button button-quiet">সাধারণ যোগাযোগ</Link>
                <button type="button" onClick={() => setGuidanceModalOpen(false)} className="button button-primary">বন্ধ করুন</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
