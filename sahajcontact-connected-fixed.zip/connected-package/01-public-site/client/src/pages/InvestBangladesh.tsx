import { useState } from "react";
import { Link } from "wouter";
import SahajHeader from "@/components/SahajHeader";
import SahajFooter from "@/components/SahajFooter";
import { useLanguage } from "@/contexts/LanguageContext";
import { 
  TrendingUp, 
  Users, 
  Building2, 
  Globe, 
  ArrowRight, 
  ExternalLink, 
  HeartHandshake,
  Briefcase
} from "lucide-react";

export default function InvestBangladesh() {
  const { language } = useLanguage();
  const isEn = language === "EN";

  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="public-civic-page public-invest-page min-h-screen bg-[#F8F9FA] text-foreground flex flex-col font-sans">
      <SahajHeader />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-r from-[#006A4E] via-[#047857] to-[#004D36] text-white py-16 md:py-24 px-4 overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
          <div className="container max-w-6xl mx-auto relative z-10 text-center">
            <div className="inline-flex items-center gap-2 bg-[#F42A41]/20 border border-[#F42A41]/40 px-4 py-1.5 rounded-full text-sm font-semibold mb-6 shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-[#F42A41] animate-pulse"></span>
              {isEn ? "Strategic Economic Gateway of South Asia" : "দক্ষিণ এশিয়ার উদীয়মান অর্থনৈতিক গেটওয়ে"}
            </div>
            
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
              {isEn ? (
                <>Invest in Bangladesh <span className="text-[#FFD700]">- 170 Million People Market</span></>
              ) : (
                <>বিনিয়োগের জন্য প্রস্তুত বাংলাদেশ <span className="text-[#FFD700]">- ১৭ কোটি মানুষের সম্ভাবনাময় বাজার</span></>
              )}
            </h1>

            <p className="text-lg md:text-xl text-emerald-100 max-w-3xl mx-auto mb-10 leading-relaxed font-normal">
              {isEn 
                ? "Discover a booming economy with sustained 6%+ growth, demographic dividend, strategic 100+ Special Economic Zones, and investor-friendly policies."
                : "৬% এর অধিক ধারাবাহিক প্রবৃদ্ধি, তরুণ কর্মক্ষম জনশক্তি, ১০০+ স্পেশাল ইকোনমিক জোন এবং বিনিয়োগবান্ধব পরিবেশ নিয়ে বাংলাদেশ আজ বিশ্ব বিনিয়োগকারীদের জন্য এক অনন্য সুযোগ।"
              }
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a
                href="#why-invest"
                className="inline-flex items-center justify-center gap-2 bg-[#F42A41] hover:bg-[#d92237] text-white font-bold px-8 py-3.5 rounded-xl shadow-lg transition-all transform active:scale-95"
              >
                {isEn ? "Explore Opportunities" : "সুযোগসমূহ জানুন"}
                <ArrowRight size={18} aria-hidden="true" />
              </a>
              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 border border-white/30 text-white font-semibold px-7 py-3.5 rounded-xl backdrop-blur-md transition-all"
              >
                <Globe size={18} aria-hidden="true" />
                {copied ? (isEn ? "Link Copied!" : "লিংক কপি হয়েছে!") : (isEn ? "Share Invest Page" : "পেজটি শেয়ার করুন")}
              </button>
            </div>
          </div>
        </section>

        {/* 4 Why Bangladesh Cards */}
        <section id="why-invest" className="py-16 px-4 container max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-sm font-bold uppercase tracking-wider text-[#006A4E] bg-emerald-100 px-3 py-1 rounded-full">
              {isEn ? "Why Bangladesh" : "কেন বাংলাদেশে বিনিয়োগ করবেন"}
            </span>
            <h2 className="text-2xl md:text-4xl font-bold mt-3 text-slate-900">
              {isEn ? "Core Pillars of Investment Growth" : "বিনিয়োগ বৃদ্ধির ৪টি মূল চালিকাশক্তি"}
            </h2>
            <p className="text-slate-600 mt-2 max-w-xl mx-auto">
              {isEn 
                ? "Key competitive advantages driving foreign direct investment and domestic business expansion."
                : "যেসব বিশেষ সুবিধার কারণে দেশি-বিদেশি বিনিয়োগকারীরা বাংলাদেশে ব্যবসা সম্প্রসারণে এগিয়ে আসছেন।"
              }
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Card 1: Market */}
            <div className="bg-white p-7 rounded-2xl shadow-md border border-slate-100 hover:shadow-xl transition-all group flex flex-col">
              <div className="w-14 h-14 rounded-xl bg-emerald-50 text-[#006A4E] flex items-center justify-center mb-5 group-hover:bg-[#006A4E] group-hover:text-white transition-colors">
                <Globe size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                {isEn ? "Massive Market" : "বিশাল বাজার (Market)"}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed flex-grow">
                {isEn 
                  ? "A booming domestic market of 170+ million consumers with a rapidly rising middle class and high purchasing power."
                  : "১৭ কোটির বেশি মানুষের অভ্যন্তরীণ বাজার এবং দ্রুত বর্ধনশীল মধ্যবিত্ত শ্রেণির ক্রমবর্ধমান চাহিদা।"
                }
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-semibold text-[#006A4E]">
                {isEn ? "170M+ Consumers" : "১৭০+ মিলিয়ন ভোক্তা"}
              </div>
            </div>

            {/* Card 2: Growth */}
            <div className="bg-white p-7 rounded-2xl shadow-md border border-slate-100 hover:shadow-xl transition-all group flex flex-col">
              <div className="w-14 h-14 rounded-xl bg-red-50 text-[#F42A41] flex items-center justify-center mb-5 group-hover:bg-[#F42A41] group-hover:text-white transition-colors">
                <TrendingUp size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                {isEn ? "Steady Growth" : "স্থায়ী প্রবৃদ্ধি (Growth)"}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed flex-grow">
                {isEn 
                  ? "Resilient GDP growth averaging over 6% annually, backed by robust exports, mega infrastructure, and digitization."
                  : "বার্ষিক ৬% এর অধিক ধারাবাহিক জিডিপি প্রবৃদ্ধি, শক্তিশালী রপ্তানি খাত ও মেগা অবকাঠামোর অগ্রগতি।"
                }
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-semibold text-[#F42A41]">
                {isEn ? "6%+ GDP Resilience" : "৬%+ জিডিপি প্রবৃদ্ধি"}
              </div>
            </div>

            {/* Card 3: Workforce */}
            <div className="bg-white p-7 rounded-2xl shadow-md border border-slate-100 hover:shadow-xl transition-all group flex flex-col">
              <div className="w-14 h-14 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-5 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Users size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                {isEn ? "Skilled Workforce" : "দক্ষ কর্মীবাহিনী (Workforce)"}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed flex-grow">
                {isEn 
                  ? "Abundant, cost-competitive, and tech-savvy young demographic dividend ready for industrial and digital transformation."
                  : "সুলভ মূল্যে তরুণ ও প্রযুক্তিমনস্ক কর্মীবাহিনী, যা শিল্প ও আইটি খাতের জন্য অত্যন্ত উপযোগী।"
                }
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-semibold text-blue-600">
                {isEn ? "Demographic Dividend" : "ডেমোগ্রাফিক ডিভিডেন্ড"}
              </div>
            </div>

            {/* Card 4: EZ */}
            <div className="bg-white p-7 rounded-2xl shadow-md border border-slate-100 hover:shadow-xl transition-all group flex flex-col">
              <div className="w-14 h-14 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-5 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                <Building2 size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                {isEn ? "Economic Zones" : "ইকোনমিক জোন (EZ)"}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed flex-grow">
                {isEn 
                  ? "100+ Special Economic Zones (SEZs) offering tax holidays, one-stop service, and state-of-the-art utility infrastructure."
                  : "১০০+ স্পেশাল ইকোনমিক জোন (SEZ) যেখানে কর অব্যাহতি, ওয়ান-স্টপ সার্ভিস ও আধুনিক সুযোগ-সুবিধা রয়েছে।"
                }
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-semibold text-amber-600">
                {isEn ? "100+ SEZs & Hi-Tech Parks" : "১০০+ স্পেশাল ইকোনমিক জোন"}
              </div>
            </div>
          </div>
        </section>

        {/* Key Sectors for Investment */}
        <section className="py-16 bg-white border-y border-slate-200 px-4">
          <div className="container max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <span className="text-sm font-bold uppercase tracking-wider text-[#F42A41] bg-red-100 px-3 py-1 rounded-full">
                {isEn ? "Lucrative Sectors" : "বিনিয়োগের প্রধান খাতসমূহ"}
              </span>
              <h2 className="text-2xl md:text-4xl font-bold mt-3 text-slate-900">
                {isEn ? "Key Sectors for High Return Investment" : "সর্বোচ্চ রিটার্ন ও সম্ভাবনাময় খাত"}
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 rounded-xl bg-[#F8F9FA] border border-slate-200">
                <div className="text-[#006A4E] font-bold text-lg mb-2 flex items-center gap-2">
                  <Briefcase size={20} />
                  {isEn ? "ICT & Software Outsourcing" : "আইসিটি ও সফটওয়্যার আউটসোর্সিং"}
                </div>
                <p className="text-slate-600 text-sm leading-relaxed">
                  {isEn 
                    ? "Government-backed Hi-Tech Parks, 100% foreign ownership allowed, tax exemptions for ITES companies."
                    : "সরকার সমর্থিত হাই-টেক পার্ক, শতভাগ বিদেশি মালিকানার সুযোগ এবং আইটিএস কোম্পানিতে কর অব্যাহতি।"
                  }
                </p>
              </div>

              <div className="p-6 rounded-xl bg-[#F8F9FA] border border-slate-200">
                <div className="text-[#006A4E] font-bold text-lg mb-2 flex items-center gap-2">
                  <Building2 size={20} />
                  {isEn ? "Textile & RMG Modernization" : "বস্ত্র ও তৈরি পোশাক আধুনিকায়ন"}
                </div>
                <p className="text-slate-600 text-sm leading-relaxed">
                  {isEn 
                    ? "World's second-largest apparel exporter shifting towards green factories, man-made fibers, and smart automation."
                    : "বিশ্বের দ্বিতীয় বৃহত্তম পোশাক রপ্তানিকারক দেশ, বর্তমানে সবুজ কারখানা (Green Factory) ও প্রযুক্তিনির্ভর উৎপাদনে অগ্রগামী।"
                  }
                </p>
              </div>

              <div className="p-6 rounded-xl bg-[#F8F9FA] border border-slate-200">
                <div className="text-[#006A4E] font-bold text-lg mb-2 flex items-center gap-2">
                  <TrendingUp size={20} />
                  {isEn ? "Agro-Processing & Cold Chain" : "কৃষি প্রক্রিয়াজাতকরণ ও কোল্ড চেইন"}
                </div>
                <p className="text-slate-600 text-sm leading-relaxed">
                  {isEn 
                    ? "High agricultural output with massive potential for export-oriented food processing, logistics, and cold storage."
                    : "প্রচুর কৃষিপণ্য উৎপাদিত হওয়ায় রপ্তানিমুখী খাদ্য প্রক্রিয়াজাতকরণ ও কোল্ড স্টোরেজ খাতে রয়েছে বিশাল সুযোগ।"
                  }
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Message for Expats Section */}
        <section className="py-16 px-4 container max-w-5xl mx-auto">
          <div className="bg-gradient-to-br from-[#006A4E] to-[#014734] text-white rounded-3xl p-8 md:p-12 shadow-xl relative overflow-hidden">
            <div className="absolute right-0 bottom-0 opacity-10 translate-x-10 translate-y-10">
              <Globe size={300} />
            </div>

            <div className="relative z-10 max-w-2xl">
              <span className="bg-[#FFD700] text-slate-900 text-xs font-extrabold uppercase px-3 py-1 rounded-full mb-4 inline-block">
                {isEn ? "Non-Resident Bangladeshi (NRB) Call" : "প্রবাসী বাংলাদেশীদের প্রতি বিশেষ আহ্বান"}
              </span>

              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                {isEn ? "Invest Your Hard-Earned Savings in Your Motherland" : "আপনার প্রবাসের কষ্টার্জিত সঞ্চয় দেশের মাটিতে বিনিয়োগ করুন"}
              </h2>

              <p className="text-emerald-100 text-sm md:text-base leading-relaxed mb-6">
                {isEn 
                  ? "Wherever you live—USA, UK, Middle East, Europe or Singapore—your contribution to Bangladesh is invaluable. Leverage NRB bonds, specialized industrial plots, and secure digital channels to participate in the nation's economic rise."
                  : "যুক্তরাষ্ট্র, যুক্তরাজ্য, মধ্যপ্রাচ্য, ইউরোপ বা সিঙ্গাপুর—যেখানেই থাকুন না কেন, দেশের অর্থনীতিতে আপনার প্রবাস জীবনের অবদান অনন্য। এনআরবি বন্ড, বিশেষ শিল্প প্লট এবং নিরাপদ ডিজিটাল চ্যানেলের মাধ্যমে দেশের উন্নয়নে অংশীদার হোন।"
                }
              </p>

              {/* Official information path */}
              <div className="bg-white/10 p-6 rounded-2xl border border-white/20 backdrop-blur-sm mb-6">
                <h3 className="text-lg font-bold text-white mb-3">
                  {isEn ? "Use official investment portals" : "সরকারি বিনিয়োগ পোর্টাল ব্যবহার করুন"}
                </h3>

                <p className="text-sm leading-relaxed text-emerald-100 mb-4">
                  {isEn
                    ? "SahajContact does not provide investment advice, accept payments, or operate a private investment desk. Please use the official BIDA and BEZA portals below for current guidance and verified contact routes."
                    : "SahajContact বিনিয়োগ পরামর্শ দেয় না, পেমেন্ট গ্রহণ করে না এবং কোনো ব্যক্তিগত বিনিয়োগ ডেস্ক পরিচালনা করে না। হালনাগাদ নির্দেশনা ও যাচাইকৃত যোগাযোগের জন্য নিচের BIDA ও BEZA-এর সরকারি পোর্টাল ব্যবহার করুন।"
                  }
                </p>

                <a
                  href="#official-investment-portals"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/40 bg-white/10 px-5 py-3 font-bold text-white transition-colors hover:bg-white/20"
                >
                  <ExternalLink size={18} aria-hidden="true" />
                  {isEn ? "View official portals" : "সরকারি পোর্টাল দেখুন"}
                </a>

                <p className="mt-4 text-xs italic text-emerald-200">
                  {isEn
                    ? "No personal payment number, transaction reference, banking detail, OTP, PIN, or investment document should be sent through this portal."
                    : "এই পোর্টালে কোনো ব্যক্তিগত পেমেন্ট নম্বর, transaction reference, ব্যাংক তথ্য, OTP, PIN বা বিনিয়োগের নথি পাঠাবেন না।"
                  }
                </p>
              </div>

              {/* Civic Disclaimer */}
              <div className="text-xs text-emerald-200 bg-black/20 p-3 rounded-xl border border-white/10">
                {isEn 
                  ? "Disclaimer: SahajContact is a civic information portal. Not a government entity."
                  : "ডিসক্লেইমার: SahajContact একটি নাগরিক তথ্য পোর্টাল। এটি কোনো সরকারি সত্তা বা অফিসিয়াল গভর্মেন্ট বডি নয়।"
                }
              </div>
            </div>
          </div>
        </section>

        {/* Official Links to BIDA, BEZA, Bangladesh Bank */}
        <section id="official-investment-portals" className="py-12 bg-slate-100 border-t border-slate-200 px-4">
          <div className="container max-w-6xl mx-auto text-center">
            <h3 className="text-xl font-bold text-slate-900 mb-6">
              {isEn ? "Official Government Investment Portals" : "সরকারি বিনিয়োগ পোর্টাল ও সংস্থাসমূহ"}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <a
                href="https://bida.gov.bd"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md border border-slate-200 flex items-center justify-between group transition-all"
              >
                <div className="text-left">
                  <div className="font-bold text-slate-900 group-hover:text-[#006A4E] transition-colors">BIDA (বিডা)</div>
                  <div className="text-xs text-slate-500">Bangladesh Investment Development Authority</div>
                </div>
                <ExternalLink size={18} className="text-slate-400 group-hover:text-[#006A4E]" />
              </a>

              <a
                href="https://www.beza.gov.bd"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md border border-slate-200 flex items-center justify-between group transition-all"
              >
                <div className="text-left">
                  <div className="font-bold text-slate-900 group-hover:text-[#006A4E] transition-colors">BEZA (বেজা)</div>
                  <div className="text-xs text-slate-500">Bangladesh Economic Zones Authority</div>
                </div>
                <ExternalLink size={18} className="text-slate-400 group-hover:text-[#006A4E]" />
              </a>

              <a
                href="https://www.bb.org.bd"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md border border-slate-200 flex items-center justify-between group transition-all"
              >
                <div className="text-left">
                  <div className="font-bold text-slate-900 group-hover:text-[#006A4E] transition-colors">Bangladesh Bank</div>
                  <div className="text-xs text-slate-500">Central Bank Investment Guidelines</div>
                </div>
                <ExternalLink size={18} className="text-slate-400 group-hover:text-[#006A4E]" />
              </a>
            </div>
          </div>
        </section>
      </main>

      <SahajFooter />
    </div>
  );
}
