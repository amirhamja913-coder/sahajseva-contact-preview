import { useMemo, useState } from "react";
import { Link } from "wouter";
import { Activity, Handshake, Send } from "lucide-react";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

export default function InvestorsPage() {
  const { language } = useLanguage();
  const overviewQuery = trpc.adminAnalytics.investors.overview.useQuery();
  const [submitted, setSubmitted] = useState(false);
  const submitMutation = trpc.adminAnalytics.investors.submit.useMutation({ onSuccess: () => setSubmitted(true) });
  const copy = useMemo(() => language === "EN" ? {
    eyebrow: "Investment & partnership", title: "Build trusted civic access with us", text: "SahajContact makes verified public-service routes easier to find. Current figures below are sourced from the latest saved analytics snapshot when available.", traffic: "Latest traffic snapshot", users: "Active users", views: "Page views", sessions: "Sessions", revenue: "Revenue disclosure", revenueText: "Public revenue figures are not published. Advertising plans and partnership opportunities are discussed case by case.", plan: "Advertising plan", contact: "Send an investor enquiry", name: "Name", org: "Organisation (optional)", message: "Your interest or proposal", submit: "Send enquiry", success: "Thank you. Your investor enquiry has been securely recorded for review.", home: "Back to home",
  } : {
    eyebrow: "বিনিয়োগ ও অংশীদারত্ব", title: "বিশ্বস্ত নাগরিক সহায়তা গড়তে পাশে থাকুন", text: "SahajContact যাচাইকৃত সরকারি সেবার পথ সহজে খুঁজে পেতে সহায়তা করে। নিচের তথ্য সর্বশেষ সংরক্ষিত analytics snapshot থেকে দেখানো হয়।", traffic: "সর্বশেষ ট্রাফিক snapshot", users: "Active users", views: "Page views", sessions: "Sessions", revenue: "আয়ের তথ্য", revenueText: "সর্বজনীন revenue figure প্রকাশ করা হয় না। বিজ্ঞাপন পরিকল্পনা ও অংশীদারত্ব case-by-case আলোচনা করা হয়।", plan: "বিজ্ঞাপন পরিকল্পনা", contact: "Investor enquiry পাঠান", name: "নাম", org: "প্রতিষ্ঠান (ঐচ্ছিক)", message: "আপনার আগ্রহ বা প্রস্তাব", submit: "Enquiry পাঠান", success: "ধন্যবাদ। আপনার investor enquiry নিরাপদে review-এর জন্য সংরক্ষিত হয়েছে।", home: "হোমে ফিরুন",
  }, [language]);
  const analytics = overviewQuery.data?.analytics;

  return (
    <div className="public-civic-page min-h-screen bg-slate-950 text-slate-100">
      <SahajHeader />
      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <section className="rounded-3xl border border-indigo-400/20 bg-gradient-to-br from-indigo-950/70 via-slate-900 to-slate-950 p-6 shadow-2xl sm:p-10">
          <p className="text-sm font-bold uppercase tracking-[0.16em] text-indigo-300">{copy.eyebrow}</p>
          <h1 className="mt-3 max-w-3xl text-3xl font-black tracking-tight sm:text-5xl">{copy.title}</h1>
          <p className="mt-4 max-w-3xl leading-7 text-slate-300">{copy.text}</p>
          <div className="mt-8">
            <h2 className="flex items-center gap-2 text-lg font-bold"><Activity className="h-5 w-5 text-indigo-300" />{copy.traffic}</h2>
            <div className="mt-3 grid gap-3 sm:grid-cols-3">
              {[[copy.users, analytics?.activeUsers], [copy.views, analytics?.pageViews], [copy.sessions, analytics?.sessions]].map(([label, value]) => (
                <div key={String(label)} className="rounded-2xl border border-white/10 bg-slate-950/55 p-4"><p className="text-sm text-slate-400">{label}</p><p className="mt-1 text-3xl font-black">{value === undefined || value === null ? "—" : Number(value).toLocaleString("en-BD")}</p></div>
              ))}
            </div>
            <p className="mt-3 text-xs text-slate-400">{analytics?.capturedAt ? `${language === "EN" ? "Captured" : "সংরক্ষিত"}: ${new Date(analytics.capturedAt).toLocaleString("en-BD")}` : (language === "EN" ? "No public analytics snapshot is available yet." : "এখনও কোনো public analytics snapshot পাওয়া যায়নি।")}</p>
          </div>
        </section>

        <div className="mt-8 grid gap-8 lg:grid-cols-2">
          <section className="rounded-3xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-xl font-bold">{copy.revenue}</h2><p className="mt-3 leading-7 text-slate-300">{copy.revenueText}</p>
            <h2 className="mt-7 flex items-center gap-2 text-xl font-bold"><Handshake className="h-5 w-5 text-indigo-300" />{copy.plan}</h2>
            <div className="mt-4 grid gap-3">{(overviewQuery.data?.prices || []).map((price: any) => <div key={price.slot} className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950 p-4"><span className="font-semibold capitalize">{price.slot}</span><span className="font-black text-indigo-200">৳{Number(price.priceBdt).toLocaleString("en-BD")}</span></div>)}</div>
          </section>
          <form onSubmit={(event) => { event.preventDefault(); const form = new FormData(event.currentTarget); submitMutation.mutate({ name: String(form.get("name") || "").trim(), email: String(form.get("email") || "").trim(), organisation: form.get("organisation")?.toString().trim() || null, message: String(form.get("message") || "").trim() }); }} className="rounded-3xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-xl font-bold">{copy.contact}</h2>
            {submitted ? <p className="mt-5 rounded-xl border border-emerald-500/25 bg-emerald-950/25 p-4 leading-7 text-emerald-100">{copy.success}</p> : <div className="mt-5 space-y-4">
              <PublicField label={copy.name} name="name" required /><PublicField label="Email" name="email" type="email" required /><PublicField label={copy.org} name="organisation" />
              <label className="block text-sm text-slate-300">{copy.message}<textarea required minLength={10} name="message" rows={5} className="mt-1.5 w-full resize-y rounded-xl border border-slate-700 bg-slate-950 px-3 py-3 text-white" /></label>
              <button disabled={submitMutation.isPending} className="inline-flex items-center gap-2 rounded-xl bg-indigo-500 px-5 py-3 font-bold text-white transition hover:bg-indigo-400 disabled:opacity-60"><Send className="h-4 w-4" />{copy.submit}</button>
              {submitMutation.error && <p className="text-sm text-rose-300">{submitMutation.error.message}</p>}
            </div>}
          </form>
        </div>
        <Link href="/" className="mt-8 inline-block font-bold text-indigo-300 hover:text-indigo-200">← {copy.home}</Link>
      </main>
      <SahajFooter />
    </div>
  );
}

function PublicField({ label, name, type = "text", required = false }: { label: string; name: string; type?: string; required?: boolean }) {
  return <label className="block text-sm text-slate-300">{label}<input required={required} type={type} name={name} className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-3 text-white" /></label>;
}
