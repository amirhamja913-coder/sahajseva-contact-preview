import { Newspaper, Tv } from "lucide-react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import MediaHubSection, { type MediaHubView } from "@/components/MediaHubSection";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

type MediaDirectoryPageProps = {
  view: Exclude<MediaHubView, "all">;
};

export default function MediaDirectoryPage({ view }: MediaDirectoryPageProps) {
  const { language } = useLanguage();
  const isBangla = language === "BN";
  const travelContentQuery = trpc.siteManagement.getTravelContent.useQuery(undefined, {
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
  const isTv = view === "tv";
  const title = isTv
    ? (isBangla ? "টিভি চ্যানেল" : "TV Channels")
    : (isBangla ? "জাতীয় পত্রিকা" : "National Newspapers");
  const description = isTv
    ? (isBangla ? "নির্বাচিত টিভি চ্যানেলের অফিসিয়াল ওয়েবসাইট এক জায়গায় দেখুন।" : "Find official websites for selected television channels in one place.")
    : (isBangla ? "নির্বাচিত জাতীয় পত্রিকার অফিসিয়াল ওয়েবসাইট এক জায়গায় দেখুন।" : "Find official websites for selected national newspapers in one place.");
  const accent = isTv ? "টিভি" : "পত্রিকা";

  return (
    <div className="site-shell">
      <SahajHeader />
      <main>
        <section aria-labelledby="media-directory-title" style={{ padding: "3.25rem 0 2.5rem", background: "radial-gradient(circle at 8% 12%, rgba(15,118,110,0.15) 0, transparent 22rem), linear-gradient(135deg, #fffdf5 0%, #f4fbf8 52%, #fff7df 100%)", borderBottom: "1px solid #d8e7df" }}>
          <div className="container">
            <Link href="/#media-hub" style={{ display: "inline-flex", color: "#0f766e", fontSize: "0.9rem", fontWeight: 800, textDecoration: "none" }}>
              ← {isBangla ? "মিডিয়া হাবে ফিরে যান" : "Back to Media Hub"}
            </Link>
            <p style={{ margin: "1.35rem 0 0", color: "#0f766e", fontSize: "0.8rem", fontWeight: 900, letterSpacing: "0.1em" }}>{isBangla ? `প্রবাসী মিডিয়া হাব / ${accent}` : `DIASPORA MEDIA HUB / ${isTv ? "TELEVISION" : "NEWSPAPERS"}`}</p>
            <h1 id="media-directory-title" style={{ margin: "0.45rem 0 0", maxWidth: "760px", color: "#102a43", fontSize: "clamp(2rem, 5vw, 3.7rem)", lineHeight: 1.05, fontWeight: 950 }}>{title}</h1>
            <p style={{ maxWidth: "650px", margin: "0.85rem 0 0", color: "#475569", fontSize: "1.05rem", lineHeight: 1.7 }}>{description}</p>
            <nav aria-label={isBangla ? "মিডিয়া বিভাগ নির্বাচন" : "Choose media directory"} style={{ display: "flex", gap: "0.7rem", flexWrap: "wrap", marginTop: "1.5rem" }}>
              <Link href="/tv-channels" aria-current={isTv ? "page" : undefined} style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", minHeight: "2.75rem", padding: "0.58rem 1rem", borderRadius: "999px", background: isTv ? "#0f766e" : "#fffdf8", color: isTv ? "#fff" : "#0f766e", border: "1px solid #0f766e", fontWeight: 850, textDecoration: "none" }}>
                <Tv size={17} aria-hidden="true" /> {isBangla ? "টিভি চ্যানেল" : "TV Channels"}
              </Link>
              <Link href="/newspapers" aria-current={!isTv ? "page" : undefined} style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", minHeight: "2.75rem", padding: "0.58rem 1rem", borderRadius: "999px", background: !isTv ? "#0f766e" : "#fffdf8", color: !isTv ? "#fff" : "#0f766e", border: "1px solid #0f766e", fontWeight: 850, textDecoration: "none" }}>
                <Newspaper size={17} aria-hidden="true" /> {isBangla ? "জাতীয় পত্রিকা" : "National Newspapers"}
              </Link>
            </nav>
          </div>
        </section>

        {travelContentQuery.isLoading ? (
          <section aria-busy="true" style={{ padding: "4rem 0", background: "#fffdf8" }}>
            <div className="container" style={{ color: "#475569", fontWeight: 700 }}>{isBangla ? "মিডিয়া তালিকা লোড হচ্ছে…" : "Loading media directory…"}</div>
          </section>
        ) : (
          <MediaHubSection
            settings={travelContentQuery.data?.mediaHubSettings}
            channels={travelContentQuery.data?.mediaHubChannels ?? []}
            language={language}
            view={view}
            headingOverride={{
              kicker: isBangla ? `প্রকাশিত ${isTv ? "টিভি চ্যানেল" : "জাতীয় পত্রিকা"}` : `PUBLISHED ${isTv ? "TV CHANNELS" : "NATIONAL NEWSPAPERS"}`,
              title,
              description,
            }}
          />
        )}
      </main>
      <SahajFooter />
    </div>
  );
}
