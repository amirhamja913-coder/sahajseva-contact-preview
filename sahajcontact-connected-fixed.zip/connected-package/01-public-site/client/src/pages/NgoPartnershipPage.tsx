import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Building2, CheckCircle2, Handshake, Landmark, Loader2, MapPinned, Send, ShieldCheck, Sparkles, UsersRound } from "lucide-react";
import SahajCivicChatWidget from "@/components/SahajCivicChatWidget";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

type PartnershipForm = {
  organizationName: string;
  registrationOrOfficialUrl: string;
  contactName: string;
  email: string;
  phone: string;
  programmeFocus: string;
  coverageArea: string;
  collaborationProposal: string;
  consentAccepted: boolean;
};

const initialForm: PartnershipForm = {
  organizationName: "",
  registrationOrOfficialUrl: "",
  contactName: "",
  email: "",
  phone: "",
  programmeFocus: "",
  coverageArea: "",
  collaborationProposal: "",
  consentAccepted: false,
};

export default function NgoPartnershipPage() {
  const { language } = useLanguage();
  const isEnglish = language === "EN";
  const [form, setForm] = useState<PartnershipForm>(initialForm);
  const [submitted, setSubmitted] = useState(false);
  const submitApplication = trpc.ngoPartnership.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setForm(initialForm);
    },
  });

  const copy = isEnglish
    ? {
        back: "Back to home",
        badge: "Public-benefit collaboration proposal",
        title: "Let’s make trustworthy civic information easier to reach",
        intro: "SahajContact is an independent civic-information platform. Government bodies, registered NGOs, foundations, socially responsible companies, investors, sponsors and advertisers may review this proposal and submit an institutional expression of interest for a lawful, practical and transparent public-benefit discussion.",
        notRepresentation: "SahajContact is not a government body and does not represent any NGO, company or public institution.",
        audienceTitle: "Who may submit an expression of interest",
        audiences: ["Government and public-service bodies", "Registered NGOs, foundations and development organisations", "Socially responsible companies and corporate CSR teams", "Investors, sponsors and responsible advertisers"],
        proposalTitle: "A practical route to public benefit",
        proposalLead: "The objective is to help people find verified civic-service information and safe next steps. Any discussion of social investment, grant support, sponsorship or advertising remains subject to private owner review, legal and policy checks, and a separate written arrangement.",
        focusTitle: "Possible collaboration areas",
        focuses: ["Digital literacy and safe service-navigation guidance", "Community outreach, inclusion and accessibility", "Verified public-information awareness campaigns", "Training, research or pilot initiatives with clear roles", "Lawful social-investment, grant, sponsorship or responsible-advertising discussions after review"],
        safeguardsTitle: "How we keep it transparent",
        safeguards: ["Applications are privately reviewed by the site owner.", "Submitting this form does not create a partnership, approval, endorsement, payment obligation, advertising placement or public listing.", "No applicant is described publicly as a partner unless a separate written decision is deliberately published.", "This form does not accept donations, payments, banking details, NID, OTP, passwords or unrelated sensitive documents."],
        formTitle: "Submit a structured institutional expression of interest",
        formLead: "Tell us about your organisation, public-benefit focus and proposed collaboration. A saved application starts in private pending review; it is not a funding request approval, partnership confirmation or advertising booking.",
        organisationName: "Organisation name",
        officialUrl: "Registration reference or official website (optional)",
        contactName: "Contact person",
        email: "Official email address",
        phone: "Phone / WhatsApp",
        programmeFocus: "Programme or service focus",
        coverageArea: "Coverage area",
        proposal: "Proposed collaboration",
        consent: "I confirm that I may share these business contact details and understand that submission does not create or verify a partnership.",
        submit: "Submit for owner review",
        submitting: "Submitting…",
        successTitle: "Your application has been saved for private review.",
        successText: "This is not a partnership confirmation or public listing. The responsible owner may contact the organisation after review.",
        another: "Submit another application",
        errorPrefix: "We could not save the application:",
      }
    : {
        back: "হোমপেজে ফিরে যান",
        badge: "জনসেবামুখী সহযোগিতার আগ্রহপত্র",
        title: "নির্ভরযোগ্য নাগরিক-তথ্য মানুষের কাছে সহজে পৌঁছাতে একসঙ্গে কাজের প্রস্তাব",
        intro: "SahajContact একটি স্বাধীন নাগরিক-তথ্য প্ল্যাটফর্ম। সরকারি সংস্থা, নিবন্ধিত NGO, ফাউন্ডেশন, সামাজিক দায়বদ্ধ কোম্পানি, বিনিয়োগকারী, sponsor ও বিজ্ঞাপনদাতা এই প্রস্তাব দেখে আইনসম্মত, ব্যবহারিক ও স্বচ্ছ জনকল্যাণমূলক সহযোগিতা নিয়ে প্রাতিষ্ঠানিক আগ্রহ জানাতে পারে।",
        notRepresentation: "SahajContact কোনো সরকারি সংস্থা নয় এবং কোনো NGO, কোম্পানি বা সরকারি প্রতিষ্ঠানের প্রতিনিধি নয়।",
        audienceTitle: "যারা আগ্রহপত্র দিতে পারেন",
        audiences: ["সরকারি ও জনসেবামূলক সংস্থা", "নিবন্ধিত NGO, ফাউন্ডেশন ও উন্নয়ন সংস্থা", "সামাজিক দায়বদ্ধ কোম্পানি ও CSR টিম", "বিনিয়োগকারী, sponsor ও দায়িত্বশীল বিজ্ঞাপনদাতা"],
        proposalTitle: "জনকল্যাণে কাজের একটি ব্যবহারিক পথ",
        proposalLead: "উদ্দেশ্য হলো যাচাইকৃত নাগরিকসেবার তথ্য ও নিরাপদ পরবর্তী ধাপ মানুষের কাছে সহজে পৌঁছানো। সামাজিক বিনিয়োগ, grant, sponsorship বা বিজ্ঞাপন-সংক্রান্ত কোনো আলোচনা private owner review, আইন ও নীতি যাচাই এবং আলাদা লিখিত সমঝোতার পরই বিবেচ্য হবে।",
        focusTitle: "সম্ভাব্য সহযোগিতার ক্ষেত্র",
        focuses: ["ডিজিটাল সাক্ষরতা ও নিরাপদ সেবা-নেভিগেশন নির্দেশনা", "কমিউনিটি আউটরিচ, অন্তর্ভুক্তি ও প্রবেশগম্যতা", "যাচাইকৃত জনতথ্য সচেতনতা কার্যক্রম", "স্পষ্ট দায়িত্বসহ প্রশিক্ষণ, গবেষণা বা পাইলট উদ্যোগ", "পর্যালোচনার পর আইনসম্মত সামাজিক বিনিয়োগ, grant, sponsorship বা দায়িত্বশীল বিজ্ঞাপন আলোচনা"],
        safeguardsTitle: "স্বচ্ছতা কীভাবে বজায় থাকে",
        safeguards: ["প্রতিটি আবেদন site owner ব্যক্তিগতভাবে পর্যালোচনা করেন।", "আবেদন জমা মানে পার্টনারশিপ, অনুমোদন, সমর্থন, অর্থপ্রদানের দায়, বিজ্ঞাপন স্থাপন বা public listing তৈরি হওয়া নয়।", "আলাদা লিখিত সিদ্ধান্ত সচেতনভাবে প্রকাশ না করা পর্যন্ত কাউকে public partner বলা হবে না।", "এই ফর্মে অনুদান, পেমেন্ট, ব্যাংক তথ্য, NID, OTP, পাসওয়ার্ড বা অপ্রাসঙ্গিক সংবেদনশীল নথি দেবেন না।"],
        formTitle: "প্রাতিষ্ঠানিক আগ্রহপত্র জমা দিন",
        formLead: "প্রতিষ্ঠানের পরিচয়, জনকল্যাণে কাজের ক্ষেত্র ও প্রস্তাবিত সহযোগিতার ধারণা লিখুন। সংরক্ষিত প্রতিটি আবেদন শুরুতে private pending review অবস্থায় থাকবে; এটি funding approval, partnership confirmation বা বিজ্ঞাপন booking নয়।",
        organisationName: "প্রতিষ্ঠানের নাম",
        officialUrl: "নিবন্ধন রেফারেন্স বা অফিসিয়াল ওয়েবসাইট (ঐচ্ছিক)",
        contactName: "যোগাযোগকারী ব্যক্তির নাম",
        email: "অফিসিয়াল ইমেইল ঠিকানা",
        phone: "ফোন / WhatsApp",
        programmeFocus: "কর্মসূচি বা সেবার ক্ষেত্র",
        coverageArea: "কাজের এলাকা",
        proposal: "প্রস্তাবিত সহযোগিতার বিবরণ",
        consent: "আমি নিশ্চিত করছি যে এই business contact তথ্য দেওয়ার অনুমতি আমার আছে এবং আবেদন জমা মানে পার্টনারশিপ তৈরি বা যাচাই হওয়া নয়।",
        submit: "Owner review-এর জন্য জমা দিন",
        submitting: "জমা হচ্ছে…",
        successTitle: "আপনার আবেদন private review-এর জন্য সংরক্ষিত হয়েছে।",
        successText: "এটি পার্টনারশিপ নিশ্চিতকরণ বা public listing নয়। পর্যালোচনার পর দায়িত্বপ্রাপ্ত owner প্রতিষ্ঠানের সঙ্গে যোগাযোগ করতে পারেন।",
        another: "আরেকটি আবেদন দিন",
        errorPrefix: "আবেদনটি সংরক্ষণ করা যায়নি:",
      };

  const update = <Key extends keyof PartnershipForm>(key: Key, value: PartnershipForm[Key]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(false);
    submitApplication.mutate(form);
  };

  return (
    <div className="public-civic-page min-h-screen bg-slate-950 text-slate-100">
      <SahajHeader />
      <main className="container mx-auto max-w-6xl px-4 py-8 sm:py-12">
        <Link href="/" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-teal-300 transition hover:text-teal-200"><ArrowLeft className="h-4 w-4" />{copy.back}</Link>

        <section className="relative overflow-hidden rounded-3xl border border-teal-400/20 bg-[radial-gradient(circle_at_top_right,_rgba(45,212,191,0.18),_transparent_42%),linear-gradient(135deg,_rgba(15,118,110,0.24),_rgba(15,23,42,0.94))] p-6 shadow-2xl shadow-teal-950/30 sm:p-10">
          <div className="relative max-w-4xl space-y-5">
            <p className="inline-flex items-center gap-2 rounded-full border border-teal-300/20 bg-teal-300/10 px-3 py-1.5 text-xs font-bold tracking-wide text-teal-100"><Handshake className="h-3.5 w-3.5" />{copy.badge}</p>
            <h1 className="text-3xl font-black leading-tight text-white sm:text-5xl">{copy.title}</h1>
            <p className="max-w-3xl text-base leading-8 text-slate-200 sm:text-lg">{copy.intro}</p>
            <div className="flex items-start gap-3 rounded-2xl border border-amber-300/25 bg-amber-300/10 p-4 text-sm leading-6 text-amber-100"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" /><p>{copy.notRepresentation}</p></div>
            <div className="pt-1">
              <h2 className="text-sm font-bold tracking-wide text-teal-100">{copy.audienceTitle}</h2>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">{copy.audiences.map((item) => <li key={item} className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100"><UsersRound className="h-4 w-4 shrink-0 text-teal-300" />{item}</li>)}</ul>
            </div>
          </div>
        </section>

        <section className="mt-8 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
          <article className="rounded-2xl border border-slate-700 bg-slate-900/80 p-6 shadow-xl sm:p-7">
            <div className="flex items-start gap-3"><span className="rounded-xl bg-teal-400/10 p-3 text-teal-300"><Landmark className="h-6 w-6" /></span><div><h2 className="text-2xl font-bold text-white">{copy.proposalTitle}</h2><p className="mt-2 text-sm leading-7 text-slate-300">{copy.proposalLead}</p></div></div>
            <h3 className="mt-6 text-base font-bold text-white">{copy.focusTitle}</h3>
            <ul className="mt-3 grid gap-3 sm:grid-cols-2">{copy.focuses.map((item) => <li key={item} className="flex gap-2 rounded-xl border border-slate-700/70 bg-slate-950/70 p-3 text-sm leading-6 text-slate-200"><Sparkles className="mt-1 h-4 w-4 shrink-0 text-teal-300" />{item}</li>)}</ul>
          </article>

          <aside className="rounded-2xl border border-indigo-400/20 bg-indigo-950/20 p-6 shadow-xl sm:p-7">
            <div className="flex items-center gap-3"><span className="rounded-xl bg-indigo-400/10 p-3 text-indigo-200"><ShieldCheck className="h-6 w-6" /></span><h2 className="text-xl font-bold text-white">{copy.safeguardsTitle}</h2></div>
            <ul className="mt-5 space-y-4">{copy.safeguards.map((item) => <li key={item} className="flex gap-3 text-sm leading-6 text-slate-200"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-indigo-300" />{item}</li>)}</ul>
          </aside>
        </section>

        <section className="mt-8 rounded-3xl border border-slate-700 bg-slate-900 p-6 shadow-2xl sm:p-9" aria-labelledby="ngo-application-heading">
          <div className="max-w-3xl"><div className="flex items-center gap-3"><span className="rounded-xl bg-teal-400/10 p-3 text-teal-300"><Building2 className="h-6 w-6" /></span><h2 id="ngo-application-heading" className="text-2xl font-bold text-white">{copy.formTitle}</h2></div><p className="mt-3 text-sm leading-7 text-slate-300">{copy.formLead}</p></div>
          {submitted ? <div className="mt-6 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-5"><div className="flex gap-3"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-300" /><div><h3 className="font-bold text-emerald-100">{copy.successTitle}</h3><p className="mt-1 text-sm leading-6 text-emerald-50/90">{copy.successText}</p><button type="button" onClick={() => setSubmitted(false)} className="mt-4 text-sm font-bold text-emerald-200 underline underline-offset-4 hover:text-white">{copy.another}</button></div></div></div> : <form onSubmit={handleSubmit} className="mt-7 space-y-5">
            {submitApplication.error && <div role="alert" className="rounded-xl border border-rose-400/30 bg-rose-400/10 p-4 text-sm text-rose-100">{copy.errorPrefix} {submitApplication.error.message}</div>}
            <div className="grid gap-5 md:grid-cols-2">
              <FormField label={copy.organisationName} required><input required value={form.organizationName} onChange={(event) => update("organizationName", event.target.value)} className={inputClass} autoComplete="organization" /></FormField>
              <FormField label={copy.contactName} required><input required value={form.contactName} onChange={(event) => update("contactName", event.target.value)} className={inputClass} autoComplete="name" /></FormField>
              <FormField label={copy.email} required><input required type="email" value={form.email} onChange={(event) => update("email", event.target.value)} className={inputClass} autoComplete="email" /></FormField>
              <FormField label={copy.phone} required><input required type="tel" value={form.phone} onChange={(event) => update("phone", event.target.value)} className={inputClass} autoComplete="tel" /></FormField>
              <FormField label={copy.officialUrl}><input type="url" value={form.registrationOrOfficialUrl} onChange={(event) => update("registrationOrOfficialUrl", event.target.value)} className={inputClass} placeholder="https://" autoComplete="url" /></FormField>
              <FormField label={copy.coverageArea} required><input required value={form.coverageArea} onChange={(event) => update("coverageArea", event.target.value)} className={inputClass} /></FormField>
            </div>
            <FormField label={copy.programmeFocus} required><input required value={form.programmeFocus} onChange={(event) => update("programmeFocus", event.target.value)} className={inputClass} /></FormField>
            <FormField label={copy.proposal} required><textarea required rows={6} value={form.collaborationProposal} onChange={(event) => update("collaborationProposal", event.target.value)} className={`${inputClass} resize-y`} /></FormField>
            <label className="flex items-start gap-3 rounded-xl border border-slate-700 bg-slate-950/70 p-4 text-sm leading-6 text-slate-200"><input required type="checkbox" checked={form.consentAccepted} onChange={(event) => update("consentAccepted", event.target.checked)} className="mt-1 h-4 w-4 accent-teal-400" /><span>{copy.consent}</span></label>
            <button type="submit" disabled={submitApplication.isPending} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-teal-500 px-5 py-3 font-bold text-slate-950 transition hover:bg-teal-400 disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"><Send className="h-4 w-4" />{submitApplication.isPending ? <><Loader2 className="h-4 w-4 animate-spin" />{copy.submitting}</> : copy.submit}</button>
          </form>}
        </section>
      </main>
      <SahajCivicChatWidget />
      <SahajFooter />
    </div>
  );
}

const inputClass = "mt-2 block w-full rounded-xl border border-slate-600 bg-slate-950 px-3.5 py-3 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-teal-300 focus:ring-2 focus:ring-teal-300/20";

function FormField({ label, required = false, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return <label className="block text-sm font-semibold text-slate-100"><span>{label}{required ? <span className="ml-1 text-teal-300">*</span> : null}</span>{children}</label>;
}
