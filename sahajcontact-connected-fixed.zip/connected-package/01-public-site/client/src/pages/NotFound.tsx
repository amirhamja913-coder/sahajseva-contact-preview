import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Home } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/contexts/LanguageContext";

export default function NotFound() {
  const [, setLocation] = useLocation();
  const { language } = useLanguage();
  const contentQuery = trpc.siteManagement.getPublicContent.useQuery(undefined, { staleTime: 60_000, refetchOnWindowFocus: false });
  const settings = contentQuery.data?.settings;
  const isEnglish = language === "EN";
  const title = isEnglish ? settings?.notFoundTitleEn || settings?.notFoundTitleBn || "Page Not Found" : settings?.notFoundTitleBn || settings?.notFoundTitleEn || "পৃষ্ঠা পাওয়া যায়নি";
  const message = isEnglish ? settings?.notFoundMessageEn || settings?.notFoundMessageBn || "Sorry, the page you are looking for does not exist." : settings?.notFoundMessageBn || settings?.notFoundMessageEn || "দুঃখিত, আপনি যে পৃষ্ঠাটি খুঁজছেন সেটি পাওয়া যায়নি।";
  const goHomeLabel = isEnglish ? "Go Home" : "হোমে ফিরে যান";

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
      <Card className="mx-4 w-full max-w-lg border-0 bg-white/80 shadow-lg backdrop-blur-sm">
        <CardContent className="pb-8 pt-8 text-center">
          <div className="mb-6 flex justify-center"><div className="relative"><div className="absolute inset-0 animate-pulse rounded-full bg-red-100" /><AlertCircle className="relative h-16 w-16 text-red-500" /></div></div>
          <h1 className="mb-2 text-4xl font-bold text-slate-900">404</h1>
          <h2 className="mb-4 text-xl font-semibold text-slate-700">{title}</h2>
          <p className="mb-8 whitespace-pre-line leading-relaxed text-slate-600">{message}</p>
          <div id="not-found-button-group" className="flex flex-col justify-center gap-3 sm:flex-row"><Button onClick={() => setLocation("/")} className="rounded-lg bg-blue-600 px-6 py-2.5 text-white shadow-md transition-all duration-200 hover:bg-blue-700 hover:shadow-lg"><Home className="mr-2 h-4 w-4" />{goHomeLabel}</Button></div>
        </CardContent>
      </Card>
    </div>
  );
}
