/* Design reminder: “নদীর পথ” — explain each data path plainly, with calm editorial spacing and no dark patterns. */
import { CheckCircle2, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react";
import { useEffect } from "react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { trackEvent } from "@/lib/analytics";

export default function PrivacyPolicy() {
  useEffect(() => {
    trackEvent("page_view", { page: "privacy_policy" });
    const previousTitle = document.title;
    const description = document.querySelector('meta[name="description"]');
    const previousDescription = description?.getAttribute("content") ?? null;
    document.title = "গোপনীয়তা ও analytics নীতি | সহজ জনসেবা";
    description?.setAttribute("content", "সাহজসেবা কীভাবে anonymous usage measurement, service-link clicks ও contact information দায়িত্বশীলভাবে পরিচালনা করে তার বাংলা নীতি।");
    return () => {
      document.title = previousTitle;
      if (description && previousDescription) description.setAttribute("content", previousDescription);
    };
  }, []);

  return (
    <div className="site-shell public-civic-page public-policy-page">
      <SahajHeader />
      <main>
        <section className="security-hero">
          <div className="route-motif route-motif-hero" aria-hidden="true"><span /><i /><b /></div>
          <div className="container security-hero-inner">
            <div className="security-title reveal-up">
              <div className="eyebrow"><span className="eyebrow-dot" />০৬ / গোপনীয়তা নীতি</div>
              <h1>তথ্যের পথ<br /><em>সীমিত ও স্বচ্ছ।</em></h1>
              <p>সাহজসেবা কোন তথ্য মাপে, কোন তথ্য নেয় না এবং ব্যবহারকারীর official service journey কীভাবে সম্মান করে—এই পেজে তা সহজ ভাষায় বলা হলো।</p>
              <Link href="/" className="back-link">← হোমে ফিরে যান</Link>
            </div>
            <aside className="security-status-card reveal-up" style={{ animationDelay: "100ms" }}>
              <div className="security-status-icon"><EyeOff size={25} /></div>
              <span className="section-number">ডেটা নীতি</span>
              <h2>কম তথ্য,<br /><em>বেশি আস্থা।</em></h2>
              <p>Analytics থাকলেও password, OTP, NID নম্বর, কার্ড তথ্য বা ব্যক্তিগত service outcome সংগ্রহ করা হয় না।</p>
              <div className="security-status-list">
                <span><CheckCircle2 size={15} />anonymous usage measurement</span>
                <span><CheckCircle2 size={15} />official link click count</span>
                <span><ShieldCheck size={15} />data minimization</span>
              </div>
            </aside>
          </div>
        </section>
        <section className="security-workspace section-paper">
          <div className="container security-layout">
            <aside className="policy-index" aria-label="গোপনীয়তা নীতির বিষয়সূচি">
              <span className="section-number">পথনির্দেশ</span>
              <h2>যা জানা<br /><em>প্রয়োজন।</em></h2>
              <nav>
                <a href="#measurement">মাপা তথ্য</a>
                <a href="#not-collected">যা নেওয়া হয় না</a>
                <a href="#contact">যোগাযোগের তথ্য</a>
                <a href="#choice">আপনার পছন্দ</a>
              </nav>
              <div className="policy-index-note"><LockKeyhole size={16} /><span>কোনো সরকারি কর্তৃপক্ষের হয়ে সেবা বা সিদ্ধান্তের নিশ্চয়তা দেওয়া হয় না।</span></div>
            </aside>
            <div className="policy-content">
              <section className="policy-section" id="measurement"><div className="policy-section-heading"><span>০১</span><h2>কোন তথ্য মাপা হতে পারে</h2></div><div className="policy-section-body"><p>সাইটের কার্যকারিতা বোঝার জন্য anonymous visitor count, page view, service-card click, official link click, phone-link click এবং সাধারণ device/browser তথ্য মাপা হতে পারে। এগুলো aggregated reporting-এর জন্য ব্যবহৃত হবে।</p><div className="policy-callout"><EyeOff size={18} /><p><strong>উদ্দেশ্য:</strong> কোন নাগরিক পথ বেশি প্রয়োজন হচ্ছে তা বোঝা—কোনো ব্যক্তিকে শনাক্ত করা নয়।</p></div></div></section>
              <section className="policy-section" id="not-collected"><div className="policy-section-heading"><span>০২</span><h2>যা সংগ্রহ করা উচিত নয়</h2></div><div className="policy-section-body"><ul className="policy-list"><li>password, OTP, PIN, CVV বা recovery code</li><li>পূর্ণ NID নম্বর/ছবি, bank account বা card details</li><li>স্বাস্থ্য, আইনগত বা সরকারি সেবা পাওয়ার ব্যক্তিগত ফলাফল</li><li>analytics-এর জন্য সরাসরি পরিচয় শনাক্তকারী তথ্য</li></ul></div></section>
              <section className="policy-section" id="contact"><div className="policy-section-heading"><span>০৩</span><h2>যোগাযোগের তথ্য ও form</h2></div><div className="policy-section-body"><p>যোগাযোগের জন্য দেওয়া নাম, মোবাইল, ইমেইল ও বার্তা কেবল উত্তর দেওয়ার উদ্দেশ্যে ব্যবহার করা উচিত। বর্তমান preview form বাস্তব backend ticket তৈরি করে না; ভবিষ্যতে সংরক্ষণ চালু হলে retention period, deletion request ও access control প্রকাশ করতে হবে।</p></div></section>
              <section className="policy-section" id="choice"><div className="policy-section-heading"><span>০৪</span><h2>আপনার পছন্দ ও অভিযোগ</h2></div><div className="policy-section-body"><p>Analytics বা privacy বিষয়ে প্রশ্ন থাকলে <Link href="/contact">যোগাযোগ পেজে</Link> জানান। Browser settings বা privacy controls-এর মাধ্যমে third-party measurement সীমিত করা যেতে পারে; এতে সাইটের official service links ব্যবহার বন্ধ হবে না।</p><p className="policy-muted">এই নীতি প্রকাশের আগে owner-এর বাস্তব analytics provider, retention setting এবং প্রযোজ্য স্থানীয় আইন/পরামর্শের সঙ্গে মিলিয়ে নিতে হবে।</p></div></section>
            </div>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
