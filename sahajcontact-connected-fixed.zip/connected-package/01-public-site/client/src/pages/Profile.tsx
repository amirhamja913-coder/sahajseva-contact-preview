import { ArrowLeft, LogOut, ShieldCheck, UserRound } from "lucide-react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { Spinner } from "@/components/ui/spinner";

export default function Profile() {
  const [, setLocation] = useLocation();
  const meQuery = trpc.auth.me.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const utils = trpc.useUtils();
  const logout = trpc.auth.logout.useMutation({
    onSuccess: async () => {
      utils.auth.me.setData(undefined, null);
      await utils.auth.me.invalidate();
      setLocation("/");
    },
  });

  return (
    <div className="site-shell">
      <SahajHeader />
      <main>
        <section className="account-v2-hero">
          <div className="container account-v2-hero-inner">
            <div>
              <Link href="/" className="back-link"><ArrowLeft size={15} aria-hidden="true" /> হোমে ফিরে যান</Link>
              <span className="eyebrow account-v2-eyebrow"><span className="eyebrow-dot" /> নিরাপদ অ্যাকাউন্ট</span>
              <h1>অ্যাকাউন্ট <em>তথ্য</em></h1>
              <p>এই পোর্টালটি সরকারি তথ্যের পথনির্দেশ দেয়। এখানে কোনো service order, payment বা sensitive personal information গ্রহণ করা হয় না।</p>
            </div>
            <div className="account-v2-hero-mark" aria-hidden="true"><UserRound size={54} /></div>
          </div>
        </section>

        {meQuery.isLoading ? (
          <div className="account-v2-loading" role="status"><Spinner /> <span>অ্যাকাউন্ট যাচাই হচ্ছে…</span></div>
        ) : !meQuery.data ? (
          <section className="account-v2-login-state">
            <div className="account-v2-empty-card">
              <div className="account-v2-icon"><ShieldCheck size={25} /></div>
              <h2>এই পেজে ব্যক্তিগত সেবা-অ্যাকাউন্ট চালু নেই</h2>
              <p>ফোন নম্বর, OTP, পাসওয়ার্ড, ঠিকানা বা transaction তথ্য এই public portal-এ দেবেন না। সরকারি সেবা নিতে সংশ্লিষ্ট সরকারি পোর্টাল ব্যবহার করুন।</p>
              <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "12px", marginTop: "1.25rem" }}>
                <Link href="/" className="button button-primary">সেবার তথ্য দেখুন</Link>
                <Link href="/contact" className="button button-quiet">সাধারণ যোগাযোগ</Link>
              </div>
            </div>
          </section>
        ) : (
          <section className="account-v2-content">
            <div className="container" style={{ maxWidth: "900px" }}>
              <div className="account-v2-card account-v2-profile-card">
                <div className="account-v2-card-heading">
                  <div><span className="section-number">অ্যাকাউন্ট নিরাপত্তা</span><h2>আপনি নিরাপদে সাইন ইন করেছেন</h2></div>
                  <div className="account-v2-icon"><ShieldCheck size={19} /></div>
                </div>
                <p style={{ color: "#374151", lineHeight: 1.7, marginBottom: "1.1rem" }}>এই public portal-এ profile edit, order history, payment status বা আবেদন-তথ্য রাখা হয় না। প্রয়োজনীয় নাগরিক সেবার জন্য প্রতিটি সেবার অফিসিয়াল লিংক অনুসরণ করুন।</p>
                <div className="account-v2-privacy"><ShieldCheck size={15} /> OTP, PIN, পাসওয়ার্ড, payment number বা transaction ID কখনো কারও সঙ্গে শেয়ার করবেন না।</div>
              </div>


              <button type="button" className="account-v2-logout" style={{ marginTop: "1rem" }} onClick={() => logout.mutate()} disabled={logout.isPending}>
                <LogOut size={17} /> {logout.isPending ? "লগআউট হচ্ছে…" : "লগআউট"}
              </button>
            </div>
          </section>
        )}
      </main>
      <SahajFooter />
    </div>
  );
}
