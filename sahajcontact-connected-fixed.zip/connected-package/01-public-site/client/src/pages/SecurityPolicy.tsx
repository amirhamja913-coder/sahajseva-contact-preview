// Design reminder: “নদীর পথ” — this policy page uses a calm editorial route: paper ground, navy ink, teal wayfinding, and saffron checkpoints. Security language must be clear, practical, and never promise absolute protection.
import { AlertTriangle, ArrowUpRight, CheckCircle2, ChevronRight, Clock3, FileKey2, Fingerprint, Globe2, LockKeyhole, ShieldCheck, Siren, WalletCards } from "lucide-react";
import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";

const policySections = [
  { id: "owner-control", label: "মালিকের নিয়ন্ত্রণ" },
  { id: "owner-evidence", label: "মালিকানা প্রমাণ" },
  { id: "access", label: "অ্যাক্সেস ও পাসওয়ার্ড" },
  { id: "hosting", label: "হোস্টিং ও ডোমেইন" },
  { id: "data", label: "তথ্য ও গোপনীয়তা" },
  { id: "payment", label: "পেমেন্ট নিরাপত্তা" },
  { id: "incident", label: "ঘটনা মোকাবিলা" },
];

const responseSteps = [
  "সন্দেহ হলে আগে পরিবর্তন, নতুন সংযোগ বা পেমেন্ট-সংক্রান্ত কাজ থামিয়ে দিন।",
  "পরিষ্কার ও নিরাপদ ডিভাইস থেকে মালিকের ইমেইল, হোস্টিং এবং ডোমেইন অ্যাকাউন্টের পাসওয়ার্ড বদলান; MFA চালু বা পুনরায় যাচাই করুন।",
  "অপরিচিত সেশন, অ্যাপ পাসওয়ার্ড, API key বা recovery method থাকলে revoke বা remove করুন।",
  "সময়, URL, স্ক্রিনশট এবং কী দেখা গেছে—এসব লিখে রাখুন; সন্দেহজনক লিংকে ক্লিক বা ফাইল চালাবেন না।",
  "হোস্টিং সহায়তা ও প্রয়োজন হলে আইনশৃঙ্খলা কর্তৃপক্ষকে জানান। নিরাপদ checkpoint থেকে সাইট পুনরুদ্ধার করার আগে কারণটি নথিভুক্ত করুন।",
  "ব্যক্তিগত তথ্য প্রকাশের আশঙ্কা থাকলে ব্যবহারকারীদের জন্য সংক্ষিপ্ত, সত্যনিষ্ঠ নোটিশ দিন এবং কীভাবে সহায়তা পাওয়া যাবে তা জানান।",
];

function PolicySection({
  id,
  number,
  title,
  children,
}: {
  id: string;
  number: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="policy-section" id={id}>
      <div className="policy-section-heading"><span>{number}</span><h2>{title}</h2></div>
      <div className="policy-section-body">{children}</div>
    </section>
  );
}

export default function SecurityPolicy() {
  return (
    <div className="site-shell public-civic-page public-policy-page">
      <SahajHeader />
      <main>
        <section className="security-hero">
          <div className="route-motif route-motif-hero" aria-hidden="true"><span /><i /><b /></div>
          <div className="container security-hero-inner">
            <div className="security-title reveal-up">
              <div className="eyebrow"><span className="eyebrow-dot" />05 / নিরাপত্তা নীতি</div>
              <h1>সাইটের নিয়ন্ত্রণ<br /><em>সুরক্ষিত থাকুক।</em></h1>
              <p>সাহজসেবা যেন মালিকের নিয়ন্ত্রণে থাকে, ব্যবহারকারীর তথ্য অযথা ঝুঁকিতে না পড়ে এবং কোনো সমস্যা হলে দ্রুত ব্যবস্থা নেওয়া যায়—এই নীতিতে সেই কাজের পথ লেখা আছে।</p>
              <Link href="/" className="back-link">← হোমে ফিরে যান</Link>
            </div>
            <aside className="security-status-card reveal-up" style={{ animationDelay: "100ms" }}>
              <div className="security-status-icon"><ShieldCheck size={25} /></div>
              <span className="section-number">বর্তমান প্রকাশনা</span>
              <h2>নিরাপদ পথে<br /><em>স্বচ্ছ ব্যবহার।</em></h2>
              <p>এটি একটি public-facing static preview। বর্তমানে কোনো বাস্তব পেমেন্ট checkout, password login বা NID/OTP সংগ্রহের ব্যবস্থা নেই।</p>
              <div className="security-status-list">
                <span><CheckCircle2 size={15} />সাইটে policy link আছে</span>
                <span><CheckCircle2 size={15} />ডেমো payment নিষ্ক্রিয়</span>
                <span><Clock3 size={15} />পর্যালোচনা: ১১ আগস্ট ২০২৬</span>
              </div>
            </aside>
          </div>
        </section>

        <section className="security-workspace section-paper">
          <div className="container security-layout">
            <aside className="policy-index" aria-label="নীতির বিষয়সূচি">
              <span className="section-number">পথনির্দেশ</span>
              <h2>যে বিষয়গুলো<br /><em>দেখে নেবেন।</em></h2>
              <nav>
                {policySections.map((section) => <a key={section.id} href={`#${section.id}`}><span>{section.label}</span><ChevronRight size={14} /></a>)}
              </nav>
              <div className="policy-index-note"><LockKeyhole size={16} /><span>মালিকের অ্যাকাউন্ট, ডোমেইন এবং recovery email কখনো কাউকে দেবেন না।</span></div>
            </aside>

            <div className="policy-content">
              <PolicySection id="owner-control" number="০১" title="মালিকের নিয়ন্ত্রণ ও দায়িত্ব">
                <p>সাহজসেবা-র প্রকাশনা, ডোমেইন, হোস্টিং project এবং ভবিষ্যৎ payment account-এর একমাত্র নিয়ন্ত্রক মালিক নিজে থাকবেন। কোনো freelancer, পরিচিত ব্যক্তি বা তৃতীয় পক্ষকে স্থায়ী owner access না দিয়ে প্রয়োজনমতো সীমিত সময়ের সহায়তা দিতে হবে।</p>
                <div className="policy-callout"><Fingerprint size={18} /><p><strong>মূল নিয়ম:</strong> কাজ করার অনুমতি আর মালিকানা এক জিনিস নয়। যিনি update করবেন, তাঁর access কাজ শেষ হলে সরিয়ে দিন।</p></div>
              </PolicySection>

              <PolicySection id="owner-evidence" number="০২" title="মালিকানা প্রমাণ ও যাচাই">
                <p>ওয়েবসাইটে কারও নাম বা contact লেখা থাকলেই আইনি মালিকানা প্রমাণ হয় না। বর্তমান hosted subdomain-এর ক্ষেত্রে project owner access, account email, MFA, publish history এবং checkpoint/version records সবচেয়ে গুরুত্বপূর্ণ control evidence। কোনো public copy বদলে গেলেও এই private records সংরক্ষিত থাকলে প্রকৃত নিয়ন্ত্রণ যাচাই সহজ হয়।</p>
                <div className="policy-callout"><FileKey2 size={18} /><p><strong>Owner evidence bundle:</strong> Project ও version IDs, owner account-এর verification, dated content/design drafts, publish receipts, change timeline এবং incident screenshots আলাদা encrypted archive-এ রাখুন। password, OTP বা recovery code archive-এ plaintext রাখবেন না।</p></div>
                <div className="policy-mini-grid">
                  <div><Fingerprint size={17} /><strong>অ্যাকাউন্ট নিয়ন্ত্রণ</strong><span>owner email, MFA ও active-session review-এর record রাখুন।</span></div>
                  <div><ArrowUpRight size={17} /><strong>প্রকাশের ইতিহাস</strong><span>checkpoint ID, publish date ও change note সংরক্ষণ করুন।</span></div>
                  <div><Globe2 size={17} /><strong>ভবিষ্যৎ domain</strong><span>registrar invoice, registrant record ও DNS export রাখুন।</span></div>
                </div>
                <p className="policy-muted">Original content বা logo-এর authorship আলাদাভাবে সংরক্ষণ এবং প্রযোজ্য হলে <a href="https://copyrightoffice.gov.bd/" target="_blank" rel="noreferrer">বাংলাদেশ কপিরাইট অফিস</a> ও <a href="https://dpdt.gov.bd/" target="_blank" rel="noreferrer">DPDT</a>-এর official route সম্পর্কে আইনজীবীর পরামর্শ নেওয়া যেতে পারে। এই পেজ কোনো আইনি certificate নয়।</p>
              </PolicySection>

              <PolicySection id="access" number="০৩" title="অ্যাক্সেস, পাসওয়ার্ড ও MFA">
                <div className="policy-checklist">
                  <div><FileKey2 size={18} /><p><strong>আলাদা পাসওয়ার্ড:</strong> মালিকের ইমেইল, হোস্টিং, domain registrar এবং payment provider-এর জন্য আলাদা দীর্ঘ password ব্যবহার করুন; password manager-এ রাখুন।</p></div>
                  <div><LockKeyhole size={18} /><p><strong>MFA চালু:</strong> যেখানে সম্ভব authenticator app বা passkey ব্যবহার করুন। SMS recovery থাকলে সেটি backup হিসেবে রাখুন, একমাত্র সুরক্ষা হিসেবে নয়।</p></div>
                  <div><ShieldCheck size={18} /><p><strong>সেশন পর্যালোচনা:</strong> shared computer বা পুরোনো ফোনে লগইন করা থাকলে sign out করুন, অচেনা device ও app access remove করুন।</p></div>
                </div>
                <p className="policy-muted">OTP, PIN, CVV, recovery code বা password কখনো WhatsApp, Messenger, ফোন বা ইমেইলে কাউকে পাঠাবেন না—even যদি সে support পরিচয় দেয়।</p>
              </PolicySection>

              <PolicySection id="hosting" number="০৪" title="হোস্টিং, ডোমেইন ও পরিবর্তন নিয়ন্ত্রণ">
                <p>প্রকাশিত সাইটের URL, DNS, registrar এবং hosting dashboard-এর owner email একইভাবে সুরক্ষিত রাখুন। DNS বা nameserver বদলানোর আগে মালিক নিজে URL, certificate এবং deployment status যাচাই করবেন।</p>
                <div className="policy-mini-grid">
                  <div><Globe2 size={17} /><strong>ডোমেইন lock</strong><span>transfer lock ও registrar MFA চালু রাখুন।</span></div>
                  <div><ArrowUpRight size={17} /><strong>পরিবর্তন লগ</strong><span>কে, কখন, কী পরিবর্তন করেছে লিখে রাখুন।</span></div>
                  <div><CheckCircle2 size={17} /><strong>প্রকাশের আগে পরীক্ষা</strong><span>route, HTTPS, mobile view ও link যাচাই করুন।</span></div>
                </div>
              </PolicySection>

              <PolicySection id="data" number="০৫" title="তথ্য, ফর্ম ও গোপনীয়তা">
                <p>সাহজসেবা প্রয়োজনের অতিরিক্ত ব্যক্তিগত তথ্য চাইবে না। ব্যবহারকারীকে password, OTP, PIN, NID-এর পূর্ণ ছবি, ব্যাংক কার্ডের তথ্য বা sensitive document public form-এ দিতে বলা যাবে না।</p>
                <ul className="policy-list">
                  <li>যোগাযোগের তথ্য কেবল উত্তর দেওয়ার প্রয়োজনে ব্যবহার করুন; public page বা service list-এ প্রকাশ করবেন না।</li>
                  <li>সাইটের যোগাযোগ form কোনো backend database-এ সংরক্ষণ করে না—তাই submit সফল দেখালেই বাস্তব ticket বা case তৈরি হয়েছে এমন দাবি করা যাবে না।</li>
                  <li>ভবিষ্যতে form data সংরক্ষণ শুরু হলে privacy notice, retention period, deletion process এবং access log আগে নির্ধারণ করতে হবে।</li>
                </ul>
              </PolicySection>

              <PolicySection id="payment" number="০৬" title="পেমেন্ট ও ভবিষ্যৎ gateway নিরাপত্তা">
                <div className="policy-callout policy-callout-saffron"><WalletCards size={18} /><p><strong>এখনকার অবস্থা:</strong> সাইটে মূল্য তালিকা, রসিদ বা payment collection চালু নেই। কোনো real payment নেওয়া, card data রাখা বা payment success দাবি করা হয় না।</p></div>
                <p>বাস্তব gateway চালুর আগে merchant account মালিকের নামে খুলতে হবে, official provider dashboard-এ MFA রাখতে হবে এবং payment provider-এর hosted checkout বা tokenized flow ব্যবহার করতে হবে। কার্ড নম্বর, CVV বা PIN নিজের database-এ রাখা যাবে না।</p>
                <p className="policy-muted">ব্যবহারকারীকে payment করার আগে URL, merchant name, amount এবং refund terms যাচাই করতে বলা হবে। Support কখনো OTP বা PIN চাইবে না।</p>
              </PolicySection>

              <PolicySection id="incident" number="০৭" title="হ্যাক বা সন্দেহজনক ঘটনার checklist">
                <div className="incident-heading"><Siren size={20} /><p>লক্ষ্য হলো আতঙ্ক না ছড়িয়ে access আটকে দেওয়া, প্রমাণ সংরক্ষণ করা এবং নিরাপদ অবস্থায় ফিরিয়ে আনা।</p></div>
                <ol className="incident-list">{responseSteps.map((step, index) => <li key={step}><span>{String(index + 1).padStart(2, "0")}</span><p>{step}</p></li>)}</ol>
                <div className="policy-warning"><AlertTriangle size={17} /><p>কেউ “সাইট বন্ধ হয়ে যাবে” বা “এখনই টাকা পাঠান” বলে চাপ দিলে আগে official dashboard বা পরিচিত যোগাযোগপথে যাচাই করুন। জরুরি অবস্থায় মালিকের ইমেইল: <a href="mailto:Amirhamja913@gmail.com">Amirhamja913@gmail.com</a></p></div>
              </PolicySection>

              <section className="policy-references">
                <span className="section-number">শেষ কথা</span>
                <h2>নিরাপত্তা মানে<br /><em>নিয়মিত যত্ন।</em></h2>
                <p>এই policy একটি বাস্তব কাজের checklist; এটি কোনো সিস্টেমকে ১০০% হ্যাক-প্রুফ করার দাবি নয়। নতুন feature, payment, form storage বা domain পরিবর্তনের আগে policy আপডেট করে আবার review করতে হবে। নীতির কাঠামোটি OWASP, NIST ও CISA-র প্রকাশিত নিরাপত্তা নির্দেশনার সঙ্গে সামঞ্জস্য রেখে সাজানো হয়েছে। <a href="https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html" target="_blank" rel="noreferrer">Authentication guidance ↗</a></p>
                <div className="policy-reference-links"><a href="https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html" target="_blank" rel="noreferrer">OWASP Logging Cheat Sheet <ArrowUpRight size={14} /></a><a href="https://pages.nist.gov/800-63-3/sp800-63b.html" target="_blank" rel="noreferrer">NIST Digital Identity Guidelines <ArrowUpRight size={14} /></a><a href="https://www.cisa.gov/cybersecurity-performance-goals" target="_blank" rel="noreferrer">CISA Cybersecurity Goals <ArrowUpRight size={14} /></a></div>
              </section>
            </div>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
