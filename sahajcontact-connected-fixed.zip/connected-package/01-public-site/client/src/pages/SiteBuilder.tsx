import { useEffect, useMemo, useState } from "react";
import { Eye, Globe2, ImagePlus, Languages, Loader2, Save, Send, Smartphone, X } from "lucide-react";
import { Link } from "wouter";
import AdminSecurityGate from "@/components/AdminSecurityGate";
import HomeSectionLayoutBuilder from "@/components/HomeSectionLayoutBuilder";
import { trpc } from "@/lib/trpc";
import { useLanguage, type SiteLanguage } from "@/contexts/LanguageContext";
import { DEFAULT_SITE_BUILDER_DOCUMENT, SITE_BUILDER_COUNTRY_CODES, type SiteBuilderDocument, type SiteBuilderCountryCode } from "@shared/siteBuilder";

const countryNames: Record<SiteBuilderCountryCode, { bn: string; en: string }> = {
  usa: { bn: "যুক্তরাষ্ট্র", en: "United States" },
  kuwait: { bn: "কুয়েত", en: "Kuwait" },
  ireland: { bn: "আয়ারল্যান্ড", en: "Ireland" },
  bangladesh: { bn: "বাংলাদেশ", en: "Bangladesh" },
};

const uiCopy = {
  BN: {
    title: "Site Builder", eyebrow: "Owner-only site design workspace", back: "Dashboard-এ ফিরুন", draft: "Draft", published: "Published", hero: "Homepage Hero", countries: "Country Section", whatsapp: "Global WhatsApp", bn: "বাংলা", en: "English", titleBn: "বাংলা Title", titleEn: "English Title", subtitleBn: "বাংলা Subtitle", subtitleEn: "English Subtitle", descriptionBn: "বাংলা Description", descriptionEn: "English Description", image: "ছবি", upload: "ছবি আপলোড", removeImage: "ছবি সরান", visible: "সাইটে দেখান", number: "WhatsApp নম্বর", save: "Save Draft", preview: "Preview", publish: "Publish Live", saving: "সংরক্ষণ হচ্ছে…", publishing: "Live publish হচ্ছে…", saved: "Draft বাস্তব database-এ সংরক্ষিত হয়েছে।", publishedMsg: "Published content public site-এ live হয়েছে।", previewNote: "Preview শুধু এই editor-এর ভেতরের unsaved state দেখায়।", realNote: "এখানে demo/mock data নেই—Save ও Publish প্রকৃত MySQL state-এ কাজ করে।", required: "বাংলা ও English—দুই ভাষার field পূরণ করুন।", imageHelp: "PNG/JPG/WebP, সর্বোচ্চ 5MB; managed storage-এ সংরক্ষিত হবে।", choose: "ফাইল বাছুন", close: "বন্ধ", previewTitle: "Live preview", previewEmpty: "Preview দেখতে Save Draft করার প্রয়োজন নেই।", language: "Dashboard ভাষা" },
  EN: {
    title: "Site Builder", eyebrow: "Owner-only site design workspace", back: "Back to Dashboard", draft: "Draft", published: "Published", hero: "Homepage Hero", countries: "Country Section", whatsapp: "Global WhatsApp", bn: "বাংলা", en: "English", titleBn: "Bangla Title", titleEn: "English Title", subtitleBn: "Bangla Subtitle", subtitleEn: "English Subtitle", descriptionBn: "Bangla Description", descriptionEn: "English Description", image: "Image", upload: "Upload image", removeImage: "Remove image", visible: "Show on site", number: "WhatsApp number", save: "Save Draft", preview: "Preview", publish: "Publish Live", saving: "Saving…", publishing: "Publishing…", saved: "Draft saved to the real database.", publishedMsg: "Published content is now live on the public site.", previewNote: "Preview shows the current editor state before publishing.", realNote: "This is not demo/mock data—Save and Publish use the real MySQL state.", required: "Complete both Bangla and English fields.", imageHelp: "PNG/JPG/WebP, maximum 5MB; stored in managed storage.", choose: "Choose file", close: "Close", previewTitle: "Live preview", previewEmpty: "You can preview without saving the draft.", language: "Dashboard language" },
} as const;

type MediaCategory = "news" | "drama" | "movie" | "government" | "national-newspapers";
const MEDIA_CATEGORIES: readonly MediaCategory[] = ["news", "drama", "movie", "government", "national-newspapers"];
const toMediaCategory = (value: string): MediaCategory => MEDIA_CATEGORIES.includes(value as MediaCategory) ? value as MediaCategory : "news";

type MediaHubChannelEditor = {
  id?: number;
  categorySlug: MediaCategory;
  categoryNameBn: string;
  categoryNameEn: string;
  channelNameBn: string;
  channelNameEn: string;
  officialUrl: string;
  logoUrl?: string | null;
  descriptionBn?: string | null;
  descriptionEn?: string | null;
  isPrime: boolean;
  visible: boolean;
  displayOrder: number;
};

const emptyMediaChannel = (): MediaHubChannelEditor => ({
  categorySlug: "national-newspapers",
  categoryNameBn: "জাতীয় পত্রিকা",
  categoryNameEn: "National Newspapers",
  channelNameBn: "",
  channelNameEn: "",
  officialUrl: "https://",
  isPrime: false,
  visible: true,
  displayOrder: 1,
});

type EducationCardEditor = {
  id?: number;
  slug: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  iconName: string;
  officialUrl: string;
  whatsappUrl: string | null;
  visible: boolean;
  displayOrder: number;
};

const emptyEducationCard = (): EducationCardEditor => ({
  slug: "new-education-card",
  titleBn: "",
  titleEn: "",
  descriptionBn: "",
  descriptionEn: "",
  iconName: "BookOpen",
  officialUrl: "",
  whatsappUrl: null,
  visible: true,
  displayOrder: 0,
});

type EditableTextProps = {
  labelBn: string;
  labelEn: string;
  valueBn: string;
  valueEn: string;
  onChangeBn: (value: string) => void;
  onChangeEn: (value: string) => void;
  multiline?: boolean;
};

function EditableText({ labelBn, labelEn, valueBn, valueEn, onChangeBn, onChangeEn, multiline = false }: EditableTextProps) {
  const Field = multiline ? "textarea" : "input";
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <label className="grid gap-2 text-sm font-semibold text-slate-200">
        <span>{labelBn}</span>
        <Field value={valueBn} onChange={(event) => onChangeBn(event.target.value)} className="min-h-11 w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-sm text-white outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" rows={multiline ? 4 : undefined} />
      </label>
      <label className="grid gap-2 text-sm font-semibold text-slate-200">
        <span>{labelEn}</span>
        <Field value={valueEn} onChange={(event) => onChangeEn(event.target.value)} className="min-h-11 w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-sm text-white outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" rows={multiline ? 4 : undefined} />
      </label>
    </div>
  );
}

function SiteBuilderEditor() {
  const { language, setLanguage } = useLanguage();
  const copy = uiCopy[language];
  const [document, setDocument] = useState<SiteBuilderDocument>(DEFAULT_SITE_BUILDER_DOCUMENT);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [uploadingCode, setUploadingCode] = useState<SiteBuilderCountryCode | null>(null);
  const builderQuery = trpc.siteManagement.management.getSiteBuilder.useQuery(undefined, { retry: false });
  const saveMutation = trpc.siteManagement.management.saveSiteBuilderDraft.useMutation({
    onSuccess: () => { setMessage(copy.saved); setError(""); void builderQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const publishMutation = trpc.siteManagement.management.publishSiteBuilder.useMutation({
    onSuccess: () => { setMessage(copy.publishedMsg); setError(""); void builderQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const uploadBase64Mutation = trpc.gallery.uploadBase64.useMutation();
  const educationCardsQuery = trpc.siteManagement.management.getEducationHubCards.useQuery(undefined, { retry: false });
  const [educationCards, setEducationCards] = useState<EducationCardEditor[]>([]);
  const createEducationMutation = trpc.siteManagement.management.createEducationHubCard.useMutation({
    onSuccess: () => { setMessage(language === "BN" ? "শিক্ষা কার্ড তৈরি হয়েছে।" : "Education card created."); setError(""); void educationCardsQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const updateEducationMutation = trpc.siteManagement.management.updateEducationHubCard.useMutation({
    onSuccess: () => { setMessage(language === "BN" ? "শিক্ষা কার্ড আপডেট হয়েছে।" : "Education card updated."); setError(""); void educationCardsQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const deleteEducationMutation = trpc.siteManagement.management.deleteEducationHubCard.useMutation({
    onSuccess: () => { setMessage(language === "BN" ? "শিক্ষা কার্ড মুছে দেওয়া হয়েছে।" : "Education card deleted."); setError(""); void educationCardsQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const mediaChannelsQuery = trpc.siteManagement.management.getMediaHubChannels.useQuery(undefined, { retry: false });
  const [mediaChannels, setMediaChannels] = useState<MediaHubChannelEditor[]>([]);
  const createMediaChannelMutation = trpc.siteManagement.management.createMediaHubChannel.useMutation({
    onSuccess: () => { setMessage(language === "BN" ? "মিডিয়া লিংক তৈরি হয়েছে।" : "Media link created."); setError(""); void mediaChannelsQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const updateMediaChannelMutation = trpc.siteManagement.management.updateMediaHubChannel.useMutation({
    onSuccess: () => { setMessage(language === "BN" ? "মিডিয়া লিংক আপডেট হয়েছে।" : "Media link updated."); setError(""); void mediaChannelsQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });
  const deleteMediaChannelMutation = trpc.siteManagement.management.deleteMediaHubChannel.useMutation({
    onSuccess: () => { setMessage(language === "BN" ? "মিডিয়া লিংক মুছে দেওয়া হয়েছে।" : "Media link deleted."); setError(""); void mediaChannelsQuery.refetch(); },
    onError: (err) => { setError(err.message); setMessage(""); },
  });

  useEffect(() => {
    if (builderQuery.data?.draft) setDocument(builderQuery.data.draft as SiteBuilderDocument);
  }, [builderQuery.data?.draft]);

  useEffect(() => {
    if (educationCardsQuery.data) {
      setEducationCards(educationCardsQuery.data.map((card) => ({ ...card, visible: Boolean(card.visible), whatsappUrl: card.whatsappUrl ?? null })));
    }
  }, [educationCardsQuery.data]);

  useEffect(() => {
    if (mediaChannelsQuery.data) {
      setMediaChannels(mediaChannelsQuery.data.map((channel) => ({ ...channel, categorySlug: toMediaCategory(channel.categorySlug), isPrime: Boolean(channel.isPrime), visible: Boolean(channel.visible) })));
    }
  }, [mediaChannelsQuery.data]);

  const publishedAt = builderQuery.data?.publishedAt ? new Date(builderQuery.data.publishedAt).toLocaleString() : null;
  const isBusy = saveMutation.isPending || publishMutation.isPending || createEducationMutation.isPending || updateEducationMutation.isPending || deleteEducationMutation.isPending || createMediaChannelMutation.isPending || updateMediaChannelMutation.isPending || deleteMediaChannelMutation.isPending || uploadingCode !== null;
  const previewLanguage = language === "BN" ? "bn" : "en";
  const previewCountries = useMemo(() => document.countries.filter((country) => country.visible), [document.countries]);

  const updateHero = (field: keyof SiteBuilderDocument["hero"], value: string) => {
    setDocument((current) => ({ ...current, hero: { ...current.hero, [field]: value } }));
  };
  const updateCountry = (code: SiteBuilderCountryCode, field: string, value: string | boolean | null) => {
    setDocument((current) => ({ ...current, countries: current.countries.map((country) => country.code === code ? { ...country, [field]: value } : country) }));
  };
  const saveDraft = () => {
    setError("");
    if (!document.hero.titleBn.trim() || !document.hero.titleEn.trim() || !document.hero.subtitleBn.trim() || !document.hero.subtitleEn.trim() || document.countries.some((country) => !country.titleBn.trim() || !country.titleEn.trim() || !country.descriptionBn.trim() || !country.descriptionEn.trim())) {
      setError(copy.required);
      return;
    }
    saveMutation.mutate(document);
  };
  const publish = () => {
    setError("");
    publishMutation.mutate();
  };
  const updateEducationCard = (index: number, field: keyof EducationCardEditor, value: string | boolean | number | null) => {
    setEducationCards((current) => current.map((card, cardIndex) => cardIndex === index ? { ...card, [field]: value } as EducationCardEditor : card));
  };
  const saveEducationCard = (card: EducationCardEditor) => {
    const { id, ...payload } = card;
    setError("");
    if (id) updateEducationMutation.mutate({ id, ...payload });
    else createEducationMutation.mutate(payload);
  };
  const removeEducationCard = (card: EducationCardEditor) => {
    if (!card.id) {
      setEducationCards((current) => current.filter((item) => item !== card));
      return;
    }
    if (window.confirm(language === "BN" ? "এই শিক্ষা কার্ডটি মুছে ফেলবেন?" : "Delete this education card?")) deleteEducationMutation.mutate({ id: card.id });
  };
  const updateMediaChannel = (index: number, field: keyof MediaHubChannelEditor, value: string | boolean | number | null) => {
    setMediaChannels((current) => current.map((channel, channelIndex) => channelIndex === index ? { ...channel, [field]: value } as MediaHubChannelEditor : channel));
  };
  const saveMediaChannel = (channel: MediaHubChannelEditor) => {
    const { id, ...rest } = channel;
    const payload = {
      ...rest,
      logoUrl: rest.logoUrl ?? null,
      descriptionBn: rest.descriptionBn ?? null,
      descriptionEn: rest.descriptionEn ?? null,
    };
    setError("");
    if (id) updateMediaChannelMutation.mutate({ id, ...payload });
    else createMediaChannelMutation.mutate(payload);
  };
  const removeMediaChannel = (channel: MediaHubChannelEditor) => {
    if (!channel.id) {
      setMediaChannels((current) => current.filter((item) => item !== channel));
      return;
    }
    if (window.confirm(language === "BN" ? "এই মিডিয়া লিংকটি মুছে ফেলবেন?" : "Delete this media link?")) deleteMediaChannelMutation.mutate({ id: channel.id });
  };

  const uploadCountryImage = async (code: SiteBuilderCountryCode, file: File) => {
    if (!file.type.startsWith("image/") || file.size > 5 * 1024 * 1024) { setError(copy.imageHelp); return; }
    setUploadingCode(code);
    setError("");
    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("Unable to read image"));
        reader.readAsDataURL(file);
      });
      const result = await uploadBase64Mutation.mutateAsync({ base64Data: base64, fileName: `site-builder-${code}-${Date.now()}-${file.name}`, contentType: file.type });
      updateCountry(code, "imageUrl", result.url);
      setMessage(language === "BN" ? "ছবি managed storage-এ upload হয়েছে। Draft Save করুন।" : "Image uploaded to managed storage. Save the draft.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Image upload failed");
    } finally {
      setUploadingCode(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-300">{copy.eyebrow}</p>
            <h1 className="mt-1 text-2xl font-black tracking-tight text-white">{copy.title}</h1>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2">
            <span className="hidden text-xs font-semibold text-slate-400 sm:inline">{copy.language}</span>
            <div className="flex rounded-full border border-slate-700 bg-slate-900 p-1" role="group" aria-label={copy.language}>
              <button type="button" onClick={() => setLanguage("BN")} className={`rounded-full px-3 py-1.5 text-xs font-bold ${language === "BN" ? "bg-emerald-500 text-slate-950" : "text-slate-300"}`}>🇧🇩 {copy.bn}</button>
              <button type="button" onClick={() => setLanguage("EN")} className={`rounded-full px-3 py-1.5 text-xs font-bold ${language === "EN" ? "bg-emerald-500 text-slate-950" : "text-slate-300"}`}>🇺🇸 {copy.en}</button>
            </div>
            <Link href="/admin/dashboard" className="rounded-xl border border-slate-700 px-3 py-2 text-sm font-semibold text-slate-200 transition hover:border-emerald-400 hover:text-white">{copy.back}</Link>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <section className="space-y-6">
          <div className="rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-sm leading-7 text-emerald-100"><strong>{copy.realNote}</strong><br />{copy.previewNote}</div>
          {builderQuery.isLoading && <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 text-slate-300"><Loader2 className="mr-2 inline h-4 w-4 animate-spin" />{copy.saving}</div>}
          {error && <div className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-200" role="alert">{error}</div>}
          {message && <div className="rounded-2xl border border-sky-500/40 bg-sky-500/10 p-4 text-sm text-sky-100" role="status">{message}</div>}

          <HomeSectionLayoutBuilder />

          <section className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl sm:p-6">
            <div className="mb-5 flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">01</p><h2 className="mt-1 text-xl font-black text-white">{copy.hero}</h2></div><Globe2 className="h-6 w-6 text-emerald-300" aria-hidden="true" /></div>
            <div className="space-y-5">
              <EditableText labelBn={copy.titleBn} labelEn={copy.titleEn} valueBn={document.hero.titleBn} valueEn={document.hero.titleEn} onChangeBn={(value) => updateHero("titleBn", value)} onChangeEn={(value) => updateHero("titleEn", value)} />
              <EditableText labelBn={copy.subtitleBn} labelEn={copy.subtitleEn} valueBn={document.hero.subtitleBn} valueEn={document.hero.subtitleEn} onChangeBn={(value) => updateHero("subtitleBn", value)} onChangeEn={(value) => updateHero("subtitleEn", value)} multiline />
            </div>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl sm:p-6">
            <div className="mb-5 flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">02</p><h2 className="mt-1 text-xl font-black text-white">{copy.countries}</h2></div><Globe2 className="h-6 w-6 text-emerald-300" aria-hidden="true" /></div>
            <div className="space-y-5">
              {SITE_BUILDER_COUNTRY_CODES.map((code) => {
                const country = document.countries.find((item) => item.code === code) ?? DEFAULT_SITE_BUILDER_DOCUMENT.countries.find((item) => item.code === code)!;
                return <article key={code} className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 sm:p-5">
                  <div className="mb-4 flex items-center justify-between gap-3"><h3 className="text-base font-black text-white">{countryNames[code].bn} / {countryNames[code].en}</h3><label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300"><input type="checkbox" checked={country.visible} onChange={(event) => updateCountry(code, "visible", event.target.checked)} className="h-4 w-4 accent-emerald-500" />{copy.visible}</label></div>
                  <div className="space-y-4">
                    <EditableText labelBn={copy.titleBn} labelEn={copy.titleEn} valueBn={country.titleBn} valueEn={country.titleEn} onChangeBn={(value) => updateCountry(code, "titleBn", value)} onChangeEn={(value) => updateCountry(code, "titleEn", value)} />
                    <EditableText labelBn={copy.descriptionBn} labelEn={copy.descriptionEn} valueBn={country.descriptionBn} valueEn={country.descriptionEn} onChangeBn={(value) => updateCountry(code, "descriptionBn", value)} onChangeEn={(value) => updateCountry(code, "descriptionEn", value)} multiline />
                    <div className="grid gap-3 sm:grid-cols-[120px_minmax(0,1fr)] sm:items-center">
                      <div className="flex h-24 w-full items-center justify-center overflow-hidden rounded-xl border border-dashed border-slate-700 bg-slate-900 sm:w-28">{country.imageUrl ? <img src={country.imageUrl} alt={previewLanguage === "bn" ? country.titleBn : country.titleEn} className="h-full w-full object-cover" /> : <ImagePlus className="h-6 w-6 text-slate-500" aria-hidden="true" />}</div>
                      <div className="space-y-2"><p className="text-sm font-semibold text-slate-200">{copy.image}</p><p className="text-xs leading-5 text-slate-400">{copy.imageHelp}</p><div className="flex flex-wrap gap-2"><label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-emerald-500 px-3 py-2 text-xs font-bold text-slate-950 transition hover:bg-emerald-400"><ImagePlus className="h-4 w-4" />{uploadingCode === code ? "Uploading…" : copy.upload}<input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" disabled={isBusy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void uploadCountryImage(code, file); event.currentTarget.value = ""; }} /></label>{country.imageUrl && <button type="button" onClick={() => updateCountry(code, "imageUrl", null)} className="rounded-xl border border-rose-500/40 px-3 py-2 text-xs font-bold text-rose-300 hover:bg-rose-500/10"><X className="mr-1 inline h-3.5 w-3.5" />{copy.removeImage}</button>}</div></div>
                    </div>
                  </div>
                </article>;
              })}
            </div>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl sm:p-6"><div className="mb-4 flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">03</p><h2 className="mt-1 text-xl font-black text-white">{copy.whatsapp}</h2></div><Smartphone className="h-6 w-6 text-emerald-300" aria-hidden="true" /></div><label className="grid gap-2 text-sm font-semibold text-slate-200"><span>{copy.number}</span><input inputMode="tel" value={document.whatsappNumber} onChange={(event) => setDocument((current) => ({ ...current, whatsappNumber: event.target.value }))} placeholder="+8801XXXXXXXXX" className="min-h-11 w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3 py-2 text-sm text-white outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20" /></label></section>

          <section className="rounded-2xl border border-emerald-500/30 bg-slate-900/80 p-5 shadow-xl sm:p-6">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
              <div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">04</p><h2 className="mt-1 text-xl font-black text-white">{language === "BN" ? "আপনার সন্তানকে শিক্ষিত করে তুলুন" : "Educate Your Child"}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">{language === "BN" ? "Homepage-এর একমাত্র শিক্ষা hub-এর ৫টি real database card এখান থেকে edit, add, hide বা delete করুন।" : "Edit, add, hide, or delete the five real database cards in the single Homepage education hub."}</p></div>
              <button type="button" disabled={isBusy} onClick={() => setEducationCards((current) => [...current, emptyEducationCard()])} className="rounded-xl border border-emerald-400/50 px-3 py-2 text-xs font-black text-emerald-200 transition hover:bg-emerald-500/10 disabled:opacity-50">+ {language === "BN" ? "কার্ড যোগ করুন" : "Add card"}</button>
            </div>
            {educationCardsQuery.isLoading ? <p className="text-sm text-slate-400">{language === "BN" ? "শিক্ষা কার্ড লোড হচ্ছে…" : "Loading education cards…"}</p> : null}
            <div className="space-y-5">
              {educationCards.map((card, index) => (
                <article key={card.id ?? `new-${index}`} className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 sm:p-5">
                  <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><h3 className="text-base font-black text-white">{language === "BN" ? `কার্ড ${index + 1}` : `Card ${index + 1}`}</h3><label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300"><input type="checkbox" checked={card.visible} onChange={(event) => updateEducationCard(index, "visible", event.target.checked)} className="h-4 w-4 accent-emerald-500" />{copy.visible}</label></div>
                  <div className="space-y-4">
                    <div className="grid gap-3 md:grid-cols-2">
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>Slug</span><input value={card.slug} onChange={(event) => updateEducationCard(index, "slug", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-emerald-400" /></label>
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "আইকন নাম" : "Icon name"}</span><input value={card.iconName} onChange={(event) => updateEducationCard(index, "iconName", event.target.value)} placeholder="BookOpen / School / Award" className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-emerald-400" /></label>
                    </div>
                    <EditableText labelBn={copy.titleBn} labelEn={copy.titleEn} valueBn={card.titleBn} valueEn={card.titleEn} onChangeBn={(value) => updateEducationCard(index, "titleBn", value)} onChangeEn={(value) => updateEducationCard(index, "titleEn", value)} />
                    <EditableText labelBn={copy.descriptionBn} labelEn={copy.descriptionEn} valueBn={card.descriptionBn} valueEn={card.descriptionEn} onChangeBn={(value) => updateEducationCard(index, "descriptionBn", value)} onChangeEn={(value) => updateEducationCard(index, "descriptionEn", value)} multiline />
                    <div className="grid gap-3 md:grid-cols-2">
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "অফিসিয়াল লিংক" : "Official link"}</span><input type="url" value={card.officialUrl} onChange={(event) => updateEducationCard(index, "officialUrl", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-emerald-400" /></label>
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>WhatsApp URL ({language === "BN" ? "ঐচ্ছিক" : "optional"})</span><input type="url" value={card.whatsappUrl ?? ""} onChange={(event) => updateEducationCard(index, "whatsappUrl", event.target.value || null)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-emerald-400" /></label>
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-3"><label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "ক্রম" : "Order"}</span><input type="number" min={0} value={card.displayOrder} onChange={(event) => updateEducationCard(index, "displayOrder", Number(event.target.value) || 0)} className="w-20 rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-sm text-white" /></label><div className="flex flex-wrap gap-2"><button type="button" disabled={isBusy} onClick={() => saveEducationCard(card)} className="rounded-xl bg-emerald-500 px-3 py-2 text-xs font-black text-slate-950 hover:bg-emerald-400 disabled:opacity-50">{language === "BN" ? "কার্ড Save" : "Save card"}</button><button type="button" disabled={isBusy} onClick={() => removeEducationCard(card)} className="rounded-xl border border-rose-500/50 px-3 py-2 text-xs font-black text-rose-200 hover:bg-rose-500/10 disabled:opacity-50">{language === "BN" ? "Delete" : "Delete"}</button></div></div>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="rounded-2xl border border-sky-500/30 bg-slate-900/80 p-5 shadow-xl sm:p-6">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
              <div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-300">05</p><h2 className="mt-1 text-xl font-black text-white">{language === "BN" ? "প্রবাসীদের মিডিয়া হাব" : "Expatriate Media Hub"}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-400">{language === "BN" ? "চারটি TV tab ও ৫ নম্বর জাতীয় পত্রিকা tab-এর official link, সিরিয়াল, visibility এবং Prime highlight এখান থেকে edit করুন।" : "Edit official links, order, visibility, and the Prime highlight for four TV tabs plus the fifth National Newspapers tab."}</p></div>
              <button type="button" disabled={isBusy} onClick={() => setMediaChannels((current) => [...current, emptyMediaChannel()])} className="rounded-xl border border-sky-400/50 px-3 py-2 text-xs font-black text-sky-200 transition hover:bg-sky-500/10 disabled:opacity-50">+ {language === "BN" ? "মিডিয়া লিংক যোগ করুন" : "Add media link"}</button>
            </div>
            {mediaChannelsQuery.isLoading ? <p className="text-sm text-slate-400">{language === "BN" ? "মিডিয়া লিংক লোড হচ্ছে…" : "Loading media links…"}</p> : null}
            <div className="space-y-5">
              {mediaChannels.map((channel, index) => (
                <article key={channel.id ?? `new-media-${index}`} className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 sm:p-5">
                  <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><h3 className="text-base font-black text-white">{language === "BN" ? `লিংক ${index + 1}` : `Link ${index + 1}`}</h3><div className="flex flex-wrap gap-4"><label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300"><input type="checkbox" checked={channel.visible} onChange={(event) => updateMediaChannel(index, "visible", event.target.checked)} className="h-4 w-4 accent-sky-500" />{copy.visible}</label><label className="inline-flex items-center gap-2 text-xs font-semibold text-amber-200"><input type="checkbox" checked={channel.isPrime} onChange={(event) => updateMediaChannel(index, "isPrime", event.target.checked)} className="h-4 w-4 accent-amber-500" />{language === "BN" ? "Prime Highlight" : "Prime highlight"}</label></div></div>
                  <div className="space-y-4">
                    <div className="grid gap-3 md:grid-cols-3">
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "Tab" : "Tab"}</span><select value={channel.categorySlug} onChange={(event) => updateMediaChannel(index, "categorySlug", event.target.value as MediaCategory)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400"><option value="news">{language === "BN" ? "সংবাদ" : "News"}</option><option value="drama">{language === "BN" ? "নাটক/সিরিয়াল" : "Drama / Serial"}</option><option value="movie">{language === "BN" ? "সিনেমা" : "Movies"}</option><option value="government">{language === "BN" ? "সরকারি" : "Government"}</option><option value="national-newspapers">{language === "BN" ? "জাতীয় পত্রিকা" : "National Newspapers"}</option></select></label>
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "বাংলা Tab নাম" : "Bangla tab label"}</span><input value={channel.categoryNameBn} onChange={(event) => updateMediaChannel(index, "categoryNameBn", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label>
                      <label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "English Tab নাম" : "English tab label"}</span><input value={channel.categoryNameEn} onChange={(event) => updateMediaChannel(index, "categoryNameEn", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label>
                    </div>
                    <div className="grid gap-3 md:grid-cols-2"><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "বাংলা নাম" : "Bangla name"}</span><input value={channel.channelNameBn} onChange={(event) => updateMediaChannel(index, "channelNameBn", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "English নাম" : "English name"}</span><input value={channel.channelNameEn} onChange={(event) => updateMediaChannel(index, "channelNameEn", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label></div>
                    <div className="grid gap-3 md:grid-cols-2"><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "বাংলা ছোট বর্ণনা" : "Bangla short description"}</span><input value={channel.descriptionBn ?? ""} onChange={(event) => updateMediaChannel(index, "descriptionBn", event.target.value || null)} placeholder="অফিসিয়াল সংবাদ ও সম্প্রচার মাধ্যম" className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "English ছোট বর্ণনা" : "English short description"}</span><input value={channel.descriptionEn ?? ""} onChange={(event) => updateMediaChannel(index, "descriptionEn", event.target.value || null)} placeholder="Official news and broadcasting portal" className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label></div>
                    <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_120px]"><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "Official Website URL" : "Official website URL"}</span><input type="url" value={channel.officialUrl} onChange={(event) => updateMediaChannel(index, "officialUrl", event.target.value)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "Official Logo URL (ঐচ্ছিক)" : "Official logo URL (optional)"}</span><input type="url" value={channel.logoUrl ?? ""} onChange={(event) => updateMediaChannel(index, "logoUrl", event.target.value || null)} placeholder="https://.../logo.png" className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label><label className="grid gap-2 text-xs font-semibold text-slate-300"><span>{language === "BN" ? "সিরিয়াল" : "Order"}</span><input type="number" min={0} value={channel.displayOrder} onChange={(event) => updateMediaChannel(index, "displayOrder", Number(event.target.value) || 0)} className="min-h-10 rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white outline-none focus:border-sky-400" /></label></div>
                    <div className="flex flex-wrap justify-end gap-2"><button type="button" disabled={isBusy} onClick={() => saveMediaChannel(channel)} className="rounded-xl bg-sky-500 px-3 py-2 text-xs font-black text-slate-950 hover:bg-sky-400 disabled:opacity-50">{language === "BN" ? "লিংক Save" : "Save link"}</button><button type="button" disabled={isBusy} onClick={() => removeMediaChannel(channel)} className="rounded-xl border border-rose-500/50 px-3 py-2 text-xs font-black text-rose-200 hover:bg-rose-500/10 disabled:opacity-50">{language === "BN" ? "Delete" : "Delete"}</button></div>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <div className="sticky bottom-3 z-20 flex flex-wrap gap-2 rounded-2xl border border-slate-700 bg-slate-950/95 p-3 shadow-2xl backdrop-blur"><button type="button" disabled={isBusy} onClick={saveDraft} className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-3 text-sm font-black text-slate-950 transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60"><Save className="h-4 w-4" />{saveMutation.isPending ? copy.saving : copy.save}</button><button type="button" disabled={isBusy} onClick={() => setPreviewOpen(true)} className="inline-flex items-center gap-2 rounded-xl border border-slate-600 px-4 py-3 text-sm font-black text-white transition hover:border-sky-400 hover:text-sky-200 disabled:opacity-60"><Eye className="h-4 w-4" />{copy.preview}</button><button type="button" disabled={isBusy} onClick={publish} className="inline-flex items-center gap-2 rounded-xl bg-sky-500 px-4 py-3 text-sm font-black text-slate-950 transition hover:bg-sky-400 disabled:cursor-not-allowed disabled:opacity-60"><Send className="h-4 w-4" />{publishMutation.isPending ? copy.publishing : copy.publish}</button>{publishedAt && <span className="self-center text-xs text-slate-400">{copy.published}: {publishedAt}</span>}</div>
        </section>

        <aside className="hidden lg:block"><div className="sticky top-24 rounded-2xl border border-slate-800 bg-slate-900/80 p-5"><div className="mb-4 flex items-center gap-2 text-sm font-bold text-white"><Languages className="h-4 w-4 text-emerald-300" />{copy.language}</div><p className="text-sm leading-7 text-slate-400">{language === "BN" ? "প্রতিটি editable field-এর বাংলা ও English মান আলাদা করে রাখুন। Public visitor /en route-এ English version দেখতে পারবেন।" : "Keep Bangla and English values separately. Public visitors can view the English version at /en."}</p><div className="mt-5 rounded-xl border border-slate-800 bg-slate-950/80 p-4 text-xs leading-6 text-slate-400"><strong className="text-slate-200">{copy.previewTitle}</strong><br />{copy.previewEmpty}</div></div></aside>
      </main>

      {previewOpen && <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/90 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={copy.previewTitle}><div className="mx-auto my-4 max-w-3xl rounded-3xl border border-slate-700 bg-slate-900 p-5 shadow-2xl sm:p-8"><div className="mb-6 flex items-center justify-between gap-4"><div><p className="text-xs uppercase tracking-[0.2em] text-emerald-300">{copy.previewTitle}</p><h2 className="mt-1 text-2xl font-black text-white">{previewLanguage === "bn" ? document.hero.titleBn : document.hero.titleEn}</h2></div><button type="button" onClick={() => setPreviewOpen(false)} className="rounded-xl border border-slate-700 p-2 text-slate-300 hover:text-white" aria-label={copy.close}><X className="h-5 w-5" /></button></div><p className="max-w-2xl text-base leading-7 text-slate-300">{previewLanguage === "bn" ? document.hero.subtitleBn : document.hero.subtitleEn}</p><div className="mt-7 grid gap-4 sm:grid-cols-2">{previewCountries.map((country) => <div key={country.code} className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-950"><div className="h-36 bg-gradient-to-br from-emerald-950 to-slate-900">{country.imageUrl && <img src={country.imageUrl} alt={previewLanguage === "bn" ? country.titleBn : country.titleEn} className="h-full w-full object-cover" />}</div><div className="p-4"><h3 className="font-black text-white">{previewLanguage === "bn" ? country.titleBn : country.titleEn}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{previewLanguage === "bn" ? country.descriptionBn : country.descriptionEn}</p></div></div>)}</div>{document.whatsappNumber && <p className="mt-6 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm text-emerald-100">WhatsApp: {document.whatsappNumber}</p>}<div className="mt-6 flex justify-end"><button type="button" onClick={() => setPreviewOpen(false)} className="rounded-xl bg-emerald-500 px-4 py-2 text-sm font-bold text-slate-950">{copy.close}</button></div></div></div>}
    </div>
  );
}

export default function SiteBuilder() {
  return <AdminSecurityGate><SiteBuilderEditor /></AdminSecurityGate>;
}
