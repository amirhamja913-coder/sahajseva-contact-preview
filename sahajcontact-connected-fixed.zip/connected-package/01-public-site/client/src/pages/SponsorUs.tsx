import { Link } from "wouter";
import { ArrowLeft, Building2, ClipboardCheck, HeartHandshake, ShieldCheck } from "lucide-react";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { useLanguage } from "@/contexts/LanguageContext";

const bn = {
  eyebrow: "প্রতিষ্ঠান ও সহযোগিতা",
  title: "দায়িত্বশীল সহযোগিতার জন্য প্রস্তাব দিন",
  lead: "সরকারি সংস্থা, এনজিও ও প্রতিষ্ঠানের জন্য SahajContact-এর একটি স্বচ্ছ, review-first যোগাযোগ পথ। প্রস্তাব জমা মানেই কোনো অংশীদারিত্ব, অনুমোদন বা প্রকাশ্য তালিকাভুক্তি নয়।",
  noticeTitle: "স্বচ্ছতা আগে",
  noticeBody: "এই পেজে কোনো মূল্য, প্যাকেজ, পেমেন্ট নির্দেশনা বা ব্যক্তিগত আর্থিক তথ্য নেওয়া হয় না। প্রয়োজন হলে যাচাইয়ের পর নির্ধারিত অফিসিয়াল যোগাযোগ মাধ্যমে পরবর্তী আলোচনা হবে।",
  stepsTitle: "কীভাবে কাজ করবে",
  steps: [
    ["১", "প্রস্তাব দিন", "প্রতিষ্ঠানের উদ্দেশ্য ও সম্ভাব্য জনসেবা-ভিত্তিক সহযোগিতার কথা লিখুন।"],
    ["২", "স্বতন্ত্র পর্যালোচনা", "প্রস্তাবটি নিরাপত্তা, প্রাসঙ্গিকতা ও জনস্বার্থের দিক থেকে যাচাই করা হবে।"],
    ["৩", "ফলাফল জানানো", "উপযুক্ত হলে অনুমোদিত যোগাযোগ পথে উত্তর দেওয়া হবে; কোনো নিশ্চয়তা স্বয়ংক্রিয়ভাবে তৈরি হয় না।"],
  ],
  cta: "সহযোগিতার প্রস্তাব দিন",
  ctaHint: "এই ফর্মে কোনো অর্থপ্রদান বা payment credential চাওয়া হয় না।",
  alternative: "অন্যান্য সাধারণ যোগাযোগের জন্য যোগাযোগ পেজ ব্যবহার করুন।",
  back: "হোমে ফিরুন",
};

const en = {
  eyebrow: "Institutional collaboration",
  title: "Propose a responsible collaboration",
  lead: "A transparent, review-first contact path for public bodies, NGOs, and institutions. Sending a proposal does not create a partnership, approval, or public listing.",
  noticeTitle: "Transparency first",
  noticeBody: "This page does not publish prices or packages, and it does not collect payment instructions or private financial information. Any later discussion follows verification through an approved official channel.",
  stepsTitle: "How it works",
  steps: [
    ["1", "Share a proposal", "Describe your organisation’s public-interest goal and possible civic-service collaboration."],
    ["2", "Independent review", "The proposal is assessed for safety, relevance, and public-interest alignment."],
    ["3", "Receive an outcome", "Where appropriate, a response follows through an approved channel; no automatic commitment is created."],
  ],
  cta: "Submit a collaboration proposal",
  ctaHint: "This form does not request payment credentials or financial details.",
  alternative: "For general enquiries, please use the contact page.",
  back: "Return home",
};

export default function SponsorUs() {
  const { isEnglish } = useLanguage();
  const copy = isEnglish ? en : bn;

  return (
    <div className="min-h-screen bg-[#f8f3e8] text-[#102b3e]">
      <SahajHeader />
      <main className="overflow-hidden">
        <section className="relative border-b border-[#173c4f]/10 bg-[#f1eadb] py-16 sm:py-20">
          <div className="container relative z-10 max-w-5xl">
            <Link href="/" className="mb-8 inline-flex items-center gap-2 text-sm font-semibold text-[#176b67] hover:underline">
              <ArrowLeft className="h-4 w-4" /> {copy.back}
            </Link>
            <div className="grid items-end gap-8 lg:grid-cols-[1fr_auto]">
              <div className="max-w-3xl">
                <p className="mb-4 flex items-center gap-2 text-sm font-extrabold tracking-[0.14em] text-[#176b67]">
                  <span className="h-2 w-2 rounded-full bg-[#d9901e]" /> {copy.eyebrow}
                </p>
                <h1 className="font-bangla-serif text-4xl font-black leading-tight text-[#102b3e] sm:text-5xl">{copy.title}</h1>
                <p className="mt-5 max-w-2xl text-lg leading-8 text-[#405461]">{copy.lead}</p>
              </div>
              <div className="hidden h-28 w-28 items-center justify-center rounded-[2rem] border border-[#176b67]/20 bg-[#e4f2e9] text-[#176b67] lg:flex">
                <HeartHandshake className="h-12 w-12" aria-hidden="true" />
              </div>
            </div>
          </div>
          <div className="pointer-events-none absolute bottom-0 left-0 h-2 w-full bg-[linear-gradient(90deg,#176b67_0%,#176b67_40%,#d9901e_40%,#d9901e_48%,#176b67_48%,#176b67_100%)]" />
        </section>

        <section className="container grid gap-7 py-12 lg:grid-cols-[0.9fr_1.4fr] lg:py-16">
          <aside className="rounded-[1.8rem] border border-[#176b67]/15 bg-[#e7f3ee] p-7 shadow-[0_18px_45px_rgba(16,43,62,0.08)]">
            <ShieldCheck className="mb-5 h-9 w-9 text-[#176b67]" aria-hidden="true" />
            <h2 className="font-bangla-serif text-2xl font-black text-[#102b3e]">{copy.noticeTitle}</h2>
            <p className="mt-4 leading-7 text-[#405461]">{copy.noticeBody}</p>
          </aside>
          <div className="rounded-[1.8rem] border border-[#173c4f]/10 bg-white p-7 shadow-[0_18px_45px_rgba(16,43,62,0.06)] sm:p-9">
            <h2 className="font-bangla-serif text-2xl font-black text-[#102b3e]">{copy.stepsTitle}</h2>
            <ol className="mt-7 grid gap-6 sm:grid-cols-3">
              {copy.steps.map(([number, title, body]) => (
                <li key={number} className="relative border-l-2 border-[#d9901e]/70 pl-4">
                  <span className="text-sm font-black text-[#d9901e]">{number}</span>
                  <h3 className="mt-1 font-bold text-[#102b3e]">{title}</h3>
                  <p className="mt-2 text-sm leading-6 text-[#536873]">{body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="container pb-16 lg:pb-20">
          <div className="rounded-[2rem] bg-[#102b3e] px-7 py-9 text-white shadow-[0_24px_65px_rgba(16,43,62,0.2)] sm:px-10 sm:py-11">
            <div className="flex flex-col gap-7 sm:flex-row sm:items-center sm:justify-between">
              <div className="max-w-2xl">
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#176b67]">
                  <Building2 className="h-6 w-6" aria-hidden="true" />
                </div>
                <h2 className="font-bangla-serif text-2xl font-black sm:text-3xl">{copy.cta}</h2>
                <p className="mt-3 leading-7 text-[#d9e5e5]">{copy.ctaHint}</p>
              </div>
              <Link href="/ngo-partnership" className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-[#63deb7] px-6 py-4 font-bold text-[#102b3e] transition hover:bg-[#83e9c9] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white">
                <ClipboardCheck className="h-5 w-5" aria-hidden="true" /> {copy.cta}
              </Link>
            </div>
            <p className="mt-7 border-t border-white/15 pt-5 text-sm text-[#b9cbd0]">{copy.alternative} <Link href="/contact" className="font-bold text-[#83e9c9] hover:underline">{isEnglish ? "Contact" : "যোগাযোগ"}</Link></p>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
