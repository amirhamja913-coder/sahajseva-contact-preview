import { Link } from "wouter";
import SahajFooter from "@/components/SahajFooter";
import SahajHeader from "@/components/SahajHeader";
import { trackOutbound } from "@/lib/analytics";
import { PARTNER_DISCLOSURE } from "@/lib/partnerDisclosure";
import { Printer, ScanLine, Smartphone, Wifi, ArrowUpRight, ExternalLink, ShieldCheck } from "lucide-react";

type MerchantLink = {
  name: string;
  url: string;
  badge: string;
};

type ToolItem = {
  name: string;
  description: string;
  icon: typeof Printer;
  iconLabel: string;
  tone: string;
  merchants: MerchantLink[];
};

export const toolItems: ToolItem[] = [
  {
    name: "লেজার প্রিন্টার",
    description: "অফিসিয়াল ফর্ম ও সার্টিফিকেট প্রিন্ট করার জন্য নির্ভরযোগ্য লেজার প্রিন্টার।",
    icon: Printer,
    iconLabel: "Laser printer",
    tone: "teal",
    merchants: [
      { name: "Daraz", url: "https://www.daraz.com.bd/tag/laser-printer/", badge: "Daraz লিংক" },
      { name: "Star Tech", url: "https://www.startech.com.bd/laser-printer", badge: "অফিসিয়াল দাম" },
    ],
  },
  {
    name: "ডকুমেন্ট স্ক্যানার",
    description: "NID, সার্টিফিকেট ও প্রয়োজনীয় কাগজপত্র দ্রুত স্ক্যান ও আপলোড করার জন্য স্ক্যানার।",
    icon: ScanLine,
    iconLabel: "Document scanner",
    tone: "saffron",
    merchants: [
      { name: "Daraz", url: "https://www.daraz.com.bd/tag/scanner-for-documents/", badge: "Daraz লিংক" },
      { name: "Ryans", url: "https://www.ryans.com/category/all-flatbed-scanner", badge: "স্টক ও দাম" },
    ],
  },
  {
    name: "অনলাইন ফর্মের মোবাইল",
    description: "স্মার্টফোন ও ট্যাব দিয়ে যেকোনো অনলাইন আবেদন ও পেমেন্ট করার জন্য ভালো ডিভাইস।",
    icon: Smartphone,
    iconLabel: "Smartphone",
    tone: "navy",
    merchants: [
      { name: "Daraz", url: "https://www.daraz.com.bd/smartphones/", badge: "Daraz লিংক" },
      { name: "Pickaboo", url: "https://www.pickaboo.com/category/smartphone", badge: "অফার ও মূল্য" },
    ],
  },
  {
    name: "ইন্টারনেট প্যাক",
    description: "নিরবচ্ছিন্ন অনলাইন ফর্ম ফিলাপ ও সেবা পাওয়ার জন্য দ্রুতগতির ইন্টারনেট প্যাক।",
    icon: Wifi,
    iconLabel: "Internet package",
    tone: "violet",
    merchants: [
      { name: "Grameenphone", url: "https://www.grameenphone.com/personal/plans-offers/internet-packages", badge: "GP প্যাক" },
      { name: "Robi", url: "https://www.robi.com.bd/en/personal/internet-offers", badge: "Robi অফার" },
    ],
  },
];

export const OUTBOUND_LINK_FALLBACK_PATH = "/help";
export { PARTNER_DISCLOSURE } from "@/lib/partnerDisclosure";

export default function Tools() {
  return (
    <div className="site-shell tools-page">
      <SahajHeader />
      <main>
        <section className="tools-hero" aria-labelledby="tools-page-title">
          <div className="container">
            <Link href="/" className="tools-back-link">
              <ArrowUpRight size={15} aria-hidden="true" /> হোমপেজে ফিরে যান
            </Link>
            <p className="eyebrow"><span className="eyebrow-dot" /> সেবার প্রস্তুতি ও সহায়ক সামগ্রী</p>
            <h1 id="tools-page-title">সেবার <em>টুলস ও পার্টনার্স</em></h1>
            <p className="tools-intro">
              নাগরিক আবেদন, NID ও ফর্ম ফিলাপ সহজ করতে নির্ভরযোগ্য দেশীয় অনলাইন প্রতিষ্ঠান ও অফিসিয়াল সেবার লিংক এখানে দেওয়া হলো। গ্রাহক সুবিধা ও মূল্যের তুলনার জন্য আপনারা সরাসরি যাচাই করতে পারেন।
            </p>
          </div>
        </section>

        <section className="tools-grid-section" aria-labelledby="tools-list-title">
          <div className="container">
            <div className="tools-section-heading">
              <div>
                <span className="section-number">০১ / বিশ্বস্ত বিক্রেতা ও পার্টনার</span>
                <h2 id="tools-list-title">আপনার সেবার পথের <em>সহায়ক ডিভাইস ও প্যাক</em></h2>
                <p className="mt-2 max-w-xl text-xs leading-relaxed text-slate-600">
                  {PARTNER_DISCLOSURE}
                </p>
              </div>
              <p className="flex items-center gap-1.5 text-sm text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 w-fit">
                <ShieldCheck size={16} /> সৎ ও যাচাইকৃত মার্চেন্ট প্ল্যাটফর্মের অফিসিয়াল লিংক
              </p>
            </div>

            <div className="tools-grid">
              {toolItems.map((item) => {
                const Icon = item.icon;
                return (
                  <article className={`tool-card tool-card-${item.tone}`} key={item.name}>
                    <div className="tool-card-visual" aria-label={item.iconLabel} role="img">
                      <Icon size={56} strokeWidth={1.25} aria-hidden="true" />
                      <span className="tool-card-spark" aria-hidden="true" />
                    </div>
                    <h3>{item.name}</h3>
                    <p className="text-xs text-slate-600 mb-3 min-h-[32px]">{item.description}</p>
                    
                    <div className="flex flex-col gap-2 mt-auto w-full">
                      {item.merchants.map((merchant) => (
                        <a
                          key={merchant.name}
                          href={merchant.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-between bg-white/90 hover:bg-white text-slate-800 text-xs font-medium px-3 py-2 rounded-md shadow-xs border border-slate-200 transition-colors"
                          onClick={() => trackOutbound(`merchant_${item.name}_${merchant.name}`, merchant.url, "tools_merchant")}
                        >
                          <span className="flex items-center gap-1.5">
                            <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-semibold">{merchant.badge}</span>
                            <strong>{merchant.name}</strong>
                          </span>
                          <ExternalLink size={14} className="text-emerald-600" aria-hidden="true" />
                        </a>
                      ))}
                    </div>
                  </article>
                );
              })}
            </div>

            <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 leading-relaxed">
              <strong>স্বচ্ছতা ও অংশীদারিত্ব নোট:</strong> সহজসেবা কোনো সরাসরি পণ্য বিক্রেতা বা ই-কমার্স প্রতিষ্ঠান নয়। উপরে তালিকাভুক্ত প্রতিষ্ঠানগুলো বাংলাদেশের স্বনামধন্য স্বাধীন প্রতিষ্ঠান। গ্রাহকদের সুবিধার জন্য তাদের অফিসিয়াল পেজের ডাইরেক্ট লিংক প্রদান করা হয়েছে। কোনো প্রকার লুকানো স্পন্সরশিপ বা জোরপূর্বক বিজ্ঞাপন এখানে নেই। কোনো বাইরের লিংক সাময়িকভাবে না খুললে <a href={OUTBOUND_LINK_FALLBACK_PATH} className="underline font-semibold">সাহায্য পেজে</a> যোগাযোগ করুন।
            </div>
          </div>
        </section>
      </main>
      <SahajFooter />
    </div>
  );
}
