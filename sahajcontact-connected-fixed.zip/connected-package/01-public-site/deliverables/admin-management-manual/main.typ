// SahajContact Bengali Admin CMS operating manual.
#import "report-theme.typ": report-accent, report-theme
#import "@preview/glossarium:0.5.10": make-glossary, register-glossary, print-glossary, gls

#show: report-theme.with(
  title: "SahajContact অ্যাডমিন ম্যানেজমেন্ট ম্যানুয়াল",
  author: "Kazi Amir Hamja",
  rhythm: "report",
  running-header: true,
)
#show: make-glossary
#set text(font: ("Noto Sans Bengali", "DejaVu Sans"), lang: "bn", region: "bd")
#show heading: set text(font: ("Noto Sans Bengali", "DejaVu Sans"), fill: report-accent)

#let terms = (
  (key: "cms", short: [CMS], long: [কনটেন্ট ম্যানেজমেন্ট সিস্টেম], description: [Admin Dashboard থেকে সাইটের লেখা, ছবি, মেনু এবং অন্যান্য কনটেন্ট পরিচালনার ব্যবস্থা।]),
  (key: "seo", short: [SEO], long: [সার্চ ইঞ্জিন অপটিমাইজেশন], description: [প্রতিটি পৃষ্ঠার Meta Title, Description, Keywords ও OG Image নিয়ন্ত্রণের ব্যবস্থা।]),
  (key: "lead", short: [Lead], long: [যোগাযোগ বা সেবা-অনুরোধ], description: [ভিজিটরের ফর্ম থেকে আসা নাম, ফোন, বার্তা ও প্রয়োজনীয় যোগাযোগ তথ্য।]),
  (key: "s3", short: [S3], long: [নিরাপদ ফাইল স্টোরেজ], description: [ছবি, PDF এবং আপলোড করা ফাইলের নিরাপদ সংরক্ষণস্থান।]),
  (key: "og", short: [OG Image], long: [সোশ্যাল শেয়ার ইমেজ], description: [Facebook বা অন্য সামাজিক মাধ্যমে লিংক শেয়ার করলে প্রদর্শিত প্রধান ছবি।]),
  (key: "ga4", short: [GA4], long: [Google Analytics 4], description: [ভিজিটর, page view ও engagement পরিমাপের Google Analytics সেবা।]),
  (key: "order", short: [Order], long: [সেবা অর্ডার], description: [মূল্য, সরকারি ফি, মোট এবং রেফারেন্স নম্বরসহ সেবা গ্রহণের রেকর্ড।]),
  (key: "sandbox", short: [Sandbox], long: [প্রোভাইডার টেস্ট পরিবেশ], description: [bKash বা Nagad-এর নিজস্ব credential ও callback-সহ provider-controlled পরীক্ষার পরিবেশ।]),
  (key: "testmode", short: [TEST MODE], long: [নো-ফান্ডস পেমেন্ট সিমুলেশন], description: [SahajContact-এর স্পষ্টভাবে চিহ্নিত অভ্যন্তরীণ পরীক্ষা-প্রবাহ; এতে কোনো বাস্তব টাকা কাটা, provider approval, SMS বা email পাঠানো হয় না।]),
  (key: "premium", short: [Premium Photo Gallery], long: [প্রিমিয়াম ফটো গ্যালারি], description: [Watermark-যুক্ত preview, মূল্য, TEST MODE checkout এবং অনুমোদিত delivery link-সহ মালিক-পরিচালিত ছবি বিক্রির অংশ।]),
  (key: "appearance", short: [Appearance Control], long: [সাইটের ভিজ্যুয়াল নিয়ন্ত্রণ], description: [Admin Dashboard থেকে পাবলিক সাইটের মূল রঙ, পেজের রঙ/ছবি, লেখার রঙ, ফন্ট সাইজ ও section spacing পরিবর্তনের নিরাপদ নিয়ন্ত্রণ।]),
)
#register-glossary(terms)

// ---------- Title page ----------
#page(margin: (top: 30%, x: 2.2cm), numbering: none, header: none)[
  #set par(first-line-indent: 0em)
  #align(center)[
    #text(size: 25pt, weight: "bold", fill: report-accent)[SahajContact]
    #v(0.35em)
    #text(size: 19pt, weight: "bold")[অ্যাডমিন ম্যানেজমেন্ট ম্যানুয়াল]
    #v(0.7em)
    #text(size: 13pt, fill: luma(85))[সাইট পরিচালনা, কনটেন্ট প্রকাশ ও সমস্যা সমাধানের ব্যবহারিক নির্দেশিকা]
    #v(2em)
    #line(length: 42%, stroke: 0.6pt + luma(160))
    #v(1.8em)
    #text(size: 11pt)[প্রস্তুতকারী: Kazi Amir Hamja]
    #v(0.45em)
    #text(size: 10pt, fill: luma(100))[সংস্করণ: ১.১  |  #datetime.today().display("[day]-[month]-[year]")]
  ]
]

// ---------- Table of contents ----------
#page(numbering: none, header: none)[
  #set text(font: ("Noto Sans Bengali", "DejaVu Sans"))
  #outline(title: [সূচিপত্র], indent: 1.5em)
]

#counter(page).update(1)

= এই ম্যানুয়াল কীভাবে ব্যবহার করবেন

এই ম্যানুয়ালটি SahajContact-এর মালিক বা অনুমোদিত Admin-এর জন্য। এখানে বলা প্রতিটি কাজ Admin Dashboard থেকে করা যায়। কোনো পরিবর্তন করার আগে বর্তমান লেখা বা ছবির একটি কপি নিজের কাছে রাখুন; তারপর পরিবর্তনটি Save করে Public Site-এ দেখে নিন। প্রকাশিত সাইট হলো #link("https://sahajcontact-8xyxsefc.manus.space/")[sahajcontact-8xyxsefc.manus.space]।

> গুরুত্বপূর্ণ: Admin password, OTP, merchant API key, Gmail app password বা অন্য কোনো secret কাউকে পাঠাবেন না। এগুলো শুধু নিরাপদ secret-settings ব্যবস্থার মাধ্যমে সংরক্ষণ করতে হবে।

== দ্রুত শুরু: পাঁচ মিনিটের কাজ

#table(
  columns: (2.2fr, 3.3fr, 3fr),
  inset: 6pt,
  table.header([*কাজ*], [*কোথায় যাবেন*], [*শেষ ধাপ*]),
  [সাইটে ঢোকা], [#raw("/admin/dashboard")], [Password দিয়ে খুলুন],
  [হোমপেজের লেখা বদল], [পাবলিক কনটেন্ট ম্যানেজমেন্ট], [Save Changes],
  [খবর প্রকাশ], [জনসভা / News / Notice], [Published নির্বাচন করে Save],
  [ছবি বদল], [Media Manager], [Upload বা Replace],
  [সাইটের রঙ/ব্যাকগ্রাউন্ড বদল], [সাইটের ভিজ্যুয়াল কন্ট্রোল], [Save appearance],
  [মেনু সাজানো], [Menu & Header Manager], [Drag & Drop, তারপর Save],
  [সেবার মূল্য বদল], [মূল্য সেটিংস], [Save Changes],
)

একবার Admin password সফলভাবে যাচাই হলে বর্তমান browser session খোলা থাকে। কাজ শেষ হলে অবশ্যই “লগ আউট” ব্যবহার করুন, বিশেষ করে অন্যের ফোন বা কম্পিউটারে।

= নিরাপদে Admin Dashboard ব্যবহার

== লগইন ও লগআউট

১. Browser-এ `/admin/dashboard` খুলুন।

২. গোপন Admin password লিখে “পাসওয়ার্ড দিয়ে খুলুন” চাপুন। Face ID বা Fingerprint থাকলে সেটি ঐচ্ছিক দ্রুত-খোলার সুবিধা; password-ভিত্তিক সেশন চালুর জন্য এটি বাধ্যতামূলক নয়।

৩. Dashboard খুললে ব্রাউজারটি ব্যক্তিগত রাখুন। কাজ শেষে উপরের লগ আউট ব্যবহার করুন।

== নিরাপত্তার নিয়ম

কখনও password, cookie, API key, OTP বা merchant credential-এর screenshot অন্যকে দেবেন না। শক্তিশালী password ব্যবহার করুন এবং সন্দেহ হলে password বদলান। Media Manager-এ আপলোড করা PDF বা ছবিতে অপ্রয়োজনীয় ব্যক্তিগত তথ্য আছে কি না আগে পরীক্ষা করুন। সন্দেহজনক Lead বা spam submission থাকলে Leads Management থেকে confirmation দিয়ে delete করা যায়।

= হোমপেজ ও পাবলিক কনটেন্ট

== Homepage Builder

#gls("cms")-এর “Homepage Builder” থেকে Hero Title, Subtitle, Button Text, Background Image এবং Video নিয়ন্ত্রণ করুন। বাংলা ও English—দুই ভাষার ঘরেই সম্পূর্ণ লেখা দিন। একটি ভাষা ফাঁকা রাখলে visitor-এর ভাষা বদলানোর সময় অসম্পূর্ণ বা পুরোনো লেখা দেখা দিতে পারে।

Hero বদলানোর নিরাপদ ক্রম হলো: প্রথমে Title BN/EN, তারপর Description BN/EN, তারপর Button Text ও Link; সবশেষে ছবি বা video upload করে Save Changes দিন। প্রকাশের পরে homepage reload করে BN ও English toggle দুটিতেই দেখুন।

== Announcement Bar, Quick Links ও Footer

“Menu & Header Manager” থেকে সবুজ Announcement Bar ON/OFF, message, button text এবং bar color পরিবর্তন করুন। জরুরি বিজ্ঞপ্তি শেষ হলে bar OFF করে দিন অথবা সঠিক নতুন লেখা বসান। একই প্যানেলে Language Toggle-এর visibility এবং default language নিয়ন্ত্রণ করা যায়।

Footer-এর Contact, Social Link এবং Admin identity সাইট settings থেকে দেখা ও আপডেট করা যায়। Phone number সবসময় দেশের কোড বা একরূপ format-এ দিন এবং email ঠিকানাটি পরীক্ষা করুন।

== সাইটের ভিজ্যুয়াল কন্ট্রোল

#gls("appearance") প্যানেল থেকে Public Site-এর প্রধান রঙ, button/highlight রঙ, পেজ background রঙ, মূল লেখার রঙ, font size এবং section-এর ফাঁকা জায়গা বদলানো যায়। চাইলে একটি background image upload করেও সেটি ব্যবহার করা যায়। ছবি upload হওয়ার পরও প্রকাশ করতে অবশ্যই “ভিজ্যুয়াল সেটিংস সেভ” চাপতে হবে। Save সফল হলে পরিবর্তনটি Public Site-এ তৎক্ষণাৎ দেখা যাবে।

#table(
  columns: (2.2fr, 3.6fr, 2.7fr),
  inset: 6pt,
  table.header([*নিয়ন্ত্রণ*], [*কী বদলাবে*], [*নিরাপদ ব্যবহার*]),
  [মূল থিম রঙ], [হেডিং, নির্বাচিত UI এবং civic-brand accent], [গাঢ় রঙ বেছে নিন যাতে সাদা লেখার সঙ্গে পড়া যায়],
  [হাইলাইট ও বাটনের রঙ], [প্রধান CTA/button-এর জোরালো রঙ], [অতিরিক্ত উজ্জ্বল রঙের পরে mobile-এ লেখা দেখা যাচ্ছে কি না দেখুন],
  [পেজ ব্যাকগ্রাউন্ড], [পেছনের রঙ বা ঐচ্ছিক background image], [ব্যস্ত/অতিরিক্ত লেখা-যুক্ত ছবি ব্যবহার করবেন না],
  [মূল লেখার রঙ], [পাবলিক শেলের body text tone], [হালকা text রঙ দেবেন না; contrast বজায় রাখুন],
  [ফন্ট সাইজ], [ছোট, স্বাভাবিক বা বড় পাঠযোগ্যতা], [বড় বয়স্ক visitor-এর জন্য “বড়” উপযোগী],
  [লেআউট ফাঁকা জায়গা], [section-গুলোর compact, standard বা relaxed spacing], [তথ্য বেশি হলে standard রাখুন],
)

পরিবর্তনের নিরাপদ ক্রম: (১) একবারে একটি বা দুটি সেটিং বদলান, (২) Save appearance চাপুন, (৩) homepage refresh করে বাংলা ও English-এ দেখুন, (৪) মোবাইলে button ও লেখা দেখা যাচ্ছে কি না পরীক্ষা করুন। পছন্দ না হলে আগের hexadecimal রঙ বা standard size/density ফিরিয়ে Save করুন।

> কোনগুলো Admin থেকে বদলানো যায়: লেখা, ছবি, logo, hero, menu, announcement, service card, gallery, রঙ, background, font size এবং spacing। কোনগুলো সুরক্ষিত: login/password policy, permission, database structure, payment credential, source code, security header এবং server setting। সুরক্ষিত অংশ পরিবর্তনের প্রয়োজন হলে আগে backup নিয়ে অনুমোদিত প্রযুক্তিগত সহায়তা নিন; এগুলো Admin appearance panel থেকে বদলানো যাবে না।

= খবর, Notice ও Blog প্রকাশ

== নতুন পোস্ট তৈরি

“জনসভা / News / Notice” প্যানেলে Add New চাপুন। বাংলা ও English title, description, date, cover image এবং প্রয়োজন হলে PDF attachment দিন। গুরুত্বপূর্ণ notice হলে Pin চালু করুন। পোস্টটি visitor-কে দেখাতে Status থেকে Published নির্বাচন করে Save করুন।

#table(
  columns: (2fr, 3.5fr, 3fr),
  inset: 6pt,
  table.header([*ফিল্ড*], [*কী দেবেন*], [*যাচাই*]),
  [Title BN/EN], [সংক্ষিপ্ত, পরিষ্কার শিরোনাম], [দুই ভাষাতেই পূরণ হয়েছে],
  [Date], [সঠিক প্রকাশের তারিখ], [ভুল ভবিষ্যৎ তারিখ নয়],
  [Cover Image], [পরিষ্কার ও প্রাসঙ্গিক ছবি], [মোবাইলেও কাটা যাচ্ছে না],
  [PDF], [প্রয়োজনীয় notice/attachment], [Link খুলছে],
  [Status], [Draft বা Published], [Public হলে Published],
)

পোস্ট প্রকাশের পরে Public Blog page খুলে title, cover image, date এবং দুই ভাষার লেখা যাচাই করুন। ভুল হলে Edit করুন; একেবারে সরাতে হলে Delete চাপুন এবং confirmation প্রশ্নে নিশ্চিত করুন।

= Tourist Spot, India Travel ও Border Route

== Tourist Spot পরিচালনা

“Tourist Spots” থেকে নাম BN/EN, category, location, description, cover image, gallery এবং map link পরিবর্তন করা যায়। একটি নতুন spot যোগ করার সময় gallery-তে কমপক্ষে একটি cover এবং পরিকল্পনার জন্য উপযোগী কয়েকটি আসল ছবি দিন। Map link খুলে location ঠিক আছে কি না পরীক্ষা করুন। Public Visibility OFF থাকলে সাইটে spot দেখা যাবে না।

Homepage-এর সাদা tourist button-এর লেখা হলো “বাংলাদেশ ভ্রমণের জন্য আপনার পছন্দের স্থান বেছে নিন”; English-এ “Choose your preferred destination”। এটি `/bangladesh` planner-এ নিয়ে যায়।

== Border route তথ্য

Bangladesh–India যাত্রাসংক্রান্ত তথ্য পরিবর্তনের সময় শুধু যাচাইকৃত সরকারি বা border authority উৎস ব্যবহার করুন। Border status, visa rule, opening time বা fee পরিবর্তনশীল হতে পারে; তাই কোনো স্থায়ী দাবি লিখলে update date দিন এবং visitor-কে official source যাচাই করতে বলুন। অনুমানভিত্তিক ভ্রমণ-পরামর্শ প্রকাশ করবেন না।

= Media Hub ও সংবাদমাধ্যম

Media Hub-এ প্রতিটি tab-এর নাম, link, logo এবং display order গুরুত্বপূর্ণ। জাতীয় পত্রিকার তালিকায় “আমার দেশ” প্রথমে Prime badge-সহ থাকবে। News tab-এ বাংলাদেশ টেলিভিশন (BTV) আগে এবং Jamuna TV পরের দিকে রাখা আছে। প্রতিটি entry-র official website ব্যবহার করুন; logo না এলে ব্রাউজারে link এবং image address পরীক্ষা করুন।

নতুন media যোগ করার সময়: নাম BN/EN, সঠিক official URL, trusted logo URL, category এবং order দিন। একই link দুইবার রাখবেন না। কোনো অননুমোদিত logo, সংবাদ বা rating প্রকাশ করবেন না।

= Menu, Header ও প্রবাসী সহায়তা

“Menu & Header Manager” থেকে menu item Add, Edit, Hide/Show ও Delete করা যায়। Drag & Drop-এর পরে Save না করলে visitor side-এ নতুন order দেখা যাবে না। Link field-এ internal page হলে `/sponsor` বা `/bangladesh`-এর মতো path দিন; external link হলে `https://` দিয়ে পূর্ণ ঠিকানা দিন।

Probashi Help Box-এর title, subtitle এবং guideline link দুই ভাষায় পরিষ্কারভাবে লিখুন। link পরিবর্তনের পরে mobile menu খুলে button-টি কাজ করছে কি না দেখুন।

= SEO, Analytics ও Leads

== Manual SEO

“SEO & Settings” থেকে Manual SEO mode চালু করে প্রতিটি পৃষ্ঠার Meta Title, Meta Description, Keywords এবং #gls("og") নির্ধারণ করুন। Title সংক্ষিপ্ত ও পৃষ্ঠার বিষয়ের সঙ্গে মিল রাখুন। এক পৃষ্ঠার metadata অন্য পৃষ্ঠায় কপি করবেন না। পরিবর্তনের পরে link preview সঙ্গে সঙ্গে না বদলালে cache update হতে সময় লাগতে পারে।

== Analytics ও Public Stats

#gls("ga4") যুক্ত থাকলে Dashboard-এ traffic পরিমাপ দেখা যায়। Public Stats Settings থেকে Active Users, Page Views, Key Events, Top Countries, Engagement এবং Shares card আলাদাভাবে ON/OFF করা যায়। যে সংখ্যা Google Analytics থেকে এখনো আসেনি সেটি অনুমান করে লিখবেন না।

== Leads Management

Lead list থেকে আসা phone, subject ও message দেখে উত্তর দেওয়ার আগে তথ্য মিলিয়ে নিন। CSV Export ব্যবহার করে রিপোর্ট রাখুন। Spam হলে Delete চাপুন; confirmation ছাড়া record মুছবেন না।

= Media Manager: ছবি, PDF ও ফাইল

সব upload করা file #gls("s3")-এ সংরক্ষিত হয়। Folder হিসেবে Banner, News, Tourist এবং General ব্যবহার করুন। Replace করার আগে পুরোনো file কোথায় ব্যবহার হয়েছে নোট করুন। Delete করলে সেই ছবি কোনো public section-এ ভাঙা দেখাচ্ছে কি না পরীক্ষা করুন।

ছবি আপলোডের আগে নামটি অর্থপূর্ণ রাখুন—যেমন `coxsbazar-cover-2026.jpg`। খুব বড় ছবি upload করলে mobile data ও page speed ক্ষতিগ্রস্ত হতে পারে, তাই পরিষ্কার কিন্তু web-friendly image ব্যবহার করুন।

= মূল্য, অর্ডার ও পেমেন্ট

== মূল্য সেটিংস ও অর্ডার

“মূল্য সেটিংস” থেকে service price এবং সরকারি fee পরিবর্তন করা যায়। Save করার পরে নতুন order-এ server-side total হিসাব হবে এবং একটি reference number তৈরি হবে। #gls("order") list-এ pending/complete status দেখা যাবে। Total হাতে লিখে বদলাবেন না; service price ও fee-ই পরিবর্তন করুন।

== TEST MODE সিমুলেশন ও bKash/Nagad প্রস্তুতি

বর্তমান #gls("testmode") প্রবাহে উপরে লাল “TEST MODE — কোনো টাকা কাটা হয়নি” বার দেখা যায়। Visitor bKash বা Nagad simulation বেছে নিতে পারেন; কিন্তু সেটি বাস্তব transaction, provider approval, SMS বা email নয়। PDF receipt-এও “TEST MODE / কোনো টাকা কাটা হয়নি” লেখা থাকবে। এই label কখনও সরাবেন না, যতক্ষণ না বাস্তব gateway callback ও signature verification চালু হয়েছে।

বাস্তব provider test-এর জন্য #gls("sandbox") credential লাগে। bKash-এর checkout onboarding ও tokenized checkout flow provider developer portal অনুযায়ী configure করতে হবে। Merchant onboarding বা provider sandbox credential ছাড়া TEST MODE-এর “সফল” অবস্থা সত্যিকারের provider test নয়। [1]

bKash/Nagad-এর merchant বা sandbox credential পাওয়ার পরে সেগুলো শুধু নিরাপদ secret settings-এ যোগ করতে হবে; code, spreadsheet বা chat message-এ লিখবেন না। তারপর redirect URL, callback signature verification, success, cancellation, duplicate submission এবং receipt—সব path একসঙ্গে পরীক্ষা করুন। বাস্তব gateway যাচাই শেষ না হওয়া পর্যন্ত public payment screen-এ TEST MODE চালু রাখুন।

= Premium Photo Gallery ও ছবি বিক্রির নিয়ন্ত্রণ

== নতুন Premium ছবি যোগ করা

Dashboard-এর “Premium Photo Gallery” প্যানেল থেকে Preview Image এবং Original High Quality Image আলাদা করে upload করুন। Preview-তে visitor watermark-সহ ছবি দেখেন; Original file শুধু সফল delivery record-এর জন্য সংরক্ষিত হয়। Title BN/EN, Description BN/EN, Price, Watermark Text এবং Published visibility পূরণ করে Save করুন। Public Visibility OFF থাকলে সেই ছবি visitor দেখতে পাবেন না।

#table(
  columns: (2.25fr, 4.7fr, 2.1fr),
  inset: 5pt,
  table.header([*ফিল্ড*], [*সঠিক ব্যবহার*], [*শেষ যাচাই*]),
  [Preview Image], [Watermark দেওয়ার উপযোগী web preview], [Public page-এ watermark দেখা যায়],
  [Original Image], [গ্রাহকের জন্য উচ্চমানের আসল file], [সরাসরি public URL প্রকাশ হয়নি],
  [Price], [বাংলাদেশি টাকায় পরিষ্কার মূল্য], [কেনার আগে সঠিক total],
  [Watermark Text], [যেমন: SahajSheba বা SahajContact], [প্রতিটি preview-তে দৃশ্যমান],
  [Published], [ON হলে public gallery-তে প্রদর্শন], [ভুল ছবি হলে OFF],
)

== নিরাপদ TEST MODE ক্রয় পরীক্ষা

Public homepage-এর Premium Photo Gallery থেকে একটি প্রকাশিত ছবির “কিনুন” চাপুন। Customer name ও email দিয়ে bKash/Nagad TEST MODE simulation সম্পন্ন করুন। সফল হলে delivery link এবং PDF invoice পাওয়া যায়; তবে এটি #gls("testmode")—বাস্তব টাকা কাটা বা বাস্তব SMS/email পাঠানো হয়নি। ছবি প্রকাশের আগে owner নিজে একবার পুরো flow পরীক্ষা করুন এবং পরীক্ষার record আলাদা করে রাখুন।

Preview-তে visible watermark এবং right-click block visitor experience উন্নত করে; কিন্তু কোনো website browser-level screenshot সম্পূর্ণভাবে ঠেকাতে পারে না। তাই অপ্রকাশ্য বা সংবেদনশীল ছবি premium gallery-তে upload করবেন না। ভুল ছবি হলে Admin panel থেকে Published OFF করুন অথবা Delete চাপার পরে confirmation দিন।

= নিজস্ব স্থিরচিত্র ও Map Photo ফোল্ডার

Dashboard-এর “নিজস্ব ছবি ও Map Photo ফোল্ডার” প্যানেলটি ব্যক্তিগত বা অবস্থান-সংক্রান্ত ছবি নিয়ন্ত্রণের জন্য। *নিজস্ব স্থিরচিত্র* বেছে নিলে ছবিটি Bank সেকশনের নিচের public gallery-তে দেখা যায় এবং visitor ছবিটি download করতে পারেন। *Map Photo* বেছে নিলে প্রকাশ্য এবং সর্বনিম্ন display order-র ছবিটি Contact পেজে Google Maps-এর পাশে দেখা যায়।

#table(
  columns: (2.25fr, 4.7fr, 2.1fr),
  inset: 5pt,
  table.header([*কাজ*], [*Dashboard-এ করণীয়*], [*Public ফলাফল*]),
  [নতুন স্থিরচিত্র], [ফোল্ডার “নিজস্ব স্থিরচিত্র” বেছে JPEG/PNG/WebP upload, বাংলা ও English নাম লিখে Public ON করে Save], [Bank সেকশনের নিচে ছবি ও Download বাটন দেখা যায়],
  [Map Photo], [ফোল্ডার “Map Photo” বেছে ছবি upload, Public ON ও display order ঠিক করে Save], [Contact পেজের মানচিত্রের পাশে নির্বাচিত ছবি দেখা যায়],
  [ছবি বদলানো], [তালিকা থেকে Edit চাপুন, নতুন ছবি upload বা লেখা/ক্রম বদলে Save], [Public page refresh করলে পরিবর্তন দেখা যায়],
  [ছবি লুকানো], [Public checkbox বন্ধ করে Save], [ছবিটি public site থেকে সরবে; record Dashboard-এ থাকবে],
  [স্থায়ীভাবে মুছা], [Delete চাপুন এবং “আপনি কি নিশ্চিত?” বার্তায় সম্মতি দিন], [ছবি আর public gallery-তে থাকবে না],
)

একই folder-এ একাধিক ছবি থাকলে কম display order আগে দেখানো হয়। Map Photo-র জন্য সাধারণত একটি প্রকাশিত ছবি রাখুন; একাধিক রাখলে সবচেয়ে কম order-রটিই public contact section-এ ব্যবহৃত হবে। ছবি upload করার আগে অন্যের ব্যক্তিগত ছবি প্রকাশের অনুমতি আছে কি না যাচাই করুন।

= Homepage-এর ভাঁজ করা তথ্য ও মতামত

Bank, Health Services ও Education অংশ এখন folder হিসেবে default-এ বন্ধ থাকে। Visitor title-এ চাপলে ভেতরের পূর্ণ directory খুলবে। কোনো তথ্য বদলানোর পরে desktop এবং mobile—দুই অবস্থাতেই folder খুলে link, title এবং layout পরীক্ষা করুন।

মতামত অংশে সবচেয়ে সাম্প্রতিক entry প্রথমে দেখা যায়। “সব মতামত দেখুন” চাপলে বাকি feedback দেখা যায়; পরে “সর্বশেষ মতামত দেখুন” চাপলে আবার সংক্ষিপ্ত view-তে ফিরে আসে। কোনো মতামতকে নিজে থেকে বানানো, rating বদলানো বা customer হিসেবে প্রকাশ করা যাবে না।

= Cache Clear, 404 ও সাধারণ সমস্যা সমাধান

#table(
  columns: (2.1fr, 2.9fr, 3.5fr),
  inset: 5pt,
  table.header([*সমস্যা*], [*আগে যা দেখবেন*], [*করণীয়*]),
  [Save হয়েছে কিন্তু public page পুরোনো], [সঠিক ভাষা/পৃষ্ঠা দেখছেন কি না], [Reload করুন, Cache Clear দিন, কয়েক মিনিট পরে দেখুন],
  [English চাপলেও বাংলা], [Header toggle এবং saved preference], [Toggle বদলে page reload; bilingual BN/EN field পূরণ করুন],
  [ছবি দেখা যাচ্ছে না], [Media link বা deleted file], [Media Manager থেকে file/URL যাচাই বা Replace করুন],
  [পোস্ট public নয়], [Status], [Edit করে Published নির্বাচন, তারপর Save],
  [order total ভুল], [service price/fee], [মূল্য সেটিংসের দুই field পরীক্ষা করে Save করুন],
  [Premium ছবি দেখা যাচ্ছে না], [Published toggle ও preview upload], [Gallery Manager-এ Published ON এবং preview URL পরীক্ষা করুন],
  [নিজস্ব ছবি দেখা যাচ্ছে না], [ফোল্ডার, Public toggle ও display order], [সঠিক folder বেছে Public ON করে Save; তারপর page reload করুন],
  [Map Photo বদলায়নি], [Map Photo folder ও lowest display order], [প্রকাশিত ছবির order 0/সর্বনিম্ন দিন; Contact page reload করুন],
  [Delivery link কাজ করছে না], [TEST MODE purchase record], [নতুন TEST MODE flow দিয়ে পরীক্ষা করুন; production gateway হলে credential/callback log পরীক্ষা করুন],
  [Bank/Health/Education content দেখা যাচ্ছে না], [Folder বন্ধ আছে কি না], [Section title চাপ দিয়ে folder খুলুন],
  [Admin form কাজ করছে না], [login session], [লগ আউট করে password দিয়ে আবার খুলুন; তবুও না হলে screenshotসহ support note রাখুন],
)

404 Error Page-এর লেখা Settings থেকে পরিবর্তন করা যায়। Visitor-কে homepage বা যোগাযোগ পৃষ্ঠায় ফেরার একটি স্পষ্ট link দিন।

= Backup, প্রকাশ এবং মাসিক রক্ষণাবেক্ষণ

মাসে অন্তত একবার secret-free project backup রাখুন। Backup-এর ভেতরে `.env`, password, API key, browser cookie, database credential বা uploaded private document থাকবে না। এই source backup-এ database schema ও migration থাকে; এতে live customer data, private S3 file বা platform-managed secret থাকে না। Live data বা private asset আলাদাভাবে export করতে হলে আগে privacy, permission এবং hosting provider-এর নিরাপদ export procedure নিশ্চিত করুন। পরিবর্তন করার আগে একটি backup এবং প্রকাশের পরে আরেকটি backup রাখুন।

#table(
  columns: (2.5fr, 6fr),
  inset: 6pt,
  table.header([*সময়*], [*নিয়মিত কাজ*]),
  [প্রতিদিন], [নতুন Lead, জরুরি notice ও public link পরীক্ষা],
  [প্রতি সপ্তাহে], [Media link, tourist map link ও bilingual copy পরীক্ষা],
  [প্রতি মাসে], [Backup, broken-link check, SEO metadata এবং analytics review],
  [payment চালুর আগে], [sandbox callback, cancelled payment, duplicate submission ও receipt পরীক্ষা],
)

= সাধারণ পরিভাষা

#print-glossary(terms, show-all: true, disable-back-references: true)

= তথ্যসূত্র

[1] #link("https://developer.bka.sh/")[bKash Developer Portal — Checkout ও sandbox onboarding নির্দেশনা]

এই ম্যানুয়ালের Admin workflow-গুলো SahajContact-এর প্রকাশিত site structure এবং বর্তমান Admin CMS-এর সঙ্গে সামঞ্জস্য রেখে লেখা হয়েছে।
