# Document Build Sources

The Bengali Admin manual uses the selected `glossarium` package to present operational terms. Its documented setup imports `make-glossary`, `register-glossary`, `print-glossary`, and `gls`; the package requires `#show: make-glossary` before term references.

- [Glossarium 0.5.10 package documentation](https://typst.app/universe/package/glossarium/)
