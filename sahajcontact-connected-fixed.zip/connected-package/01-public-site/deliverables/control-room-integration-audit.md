# Super Control Room Source Audit

## Scope and inspection method

The supplied `SAHajContact-Super-Control-Room-Source.zip` archive was inspected as untrusted source material. Its archive integrity check passed, and the eleven contained files were reviewed without executing any Apps Script code. The package is a **Google Apps Script web application**, not an APK, a Firebase app, or a separately hosted server.

## Current implementation

| Area | Finding | Integration consequence |
| --- | --- | --- |
| Owner interface | Mobile-first Bengali Apps Script HTML interface | It can remain the owner-facing Control Room interface. |
| Data store | Private Apps Script Script Properties | Its switches, local backups, and audit list are separate from SahajContact's database. |
| Current controls | Maintenance state/message and SMS, signup, payment, and login toggles | These values currently affect only the Apps Script project; they do not update SahajContact. |
| Authentication | Intended for one Google account and restricted Apps Script deployment | The owner identity must be checked again by SahajContact through a separate, revocable machine credential; browser cookies cannot be reused externally. |
| External communication | No HTTP client, webhook, remote endpoint, or shared data layer exists | A new server-side bridge is necessary before any Control Room switch can change the live portal. |
| Audit capability | Local Apps Script audit list and backup snapshots | SahajContact must also record all accepted remote actions in its existing server-side operational logs. |

## Security observations

The supplied source uses Script Properties and a script lock, which are suitable for its local control state. However, it has no outbound authentication protocol because it is currently standalone. The deployed owner account documented by the supplied source differs from the SahajContact owner email used by the live portal. Therefore, the connection must **not** treat an email string or the public Apps Script URL as proof of authority.

The existing `requireOwner_()` helper falls back to the configured owner email when the Apps Script active-user email is unavailable. The Apps Script deployment must consequently remain restricted to the owner account, and the proposed server bridge must fail closed unless it receives a valid request signature or bearer credential. No browser-session cookie, Google account identity, GA4 credential, or CMS owner password will be transmitted to the Control Room.

## Outage-recovery boundary

> A Control Room running on Google Apps Script can remain accessible while SahajContact is unavailable, but it cannot change a database or API that is itself unreachable. It can retain queued changes, local recovery notes, and emergency status information until the main service returns.

The current `manus.space` address cannot be failed over by this Apps Script project. A genuine public-site failover requires a separate independent fallback host and control over a custom domain's DNS or edge routing. The Control Room integration can provide remote maintenance control and queued, audited settings synchronization when the SahajContact API is reachable; it cannot make the same public site self-heal during a total production or database outage.

## Recommended safe scope for the first connection

The first bridge should use a dedicated, revocable server-side shared credential held only in protected secrets and Apps Script Script Properties. It should accept a narrow allowlist of actions: read status, switch maintenance mode, set a short maintenance message, and enable or disable the existing payment, login, signup, and SMS controls. Every accepted action should be timestamped and recorded in SahajContact's operational log. High-risk CMS changes, payment settings, user records, media uploads, backups, and source deployment controls should remain within the existing owner dashboard until a separate approval design is completed.
