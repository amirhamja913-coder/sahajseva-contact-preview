# Government Hospital Directory Audit

Audit date: 22 August 2026

The public Health Service folder currently directs visitors to the official DGHS Facility Registry, ambulance directory, and 16263 health guidance. It does **not** currently display named government hospitals with address context. The correction should retain the official all-Bangladesh directory and add a small, clearly labelled verified example list rather than claim that a short static list is complete.

## Verified sources

1. The official [DGHS Facility Registry](https://hrm.dghs.gov.bd/public/facility-registry) identifies itself as the Ministry of Health and Family Welfare's list of institutions. It offers filters for government ownership, facility type, division, district, city corporation, and upazila.
2. The official [DGHS Organization List report](https://hrm.dghs.gov.bd/public/facility-registry/reports/organization-list) reports 39,432 active facilities at the time of review and supports exporting filtered results. It is the authoritative all-country lookup path, so static entries must not be presented as exhaustive.
3. The UK FCDO's [Bangladesh doctors and medical facilities list](https://www.gov.uk/government/publications/bangladesh-list-of-medical-facilities/bangladesh-doctors-and-medical-facilities), updated 1 December 2024, identifies the following public DGHS-accredited hospitals and published address context:
   - Dhaka Medical College Hospital — Secretariat Road, Dhaka.
   - Kurmitola General Hospital — New Airport Road, Kurmitola, Dhaka Cantonment, Dhaka-1206.
   - Sylhet MAG Osmani Medical College Hospital — Medical Road, Kajolshah, Sylhet.

## Implementation guidance

Display the three examples under a heading such as “কিছু যাচাইকৃত সরকারি হাসপাতাল (পূর্ণ তালিকা নয়)”. Label each address as information to verify at the linked official source. Keep a prominent DGHS Facility Registry action for nationwide, current address and availability searches. In an emergency, direct visitors to 999; do not imply that this directory dispatches ambulances or guarantees beds, doctors, or service availability.
