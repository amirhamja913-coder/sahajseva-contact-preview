# Public Menu and Admin Coverage Audit

**Audit state:** In progress  
**Audit date:** 2026-08-22

The published homepage currently exposes the following top navigation items: Home, Services, About Us, Partnership & NGO, Future Plan, Public Guidance, Security Policy, Contact, Sponsor Us, and Service Tools. It also exposes language switching, theme control, PWA installation, sharing, public photo categories, service search and service-category filters.

The first published-page inspection confirms that a material amount of public content is still assembled from page-level content blocks and action-card configuration, rather than presenting an obvious one-to-one owner-management surface. The implementation audit will map each of these public areas to its actual Dashboard control and identify any content that needs a dedicated owner-safe editor.

The transport and Bangladesh–India travel area is already known to have DB-backed land-border records but no dedicated Dashboard manager. This remains a priority gap within the broader menu coverage audit.
