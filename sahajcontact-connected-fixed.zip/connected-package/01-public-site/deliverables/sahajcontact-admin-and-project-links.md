# SahajContact — প্রয়োজনীয় লিংক

এই ফাইলটি ফোনে সংরক্ষণ করুন অথবা অন্য developer-কে পাঠান।

| কাজ | লিংক |
|---|---|
| **Main public site** | https://sahajcontact-8xyxsefc.manus.space/ |
| **Admin content editing** | https://sahajcontact-8xyxsefc.manus.space/admin/dashboard |
| **Bangladesh / India / Transport public page** | https://sahajcontact-8xyxsefc.manus.space/bangladesh |
| **Current project version** | manus-webdev://dcf8f4c4 |

## ফোনে কীভাবে ব্যবহার করবেন

1. **Main public site** লিংকটি খুললে সাধারণ visitors যে website দেখেন তা দেখা যাবে।
2. **Admin content editing** লিংকটি খুলে owner password session দিয়ে Dashboard-এ প্রবেশ করুন। এখান থেকে site content, menu, images, Transport & India তথ্য এবং অন্যান্য owner-enabled অংশ edit করে **Save** দিন।
3. **Current project version** লিংকটি Manus project workspace-এ বর্তমান version খোলার জন্য। এটি public site নয় এবং code/project edit করার অনুমতি Manus account access-এর মাধ্যমে নিয়ন্ত্রিত।

> নিরাপত্তা: Admin password, project secrets, বা database credentials কাউকে পাঠাবেন না। অন্য developer-কে code পরিবর্তনের প্রয়োজন হলে কেবল যথাযথ project access দিন।
