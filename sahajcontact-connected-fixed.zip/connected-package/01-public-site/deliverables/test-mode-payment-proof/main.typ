// Owner-facing no-funds payment-simulation proof report.
#import "report-theme.typ": report-accent, report-theme

#let danger = rgb("b42318")
#let danger-soft = rgb("fff2f0")
#let green = rgb("176b4d")

#show: report-theme.with(
  title: "TEST MODE Payment Simulation Proof",
  author: "SahajContact",
  rhythm: "report",
  running-header: true,
)

#set text(font: ("Noto Sans Bengali", "Noto Sans"))

// ---------- Title page ----------
#page(margin: (top: 29%, x: 2.2cm), numbering: none, header: none)[
  #set par(first-line-indent: 0em)
  #align(center)[
    #text(size: 26pt, weight: "bold", fill: danger)[TEST MODE Payment Simulation Proof]
    #v(0.5em)
    #text(size: 14pt, fill: luma(80))[কোনো অর্থ স্থানান্তর হয়নি — যাচাইকৃত প্রমাণ]
    #v(2em)
    #line(length: 40%, stroke: 0.5pt + luma(160))
    #v(2em)
    #text(size: 12pt)[
      প্রস্তুতকারী: SahajContact \
      তারিখ: ২১ আগস্ট ২০২৬ \
      অবস্থা: TEST MODE / No Funds
    ]
  ]
]

// ---------- Main body ----------
#counter(page).update(1)

= প্রমাণের সারসংক্ষেপ

এই প্রতিবেদনটি SahajContact-এর public order flow-এ চালানো একটি স্পষ্টভাবে চিহ্নিত TEST MODE payment simulation-এর ফলাফল সংরক্ষণ করে। এটি bKash বা Nagad-এর আসল payment gateway-এর অনুমোদন নয়, এবং এতে কোনো merchant credential, provider API key, SMS credential বা Email credential ব্যবহৃত হয়নি।

#rect(
  fill: danger-soft,
  stroke: 1pt + danger,
  radius: 8pt,
  inset: 14pt,
  width: 100%,
)[
  #text(weight: "bold", fill: danger)[TEST MODE — কোনো টাকা কাটা হয়নি]

  #v(0.45em)
  এই প্রমাণে payment button চাপার ফলে শুধুমাত্র একটি software simulation সম্পন্ন হয়েছে। কোনো অর্থ transfer হয়নি, কোনো বাস্তব SMS পাঠানো হয়নি এবং কোনো বাস্তব Email delivery করা হয়নি।
]

= যাচাইকৃত ফলাফল

#table(
  columns: (37%, 63%),
  stroke: 0.5pt + luma(190),
  inset: 8pt,
  [*পরীক্ষার ধাপ*], [*রেকর্ডকৃত ফলাফল*],
  [Product / service selection], [Online application support service-এর জন্য test order তৈরি করা হয়েছে।],
  [Order reference], [SC-MT2JLCVN-IW0X],
  [Service total], [৳250; এটি order summary-তে দেখানো server-calculated amount।],
  [Payment action], [bKash test simulation চালানো হয়েছে; এটি কোনো real provider checkout নয়।],
  [Simulation result], [Simulation complete — কোনো টাকা transfer হয়নি।],
  [SMS status], [পাঠানো হয়নি — SMS provider key এখনও যুক্ত করা হয়নি।],
  [Email status], [পাঠানো হয়নি — Email provider/recipient এখনও যুক্ত করা হয়নি।],
  [Receipt artifact], [TEST MODE PDF receipt সফলভাবে download করা হয়েছে।],
)

= দৃশ্যমান প্রমাণ

নিচের screenshot-এ একই screen-এ লাল TEST MODE disclosure, payment-simulation buttons, simulation completion message, “পাঠানো হয়নি” SMS/Email status এবং PDF receipt download control দেখা যাচ্ছে।

#figure(
  image("test-mode-simulation-complete.webp", width: 100%),
  caption: [Public order summary-তে TEST MODE simulation completion-এর captured evidence.],
)

= কী প্রমাণিত হয়েছে

#list(
  [User flow-তে product/service order থেকে TEST MODE simulation পর্যন্ত একটি দৃশ্যমান পথ রয়েছে।],
  [Screen-এ এটি পরীক্ষা হিসেবে চিহ্নিত এবং “কোনো টাকা কাটা হয়নি” সতর্কতা স্পষ্ট আছে।],
  [SMS ও Email-এর অবস্থা সত্যনিষ্ঠভাবে “পাঠানো হয়নি” দেখায়; কোনো ভুয়া delivery claim করা হয়নি।],
  [Download করা receipt-এও TEST MODE এবং no-funds disclosure থাকে।],
)

= পরবর্তী নিরাপদ ধাপ

Official bKash/Nagad sandbox বা production payment চালু করার আগে owner-কে সংশ্লিষ্ট provider-এর অনুমোদিত merchant/sandbox credentials নিরাপদে প্রদান করতে হবে। Credentials ছাড়া কোনো real payment activation বা real payment-success claim করা হবে না।
