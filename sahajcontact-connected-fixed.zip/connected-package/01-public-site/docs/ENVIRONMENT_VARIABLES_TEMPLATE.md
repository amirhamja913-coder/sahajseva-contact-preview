# SahajContact environment-variable template

This file is the **secret-free template** for deployments and backup handoff. Copy the variable names to the deployment platform’s secure secret manager, then add the real values there. Do **not** commit a populated `.env` file or send credentials through chat, email, or screenshots.

| Group | Variable | Status |
|---|---|---|
| Application | `NODE_ENV` | Required in production; use `production` |
| Database | `DATABASE_URL` | Required |
| Session security | `JWT_SECRET` | Required; generate a unique strong value |
| Manus OAuth | `VITE_APP_ID`, `OAUTH_SERVER_URL`, `VITE_OAUTH_PORTAL_URL` | Required when using Manus OAuth |
| Owner control | `OWNER_OPEN_ID`, `OWNER_NAME` | Optional when using the local password owner gate |
| Local Admin login | `LOCAL_ADMIN_PASSWORD`, `LOCAL_ADMIN_NAME` | `LOCAL_ADMIN_PASSWORD` is required for the local admin login; keep it only in deployment secrets |
| Retired Admin variables | `ADMIN_CUSTOM_PASSWORD`, `ADMIN_OTP_EMAIL` | Not used; configure `LOCAL_ADMIN_PASSWORD` instead |
| Platform services | `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY`, `VITE_FRONTEND_FORGE_API_URL`, `VITE_FRONTEND_FORGE_API_KEY` | Required only when the respective platform services are used |
| Scheduling | `SCHEDULED_JOB_SECRET` | Required only for scheduled jobs |
| Analytics | `VITE_GA_MEASUREMENT_ID`, `GA4_PROPERTY_ID`, `GA4_SERVICE_ACCOUNT_JSON`, `VITE_ANALYTICS_ENDPOINT`, `VITE_ANALYTICS_WEBSITE_ID` | Optional; configure only when analytics is enabled |
| Mail | `GMAIL_APP_PASSWORD` | Optional; configure only when secure email notification is enabled |
| bKash | `BKASH_APP_KEY`, `BKASH_APP_SECRET`, `BKASH_USERNAME`, `BKASH_PASSWORD` | Future live-gateway configuration; leave unset before merchant approval |
| Nagad | `NAGAD_MERCHANT_ID`, `NAGAD_MERCHANT_KEY` | Future live-gateway configuration; leave unset before merchant approval |
| SMS | `SMS_API_KEY` | Future notification configuration; leave unset until a provider is selected |

> **Important:** No payment, receipt, invoice, or test-mode payment flow is active. Do not configure bKash/Nagad gateway values or represent a provider transaction until merchant approval, written policy, privacy review, provider verification, and an authorised implementation are complete.

## Secure deployment checklist

1. Create each variable in the host’s secret settings, leaving the source repository secret-free.
2. Use a unique production database and a unique `JWT_SECRET`.
3. Restrict database access, rotate keys after any suspected exposure, and never place API keys in frontend source code.
4. Confirm that public-only configuration such as `VITE_GA_MEASUREMENT_ID` does not expose a private credential.
5. Test the local password owner sign-in boundary and permitted media/CMS actions after deployment; do not test or expose an order or payment path while payments are inactive.

## Control Room bridge
CONTROL_ROOM_SHARED_SECRET=REQUIRED  # Same random secret configured in Control Room; never commit it
