# SahajContact তিন-সাইট programme: পরিচালনা, সংযুক্তি ও budget planning

**প্রস্তুতির তারিখ:** 27 August 2026  
**পরিধি:** SahajContact public portal, এর in-site owner Admin workspace, এবং পৃথক SahajControl/Executive Control project-এর programme-level planning।

> এটি একটি **planning estimate**—কোনো vendor quotation, ক্রয়-নির্দেশ, বিনিয়োগ পরামর্শ, বা service-level commitment নয়। বাস্তব চুক্তির আগে scope, ownership, security review, tax/VAT, vendor capability, usage volume ও support window লিখিতভাবে নির্ধারণ করা প্রয়োজন।

## 1. এখনকার অবস্থান ও নিরাপদ কাঠামো

SahajContact-এর public portal ও তার in-site Admin এখন আলাদা দায়িত্বে আছে: public অংশে দর্শনার্থীর জন্য তথ্য ও service navigation, এবং owner-only অংশে অনুমোদিত operational controls। Admin entry কেবল official OAuth ও server-side owner authorization ব্যবহার করে; কোনো আলাদা password, PIN, OTP, recovery code বা client-side credential store করা হয়নি। এই সীমা রাখা জরুরি, কারণ public navigation এবং management authority একই জিনিস নয়।

তৃতীয় system SahajControl/Executive Control-কে আলাদা project হিসেবেই রাখতে হবে। এটি একটি programme-level coordination layer হতে পারে, কিন্তু SahajContact-এর private Admin data বা credentials সরাসরি copy করে সেখানে নেওয়া যাবে না। বর্তমান source-access সীমাবদ্ধতার কারণে সেই পৃথক project-এর OAuth return-path সমস্যা এই release-এ পরিবর্তন করা হয়নি।

| Layer | উদ্দেশ্য | বর্তমান/প্রস্তাবিত নিরাপদ boundary |
| --- | --- | --- |
| **SahajContact public portal** | সেবা, tourism, gallery, civic information ও public discovery | Public content only; external links নিরাপদ নতুন tab-এ খোলে; কোনো owner control প্রকাশ নয় |
| **In-site Admin workspace** | Owner-এর অনুমোদিত site operation, content, audit ও workflow entry | Official OAuth + server-side owner check; responsive reference-inspired navigation; বাস্তব data ছাড়া fabricated dashboard metrics নয় |
| **SahajControl / Executive Control** | একাধিক site-এর programme oversight | স্বতন্ত্র project ও authorization boundary; source access ও OAuth fix ছাড়া live linkage নয় |

## 2. Reference design থেকে বাস্তবায়িত দিক

দেওয়া dashboard design-টির ব্যবহারযোগ্য দিক—light visual hierarchy, grouped sidebar, compact mobile navigation, overview entry points এবং দ্রুত action discovery—owner workspace shell-এ প্রয়োগ করা হয়েছে। কিন্তু ছবির সংখ্যাগুলো sample হওয়ায় সেগুলো বা অনুরূপ business counts, review, claim, user, alert বা traffic figures বানিয়ে দেখানো হয়নি। কোনো metric কেবল প্রকৃত, অনুমোদিত data source থেকে আসতে পারে।

| Included in the current safe shell | Intentionally excluded until a verified data source and owner approval exist |
| --- | --- |
| Grouped workspace navigation | Invented users, claims, businesses, sessions or alerts |
| Compact mobile menu and accessible entry points | Fake reviews, ratings, testimonials or “recent activity” |
| Routes to existing content, partner, analytics, security and operation controls | Private dashboard inspection during this work |
| Official OAuth and owner-only separation retained | New password/PIN/OTP/recovery authentication flows |

## 3. প্রয়োজনীয় সংযুক্তির বাস্তব roadmap

সব integration একসঙ্গে চালু করা নিরাপদ নয়। প্রথমে public portal ও in-site Admin-এর ownership, public routes, content workflow এবং audit logging স্থিতিশীল রাখা উচিত; তারপর approved data source অনুযায়ী reporting যোগ করা যায়। Payment, DNS, account selection, advertising, backup restoration, analytics property বা third-party account কোনোটি এই কাজের মধ্যে খোলা/পরিবর্তন করা হয়নি।

| Priority | সংযুক্তি/কাজ | কেন দরকার | আগে যা নিশ্চিত করতে হবে | Status |
| --- | --- | --- | --- | --- |
| P1 | Public portal ↔ in-site Admin content workflow | Owner-approved public content পরিচালনা | Existing owner authorization ও change audit | Existing foundation retained |
| P1 | Public search/SEO signals | Content discoverability | Canonical, robots, sitemap, structured data consistency | Existing audit foundation retained |
| P1 | Mobile/PWA release delivery | Updated public visuals পাওয়া | Service-worker cache/version validation | Current release includes cache refresh |
| P2 | Verified analytics reporting | বাস্তব traffic ও conversion overview | Owner-approved analytics property and read-only service credential | Approval/credential required; do not fabricate data |
| P2 | Partner/advertiser intake workflow | NGO, sponsor, investor ও business enquiries | Public policy, consent text, status workflow, data retention | Requires scoped product decision |
| P3 | SahajControl programme linkage | তিন system-এর high-level oversight | Writable source, correct OAuth return flow, explicit cross-project data contract | Separate blocked project; not changed here |
| P3 | Payments or paid partner tools | Commercial collection/fulfilment | Business/legal process, refund policy, account ownership and security review | Not activated |

## 4. Market reference এবং estimate method

Bangladesh-এর public vendor material থেকে দেখা যায়, basic business site এবং custom portal-এর মূল্যস্তর ব্যাপকভাবে আলাদা। Techabyte-এর April 2026 explanatory guide একটি basic business site প্রায় **৳15,000–৳30,000**, advanced custom site প্রায় **৳50,000–৳150,000**, এবং large custom portal প্রায় **৳200,000 থেকে** শুরু হতে পারে বলেছে; maintenance আলাদা হতে পারে। [^1] ARN TECH-এর August 2026 article professional-help-এর জন্য **৳43,000–৳2,600,000** পর্যন্ত বিস্তৃত range এবং managed hosting **৳1,700–৳5,000/month** উল্লেখ করেছে। [^2] ZAMAN IT-এর published packaged offers ৳14,990–৳49,990 স্তরে আছে, যা ছোট packaged site-এর floor signal; তিন-সাইটের custom owner-control programme-এর সমতুল্য নয়। [^3]

এই programme-এর estimate তাই basic package price দিয়ে গুণ করা হয়নি। নিচের work-package model-এ নিরাপদ authentication, responsive Admin, content governance, testing এবং public delivery-এর বাস্তব শ্রম আলাদা করে ধরা হয়েছে। প্রতিটি সারি একটি planning range; tax/VAT, legal services, ad spend, paid data, payment processing fees ও unforeseen third-party migration এতে নেই।

| One-time work package | Assumption | Planning range (BDT) |
| --- | --- | ---: |
| Discovery, information architecture ও design system | Three-system role map, public/Admin separation, mobile/desktop flows | ৳40,000–৳70,000 |
| Public portal content and visual implementation | Public pages, responsive visual corrections, search/SEO hygiene, PWA delivery | ৳70,000–৳120,000 |
| In-site Admin workspace | Owner-only navigation, real-data-ready overview, content-operation controls and access tests | ৳160,000–৳260,000 |
| Separate SahajControl system completion | Own project workflow, OAuth return fix, dashboard scope and deployment validation | ৳180,000–৳300,000 |
| Secure integration and data contracts | Approved analytics reporting, audit events, cross-project boundary and error handling | ৳220,000–৳400,000 |
| QA, accessibility, device/browser checks and release hardening | Regression suite, responsive checks, release documentation | ৳70,000–৳130,000 |
| Content migration/training and operating handover | Content inventory, role guidance, acceptance review | ৳50,000–৳100,000 |
| Contingency | Unknown source condition, legacy flow repair and approved change requests | ৳40,000–৳100,000 |
| **Estimated programme implementation total** | Sum of the planning work packages | **৳830,000–৳1,480,000** |

The quoted sum is computed directly from the listed assumptions. A lower figure would normally mean materially less scope—for example, removing the separate Control project, deferring integrations, limiting content tools, or accepting fewer validation/support commitments. A higher figure could be justified if regulated payments, broad multilingual content, high-availability operations, custom mobile apps, formal security testing, data migration or 24/7 support are required.

## 5. তিনটি site চালানোর recurring operating model

Recurring cost is not just hosting. A usable three-site programme needs monitoring, security updates, content governance and a known incident path. The following model is presented as **monthly planning capacity**, not a vendor price or mandate. Any external paid service must be approved and billed under an owner-controlled account.

| Monthly operating area | What it covers | Planning range (BDT/month) |
| --- | --- | ---: |
| Hosting, domain/DNS, storage, monitoring and backups | Production capacity and routine operational checks across three systems | ৳12,000–৳30,000 |
| Security, maintenance and release support | Dependency updates, bug triage, access-boundary checks, tested releases | ৳30,000–৳75,000 |
| Content/SEO/analytics reporting operations | Editorial update support and verified report preparation | ৳15,000–৳40,000 |
| Owner support and incident response | Agreed working-hour support, documentation and escalation | ৳10,000–৳30,000 |
| **Estimated recurring total** | Sum of the monthly operating areas | **৳67,000–৳175,000/month** |
| **Indicative annual operating total** | Monthly estimate × 12 | **৳804,000–৳2,100,000/year** |

> A practical commercial contract should explicitly state support hours, response targets, inclusions, exclusions, renewal terms, data ownership, backup responsibility, approval workflow and who controls each third-party account. Without those terms, a monthly amount alone does not guarantee service continuity.

## 6. Recommended delivery order

The first operational priority is to stabilise the public portal and its owner-only Admin, because public trust and content governance depend on those two layers. The second is to make analytics/reporting verifiable through an approved, read-only data path. The third is to recover writable source access and the official OAuth return flow for SahajControl before any cross-site control claim. Payments, sponsored placement automation and other commercial integrations should remain deferred until policy, ownership, data handling, and audit requirements are separately accepted.

| Delivery stage | Owner outcome | Acceptance evidence |
| --- | --- | --- |
| 1. Public visual and navigation release | Correct Home/tourism visuals, usable public route | Responsive visual review, source contracts, build and published read-back |
| 2. Owner workspace foundation | Clear, responsive Admin navigation without invented data | Official signed-out entry, owner-only source boundary, regression results |
| 3. Verified operational reporting | Metrics only from an approved source | Read-only data contract, empty/error state, documented origin of each metric |
| 4. Separate Control recovery | Correct independent control project path | Writable source, tested official OAuth round trip, separate release record |
| 5. Optional commercial tooling | Controlled partner/payment workflow | Approved policy, account ownership, security review and staged test evidence |

## 7. Current release evidence and remaining owner-controlled actions

The current visual release places the compact Sundarbans Royal Bengal Tiger drinking beside the river and water lily **inside the Bangladesh map card’s existing river-design panel**. The map geography and district labels remain unobscured. The clean Karnaphuli Tunnel remains in place, the Bangladesh-flag/plus cue is retained on the compact tourism entry, and the public open gallery remains compact. The public Business Directory is truthfully empty until an owner publishes a real reviewed listing; its consent-based ownership/correction requests are review-first, do not grant ownership automatically, and are never exposed publicly with applicant contact details. The public Admin entry copy correctly identifies official Manus sign-in and server-side owner verification instead of a separate site password.

Focused regression tests, full single-worker tests, TypeScript validation, production build, diff-integrity checks, signed-out public route checks, and desktop/mobile current-source visual checks were completed before the respective publications. Protected Admin content was not opened during those checks.

To activate any real analytics, payment, advertising, domain or cross-project integration later, the owner must choose the relevant service and approve the account/data scope. SahajControl and Recovery Admin remain separate projects with unavailable writable-source or owner-device evidence requirements; they were not merged into SahajContact. No credentials, PINs, OTPs, security codes, backup data, payment data, DNS changes, or private account selection are needed for the work documented here.

## References

[^1]: [Techabyte, “How Much Does Website Design Cost in Bangladesh? A Complete Guide” (updated 5 April 2026)](https://www.techabyte.xyz/how-much-does-website-design-cost-in-bangladesh-a-complete-guide/).
[^2]: [ARN TECH, “How Much Time and Money Is Needed for Website Design?” (14 August 2026)](https://arntechbd.com/blog/how-much-time-and-money-is-needed-for-website-design/).
[^3]: [ZAMAN IT public website/package page](https://zaman-it.com/), accessed 27 August 2026.
