# Legacy Dashboard Routing — 26 August 2026

## Scope

This change addresses ambiguity between the legacy public-facing `/dashboard` and `/admin` URLs and the project’s official owner-only Admin Dashboard. It does not add, restore, collect, or store a site password, OTP, PIN, biometric, security/recovery code, or secret.

## Verified behaviour

Both legacy client routes—`/dashboard` and `/admin`—now use the same small redirect component that replaces their location with `/admin/dashboard`. That entrypoint remains governed by the established official Manus OAuth and owner-only authorization boundary. A focused source-contract test confirms both redirects and the absence of prohibited custom-credential mechanisms. TypeScript, the full single-worker test suite, production build, and diff-integrity check passed for this change.

## Privacy boundary

During a visual route check, an already-authenticated private owner workspace was encountered. Inspection ended immediately. No account, personal, operational, or site-management content was opened, transcribed, retained, edited, exported, or acted on. Therefore, this note does not claim a fresh signed-out browser walkthrough; it records source and regression evidence only.

## Safe use

Use the existing official sign-in button at the owner Admin entrypoint. The route change means old `/dashboard` or `/admin` links will no longer open the ambiguous general workspace route. The platform’s official authentication remains the sole access mechanism.
