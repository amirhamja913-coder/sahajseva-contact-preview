# Bangladesh Bank Directory Research & Verification

- **Official Source**: Bangladesh Bank (Central Bank of Bangladesh) [https://www.bb.org.bd/](https://www.bb.org.bd/) [1]
- **Scheduled & Non-Scheduled Bank Directory**: [https://www.bb.org.bd/en/index.php/financialactivity/bankfi](https://www.bb.org.bd/en/index.php/financialactivity/bankfi) [2]
- **Directory Scope**: 63 Scheduled Banks and 5 Non-Scheduled Banks operating under the statutory supervision of Bangladesh Bank [2].
- **Card Requirements**:
  - Title: ব্যাংক ও আর্থিক সেবা (Bank & Financial Services)
  - Description Bn: "বাংলাদেশ ব্যাংকের ৬৩টি Scheduled + ৫টি Non-Scheduled ব্যাংকের অফিসিয়াল তালিকা"
  - Description En: "Official directory of 63 Scheduled and 5 Non-Scheduled banks under Bangladesh Bank"
  - Button: "Bangladesh Bank Directory" → `https://www.bb.org.bd/en/index.php/financialactivity/bankfi`
  - Disclaimer Bn: "সাহজসেবা লোন/ডিপোজিটের গ্যারান্টি দেয় না। লেনদেনের আগে BB তে যাচাই করুন।"
  - Disclaimer En: "SahajContact does not guarantee loans or deposits. Verify with BB before transactions."

## References
[1] Bangladesh Bank Official Portal. Available online at: https://www.bb.org.bd/
[2] Bangladesh Bank Financial Sector & Bank List. Available online at: https://www.bb.org.bd/en/index.php/financialactivity/bankfi
