# Bill-payment source audit

Date checked: 2026-08-13

## Verified official destinations

| Requested card | Verified official destination | Evidence |
|---|---|---|
| Electricity: DPDC, DESCO, NESCO | To be completed with each operator’s own official payment page or a clearly identified official bill-payment entry point | Further operator checks required |
| Gas: Titas Gas | To be completed with Titas’s own official payment page or an official bill-payment entry point | Further operator checks required |
| Water: Chattogram WASA | To be completed with CWASA’s own official payment page or an official bill-payment entry point | Further operator checks required |
| Internet: Link3, Circle, Amber IT | Amber IT official bill-pay page: https://www.amberit.com.bd/bill-pay | The page is titled “Pay Your Internet Bill Online” and links its online payment flow to https://myswift.amberit.com.bd. It also documents bKash bill-payment steps for Link3 and Amber IT. Link3 and Circle direct payment destinations still require separate verification. |
| Mobile recharge: GP, Robi, Banglalink | Grameenphone official utility-bill page: https://www.grameenphone.com/personal/services/financial-services/gpay/utility-bill-payment | The page is on the official Grameenphone domain and explains GPAY utility bill payment, including DPDC, DESCO, Titas, Chattogram WASA, and internet partners. A separate direct GP recharge page and official Robi/Banglalink recharge pages still require verification. |

## Claim-safe implementation note

The site should label these actions as **official payment/recharge destination** only when the target is the operator’s official domain or a payment portal explicitly linked by that operator. The SahajSeva site does not collect or process payment information. If a provider does not expose a stable public payment URL, the card should link to the provider’s official billing/help entry point rather than inventing a direct form URL.

## Additional operator checks

- **DPDC:** Official page `https://dpdc.gov.bd/pages/static-pages/6922dee2933eb65569e1e1bb` is titled “অনলাইন বিল পরিশোধ” and lists payment links for Visa/MasterCard, DBBL gateway/Nexus/Rocket, AB Bank, Mutual Trust Bank, Prime Bank, Southeast Bank, Islami Bank, and One Bank. The page is on the official `dpdc.gov.bd` government/operator domain. Because the page publishes multiple payment gateways rather than one single universal form, the safest card destination is this official DPDC bill-payment page.

- **NESCO:** Official customer portal `https://prepaid.nesco.gov.bd/` identifies itself as “কাস্টমার সার্ভিস পোর্টাল,” links to `https://nesco.gov.bd/`, and states it supports viewing postpaid bills and prepaid-meter recharge/usage. This is suitable as the NESCO card destination.
- **DESCO:** Official prepaid customer portal `https://prepaid.desco.org.bd/customer/` is titled “DESCO Prepaid Customer Portal | Meter Balance, Recharge and Consumption Data.” The official DESCO result also identifies `https://desco.gov.bd/` as the operator home and mentions e-bill payment. Use the prepaid portal as the direct destination for prepaid customers, with the operator home as a safer fallback if the portal is unavailable.

- **Titas Gas:** Official customer portal `https://portal.titasgas.org.bd/login` displays “Titas Gas Transmission & Distribution Company Limited” and requests a customer code and phone number. Use this official login/billing destination for the gas card; do not describe the SahajSeva page as processing the bill.
- **Chattogram WASA:** Official e-bill system `http://ebill.cwasabd.org/ebill/home.aspx` provides monthly bill, arrear bill, ledger, meter cost, bank-branch, contact, and a “Bill Pay Link” menu. It identifies itself as designed and developed by ICT Circle, Chattogram WASA. Use the e-bill home as the water-bill entry point because its exact payment link is exposed through the official menu.

- **Link3:** Official online payment page `https://selfcare.link3.net/payonline` is branded Link3, links to `www.link3.net`, asks for a customer ID, and provides a Next button. Use this as the Link3 destination.
- **Circle:** Official search result identifies `https://www.circlenetworkbd.net/pay-bill` as Circle Network’s “Pay Bill” page and describes payment through its secure self-care portal. The page returned no extractable text during this check, so retain this operator-owned URL as the destination and treat the live portal as subject to availability.

- **Robi:** Official recharge page `https://www.robi.com.bd/en/recharge` is branded “My Robi,” has Mobile Number and Amount fields, and an Add to cart action. Use this as the Robi recharge destination.
- **Banglalink:** Official recharge page `https://www.banglalink.net/recharge` is on the Banglalink operator domain and is identified in search as the official recharge entry point. The browser returned a blank rendered view during this check, so the destination should be labeled as an official Banglalink recharge page and monitored for availability.
