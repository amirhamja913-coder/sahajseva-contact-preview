# Bangladesh–India border-route source notes

**Purpose.** This is an internal implementation reference for public route cards. It is not a substitute for immigration, customs, visa, health, or travel advice. The public interface must keep a visible instruction to confirm current rules with the relevant official authorities before travel.

| Crossing pair | Verified source | Key verified statement | Intended use in public card |
|---|---|---|---|
| Benapole (Bangladesh) – Petrapole (India) | [Land Ports Authority of India: Petrapole](https://lpai.gov.in/en/icp-petrapole) | The official Indian authority identifies Petrapole–Benapole as a significant India–Bangladesh land-border crossing for trade and passenger movement; Petrapole is about 80 km from Kolkata. | Pair name, counterpart label, official link, and a cautious route-orientation note—not live operating advice. |
| Akhaura (Bangladesh) – Agartala (India) | [Land Ports Authority of India: Agartala](http://lpai.gov.in/en/icp-agartala) | The official Indian port page identifies the Agartala–Akhaura border point. | Pair name, counterpart label, and official-source link. |
| Tamabil (Bangladesh) – Dawki (India) | [Land Ports Authority of India: Dawki](http://lpai.gov.in/en/icp-dawki) | The official Indian port page identifies Dawki as a land port and notes its National Highway / Asian Highway connectivity. | Pair name, counterpart label, and source link; no unverified route timing. |
| Bangladesh passenger land-port service | [Bangladesh Land Port Authority passenger service](https://passenger.blpa.gov.bd/) | The official service exposes a traveller-facing departure/arrival land-port selector, including Benapole, Banglabandha, Burimari, and Nakugaon. | Government verification link and clear “confirm before travel” CTA. |

## Data and safety rules

1. Use only a concise Bangladesh-side locality/address line and a separately labelled India counterpart. Avoid presenting roads, hours, visa eligibility, charges, or operating status as static facts.
2. Preserve Admin edit/delete control over the public route cards. Route copy and official source URL must validate as non-empty before saving.
3. Link to official authority pages with clear labels. The user must verify current border, immigration, and port conditions directly with the authority before travelling.
4. Do not add fabricated ratings, passenger stories, endorsements, or crowd reports.
