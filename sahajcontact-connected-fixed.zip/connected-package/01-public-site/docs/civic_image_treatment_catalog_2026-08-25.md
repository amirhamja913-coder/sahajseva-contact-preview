# Civic image-treatment catalogue — 25 August 2026

## Scope

This catalogue describes only existing public imagery already referenced by SahajContact. It neither generates nor seeds substitute imagery, logos, reviews, partner marks, or civic-service outcomes.

| Public service area | Existing visual treatment | Asset/reference | Treatment distinction to retain |
| --- | --- | --- | --- |
| Bill payment guidance | Customer/payment-context illustration | `sahajcontact-bill-payment-customer` | Transaction-information context; it must not imply a live portal payment path. |
| Agriculture | Farmer-focused illustration | `sahajcontact-agriculture-farmer` | Agricultural work and rural service context. |
| Expatriate support | Family/overseas-support illustration | `sahajcontact-expatriate-family` | Family and diaspora journey context. |
| Courts and legal services | Court/justice illustration | `sahajcontact-justice-court` | Legal information context; not a promise of legal representation. |
| Women and children | Family protection illustration | `sahajseva-women-children-theme` | Safeguarding and support context. |
| Law enforcement | Public-security illustration | `sahajseva-army-security-theme` | Public safety context; no agency endorsement claim. |
| Citizen guides and local discovery | Bangladesh landscape/civic exploration illustration | `sahajseva-citizen-hills-theme` | Place and wayfinding context. |
| Media directories | Official organization sites with logos where supplied | `MediaHubSection` owner-managed entries | Directory identity is institution-specific; preserve official outbound-link labeling. |
| Bangladesh discovery hero | Scenic river image plus a separately layered Bangladesh map | Home `picture` and `BangladeshMapInteractive` | Scenic photo remains untouched; green/red treatment applies only to the map overlay. |

## Audit result

The currently referenced public section artwork is already category-specific across the principal civic groups sampled in the Home route. The visual-audit repair target is therefore not a mass asset replacement. Future artwork changes must preserve these distinctions, use approved/licensed sources, keep the parent scenic hero unmodified, and avoid fabricated public claims or partner branding.
