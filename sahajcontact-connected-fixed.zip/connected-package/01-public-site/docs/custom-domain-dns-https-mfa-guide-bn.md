# সহজ জনসেবা — কাস্টম ডোমেইন, DNS, HTTPS ও MFA গাইড

এই নির্দেশিকাটি `sahojonseba.com` বা মালিকের নির্বাচিত কাস্টম ডোমেইনকে Manus hosting-এ যুক্ত করার জন্য। এখানে কোনো পাসওয়ার্ড, OTP, পেমেন্ট তথ্য বা account secret লিখবেন না। ডোমেইন কেনা, registrar account, Manus account এবং MFA কেবল মালিক নিজে পরিচালনা করবেন।

## ১. ডোমেইন কেনা

1. মালিকের নিজের ইমেইল দিয়ে একটি বিশ্বস্ত domain registrar-এ account খুলুন বা বিদ্যমান account-এ sign in করুন।
2. পছন্দের ডোমেইন availability এবং renewal price যাচাই করুন। প্রথম বছরের offer price এবং পরবর্তী renewal price আলাদা করে দেখুন।
3. WHOIS/privacy option, auto-renew এবং domain-lock setting যাচাই করুন। ব্যবসার ডোমেইন হলে billing ও ownership email মালিকের নিয়ন্ত্রণে রাখুন।
4. পেমেন্ট সম্পন্ন করার পর invoice, registrar name, registration date, expiry date এবং ownership email-এর প্রমাণ নিরাপদে সংরক্ষণ করুন।

## ২. Manus-এ custom domain যোগ করা

1. Manus Management UI-তে এই project খুলুন।
2. **Settings → Domains** খুলুন এবং custom-domain যোগ করার অপশন নির্বাচন করুন।
3. মালিকের কেনা ডোমেইনটি লিখুন—যেমন `sahojonseba.com`।
4. Management UI যে exact DNS record, target hostname বা verification value দেখাবে, সেটি কপি করুন। এই value অনুমান করে বসাবেন না; project অনুযায়ী target আলাদা হতে পারে।
5. Registrar-এর DNS panel-এ গিয়ে Manus-এর দেখানো record যোগ করুন। সাধারণত root domain-এর জন্য A/ALIAS/ANAME অথবা `www`-এর জন্য CNAME লাগতে পারে; Management UI-র নির্দেশনাই চূড়ান্ত।
6. পুরোনো conflicting A, AAAA বা CNAME record থাকলে আগে screenshot/backup নিয়ে তারপর Manus-এর নির্দেশনা অনুযায়ী সংশোধন করুন। একই hostname-এ conflicting record রাখবেন না।
7. DNS save করার পরে Management UI-তে verification বা **Check status** চালান। DNS propagation-এ কয়েক মিনিট থেকে ৪৮ ঘণ্টা পর্যন্ত সময় লাগতে পারে।

## ৩. HTTPS এবং www/non-www পরীক্ষা

1. Domain verification সফল হলে Manus-এর Domains panel-এ HTTPS/SSL status দেখুন। Certificate active না হওয়া পর্যন্ত domain-এ customer traffic পাঠাবেন না।
2. `https://sahojonseba.com` এবং `https://www.sahojonseba.com`—দুটি address আলাদাভাবে খুলে দেখুন। কোনটি primary এবং কোনটি redirect হবে, Management UI-র canonical-domain setting অনুযায়ী যাচাই করুন।
3. HTTP address-ও পরীক্ষা করুন। সম্ভব হলে `http://` থেকে `https://`-এ redirect হচ্ছে কি না দেখুন। Browser address bar-এ certificate warning থাকা চলবে না।
4. Homepage, login/profile entry, service order, WhatsApp CTA, bill folder, expatriate folder এবং offline/PWA assets custom domain-এ খুলে দেখুন।
5. Domain বা certificate পরিবর্তনের পরে browser cache এবং service-worker cache-এর কারণে পুরোনো shell দেখা গেলে private window-তে আবার পরীক্ষা করুন।

## ৪. MFA/2FA চালু করা

1. Manus account-এর **Account/Settings → Security** অংশে যান।
2. Authenticator-app ভিত্তিক MFA/2FA চালু করুন; SMS-only recovery থাকলে authenticator backup method রাখুন।
3. Recovery codes তৈরি হলে কাগজে বা encrypted password manager-এ রাখুন। Public chat, website form, WhatsApp বা email-এ recovery code/OTP রাখবেন না।
4. নতুন device থেকে sign-in করে MFA challenge সফলভাবে পরীক্ষা করুন এবং অন্তত একটি trusted recovery path কাজ করছে কি না নিশ্চিত করুন।
5. MFA চালু করার পর project owner account, publish control, domain settings এবং version history খুলে access যাচাই করুন।

## ৫. মালিকানা ও প্রমাণ সংরক্ষণ

নিচের evidence মালিকের ব্যক্তিগত নিরাপদ storage-এ রাখুন:

| প্রমাণ | কী সংরক্ষণ করবেন |
|---|---|
| Domain ownership | registrar invoice, domain name, expiry, ownership email |
| DNS | DNS record screenshot/export এবং verification status |
| HTTPS | certificate active status এবং primary-domain redirect |
| Manus project | project name, current live URL, owner account এবং version ID |
| MFA | MFA enabled status; recovery codes নয়, শুধু নিরাপদ storage location |
| Backup | সর্বশেষ project ZIP/checkpoint এবং backup date |

প্রমাণে পাসওয়ার্ড, API key, OTP, bKash PIN, recovery code বা ব্যক্তিগত payment credential রাখবেন না।

## ৬. শেষ যাচাই তালিকা

- [ ] Domain registrar account মালিকের নিজের ইমেইলে আছে
- [ ] Manus Domains panel-এ domain verified
- [ ] HTTPS certificate active
- [ ] Primary domain এবং `www` redirect সঠিক
- [ ] HTTP থেকে HTTPS redirect কাজ করছে
- [ ] Homepage ও গুরুত্বপূর্ণ customer flows custom domain-এ কাজ করছে
- [ ] PWA manifest, service worker ও offline fallback custom domain-এ serve হচ্ছে
- [ ] MFA/2FA চালু এবং recovery path পরীক্ষা করা হয়েছে
- [ ] Invoice, DNS, HTTPS, owner এবং backup evidence নিরাপদে সংরক্ষিত

> এই ফাইলটি নির্দেশিকা মাত্র। Domain purchase, DNS change, MFA enablement বা ownership declaration বাস্তবে সম্পন্ন হয়েছে বলা যাবে না, যতক্ষণ না মালিক নিজে Management UI ও registrar-এ কাজগুলো করে যাচাই করেন।
