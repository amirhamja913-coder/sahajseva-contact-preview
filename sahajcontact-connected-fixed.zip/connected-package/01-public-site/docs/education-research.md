# Education hub source notes

The canonical five-card education hub uses official Bangladesh government destinations as its primary links. These are informational pathways only; SahajContact does not collect applications in this hub.

| Card | Official URL | Purpose |
|---|---|---|
| School Education | https://www.dpe.gov.bd/ | Directorate of Primary Education portal for primary-school information and notices. |
| Education Boards | https://www.educationboard.gov.bd/ | Bangladesh education-board information portal. |
| Madrasa Education | https://bmeb.gov.bd/ | Bangladesh Madrasah Education Board portal. |
| Certificates & Government Allowances | https://www.mygov.bd/ | Bangladesh national government-services gateway for certificate/service pathways and public benefit information. |
| Higher Education & Scholarships | https://shed.gov.bd/pages/moedu-scholarships | Secondary and Higher Education Division scholarship information page. |

Verification note: sources were checked through public web search on 2026-08-20. Government URLs can change; the Site Builder stores each URL so the owner can update it without code changes. No user-generated claims, reviews, or application forms are included.
