# Embassy research notes

Verified on 20 August 2026 from official mission pages:

| Mission | Address | Phone | Source |
|---|---|---|---|
| British High Commission Dhaka | United Nations Road, Baridhara, Dhaka 1212, Bangladesh | The GOV.UK organization page exposes the current address; emergency/contact numbers are linked through the official contact service page. | https://www.gov.uk/world/organisations/british-high-commission-dhaka |
| High Commission of India, Dhaka | Plot No. 1-3, Park Road, Baridhara, Dhaka-1212, Bangladesh | Main Reception: +880-2-55067301-308; +880-2-55067361 | https://www.mea.gov.in/indian-mission.htm?20/Bangladesh |

The public directory will link each record to its official mission website and retain a source URL. WhatsApp buttons are clearly labeled as SahajContact assistance links, not embassy-owned channels.
