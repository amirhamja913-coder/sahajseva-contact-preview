# Embassy research notes

Research date: 2026-08-20 (user timezone context).

## Primary government source
- Bangladesh Economic Relations Division: https://erd.gov.bd/pages/static-pages/694032ae35ce18e1c05606d7
- Page title: List of Mission Head with address in Dhaka / Ambassadors/High Commissioners/Heads of Agencies in Dhaka.
- Page states its data source is the relevant desk of ERD and was updated 14 May 2026.
- Extracted official-government directory facts used for initial records:
  - Australia: Australian High Commission, 184 Gulshan Avenue, Gulshan, Dhaka-1212; +88-02-58813101-5, +88 02-9604 260100.
  - Canada: High Commission of Canada, United Nations Road, Baridhara, Dhaka-1212; +88-02-8851111.
  - China: Plot 2 and 4, Embassy Road, Block-1, Baridhara, Dhaka; +88-02-9862988.
  - France: Diplomatic Enclave, Felani Ave (Madani Avenue), Dhaka; +88-02-5566860.
  - Germany: 11 Madani Avenue, Baridhara, Diplomatic Enclave, Dhaka-1212; +880 2 5566 8650.
  - India: House No. 1-3, Park Road, Baridhara, Dhaka-1212; +88-02-55067310.
  - Italy: 3rd Floor, Bays Edgewater, NE(N) 12 North Avenue, Gulshan 2 Dhaka 1212; +88-02-8822781-3.
  - Japan: Plot No. 5 & 7, Dutabash Road, Baridhara, Dhaka-1212; +88-02-2222-60010.
  - South Korea: 4 Madani Avenue Baridhara, Dhaka-1212, Diplomatic Enclave; +880-131344776 (ERD lists this as cell, plus fax).
  - Russia: House NE(J) 9, Road #79, Gulshan-2, Dhaka; +88-02-222280011. Official Russian Embassy contact page gives + (88) 02222 280011 and + (88) 01713 063027.
  - Spain: Navana Pristine Pavilion Building, 13th Floor, 128 Gulshan Avenue, Gulshan-2 Dhaka 1212; +88-02-55069744-9.
  - United Kingdom: United Nations Road, Baridhara, Dhaka-1212; +880-2-55668700 / 01713149900.
  - United States: Madani Avenue, Baridhara, Dhaka-1212; +88-02-55662000. Official U.S. Embassy page confirms Consular Section, Madani Avenue, Baridhara, Dhaka-1212 and phone (880)(2)5566-2000.

## Official source pages
- U.S. Embassy Dhaka contact page: https://bd.usembassy.gov/contact-information-for-u-s-citizens/
  - Confirms the U.S. Embassy/Consular Section address and phone; visa inquiry number shown separately as 09610202040.
- Russian Embassy Dhaka contacts: https://bangladesh.mid.ru/en/embassy/contacts/
  - Confirms address House NE(J) 9, Road 79, Gulshan-2, Dhaka-1212; embassy phones + (88) 02222 280011 and + (88) 01713 063027; consular phone + (88) 02222 281680.
- EU Delegation Bangladesh Travel & Study page: https://www.eeas.europa.eu/bangladesh/travel-study_en?s=164
  - Confirms visa information must be checked with the relevant embassy and that the EU Delegation does not issue visas. It lists official EU-member contact routes and links for France, Spain and other Schengen missions.

## Data-safety decision
This feature will store source URLs and a last-verified date alongside each embassy record. Missing or unverified WhatsApp links will remain null rather than being fabricated. Public copy will state that embassy information can change and users should verify on the official website before travel or visa action.

## Dynamic directory verification
- Browser verified the official ERD page rendered the mission table and stated it was last updated 14 May 2026; the site footer was updated 19 August 2026.
- Detailed table HTML was saved locally at `/home/ubuntu/browser_html/erd_gov_bd_694032ae35ce18e1c05606d7_1787193099024.html` for passive parsing only.
- Public records will retain the ERD directory as a source and show a verify-before-travel notice; WhatsApp remains null unless an official mission publishes a WhatsApp contact.
