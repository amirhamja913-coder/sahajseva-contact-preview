# Expatriate-service badge QA — 2026-08-14

## Scope
The five newly added expatriate shortcut cards—BMET registration, remittance-rate reference, visa-status check, remittance links, and family NID/bill support—now display an accessible Bengali `নতুন` badge. Legacy bill-payment cards and earlier service cards were not given this badge.

## Validation
- Focused shortcut regression, full Vitest suite, TypeScript validation, and production build passed.
- Desktop full-page visual capture completed at 1280×720.
- Mobile full-page visual capture completed at 375×812.
- Existing paid-assistance section remains open by default; bill-payment and expatriate shortcut folders remain collapsed by default.
- Badge styling uses the River Path saffron accent, remains compact on narrow screens, and respects reduced-motion preferences.

## Limitation
The screenshot tool verified rendered layout and responsive presentation. Actual device-level home-screen installation and outbound government-site behavior still depend on the user’s Android/iPhone browser and the external sites.
