# Verified external sources

## Bangladesh Space Research and Remote Sensing Organization

- **Organisation:** Bangladesh Space Research and Remote Sensing Organization (SPARRSO)
- **Official public website:** https://sparrso.gov.bd/
- **Verified on:** 24 August 2026
- **Use in portal:** A clearly labelled external information link in the science-project link group beside the nuclear-power-project references. It is not a SahajContact partnership or endorsement claim.
