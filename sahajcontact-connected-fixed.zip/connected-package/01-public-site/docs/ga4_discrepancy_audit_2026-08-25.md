# GA4 report discrepancy audit — 25 August 2026

## Read-only findings

The automatic refresh setting is enabled and still points to its existing scheduled task UID `DekSDWEhu3QUgM5zHFZqeP`. Its most recent stored automatic attempt, successful run, and snapshot all have the same UTC timestamp: **2026-08-24 18:26:19**. The saved error field is empty.

The automatic snapshot for `2026-08-25` is stored as the report titled **GA4 SEO daily snapshot — 2026-08-25**, with zero values for active users, sessions, page views, and total events. A separate owner-approved manual report exists from 2026-08-24 and is also zero. These records must remain distinct: neither record is evidence that the other is broken or should be overwritten.

A read-only GA4 Admin discovery request can authenticate the configured service account and enumerate non-secret property identifiers available to that account. That result does **not** prove Data API access to the selected reporting property, nor does it prove a match with the owner’s report date range, timezone, stream, or reporting view.

The public automatic-report anchor is `/#public-seo-report`. It is a navigation shortcut to the stored automatic snapshot card and does not change analytics data. A later local consolidation removes duplicate public manual/static report surfaces while retaining the stored automatic/manual records and their separate owner-side workflows.

## Current conclusion

The present evidence does not support changing the schedule, triggering it manually, changing credentials, or replacing the truthful zero snapshot with the owner-supplied August figures. A difference with Google Analytics should next be reconciled by comparing the exact GA4 **property ID**, web data stream, report date range, timezone, filters, and metric definitions in the owner’s Google Analytics interface.

## Published GA4 script smoke check

The published HTML source includes the GA4 measurement ID `G-EJQEKS80NH` and a `gtag.js` loader. A browser-console resource inspection did not return a usable result in the sandbox console, so it is **not** evidence that a collection request succeeded. This check neither changes the measurement ID nor creates data. The remaining discrepancy must therefore be assessed from the configured GA4 property's report response and the date-window alignment, not from a fabricated client-side confirmation.

## Owner-confirmed traffic property

On 25 August 2026, the owner supplied a Google Analytics property-picker screenshot that explicitly labels the traffic-bearing property as **`sahajcontact-8xyxsefc.manus.space`**, **GA4 `549836162`**, under Analytics Account **`404610002`**. A separate screenshot shows the same property’s report/realtime workspace. Therefore `404610002` is the account identifier and `549836162` is the nested GA4 Property ID; the earlier comparison against `404610002` is retained only as historical evidence of the original account/property mismatch.

With the owner’s explicit instruction to use the traffic-bearing property, the managed GA4 property setting was updated to `549836162`. No service-account JSON, private key, token, web-stream collection setting, scheduler, stored report, or public-report data was changed. Timezone, web-stream measurement ID, report date range, filters, and metric definitions still need comparison before any date-range reconciliation claim can be made.

## Permission-repair history

Before Google Analytics Property Viewer access was granted, the read-only GA4 Data API `runReport` request returned **403 `PERMISSION_DENIED`**. That historical result was the property-access blocker; it did not change an automatic snapshot, manual report, schedule, task UID, traffic-collection setting, or credential content.

The owner-only Admin Analytics panel exposes only the configured service account’s `client_email`, so the owner can use Google Analytics **Admin → Property access management** to grant Viewer or Analyst access. The panel does not return the credential JSON, private key, token, project data, property identifier, or accessible-property list. Viewer access was subsequently granted and a separate opt-in live test passed, as recorded below. The next natural scheduled refresh remains the only permitted path to create or replace an automatic public snapshot.

## Owner-session read-only check

The owner-provided Google Analytics account opened successfully on 25 August 2026, but the initially selected property showed no data stream and no traffic. No access, property, stream, report, or credential was changed. The owner must select the traffic-bearing property in the Analytics account/property picker before any permission change is considered; this prevents granting the server service account access to an unrelated empty property.

The browser session’s account/property picker did not present a selectable list to the read-only automation check. This blocks reliable identification of the traffic-bearing property in the current session. No attempt was made to add a user, change access, or infer a property identifier from the empty selection.

## Post-configuration read-only check

The explicit live credential test can authenticate the existing service account and list its non-secret accessible properties, but its small `runReport` request for GA4 Property `549836162` returns **403 `PERMISSION_DENIED`**. This confirms the remaining blocker is property access rather than a guessed account/property identifier. The owner must grant the exact owner-only Admin-panel service-account email **Viewer** or **Analyst** on GA4 Property `549836162`; no automatic refresh was triggered, and no metric was created, edited, or presented as current traffic.

With the owner’s confirmation, the Google Analytics browser session was navigated to Analytics Account `404610002` and GA4 Property `549836162`; the selected property’s Admin page loaded and exposed the **Property access management** control. No access record has yet been added or changed.

The selected property’s access-management list confirms the owner Google account is an **Administrator** and exposes the **Add access permissions to new users** control. This establishes that adding the narrowly scoped Viewer access can be performed on the confirmed traffic property; no addition had occurred at the time of this read-only check.

With the owner’s explicit confirmation, the existing service-account email was entered into the **Add roles and data restrictions** form for GA4 Property `549836162`. The **Viewer** role was selected; no restriction checkbox was selected. At this point the form is prepared for its final Add action, so the user list still does not prove that access was granted until the submission result is observed.

After the form accepted the email, it closed and the Google Analytics property-access page’s rendered user list contained the service-account address. This is consistent with the approved Viewer access being added to GA4 Property `549836162`. No higher role, data restriction, report, collection setting, schedule, secret, or other Google property was changed. A separate server-side read-only Data API check remains required to confirm the permission is effective for the reporting endpoint.

The explicit, opt-in live GA4 credential smoke test then passed both checks: a small authenticated `runReport` request for configured GA4 Property `549836162`, and the non-secret accessible-property discovery request. This establishes that the server service account can now read the selected traffic property through the GA4 Data API. The test only reads data; it does not manually run the automatic job, create an automatic snapshot, alter the stored public card, or equate the manual report with the automatic report. Date range, timezone, stream, filter, and metric-definition reconciliation still remain separate work before interpreting any historical discrepancy.

## Historic-zero snapshot diagnosis after access repair

On 25 August 2026, a read-only database query confirmed that the public automatic-report source is still the `ga4_daily_automation` record with Bangladesh day key `2026-08-25`. It was created at **2026-08-24 18:26:19 UTC**, before the GA4 Property Viewer permission repair, and stores zero active users, sessions, page views, and events. The stored scheduler health record has the same successful-run and snapshot timestamp and no error. The public `getPublicSeoSummary` endpoint reads only that latest automatic record; it does not read owner-manual reports or make an on-page live GA4 request.

The scheduled writer has been verified from source only. At each natural run it reads `getLiveGa4DashboardReport()` and then upserts one automatic record for the Bangladesh calendar day. Its project-level Heartbeat remains enabled on the unchanged cron **`0 15 18 * * *` UTC** (00:15 Bangladesh time), with the next recorded execution at **2026-08-25 18:15:00 UTC**. The job was neither manually triggered nor modified during this diagnosis.

A separate one-time, read-only live dashboard query at **2026-08-25 05:55:12 UTC** returned non-zero current aggregates: **585 active users and 677 sessions for the last 7 days**, plus **5,117 page views and 10,118 events for the last 30 days**. The query did not write a report, change the schedule, or change the public card. These values are evidence that the repaired service account can now read GA4; they are **not** a newly created automatic public snapshot and must not be presented as one.

Therefore the cause of the zero values is a historic snapshot created before the permission repair, not a missing public component or a current GA4 read failure. The next unchanged natural scheduled run is the only truthful mechanism that may replace it. Its resulting stored record and public card must be checked read-only after execution; historical date-range, timezone, web-stream, filter, and metric-definition reconciliation remain open.

## Owner-approved daily schedule amendment

After the historic-zero diagnosis, the owner expressly changed the **permanent daily** automatic-report time to **12:50 Bangladesh time**. The existing project-level Heartbeat task UID `DekSDWEhu3QUgM5zHFZqeP` was updated only to cron **`0 50 6 * * *` UTC**, whose next scheduled execution is **2026-08-25 06:50:00 UTC**. Its callback path remains `/api/scheduled/daily-seo-report-refresh`, its method remains `POST`, its payload remains empty, and it remains enabled.

The prior 00:15 Bangladesh-time schedule stated above describes the earlier diagnosis baseline; it is no longer the active daily time. No run was manually triggered during the update. The 12:50 execution must occur naturally before its Heartbeat log, stored automatic snapshot, and public card can be used to confirm a refreshed public report.

## Same-day automatic-refresh verification and current schedule

The first 12:50 Bangladesh-time execution was dispatched naturally at **2026-08-25 06:59:34 UTC** (12:59 Bangladesh time) and returned HTTP 200. Its `created: false` result means the automatic report already existed for Bangladesh day key `2026-08-25`; it does not mean that the Heartbeat failed or that a manual run occurred. A read-only database check subsequently confirmed that the existing automatic record contains non-zero GA4 aggregates. The owner’s 12:54 screenshot predates that delayed natural execution, so it correctly still showed the historic zero values.

The same-day automatic upsert originally retained the prior capture timestamp even when it refreshed the existing automatic row. This made the public freshness label look historic even after the automatic GA4 aggregates changed. A limited scheduled-writer fix now persists the current live GA4 capture time during that automatic same-day upsert, with focused regression coverage. It does not read manual reports, seed values, or create a second automatic record.

Afterwards, the owner expressly changed the **permanent daily** report time again to **13:05 Bangladesh time**. The same enabled Heartbeat UID now uses cron **`0 5 7 * * *` UTC**. Its callback path, HTTP method, empty payload, automatic-only boundary, and no-manual-trigger requirement remain unchanged. The next natural 13:05 execution must be verified through its Heartbeat log, stored automatic record, and public card before claiming final freshness or full page-level coverage.

## Latest owner-approved schedule: 14:00 Bangladesh time

The owner subsequently approved a permanent daily time of **14:00 Bangladesh time**. The same enabled Heartbeat UID `DekSDWEhu3QUgM5zHFZqeP` now uses **`0 0 8 * * *` UTC**, with the next natural execution scheduled for **2026-08-25 08:00:00 UTC**. Its `POST` callback path remains `/api/scheduled/daily-seo-report-refresh`, its payload remains empty, and no manual execution, seed, or direct database write was performed. The 12:50 and 13:05 entries above are retained only as historical schedule changes; neither is the active daily time.

The natural 14:00 execution must be read-only verified against the Heartbeat log, stored automatic snapshot, and public card. The owner-provided Google Analytics screenshots use an August-oriented view, while the automatic public snapshot currently stores active users and sessions for the last 7 days, and page views, events, and country breakdown for the last 30 days. Those different windows must be labelled and reconciled before any public claim that the figures “match.”

## Owner-provided GA4 screenshot evidence (read-only)

Two owner-provided mobile GA4 screenshots captured at 13:14 Bangladesh time show the Reports snapshot configured for **August compared with July**. The event-total card shows **10,222 events** and **5,167 `page_view` events**. Those two values match the current stored automatic snapshot's 30-day `totalEvents` and `pageViews` aggregates. The screenshots also display event names and key-event counts, but the existing daily automatic public snapshot does not collect or store event-level/key-event fields; they must not be reconstructed, estimated, or presented as automatic public data.

A third owner-provided screenshot captured at 13:13 Bangladesh time shows **937 August sessions** and **773 August active users by country**. Its leading country values are United States **432** and Bangladesh **232**, which match the stored 30-day country counts. The public snapshot's **688 sessions** and **595 active users** remain different because they are explicitly collected for the last 7 days, not the August comparison range. Traffic-source rows shown in this owner screenshot are also outside the existing stored automatic public-snapshot contract and must not be exposed as if they were collected there.

A fourth screenshot shows **779 August new users** and repeats **937 August sessions** in a channel-oriented view. New users and channel dimensions are not currently fetched, stored, or returned by the scheduled public-report pipeline. They are therefore documented only as owner-supplied diagnostic evidence, not as public automatic-report data.

## 14:00 Bangladesh-time natural-dispatch observation

At **14:20 Bangladesh time** on 25 August 2026, the enabled Heartbeat still reported `next_execution_at` as **2026-08-25T08:00:00Z** and its most recent run remained the earlier **12:59 Bangladesh-time** natural success. No 14:00 run record, response body, snapshot write, or manual trigger appeared. This is recorded as a platform-side dispatch delay, not as a failed GA4 read and not as permission to run the job manually. The existing 12:59 result remains the latest verified automatic update until a new natural Heartbeat record proves otherwise.

At **14:29 Bangladesh time**, an additional read-only Heartbeat list/log check returned the same result: the task was enabled with cron `0 0 8 * * *`, `last_executed_at` remained `2026-08-25T06:59:35Z`, and `next_execution_at` was still the past-due `2026-08-25T08:00:00Z`. The stored refresh-health record also remained successful at 12:59 with no error. No scheduler mutation, pause/resume, recreation, deletion, manual execution, or direct snapshot write was performed.

After completion of the homepage map correction, a further read-only status and execution-log check returned the same state: the 14:00 Bangladesh-time task remains enabled on `0 0 8 * * *`, the only latest successful natural run is still `2026-08-25T06:59:35Z` (HTTP 200, `is_manual_trigger: false`), and `next_execution_at` remains the overdue `2026-08-25T08:00:00Z`. There is still no 14:00 execution record. This remains a platform dispatch-delay observation only; no manual run, schedule change, pause/resume, recreation, deletion, credential change, or stored-report write was attempted.
