# Public Gallery and Footer FAQ Visual Check — 2026-08-26

The local public Home route loaded successfully after the initial skeleton. The browser reported a scrollable public page and exposed the established Home content without accessing any private Admin surface.

The updated source contracts place the public open-gallery block before the compact FAQ block, with the FAQ immediately before the existing site footer. The open-gallery component retains a single semantic `details` folder and its one-image viewer; it now includes a labelled, height-bounded `data-gallery-scroll-list` containing every available published record for selection. Existing managed image sources, legacy records, image order, and protected owner controls were not changed during this layout work.

The fixed page navigation control provides an accessible downward jump while content remains below and an upward return after scrolling. Detailed desktop/mobile screenshot review and full regression validation remain required before release.
