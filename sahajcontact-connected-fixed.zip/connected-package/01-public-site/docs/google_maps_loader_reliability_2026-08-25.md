# Google Maps loader reliability follow-up — 25 August 2026

## Evidence and scope

Recent browser-console and network-log review did not reproduce the historic Maps script-load error. The Contact page is the sole current `MapView` consumer. Its former loader could nevertheless leave a pending Promise forever when the script request failed, and concurrent map mounts could create duplicate script requests.

## Applied safe hardening

The browser-only loader now reuses one pending Promise, preserves the script element for shared use, rejects on a load failure, clears the failed Promise for a later retry, and checks that the Maps API is actually available before constructing a map. No key, proxy URL, external dependency, private location data, Maps API configuration, or third-party library was added or changed.

Contact receives the error callback and preserves a non-blocking Bengali fallback with the existing external Google Maps route. This lets people continue using the address/route action if interactive map rendering is unavailable.

## Verification

The focused static contract test passed, as did TypeScript checking. Desktop and 375-pixel phone previews show the Contact route remains readable and the map-area fallback remains a usable path rather than a blocking blank state. A historic script-load failure remains unproven; it should only be investigated further if current logs reproduce it.
