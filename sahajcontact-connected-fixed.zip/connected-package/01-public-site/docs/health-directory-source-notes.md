# Nationwide Government Hospital Directory — Source Notes

## Primary official source candidate

The DGHS Facility Registry publishes a searchable organization list with fields for organization name, Bangla name, facility agency, facility type, division, district, and upazila. It is the leading candidate for a nationwide directory because it supports geographic filtering at the required administrative levels.

- DGHS Facility Registry: https://hrm.dghs.gov.bd/public/facility-registry/reports/organization-list
- Alternative registry host / report view: https://hris.mohfw.gov.bd/public/facility-registry/reports/organization-list

## Supporting official sources

- DGHS hospital-services dashboard describes reporting categories including district/general hospitals and Upazila Health Complexes: https://dashboard.dghs.gov.bd/pages/dashboard_hospital_services.php
- DGHS facility-head contact list exposes facility examples and administrative placement, but must not be used to invent or infer missing contacts: https://old.dghs.gov.bd/dghs_website/facilityHeadContactInformation.php
- DGHS organogram resources list facility groupings, including 10-bed hospitals and Upazila Health Complexes: https://old.dghs.gov.bd/index.php/en/component/content/article/121-bengali/menu-articles/1125-organograms

## Data-safety decision

Only facility records explicitly labelled as government/public by the official registry will be included. The public UI will retain the official registry action and a last-checked notice. Missing address or phone fields will be shown as unavailable rather than guessed.

## Cross-check completed on 2026-08-22

The public Facility Registry exposes filters for government ownership, DGHS agency, facility type, division, district, and upazila, plus an Excel export action. The DGHS Hospital Services dashboard separately identifies District/General Hospital and Upazila Health Complex as hospital-service reporting categories. The directory implementation should therefore scope the primary collection to explicitly government-owned DGHS facilities in those categories, while retaining the official registry link for the complete and most current record.

## Export verification completed on 2026-08-22

An official Excel export was generated with these registry filters: Agency `DGHS` (ID 2), Ownership `Fully Government-owned` (ID 1), and facility types `District/General Hospital` (ID 28) plus `Upazila Health Complex` (ID 29). The export contained 482 records: 59 District/General Hospitals and 423 Upazila Health Complexes, covering all 8 divisions, 64 districts, and 467 upazilas. Available fields include registry ID, English/Bangla names, facility code, email, agency, ownership, type, division, district, upazila, and mobile number.

The records will be incorporated only as supplied by DGHS. The directory will not infer missing contacts or postal addresses, and it will identify the DGHS Facility Registry as the live source of record.

## Published-directory implementation contract

- The verified 2026-08-22 export is stored as a deployment-safe project asset, not as a database seed or a claim that contact details are permanent.
- The public Health folder lazy-loads that export only when a visitor opens the searchable directory. It preserves only records labelled `DGHS`, `Fully Government-owned`, and either `District/General Hospital` or `Upazila Health Complex`.
- Visitors can search by name, district, and upazila; the interface shows only a supplied mobile value and otherwise says that the export did not supply one. It does not derive addresses, availability, bed count, or emergency capability.
- The DGHS Facility Registry remains the live source of record. To refresh the directory safely, obtain a new export with the same documented filters, validate record/geographic coverage, replace the deployment asset, then rerun the focused regression test and responsive review before publishing.

## Visual verification

On 2026-08-22, the public homepage and the Health folder were visually reviewed after the searchable-directory component was added. The directory remains inside the default-collapsed Health folder, avoiding a long initial homepage load; opening it exposes the search controls and first result page only on demand.
