# Homepage layout update — 25 August 2026

## Mobile visual checkpoint

The 375×812 mobile preview rendered the header and Bangladesh interactive-map hero without a blank area or overlap. The map keeps its labelled regional interaction points and a restrained red flag-disc treatment. Following the owner’s correction, the original scenic river-and-bridge `<picture>` remains unchanged; only the Bangladesh silhouette carries the green-and-red flag-inspired treatment. Follow-up 1280×720 desktop and 375×812 phone previews show the scenic image around the map, no full-field colour layer, and a readable `ব্রাহ্মণবাড়িয়া` label on the phone layout.

## Approved content order

The code contract now places the Education hub immediately after the Law Enforcement section and immediately before Court & Legal Services. The former Bangladesh gallery card mount before the Karnaphuli Tunnel feature has been removed; the footer-adjacent open public gallery remains intact.

## Public-report anchor review

On 25 August 2026, the direct `#public-seo-report` desktop viewport resolved at the footer boundary because the report is intentionally located immediately before the footer-adjacent Gallery. The mobile full-page rendering completed without a blank page or browser failure. These captures establish route/render continuity only; public GA4 figures remain subject to the stored automatic snapshot and natural-run verification, not visual inference.
