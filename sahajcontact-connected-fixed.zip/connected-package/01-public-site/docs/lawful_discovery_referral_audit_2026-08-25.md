# Lawful search and referral readiness audit — 25 August 2026

## Scope and integrity boundary

This audit covers only legitimate discoverability: crawlable public links, indexable public routes, canonical signals, `robots.txt`, the sitemap, and context-rich outbound official sources. It explicitly excludes visitor bots, click farms, traffic injection, cross-site tracking, forced redirects, pop-ups on unrelated websites, and any referral mechanism without a user’s informed choice.

## Current site findings

| Control | Verified current state | Assessment |
| --- | --- | --- |
| Crawl access | `client/public/robots.txt` allows standard crawlers and points to the production-root sitemap. | Ready; no crawler block found. |
| Sitemap | `client/public/sitemap.xml` lists the principal public Bengali portal routes with absolute production URLs. | Ready; suitable for the current small public route set. |
| Canonical and social metadata | The public route SEO map and route synchronizer set canonical, title, description, Open Graph, and Twitter metadata for indexable public routes. | Ready; preserve the configured canonical route for each page. |
| Internal discovery | Public service search, menu links, and visible report shortcut use standard internal destinations rather than hidden redirects. | Ready; this supports meaningful navigation and crawlability. |
| External links | The established external-link policy opens external official sources in a new tab with `rel="noopener noreferrer"`; internal SahajContact routes remain same-tab. | Ready for browser security; do not add blanket `nofollow` to trusted official citations. |
| Content integrity | Public content uses claimed-safe official sources and contact-only/review-first wording. | Appropriate; no fabricated review, traffic, partnership, or outcome should be added merely to improve ranking. |

## Evidence-based next actions for the owner

Google advises that sitemaps use complete canonical URLs, can be declared through `robots.txt`, and may be submitted through the Search Console Sitemaps report; submission is a hint rather than a ranking or crawl guarantee.[1] The owner should verify the exact production property in Search Console, submit `https://sahajcontact-8xyxsefc.manus.space/sitemap.xml`, and review any processing errors.

For a few newly published or materially changed pages, the owner can use Search Console’s URL Inspection tool and request indexing. Google states that this is rate-limited, does not guarantee inclusion, and may take days or weeks; repeated requests do not speed crawling.[2] [3] Recommended first checks after the next published release are the Home page, `/ngo-partnership`, `/tv-channels`, `/newspapers`, and `/reports/august-2026`.

Google recommends crawlable `<a href>` links, descriptive anchor text, context around external sources, and meaningful internal cross-references.[4] SahajContact should therefore continue creating useful Bengali civic guidance that links naturally to its own related public pages and to genuine official sources. Any future paid placement must be clearly disclosed and qualified as `rel="sponsored"` or `nofollow` only when that relationship actually exists.[4]

## No artificial-traffic decision

No traffic-generation mechanism has been added. The portal’s next legitimate discovery signals should come from useful public content, Search Console verification, sitemap processing, honest community sharing by the owner, and voluntary links from relevant organizations that independently choose to cite the portal. Search visibility and referral traffic remain controlled by users and search engines; they cannot be safely guaranteed.

## References

[1] [Google Search Central — Build and submit a sitemap](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap)

[2] [Google Search Central — Ask Google to recrawl URLs](https://developers.google.com/search/docs/crawling-indexing/ask-google-to-recrawl)

[3] [Google Search Console Help — URL Inspection tool](https://support.google.com/webmasters/answer/9012289?hl=en)

[4] [Google Search Central — Link best practices](https://developers.google.com/search/docs/crawling-indexing/links-crawlable)
