# Live Proof Run Notes

## Admin CMS authorization check

On the live production dashboard, the owner-provided Admin password successfully opened the CMS without requiring optional Face ID/Fingerprint enrollment. The unlocked dashboard displayed editable Homepage Builder, Menu & Header Manager, Pricing Settings, real order management, and Jonosobha/News/Notice controls.

## Approved Blog publication

The owner approved a temporary live post with the title **SahajSheba Launch Test** and the content **এটি একটি টেস্ট পোস্ট। সাইট এখন লাইভ।** The post will be published through the live Admin CMS, its public URL will be recorded, and it will then be removed as instructed.

At the start of the proof run, the live Jonosobha/News/Notice list reported that no posts were present. Its editor exposes Bengali/English titles, slug, publication status, summaries, full content, optional cover/PDF fields, a pin control, and a save action.

The editor is rendered in the active production Admin route after password-session unlock. Control identifiers are being read from the rendered page before values are submitted, so unrelated CMS controls are not changed.

## Live public order-flow verification

- Live home route verified on 2026-08-21: `https://sahajcontact-8xyxsefc.manus.space/`.
- The page loaded the public service catalogue and exposed the PWA install controls, “Add to Home Screen” and “Install”.
- A clearly marked owner-authorized non-payment application was submitted using `SahajContact Test Customer` and the non-deliverable test number `01900000000`. The server-side real-order creation path ran after the service application.
- The then-live success dialog did not show the returned reference number, total, or payment status, so the visual proof could not be captured reliably. The source now renders the returned real-order summary in the success dialog and links to the public pricing summary; the next verification must be performed after this repair is published.

### Published proof after the repair

- The repair was published in checkpoint `0684733c`.
- On the published site, a new clearly marked non-payment test order was submitted with `SahajContact Test Customer` and `01900000000`.
- The public order-summary card displayed reference **SC-MT2H2O00-C6SJ**, service **Online application support**, service price **৳250**, government application fee **৳0**, total **৳250**, and payment status **Pending**.
- The proof screenshot was captured at `/home/ubuntu/screenshots/sahajcontact-8xyxsef_2026-08-21_04-52-13_9750.webp`. No payment was initiated and no funds were collected.
- The owner-authorized temporary Blog post **“SahajSheba Launch Test”** was then deleted through the published Admin dashboard. The dashboard displayed **“Notice deleted successfully.”** and confirmed that no Jonosobha post remained.

### TEST MODE release verification note

- After publishing checkpoint `ec8966e1`, the public route `https://sahajcontact-8xyxsefc.manus.space/` returned HTTP 500 twice during verification (05:58 and 05:59 on 21 August 2026).
- Production-log retrieval reported that the Cloud Run service was not found, while the local development server remained healthy. Owner-facing TEST MODE proof collection is paused until the public deployment is restored and revalidated.

### TEST MODE preview proof — 21 August 2026

- With the production route still returning a platform-level HTTP 500, the explicitly labelled TEST MODE proof was collected in the healthy project preview. It is not represented as a production payment.
- A clearly marked test order was created with reference **SC-MT2JLCVN-IW0X** and total **৳250**. The bKash **test simulation** completed with the on-screen message **“Simulation complete — কোনো টাকা transfer হয়নি।”**
- The interface truthfully showed **SMS: পাঠানো হয়নি** and **Email: পাঠানো হয়নি** because no provider keys or recipient delivery configuration exist.
- The receipt download succeeded at `/home/ubuntu/Downloads/sahajcontact-test-mode-SC-MT2JLCVN-IW0X.pdf`.
- Screenshot evidence: `/home/ubuntu/screenshots/3000-i6cccxqim3eiqjk_2026-08-21_06-03-59_2279.webp`.
- Owner-facing report: `deliverables/test-mode-payment-proof/main.pdf`. It passed strict Typst compilation and deterministic verification; visual review confirmed a readable three-page Bengali report with the no-funds disclosure, results table, captured screen, and safe next steps.
