# SahajContact Main Site Audit — 24 August 2026

## Scope and Safety Boundary

This owner-authorised audit covers public-page presentation, responsive layout, navigation, and the existing in-site owner management surface. It is an **audit record**, not a claim that every finding has been repaired. The independent Recovery Admin remains a separate, private, Phase 1 read-only deployment; its Android-Chrome sign-in redirect repair remains pending and is not changed by this audit.

No payment flow, applicant data, DNS/custom-domain setting, scheduler/GA4 configuration, credential, Control Room, restore, or Recovery Admin boundary is modified by this audit.

## First Desktop Evidence Set

Full-page desktop checks were captured for the following routes: `/`, `/bangladesh`, `/tv-channels`, `/newspapers`, `/ngo-partnership`, `/expatriate-guide`, `/blog`, and `/admin`.

| Surface | Verified strength | Audit finding | Priority |
| --- | --- | --- | --- |
| Home | The public page renders, retains the approved open Gallery, and contains service/wayfinding content. | The page is very long and visually dense, with repeated card treatments; its civic journey needs clearer grouping and stronger editorial pacing. | High |
| Bangladesh guide | The destination directory renders with image cards. | The very large repeating image-card grid is the highest visual-repetition risk and needs a service/category-aware asset and layout strategy. | High |
| TV channels | A separate television page exists with clear official-site actions. | The page uses appropriate TV-focused routing but needs a stronger feature visual so it is recognisably different from other directory pages. | Medium |
| Newspapers | A separate newspaper page exists with official-site actions. | The page is structurally sound but shares much of the same card language as TV; its newspaper identity needs a distinct editorial treatment. | Medium |
| NGO partnership | The review-first form, safety disclosures, and non-payment posture render clearly. | The content is readable; future refinement should preserve its deliberate, institutional visual distinction from public discovery pages. | Low |
| Expatriate guide | Contact/guidance content renders as cards and guidance blocks. | It needs a more deliberate service-specific visual hierarchy rather than more generic card repetition. | Medium |
| Blog | Empty state renders rather than failing. | The route is technically healthy but presently has no published updates; this is a content-state observation, not a request to fabricate posts. | Low |
| In-site Admin | The existing daily owner dashboard renders and shows owner-only operational summary. | It is intentionally distinct and functional-looking, but its labels/actions need an audit for clear edit/delete discovery on mobile and desktop. | High |

## Visual-Diversity Direction

The owner specifically reported that many design images look alike. Future visual repair must avoid near-duplicate stock-like imagery and must map visual language to service meaning.

| Service family | Intended visual category | Must avoid |
| --- | --- | --- |
| Passport / NID | travel-document, identity-verification, or border/airport context | generic civic-office card art reused elsewhere |
| Birth / registration | certificate, family-record, or registry context | passport or police imagery |
| Police / law enforcement | police-station, helpdesk, safety-route, or verified public-service context | registration/document imagery |
| Health | clinic, hospital wayfinding, health-support context | law-enforcement or travel imagery |
| Education | book, classroom, learning-route context | generic tourism landscapes |
| TV | broadcast screen, studio, channel/program visual language | newspaper masthead treatment |
| Newspapers | publication, print, editorial/newsroom visual language | TV broadcast graphics |
| Bangladesh guide | geography, landscape, heritage, and route-specific imagery selected by destination type | repeating the same scenery, crops, or card composition across every destination |

## Cross-Page Design Direction

The shared warm ivory, navy, and teal system is a viable basis. The next repair plan should use it with more discipline: one primary public name treatment, quieter navigation, more concise labels, deeper navy headings, teal for primary actions, and restrained saffron only for markers/section signals. Main public pages should use a consistent civic-wayfinding motif—such as a subtle navy route line, a teal marker, and a limited saffron signal—without turning every section into another identical card grid.

## Open Evidence Needed

1. Mobile screenshots of the same high-priority public and Admin surfaces.
2. A route/component inventory that ties each visual issue to an editable source and, where relevant, an owner Admin control.
3. A safe repair proposal before changing public visuals or adding any new assets.

## Mobile Evidence Set

The same eight routes were captured at a 375 × 812 mobile viewport after the desktop set. The pages render rather than breaking, and the mobile header condenses into theme, home, and menu actions.

| Surface | Mobile finding | Priority |
| --- | --- | --- |
| Home and Bangladesh guide | Long directory-style content is usable but highly repetitive and scroll-heavy. The Bangladesh guide especially needs categories, varied card proportions or route-grouping rather than more identical image tiles. | High |
| TV and Newspapers | Both are readable single-column card lists. Their responsive layout works, but the two pages need clearer visual differentiation from each other and from ordinary civic-service directories. | Medium |
| NGO partnership | The form remains legible at phone width and its safety notice is retained. It is a good reference for keeping substantive content readable without dense multi-column layout. | Low |
| Expatriate guide | Contact cards and guidance blocks stack correctly. The amount of repeated bordered-panel treatment remains visually heavy over a long phone scroll. | Medium |
| Blog | The empty state is readable and action-oriented. No runtime/mobile rendering defect was observed. | Low |
| In-site Admin | The owner Admin dashboard renders in a narrow single-column layout. Its primary summary and export action remain visible, but a deeper control-by-control test is still needed to confirm that gallery/content edit and delete functions are discoverable and usable on an owner phone. | High |

The mobile evidence confirms the owner’s visual concern: the core problem is not one broken screen but a repeating card-and-image pattern across long public directories. Repairs should therefore favour purposeful page architectures and controlled service-specific image categories over simply adding more image cards.

## Source and Safety Findings

The route map confirms that public information, daily owner administration, and the separate Recovery Admin have distinct roles. The main portal contains public routes for Home, Bangladesh, TV, newspapers, NGO partnership, expatriate guidance, blog, contact and policy content; the daily owner surfaces are `/admin`, `/admin/dashboard`, and `/admin/site-builder`. The separate Recovery Admin is not part of this route map and remains a private, read-only external deployment.

The visual source review found the following existing owner-editable or source-backed mechanisms: the public owner photo gallery already supports ordered uploads; the main-page manager exposes edit/delete actions for education, financial and media records; the media hub uses separate TV and newspaper feature artwork. These provide a sound base for genuine visual differentiation, provided new public service artwork is categorised rather than reused generically.

| Finding | Evidence | Required safe direction |
| --- | --- | --- |
| Repeated public card/image treatment | Long Home and Bangladesh galleries use similar rounded card forms; the image-reference scan found 95 image-related matches in 26 client files. | Use fewer generic image cards, create service-specific categories and retain owner-controlled ordering rather than inventing photos or testimonials. |
| Brand-name inconsistency | Route/UI sources include both `SahajContact` and `সহজসেবা`/`SahajSeba`. | Select one public Bengali/English naming treatment before broad visual refactoring; do not silently rewrite owner content. |
| Daily Admin scope is fragmented | `/admin` currently focuses on sponsor/service application exports, while `/admin/dashboard` and `/admin/site-builder` provide other owner controls. | Audit control discoverability as one workflow, then improve navigation/labels without weakening owner authorization. |
| Unsafe legacy payment/partner language remains | The source scan found personal bKash-payment instructions, a personal-number reference, order completion controls, and named organisation/price claims in older components and pages. | Prioritise removal or replacement with the existing contact-only, no-payment, no-unverified-partner posture. Do not collect payment data, activate a gateway, or label any organisation as a partner without verified approval. |

The safety finding must be resolved before visual polishing is presented as a final release. It is a source audit finding only; no payments, orders, applicant records, partner claims, credentials, or external settings were changed by this audit.

## Remaining Public-Route Visual Review

The desktop review of Sponsor, Advertise, Funding Guidance, NGO Partnership, Expatriate Guide, Invest Bangladesh, Investors and Contact confirms that the portal is generally responsive and no route was blank. The review nevertheless found that a number of public business-facing pages still present content that conflicts with the required cautious, review-first posture.

| Route or surface | Observed condition | Priority direction |
| --- | --- | --- |
| Sponsor page | A public “Google Analytics API connected” snapshot with prominent metrics, named country chips, hard-coded sponsorship prices and direct contact details is visually dominant. | Retain only verified analytics snapshots; remove unsupported live-connection language and demo-like/fixed commercial pricing until an approved, transparent policy exists. |
| Advertise page | The page uses a clean form, but describes a commercial invoice path and business advertising flow. | Keep it strictly an expression-of-interest form with owner review; do not promise invoice, approval, or live advertising. |
| Funding Guidance | Public cards name multiple commercial/NGO organisations in the same visual treatment as partnership guidance. | Preserve only neutral information-source labels and the explicit non-partner disclaimer; separate any organisation list from sponsorship language. |
| NGO Partnership | The page is the strongest public review-first flow: it states that an application does not create a partnership and prohibits sensitive data. | Preserve its safety language; strengthen the distinct visual identity with fewer generic cards and clearer editorial grouping. |
| Expatriate Guide | Embassy/contact and checklist layout is service-specific, but it is a long uninterrupted sequence of similarly weighted cards. | Break the flow into route-like chapters and retain only verified official contact data. Avoid payment or remittance action instructions. |
| Invest Bangladesh / Investors | Both pages use credible civic editorial structure, but contain investment/economic claims and direct enquiry calls. | Keep them informational and clearly sourced; avoid financial solicitations, return claims or transaction pathways. |
| Contact | The page already differs visually through an editorial two-column composition and owner photo, but it has multiple forms competing for attention. | Merge or clearly differentiate general feedback versus owner-service contact forms, with privacy copy visible beside each submission control. |

Across these pages, the footer/header inconsistency is visible: the public header uses `SahajContact`, while footer text and some page-level copy use `সহজ সেবা` / `SahajSeba`. This naming decision should be resolved once at the shared layout level before modifying individual page graphics. No user data was entered in any form during this read-only review.

## Source Evidence: Sponsor Page

`client/src/pages/SponsorUs.tsx` contains multiple public claims and action paths that should be removed or neutralised together rather than cosmetically hidden. These include hard-coded analytics fallbacks and a static weekly snapshot, a public “Google Analytics API Connected” label, fixed country totals, prefilled “Gold (50,000 BDT)” sponsorship interest, three fixed-price sponsorship packages, personal telephone/WhatsApp calls to action, and copyable named outreach drafts that mention Nagad, US-Bangla Airlines and BRAC.

The existing form is already server-backed, but its success text claims that an application was delivered to the founder and via SMS. Any repair must instead keep the form as a review-only enquiry, use neutral interest categories, avoid promises of contact method or outcome, remove package prices and named-partner outreach, and show public analytics only when a verified report is explicitly identified as such. This is a high-priority safety correction, not a change to live payment or a partnership claim.

## Public-Commercial Safety Remediation Verification — 2026-08-24

After the legacy public-phone, OTP, order, payment, and advertiser-control cleanup, full-page screenshots were captured for `/`, `/sponsor`, `/advertise`, `/ngo-partnership`, and `/admin` at both 1280 × 720 and 375 × 812. All five routes rendered at both sizes; no blank route was observed.

| Surface | Verified current state | Remaining follow-up |
| --- | --- | --- |
| Home | The long public directory renders after the removal of the app-built application/order interface. It now routes service actions to read-only official guidance rather than price, payment, or order completion UI. | The page remains long and card-dense; the documented visual-diversity phase remains open. |
| Sponsor | The page presents a bilingual institutional, review-first proposal and routes the formal path to NGO partnership. It states that it does not request payments or financial credentials. | Before any public registration disclosure, obtain explicit owner approval of the exact limited, non-sensitive fields that may be shown. |
| Advertise | The public page is a review-first business-collaboration explanation: it shows no rate card, invoice, payment, campaign-result, or automatic-placement control. | A future business inquiry path must stay review-only and must not promise commercial placement or collect payment data. |
| NGO partnership | The existing formal organisation inquiry form remains readable on phone and desktop, with its sensitive-data prohibition and owner-review messaging visible. | Preserve the institutional-contact scope; do not extend it into payment, identity-document, or transaction collection. |
| In-site Admin | The dashboard now labels institutional inquiries as private review records. Visible metric cards state that a published price, approved placement, and financial result are not recorded; the daily management surface remains available. | Continue the owner-control discoverability audit and retain no unsupported notification, invoice, package-price, partner, or outcome claim. |

The shared footer still visibly contains legacy direct contact details in the screenshot evidence. Those details are not used as a payment or order action in this release, but they need a separate privacy and contact-routing review before any broader business-facing rollout. The Recovery Admin remains outside this verification and its Android Chrome owner-sign-in repair remains blocked and unresolved.

## Verified Owner-Workspace and Public-Gallery Hardening — 2026-08-25

The in-site owner Admin now uses the established official account boundary only. The visible entry surface provides an official-account handoff; it does not display or collect an app-built password, OTP, biometric, Face ID, fingerprint, or passkey. Sensitive server procedures enforce the configured portal owner identity rather than accepting the retired custom-password cookie. This verification covers the public/non-owner boundary and source contracts; it does **not** claim that an authenticated owner browser session was exercised in this review.

The dashboard is now a compact owner workspace: desktop keeps a persistent section sidebar, search directs the owner to real editable controls and opens the destination work area, and mobile starts with a labelled on-demand menu. The grouped work areas—including the homepage builder—begin collapsed, preserving existing CMS, Gallery, institutional-review, edit, and delete controls without presenting invented analytics or outcomes.

The open public Gallery is the final public-content section immediately above the shared footer. It is a default-open folder-style collection with display-order serials, accessible labels, responsive grid layout, and preserved public image/open actions. No photo data was invented, removed, hidden, or moved into local project assets.

The public posture remains contact-only and review-first. No payment collection, rate card, receipt/invoice flow, payment-completion outcome, provider/merchant affiliation, or demo/test payment flow was activated. Footer contact routing now uses the portal contact page rather than a payment or order channel.

| Safety area | Verified current condition | Intentionally unchanged |
| --- | --- | --- |
| Retired custom Admin auth | Retired custom-password, audit, and biometric-claim code paths were removed from the active in-site Admin surface and router. | Legacy schema declarations remain inert; no destructive table-drop migration was generated or applied. |
| Trade-licence privacy | Owner-only record stores only a status and confirmation timestamp design. | No licence image, number, signature, address, badge, or public disclosure was added; no owner acknowledgement was recorded. |
| Infrastructure and private recovery | Compact Admin/Gallery work did not depend on external operations. | No DNS, Control Room, scheduler, GA4 configuration, credentials, applicant data, payment gateway, database data, or Recovery Admin runtime change occurred. |

The final source regression passed **107 files / 360 tests** with **2 skipped**. TypeScript and production builds passed; the build retains the pre-existing large-chunk advisory. Final desktop (1280×720) and mobile (390×844) captures covered `/admin/dashboard` and `/`; the browser-console review showed no new related error. One historic Google Maps script-load error remains separately tracked and was not changed in this release.
