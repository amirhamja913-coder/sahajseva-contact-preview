# Hero Map Correction — Visual Working Notes

## 25 August 2026: First asset check

The first generated green-and-red Bangladesh-map overlay visually retained a checkerboard rectangle in the browser preview. It therefore does **not** preserve the unchanged river-scene hero background and must not be used as the final asset.

The original 600 × 600 map reference contains a dark Bangladesh silhouette on a transparent field. A local, reproducible alpha-mask build retained the original outline and confirmed both transparent and opaque pixels. The resulting small PNG is the candidate for final browser validation; the hero’s scenic `<picture>` itself remains unedited.

## Final responsive preview

Desktop and 375 × 812 phone previews confirm that the river-and-bridge scene remains visible around the map. The green silhouette and restrained red disc are limited to the map, without a full-width or rectangular flag field. The `ব্রাহ্মণবাড়িয়া` label is present and visibly retained on the phone layout alongside a deliberately limited label set.
