# Expatriate Media Hub - Verified Official Channel Destinations

- **Category 1: News (সংবাদ)**
  - Jamuna TV: https://www.jamuna.tv/
  - Channel i: https://www.channelionline.com/
  - ATN News: https://atnnews.tv/
  - Somoy TV: https://www.somoynews.tv/
  - DBC News: https://dbcnews.tv/
  - Ekattor TV: https://www.ekattor.tv/
  - Independent TV: https://www.independent24.com/
  - News24: https://www.news24bd.tv/
  - BTV: https://btv.gov.bd/

- **Category 2: Drama / Serials (নাটক ও সিরিয়াল)**
  - NTV BD: https://www.ntvbd.com/
  - Channel i: https://www.channelionline.com/
  - Rtv Online: https://www.rtvonline.com/
  - Deepto TV: https://deepto.tv/
  - GTV (Gazi TV): https://www.gtv.com.bd/
  - Maasranga TV: https://maasranga.tv/
  - Asian TV: https://asiantvbd.com/
  - Bangla TV: https://banglatv.tv/

- **Category 3: Movies (সিনেমা)**
  - Channel i Movie: https://www.channelionline.com/
  - Rtv Movie: https://www.rtvonline.com/
  - Cinema Bangla: https://www.youtube.com/@CinemaBangla
  - Deepto Cinema: https://deepto.tv/

- **Category 4: Government (সরকারি)**
  - Bangladesh Television (BTV): https://btv.gov.bd/
  - BTV World: https://btv.gov.bd/
  - Sangsad TV: http://www.jats.gov.bd/
  - BTV Chattogram: https://chittagong.btv.gov.bd/

## Category order and logo policy

The live MySQL directory is ordered so **Amar Desh** is the first national newspaper and remains marked Prime. The news tab begins with **BTV**, followed by **Jamuna TV**, then Channel i, ATN News, Somoy TV, DBC News, Ekattor TV, Independent TV, and News24. The drama, movie, and government tabs retain the requested entries and display order.

Each channel row remains editable through Site Builder for its bilingual name, category, official URL, logo URL, description, display order, visibility, and Prime status. Where a publisher-hosted favicon was successfully retrieved, it is stored under the project lifecycle path `/manus-storage/`; when a publisher blocks or does not expose a favicon, the UI keeps the official domain favicon URL and an accessible category fallback mark rather than fabricating a logo.

### National newspaper sequence

1. Amar Desh — https://amardeshonline.com — Prime
2. Prothom Alo — https://www.prothomalo.com
3. bdnews24 — https://bdnews24.com
4. Daily Naya Diganta — https://www.dailynayadiganta.com
5. Daily Inqilab — https://dailyinqilab.com
6. Jugantor — https://www.jugantor.com
7. Ittefaq — https://www.ittefaq.com.bd
8. Kaler Kantho — https://www.kalerkantho.com
9. The Daily Star — https://www.thedailystar.net
10. BSS News — https://www.bssnews.net

### Final live TV order

The live news tab is ordered as follows: **BTV**, **Jamuna TV**, Channel i, ATN News, Somoy TV, DBC News, Ekattor TV, Independent TV, and News24. The drama/serial tab contains NTV BD, Channel i, Rtv Online, Deepto TV, GTV (Gazi TV), Maasranga TV, Asian TV, and Bangla TV. The movie tab contains Channel i Movie, Rtv Movie, Cinema Bangla, and Deepto Cinema. The government tab contains Bangladesh Television (BTV), BTV World, Sangsad TV, and BTV Chattogram.

All 35 visible rows in the five tabs have a non-empty logo URL in the live database. Project-hosted publisher logo files are preferred where available; official publisher-hosted favicon URLs remain the fallback for domains that do not expose a stable downloadable logo. No fabricated customer endorsement, review, or rating is used.
