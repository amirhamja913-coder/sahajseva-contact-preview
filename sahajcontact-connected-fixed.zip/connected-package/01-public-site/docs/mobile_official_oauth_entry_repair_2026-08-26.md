# Mobile Official OAuth Entry Repair — 26 August 2026

## Verified repair

The unauthenticated Owner Workspace control now uses the existing same-origin server-assisted official OAuth start endpoint:

```text
/api/oauth/start?returnTo=%2Fadmin%2Fdashboard
```

This replaces the former client-side navigation trigger only at the Owner Workspace entry control. The endpoint already creates the one-time OAuth state nonce, sets the short-lived cookies, and issues a top-level redirect to the official Manus sign-in page. It then returns to `/admin/dashboard` after the established callback completes.

No custom password, PIN, OTP, biometric check, security code, recovery code, cookie manipulation by the client, or new OAuth callback was added.

## Evidence

The focused owner-boundary contract and the full single-worker Vitest suite passed after the change. TypeScript checking, the production build, and `git diff --check` passed. A local header-only request to the existing official start endpoint returned `302` with the expected official sign-in location and short-lived state/return-path cookies.

### Follow-up: installed mobile/PWA navigation

The owner reported that the published mobile control still did not open the official sign-in page. Read-only inspection identified the public service-worker navigation fallback as the remaining risk: it could consume a top-level redirect before Android PWA/WebView followed the official account-selection page.

The public service-worker cache version was advanced and it now bypasses its fetch handler for same-origin `/api/`, `/oauth/`, and `/admin` paths. Those requests therefore use the browser's native network and redirect behaviour; public offline navigation remains limited to non-protected pages. Regression contracts cover the bypass ordering and the absence of custom credential collection. The existing public start endpoint was rechecked on the published domain and returned an official sign-in `302` with short-lived state and safe return-path cookies.

After the `c688d655` publication, the published `/sw.js` response was read back and confirmed the new cache version plus all three protected-navigation bypass rules. The published official start endpoint again returned the expected `302` to the official account-selection service. This is transport-level verification only; the owner must complete the normal official account selection on their own device, and no private session was inspected.

## Owner-device outcome

The owner subsequently confirmed that, after choosing the official owner email in the external account-selection flow, the owner was able to enter the SahajContact Admin dashboard. No private dashboard content, account details, settings, or data was requested, inspected, exported, or changed to establish this outcome.

## Privacy boundary

During mobile visual review, a pre-authenticated protected Owner Admin workspace appeared in the development preview. Visual inspection stopped immediately; no private account content, user data, settings, or Admin actions were opened, read, exported, or changed. The repair is therefore supported by source, regression, build, and header evidence rather than a fresh signed-out visual click-through.
