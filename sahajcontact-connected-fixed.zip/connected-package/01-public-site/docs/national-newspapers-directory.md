# National Newspapers Directory (জাতীয় পত্রিকা)

Verified official URLs for the 10 national newspapers and news wires featured in Tab 5 of the Expatriate Media Hub:

1. **আমার দেশ** (Prime Highlighted Item) — https://amardeshonline.com
2. **প্রথম আলো** — https://www.prothomalo.com
3. **বিডিনিউজ24** — https://bdnews24.com
4. **নয়া দিগন্ত** — https://www.dailynayadiganta.com
5. **ডেইলি ইনকিলাব** — https://dailyinqilab.com
6. **যুগান্তর** — https://www.jugantor.com
7. **ইত্তেফাক** — https://www.ittefaq.com.bd
8. **কালের কণ্ঠ** — https://www.kalerkantho.com
9. **The Daily Star** — https://www.thedailystar.net
10. **BSS News** — https://www.bssnews.net
