# Open Gallery Folder Review — 26 August 2026

## Source and visual findings

The Home page renders exactly one `OpenPhotoGallery` instance in its lower `#open-photo-gallery` section. The component itself contains one native default-open `<details>` folder and presents all currently published folder and legacy gallery records through a single one-image viewer plus serial selectors.

The same page separately renders `BangladeshGallery` in the established “বাংলাদেশের কিছু স্থিরচিত্র” heritage section. That is the earlier owner-required closed heritage folder, placed below the existing Padma Bridge visual, Bangladesh narrative, and public-sector links. It is not a second instance of the lower open-gallery component and must not be removed, reseeded, or merged without an explicit change to the established heritage-gallery requirement.

## Safe next decision

No image, record, source, order, or folder UI was changed in this review. If the reported two folders mean these two distinct sections, the owner needs to specify whether the preserved heritage folder should be restyled, relocated, or removed from Home; each option would change previously approved public content presentation.
