# Open Gallery Single-Folder Repair — 26 August 2026

## Scope

The repair is limited to the lower public open gallery on the Home page. The Bangladesh page and the separate preserved Home heritage gallery were not changed.

## Change

The lower `OpenPhotoGallery` had one functional native folder control but also a decorative folder-tab strip positioned directly above it. On a phone, the tab and the actual folder header could be mistaken for two folder options. The decorative outer strip and its negative-margin join were removed.

The lower gallery now has one default-open native folder surface. Inside it, the existing combined owner-published folder and legacy records remain available through the same one-image viewer, previous/next controls, and serial selectors. No gallery record, image URL, source, title, summary, order, or visibility flag was edited, deleted, reseeded, or replaced.

## Verification

Focused open-gallery, owner-boundary, and PWA OAuth regression tests passed. The full single-worker Vitest suite, TypeScript check, production build, and `git diff --check` passed. Build output retains the project’s existing large-chunk advisories only.
