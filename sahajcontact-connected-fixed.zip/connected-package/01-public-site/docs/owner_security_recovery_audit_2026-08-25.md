# Owner Security, Recovery and Privacy Audit — 25 August 2026

## Scope and non-actions

This review examined the active owner authorization, public input/upload boundaries, scheduled endpoints, and the separate Recovery Admin record. It did **not** read, upload, publish, or derive data from the private trade-licence image. It did not change DNS, Control Room, GA4 credentials, schedules, backup snapshots, restoration state, payment settings, applicant data, or the separate Recovery Admin deployment.

## Verified active boundaries

| Area | Verified boundary | Result |
|---|---|---|
| In-site Admin | Official-account authentication plus server-side `ownerOnlyProcedure` / configured-owner enforcement | Owner-only; a supplied legacy-looking admin cookie is rejected |
| Custom credentials | Active Admin flow does not contain a custom password, OTP, passkey, biometric, Face ID, or fingerprint collection surface | No application-managed credential flow claimed |
| Owner-managed links | Server validation permits bounded internal paths and `https`, `http`, `mailto`, and `tel` URLs while rejecting unsafe/control-character input | Public CMS link safety boundary is present |
| Media upload | Owner paths validate image MIME type and a 20 MB maximum before storage upload | Existing bounded file-input control is present |
| Backup/recovery | Export, snapshot, restore and reset procedures are owner-only; the separately deployed Recovery Admin remains private and read-only | No public recovery control or restore guarantee is exposed |
| Scheduled operations | GA4 and backup routes use machine-to-machine / cron authorization instead of browser-entered task identifiers | Browser callers cannot invoke the protected refresh path |

## Added low-risk hardening

The server now sends four narrow response headers before storage, OAuth, scheduled and API routes: `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `X-Frame-Options: SAMEORIGIN`, and a `Permissions-Policy` disabling camera, microphone and payment APIs. Regression coverage confirms their placement and deliberately confirms that no blanket CSP, cross-origin-isolation policy, or other potentially integration-breaking policy was introduced.

A Content Security Policy was deliberately not added in this batch. It requires a complete inventory and compatibility test for the verified OAuth, Maps, storage, analytics and external public links; an untested policy could break safe public services or owner access.

## Residual limits and owner action

The separate Recovery Admin is not evidence that the main portal, database or recovery bridge is available, and it must not be represented as such. It remains private and read-only pending its separate owner-device sign-in verification. The trade-licence privacy verification checklist also remains open by design: no file was inspected or disclosed, and any future publication requires an explicit owner decision after reviewing the minimum necessary redacted information.
