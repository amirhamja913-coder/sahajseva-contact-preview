# Payment Gateway Research — 21 August 2026

## bKash Tokenized Checkout

The verified bKash developer documentation describes a server-to-server payment sequence: obtain an access token, create a payment, redirect the customer to the returned `bkashURL`, then execute and independently verify the payment before marking an order as paid. The create request uses the merchant-provided base URL, requires `Authorization` and `X-App-Key` headers, and must carry the order amount in BDT together with a unique merchant invoice number. The payment identifier has a one-use, 24-hour execution lifecycle.

bKash also supports Instant Payment Notifications. Its documentation specifies that the merchant provides a listener URL during onboarding, and that notifications need authenticity verification before any order state is changed. The production callback and webhook listener must therefore never trust a browser redirect alone.

## Nagad

Nagad's official merchant signup page confirms that accepting payments requires a Merchant Account and onboarding. The owner has not yet supplied sandbox or merchant credentials, so no real-money processing can be enabled or demonstrated. The gateway adapter will remain in explicit sandbox-disabled state until the owner safely provides official credentials.

## Implementation Decisions

- Gateway secrets remain server-side and are never stored in browser-accessible site settings or returned by tRPC.
- Orders retain a durable provider, provider-payment ID, transaction ID, payment attempt status, and verified completion time.
- Browser callbacks display a result only after the server independently validates the provider result.
- The public UI may show bKash and Nagad as unavailable sandbox choices until credentials have been configured.
- Email and SMS delivery similarly remain opt-in and credential-gated; a failed notification cannot change a payment result.

## Sources

1. [bKash Tokenized Checkout overview](https://developer.bka.sh/docs/tokenized-checkout-overview)
2. [bKash Create Payment reference](https://developer.bka.sh/docs/create-payment-1)
3. [bKash Execute Payment reference](https://developer.bka.sh/docs/execute-payment-1)
4. [bKash Instant Payment Notification reference](https://developer.bka.sh/docs/webhooks)
5. [Nagad Merchant Sign Up](https://nagad.com.bd/en/forms/?form=be-a-merchant)
