# bKash and Nagad Sandbox Readiness

## Owner-approved scope

The owner has approved an implementation that supports **bKash and Nagad sandbox/test mode only**. The application must not process real money, use production endpoints, claim provider confirmation without provider verification, or mark an order as paid merely because a browser flow was opened.

## bKash implementation target

The target integration is bKash hosted Checkout. bKash documents Checkout as a hosted payment experience and provides webhooks for server-side transaction notifications. The application must create the payment from trusted server-side order totals and accept a completed result only after provider verification or a signed webhook.

Source: <https://developer.bka.sh/>

## Required sandbox information

Both provider integrations remain disabled until the owner supplies their provider-issued sandbox/onboarding values securely. Typical values include the sandbox base URL, merchant or app key, app secret, username/password or API credentials, callback URL requirements, and any provider-issued test wallet/customer instructions. These values must be stored only as server-side secrets; they must never be placed in client code, database records, or source control.

## Nagad implementation target

The Nagad adapter follows the same server-side contract: create a payment from the saved order total, redirect to the provider checkout only when sandbox credentials are present, validate the callback server-side, and update the order only after a provider-verified success response. Exact endpoint and signing details will be added from the merchant-issued Nagad sandbox documentation, not guessed from third-party examples.

## Notification and receipt policy

Order-status email and SMS notifications are opt-in delivery adapters. A notification failure must never change a payment status. A PDF receipt is generated from the server-calculated order snapshot and displays its payment status accurately. Until an actual provider-confirmed payment exists, every receipt remains marked **Pending / বকেয়া**.
