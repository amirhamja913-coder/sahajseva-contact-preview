# Payment Activation Research Notes

## Bangladesh Bank payment-system oversight

Bangladesh Bank explains that its Payment Systems Department regulates, licenses, and oversees payment systems. Its public overview distinguishes Payment Service Providers (PSPs), which facilitate payments or payment processes directly to customers and settle transactions through scheduled banks or financial institutions, from Payment System Operators (PSOs), which operate settlement systems such as payment gateways and aggregators. The source also states that licensing assessments consider regulatory requirements, risk management, settlement systems, and eligibility criteria.

For SahajContact, this supports a conservative product decision: do not present the existing bKash/Nagad simulation as a real checkout, do not claim payment confirmation, and do not collect or process payment credentials. A real online payment launch should use a properly authorised merchant/payment-provider route and be preceded by a separate owner decision on the final commercial, refund, privacy, and operational terms.

Source: [Bangladesh Bank, Payment and Settlement Systems](https://www.bb.org.bd/en/index.php/financialactivity/paysystems) (accessed 24 August 2026).
