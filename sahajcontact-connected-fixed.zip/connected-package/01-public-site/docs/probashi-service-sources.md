
# Probashi service source audit

Date checked: 2026-08-14.

| Requested card | Verified destination | Evidence and safe wording |
|---|---|---|
| BMET registration | https://bmet.gov.bd/ | Official Bangladesh Bureau of Manpower, Employment and Training government site. Use “BMET-এর অফিসিয়াল সাইটে আবেদন/তথ্য দেখুন” rather than claiming SahajSeva submits the application. |
| Qatar visa status | https://portal.moi.gov.qa/wps/portal/visainquiry | Official Qatar Ministry of Interior “Visa Inquiry & Printing” page. |
| Daily currency reference | https://www.bb.org.bd/en/index.php/econdata/exchangerate | Official Bangladesh Bank exchange-rate page. It publishes dated USD/BDT and cross-rate tables; display the checked date and label values as reference rates, not guaranteed remittance payout rates. |

The Saudi and UAE destinations, remittance-provider links, and family-service entry point still require final official-source checks. No live rate should be fabricated or represented as a guaranteed remittance rate.

## Additional official checks

| Requested card | Verified destination | Evidence and safe wording |
|---|---|---|
| Saudi visa status | https://www.mofa.gov.sa/en/eservices/pages/default.aspx | Official Saudi Ministry of Foreign Affairs eServices page. It describes a “Query About Visa Issued from MOFA” service; link as Saudi MOFA visa inquiry rather than claiming SahajSeva verifies the visa. |
| Dubai/UAE visa status | https://gdrfad.gov.ae/en/node/14321 | Official GDRFA Dubai “Visa Status” page identified in the official GDRFA domain; it covers verification of entry/residence permits. The UAE government also directs users to GDRFA for Dubai cases and ICP for other emirates. |

The UAE government guidance page was dynamically rendered in the browser, so the card should present the GDRFA link as an official Dubai status-check destination and retain a clear notice that the user must enter details only on the government portal.

## Remittance destinations

| Requested card | Verified destination | Evidence and safe wording |
|---|---|---|
| bKash remittance | https://www.bkash.com/en/products-services/remittance | Official bKash remittance page describing sending remittance to a loved one’s bKash account. |
| Nagad remittance | https://nagad.com.bd/services/?service=remittance | Official Nagad service page for remittance. |
| Bank remittance information | https://www.bb.org.bd/en/index.php/links/links/9 | Bangladesh Bank’s official scheduled-bank directory; use it as a directory, not as a single bank transfer form. |
| Bangladesh Bank remittance information | https://www.bb.org.bd/en/index.php/econdata/wageremitance | Official monthly wage-earner remittance data page; useful as an informational source, not a transaction endpoint. |

The site will not collect transfer credentials or claim to process remittances. Each card will route users to the relevant operator or Bangladesh Bank page and advise them to confirm fees, exchange rates, recipient details, and legal-channel requirements on the destination site.
