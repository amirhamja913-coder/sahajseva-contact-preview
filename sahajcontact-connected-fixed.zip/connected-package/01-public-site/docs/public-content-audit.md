# Public Content Audit — 21 August 2026

## Confirmed live Blog proof

| Check | Verified result |
|---|---|
| Admin workflow | An authenticated Admin session saved the owner-approved Blog post and selected the Published state. |
| Public URL | `https://sahajcontact-8xyxsefc.manus.space/blog` |
| Public title | `SahajSheba Launch Test` |
| Public body | `এটি একটি টেস্ট পোস্ট। সাইট এখন লাইভ।` |
| Public date | `২১ আগস্ট, ২০২৬` |
| Removal plan | Delete this owner-approved test post only after all requested proof has been captured. |

## Media Hub source audit
The public component keeps the owner-requested category priority: national newspapers first, then News, Drama, Movies, and Government. It sorts prime media before display order, renders a 80px Prime logo and 64px standard logos, uses channel-specific official logo URLs with a favicon fallback, and supplies Bengali/English labels for the visible section controls.

## Tourist call-to-action correction
| Language | White button copy |
|---|---|
| বাংলা | বাংলাদেশ ভ্রমণের জন্য আপনার পছন্দের স্থান বেছে নিন |
| English | Choose your preferred destination |

The white call-to-action on the homepage Bangladesh Tourist Spots section now uses the requested destination-selection wording and retains its public `/bangladesh` route.

## Live Sponsor-page language finding

- Audited URL: `https://sahajcontact-8xyxsefc.manus.space/sponsor`
- Current initial view is Bengali, as expected for the inclusive default language.
- The page contains a mix of English and Bengali labels before an explicit English-toggle check; the next validation pass must confirm a fully localized English presentation and correct any retained Bengali text.
- The browser’s explicit saved language preference was set to `EN` for the next live render test; this uses the same persistent preference pathway as the public language toggle.

## Sponsor-page bilingual correction

- **Finding:** The Sponsor page retained Bengali-only body content after the explicit English preference was selected.
- **Correction:** The page now selects separate Bengali and English render components through the shared language context. The English component retains analytics cards, sponsorship packages, partnership drafts, direct contact paths, and the secure sponsor-submission form.
- **Compile validation:** `pnpm check` passes after this correction. The updated preview will be browser-verified before publication.

## English-language visual verification

| Route | Verified English-mode result |
|---|---|
| `/sponsor` | Sponsor content, form labels, analytics cards, navigation, and shared footer render in English. |
| `/funding-guidance` | NGO, partnership, government-assistance, advertising, disclaimer, action links, navigation, and shared footer render in English. |
| `/public-guidance` | Public government-service guidance, safety steps, action links, navigation, and shared footer render in English. |

The shared footer now resolves its language from `LanguageContext` whenever a page does not explicitly pass a language override. This removes the previous Bengali-only footer behavior after an English selection.

## Homepage English-mode correction

The homepage hero accent now follows the active language preference. English visitors see: “Educate your child; bring government services within reach.” The Bengali wording remains available only in Bangla mode.
