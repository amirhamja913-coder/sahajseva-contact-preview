# Public Design Audit — 2026-08-23

## Scope and method

The first desktop visual pass inspected `/`, `/bangladesh`, `/blog`, `/contact`, `/sponsor`, `/advertise`, `/investors`, and `/invest-bangladesh`. This audit records only observed UI behavior and the implementation direction; it does not alter public data.

## Findings

| Route | Observed state | Completion direction |
|---|---|---|
| `/` | Content-rich civic directory, but very long visual rhythm and inconsistent section treatments. | Apply shared civic brand wrapper, standardized section headers, and controlled icon treatment without changing managed content. |
| `/bangladesh` | Strong destination-card coverage but an overly dark, dense card field. | Preserve destination content while creating calmer route-guidance and official-source presentation. |
| `/blog` | Clear empty state and footer; header logo is visually inconsistent with the SahajContact civic identity. | Adopt a shared neutral civic mark and consistent page shell. |
| `/contact` | Strong two-column service/form layout and readable hierarchy. | Retain layout, refine shared header and route-marker details. |
| `/sponsor`, `/advertise`, `/investors` | Dark dashboard/sales-card look, mixed blue/purple accents, and visual language inconsistent with citizen-service pages. | Normalize typography, surface treatments, and color tokens toward civic guidance; retain functional forms. |
| `/invest-bangladesh` | Best-aligned light civic surface among the sampled routes, with clear information cards. | Use as the calm surface reference for shared treatments. |

## Shared correction rules

1. The public design system will use warm ivory paper, deep navy ink, Sahaj teal, and saffron only as a small directional accent.
2. Personal/avatar imagery and magenta-framed marks will not remain the primary public brand mark; a neutral, accessible Sahaj civic mark is required.
3. Major Bengali headings should use the existing editorial display hierarchy; navigation, forms, and metadata should use a consistent Bangla-friendly sans hierarchy.
4. Page and section transitions should use a restrained route/path motif rather than repeated neon gradients, mixed glows, or dashboard-like cards.
5. Functional forms, managed data, public links, and owner-only edit paths must be preserved while visual treatment is normalized.

## Next audit pass

The remaining public routes and mobile breakpoints require the same visual and accessibility inventory before the release checklist is marked complete.

## Implementation verification note — 2026-08-23

The first post-change desktop verification confirmed the public route has retained its data-rich planning structure, and the structured border-route model is available to the page. The shared Media Hub and managed-logo-frame refinements compile. The running local browser still presents substantial legacy dark-surface styling across longer public route sections, however. The next targeted visual pass must keep the warm ivory, deep-navy, teal, and restrained saffron “নদীর পথ” system legible in both light and dark mode rather than relying on the former slate-dashboard treatment.

The subsequent narrow-mobile verification of `/bangladesh` confirmed the content stacks into a single route with image coverage, route cards, guide cards, and footer rather than exposing a blank section. The initial civic-paper override is active; the final release pass should now sample the same screen at desktop and the remaining public marketing routes before declaring the site-wide visual audit complete.

## Public civic-shell verification — 2026-08-23

The final targeted pass sampled `/`, `/bangladesh`, `/sponsor`, `/advertise`, `/investors`, and `/invest-bangladesh` at 375px wide, plus the Sponsor and Investors routes at desktop width. The shared header, Bengali-first controls, route guidance, forms, and fallback content all remained visible without a blank public panel. The public shell now pins its semantic surface tokens to warm ivory, deep navy, muted teal, and restrained saffron even when a visitor retains a dark-theme preference; this is deliberately scoped to public civic pages and does not alter Admin surfaces or the footer.

`/invest-bangladesh` received a final visual-only correction: its opening red CTA and saturated dark hero are now a light civic-paper route marker with a saffron action, while the existing navigation, share action, bilingual copy, and investment content remain unchanged. This closes the sampled public-route normalization milestone; future content additions should use the same public civic-shell classes and tokens rather than introducing dark dashboard cards.

## Unsampled public information-route pass — 23 August 2026

Desktop review of `/blog`, `/contact`, `/security-policy`, `/privacy-policy`, `/advertising-policy`, `/funding-guidance`, `/expatriate-guide`, and `/tools` found that the Blog empty state already has a complete teal civic treatment with an explicit icon and return route. Contact, policy, funding-guidance, expatriate-guide, and portions of tools remain content-complete but still present as dark dashboard surfaces. The next visual-only pass should introduce a scoped warm-paper wrapper for these information routes, preserve high-contrast alert and callout semantics, and leave all owner/Admin routes untouched.

### Contact verification and route details

After the scoped Contact update, desktop rendering preserves the route motif, message form, location map, owner-managed map photo, direct contact cards, partnership form, feedback folder, and footer while replacing the stored-dark preference surface with warm civic paper. The following route review confirms a final small normalization queue: `/security-policy`, `/privacy-policy`, and `/advertising-policy` have a readable paper body but retain a dark hero; `/funding-guidance` and `/expatriate-guide` are still dominated by slate dashboard surfaces; `/tools` already has an information-rich, icon-led card grid but should be brought onto the same light surface without changing its partner disclosure. No public route observed in this pass is blank or missing an intentional visual treatment.

### Funding and expatriate visual verification

`/funding-guidance` now uses a warm civic-paper background with accessible white content cards and retained disclosure/caution labels. Its external organisation references remain explicitly informational rather than sponsorship claims. `/expatriate-guide` now presents the verified mission directory, call links, source links, urgent-contact caution, and five guidance cards in the same palette; safety and warning cards retain distinct teal, rose, and saffron semantics. Both routes retain their public footer and no content mutation was made during this visual pass.

### Policy-route verification

The top viewport of `/security-policy`, `/privacy-policy`, and `/advertising-policy` now shares the civic-paper hero treatment: deep-navy Bengali headlines, teal route emphasis, saffron micro-markers, and a neutral paper status card. Existing owner-security advice, privacy minimisation statements, and commercial disclosure language were retained unchanged. The policy workspace remains the established paper content layout rather than a dark dashboard surface.
