# Public Activation Safety Checklist

This operational checklist helps SahajContact decide what can be publicly available without implying a payment, commercial affiliation, government approval, or verified NGO partnership that has not been established. It is not legal advice. Before accepting money or entering a formal commercial arrangement, the owner should obtain Bangladesh-specific legal and tax advice and complete the payment provider's merchant onboarding requirements.

## Safe to keep public now

| Surface | Public state | Required disclosure |
|---|---|---|
| NGO and institutional collaboration proposal | Public | An application does not establish partnership, verification, endorsement, or a public listing. |
| NGO application form | Public | Only collect necessary organisation and contact details; status remains pending until owner review. |
| Advertising and sponsorship interest forms | Public | They are enquiries subject to owner review, not a booking, payment request, or guaranteed placement. |
| Service guidance and official outbound links | Public | SahajContact provides guidance only; people must verify official fees and procedures on the responsible authority's site. |

## Must remain unavailable until formal approval and setup

| Surface | Why it must not be enabled yet | Conditions before activation |
|---|---|---|
| Payment collection, wallet transfer, card payment, or payout | A public site must not imply it can receive, hold, transfer, or confirm money without approved merchant/payment infrastructure. | Registered merchant onboarding with the selected provider; terms, refund and cancellation policy; privacy notice; support channel; tested live payment lifecycle; owner-approved accounting and tax process. |
| Personal-number payment directions | Government fees or commercial payments must not be routed through a personal account from the public site. | Replace only with a verified merchant flow or the responsible authority's official payment portal. |
| Simulated payment, test receipt, SMS, email receipt, or “paid” badge | Visitors can mistake simulation output for a real transaction or proof of payment. | Use only a real provider-confirmed transaction state and a server-side, auditable receipt flow. |
| Named payment, remittance, telecom, government, NGO, or corporate “partner” badge | It may imply endorsement or affiliation without written approval. | Written permission and independently verified public disclosure approved by the owner. |
| Public “verified NGO partner” directory | Applicant data alone is not verification. | Owner review, appropriate due diligence, written consent to publish, and an accurate description of the relationship. |

## Privacy and abuse-prevention rules

The public site must never ask a visitor to send an OTP, password, PIN, CVV, NID scan, bank login, wallet credential, or any unrelated identity document through the contact, NGO, advertising, or service forms. Forms should collect only the minimum organisation/contact details necessary for an owner review. Applicant data must remain owner-only unless the applicant provides an appropriate basis and consent for publication.

## Payment and commercial activation gate

Before enabling any payment or income workflow, the owner should confirm all of the following in writing: the exact service being sold; the authorised merchant entity and merchant account; transparent price and currency; government fee versus service fee; taxes and record-keeping; refund/cancellation process; contact/support route; privacy notice; and the provider's production acceptance criteria. A live payment status must originate from the authorised provider or a reconciled merchant workflow—not browser UI state.

Bangladesh Bank publishes public information about the national payment-system context and regulated payment activity. It should be used as an initial official reference, alongside the selected provider's merchant requirements and professional advice: [Bangladesh Bank — Payment Systems][1].

## Release review

Before a public release, confirm that no page contains `TEST MODE`, simulated payment, simulated receipt, personal-account payment instructions, unverified commercial-partner names, or an unverified government/NGO endorsement claim. Run the automated safety regression, perform a mobile/desktop visual review, and keep the public content limited to the safe-to-publish surfaces above.

## Verification record

On 2026-08-24, desktop and phone-size checks covered the Home page, the NGO Partnership page, and the Sponsor page. The NGO page showed the independent-platform disclosure, pending-review notice, and application form without public partner claims. The Sponsor page remained an enquiry/relationship surface; it did not present a payment gateway or simulated receipt. The responsive layouts remained readable in the reviewed views.

On the same date, a read-only production check of the Home page with the release query `?release=7c63709a` completed after the page loaded. The reviewed live content did not expose the removed TEST MODE payment simulation or a public bKash, Nagad, Western Union, or Grameenphone commercial-partner claim.

[1]: https://www.bb.org.bd/en/index.php/financialactivity/paysystems
