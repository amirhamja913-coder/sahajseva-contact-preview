# Public civic-service icon audit — 25 August 2026

## Scope

The visual check covered the visible civic-service cards requested for **NID**, **e-passport**, **birth/death registration**, and **police/safety** presentation. The purpose was to determine whether an actual missing visual could be repaired without inventing imagery, mimicking an official logo, or implying a government affiliation.

| Service area | Current visual treatment | Finding | Safe action taken |
|---|---|---|---|
| NID | Semantic `ClipboardCheck` interface icon with the accessible label `জাতীয় পরিচয়পত্র` | Not empty; it is a deliberately non-official visual marker. | Kept unchanged. |
| E-passport | Semantic `FileText` interface icon with the accessible label `ই-পাসপোর্ট` | Not empty; it is a deliberately non-official visual marker. | Kept unchanged. |
| Birth/death registration | Semantic `ClipboardCheck` interface icon with the accessible label `জন্ম ও মৃত্যু নিবন্ধন` | Not empty; it is a deliberately non-official visual marker. | Kept unchanged. |
| Police/safety | Semantic `ShieldAlert` interface icon with the accessible label `থানা ও নিরাপত্তা` | Not empty; it is a deliberately non-official visual marker. | Kept unchanged. |

## Evidence and boundary

The mapping is maintained in `client/src/lib/serviceBranding.ts`. Its interface contract explicitly describes these as semantic UI icons rather than official government logos. The visible service-card model has no approved `imageUrl` or image-rights field for these civic services.

Accordingly, no new passport, registration, police, government-logo, person, document, or service-result image was inserted. Adding an illustrative image later requires a verified owner-supplied asset or a safely sourced asset with recorded usage rights, neutral captioning, and no suggestion that SahajContact is the responsible government office or a service provider.

## Outcome

There is no confirmed blank or broken icon in this audit scope. The implemented public-report shortcut remains the only visual adjustment in the current report/icon phase; it identifies an existing public automatic-report section and does not display a score, estimated metric, official badge, or newly created service imagery.
