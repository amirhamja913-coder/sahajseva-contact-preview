# Public Name & Search Appearance Audit — 26 August 2026

## Read-only public evidence

On 26 August 2026, the published homepage at `https://sahajcontact-8xyxsefc.manus.space/` returned the document title **“সহজসেবা — সরকারি সেবা ও নাগরিক তথ্যের পথ”**. The loaded page header showed **“SahajContact সহজ জনসেবা পোর্টাল”** as its brand link, and the rendered footer displayed the hosting attribution **“Made with Manus”**.

Public search discovery returned the homepage with the title **“সহজসেবা — সরকারি সেবা ও নাগরিক তথ্যের পথ”** and a snippet containing **“SahajContact সহজ জনসেবা পোর্টাল”**. The same discovery search also found unrelated third-party Manus pages because `SahajContact` can match the hosting platform’s terminology; these are not controlled by this project.

Source URLs:

- `https://sahajcontact-8xyxsefc.manus.space/`
- `https://www.facebook.com/kaze.amir.hamja/posts/%E0%A6%86%E0%A6%B2%E0%A6%B9%E0%A6%BE%E0%A6%AE%E0%A6%A6%E0%A7%81%E0%A6%B2%E0%A6%BF%E0%A6%B2%E0%A7%8D%E0%A6%B2%E0%A6%BE%E0%A6%B9-%E0%A6%B8%E0%A6%B9%E0%A6%9C-%E0%A6%9C%E0%A6%A8%E0%A6%B8%E0%A7%87%E0%A6%AC%E0%A6%BE-%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%E0%A6%BE%E0%A6%B2%E0%A7%87%E0%A6%B0-%E0%A6%A1%E0%A6%BF%E0%A6%9C%E0%A6%BE%E0%A6%87%E0%A6%A8%E0%A7%87%E0%A6%B0-%E0%A6%95%E0%A6%BE%E0%A6%9C-%E0%A6%95%E0%A6%AE%E0%A6%AA%E0%A7%8D%E0%A6%B2%E0%A6%BF%E0%A6%9F%E0%A6%86%E0%A6%B8%E0%A6%B8%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%AE%E0%A7%81-%E0%A6%86%E0%A6%B2%E0%A6%BE%E0%A6%87%E0%A6%95%E0%A7%81%E0%A6%AE-%E0%A6%B8%E0%A6%AC%E0%A6%BE%E0%A6%87-%EF%B8%8F-/4472673226314234/`

## Controlled correction

The project-owned title, route metadata, public PWA name, Admin PWA name, Open Graph title, Twitter title, `application-name`, Apple web-app label, and WebSite JSON-LD now consistently use **SahajContact** with the Bengali alternate name **সহজ জনসেবা পোর্টাল**. The static canonical URL remains unchanged.

The correction intentionally does not alter visitor-facing content, analytics settings, traffic, ranking, or third-party search results. Existing public routes keep their descriptions while their controlled titles inherit the consistent site identity.

## What cannot be changed instantly

Google chooses its own result title and refreshes cached information on its own crawl schedule. Old snippets and previous titles may therefore remain temporarily even after publication. The `manus.space` host name is part of the current published address; it will remain visible in a URL until the owner connects a separate custom domain. Unrelated third-party pages that Google returns for broad `SahajContact`/Manus queries are outside this project and cannot be removed from here.

After publication, the owner can request re-indexing for the home URL in the verified Google Search Console property. No fake visits, automated searches, traffic manipulation, or false ranking claims are used or needed.

## Published crawl-signal check

On 26 August 2026, the live `robots.txt` allowed normal crawling and declared the site’s own sitemap URL. The live sitemap listed the root URL plus the current public routes, including `/about`, `/bangladesh`, `/contact`, `/public-guidance`, `/tv-channels`, `/newspapers`, and `/privacy-policy`. This confirms that the public crawl entry points are present and do not use a conflicting host.

The same published Home extraction also showed that residual *visible editorial copy* still contains older spelling variants such as `সহজকন্টেক` and `সহজকন্টাক্ট`. These are not Google title or JSON-LD fields, but they can create inconsistent brand signals. They require a limited copy audit before this checklist item can be considered fully complete.

## Limited public-label correction

The public share label and the Home heritage-gallery archive label now use the exact **SahajContact** spelling, replacing the prior Bengali transliteration in those two brand-adjacent UI locations. A focused source contract covers both labels; the full single-worker regression suite, TypeScript check, production build, and diff-integrity check passed. The broader visible-copy audit remains open because it may involve ordinary editorial wording and should not be changed indiscriminately.

Sources: <https://sahajcontact-8xyxsefc.manus.space/robots.txt>, <https://sahajcontact-8xyxsefc.manus.space/sitemap.xml>, and <https://sahajcontact-8xyxsefc.manus.space/>.
