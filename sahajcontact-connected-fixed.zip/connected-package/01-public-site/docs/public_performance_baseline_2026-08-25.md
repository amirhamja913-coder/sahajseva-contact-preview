# Public performance baseline — 25 August 2026

## Published-home response check

At the time of this read-only check, `https://sahajcontact-8xyxsefc.manus.space/` returned HTTP 200. From the sandbox connection, the initial HTML response measured **374,916 bytes**, with a time to first byte of **3.313 seconds** and total transfer time of **4.333 seconds**.

This is a single environment-specific request, not a Core Web Vitals score. It does, however, establish a real baseline showing that server/initial-document delivery deserves investigation before disabling public features or changing real Gallery assets.

The published document references the hashed application bundle `index-CH_WQVWA.js`, the stylesheet `index-B2gvCh8Y.css`, a Manus editor/dispatcher script, and a Plausible analytics script. The current publication is known to lag the uncheckpointed local source, so the final release must be measured again after the next checkpoint.

## Local release performance improvement

The Home page previously statically included the below-the-fold manual GA4 report and public Gallery. On 25 August 2026, only those non-critical modules were split from Home and mounted after the existing short idle delay. The automatic public report and its `#public-seo-report` anchor remain eager, so a direct report link remains immediately addressable. A stable `#open-photo-gallery` wrapper remains in the document while the default-open public Gallery module loads, so the footer-adjacent public section is not removed or renamed.

| Production-build output | Before | After | Result |
| --- | ---: | ---: | --- |
| Home JavaScript | 484.8 kB | 463.46 kB | 21.34 kB removed from the Home chunk |
| Home JavaScript, gzip | 84.2 kB | 81.12 kB | 3.08 kB removed from initial Home transfer |
| Deferred manual GA4 report | bundled with Home | 9.48 kB, gzip 2.36 kB | loads after idle with its small placeholder |
| Deferred public Gallery | bundled with Home | 15.65 kB, gzip 3.53 kB | loads after idle; public default-open behaviour preserved |

The 25 August local production build passed after the split. Full-page desktop and phone viewport checks confirmed that both the automatic-report anchor and the footer-adjacent Gallery still render without a duplicate section ID or visible ordering regression. The numbers above measure generated JavaScript only; they do not change the earlier environment-specific published HTML TTFB result. The next checkpointed production release should be measured afresh before drawing any Core Web Vitals conclusion.
