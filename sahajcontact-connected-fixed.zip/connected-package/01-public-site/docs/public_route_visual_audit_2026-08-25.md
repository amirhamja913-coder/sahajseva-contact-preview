# Public Route Visual Audit — 2026-08-25

## Scope and Boundary

This is a read-only visual audit of the local development preview at desktop width (1280×720). It covers the first sixteen public routes selected from the active router. It does not change content, analytics, payment, applicants, trade-licence data, DNS, scheduler configuration, credentials, or the private Recovery Admin.

## Batch 1 Findings

| Route group | Observed result | Priority |
| --- | --- | --- |
| Home | The civic portal retains its layered, information-rich landing layout and the Gallery remains a final public-content block above the shared footer. | Monitor only; Gallery position is already verified in its dedicated review. |
| Contact | Clear service-oriented two-column form, map card, direct contact information, and repeated support form are visible. The repeated form merits a later usability/content decision; no change is made by this audit. | Medium |
| Sponsor and advertise | Both routes consistently state review-first and no public rate/payment/approval claim. Their visual treatment is more editorial and distinct from the directory pages. | No safety defect observed. |
| NGO partnership and funding guidance | The application and guidance surfaces preserve review-first language. Funding guidance contains named external institutions as informational references, so future updates should keep legal/affiliation wording carefully bounded. | Medium content-governance check. |
| Expatriate guide | Dense official-contact directory and action guidance remain readable at desktop but create a very long information path. | Medium mobile and information-architecture review. |
| Invest Bangladesh | A visually distinct investment overview is present. The visible contact treatment should remain clearly informational and not imply investment advice, endorsement, or transaction capability. | Medium content-governance check. |

## Batch 2 Findings

| Route group | Observed result | Priority |
| --- | --- | --- |
| Bangladesh guide | A deep card-based destination guide is visually discoverable but has considerable vertical length. Category filters and card repetition require mobile assessment before design changes. | Medium |
| TV channels and newspapers | The two separate media directories use clear category-specific headings and ordered cards; the selected newspaper card carries a strong amber outline that improves scanning. | No layout defect observed; verify outbound destinations separately before claiming accuracy. |
| Investors | The page honestly displays the available verified snapshot and a simple inquiry form. Zero metrics are visibly labelled rather than replaced with invented data. | No fabricated metric observed. |
| Blog | An intentionally empty-state screen is displayed instead of fabricated news content. | No defect observed. |
| August report | The static owner-provided August report remains visually clear, with a prominent report date and structured metrics. It must remain distinguishable from automatically refreshed analytics. | Monitor data provenance. |
| Tools | Tool cards use strong visual variety and standard safe-outbound context. | No layout defect observed. |
| Security policy | The security page is information-dense and long but retains differentiated section styling and clear heading hierarchy at desktop. | Medium mobile readability review. |

## Interim Direction

The shared header/footer and pale civic palette provide continuity, while distinct hero treatments already differentiate partnership, commercial-review, media, tool, and investment surfaces. The priority for subsequent review is therefore **mobile readability and management discoverability**, not a blanket redesign. Any later repair must remain truthful: do not create sponsor, partner, payment, licence, review, analytics, or public-success claims without verified underlying data and explicit authorisation.

## Batch 3 Follow-up: 2026-08-26 Desktop and Phone Review

This read-only follow-up reviewed `/future-plan`, `/public-guidance`, `/security-policy`, `/privacy-policy`, `/copyright-security`, `/advertising-policy`, `/campaign`, and `/help` at 1280×720 and 375×812. It did not use Admin authentication or modify content, data, credentials, analytics, schedules, backups, recovery controls, payments, or external links.

| Route group | Desktop finding | Phone finding | Priority |
| --- | --- | --- | --- |
| Future plan, public guidance, campaign, and help | The editorial two-column hero, clear “back to Home” affordance, and non-transactional notice remain consistent. | The navigation collapses into the menu trigger; heading and supporting text remain readable without horizontal clipping. | No visual repair observed. |
| Security, privacy, and advertising policies | Separate headings and disclosure cards provide differentiated information hierarchy. | The long-form content reflows into a single readable column and retains the visible navigation controls. | Monitor content governance only. |
| Copyright and Admin security policy | Dense policy cards retain legible section headings and card boundaries. | Card text wraps within the viewport; the floating help affordance is visible but does not block the opening title. | No visual repair observed. |

The observed routes render as information-only pages and show no payment, credential-entry, recovery, or outcome-promise control in the reviewed viewport. The current practical priority remains a read-only owner-data-status review only after an official authenticated owner session is present; this audit does not attempt a login or request credentials.

## Batch 4 Follow-up: 2026-08-26 Core, Footer, and Protected-Route Review

The remaining core public routes and footer-information pages were reviewed at phone width (375×812), alongside the protected route family. The reviewed public pages retained the shared header, compact Bengali/English switch, footer navigation, readable Bengali headings, and their existing public-safety language. No empty public content state or broken navigation was observed in this read-only review.

The `/admin/dashboard` and `/admin/site-builder` source contracts wrap management UI in `AdminSecurityGate`. That gate renders only an official-account sign-in state to unauthenticated visitors and independently checks `auth.canAccessOwnerPanel` before rendering children. The visible `/admin` management summary contains only non-sensitive, zero-count and public-policy copy; it is not treated as evidence of owner access. No login, button press, credential collection, owner-data request, edit, export, cache action, database action, backup/restore action, scheduler action, or Control Room action was performed.

An unusually tall capture was observed for `/dashboard`; no claim about its detailed content is made from a scaled image. It remains in the audit backlog pending a separate high-resolution inspection.

## Privacy Stop Condition: 2026-08-26

A later desktop inspection of `/dashboard` revealed an already authenticated personal-account session in the browser preview. The audit stopped immediately: no personal details were transcribed, retained in this note, exported, edited, or acted on. The private account dashboard is outside the public-route and owner-Admin audit scope, so no further inspection will occur without an explicit user request and an appropriate authenticated-session boundary.
