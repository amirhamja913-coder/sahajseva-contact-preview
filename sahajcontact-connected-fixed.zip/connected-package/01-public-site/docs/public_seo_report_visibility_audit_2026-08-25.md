# Public SEO/GA4 report visibility audit — 25 August 2026

## Verified public navigation

The Home service-search area now contains a visible internal shortcut labelled **`স্বয়ংক্রিয় SEO ও GA4 রিপোর্ট`**. Its supporting text says that it shows only stored aggregate information and no estimated figures.

The shortcut points to `/#public-seo-report`. A browser interaction test confirmed that clicking the shortcut changes the page position toward the report section (`Pixels above viewport` moved from `0` to `1026`) while retaining the same internal fragment URL. The direct first-load fragment did not determine final scroll position because the page has substantial dynamic content above the report; normal shortcut interaction is therefore the verified navigation path.

## Integrity boundary

The update adds discoverability only. It does not change the daily job, its schedule, credentials, stored GA4 values, manual-report data, or the difference between automatic and owner-approved manual reporting. No metric, score, growth assertion, or report value was invented.

## Related visual audit

The adjacent civic-service controls render semantic service icons and labels; no empty or broken icon was identified in the audit scope. Detailed icon findings and the asset-rights boundary are recorded in `docs/public_icon_audit_2026-08-25.md`.
