# Contact and location QA notes

Date: 2026-08-20

## Desktop preview

Captured `/`, `/contact`, and `/about` at 1280x900. The Contact and About surfaces render without layout errors. The shared footer shows the centered English Admin identity: `Name: Kazi Amir Hamja` and `Title: Entrepreneur, SahajContact`. The homepage office section is present in the long page capture with the Tiara Bazar address, actionable contact details, and embedded map container.

## Mobile preview

Captured `/`, `/contact`, and `/about` at 390x844. The public layout stacks cleanly, the footer identity remains centered and readable, and the contact/about cards fit the narrow viewport. The homepage office grid uses a responsive auto-fit layout and the map iframe has a fluid width with a minimum height, so it remains usable on mobile and desktop.

## Validation status

- TypeScript check: passed.
- Owner contact regression: 3 tests passed.
- Production build: passed.
- Visual QA: desktop and mobile captures completed.

## Remaining release work

Regenerate the secret-free archive and final PDF deliverables, then save a checkpoint after reviewing `todo.md`.

## Final homepage capture

After the homepage office block was added, `/` was recaptured at 1280x900 and 390x844. Both captures completed successfully. The section is mounted in the homepage flow and the responsive card layout remains intact at both widths; the map container uses the same fluid responsive treatment as the Contact page, while phone and email remain represented as actionable contact cards.
