# Media, Section Logo, and Address QA Notes

Date: 2026-08-20

## Current verified findings

- The live media directory contains 10 national newspapers, with Amar Desh at display order 1 and marked as Prime.
- The news category begins with BTV at display order 1 and Jamuna TV at display order 2.
- The live records expose official URLs and logo URLs for the audited media entries; some use project-storage logo URLs and some retain publisher-hosted favicon URLs as fallbacks.
- The tourist planner currently renders the large Tourist Guide emblem and includes bilingual Address/ঠিকানা fields for land-port cards, falling back to the location field when an address is unavailable.
- The production build completed successfully and the homepage desktop preview rendered successfully.
- A full-page screenshot attempt failed, while a lightweight homepage viewport capture succeeded. Full-page capture needs no further action unless a later visual regression requires it.

## Remaining verification

- Confirm all five media tabs and complete requested inventory from the database in compact category-specific queries.
- Confirm mobile layout and the education/bank section emblem rendering.
- Add or update regression assertions, mark verified checklist items, refresh the secret-free backup, and save the final checkpoint.

## Mobile visual QA

The 375px mobile previews rendered successfully for both `/` and `/bangladesh`. The Tourist Guide emblem is visible inside the hero without overflow, and the planner’s search/filter controls remain horizontally scrollable and usable. The homepage remains readable with the existing Bengali default language; the English-toggle behavior is covered by the existing language tests and will be rechecked in the final suite.
