# SahajContact remaining-work reconciliation — 25 August 2026

## Decision basis

The remaining checklist was reviewed against the current main-project source, the public route registry, the completed map release, and the strict safety boundaries. Items were separated by whether they can be completed from the current project without changing credentials, schedules, payment state, private owner access, or data held in a separate project.

| Group | Remaining work | Dependency | Next handling |
| --- | --- | --- | --- |
| Independent, highest priority | Complete the evidence-based public/Admin visual audit and catalogue distinct, real image treatments by civic category. | Main-project source and existing owner-managed media only. | Continue now, without generating or inventing public imagery, reviews, institutions, or outcomes. |
| Independent, conditional | Remove any legacy public/Admin payment or named-partner language that the audit actually finds. | Source evidence is required. | Search and repair only genuine remaining instances; preserve the review-first/no-payment posture. |
| Evidence-led follow-up | Historic Google Maps script-load error. | A reproducible current browser/log error is required; credentials and private location data are out of scope. | Inspect only if current evidence reproduces the fault. |
| Owner-confirmation blocked | Public institutional-registration disclosure. | Owner must specify the limited non-sensitive fields permitted for publication. | Do not infer or publish a licence, address, number, signature, or identity field. |
| Platform/external-service blocked | GA4 natural-run reconciliation. | Heartbeat dispatch must occur naturally; manual execution and schedule mutation remain prohibited. | Read-only verify after a natural run; do not seed data or claim reconciliation early. |
| Separate-project blocked | Private Recovery Admin mobile sign-in and owner callback repair. | Source/deployment control for the separate private project and an owner-device verification path. | Keep private/read-only boundary intact; do not modify the main portal as a workaround. |

## Media-directory diagnosis

The phone screenshot showed the initial `isLoading` branch while the request was in flight. Read-only log review showed a successful `getTravelContent` response, and a direct browser verification of `/tv-channels` rendered all published card data and official links. Therefore, no persistent media-directory defect was reproduced and no data, link, or rendering code was changed. The transient capture state is documented rather than misrepresented as a user-facing failure.

## Immediate safe work order

The next independent batch is to complete the main public/Admin visual audit and catalogue existing image treatment overlap. Only evidence-backed styling or navigation repairs will be proposed. Any item requiring private owner confirmation, a natural scheduled execution, or the separate Recovery Admin source remains pending.
