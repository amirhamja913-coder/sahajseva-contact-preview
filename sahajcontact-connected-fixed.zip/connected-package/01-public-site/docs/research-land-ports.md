# Official land-port research notes

Source: https://blpa.gov.bd/
Accessed: 2026-08-20.

The official Bangladesh Land Port Authority homepage identifies the authority as Bangladesh Land Port Authority and exposes an official passenger-facilities portal with a departure/arrival-port selector. The page currently lists passenger charge payment and links to official land-port systems, including the Passenger Facilities Charge portal and ISLAS. The official site also confirms that the authority manages the country’s land-port operations and shows current notices for ports including Burimari and operational updates for other ports.

Related official source discovered: https://passenger.blpa.gov.bd/ — Bangladesh Land Port Authority Passenger Facilities Charge portal; its departure/arrival-port selector includes Benapole and Banglabandha among the available ports.

Related official source discovered: http://slp.blpa.gov.bd/burimari/ — official Burimari Land Port portal.

Implementation implication: public route cards should show the Bangladesh-side port location/address as a clear location field, link users to the official BLPA/port portal where available, and use a bilingual disclaimer that schedules, immigration, visa, and transit requirements must be verified with BLPA, Bangladesh immigration, and the relevant Indian authority before travel. Do not invent street-level addresses when an official source only publishes district/upazila/port locality; use the verified locality-level address instead.

## Official BLPA verification — 20 August 2026

Sources consulted:

- Bangladesh Land Port Authority homepage: http://blpa.gov.bd/
- BLPA office profile: http://blpa.gov.bd/pages/office-contents/6922d89d933eb65569df9347
- BLPA passenger facilities portal: https://passenger.blpa.gov.bd/

The BLPA homepage states that 24 land ports have been declared, 21 currently exist, and 17 are operational. It identifies 12 under BLPA management: Benapole, Burimari, Akhaura, Bhomra, Nakugaon, Tamabil, Sonahat, Gobrakura–Karaitali, Belonia, Sheola, Dhanua–Kamalpur, and Bholaganj. Five are operated under BOT arrangements: Sonamasjid, Hili, Banglabandha, Teknaf, and Bibirbazar. The same page lists closed ports including Daulatganj, Tegamukh, and Chilahati, and records development or suspended-operation statuses for Ramgarh, Biral, Darshana, and Balla.

The BLPA office profile publishes the authority address as F-19/A, Sher-e-Bangla Nagar (opposite GTCL Bhaban), Agargaon, Dhaka-1207, Bangladesh; telephone +88-02-41025348; email chairman@blpa.gov.bd; website www.blpa.gov.bd. The passenger portal currently exposes Benapole, Banglabandha, Burimari, and Nakugaon as passenger facilities. These sources support displaying port locality/status and an official BLPA verification link; they do not publish one single street address for every individual port in the extracted content, so individual cards should avoid inventing street-level addresses and should label locality plus official verification link where necessary.
