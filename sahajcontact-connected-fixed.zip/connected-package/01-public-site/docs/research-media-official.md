
## Official media verification notes

- **BTV:** https://btv.gov.bd/ opened successfully as the Bangladesh Television government portal. The page title identified it as বাংলাদেশ টেলিভিশন and exposed BTV, BTV News, and BTV Chattogram destinations.
- **Jamuna TV:** https://www.jamuna.tv/ resolved to the active Jamuna TV news portal. Automated browser rendering encountered a captcha, but the extracted page contained current Jamuna TV news sections and confirmed the domain as the publisher destination. Keep the official URL and use a graceful image fallback if the site blocks remote logo requests.
- **Logo implementation note:** The current database stores favicon URLs for newspapers. These should be replaced or supplemented with stable colorful official logo assets/URLs where possible; the UI must keep a fallback mark so a blocked remote logo never leaves a blank card.

## Requested media source register

The media hub source list is maintained in `docs/media-hub-channels.md`. Television destinations include BTV (`https://btv.gov.bd/`), Jamuna TV (`https://www.jamuna.tv/`), Channel i (`https://www.channelionline.com/`), ATN News (`https://atnnews.tv/`), Somoy TV (`https://www.somoynews.tv/`), DBC News (`https://dbcnews.tv/`), Ekattor TV (`https://www.ekattor.tv/`), Independent TV (`https://www.independent24.com/`), News24 (`https://www.news24bd.tv/`), NTV (`https://www.ntvbd.com/`), Rtv (`https://www.rtvonline.com/`), Deepto TV (`https://deepto.tv/`), GTV (`https://www.gtv.com.bd/`), Maasranga (`https://maasranga.tv/`), Asian TV (`https://asiantvbd.com/`), Bangla TV (`https://banglatv.tv/`), and the government destinations BTV Chattogram (`https://chittagong.btv.gov.bd/`) and National Parliament (`http://www.jats.gov.bd/`).

Newspaper destinations are recorded in `docs/national-newspapers-directory.md` and the live database currently contained the requested ten entries in the required order: Amar Desh, Prothom Alo, bdnews24, Daily Naya Diganta, Daily Inqilab, Jugantor, Ittefaq, Kaler Kantho, The Daily Star, and BSS News. Amar Desh was already marked Prime and display order 1.

Image-search results were treated as visual references only, not as authoritative data sources. The live UI therefore uses publisher-hosted favicon/logo URLs with a visible fallback mark rather than copying third-party image-search assets. Relevant reference results included BTV and Jamuna logo imagery, but their third-party hosting should not be treated as official ownership evidence.
