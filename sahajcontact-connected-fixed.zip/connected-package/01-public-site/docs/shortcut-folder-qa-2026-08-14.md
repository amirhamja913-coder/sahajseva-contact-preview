# Shortcut folder QA — 2026-08-14

## Scope

The existing “আমরা যা করে দেবো” paid-assistance section must remain open by default. Only the newly added “বিল পে করুন ঘরে বসে” and “প্রবাসী সেবা – Proudly Bangladeshi” sections should be collapsed folders, closed by default.

## Automated checks

- `server/shortcutSections.test.ts`: 5 tests passed.
- TypeScript validation: passed.
- Production build: passed.

## Visual checks

- Desktop full-page capture at 1280×720 completed successfully.
- Mobile full-page capture at 390×844 completed successfully.
- The River Path card layout remains present, and the shortcut sections are visually compact in the page flow.
- No visual overflow or build-time rendering error was reported by the managed preview.

## Implementation notes

- The bill and expatriate sections use native `details` elements without `open`, so they are closed by default and keyboard-accessible through their `summary` controls.
- The paid-assistance section uses `details open`, preserving its previous open-by-default behavior.
- Existing service entries remain in the paid-assistance catalog; online-application assistance is explicitly labeled and includes transparent service-charge wording.

## Remaining verification

A final interaction check should confirm opening and closing each folder in the live preview, followed by the publish checkpoint.

