# Standalone Admin Dashboard: নিরাপদ Recovery Architecture

## উদ্দেশ্য

এই নকশার উদ্দেশ্য হলো SahajContact-এর public website থেকে পৃথক একটি **owner-only Admin Dashboard app** তৈরি করা। এটি public frontend-এর কোনো সমস্যা হলে owner-কে আলাদা address থেকে emergency status, recovery guidance এবং অনুমোদিত control surface দিতে পারে। এটি public visitor-এর জন্য নয় এবং কোনো অবস্থাতেই owner data বা applicant data প্রকাশ করবে না।

> একটি আলাদা dashboard কেবল তখনই বাস্তবে স্বাধীন হবে, যখন সেটি আলাদা deployment ও আলাদা URL-তে চলবে। একই server-এর অন্য route বা একই deployment-এর “copy” main server পুরোপুরি অচল হলে কাজ করবে না।

| স্তর | বর্তমান অবস্থা | Recovery-safe নকশা |
|---|---|---|
| Public site | একই SahajContact deployment-এ React frontend ও server | আলাদা public deployment হিসেবে থাকবে |
| Owner access | বর্তমান owner-only tRPC middleware, request/session ও database-নির্ভর | নতুন app-এ আলাদা owner sign-in boundary লাগবে |
| Content/data controls | একই server API ও MySQL-backed data helpers ব্যবহার করে | মূল backend সচল থাকলে সীমিত, authenticated recovery API ব্যবহার করবে |
| Full server outage | Dashboard-এর backend/API-ও অপ্রাপ্য হতে পারে | জরুরি status, recovery instructions ও non-secret recovery kit দেখা যাবে; data mutation দাবি করা হবে না |

## বাস্তব সীমা

বর্তমান Admin Dashboard-এর সংবেদনশীল operations owner-only middleware দিয়ে রক্ষা করা হয় এবং সেই middleware চলতে request/session ও project backend প্রয়োজন। তাই original backend বা database অনুপলব্ধ থাকলে আলাদা app-এর জন্য একই live data edit করা নিরাপদ বা সত্যনিষ্ঠভাবে সম্ভব নয়। এই অবস্থায় “সব control চলবে” বলা হবে ভুল প্রতিশ্রুতি এবং data conflict তৈরি করতে পারে।

Public website-এর frontend error হলেও যদি server API ও database সচল থাকে, standalone app authenticated recovery API-এর মাধ্যমে সীমিত admin actions দিতে পারবে। কিন্তু server/database outage হলে app কেবল incident status, last-known non-sensitive recovery notes এবং owner-facing next steps দেখাবে। DNS, credentials, payments, Control Room, database restore বা scheduler mutation এই app স্বয়ংক্রিয়ভাবে করবে না।

## প্রস্তাবিত ধাপে বাস্তবায়ন

প্রথম ধাপে আলাদা managed deployment-এ একটি owner-only Recovery Admin app তৈরি হবে। এতে secure sign-in, public-site/API health indicator, incident checklist, last-verified release reference এবং non-secret recovery guidance থাকবে। এই ধাপের উদ্দেশ্য হলো main public UI ভেঙে গেলেও owner যেন আলাদা address-এ গিয়ে সঠিক অবস্থান বুঝতে পারেন।

দ্বিতীয় ধাপে, কেবল server API availability check সফল হলে, allowlisted read-only status ও controlled content-management actions যোগ করা যেতে পারে। প্রতিটি mutation-এর জন্য strong owner authorization, audit trail, bounded input validation এবং optimistic UI-এর বদলে confirmed server response ব্যবহার করতে হবে।

তৃতীয় ধাপে, owner যদি আলাদা database/API availability এবং backup/restore policy অনুমোদন করেন, তখন recovery workflow আরও বিস্তৃত করা যেতে পারে। এই ধাপেও full backend outage-এ live content edit সম্ভব বলে বলা হবে না; বরং recovery runbook ও backup handoff থাকবে।

## Deployment requirement

এই বর্তমান SahajContact project-এর ভেতরে route যোগ করলে তা আলাদা app নয়। সত্যিকারের পৃথক access-এর জন্য একটি **দ্বিতীয় managed web project/deployment** এবং আলাদা public address প্রয়োজন। নতুন app তৈরি হলে একই production database-এ direct credential sharing করা হবে না; minimal, server-side, owner-authorized recovery interface ব্যবহার করা হবে।

## নিরাপত্তা নীতি

Recovery app-এ কোনো password, OTP, database URL, private API key, owner personal details, NGO applicant data, payment credential বা backup archive public bundle-এ রাখা যাবে না। Public UI-তে কোনো “system fixed”, “always available”, “payment active” বা “partner verified” ধরনের যাচাইহীন দাবি থাকবে না।

## বর্তমান সংরক্ষণ ও যাচাই নোট

২০২৬-০৮-২৪ তারিখে main portal-এর uncheckpointed Gallery repair-এর source, regression, TypeScript, production build এবং desktop/mobile full-page preview পুনরায় যাচাই করা হয়েছে। Mounted `PremiumPhotoGallery` component-এ default-open folder, visible folder state, serial labels এবং existing owner-managed ordering বজায় আছে। এই record কেবল source/preview verification; এটি কোনো production recovery-control claim, analytics claim, schedule change, credential operation বা user-data mutation নয়।

একই তারিখে `sahajcontact-recovery-admin` নামে দ্বিতীয় managed project তৈরি হয়েছে (project ID: `YVKLMvMcaNFdneBJSow3XA`)। এটি মূল SahajContact project/deployment থেকে পৃথক project boundary; recovery app-এর source, owner access boundary এবং public address পরবর্তী implementation ও publication verification-এর পরে আলাদাভাবে নথিভুক্ত হবে।

Recovery app implementation task ID `zmK6QCcXdbxEmTdlgAM2oT` একই পৃথক managed project-এ শুরু হয়েছে। অনুমোদিত প্রথম ধাপটি owner-only, read-only recovery console পর্যন্ত সীমিত: shared bridge status প্রাথমিকভাবে `not configured`; main backend/database অনুপলব্ধ অবস্থায় mutation, automatic restore বা recovery success-এর কোনো দাবি থাকবে না।

Independent build preview endpoint: `https://3000-i5xvkrp3gw3eh8ckq638l-bb1ddd89.us4.manus.computer/`। এটি build-in-progress preview মাত্র; public recovery address, checkpoint identifier এবং deployment verification প্রকাশের পরে এই architecture record-এ আলাদাভাবে যোগ করতে হবে।

## Deployment ও private-access verification — ২০২৬-০৮-২৪

Phase 1 Recovery Admin deployment এখন `https://sahajreco-b7rzpksq.manus.space/`-এ আলাদা app হিসেবে চালু হয়েছে। এটি সাধারণ public access বা discovery-এর জন্য নয়; deployment visibility restricted/invited owner-only access হিসেবে নির্ধারিত। Login ছাড়া console data দেখা যায় না।

Owner sign-in boundary যাচাইয়ে একটি configuration defect ধরা পড়ে: configured owner account-এর sign-in সফল হলেও published app-এর server-side owner comparison তখনও `FORBIDDEN` ফেরত দিচ্ছিল। তাই app-টি সম্পূর্ণ usable বলা হয়নি এবং owner authorization repair task একই পৃথক project-এ অনুমোদিতভাবে চালু করা হয়েছে। Repair-এর scope কেবল configured owner match সঠিক করা, non-owner/unauthenticated denial অক্ষুণ্ণ রাখা, focused test পুনরায় চালানো এবং Phase 1-এর read-only safety boundary বজায় রাখা।

এই অবস্থাতেও কোনো main-project database credential, secret, OTP, NID, applicant data, backup archive, recovery bridge, mutation, DNS control, payment action, scheduler action বা automatic restore প্রকাশ/সংযুক্ত করা হয়নি। Repair সফল হওয়ার পর owner dashboard access, non-owner denial, private visibility এবং read-only outage semantics পুনরায় যাচাই না হওয়া পর্যন্ত অপারেশনাল control claim করা যাবে না।

## Repaired private release verification — ২০২৬-০৮-২৪

Owner-authorization repair শেষে পৃথক Recovery Admin-এর server-side configured-owner comparison boundary whitespace-safe normalizationসহ সংশোধন করা হয়েছে। পৃথক project-এর repair record অনুযায়ী configured owner এখন `recovery.status` read-only procedure-তে অনুমোদিত; unauthenticated caller এবং authenticated non-owner admin উভয়ই denied থাকে। Focused access-control coverage (৯টি test), TypeScript, production build, desktop/mobile visual review, controlled owner smoke check এবং console audit সম্পন্ন হয়েছে।

Management UI-তে deployment `Published` হলেও visibility/access area থেকে এটি private/restricted owner-only configuration হিসেবেই রাখা হয়েছে। আলাদা addressটি public marketing/discovery link হিসেবে কোথাও যোগ করা হয়নি। Live endpoint-এ unauthenticated অবস্থায় কোনো recovery status বা console data প্রকাশের বদলে owner sign-in boundary দেখা যায়।

Phase 1 এখনো কেবল read-only। এটি নিজে চলমান আছে—এই তথ্যকে main public site, main API, shared database বা কোনো recovery bridge সচল থাকার প্রমাণ হিসেবে ব্যবহার করা যাবে না। Main public-site status এবং recovery bridge panel উভয়ের সঠিক অবস্থা `not verified`/`not configured`; কোনো content edit, delete, restore, DNS, payment, Control Room বা scheduler action নেই।

## Owner sign-in loop investigation — ২০২৬-০৮-২৪

Owner একটি repeated security-code/loading loop-এর কথা জানানোর পর live private endpoint read-only ভাবে পুনরায় দেখা হয়েছে। Unauthenticated Recovery Admin screenটি শুধু “মালিক হিসেবে সাইন ইন করুন” action দেয়; app UI-তে কোনো password, OTP, security code বা recovery code input নেই। ওই action-এর গন্তব্য হলো Manus-hosted account-selection page: `https://manus.im/app-auth` (redirect URI: `https://sahajreco-b7rzpksq.manus.space/api/oauth/callback`), যেখানে কেবল configured Amir Hamja account বা “Use another account” বিকল্প দেখা যায়।

অতএব reported code promptটি Recovery Admin app-এর নিজস্ব credential collection বলে প্রমাণিত নয়; তা provider-side account/session verification বা post-callback session completion-এর সঙ্গে সম্পর্কিত হতে পারে। Owner sign-in completion flow আলাদাভাবে repair ও verify না হওয়া পর্যন্ত owner-কে code পুনরায় না দিতে বলা হয়েছে। কোনো code/OTP/password সংগ্রহ, সংরক্ষণ বা এই নথিতে লেখা হয়নি।

## Owner sign-in completion repair — ২০২৬-০৮-২৪

Owner-reported loop-এর জন্য পৃথক repair task `DXCD4DuXsNF1yPPeGXBMLj`-তে client-side auth completion flow সংশোধন করা হয়েছে। এর আগে auth-status fetch-এ `SERVER_ERROR` এলে UI সেটিকেও sign-in failure ধরে নতুন provider redirect শুরু করত; ফলে callback-এর পরে একই flow ঘুরে যাওয়ার ঝুঁকি ছিল। এখন প্রথম authenticated-state resolution চলাকালে কেবল সত্যিকারের unauthenticated response-এ একবার sign-in redirect অনুমোদিত, এবং server-side error হলে auto-redirect না করে safe retry/error state দেখানো হয়।

Repair task-এর record অনুযায়ী focused auth-flow tests, TypeScript validation, production build, desktop/mobile review, controlled owner smoke check এবং console audit সম্পন্ন হয়েছে; private deployment-এ নতুন checkpoint প্রকাশিত হয়েছে। App UI এখনও password, OTP, security code বা recovery code সংগ্রহ করে না, এবং shared main-project data/control surface যোগ করা হয়নি। Provider-side account/session verification স্বতন্ত্রভাবে চলতে পারে; তাই বাস্তব owner device-এ একবার re-test প্রয়োজন, কিন্তু পুনরাবৃত্ত code prompt বা loading loop দেখলে user-কে আবার code না দিয়ে বের হয়ে যেতে বলা হয়েছে।

সর্বশেষ live reproduction-এ private Recovery Admin থেকে official Manus account-selection boundary পর্যন্ত redirect হয়েছে; এই পর্যায়ে app-side code field বা app-generated error দেখা যায়নি। Owner device-এ access failure এখনো পুনরুৎপাদনযোগ্য হওয়ায় live callback/session persistence, browser state এবং private visibility configuration আলাদাভাবে diagnose না করা পর্যন্ত repair-কে user-verified successful বলা যাবে না।

Read-only endpoint probe-এ provider parameters ছাড়া `/api/oauth/callback` সরাসরি খুললে প্রত্যাশিত HTTP 400 পাওয়া গেছে; এটি একা fault প্রমাণ করে না, কারণ authorization callback-এ provider-issued parameters ও state প্রয়োজন। তাই পরবর্তী diagnosis-এ valid owner callback/session completion এবং client-side rendered state আলাদাভাবে যাচাই করতে হবে।

2026-08-24 live reproduction: official owner account নির্বাচন করার পর browser আবার `https://sahajreco-b7rzpksq.manus.space/`-এ ফিরেছে, কিন্তু UI এখনও “মালিক হিসেবে সাইন ইন করুন” card দেখিয়েছে—dashboard, explicit denial, বা app-side code field দেখায়নি। ফলে current blocking defectটি provider selection নয়; callback/session persistence অথবা client auth-state hydration failure হিসেবে treat করতে হবে। Owner-only boundary দুর্বল না করে এই server/client contract repair প্রয়োজন।

Follow-up endpoint probe: the same browser session received HTTP 200 from the recovery deployment’s typed `auth.me` endpoint with `authenticated: true`, while the rendered UI continued to show the sign-in card. This narrows the defect to client-side session consumption, query-key/data-shape handling, or stale deployment assets—not an absent provider session. The app must be repaired to consume only the existing server assertion and must not add a custom credential or code collection path.

2026-08-24 owner re-test: the owner reopened the private Recovery Admin using a cache-bypassing query string (`?refresh=20260824b`). The supplied mobile screenshot confirms that the non-blank landing screen rendered and showed only the normal “মালিক হিসেবে সাইন ইন করুন” action; the owner did not enter any security code, and the app displayed no app-side code field. This is evidence that the observed blank landing-screen symptom was consistent with stale browser-cached client assets rather than a requirement for an app-collected credential. It is not, by itself, evidence that the post-sign-in owner dashboard rendered, so that protected-flow validation remains open. The Recovery Admin must continue to use the normal private owner sign-in boundary; it must not request, store, or transmit any password, OTP, security code, or recovery code.

Independent read-only checks on the same date returned the expected Recovery Admin sign-in landing content from both the normal address and the cache-bypassing address. Browser interaction was stopped by a provider CAPTCHA before any sign-in action, so no CAPTCHA was bypassed and no owner session was exercised in that check. The returned landing content matches the owner screenshot: a read-only Phase 1 notice and a single owner sign-in action, with no app-side password, OTP, or security-code field. This supports the finding that the deployment serves a non-blank landing response; it does not replace a successful owner post-sign-in dashboard verification.

## Owner sign-in button no-response diagnosis — ২০২৬-০৮-২৪

Landing screen খোলার পর owner জানান যে “মালিক হিসেবে সাইন ইন করুন” button চাপলে mobile device-এ কোনো দৃশ্যমান navigation বা account-selection page খোলে না। এটি blank landing issue থেকে আলাদা blocking defect; তাই owner-কে পুনরায় চাপতে, code দিতে, বা কোনো credential পাঠাতে বলা হয়নি।

Published bundle-এর read-only inspection-এ button-এর `onClick` handler এবং official `https://manus.im/app-auth` redirect construction উপস্থিত পাওয়া গেছে। Normal address ও `?refresh=20260824b` address একই hashed JavaScript asset reference করে; উভয় HTML response-এ `no-cache, no-store, must-revalidate` policy আছে। ফলে query string কোনো বিকল্প server-side bundle বাছাই করে না। Handler redirect দেওয়ার আগে `crypto.randomUUID()` দিয়ে OAuth state nonce তৈরি করে; কিছু পুরোনো বা embedded mobile browser context-এ API-টি অনুপস্থিত হলে এই প্রথম line-এই silent runtime failure হতে পারে। এটি compatibility hypothesis, নিশ্চিত root cause নয়।

নিরাপদ repair scope হলো আলাদা Recovery Admin source-এ platform-compatible nonce generation fallback এবং visible, non-sensitive error/retry state যোগ করা, তারপর supported mobile browser-এ single-click redirect regression test চালানো। এতে owner-only server authorization, official provider sign-in, Phase 1 read-only restriction, এবং কোনো password/OTP/security-code collection অপরিবর্তিত থাকবে।

Owner-এর দ্বিতীয় supplied screenshot-এ address bar ও Chrome controls দৃশ্যমান; অর্থাৎ একই no-response failure আর কেবল embedded preview-window hypothesis নয়, Android Chrome session-এও পুনরুৎপাদিত হয়েছে। Button-টি visible pressed/focus state পেয়েছে, কিন্তু official account-selection page-এ navigation হয়নি। তাই mobile sign-in click repair ও real Android Chrome redirect verification এখন আবশ্যক, এখনও অসম্পন্ন কাজ হিসেবে রাখা হয়েছে।

### 2026-08-24 — পৃথক project repair সাময়িক বাধা

Source-level repair পাঠানোর সময় বর্তমান main-project Forge credential দিয়ে prior separate-task follow-up endpoint অনুমোদিত হয়নি; ফলে এই main workspace থেকে পৃথক Recovery Admin source/deployment পরিবর্তন করা যায়নি। এরপর official Manus management endpoint read-onlyভাবে খুললে scheduled maintenance notice দেখিয়েছে যে access 2026-08-25 08:00 SGT-তে resume হবে (বাংলাদেশ সময় 06:00)। এই বাহ্যিক maintenance চলাকালে repair publish, private deployment পুনরায় খোলা, অথবা user-device retest সম্পন্ন হয়েছে বলে কোনো দাবি করা হয়নি।

সূত্র: `https://manus.im/maintenance` (2026-08-24 read-only check)।
