# Tourism Image Visibility Audit — 26 August 2026

## Scope

This was a read-only inspection of the public `/bangladesh` route and the existing `tourist_places` records. No tourism record, storage object, gallery image, or publish state was edited.

## Findings

The read-only database query returned **57 visible tourism records**. Existing records retain either a primary `imageUrl`, a `galleryJson` list, or both. For example, the first ordered record has no primary image URL but retains three managed `/manus-storage/` gallery images; the following ordered record retains both a managed primary image and gallery images. The dataset also contains older external Wikimedia image references.

Desktop (1280 px) and phone (375 px) full-page reviews of the current development route rendered a populated multi-card tourism gallery with image thumbnails rather than a page-wide placeholder state. This indicates that the reported prior disappearance is not reproducible in the current public rendering path. The next safe change should therefore preserve every existing record and make the requested Bengali heading clearer, rather than deleting, replacing, or reseeding tourism images.

## Follow-up Boundary

Any future repair must use the existing owner-managed image URLs or gallery metadata only. It must not fabricate substitute tourism images, overwrite verified records, or change external-source records without owner review.

## Implemented Presentation Clarification

The white discovery card now begins with the clear Bengali page heading **“বাংলাদেশকে ঘুরে দেখুন”**, followed by the retained contextual line **“বাংলাদেশকে জানুন, অনুভব করুন”**. A desktop (1280 px) and phone (375 px) visual review confirmed that the heading is readable, the card remains white, and the existing tourism gallery continues to render below it without record changes.

## Verified Gallery and Folder Repair

The public gallery renderer now retains the complete de-duplicated union of the existing primary `imageUrl` and every valid `galleryJson` URL. The former six-image display cap has been removed; no tourism record, image URL, storage object, gallery order, or visibility flag was edited. The first image loads eagerly, later existing images retain lazy loading, and each image remains reachable through tap-visible previous/next controls and keyboard-focusable image selectors. The counter reports the full retained image total for each place.

The `/bangladesh` white discovery box is now a native default-open disclosure folder. It preserves both Bengali headings, presents a CSS-rendered Bangladesh flag with accessible text, and includes a labelled tourism-folder treatment with the expanded-state indicator. Closing and reopening the box is available through the semantic summary control without hiding it from keyboard users. Desktop 1280×720 and phone 375×812 visual reviews confirmed the flag, folder cue, opening state, and responsive card rendering. Focused source-contract regression, TypeScript, full single-worker regression (**114 passed test files, 387 passed tests; 1 file / 4 tests skipped**), production build, and whitespace diff integrity checks passed. The existing production build’s chunk-size advisory remains non-blocking.

## Follow-up: Previous Image Visibility

The owner reported that older images inside **“বাংলাদেশকে জানুন, অনুভব করুন”** were still not apparent. A new read-only sample confirmed that visible records retain their earlier managed `galleryJson` items in object form alongside optional cover images. To make those existing images visible at a glance rather than only reachable as carousel dots, every multi-image card now includes a labelled horizontal thumbnail folder strip. Each thumbnail is the original image URL, visibly numbered, keyboard-focusable, and selects that exact image in the main viewer. This follow-up adds no image source, record, storage object, gallery order, or database write. Updated 1280×720 desktop and 375×812 phone full-page reviews both show the per-card thumbnail strips beneath the primary views.
