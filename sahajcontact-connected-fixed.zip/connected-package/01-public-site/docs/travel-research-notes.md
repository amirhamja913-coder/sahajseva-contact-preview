# Travel research notes

## Source 1: Bangladesh Tourism Board
- URL: https://tourismboard.gov.bd/
- Accessed: 2026-08-20.
- The official board site identifies tourism-board services including tourist operators, tour guides, tourism accommodation, tourism transportation, tourism master planning, tourism publications, and research reports. It also displayed an official notice related to Tanguar Haor and links to the Bangladesh Tourism Board registration portal.

## Source 2: Bangladesh High Commission, London — Tourism in Bangladesh
- URL: https://bhclondon.org.uk/tourism-in-bangladesh
- Accessed: 2026-08-20.
- The High Commission’s public Bangladesh information area links to the Ministry of Civil Aviation and Tourism, Bangladesh Parjatan Corporation, Tourist Attraction, Picture Gallery, Tourist Entertainment, Transportation, Tour Operators, and Accommodation facilities.

## Data policy
- Tourist records should use real named destinations and bilingual descriptions, not fabricated reviews or testimonials.
- Each destination should have a cover image plus a small gallery with provenance captured in the seed notes or source documentation.
- Embassy records must retain official mission website URLs, source URLs, phone/address fields, and a last-verified date.

## Image-source handling

Wikimedia’s [Common thumbnail sizes](https://www.mediawiki.org/wiki/Common_thumbnail_sizes) page states that direct thumbnail requests must use standard production widths such as 20, 40, 60, 120, 250, 330, 500, 960, 1280, 1920, or 3840 pixels. The asset preparation workflow therefore uses the 960px standard variant rather than manually constructed 800px or 1200px thumbnail URLs, while preserving each Commons file page as the attribution/source URL.
