# SahajContact visual audit — 25 August 2026

## Scope and method

This is an evidence-led first pass, not a claim that every route has been redesigned. The public route registry was reviewed from `client/src/App.tsx`. Full-page desktop and phone-sized previews were captured for the Home, Contact, Sponsor, Advertise, Investors, Bangladesh tourism, TV Channels, Newspapers, and owner Admin entry surfaces.

## Confirmed strengths

The Contact, Sponsor, Advertise, Investors, and owner Admin entry views render without a blank screen on both sampled widths. The mobile header collapses to a menu control rather than horizontally overflowing. Sponsor and Advertise retain the published review-first/no-payment language, and the owner Admin summary correctly shows empty data rather than inventing outcomes.

The first two desktop audit batches also rendered the principal Home, Blog, investment, tourism, media, future-plan, public-guidance, security, privacy, copyright, and advertising-policy public routes. The TV and newspaper directories showed their published official-site cards. The information pages displayed real empty states where no public update exists, rather than placeholder claims. No broken navigation or blank public route was reproduced in these batches.

The third desktop batch rendered the funding, NGO partnership, expatriate guide, tools, campaign, help, complaint, and about routes. The NGO form labels its submission as owner review and does not promise funding or placement. The expatriate and tools pages label external resources and official-source checks. However, the public About page contains a named individual and title, while the funding guide names third-party organizations in illustrative card groups. Their factual/current disclosure status cannot be inferred from a screenshot, so neither has been altered.

The phone audit initially exposed a public `/expatriate` 404 while the registered guide route was `/expatriate-guide`. A backward-compatible alias now renders the same approved Expatriate Guide content at both locations. Focused route-contract testing and phone full-page previews verified the alias; neither the guide content nor any external-service boundary changed.

The final desktop public batch rendered the four About narrative pages plus Careers, Supplier, and Merchant. The About narrative uses a clear problem → solution → impact → partnership sequence and routes users to the portal Contact page instead of a personal channel. Careers, Supplier, and Merchant truthfully show no active opening/programme/marketplace and do not simulate an operational business flow. With the earlier batches, every currently registered public route has now been previewed at least once at desktop or phone size; the sole reproduced route defect was the resolved `/expatriate` alias gap. The owner Admin dashboard remains protected by official-account authorization, so only its public entry/unauthenticated boundary—not private authenticated controls—was visually audited.

## Confirmed repair candidates

| Priority | Evidence | Safe next action |
| --- | --- | --- |
| Resolved | Phone previews initially captured “মিডিয়া তালিকা লোড হচ্ছে...” while the desktop captures rendered directory cards. | Read-only logs showed a successful content response and direct browser verification rendered the published directory. This was a transient initial-fetch capture, not a reproduced user-facing defect; no data or link was changed. |
| Medium | The Home route is substantially longer than the focused information pages, making its primary civic paths less discoverable on a phone. | Audit the Home section sequence and only then propose a scoped navigation/content-density repair; preserve already approved map, service order, Karnaphuli placement, Gallery, and report work. |
| Medium | Header/footer use the English product label `SahajContact` while much of the public copy uses Bengali `সহজ সেবা`. | Inventory existing brand assets and owner-managed settings before altering public identity; do not replace the live logo with an unverified or generated mark. |
| Medium | Many directory cards share a similar visual treatment despite different service categories. | Catalogue real existing assets and map each public service category to a distinct approved image strategy, without fabricating reviews, outcomes, or partner claims. |
| Owner confirmation required | `/about` presents a named individual and title; `/funding-guidance` displays named third-party organizations. | Obtain confirmation of the exact public identity/organizational-disclosure scope, source basis, and desired wording before any alteration or expanded claim. |

## Boundaries retained

No change in this audit touches private Recovery Admin access, payment, DNS, personal/applicant data, trade-licence material, GA4 credentials, GA4 collection, or the automatic-report schedule. The visual evidence alone does not prove an API failure; the media-directory state requires targeted diagnostics.
