# যাচাইকৃত গণমাধ্যম গন্তব্য

## আমার দেশ

২৩ আগস্ট ২০২৬-এ owner-reported ভুল outbound destination যাচাই করা হয়েছে। `https://www.dailyamardesh.com/`-এর public footer-এ “স্বত্ব: ©️ আমার দেশ” এবং `info@dailyamardesh.com` উল্লেখ আছে; তাই public news portal-এর matching destination হিসেবে এই URL ব্যবহৃত হয়েছে। সংশ্লিষ্ট e-paper URL `https://eamardesh.com/` আলাদা ডিজিটাল সংস্করণ হলেও Home-এর জাতীয় পত্রিকা record-এর জন্য সাধারণ public news portal URL রাখা হয়েছে।

| Record | আগের URL | যাচাইকৃত URL | Source |
|---|---|---|---|
| আমার দেশ / Amar Desh | `https://amardeshonline.com` | `https://www.dailyamardesh.com/` | [দৈনিক আমার দেশ](https://www.dailyamardesh.com/) |

এই verification কেবল matching owner-managed record-এর outbound destination সংশোধনের জন্য। এটি কোনো endorsement, ranking, media record সৃষ্টি, অথবা অন্য পত্রিকার link পরিবর্তন বোঝায় না।
