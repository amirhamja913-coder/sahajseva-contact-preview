# 2026-08-23 Public Visual Validation Notes

- The rendered Home document places the `#law-enforcement-services` section before the Home Media directory.
- The Media directory rendered immediately after that section begins with the TV Channels entry and includes the separate Newspaper Portal entry.
- The Home service-card markup renders stored service artwork with a permanent semantic fallback layer, so an unavailable remote image does not leave a blank white visual area.
- The phone-sized full-page capture was taken from the running development preview for final visual regression review.
- A browser DOM audit found the fallback layer on all 37 rendered service artwork containers. The stored images had previously been lazy-loaded while off-screen, so the final markup now uses eager loading for the shared, cached service artwork and retains the fallback on image errors.
- The responsive Media grid changes to one column at phone width, preserving the requested vertical TV Channels then Newspaper Portal order.
- Final browser visual inspection showed the two separate, large cards under the law-enforcement sequence: first “বাংলাদেশ টিভি চ্যানেল”, then “বাংলাদেশ পত্রিকা পোর্টাল”, each with its own destination label and non-empty hero artwork.
- After the eager-load refinement, browser DOM verification confirmed all 37 service images loaded. The verified target cards included NID/registration, e-passport, police-station assistance and trade-licence/civic-office artwork; each also retained the permanent fallback layer.
- The final card-level visual inspection showed the NID/registration and police cards with full-width colourful civic illustrations rather than blank white panels or logo-only decorations.
