CREATE TABLE `service_reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`serviceId` varchar(32) NOT NULL,
	`serviceName` varchar(255) NOT NULL,
	`rating` int NOT NULL,
	`comment` text NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `service_reviews_id` PRIMARY KEY(`id`),
	CONSTRAINT `service_reviews_user_service_idx` UNIQUE(`userId`,`serviceId`)
);
