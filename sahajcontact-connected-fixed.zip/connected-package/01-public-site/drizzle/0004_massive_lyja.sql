CREATE TABLE `gallery_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`imageUrl` text NOT NULL,
	`category` varchar(32) NOT NULL,
	`titleBn` varchar(255) NOT NULL,
	`titleEn` varchar(255) NOT NULL,
	`captionBn` text NOT NULL,
	`captionEn` text NOT NULL,
	`creditBn` varchar(255),
	`creditEn` varchar(255),
	`uploaderId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gallery_photos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `service_applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(50) NOT NULL,
	`service_needed` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `service_applications_id` PRIMARY KEY(`id`)
);
