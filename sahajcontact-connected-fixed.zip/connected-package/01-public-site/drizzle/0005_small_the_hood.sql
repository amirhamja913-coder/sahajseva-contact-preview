CREATE TABLE `admin_analytics_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportTitle` varchar(255) NOT NULL,
	`totalEvents` int NOT NULL DEFAULT 3714,
	`pageViews` int NOT NULL DEFAULT 1845,
	`activeUsers` int NOT NULL DEFAULT 291,
	`sessions` int NOT NULL DEFAULT 321,
	`countryData` text NOT NULL,
	`cityData` text NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_analytics_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `admin_media_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileType` varchar(64) NOT NULL,
	`folderName` varchar(128) NOT NULL DEFAULT 'General',
	`fileSize` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_media_files_id` PRIMARY KEY(`id`)
);
