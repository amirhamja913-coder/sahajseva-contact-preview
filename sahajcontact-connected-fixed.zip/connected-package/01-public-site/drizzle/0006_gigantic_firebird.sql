CREATE TABLE `admin_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(255) NOT NULL,
	`name` varchar(128) NOT NULL,
	`role` varchar(64) NOT NULL DEFAULT 'Editor',
	`status` varchar(32) NOT NULL DEFAULT 'Active',
	`addedBy` varchar(255) NOT NULL DEFAULT 'Primary Owner',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_members_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_members_email_unique` UNIQUE(`email`)
);
