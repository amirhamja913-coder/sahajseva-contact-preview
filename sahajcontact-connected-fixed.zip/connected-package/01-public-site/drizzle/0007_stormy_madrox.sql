CREATE TABLE `admin_access_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`passwordHash` varchar(128) NOT NULL,
	`passwordSalt` varchar(128) NOT NULL,
	`updatedBy` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_access_settings_id` PRIMARY KEY(`id`)
);
