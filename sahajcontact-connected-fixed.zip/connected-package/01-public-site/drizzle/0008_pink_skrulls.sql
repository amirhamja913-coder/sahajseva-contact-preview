CREATE TABLE `admin_login_activities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`outcome` enum('success','failure') NOT NULL,
	`method` enum('password','biometric') NOT NULL,
	`deviceSummary` varchar(160) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_login_activities_id` PRIMARY KEY(`id`)
);
