CREATE TABLE `admin_login_alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`failedAttemptCount` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_login_alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `admin_member_feature_permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`feature` enum('analytics','media','members','security','exports') NOT NULL,
	`enabled` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_member_feature_permissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_member_feature_unique` UNIQUE(`memberId`,`feature`)
);
