CREATE TABLE `admin_login_alert_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`enabled` int NOT NULL DEFAULT 1,
	`threshold` int NOT NULL DEFAULT 3,
	`windowMinutes` int NOT NULL DEFAULT 10,
	`lastAlertAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_login_alert_settings_id` PRIMARY KEY(`id`)
);
