CREATE TABLE `admin_media_folders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_media_folders_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_media_folders_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `site_content_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`heroTitleBn` varchar(255),
	`heroSubtitleBn` text,
	`heroAccentMessageBn` varchar(255),
	`primaryCtaLabelBn` varchar(120),
	`primaryCtaHref` varchar(500),
	`ownerNoticeTitleBn` varchar(180),
	`ownerNoticeTextBn` text,
	`noticeVisible` int NOT NULL DEFAULT 0,
	`quickLinksVisible` int NOT NULL DEFAULT 1,
	`brandAccentColor` varchar(7) NOT NULL DEFAULT '#0d5c56',
	`brandHighlightColor` varchar(7) NOT NULL DEFAULT '#f2b84b',
	`updatedBy` varchar(80) NOT NULL DEFAULT 'Primary Owner',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_content_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `site_management_change_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`action` varchar(64) NOT NULL,
	`summary` varchar(255) NOT NULL,
	`changedFields` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `site_management_change_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `site_quick_links` (
	`id` int AUTO_INCREMENT NOT NULL,
	`titleBn` varchar(160) NOT NULL,
	`url` varchar(500) NOT NULL,
	`descriptionBn` varchar(255),
	`openInNewTab` int NOT NULL DEFAULT 1,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_quick_links_id` PRIMARY KEY(`id`)
);
