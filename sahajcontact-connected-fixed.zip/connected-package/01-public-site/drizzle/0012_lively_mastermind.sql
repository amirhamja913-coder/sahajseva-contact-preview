CREATE TABLE `contact_leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`mobile` varchar(32) NOT NULL,
	`subject` varchar(180),
	`message` text NOT NULL,
	`source` varchar(64) NOT NULL DEFAULT 'contact',
	`status` enum('new','reviewed','closed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contact_leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `site_announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`messageBn` varchar(300) NOT NULL,
	`linkUrl` varchar(500),
	`enabled` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `site_blog_posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`titleBn` varchar(220) NOT NULL,
	`slug` varchar(240) NOT NULL,
	`excerptBn` varchar(420) NOT NULL,
	`contentBn` text NOT NULL,
	`coverImageUrl` text,
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_blog_posts_id` PRIMARY KEY(`id`),
	CONSTRAINT `site_blog_posts_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `logoUrl` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoMode` enum('auto','manual') DEFAULT 'auto' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoSiteTitle` varchar(255);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoMetaDescription` varchar(320);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoKeywords` varchar(500);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoOgImageUrl` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoFaviconUrl` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `googleVerificationCode` varchar(255);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `robotsDirectives` text;