CREATE TABLE `site_operational_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`level` enum('error','warning','info') NOT NULL DEFAULT 'info',
	`operation` varchar(80) NOT NULL,
	`message` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `site_operational_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `site_announcements` ADD `messageEn` varchar(300);--> statement-breakpoint
ALTER TABLE `site_blog_posts` ADD `titleEn` varchar(220);--> statement-breakpoint
ALTER TABLE `site_blog_posts` ADD `excerptEn` varchar(420);--> statement-breakpoint
ALTER TABLE `site_blog_posts` ADD `contentEn` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `heroTitleEn` varchar(255);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `heroSubtitleEn` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `heroAccentMessageEn` varchar(255);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `primaryCtaLabelEn` varchar(120);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `ownerNoticeTitleEn` varchar(180);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `ownerNoticeTextEn` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoSiteTitleBn` varchar(255);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoSiteTitleEn` varchar(255);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoMetaDescriptionBn` varchar(320);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `seoMetaDescriptionEn` varchar(320);--> statement-breakpoint
ALTER TABLE `site_quick_links` ADD `titleEn` varchar(160);--> statement-breakpoint
ALTER TABLE `site_quick_links` ADD `descriptionEn` varchar(255);