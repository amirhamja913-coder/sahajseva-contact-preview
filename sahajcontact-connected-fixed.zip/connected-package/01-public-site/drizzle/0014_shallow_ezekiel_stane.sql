CREATE TABLE `ad_click_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ad_click_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `advertiser_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accessToken` varchar(72) NOT NULL,
	`businessName` varchar(180) NOT NULL,
	`contactName` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`slot` enum('header','sidebar','blog') NOT NULL,
	`adTitleBn` varchar(160) NOT NULL,
	`adTitleEn` varchar(160),
	`adUrl` varchar(500) NOT NULL,
	`imageUrl` text,
	`priceBdt` int NOT NULL DEFAULT 0,
	`invoiceNumber` varchar(64) NOT NULL,
	`status` enum('submitted','approved','rejected','awaiting_payment','paid','live','expired') NOT NULL DEFAULT 'submitted',
	`decisionNote` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `advertiser_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `advertiser_orders_accessToken_unique` UNIQUE(`accessToken`),
	CONSTRAINT `advertiser_orders_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
CREATE TABLE `advertiser_slot_prices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slot` enum('header','sidebar','blog') NOT NULL,
	`priceBdt` int NOT NULL DEFAULT 0,
	`active` int NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `advertiser_slot_prices_id` PRIMARY KEY(`id`),
	CONSTRAINT `advertiser_slot_prices_slot_unique` UNIQUE(`slot`)
);
--> statement-breakpoint
CREATE TABLE `investor_leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`organisation` varchar(180),
	`message` text NOT NULL,
	`status` enum('new','reviewed','closed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `investor_leads_id` PRIMARY KEY(`id`)
);
