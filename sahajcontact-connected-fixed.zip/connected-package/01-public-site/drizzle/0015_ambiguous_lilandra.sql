CREATE TABLE `site_backup_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kind` enum('scheduled','manual') NOT NULL DEFAULT 'scheduled',
	`dayKey` varchar(10),
	`snapshotJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `site_backup_snapshots_id` PRIMARY KEY(`id`),
	CONSTRAINT `site_backup_snapshots_day_unique` UNIQUE(`dayKey`)
);
