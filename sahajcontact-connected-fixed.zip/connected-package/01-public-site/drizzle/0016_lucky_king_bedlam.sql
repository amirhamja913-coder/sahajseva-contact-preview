CREATE TABLE `site_backup_automation_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schedule_cron_task_uid` varchar(65),
	`enabled` int NOT NULL DEFAULT 1,
	`last_successful_run_at` timestamp,
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_backup_automation_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `site_backup_automation_settings_schedule_cron_task_uid_unique` UNIQUE(`schedule_cron_task_uid`)
);
