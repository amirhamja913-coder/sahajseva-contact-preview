ALTER TABLE `admin_login_activities` ADD `loginEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `admin_login_activities` ADD `ipAddress` varchar(64);