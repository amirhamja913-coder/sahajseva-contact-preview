CREATE TABLE `site_builder_states` (
	`id` int AUTO_INCREMENT NOT NULL,
	`draftJson` text NOT NULL,
	`publishedJson` text,
	`updatedBy` varchar(128) NOT NULL DEFAULT 'Primary Owner',
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_builder_states_id` PRIMARY KEY(`id`)
);
