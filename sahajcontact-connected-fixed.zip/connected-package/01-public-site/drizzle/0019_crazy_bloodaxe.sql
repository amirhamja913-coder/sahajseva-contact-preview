CREATE TABLE `site_builder_countries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`titleBn` varchar(160) NOT NULL,
	`titleEn` varchar(160) NOT NULL,
	`descriptionBn` text NOT NULL,
	`descriptionEn` text NOT NULL,
	`imageUrl` text,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`updatedBy` varchar(128) NOT NULL DEFAULT 'Primary Owner',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_builder_countries_id` PRIMARY KEY(`id`),
	CONSTRAINT `site_builder_countries_code_idx` UNIQUE(`code`)
);
--> statement-breakpoint
ALTER TABLE `site_builder_states` ADD `heroTitleBn` varchar(255);--> statement-breakpoint
ALTER TABLE `site_builder_states` ADD `heroTitleEn` varchar(255);--> statement-breakpoint
ALTER TABLE `site_builder_states` ADD `heroSubtitleBn` text;--> statement-breakpoint
ALTER TABLE `site_builder_states` ADD `heroSubtitleEn` text;--> statement-breakpoint
ALTER TABLE `site_builder_states` ADD `whatsappNumber` varchar(40);