CREATE TABLE `border_ports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nameBn` varchar(180) NOT NULL,
	`nameEn` varchar(180) NOT NULL,
	`locationBn` varchar(180) NOT NULL,
	`locationEn` varchar(180) NOT NULL,
	`infoBn` varchar(420) NOT NULL,
	`infoEn` varchar(420) NOT NULL,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `border_ports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tourist_places` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nameBn` varchar(180) NOT NULL,
	`nameEn` varchar(180) NOT NULL,
	`descBn` varchar(420) NOT NULL,
	`descEn` varchar(420) NOT NULL,
	`imageUrl` text,
	`category` enum('সমুদ্র','পাহাড়','ঐতিহাসিক','ধর্মীয়') NOT NULL,
	`location` varchar(180) NOT NULL,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tourist_places_id` PRIMARY KEY(`id`)
);
