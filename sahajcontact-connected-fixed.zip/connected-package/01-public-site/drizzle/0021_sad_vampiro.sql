CREATE TABLE `embassies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`countryCode` varchar(3) NOT NULL,
	`countryNameBn` varchar(120) NOT NULL,
	`countryNameEn` varchar(120) NOT NULL,
	`flagEmoji` varchar(8) NOT NULL,
	`addressBn` varchar(420) NOT NULL,
	`addressEn` varchar(420) NOT NULL,
	`phone` varchar(180) NOT NULL,
	`websiteUrl` text NOT NULL,
	`whatsappUrl` text,
	`sourceUrl` text NOT NULL,
	`lastVerifiedAt` timestamp NOT NULL,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `embassies_id` PRIMARY KEY(`id`)
);
