CREATE TABLE `education_hub_cards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(80) NOT NULL,
	`titleBn` varchar(180) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`descriptionBn` varchar(420) NOT NULL,
	`descriptionEn` varchar(420) NOT NULL,
	`iconName` varchar(48) NOT NULL DEFAULT 'BookOpen',
	`officialUrl` text NOT NULL,
	`whatsappUrl` text,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `education_hub_cards_id` PRIMARY KEY(`id`),
	CONSTRAINT `education_hub_cards_slug_unique` UNIQUE(`slug`)
);
