CREATE TABLE `media_hub_channels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`categorySlug` varchar(40) NOT NULL,
	`categoryNameBn` varchar(80) NOT NULL,
	`categoryNameEn` varchar(80) NOT NULL,
	`channelNameBn` varchar(120) NOT NULL,
	`channelNameEn` varchar(120) NOT NULL,
	`officialUrl` text NOT NULL,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `media_hub_channels_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `media_hub_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(80) NOT NULL,
	`titleBn` varchar(180) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`descriptionBn` varchar(420) NOT NULL,
	`descriptionEn` varchar(420) NOT NULL,
	`disclaimerBn` varchar(420) NOT NULL,
	`disclaimerEn` varchar(420) NOT NULL,
	`iconName` varchar(48) NOT NULL DEFAULT 'Tv',
	`visible` int NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `media_hub_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `media_hub_settings_slug_unique` UNIQUE(`slug`)
);
