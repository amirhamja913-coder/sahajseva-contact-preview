ALTER TABLE `media_hub_channels` ADD `logoUrl` text;--> statement-breakpoint
ALTER TABLE `media_hub_channels` ADD `descriptionBn` varchar(255);--> statement-breakpoint
ALTER TABLE `media_hub_channels` ADD `descriptionEn` varchar(255);