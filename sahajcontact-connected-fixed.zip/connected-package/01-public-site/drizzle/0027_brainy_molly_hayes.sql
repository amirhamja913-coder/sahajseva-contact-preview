ALTER TABLE `border_ports` ADD `imageUrl` text;--> statement-breakpoint
ALTER TABLE `border_ports` ADD `galleryJson` text;--> statement-breakpoint
ALTER TABLE `tourist_places` ADD `galleryJson` text;