ALTER TABLE `site_content_settings` ADD `googleAnalyticsId` varchar(120);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `facebookPixelId` varchar(120);