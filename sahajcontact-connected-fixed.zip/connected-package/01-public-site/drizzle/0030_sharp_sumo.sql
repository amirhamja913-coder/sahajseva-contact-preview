ALTER TABLE `site_announcements` ADD `color` varchar(7) DEFAULT '#0d5c56' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_blog_posts` ADD `pdfUrl` text;--> statement-breakpoint
ALTER TABLE `site_blog_posts` ADD `isPinned` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `heroBackgroundImageUrl` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `heroVideoUrl` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `siteNameBn` varchar(180);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `siteNameEn` varchar(180);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `contactPhone` varchar(40);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `contactEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `socialLinksJson` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `notFoundTitleBn` varchar(180);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `notFoundTitleEn` varchar(180);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `notFoundMessageBn` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `notFoundMessageEn` text;--> statement-breakpoint
ALTER TABLE `site_quick_links` ADD `iconName` varchar(48) DEFAULT 'Link' NOT NULL;--> statement-breakpoint
ALTER TABLE `tourist_places` ADD `mapUrl` text;