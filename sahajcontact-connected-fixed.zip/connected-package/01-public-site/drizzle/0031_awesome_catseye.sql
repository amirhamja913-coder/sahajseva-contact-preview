ALTER TABLE `site_content_settings` ADD `showStatActiveUsers` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showStatPageViews` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showStatKeyEvents` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showStatTopCountries` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showStatEngagement` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showStatShares` int DEFAULT 1 NOT NULL;