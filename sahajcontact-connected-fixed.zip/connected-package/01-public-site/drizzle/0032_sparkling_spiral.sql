CREATE TABLE `site_navigation_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`titleBn` varchar(180) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`url` varchar(500) NOT NULL,
	`visible` int NOT NULL DEFAULT 1,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_navigation_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerAnnouncementEnabled` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerAnnouncementTextBn` varchar(300) DEFAULT 'গ্রামীণ মোটিফ চলছে' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerAnnouncementTextEn` varchar(300) DEFAULT 'Rural motif is active' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerAnnouncementButtonBn` varchar(120) DEFAULT 'থামাতে চাপুন' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerAnnouncementButtonEn` varchar(120) DEFAULT 'Tap to pause' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerAnnouncementColor` varchar(7) DEFAULT '#0d5c56' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showLanguageBn` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `showLanguageEn` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `defaultSiteLanguage` enum('BN','EN') DEFAULT 'BN' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpVisible` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpTitleBn` varchar(180) DEFAULT 'প্রবাসী সহায়তা' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpTitleEn` varchar(180) DEFAULT 'Expatriate Support' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpSubtitleBn` varchar(300) DEFAULT 'প্রবাসী গাইড ও কান্ট্রি ফিল্টার' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpSubtitleEn` varchar(300) DEFAULT 'Expat Guide & Country Filter' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpLinkBn` varchar(120) DEFAULT 'গাইডলাইন দেখতে চাপুন' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpLinkEn` varchar(120) DEFAULT 'Tap to view guidelines' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `probashiHelpHref` varchar(500) DEFAULT '/#expatriates' NOT NULL;