CREATE TABLE `service_pricing` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serviceKey` varchar(96) NOT NULL,
	`serviceNameBn` varchar(255) NOT NULL,
	`serviceNameEn` varchar(255) NOT NULL,
	`servicePrice` int NOT NULL DEFAULT 250,
	`governmentFee` int NOT NULL DEFAULT 0,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `service_pricing_id` PRIMARY KEY(`id`),
	CONSTRAINT `service_pricing_service_key_idx` UNIQUE(`serviceKey`)
);
--> statement-breakpoint
ALTER TABLE `customer_orders` ADD `serviceKey` varchar(96);--> statement-breakpoint
ALTER TABLE `customer_orders` ADD `referenceNumber` varchar(64);--> statement-breakpoint
ALTER TABLE `customer_orders` ADD `governmentFee` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `customer_orders` ADD `totalAmount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `customer_orders` ADD `paymentStatus` enum('pending','completed') DEFAULT 'pending' NOT NULL;