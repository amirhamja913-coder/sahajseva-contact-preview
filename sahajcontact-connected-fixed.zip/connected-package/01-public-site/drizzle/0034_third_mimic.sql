CREATE TABLE `premium_photo_products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`titleBn` varchar(255) NOT NULL,
	`titleEn` varchar(255) NOT NULL,
	`descriptionBn` text,
	`descriptionEn` text,
	`previewImageUrl` text NOT NULL,
	`fullImageKey` varchar(512) NOT NULL,
	`priceBdt` int NOT NULL DEFAULT 0,
	`watermarkText` varchar(128) NOT NULL DEFAULT 'SahajSheba',
	`isPublished` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `premium_photo_products_id` PRIMARY KEY(`id`),
	CONSTRAINT `premium_photo_products_id_idx` UNIQUE(`id`)
);
--> statement-breakpoint
CREATE TABLE `premium_photo_purchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`purchaseReference` varchar(64) NOT NULL,
	`purchaserName` varchar(255) NOT NULL,
	`purchaserEmail` varchar(320),
	`amountBdt` int NOT NULL,
	`provider` enum('bkash_test','nagad_test','bkash','nagad') NOT NULL,
	`paymentMode` enum('test','live') NOT NULL DEFAULT 'test',
	`paymentStatus` enum('test_completed','pending','completed','failed') NOT NULL DEFAULT 'test_completed',
	`accessToken` varchar(96) NOT NULL,
	`accessExpiresAt` timestamp NOT NULL,
	`deliveredAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `premium_photo_purchases_id` PRIMARY KEY(`id`),
	CONSTRAINT `premium_photo_purchases_reference_idx` UNIQUE(`purchaseReference`),
	CONSTRAINT `premium_photo_purchases_access_token_idx` UNIQUE(`accessToken`)
);
