CREATE TABLE `owner_personal_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`folder` enum('gallery','map') NOT NULL DEFAULT 'gallery',
	`titleBn` varchar(255) NOT NULL,
	`titleEn` varchar(255) NOT NULL,
	`descriptionBn` text,
	`descriptionEn` text,
	`imageUrl` text NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`isPublic` int NOT NULL DEFAULT 0,
	`displayOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `owner_personal_photos_id` PRIMARY KEY(`id`),
	CONSTRAINT `owner_personal_photos_folder_id_idx` UNIQUE(`folder`,`id`)
);
