ALTER TABLE `site_content_settings` ADD `headerTaglineBn` varchar(180);--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `headerTaglineEn` varchar(180);