ALTER TABLE `site_content_settings` ADD `pageBackgroundColor` varchar(7) DEFAULT '#f3faf6' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `pageBackgroundImageUrl` text;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `siteTextColor` varchar(7) DEFAULT '#173b32' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `fontScale` enum('small','standard','large') DEFAULT 'standard' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `layoutDensity` enum('compact','standard','relaxed') DEFAULT 'standard' NOT NULL;