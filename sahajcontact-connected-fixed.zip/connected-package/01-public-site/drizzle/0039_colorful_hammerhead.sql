ALTER TABLE `site_content_settings` ADD `remoteMaintenanceMode` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remoteMaintenanceMessage` varchar(280) DEFAULT 'সেবা চালু আছে' NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remoteSmsEnabled` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remoteSignupEnabled` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remotePaymentEnabled` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remoteLoginEnabled` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remoteControlUpdatedAt` timestamp;--> statement-breakpoint
ALTER TABLE `site_content_settings` ADD `remoteControlUpdatedBy` varchar(120) DEFAULT 'Admin Dashboard' NOT NULL;