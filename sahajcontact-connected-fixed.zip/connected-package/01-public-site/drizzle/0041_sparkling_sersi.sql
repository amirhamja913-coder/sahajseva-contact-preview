ALTER TABLE `border_ports` ADD `bangladeshAddressBn` varchar(420);--> statement-breakpoint
ALTER TABLE `border_ports` ADD `bangladeshAddressEn` varchar(420);--> statement-breakpoint
ALTER TABLE `border_ports` ADD `indiaCounterpartBn` varchar(180);--> statement-breakpoint
ALTER TABLE `border_ports` ADD `indiaCounterpartEn` varchar(180);--> statement-breakpoint
ALTER TABLE `border_ports` ADD `officialSourceUrl` text;--> statement-breakpoint
ALTER TABLE `border_ports` ADD `officialSourceLabelBn` varchar(180);--> statement-breakpoint
ALTER TABLE `border_ports` ADD `officialSourceLabelEn` varchar(180);--> statement-breakpoint
ALTER TABLE `border_ports` ADD `mapUrl` text;