CREATE TABLE `seo_report_refresh_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schedule_cron_task_uid` varchar(65),
	`enabled` int NOT NULL DEFAULT 1,
	`last_attempted_at` timestamp,
	`last_successful_run_at` timestamp,
	`last_snapshot_at` timestamp,
	`last_error` varchar(280),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seo_report_refresh_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `seo_report_refresh_settings_schedule_cron_task_uid_unique` UNIQUE(`schedule_cron_task_uid`)
);
--> statement-breakpoint
ALTER TABLE `admin_analytics_reports` ADD `snapshotDayKey` varchar(10);--> statement-breakpoint
ALTER TABLE `admin_analytics_reports` ADD `snapshotSource` varchar(48);--> statement-breakpoint
ALTER TABLE `admin_analytics_reports` ADD CONSTRAINT `admin_analytics_reports_snapshotDayKey_unique` UNIQUE(`snapshotDayKey`);