CREATE TABLE `ngo_partnership_applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationName` varchar(255) NOT NULL,
	`registrationOrOfficialUrl` varchar(500),
	`contactName` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(32) NOT NULL,
	`programmeFocus` varchar(255) NOT NULL,
	`coverageArea` varchar(255) NOT NULL,
	`collaborationProposal` text NOT NULL,
	`consentAccepted` int NOT NULL DEFAULT 0,
	`status` enum('pending','verified','declined','archived') NOT NULL DEFAULT 'pending',
	`ownerNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ngo_partnership_applications_id` PRIMARY KEY(`id`)
);
