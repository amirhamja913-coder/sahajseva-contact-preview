CREATE TABLE `institutional_verification_registers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tradeLicenceStatus` enum('not_recorded','owner_confirms_held') NOT NULL DEFAULT 'not_recorded',
	`confirmedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `institutional_verification_registers_id` PRIMARY KEY(`id`)
);
