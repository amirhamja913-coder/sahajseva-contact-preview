CREATE TABLE `business_directory_submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`businessName` varchar(180) NOT NULL,
	`category` varchar(120) NOT NULL,
	`district` varchar(120) NOT NULL,
	`publicWebsiteUrl` varchar(500),
	`publicDescription` text NOT NULL,
	`contactName` varchar(160) NOT NULL,
	`contactEmail` varchar(320) NOT NULL,
	`contactPhone` varchar(32) NOT NULL,
	`consentAccepted` int NOT NULL DEFAULT 0,
	`status` enum('pending','published','declined','archived') NOT NULL DEFAULT 'pending',
	`ownerNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `business_directory_submissions_id` PRIMARY KEY(`id`)
);
