CREATE TABLE `business_directory_claim_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`listingId` int NOT NULL,
	`claimantName` varchar(160) NOT NULL,
	`relationship` varchar(180) NOT NULL,
	`contactEmail` varchar(320) NOT NULL,
	`contactPhone` varchar(32) NOT NULL,
	`requestExplanation` text NOT NULL,
	`consentAccepted` int NOT NULL DEFAULT 0,
	`status` enum('pending','reviewed','declined','archived') NOT NULL DEFAULT 'pending',
	`ownerNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `business_directory_claim_requests_id` PRIMARY KEY(`id`)
);
