import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing the existing Manus OAuth flow and the new phone OTP flow.
 * Phone-auth users use an openId in the form `phone:<normalized-phone>`.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 128 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }).unique(),
  address: text("address"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** One-time OTP challenges. OTP values are stored only as SHA-256 hashes. */
export const phoneOtpChallenges = mysqlTable("phone_otp_challenges", {
  id: int("id").autoincrement().primaryKey(),
  phone: varchar("phone", { length: 20 }).notNull(),
  otpHash: varchar("otpHash", { length: 64 }).notNull(),
  dayKey: varchar("dayKey", { length: 10 }).notNull(),
  attempts: int("attempts").default(0).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  consumedAt: timestamp("consumedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PhoneOtpChallenge = typeof phoneOtpChallenges.$inferSelect;
export type InsertPhoneOtpChallenge = typeof phoneOtpChallenges.$inferInsert;

/** Customer-owned service order history. */
export const customerOrders = mysqlTable("customer_orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  serviceKey: varchar("serviceKey", { length: 96 }),
  serviceName: varchar("serviceName", { length: 255 }).notNull(),
  referenceNumber: varchar("referenceNumber", { length: 64 }),
  orderDate: timestamp("orderDate").defaultNow().notNull(),
  status: varchar("status", { length: 64 }).default("প্রক্রিয়াধীন").notNull(),
  price: int("price"),
  governmentFee: int("governmentFee").default(0).notNull(),
  totalAmount: int("totalAmount").default(0).notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "completed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CustomerOrder = typeof customerOrders.$inferSelect;
export type InsertCustomerOrder = typeof customerOrders.$inferInsert;

/** Owner-managed purchasable still images. `fullImageKey` is never sent by public product APIs. */
export const premiumPhotoProducts = mysqlTable(
  "premium_photo_products",
  {
    id: int("id").autoincrement().primaryKey(),
    titleBn: varchar("titleBn", { length: 255 }).notNull(),
    titleEn: varchar("titleEn", { length: 255 }).notNull(),
    descriptionBn: text("descriptionBn"),
    descriptionEn: text("descriptionEn"),
    previewImageUrl: text("previewImageUrl").notNull(),
    fullImageKey: varchar("fullImageKey", { length: 512 }).notNull(),
    priceBdt: int("priceBdt").default(0).notNull(),
    watermarkText: varchar("watermarkText", { length: 128 }).default("SahajSheba").notNull(),
    isPublished: int("isPublished").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    premiumPhotoPublishedIndex: uniqueIndex("premium_photo_products_id_idx").on(table.id),
  }),
);

export type PremiumPhotoProduct = typeof premiumPhotoProducts.$inferSelect;
export type InsertPremiumPhotoProduct = typeof premiumPhotoProducts.$inferInsert;

/**
 * TEST MODE and future provider purchase records. Access tokens are the only public
 * capability used to request a temporary signed full-resolution delivery URL.
 */
export const premiumPhotoPurchases = mysqlTable(
  "premium_photo_purchases",
  {
    id: int("id").autoincrement().primaryKey(),
    productId: int("productId").notNull(),
    purchaseReference: varchar("purchaseReference", { length: 64 }).notNull(),
    purchaserName: varchar("purchaserName", { length: 255 }).notNull(),
    purchaserEmail: varchar("purchaserEmail", { length: 320 }),
    amountBdt: int("amountBdt").notNull(),
    provider: mysqlEnum("provider", ["bkash_test", "nagad_test", "bkash", "nagad"]).notNull(),
    paymentMode: mysqlEnum("paymentMode", ["test", "live"]).default("test").notNull(),
    paymentStatus: mysqlEnum("paymentStatus", ["test_completed", "pending", "completed", "failed"]).default("test_completed").notNull(),
    accessToken: varchar("accessToken", { length: 96 }).notNull(),
    accessExpiresAt: timestamp("accessExpiresAt").notNull(),
    deliveredAt: timestamp("deliveredAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    premiumPhotoPurchaseReferenceUnique: uniqueIndex("premium_photo_purchases_reference_idx").on(table.purchaseReference),
    premiumPhotoPurchaseAccessTokenUnique: uniqueIndex("premium_photo_purchases_access_token_idx").on(table.accessToken),
  }),
);

export type PremiumPhotoPurchase = typeof premiumPhotoPurchases.$inferSelect;
export type InsertPremiumPhotoPurchase = typeof premiumPhotoPurchases.$inferInsert;

/** Owner photographs for the public personal gallery and the contact-location portrait. */
export const ownerPersonalPhotos = mysqlTable(
  "owner_personal_photos",
  {
    id: int("id").autoincrement().primaryKey(),
    folder: mysqlEnum("folder", ["gallery", "map"]).default("gallery").notNull(),
    titleBn: varchar("titleBn", { length: 255 }).notNull(),
    titleEn: varchar("titleEn", { length: 255 }).notNull(),
    descriptionBn: text("descriptionBn"),
    descriptionEn: text("descriptionEn"),
    imageUrl: text("imageUrl").notNull(),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    isPublic: int("isPublic").default(0).notNull(),
    displayOrder: int("displayOrder").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    ownerPersonalPhotoFolderIndex: uniqueIndex("owner_personal_photos_folder_id_idx").on(table.folder, table.id),
  }),
);

export type OwnerPersonalPhoto = typeof ownerPersonalPhotos.$inferSelect;
export type InsertOwnerPersonalPhoto = typeof ownerPersonalPhotos.$inferInsert;

/** Owner-managed service prices used to create transparent, real order summaries. */
export const servicePricing = mysqlTable(
  "service_pricing",
  {
    id: int("id").autoincrement().primaryKey(),
    serviceKey: varchar("serviceKey", { length: 96 }).notNull(),
    serviceNameBn: varchar("serviceNameBn", { length: 255 }).notNull(),
    serviceNameEn: varchar("serviceNameEn", { length: 255 }).notNull(),
    servicePrice: int("servicePrice").default(250).notNull(),
    governmentFee: int("governmentFee").default(0).notNull(),
    isActive: int("isActive").default(1).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    servicePricingKeyUnique: uniqueIndex("service_pricing_service_key_idx").on(table.serviceKey),
  }),
);

export type ServicePricing = typeof servicePricing.$inferSelect;
export type InsertServicePricing = typeof servicePricing.$inferInsert;

/**
 * Customer reviews are held for moderation before public display. The service
 * key is the stable catalog number (01–40), not a mutable URL or array index.
 */
export const serviceReviews = mysqlTable(
  "service_reviews",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    serviceId: varchar("serviceId", { length: 32 }).notNull(),
    serviceName: varchar("serviceName", { length: 255 }).notNull(),
    rating: int("rating").notNull(),
    comment: text("comment").notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    oneReviewPerUserAndService: uniqueIndex("service_reviews_user_service_idx").on(table.userId, table.serviceId),
  }),
);

export type ServiceReview = typeof serviceReviews.$inferSelect;
export type InsertServiceReview = typeof serviceReviews.$inferInsert;

/** Public sponsor and partnership inquiries submitted from the Contact page. */
export const sponsorInquiries = mysqlTable("sponsor_inquiries", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  organization: varchar("organization", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  interest: varchar("interest", { length: 120 }).notNull(),
  message: text("message").notNull(),
  consentAccepted: int("consentAccepted").default(1).notNull(),
  status: mysqlEnum("status", ["new", "contacted", "closed"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SponsorInquiry = typeof sponsorInquiries.$inferSelect;
export type InsertSponsorInquiry = typeof sponsorInquiries.$inferInsert;

/**
 * Private collaboration applications submitted by prospective NGO, public-sector
 * or company partners. A saved application is never a public partnership claim.
 */
export const ngoPartnershipApplications = mysqlTable("ngo_partnership_applications", {
  id: int("id").autoincrement().primaryKey(),
  organizationName: varchar("organizationName", { length: 255 }).notNull(),
  registrationOrOfficialUrl: varchar("registrationOrOfficialUrl", { length: 500 }),
  contactName: varchar("contactName", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull(),
  programmeFocus: varchar("programmeFocus", { length: 255 }).notNull(),
  coverageArea: varchar("coverageArea", { length: 255 }).notNull(),
  collaborationProposal: text("collaborationProposal").notNull(),
  consentAccepted: int("consentAccepted").default(0).notNull(),
  status: mysqlEnum("status", ["pending", "verified", "declined", "archived"]).default("pending").notNull(),
  ownerNote: text("ownerNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NgoPartnershipApplication = typeof ngoPartnershipApplications.$inferSelect;
export type InsertNgoPartnershipApplication = typeof ngoPartnershipApplications.$inferInsert;

/**
 * Public business-directory submissions. Contact details and owner notes stay
 * private; only owner-published business details are exposed on the public
 * directory. A published status means editorial listing approval only, never a
 * government licence check, endorsement, rating, or paid placement.
 */
export const businessDirectorySubmissions = mysqlTable("business_directory_submissions", {
  id: int("id").autoincrement().primaryKey(),
  businessName: varchar("businessName", { length: 180 }).notNull(),
  category: varchar("category", { length: 120 }).notNull(),
  district: varchar("district", { length: 120 }).notNull(),
  publicWebsiteUrl: varchar("publicWebsiteUrl", { length: 500 }),
  publicDescription: text("publicDescription").notNull(),
  contactName: varchar("contactName", { length: 160 }).notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }).notNull(),
  contactPhone: varchar("contactPhone", { length: 32 }).notNull(),
  consentAccepted: int("consentAccepted").default(0).notNull(),
  status: mysqlEnum("status", ["pending", "published", "declined", "archived"]).default("pending").notNull(),
  ownerNote: text("ownerNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BusinessDirectorySubmission = typeof businessDirectorySubmissions.$inferSelect;
export type InsertBusinessDirectorySubmission = typeof businessDirectorySubmissions.$inferInsert;

/**
 * Private review requests tied to an already published directory listing.
 * A request is never proof of ownership, a licence check, endorsement, badge,
 * payment arrangement, or an automatic public listing change.
 */
export const businessDirectoryClaimRequests = mysqlTable("business_directory_claim_requests", {
  id: int("id").autoincrement().primaryKey(),
  listingId: int("listingId").notNull(),
  claimantName: varchar("claimantName", { length: 160 }).notNull(),
  relationship: varchar("relationship", { length: 180 }).notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }).notNull(),
  contactPhone: varchar("contactPhone", { length: 32 }).notNull(),
  requestExplanation: text("requestExplanation").notNull(),
  consentAccepted: int("consentAccepted").default(0).notNull(),
  status: mysqlEnum("status", ["pending", "reviewed", "declined", "archived"]).default("pending").notNull(),
  ownerNote: text("ownerNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BusinessDirectoryClaimRequest = typeof businessDirectoryClaimRequests.$inferSelect;
export type InsertBusinessDirectoryClaimRequest = typeof businessDirectoryClaimRequests.$inferInsert;

// The project currently uses explicit userId checks in server procedures. This
// keeps the migration portable across the existing MySQL-compatible database.

/** Service applications submitted from homepage service cards. */
export const serviceApplications = mysqlTable("service_applications", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  serviceNeeded: varchar("service_needed", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ServiceApplication = typeof serviceApplications.$inferSelect;
export type InsertServiceApplication = typeof serviceApplications.$inferInsert;

/** Admin-uploaded gallery photos for Bangladesh still images section. */
export const galleryPhotos = mysqlTable("gallery_photos", {
  id: int("id").autoincrement().primaryKey(),
  imageUrl: text("imageUrl").notNull(),
  category: varchar("category", { length: 32 }).notNull(), // development | nature | culture
  titleBn: varchar("titleBn", { length: 255 }).notNull(),
  titleEn: varchar("titleEn", { length: 255 }).notNull(),
  captionBn: text("captionBn").notNull(),
  captionEn: text("captionEn").notNull(),
  creditBn: varchar("creditBn", { length: 255 }),
  creditEn: varchar("creditEn", { length: 255 }),
  uploaderId: int("uploaderId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GalleryPhoto = typeof galleryPhotos.$inferSelect;
export type InsertGalleryPhoto = typeof galleryPhotos.$inferInsert;

/** Persistent analytics and CEO report snapshots recorded by admin. */
export const adminAnalyticsReports = mysqlTable("admin_analytics_reports", {
  id: int("id").autoincrement().primaryKey(),
  reportTitle: varchar("reportTitle", { length: 255 }).notNull(),
  /** Present only for the one idempotent automatic GA4 snapshot per Bangladesh calendar day. */
  snapshotDayKey: varchar("snapshotDayKey", { length: 10 }).unique(),
  /** Identifies automatically collected, non-estimated GA4 snapshots without changing older manual reports. */
  snapshotSource: varchar("snapshotSource", { length: 48 }),
  totalEvents: int("totalEvents").default(3714).notNull(),
  pageViews: int("pageViews").default(1845).notNull(),
  activeUsers: int("activeUsers").default(291).notNull(),
  sessions: int("sessions").default(321).notNull(),
  countryData: text("countryData").notNull(), // JSON string for country breakdown
  cityData: text("cityData").notNull(),     // JSON string for city breakdown
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdminAnalyticsReport = typeof adminAnalyticsReports.$inferSelect;
export type InsertAdminAnalyticsReport = typeof adminAnalyticsReports.$inferInsert;

/** Singleton configuration and transparent health state for the project-level daily GA4/SEO snapshot. */
export const seoReportRefreshSettings = mysqlTable("seo_report_refresh_settings", {
  id: int("id").autoincrement().primaryKey(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }).unique(),
  enabled: int("enabled").notNull().default(1),
  lastAttemptedAt: timestamp("last_attempted_at"),
  lastSuccessfulRunAt: timestamp("last_successful_run_at"),
  lastSnapshotAt: timestamp("last_snapshot_at"),
  lastError: varchar("last_error", { length: 280 }),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type SeoReportRefreshSetting = typeof seoReportRefreshSettings.$inferSelect;
export type InsertSeoReportRefreshSetting = typeof seoReportRefreshSettings.$inferInsert;

/** Admin-managed media and folder items for mobile uploads. */
export const adminMediaFiles = mysqlTable("admin_media_files", {
  id: int("id").autoincrement().primaryKey(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileType: varchar("fileType", { length: 64 }).notNull(), // image | folder | document
  folderName: varchar("folderName", { length: 128 }).default("General").notNull(),
  fileSize: varchar("fileSize", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdminMediaFile = typeof adminMediaFiles.$inferSelect;
export type InsertAdminMediaFile = typeof adminMediaFiles.$inferInsert;

/** Admin members for user management inside the dashboard. */
export const adminMembers = mysqlTable("admin_members", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  role: varchar("role", { length: 64 }).default("Editor").notNull(), // Owner, Admin, Editor
  status: varchar("status", { length: 32 }).default("Active").notNull(), // Active, Suspended
  addedBy: varchar("addedBy", { length: 255 }).default("Primary Owner").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AdminMember = typeof adminMembers.$inferSelect;
export type InsertAdminMember = typeof adminMembers.$inferInsert;

/**
 * Legacy inactive records retained in the schema only to avoid an unapproved,
 * destructive migration. No application code reads, writes, or authorizes with
 * these tables: the in-site Admin requires only the official owner account.
 */
export const adminAccessSettings = mysqlTable("admin_access_settings", {
  id: int("id").autoincrement().primaryKey(),
  passwordHash: varchar("passwordHash", { length: 128 }).notNull(),
  passwordSalt: varchar("passwordSalt", { length: 128 }).notNull(),
  updatedBy: varchar("updatedBy", { length: 128 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const adminLoginActivities = mysqlTable("admin_login_activities", {
  id: int("id").autoincrement().primaryKey(),
  outcome: mysqlEnum("outcome", ["success", "failure"]).notNull(),
  method: mysqlEnum("method", ["password", "biometric"]).notNull(),
  loginEmail: varchar("loginEmail", { length: 320 }),
  ipAddress: varchar("ipAddress", { length: 64 }),
  deviceSummary: varchar("deviceSummary", { length: 160 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const adminLoginAlerts = mysqlTable("admin_login_alerts", {
  id: int("id").autoincrement().primaryKey(),
  failedAttemptCount: int("failedAttemptCount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const adminLoginAlertSettings = mysqlTable("admin_login_alert_settings", {
  id: int("id").autoincrement().primaryKey(),
  enabled: int("enabled").default(1).notNull(),
  threshold: int("threshold").default(3).notNull(),
  windowMinutes: int("windowMinutes").default(10).notNull(),
  lastAlertAt: timestamp("lastAlertAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Owner-only institutional-document acknowledgement. This deliberately records
 * no licence image, licence number, signature, address, or personal details.
 * It is never included in public portal queries.
 */
export const institutionalVerificationRegisters = mysqlTable("institutional_verification_registers", {
  id: int("id").autoincrement().primaryKey(),
  tradeLicenceStatus: mysqlEnum("tradeLicenceStatus", ["not_recorded", "owner_confirms_held"]).default("not_recorded").notNull(),
  confirmedAt: timestamp("confirmedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InstitutionalVerificationRegister = typeof institutionalVerificationRegisters.$inferSelect;
export type InsertInstitutionalVerificationRegister = typeof institutionalVerificationRegisters.$inferInsert;

/** Owner-configured permissions that can further narrow a delegated Admin's role. */
export const adminMemberFeaturePermissions = mysqlTable(
  "admin_member_feature_permissions",
  {
    id: int("id").autoincrement().primaryKey(),
    memberId: int("memberId").notNull(),
    feature: mysqlEnum("feature", ["analytics", "media", "members", "security", "exports"]).notNull(),
    enabled: int("enabled").default(0).notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("admin_member_feature_unique").on(table.memberId, table.feature)],
);

export type AdminMemberFeaturePermission = typeof adminMemberFeaturePermissions.$inferSelect;
export type InsertAdminMemberFeaturePermission = typeof adminMemberFeaturePermissions.$inferInsert;

/**
 * Owner-controlled public-site copy and limited brand presentation controls.
 * This singleton is intentionally narrow: it never accepts HTML, scripts, or
 * arbitrary CSS, so public content remains safe to render.
 */
export const siteContentSettings = mysqlTable("site_content_settings", {
  id: int("id").autoincrement().primaryKey(),
  heroTitleBn: varchar("heroTitleBn", { length: 255 }),
  heroTitleEn: varchar("heroTitleEn", { length: 255 }),
  heroSubtitleBn: text("heroSubtitleBn"),
  heroSubtitleEn: text("heroSubtitleEn"),
  heroBackgroundImageUrl: text("heroBackgroundImageUrl"),
  heroVideoUrl: text("heroVideoUrl"),
  siteNameBn: varchar("siteNameBn", { length: 180 }),
  siteNameEn: varchar("siteNameEn", { length: 180 }),
  headerTaglineBn: varchar("headerTaglineBn", { length: 180 }),
  headerTaglineEn: varchar("headerTaglineEn", { length: 180 }),
  contactPhone: varchar("contactPhone", { length: 40 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  socialLinksJson: text("socialLinksJson"),
  notFoundTitleBn: varchar("notFoundTitleBn", { length: 180 }),
  notFoundTitleEn: varchar("notFoundTitleEn", { length: 180 }),
  notFoundMessageBn: text("notFoundMessageBn"),
  notFoundMessageEn: text("notFoundMessageEn"),
  heroAccentMessageBn: varchar("heroAccentMessageBn", { length: 255 }),
  heroAccentMessageEn: varchar("heroAccentMessageEn", { length: 255 }),
  primaryCtaLabelBn: varchar("primaryCtaLabelBn", { length: 120 }),
  primaryCtaLabelEn: varchar("primaryCtaLabelEn", { length: 120 }),
  primaryCtaHref: varchar("primaryCtaHref", { length: 500 }),
  ownerNoticeTitleBn: varchar("ownerNoticeTitleBn", { length: 180 }),
  ownerNoticeTitleEn: varchar("ownerNoticeTitleEn", { length: 180 }),
  ownerNoticeTextBn: text("ownerNoticeTextBn"),
  ownerNoticeTextEn: text("ownerNoticeTextEn"),
  noticeVisible: int("noticeVisible").default(0).notNull(),
  quickLinksVisible: int("quickLinksVisible").default(1).notNull(),
  showStatActiveUsers: int("showStatActiveUsers").default(1).notNull(),
  showStatPageViews: int("showStatPageViews").default(1).notNull(),
  showStatKeyEvents: int("showStatKeyEvents").default(0).notNull(),
  showStatTopCountries: int("showStatTopCountries").default(1).notNull(),
  showStatEngagement: int("showStatEngagement").default(0).notNull(),
  showStatShares: int("showStatShares").default(1).notNull(),
  headerAnnouncementEnabled: int("headerAnnouncementEnabled").default(1).notNull(),
  headerAnnouncementTextBn: varchar("headerAnnouncementTextBn", { length: 300 }).default("গ্রামীণ মোটিফ চলছে").notNull(),
  headerAnnouncementTextEn: varchar("headerAnnouncementTextEn", { length: 300 }).default("Rural motif is active").notNull(),
  headerAnnouncementButtonBn: varchar("headerAnnouncementButtonBn", { length: 120 }).default("থামাতে চাপুন").notNull(),
  headerAnnouncementButtonEn: varchar("headerAnnouncementButtonEn", { length: 120 }).default("Tap to pause").notNull(),
  headerAnnouncementColor: varchar("headerAnnouncementColor", { length: 7 }).default("#0d5c56").notNull(),
  showLanguageBn: int("showLanguageBn").default(1).notNull(),
  showLanguageEn: int("showLanguageEn").default(1).notNull(),
  defaultSiteLanguage: mysqlEnum("defaultSiteLanguage", ["BN", "EN"]).default("BN").notNull(),
  probashiHelpVisible: int("probashiHelpVisible").default(1).notNull(),
  probashiHelpTitleBn: varchar("probashiHelpTitleBn", { length: 180 }).default("প্রবাসী সহায়তা").notNull(),
  probashiHelpTitleEn: varchar("probashiHelpTitleEn", { length: 180 }).default("Expatriate Support").notNull(),
  probashiHelpSubtitleBn: varchar("probashiHelpSubtitleBn", { length: 300 }).default("প্রবাসী গাইড ও কান্ট্রি ফিল্টার").notNull(),
  probashiHelpSubtitleEn: varchar("probashiHelpSubtitleEn", { length: 300 }).default("Expat Guide & Country Filter").notNull(),
  probashiHelpLinkBn: varchar("probashiHelpLinkBn", { length: 120 }).default("গাইডলাইন দেখতে চাপুন").notNull(),
  probashiHelpLinkEn: varchar("probashiHelpLinkEn", { length: 120 }).default("Tap to view guidelines").notNull(),
  probashiHelpHref: varchar("probashiHelpHref", { length: 500 }).default("/#expatriates").notNull(),
  brandAccentColor: varchar("brandAccentColor", { length: 7 }).default("#0d5c56").notNull(),
  brandHighlightColor: varchar("brandHighlightColor", { length: 7 }).default("#f2b84b").notNull(),
  pageBackgroundColor: varchar("pageBackgroundColor", { length: 7 }).default("#f3faf6").notNull(),
  pageBackgroundImageUrl: text("pageBackgroundImageUrl"),
  /** JSON map of allowlisted public page/menu background overrides. */
  themeBackgroundOverridesJson: text("themeBackgroundOverridesJson"),
  /** JSON map of safe, owner-managed homepage visual block preferences. */
  homeSectionLayoutJson: text("homeSectionLayoutJson"),
  siteTextColor: varchar("siteTextColor", { length: 7 }).default("#173b32").notNull(),
  fontScale: mysqlEnum("fontScale", ["small", "standard", "large"]).default("standard").notNull(),
  layoutDensity: mysqlEnum("layoutDensity", ["compact", "standard", "relaxed"]).default("standard").notNull(),
  logoUrl: text("logoUrl"),
  seoMode: mysqlEnum("seoMode", ["auto", "manual"]).default("auto").notNull(),
  seoSiteTitle: varchar("seoSiteTitle", { length: 255 }),
  seoMetaDescription: varchar("seoMetaDescription", { length: 320 }),
  seoSiteTitleBn: varchar("seoSiteTitleBn", { length: 255 }),
  seoSiteTitleEn: varchar("seoSiteTitleEn", { length: 255 }),
  seoMetaDescriptionBn: varchar("seoMetaDescriptionBn", { length: 320 }),
  seoMetaDescriptionEn: varchar("seoMetaDescriptionEn", { length: 320 }),
  seoKeywords: varchar("seoKeywords", { length: 500 }),
  seoOgImageUrl: text("seoOgImageUrl"),
  seoFaviconUrl: text("seoFaviconUrl"),
  googleVerificationCode: varchar("googleVerificationCode", { length: 255 }),
  googleAnalyticsId: varchar("googleAnalyticsId", { length: 120 }),
  facebookPixelId: varchar("facebookPixelId", { length: 120 }),
  robotsDirectives: text("robotsDirectives"),
  remoteMaintenanceMode: int("remoteMaintenanceMode").default(0).notNull(),
  remoteMaintenanceMessage: varchar("remoteMaintenanceMessage", { length: 280 }).default("সেবা চালু আছে").notNull(),
  remoteSmsEnabled: int("remoteSmsEnabled").default(1).notNull(),
  remoteSignupEnabled: int("remoteSignupEnabled").default(1).notNull(),
  remotePaymentEnabled: int("remotePaymentEnabled").default(1).notNull(),
  remoteLoginEnabled: int("remoteLoginEnabled").default(1).notNull(),
  remoteControlUpdatedAt: timestamp("remoteControlUpdatedAt"),
  remoteControlUpdatedBy: varchar("remoteControlUpdatedBy", { length: 120 }).default("Admin Dashboard").notNull(),
  updatedBy: varchar("updatedBy", { length: 80 }).default("Primary Owner").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteContentSettings = typeof siteContentSettings.$inferSelect;
export type InsertSiteContentSettings = typeof siteContentSettings.$inferInsert;

/** Owner-published, validated links for the public quick-links section. */
export const siteQuickLinks = mysqlTable("site_quick_links", {
  id: int("id").autoincrement().primaryKey(),
  titleBn: varchar("titleBn", { length: 160 }).notNull(),
  titleEn: varchar("titleEn", { length: 160 }),
  url: varchar("url", { length: 500 }).notNull(),
  descriptionBn: varchar("descriptionBn", { length: 255 }),
  descriptionEn: varchar("descriptionEn", { length: 255 }),
  iconName: varchar("iconName", { length: 48 }).default("Link").notNull(),
  iconImageUrl: varchar("iconImageUrl", { length: 1_200 }),
  openInNewTab: int("openInNewTab").default(1).notNull(),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteQuickLink = typeof siteQuickLinks.$inferSelect;
export type InsertSiteQuickLink = typeof siteQuickLinks.$inferInsert;

/** Owner-managed header navigation shared by desktop and mobile menus. */
export const siteNavigationItems = mysqlTable("site_navigation_items", {
  id: int("id").autoincrement().primaryKey(),
  titleBn: varchar("titleBn", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  url: varchar("url", { length: 500 }).notNull(),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteNavigationItem = typeof siteNavigationItems.$inferSelect;
export type InsertSiteNavigationItem = typeof siteNavigationItems.$inferInsert;

/** Separate media folders make mobile organisation reliable and queryable. */
export const adminMediaFolders = mysqlTable("admin_media_folders", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminMediaFolder = typeof adminMediaFolders.$inferSelect;
export type InsertAdminMediaFolder = typeof adminMediaFolders.$inferInsert;

/** Privacy-safe operational history for owner-originated site changes. */
export const siteManagementChangeHistory = mysqlTable("site_management_change_history", {
  id: int("id").autoincrement().primaryKey(),
  action: varchar("action", { length: 64 }).notNull(),
  summary: varchar("summary", { length: 255 }).notNull(),
  changedFields: text("changedFields"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SiteManagementChangeHistory = typeof siteManagementChangeHistory.$inferSelect;
export type InsertSiteManagementChangeHistory = typeof siteManagementChangeHistory.$inferInsert;

/** Owner-managed public announcements, intentionally text-only and script-free. */
export const siteAnnouncements = mysqlTable("site_announcements", {
  id: int("id").autoincrement().primaryKey(),
  messageBn: varchar("messageBn", { length: 300 }).notNull(),
  messageEn: varchar("messageEn", { length: 300 }),
  linkUrl: varchar("linkUrl", { length: 500 }),
  color: varchar("color", { length: 7 }).default("#0d5c56").notNull(),
  enabled: int("enabled").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteAnnouncement = typeof siteAnnouncements.$inferSelect;
export type InsertSiteAnnouncement = typeof siteAnnouncements.$inferInsert;

/** Singleton draft/published payload for the owner-only Site Builder. Image bytes stay in S3; MySQL stores JSON content and references. */
export const siteBuilderStates = mysqlTable("site_builder_states", {
  id: int("id").autoincrement().primaryKey(),
  draftJson: text("draftJson").notNull(),
  publishedJson: text("publishedJson"),
  heroTitleBn: varchar("heroTitleBn", { length: 255 }),
  heroTitleEn: varchar("heroTitleEn", { length: 255 }),
  heroSubtitleBn: text("heroSubtitleBn"),
  heroSubtitleEn: text("heroSubtitleEn"),
  whatsappNumber: varchar("whatsappNumber", { length: 40 }),
  updatedBy: varchar("updatedBy", { length: 128 }).notNull().default("Primary Owner"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteBuilderState = typeof siteBuilderStates.$inferSelect;
export type InsertSiteBuilderState = typeof siteBuilderStates.$inferInsert;

/** Normalized owner-managed country records. Draft text is explicitly bilingual; published content is emitted from the state snapshot. */
export const siteBuilderCountries = mysqlTable(
  "site_builder_countries",
  {
    id: int("id").autoincrement().primaryKey(),
    code: varchar("code", { length: 32 }).notNull(),
    titleBn: varchar("titleBn", { length: 160 }).notNull(),
    titleEn: varchar("titleEn", { length: 160 }).notNull(),
    descriptionBn: text("descriptionBn").notNull(),
    descriptionEn: text("descriptionEn").notNull(),
    imageUrl: text("imageUrl"),
    visible: int("visible").default(1).notNull(),
    displayOrder: int("displayOrder").default(0).notNull(),
    updatedBy: varchar("updatedBy", { length: 128 }).notNull().default("Primary Owner"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    codeUnique: uniqueIndex("site_builder_countries_code_idx").on(table.code),
  }),
);

export type SiteBuilderCountry = typeof siteBuilderCountries.$inferSelect;
export type InsertSiteBuilderCountry = typeof siteBuilderCountries.$inferInsert;

/** Real owner-managed Bangladesh tourist destinations; image bytes remain in managed storage. */
export const touristPlaces = mysqlTable("tourist_places", {
  id: int("id").autoincrement().primaryKey(),
  nameBn: varchar("nameBn", { length: 180 }).notNull(),
  nameEn: varchar("nameEn", { length: 180 }).notNull(),
  descBn: varchar("descBn", { length: 420 }).notNull(),
  descEn: varchar("descEn", { length: 420 }).notNull(),
  imageUrl: text("imageUrl"),
  galleryJson: text("galleryJson"),
  category: mysqlEnum("category", ["সমুদ্র", "পাহাড়", "ঐতিহাসিক", "ধর্মীয়", "প্রকৃতি"]).notNull(),
  location: varchar("location", { length: 180 }).notNull(),
  mapUrl: text("mapUrl"),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TouristPlace = typeof touristPlaces.$inferSelect;
export type InsertTouristPlace = typeof touristPlaces.$inferInsert;

/** Real owner-managed Bangladesh–India land border guidance; text only and bilingual. */
export const borderPorts = mysqlTable("border_ports", {
  id: int("id").autoincrement().primaryKey(),
  nameBn: varchar("nameBn", { length: 180 }).notNull(),
  nameEn: varchar("nameEn", { length: 180 }).notNull(),
  locationBn: varchar("locationBn", { length: 180 }).notNull(),
  locationEn: varchar("locationEn", { length: 180 }).notNull(),
  bangladeshAddressBn: varchar("bangladeshAddressBn", { length: 420 }),
  bangladeshAddressEn: varchar("bangladeshAddressEn", { length: 420 }),
  indiaCounterpartBn: varchar("indiaCounterpartBn", { length: 180 }),
  indiaCounterpartEn: varchar("indiaCounterpartEn", { length: 180 }),
  infoBn: varchar("infoBn", { length: 420 }).notNull(),
  infoEn: varchar("infoEn", { length: 420 }).notNull(),
  officialSourceUrl: text("officialSourceUrl"),
  officialSourceLabelBn: varchar("officialSourceLabelBn", { length: 180 }),
  officialSourceLabelEn: varchar("officialSourceLabelEn", { length: 180 }),
  mapUrl: text("mapUrl"),
  imageUrl: text("imageUrl"),
  galleryJson: text("galleryJson"),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BorderPort = typeof borderPorts.$inferSelect;
export type InsertBorderPort = typeof borderPorts.$inferInsert;

/**
 * Owner-managed transport and India-travel guidance. Official sources are kept
 * explicit so public cards remain informational and never imply immigration
 * authority, eligibility, fees, operating hours, or guaranteed entry.
 */
export const transportIndiaGuides = mysqlTable("transport_india_guides", {
  id: int("id").autoincrement().primaryKey(),
  kind: mysqlEnum("kind", ["india_travel", "transport"]).notNull().default("india_travel"),
  titleBn: varchar("titleBn", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  descriptionBn: varchar("descriptionBn", { length: 600 }).notNull(),
  descriptionEn: varchar("descriptionEn", { length: 600 }).notNull(),
  checklistBn: text("checklistBn"),
  checklistEn: text("checklistEn"),
  officialUrl: text("officialUrl").notNull(),
  officialLabelBn: varchar("officialLabelBn", { length: 180 }).notNull(),
  officialLabelEn: varchar("officialLabelEn", { length: 180 }).notNull(),
  iconName: varchar("iconName", { length: 48 }).notNull().default("Landmark"),
  iconImageUrl: varchar("iconImageUrl", { length: 1200 }),
  coverImageUrl: text("coverImageUrl"),
  sourceName: varchar("sourceName", { length: 180 }).notNull(),
  lastVerifiedAt: timestamp("lastVerifiedAt"),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TransportIndiaGuide = typeof transportIndiaGuides.$inferSelect;
export type InsertTransportIndiaGuide = typeof transportIndiaGuides.$inferInsert;

/** Owner-managed foreign embassy contacts in Dhaka; public records retain their official source URL. */
export const embassies = mysqlTable("embassies", {
  id: int("id").autoincrement().primaryKey(),
  countryCode: varchar("countryCode", { length: 3 }).notNull(),
  countryNameBn: varchar("countryNameBn", { length: 120 }).notNull(),
  countryNameEn: varchar("countryNameEn", { length: 120 }).notNull(),
  flagEmoji: varchar("flagEmoji", { length: 8 }).notNull(),
  addressBn: varchar("addressBn", { length: 420 }).notNull(),
  addressEn: varchar("addressEn", { length: 420 }).notNull(),
  phone: varchar("phone", { length: 180 }).notNull(),
  websiteUrl: text("websiteUrl").notNull(),
  whatsappUrl: text("whatsappUrl"),
  sourceUrl: text("sourceUrl").notNull(),
  lastVerifiedAt: timestamp("lastVerifiedAt").notNull(),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Embassy = typeof embassies.$inferSelect;
export type InsertEmbassy = typeof embassies.$inferInsert;

/** The single owner-managed education hub shown after the embassy section on the Homepage. */
export const educationHubCards = mysqlTable("education_hub_cards", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  titleBn: varchar("titleBn", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  descriptionBn: varchar("descriptionBn", { length: 420 }).notNull(),
  descriptionEn: varchar("descriptionEn", { length: 420 }).notNull(),
  iconName: varchar("iconName", { length: 48 }).notNull().default("BookOpen"),
  officialUrl: text("officialUrl").notNull(),
  whatsappUrl: text("whatsappUrl"),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EducationHubCard = typeof educationHubCards.$inferSelect;
export type InsertEducationHubCard = typeof educationHubCards.$inferInsert;

/** The owner-managed Bangladesh Bank and financial-services card shown with the public information hubs. */
export const financialServiceCards = mysqlTable("financial_service_cards", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  titleBn: varchar("titleBn", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  descriptionBn: varchar("descriptionBn", { length: 420 }).notNull(),
  descriptionEn: varchar("descriptionEn", { length: 420 }).notNull(),
  disclaimerBn: varchar("disclaimerBn", { length: 420 }).notNull(),
  disclaimerEn: varchar("disclaimerEn", { length: 420 }).notNull(),
  buttonLabelBn: varchar("buttonLabelBn", { length: 180 }).notNull(),
  buttonLabelEn: varchar("buttonLabelEn", { length: 180 }).notNull(),
  iconName: varchar("iconName", { length: 48 }).notNull().default("Landmark"),
  officialUrl: text("officialUrl").notNull(),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FinancialServiceCard = typeof financialServiceCards.$inferSelect;
export type InsertFinancialServiceCard = typeof financialServiceCards.$inferInsert;

/** Owner-managed card metadata for the single Expatriate Media Hub on the Homepage. */
export const mediaHubSettings = mysqlTable("media_hub_settings", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  titleBn: varchar("titleBn", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  descriptionBn: varchar("descriptionBn", { length: 420 }).notNull(),
  descriptionEn: varchar("descriptionEn", { length: 420 }).notNull(),
  disclaimerBn: varchar("disclaimerBn", { length: 420 }).notNull(),
  disclaimerEn: varchar("disclaimerEn", { length: 420 }).notNull(),
  iconName: varchar("iconName", { length: 48 }).notNull().default("Tv"),
  visible: int("visible").default(1).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const mediaHubChannels = mysqlTable("media_hub_channels", {
  id: int("id").autoincrement().primaryKey(),
  categorySlug: varchar("categorySlug", { length: 40 }).notNull(),
  categoryNameBn: varchar("categoryNameBn", { length: 80 }).notNull(),
  categoryNameEn: varchar("categoryNameEn", { length: 80 }).notNull(),
  channelNameBn: varchar("channelNameBn", { length: 120 }).notNull(),
  channelNameEn: varchar("channelNameEn", { length: 120 }).notNull(),
  officialUrl: text("officialUrl").notNull(),
  logoUrl: text("logoUrl"),
  descriptionBn: varchar("descriptionBn", { length: 255 }),
  descriptionEn: varchar("descriptionEn", { length: 255 }),
  isPrime: int("isPrime").default(0).notNull(),
  visible: int("visible").default(1).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MediaHubSetting = typeof mediaHubSettings.$inferSelect;
export type InsertMediaHubSetting = typeof mediaHubSettings.$inferInsert;
export type MediaHubChannel = typeof mediaHubChannels.$inferSelect;
export type InsertMediaHubChannel = typeof mediaHubChannels.$inferInsert;

/** Owner-created civic blog and news posts; image bytes remain in S3, only URLs live here. */
export const siteBlogPosts = mysqlTable("site_blog_posts", {
  id: int("id").autoincrement().primaryKey(),
  titleBn: varchar("titleBn", { length: 220 }).notNull(),
  titleEn: varchar("titleEn", { length: 220 }),
  slug: varchar("slug", { length: 240 }).notNull().unique(),
  excerptBn: varchar("excerptBn", { length: 420 }).notNull(),
  excerptEn: varchar("excerptEn", { length: 420 }),
  contentBn: text("contentBn").notNull(),
  contentEn: text("contentEn"),
  coverImageUrl: text("coverImageUrl"),
  pdfUrl: text("pdfUrl"),
  isPinned: int("isPinned").default(0).notNull(),
  status: mysqlEnum("status", ["draft", "published"]).default("draft").notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteBlogPost = typeof siteBlogPosts.$inferSelect;
export type InsertSiteBlogPost = typeof siteBlogPosts.$inferInsert;

/** Owner-only contact leads. No password, browser fingerprint, or unrelated visitor data is stored. */
export const contactLeads = mysqlTable("contact_leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  mobile: varchar("mobile", { length: 32 }).notNull(),
  email: varchar("email", { length: 320 }),
  subject: varchar("subject", { length: 180 }),
  message: text("message").notNull(),
  source: varchar("source", { length: 64 }).default("contact").notNull(),
  consentAt: timestamp("consentAt"),
  status: mysqlEnum("status", ["new", "reviewed", "closed"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContactLead = typeof contactLeads.$inferSelect;
export type InsertContactLead = typeof contactLeads.$inferInsert;

/** Sanitised operational events for the owner-only Site Logs viewer. */
export const siteOperationalLogs = mysqlTable("site_operational_logs", {
  id: int("id").autoincrement().primaryKey(),
  level: mysqlEnum("level", ["error", "warning", "info"]).default("info").notNull(),
  operation: varchar("operation", { length: 80 }).notNull(),
  message: varchar("message", { length: 500 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SiteOperationalLog = typeof siteOperationalLogs.$inferSelect;
export type InsertSiteOperationalLog = typeof siteOperationalLogs.$inferInsert;

/**
 * Immutable owner-managed public-site snapshots used only for explicit recovery.
 * Passwords, sessions, biometric credentials, user/member data, leads, orders,
 * payments, and file bytes are deliberately outside this restore scope.
 */
export const siteBackupSnapshots = mysqlTable(
  "site_backup_snapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    kind: mysqlEnum("kind", ["scheduled", "manual"]).default("scheduled").notNull(),
    dayKey: varchar("dayKey", { length: 10 }),
    snapshotJson: text("snapshotJson").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("site_backup_snapshots_day_unique").on(table.dayKey)],
);

export type SiteBackupSnapshot = typeof siteBackupSnapshots.$inferSelect;
export type InsertSiteBackupSnapshot = typeof siteBackupSnapshots.$inferInsert;

/**
 * Singleton configuration for the project-level daily recovery snapshot job.
 * The cron task UID is server-owned and is never accepted from public input.
 */
export const siteBackupAutomationSettings = mysqlTable("site_backup_automation_settings", {
  id: int("id").autoincrement().primaryKey(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }).unique(),
  enabled: int("enabled").notNull().default(1),
  lastSuccessfulRunAt: timestamp("last_successful_run_at"),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type SiteBackupAutomationSetting = typeof siteBackupAutomationSettings.$inferSelect;
export type InsertSiteBackupAutomationSetting = typeof siteBackupAutomationSettings.$inferInsert;

/** Owner-configured advertising price cards. Prices are descriptive until a payment provider is connected. */
export const advertiserSlotPrices = mysqlTable("advertiser_slot_prices", {
  id: int("id").autoincrement().primaryKey(),
  slot: mysqlEnum("slot", ["header", "sidebar", "blog"]).notNull().unique(),
  priceBdt: int("priceBdt").notNull().default(0),
  active: int("active").notNull().default(1),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const advertiserOrders = mysqlTable("advertiser_orders", {
  id: int("id").autoincrement().primaryKey(),
  accessToken: varchar("accessToken", { length: 72 }).notNull().unique(),
  businessName: varchar("businessName", { length: 180 }).notNull(),
  contactName: varchar("contactName", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  slot: mysqlEnum("slot", ["header", "sidebar", "blog"]).notNull(),
  adTitleBn: varchar("adTitleBn", { length: 160 }).notNull(),
  adTitleEn: varchar("adTitleEn", { length: 160 }),
  adUrl: varchar("adUrl", { length: 500 }).notNull(),
  imageUrl: text("imageUrl"),
  priceBdt: int("priceBdt").notNull().default(0),
  invoiceNumber: varchar("invoiceNumber", { length: 64 }).notNull().unique(),
  status: mysqlEnum("status", ["submitted", "approved", "rejected", "awaiting_payment", "paid", "live", "expired"]).notNull().default("submitted"),
  decisionNote: varchar("decisionNote", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const adClickEvents = mysqlTable("ad_click_events", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const investorLeads = mysqlTable("investor_leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  organisation: varchar("organisation", { length: 180 }),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["new", "reviewed", "closed"]).notNull().default("new"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InsertAdvertiserSlotPrice = typeof advertiserSlotPrices.$inferInsert;
export type InsertAdvertiserOrder = typeof advertiserOrders.$inferInsert;
export type InsertInvestorLead = typeof investorLeads.$inferInsert;
