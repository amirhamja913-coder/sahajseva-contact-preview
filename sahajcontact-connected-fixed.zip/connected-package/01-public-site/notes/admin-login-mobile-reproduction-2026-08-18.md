# Admin login mobile reproduction — 2026-08-18

The user-provided screenshot shows the `/admin/dashboard` access gate, but tapping the owner login button appears to do nothing. The browser title in the screenshot remains the public homepage title, suggesting a stale document or cached app shell may be involved.

Local source inspection confirms the button calls `startLogin("/admin/dashboard")`, and `startLogin` accepts an optional return path, writes the OAuth nonce cookie, and navigates to `${VITE_OAUTH_PORTAL_URL}/app-auth`.

The production browser reproduction loaded the admin route but remained on the Bengali loading skeleton in the sandbox browser. No browser console output was reported. The service worker uses cache version `sahajseva-pwa-v4` and currently caches the public manifest in its app shell, so the next fix should bump the cache version, include the admin manifest, and make the login action resilient to stale mobile caches.

The screenshot's public title and non-responsive login behavior are being treated as a route/cache compatibility issue rather than an access-policy change. The owner restriction remains `amirhamja913@gmail.com`.


## Post-fix verification

The mobile preview at 390×844 rendered the admin-specific app-lock screen, confirming that `/admin/dashboard` is now using the admin experience rather than the public install guide. The production build completed successfully and the full Vitest suite passed with 203 tests. The login button now has a visible loading state and an accessible error alert if the OAuth navigation cannot start.
