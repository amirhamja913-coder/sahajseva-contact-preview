from pathlib import Path
from urllib.parse import urljoin
import re
import requests
from bs4 import BeautifulSoup

sites = {
    "rab": "https://www.rab.gov.bd/",
    "cid": "https://www.cid.gov.bd/",
    "special_branch": "https://specialbranch.gov.bd/",
    "dmp": "https://dmp.gov.bd/",
    "fire_service": "https://fireservice.gov.bd/",
    "ansar_vdp": "https://ansarvdp.gov.bd/",
    "coast_guard": "https://coastguard.gov.bd/",
    "navy": "https://www.navy.mil.bd/",
    "air_force": "https://baf.mil.bd/",
    "police": "https://police.portal.gov.bd/",
    "army": "https://www.army.mil.bd/",
}

out = []
for name, url in sites.items():
    out.append(f"### {name} {url}")
    try:
        response = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 (compatible; SahajContact research)"},
            timeout=20,
            verify=False,
        )
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        candidates = []
        for tag in soup.find_all(["img", "link"]):
            value = tag.get("src") or tag.get("href") or ""
            if not value:
                continue
            absolute = urljoin(response.url, value)
            lowered = absolute.lower()
            if any(term in lowered for term in ("logo", "emblem", "seal", "crest", "header")):
                if absolute not in candidates:
                    candidates.append(absolute)
        out.extend(candidates[:30] or [f"HTTP {response.status_code}; no logo-like references found"])
    except Exception as exc:
        out.append(f"ERROR: {type(exc).__name__}: {exc}")
    out.append("")

Path("/home/ubuntu/sahajseva-contact-preview/notes/official-logo-url-scan-v2.txt").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
