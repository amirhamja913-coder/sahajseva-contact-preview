# Gallery repair source notes

## Confirmed broken URLs
- Durga Puja URL: https://images.unsplash.com/photo-1603228254117-e9a3d6d3c7d6?auto=format&fit=crop&w=1200&q=80
- Sundarbans URL: https://images.unsplash.com/photo-1596401507720-dbe9e697d3b1?auto=format&fit=crop&w=1200&q=80
- HTTP check on 2026-08-16: both returned status 404, content type text/html, size 29 bytes.
- Eid Unsplash URL returned status 200 and remains usable.

## Verified replacement candidate
- Source page: https://commons.wikimedia.org/wiki/File:Durga_Puja_celebrations_in_Bangladesh.jpg
- Original file: https://upload.wikimedia.org/wikipedia/commons/3/38/Durga_Puja_celebrations_in_Bangladesh.jpg
- Title: Durga Puja celebrations in Bangladesh.jpg
- Creator: Naren marik
- License: Creative Commons Attribution-ShareAlike 4.0 International
- Dimensions: 1600 x 1200; JPEG; 305 KB

## Sundarbans research sources
- Category: https://commons.wikimedia.org/wiki/Category:Sundarbans_(Bangladesh)
- Candidate file pages discovered:
  - https://commons.wikimedia.org/wiki/File:Bangladesh%27s_Sundarbans_at_dawn_(2398829081).jpg
  - https://commons.wikimedia.org/wiki/File:Sundarban,_Bangladesh.png
  - https://commons.wikimedia.org/wiki/File:Sundarban_(6).jpg
  - https://commons.wikimedia.org/wiki/File:Sundarban_(11).jpg
  - https://commons.wikimedia.org/wiki/File:Wilderness_of_sundarban.jpg

## Intended fix
Replace the two dead external Unsplash URLs with managed webdev storage assets, preserving bilingual captions and adding visible source/license attribution in gallery metadata.
