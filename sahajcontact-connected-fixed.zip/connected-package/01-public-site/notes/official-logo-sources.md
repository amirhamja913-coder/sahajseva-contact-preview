# Official logo source research

## Bangladesh Police
- Official portal: https://police.portal.gov.bd/
- Browser page title: হোম | পুলিশ হেডকোয়ার্টার্স, বাংলাদেশ পুলিশ
- Official page HTML exposes the image asset: `/site-assets/images/logo.png`, which is the police headquarters logo shown in the public header.
- Screenshot/visual inspection confirms the header logo is a Bangladesh Police emblem with the text “পুলিশ হেডকোয়ার্টার্স, বাংলাদেশ পুলিশ”.
- Use the official portal URL as the source/attribution reference if the asset is downloaded and managed for the site.

## Implementation scope observed
The law-enforcement page currently renders generic Lucide icons in cards for: 999 emergency, Bangladesh Police, Online Police Service, Cyber Security, RAB, CID, Special Branch, DMP, Fire Service, Ansar-VDP, Coast Guard, Narcotics Control, BGB, Bangladesh Army, Bangladesh Navy, and Bangladesh Air Force. The relevant render block is in `client/src/components/UtilityAndExpatriateSections.tsx` lines 727–873.

## Bangladesh Army
- Official portal: https://www.army.mil.bd/
- Browser page title: Bangladesh Army
- The official site is an active government/armed-forces portal and can be used as the attribution/source reference for the Bangladesh Army emblem.
- The public page uses image assets under the site's `UserFile/` paths; the exact header emblem path should be extracted from the page HTML if needed. The page identity itself is verified through the official domain and title.

## Border Guard Bangladesh (BGB)
- Commons file page: https://commons.wikimedia.org/wiki/File:%E0%A6%AC%E0%A6%B0%E0%A7%8D%E0%A6%A1%E0%A6%BE%E0%A6%B0_%E0%A6%97%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%A1_%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%E0%A7%87%E0%A6%B0_%E0%A6%AE%E0%A6%A8%E0%A7%8B%E0%A6%97%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%AE.svg
- The page identifies the file as the Border Guard Bangladesh monogram and states the main source attribution is the official BGB website (PDF).
- Reuse information on the page: public domain; simple geometric/text logo and/or expired government-work protection according to the Commons description.
- The displayed emblem is a red circular BGB monogram with lotus, laurel, crossed rifles, and Bengali ribbon text.

## 2026-08-16 source verification
- Wikimedia Commons file `Bangladesh Police Emblem.svg` identifies the Bangladesh Police emblem and marks the work as public domain under the Bangladesh government-work/copyright explanation; source page: https://commons.wikimedia.org/wiki/File:Bangladesh_Police_Emblem.svg
- The official Bangladesh Army site is https://www.army.mil.bd/ and visibly identifies itself as the Bangladesh Army official website. Its header displays the Army identity/emblem; use the official site as the organization reference when selecting the managed emblem asset.

## Additional verified emblem sources
- Bangladesh Police emblem file: https://commons.wikimedia.org/wiki/File:Bangladesh_Police_Emblem.svg; original media URL: https://upload.wikimedia.org/wikipedia/commons/7/75/Bangladesh_Police_Emblem.svg. Commons states it was redrawn from the Bangladesh Police source `https://www.police.gov.bd/storage/upload/logo/en.png`, identifies it as official insignia, and provides a Bangladesh public-domain rationale with a trademark/insignia-use caution.
- BGB monogram file page: https://commons.wikimedia.org/wiki/File:%E0%A6%AC%E0%A6%B0%E0%A7%8D%E0%A6%A1%E0%A6%BE%E0%A6%B0_%E0%A6%97%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%A1_%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%E0%A7%87%E0%A6%B0_%E0%A6%AE%E0%A6%A8%E0%A7%8B%E0%A6%97%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%AE.svg; original media URL: https://upload.wikimedia.org/wikipedia/commons/b/b6/%E0%A6%AC%E0%A6%B0%E0%A7%8D%E0%A6%A1%E0%A6%BE%E0%A6%B0_%E0%A6%97%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%A1_%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%E0%A7%87%E0%A6%B0_%E0%A6%AE%E0%A6%A8%E0%A7%8B%E0%A6%97%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%AE.svg. The page attributes the emblem to the official BGB source but currently shows a deletion nomination and contested public-domain claims; do not use this file without a rights review or a directly sourced official asset.
- Bangladesh Air Force roundel: https://commons.wikimedia.org/wiki/File:Roundel_of_Bangladesh.svg; original media URL: https://upload.wikimedia.org/wikipedia/commons/7/7b/Roundel_of_Bangladesh.svg. Commons identifies it as the official Bangladesh Air Force roundel and marks it public domain as simple geometry, while noting official-insignia restrictions.
- Commons military category identifies Bangladesh Army, Bangladesh Navy, Bangladesh Air Force, and Bangladesh Coast Guard as Bangladesh military organizations: https://commons.wikimedia.org/wiki/Category:Military_of_Bangladesh.

## Fire Service source verification
- Wikimedia Commons file page: https://commons.wikimedia.org/wiki/File:Flag_of_Bangladesh_Fire_Service_%26_Civil_Defence.png
- Original media URL: https://upload.wikimedia.org/wikipedia/commons/a/a8/Flag_of_Bangladesh_Fire_Service_%26_Civil_Defence.png
- The file page identifies the Bangladesh Fire Service & Civil Defence emblem/flag and marks it CC0 1.0 Universal Public Domain Dedication.

## Bangladesh Navy source verification
- Wikimedia Commons file page: https://commons.wikimedia.org/wiki/File:Emblem_of_the_Bangladesh_Navy.svg
- The page identifies the current Bangladesh Navy emblem and lists navy.mil.bd as the source.
- The file page describes public-domain status under Bangladesh government-work/copyright terms and notes possible insignia restrictions.
- Original media URL is available from the Commons page's Original file link and should be downloaded into managed storage rather than hotlinked.

## Bangladesh Army source verification
- Wikimedia Commons file page: https://commons.wikimedia.org/wiki/File:Flag_of_the_Bangladesh_Army.svg
- The page identifies the Bangladesh Army flag/monogram and links the source identity to the Bangladesh Army.
- License shown: Creative Commons Attribution-ShareAlike 2.5 Generic; retain attribution and license reference in the site metadata.
- The page provides an Original file link for managed download.

## 2026-08-16 additional official-domain findings
- Official RAB domain verified by search: https://www.rab.gov.bd/ . The site exposes a public brand label `RABLogo`, but the host was intermittently unavailable to direct extraction; do not hotlink an unverified RAB asset.
- Official Special Branch domain verified: https://specialbranch.gov.bd/ . Direct page scan exposes `/img/logo1.jpg`; use the official domain as the source reference if managed.
- Official CID domain verified: https://www.cid.gov.bd/ . The page identifies itself as “Criminal Investigation Department Bangladesh Police” and exposes a public `Logo` link; retain the official CID domain as the source reference.
- Official DMP domain verified: https://dmp.gov.bd/ . Direct page scan exposes `https://dmp.gov.bd/wp-content/uploads/2017/08/dmp_logo-1-1.png` as the DMP logo asset.
- Official Bangladesh Army domain verified: https://www.army.mil.bd/ . Use a managed emblem asset with source attribution rather than hotlinking.
- Search/HTTP retrieval note: the official RAB host returned intermittent TLS/connection failures during this scan, so an official RAB logo must be sourced from a stable verified file page or omitted in favor of a clearly labeled official-domain fallback; do not fabricate an insignia.

## RAB source follow-up
- The official RAB page remains intermittently unavailable to direct browsing: https://www.rab.gov.bd/ .
- A traceable Commons source exists for RAB insignia: https://commons.wikimedia.org/wiki/File:Rapid_Action_Battalion_Force_Ranks_%26_Insignia.png . Search metadata identifies the file as a Rapid Action Battalion ranks/insignia image and marks it CC0 1.0 Universal Public Domain Dedication. Use only the emblem crop if it is visually clear; retain the Commons source link in attribution metadata.
- Avoid third-party logo aggregators as the primary source, because they do not establish official ownership or reuse terms.

## Commons original URLs verified for managed download
- Bangladesh Army flag/monogram: https://upload.wikimedia.org/wikipedia/commons/c/cb/Flag_of_the_Bangladesh_Army.svg; Commons file page https://commons.wikimedia.org/wiki/File:Flag_of_the_Bangladesh_Army.svg; CC BY-SA 2.5, with official-insignia restrictions noted.
- Bangladesh Navy emblem: https://upload.wikimedia.org/wikipedia/commons/6/6c/Emblem_of_the_Bangladesh_Navy.svg; Commons file page https://commons.wikimedia.org/wiki/File:Emblem_of_the_Bangladesh_Navy.svg; source identified as navy.mil.bd, public-domain rationale with insignia restrictions.
- Bangladesh Air Force roundel: https://upload.wikimedia.org/wikipedia/commons/7/7b/Roundel_of_Bangladesh.svg; Commons file page https://commons.wikimedia.org/wiki/File:Roundel_of_Bangladesh.svg; simple-geometry public-domain rationale with insignia restrictions.
- Rapid Action Battalion source image: https://upload.wikimedia.org/wikipedia/commons/6/6e/Rapid_Action_Battalion_Force_Ranks_%26_Insignia.png; Commons file page https://commons.wikimedia.org/wiki/File:Rapid_Action_Battalion_Force_Ranks_%26_Insignia.png; source identified as rab.gov.bd/about_rank.php and marked CC0. Use only a clear emblem crop if visually appropriate.

## RAB managed-asset inspection
- Source media URL: https://upload.wikimedia.org/wikipedia/commons/6/6e/Rapid_Action_Battalion_Force_Ranks_%26_Insignia.png
- Commons file page: https://commons.wikimedia.org/wiki/File:Rapid_Action_Battalion_Force_Ranks_%26_Insignia.png
- Search/source notes identify the file as Rapid Action Battalion ranks and insignia, marked CC0, with source attributed to rab.gov.bd/about_rank.php.
- Downloaded source dimensions: 3280 × 3182 PNG. Use only a clearly identifiable emblem crop if visual inspection confirms it is appropriate; do not present a generic or fabricated mark as an official logo.

## Managed asset visual review
- Downloaded official-domain assets resolved as image files for Special Branch, DMP, Fire Service, BGB, and DNC. The DMP source is a horizontal official wordmark; the card icon treatment will use its left emblem crop for legibility. The Fire Service source is a wide orange flag with the centered official emblem; the managed card asset will use a centered square crop. BGB and DNC official-domain logo PNGs are compact 77×78 government marks. Special Branch resolves as a 100×100 official badge.
- Police, Army, Navy, and Air Force will use the verified Commons/official insignia sources saved above. The RAB ranks sheet was visually reviewed and is not a standalone logo, so it will not be mislabeled or presented as one; the RAB card will retain a clearly labeled official-portal badge treatment until a directly verifiable standalone RAB logo can be safely managed.

## 2026-08-16 managed-source visual confirmation
The stable official-domain endpoints were verified as follows: police.portal.gov.bd/site-assets/images/logo.png, fireservice.gov.bd/site-assets/images/logo.png, ansarvdp.gov.bd/site-assets/images/logo.png, and coastguard.gov.bd/site-assets/images/logo.png all return 77×78 PNG government marks from the respective official domains; dmp.gov.bd/wp-content/uploads/2017/08/dmp_logo-1-1.png returns the DMP wordmark; specialbranch.gov.bd/img/logo1.jpg returns the Special Branch badge. The compact 77×78 official-domain marks visually use the Bangladesh government seal, so they are treated as official agency portal marks rather than claimed custom insignia. The Fire Service Commons asset remains the clearer agency-specific emblem and is retained for the Fire Service card. The RAB Commons ranks sheet contains rank tabs, not a standalone RAB logo, and is therefore not used as a logo.
