from pathlib import Path
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

sites = {
    "rab": "https://www.rab.gov.bd/",
    "cid": "https://www.cid.gov.bd/",
    "bgb": "https://bgb.gov.bd/",
    "dnc": "https://dnc.gov.bd/",
    "navy": "https://www.navy.mil.bd/",
    "air_force": "https://baf.mil.bd/",
}

out = []
for name, url in sites.items():
    out.append(f"### {name} {url}")
    candidates = [
        urljoin(url, "/site-assets/images/logo.png"),
        urljoin(url, "/site-assets/images/logo.jpg"),
        urljoin(url, "/images/logo.png"),
        urljoin(url, "/img/logo.png"),
    ]
    try:
        response = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (compatible; SahajContact research)"}, timeout=15, verify=False)
        out.append(f"PAGE {response.status_code} {response.url}")
        if response.ok:
            soup = BeautifulSoup(response.text, "html.parser")
            for tag in soup.find_all(["img", "link"]):
                value = tag.get("src") or tag.get("href") or ""
                if value:
                    absolute = urljoin(response.url, value)
                    if any(term in absolute.lower() for term in ("logo", "emblem", "seal", "crest")) and absolute not in candidates:
                        candidates.append(absolute)
    except Exception as exc:
        out.append(f"PAGE ERROR {type(exc).__name__}: {exc}")
    for candidate in candidates:
        try:
            head = requests.get(candidate, headers={"User-Agent": "Mozilla/5.0 (compatible; SahajContact research)"}, timeout=12, verify=False, stream=True)
            out.append(f"{head.status_code} {head.headers.get('content-type', '')} {candidate}")
            head.close()
        except Exception as exc:
            out.append(f"ASSET ERROR {type(exc).__name__}: {candidate} :: {exc}")
    out.append("")

Path("/home/ubuntu/sahajseva-contact-preview/notes/probe-agency-logos.txt").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
