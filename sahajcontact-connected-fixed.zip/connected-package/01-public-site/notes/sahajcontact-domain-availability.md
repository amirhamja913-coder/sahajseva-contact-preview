# sahajcontact.com availability check

Checked on 2026-08-17.

- Direct website check: https://www.sahajcontact.com returned `ERR_NAME_NOT_RESOLVED` from the browser, so the hostname does not currently resolve in the checking environment.
- Google DNS-over-HTTPS query: https://dns.google/resolve?name=sahajcontact.com&type=NS returned `Status: 3` (NXDOMAIN) and no NS answer for the domain.
- Verisign RDAP endpoint: https://rdap.verisign.com/com/v1/domain/sahajcontact.com was attempted but stalled in this environment; no authoritative RDAP response was obtained.
- RDAP mirror: https://rdap.org/domain/sahajcontact.com redirected/timed out in this environment; no authoritative response was obtained.
- Public WHOIS page: https://www.whois.com/whois/sahajcontact.com loaded, but the saved page contained lookup scripts and generic registered/available offer text rather than a definitive rendered status.
- Search results only returned generic registrar lookup pages and did not provide a domain-specific availability result.

Conclusion for user-facing report: the domain appears unregistered/not delegated because it returns NXDOMAIN, but purchase availability must be confirmed in a live registrar checkout/search before buying. No purchase or form submission was performed.

## Latest refresh

A fresh check was run after the previous lookup.

- Google DNS A query: `Status: 3` (NXDOMAIN), with no A answer.
- Google DNS NS query: `Status: 3` (NXDOMAIN), with no NS answer.
- Verisign RDAP: timed out again; the curl wrapper reported HTTP_STATUS=404 after the failed request, so no usable authoritative domain record was received.
- Public WHOIS page: loaded but returned no definitive domain-specific rendered status in the extracted text.

Updated conclusion: the domain still has no public DNS delegation and appears likely unregistered, but a live registrar search is still required for final availability confirmation. No purchase or checkout was initiated.
