from pathlib import Path
import re
import requests

sites = [
    "https://www.rab.gov.bd/",
    "https://www.cid.gov.bd/",
    "https://specialbranch.gov.bd/",
    "https://dmp.gov.bd/",
    "https://fireservice.gov.bd/",
    "https://ansarvdp.gov.bd/",
    "https://coastguard.gov.bd/",
    "https://www.navy.mil.bd/",
    "https://baf.mil.bd/",
    "https://police.portal.gov.bd/",
]
pattern = re.compile(r'''(?:https?:)?[^\"'\s<>]+(?:logo|Logo|LOGO|emblem|Emblem|seal|Seal)[^\"'\s<>]*\.(?:png|svg|jpg|jpeg|webp)''', re.I)
lines = []
for site in sites:
    lines.append(f"### {site}")
    try:
        response = requests.get(site, headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
        response.raise_for_status()
        matches = []
        for match in pattern.findall(response.text):
            if match not in matches:
                matches.append(match)
        lines.extend(matches[:20] or [f"HTTP {response.status_code}; no logo-like asset found"])
    except Exception as exc:
        lines.append(f"ERROR: {exc}")
    lines.append("")
Path("/home/ubuntu/sahajseva-contact-preview/notes/official-logo-url-scan.txt").write_text("\n".join(lines), encoding="utf-8")
print("\n".join(lines))
