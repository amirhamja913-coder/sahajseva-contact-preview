import fs from "node:fs/promises";
import mysql from "mysql2/promise";

const sqlPath = "/home/ubuntu/travel_seed.sql";
const connectionUrl = process.env.DATABASE_URL;
if (!connectionUrl) throw new Error("DATABASE_URL is not available");

const connection = await mysql.createConnection(connectionUrl);
try {
  const [rows] = await connection.query(
    "SELECT (SELECT COUNT(*) FROM tourist_places) AS touristCount, (SELECT COUNT(*) FROM border_ports) AS borderCount, (SELECT COUNT(*) FROM embassies) AS embassyCount"
  );
  const current = rows[0];
  if (Number(current.touristCount) > 0 || Number(current.borderCount) > 0 || Number(current.embassyCount) > 0) {
    throw new Error(`Refusing to seed non-empty travel tables: ${JSON.stringify(current)}`);
  }

  const source = await fs.readFile(sqlPath, "utf8");
  const statements = source
    .split(/(?=INSERT INTO `(?:tourist_places|border_ports|embassies)`)/g)
    .map((statement) => statement.trim())
    .filter((statement) => statement.startsWith("INSERT INTO"));
  if (statements.length !== 3) throw new Error(`Expected 3 INSERT statements, found ${statements.length}`);

  await connection.beginTransaction();
  for (const statement of statements) await connection.query(statement);
  await connection.commit();

  const [after] = await connection.query(
    "SELECT (SELECT COUNT(*) FROM tourist_places) AS touristCount, (SELECT COUNT(*) FROM border_ports) AS borderCount, (SELECT COUNT(*) FROM embassies) AS embassyCount"
  );
  console.log(JSON.stringify({ seeded: true, counts: after[0] }));
} catch (error) {
  try { await connection.rollback(); } catch {}
  throw error;
} finally {
  await connection.end();
}
