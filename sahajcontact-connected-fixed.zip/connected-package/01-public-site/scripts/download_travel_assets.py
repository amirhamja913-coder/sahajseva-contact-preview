import json
import re
from pathlib import Path
from urllib.parse import urlparse

import requests

MANIFEST = Path('/home/ubuntu/travel_assets.json')
OUTPUT = Path('/home/ubuntu/webdev-static-assets/sahajcontact-travel')
OUTPUT.mkdir(parents=True, exist_ok=True)
manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
headers = {'User-Agent': 'SahajContact/1.0 (public civic portal asset preparation)'}

for index, place in enumerate(manifest, start=1):
    local_images = []
    for image_index, image in enumerate(place['images'][:3], start=1):
        extension = Path(urlparse(image['url']).path).suffix.lower() or '.jpg'
        if extension not in {'.jpg', '.jpeg', '.png', '.webp'}:
            extension = '.jpg'
        filename = f"{index:02d}-{image_index:02d}{extension}"
        destination = OUTPUT / filename
        if not destination.exists() or destination.stat().st_size < 1000:
            image_url = image['url'].replace('/1200px-', '/960px-', 1).replace('/800px-', '/960px-', 1)
            response = requests.get(image_url, headers=headers, timeout=60)
            response.raise_for_status()
            image['url'] = image_url
            destination.write_bytes(response.content)
        local_images.append({'filename': filename, 'sourceUrl': image['sourceUrl'], 'title': image.get('title', '')})
    place['localImages'] = local_images

(Path('/home/ubuntu/travel_assets_local.json')).write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
(Path('/home/ubuntu/webdev-static-assets/sahajcontact-travel/ATTRIBUTION.json')).write_text(json.dumps([
    {'nameEn': p['nameEn'], 'nameBn': p['nameBn'], 'images': p['localImages']} for p in manifest
], ensure_ascii=False, indent=2), encoding='utf-8')
print(f'Downloaded/verified {sum(len(p["localImages"]) for p in manifest)} gallery assets for {len(manifest)} destinations')
