import { listAccessibleGa4Properties } from "../server/ga4Live.ts";

const properties = await listAccessibleGa4Properties();
for (const property of properties) {
  console.log(`${property.propertyId}\t${property.displayName}`);
}
