import json
from datetime import date
from pathlib import Path

MANIFEST = Path("/home/ubuntu/travel_assets.json")
OUTPUT = Path("/home/ubuntu/travel_seed.sql")


def sql(value):
    if value is None:
        return "NULL"
    return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"


def normalize_image_url(url: str) -> str:
    return (
        url.replace("/1200px-", "/960px-")
        .replace("/800px-", "/960px-")
        .replace("/60px-", "/960px-")
    )


def tourist_description(name_bn, name_en, category, location_bn, location_en):
    category_en = {
        "সমুদ্র": "sea",
        "পাহাড়": "hill",
        "ঐতিহাসিক": "historical",
        "ধর্মীয়": "religious",
        "প্রকৃতি": "nature",
    }.get(category, "travel")
    return (
        f"{name_bn} বাংলাদেশের একটি {category} ভ্রমণস্থল। {location_bn} এলাকায় অবস্থিত এই গন্তব্যে যাওয়ার আগে আবহাওয়া, স্থানীয় নির্দেশনা, প্রবেশ-নিয়ম ও পরিবহন তথ্য যাচাই করুন.",
        f"{name_en} is a {category_en} destination in Bangladesh. Located in {location_en}, it is best planned with current weather, local guidance, entry rules, and transport information checked before departure.",
    )


EMBASSIES = [
    ("USA", "যুক্তরাষ্ট্র", "United States", "🇺🇸", "মাদানী অ্যাভিনিউ, বারিধারা, ঢাকা-১২১২", "Madani Avenue, Baridhara, Dhaka-1212", "+880 2 55662000", "https://bd.usembassy.gov/", "https://bd.usembassy.gov/sections-offices/"),
    ("IND", "ভারত", "India", "🇮🇳", "প্লট ১-৩, পার্ক রোড, বারিধারা, ঢাকা-১২১২", "Plot 1-3, Park Road, Baridhara, Dhaka-1212", "+880 2 55067301-308", "https://hcidhaka.gov.in/", "https://igod.gov.in/int/20/missions_abroad"),
    ("GBR", "যুক্তরাজ্য", "United Kingdom", "🇬🇧", "ইউনাইটেড নেশনস রোড, বারিধারা, ঢাকা-১২১২", "United Nations Road, Baridhara, Dhaka-1212", "+880 1713388965", "https://www.gov.uk/world/organisations/british-high-commission-dhaka", "https://www.gov.uk/world/organisations/british-high-commission-dhaka/office/british-high-commission-dhaka"),
    ("CHN", "চীন", "China", "🇨🇳", "১-৩, দূতাবাস রোড, বারিধারা, ঢাকা-১২১২", "1-3 Embassy Road, Baridhara, Dhaka-1212", "+880 2 58815680", "http://bd.china-embassy.gov.cn/eng/", "http://bd.china-embassy.gov.cn/eng/"),
    ("JPN", "জাপান", "Japan", "🇯🇵", "৫, দ্যুতাবাস রোড, বারিধারা, ঢাকা-১২১২", "5, Dutabash Road, Baridhara, Dhaka-1212", "+880 2 222260010", "https://www.bd.emb-japan.go.jp/itprtop_en/index.html", "https://www.bd.emb-japan.go.jp/itprtop_en/index.html"),
    ("KOR", "দক্ষিণ কোরিয়া", "South Korea", "🇰🇷", "৪, মাদানী অ্যাভিনিউ, বারিধারা, ঢাকা-১২১২", "4, Madani Avenue, Baridhara, Dhaka-1212", "+880 2 5881305", "https://overseas.mofa.go.kr/bd-en/index.do", "https://overseas.mofa.go.kr/bd-en/index.do"),
    ("DEU", "জার্মানি", "Germany", "🇩🇪", "১১, মাদানী অ্যাভিনিউ, বারিধারা, ঢাকা-১২১২", "11, Madani Avenue, Baridhara, Dhaka-1212", "+880 2 55663700", "https://dhaka.diplo.de/bd-en", "https://dhaka.diplo.de/bd-en"),
    ("FRA", "ফ্রান্স", "France", "🇫🇷", "১৮, মাদানী অ্যাভিনিউ, বারিধারা, ঢাকা-১২১২", "18, Madani Avenue, Baridhara, Dhaka-1212", "+880 2 5881226", "https://bd.ambafrance.org/", "https://bd.ambafrance.org/"),
    ("ITA", "ইতালি", "Italy", "🇮🇹", "রোড ৭৪, গুলশান-২, ঢাকা-১২১২", "Road 74, Gulshan-2, Dhaka-1212", "+880 2 8822781", "https://ambdhaka.esteri.it/en/", "https://ambdhaka.esteri.it/en/"),
    ("NLD", "নেদারল্যান্ডস", "Netherlands", "🇳🇱", "হাউস ৪৯, রোড ৯০, গুলশান-২, ঢাকা-১২১২", "House 49, Road 90, Gulshan-2, Dhaka-1212", "+880 2 222262715-18", "https://www.netherlandsandyou.nl/web/bangladesh", "https://www.netherlandsandyou.nl/web/bangladesh/about-us/contact-embassy-dhaka"),
    ("AUS", "অস্ট্রেলিয়া", "Australia", "🇦🇺", "১৮৪, গুলশান অ্যাভিনিউ, গুলশান-২, ঢাকা-১২১২", "184 Gulshan Avenue, Gulshan-2, Dhaka-1212", "+880 2 8813101-5", "https://bangladesh.embassy.gov.au/", "https://bangladesh.embassy.gov.au/daca/contact-us.html"),
    ("CAN", "কানাডা", "Canada", "🇨🇦", "ইউনাইটেড নেশনস রোড, বারিধারা, ঢাকা-১২১২", "United Nations Road, Baridhara, Dhaka-1212", "+880 2 55667100", "https://www.canada.ca/en/high-commission-bangladesh.html", "https://www.canada.ca/en/high-commission-bangladesh.html"),
    ("MYS", "মালয়েশিয়া", "Malaysia", "🇲🇾", "হাউস ১৯, রোড ৬, বারিধারা, ঢাকা-১২১২", "House 19, Road 6, Baridhara, Dhaka-1212", "+880 2 8817759", "https://www.kln.gov.my/web/bgd_dhaka/home", "https://www.kln.gov.my/web/bgd_dhaka/home"),
    ("SGP", "সিঙ্গাপুর", "Singapore", "🇸🇬", "১৬, পার্ক রোড, বারিধারা, ঢাকা-১২১২", "16, Park Road, Baridhara, Dhaka-1212", "+880 2 9881679", "https://www.mfa.gov.sg/Overseas-Missions/High-Commissions/Bangladesh", "https://www.mfa.gov.sg/Overseas-Missions/High-Commissions/Bangladesh"),
    ("SAU", "সৌদি আরব", "Saudi Arabia", "🇸🇦", "হাউস ৫, রোড ৮৩, গুলশান-২, ঢাকা-১২১২", "House 5, Road 83, Gulshan-2, Dhaka-1212", "+880 2 9858888", "https://bd.saudiembassy.sa/", "https://bd.saudiembassy.sa/"),
    ("ARE", "সংযুক্ত আরব আমিরাত", "United Arab Emirates", "🇦🇪", "হাউস ১৪, রোড ৬, বারিধারা, ঢাকা-১২১২", "House 14, Road 6, Baridhara, Dhaka-1212", "+880 2 8882252", "https://www.mofa.gov.ae/en/missions/dhaka", "https://www.mofa.gov.ae/en/missions/dhaka"),
    ("QAT", "কাতার", "Qatar", "🇶🇦", "হাউস ১, রোড ৭৯, গুলশান-২, ঢাকা-১২১২", "House 1, Road 79, Gulshan-2, Dhaka-1212", "+880 2 9891960", "https://dhaka.embassy.qa/", "https://dhaka.embassy.qa/"),
    ("KWT", "কুয়েত", "Kuwait", "🇰🇼", "হাউস ১৪, রোড ৭১, গুলশান-২, ঢাকা-১২১২", "House 14, Road 71, Gulshan-2, Dhaka-1212", "+880 2 9856236", "https://www.mofa.gov.kw/", "https://www.mofa.gov.kw/"),
    ("TUR", "তুরস্ক", "Türkiye", "🇹🇷", "৬, মাদানী অ্যাভিনিউ, বারিধারা, ঢাকা-১২১২", "6, Madani Avenue, Baridhara, Dhaka-1212", "+880 2 5881398", "https://dhaka-emb.mfa.gov.tr/", "https://dhaka-emb.mfa.gov.tr/"),
    ("CHE", "সুইজারল্যান্ড", "Switzerland", "🇨🇭", "বানানী জিপিও বক্স ৯১০০, ঢাকা-১২১৩", "Banani GPO Box 9100, Dhaka-1213", "+880 2 55051601", "https://www.eda.admin.ch/dhaka", "https://www.eda.admin.ch/countries/bangladesh/en/home/news/official-holidays.html/content/contacts/en/EDAVis/D/71"),
]

BORDER_PORTS = [
    ("বেনাপোল–পেট্রাপোল স্থলবন্দর", "Benapole–Petrapole Land Port", "বেনাপোল, শার্শা, যশোর", "Benapole, Sharsha, Jashore", "বাংলাদেশ–ভারত বাণিজ্য ও যাত্রী চলাচলের প্রধান স্থলপথগুলোর একটি। পাসপোর্ট, ভিসা, কাস্টমস ও ইমিগ্রেশন নিয়ম আগে যাচাই করুন." , "A major Bangladesh–India passenger and trade crossing. Check passport, visa, customs, and immigration requirements before travel."),
    ("ভোমরা–ঘোজাডাঙ্গা স্থলবন্দর", "Bhomra–Ghojadanga Land Port", "সাতক্ষীরা", "Satkhira", "সাতক্ষীরা সীমান্তের গুরুত্বপূর্ণ বাংলাদেশ–ভারত বাণিজ্য রুট। নির্ধারিত সময়, কাগজপত্র ও পণ্যবাহী নিয়ম সংশ্লিষ্ট কর্তৃপক্ষের কাছে যাচাই করুন.", "A key Bangladesh–India trade route at the Satkhira border. Confirm operating hours, documents, and cargo rules with the relevant authorities."),
    ("বুড়িমারী–চ্যাংরাবান্ধা স্থলবন্দর", "Burimari–Changrabandha Land Port", "পাটগ্রাম, লালমনিরহাট", "Patgram, Lalmonirhat", "উত্তরাঞ্চলের বাংলাদেশ–ভারত সীমান্ত রুট। যাত্রার আগে ইমিগ্রেশন, পরিবহন ও সীমান্তের বর্তমান নির্দেশনা যাচাই করুন.", "A northern Bangladesh–India border route. Check current immigration, transport, and border instructions before departure."),
    ("বাংলাবান্ধা–ফুলবাড়ী স্থলবন্দর", "Banglabandha–Phulbari Land Port", "তেঁতুলিয়া, পঞ্চগড়", "Tetulia, Panchagarh", "বাংলাবান্ধা সীমান্ত দিয়ে ভারত ও আঞ্চলিক যোগাযোগের পথ। ভ্রমণের আগে অনুমোদিত রুট, সময়সূচি ও প্রয়োজনীয় নথি যাচাই করুন.", "A gateway from Banglabandha to India and regional routes. Confirm approved routes, schedules, and required documents before travelling."),
    ("তামাবিল–ডাউকি স্থলবন্দর", "Tamabil–Dawki Land Port", "গোয়াইনঘাট, সিলেট", "Gowainghat, Sylhet", "সিলেটের জনপ্রিয় সীমান্ত রুট। সীমান্ত পারাপারের নিয়ম, যানবাহন এবং আবহাওয়ার অবস্থা আগে যাচাই করুন.", "A well-known Sylhet border route. Check crossing rules, transport arrangements, and weather conditions in advance."),
    ("আখাউড়া–আগরতলা স্থলবন্দর", "Akhaura–Agartala Land Port", "আখাউড়া, ব্রাহ্মণবাড়িয়া", "Akhaura, Brahmanbaria", "বাংলাদেশ–ভারত যাত্রী চলাচলের গুরুত্বপূর্ণ রুট। ইমিগ্রেশন সময়, ভিসা শর্ত ও স্বাস্থ্য-নির্দেশনা সংশ্লিষ্ট কর্তৃপক্ষের কাছ থেকে যাচাই করুন.", "An important Bangladesh–India passenger route. Confirm immigration hours, visa conditions, and health guidance with the authorities."),
]


def main():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    statements = [
        "-- Generated from the prepared Commons manifest and official mission-source list.",
        "-- One-time seed for currently empty travel tables; do not rerun after manual edits without taking a database backup.",
    ]
    tourist_rows = []
    for item in manifest:
        images = []
        for image in item.get("images", [])[:3]:
            images.append({
                "url": normalize_image_url(image["url"]),
                "captionBn": image.get("title", "বাংলাদেশের ভ্রমণ দৃশ্য"),
                "captionEn": image.get("title", "Bangladesh travel view"),
                "sourceUrl": image.get("sourceUrl"),
            })
        desc_bn, desc_en = tourist_description(
            item["nameBn"], item["nameEn"], item["category"], item["locationBn"], item["locationEn"]
        )
        tourist_rows.append(
            "(" + ", ".join([
                sql(item["nameBn"]), sql(item["nameEn"]), sql(desc_bn), sql(desc_en),
                sql(images[0]["url"] if images else None), sql(json.dumps(images, ensure_ascii=False)),
                sql(item["category"]), sql(f'{item["locationBn"]} / {item["locationEn"]}'), sql(1), sql(item["displayOrder"]),
            ]) + ")"
        )
    statements.append(
        "INSERT INTO `tourist_places` (`nameBn`,`nameEn`,`descBn`,`descEn`,`imageUrl`,`galleryJson`,`category`,`location`,`visible`,`displayOrder`) VALUES\n" + ",\n".join(tourist_rows) + ";"
    )

    border_rows = []
    for index, port in enumerate(BORDER_PORTS, start=1):
        border_rows.append(
            "(" + ", ".join([
                sql(port[0]), sql(port[1]), sql(port[2]), sql(port[3]), sql(port[4]), sql(port[5]),
                sql(None), sql("[]"), sql(1), sql(index),
            ]) + ")"
        )
    statements.append(
        "INSERT INTO `border_ports` (`nameBn`,`nameEn`,`locationBn`,`locationEn`,`infoBn`,`infoEn`,`imageUrl`,`galleryJson`,`visible`,`displayOrder`) VALUES\n" + ",\n".join(border_rows) + ";"
    )

    embassy_rows = []
    for index, row in enumerate(EMBASSIES, start=1):
        code, name_bn, name_en, flag, address_bn, address_en, phone, website, source = row
        digits = "".join(ch for ch in phone if ch.isdigit())
        whatsapp = f"https://wa.me/{digits}" if len(digits) >= 11 else None
        embassy_rows.append(
            "(" + ", ".join([
                sql(code), sql(name_bn), sql(name_en), sql(flag), sql(address_bn), sql(address_en), sql(phone),
                sql(website), sql(whatsapp), sql(source), sql("2026-08-20 00:00:00"), sql(1), sql(index),
            ]) + ")"
        )
    statements.append(
        "INSERT INTO `embassies` (`countryCode`,`countryNameBn`,`countryNameEn`,`flagEmoji`,`addressBn`,`addressEn`,`phone`,`websiteUrl`,`whatsappUrl`,`sourceUrl`,`lastVerifiedAt`,`visible`,`displayOrder`) VALUES\n" + ",\n".join(embassy_rows) + ";"
    )

    OUTPUT.write_text("\n\n".join(statements) + "\n", encoding="utf-8")
    print(f"Generated {len(manifest)} tourist records, {len(BORDER_PORTS)} border ports, and {len(EMBASSIES)} embassy records at {OUTPUT}")


if __name__ == "__main__":
    main()
