import fs from "node:fs";

const path = "/home/ubuntu/sahajseva-contact-preview/client/src/pages/AdminAnalyticsDashboard.tsx";
let source = fs.readFileSync(path, "utf8");
if (!source.includes('import { HomepageBuilderPanel, JonosobhaPanel } from "../components/FullControlCmsPanels";')) {
  source = source.replace('import { useLanguage } from "@/contexts/LanguageContext";\n', 'import { useLanguage } from "@/contexts/LanguageContext";\nimport { HomepageBuilderPanel, JonosobhaPanel } from "../components/FullControlCmsPanels";\n');
}
const start = source.indexOf('          <section className="bg-slate-900 border border-emerald-500/25 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">');
const end = source.indexOf('\n\n          {/* Analytics Summary */}', start);
if (start < 0 || end < 0) throw new Error("Could not find the legacy Site Management block");
const replacement = `          <HomepageBuilderPanel isOwner={isOwner} />
          <JonosobhaPanel isOwner={isOwner} />`;
source = source.slice(0, start) + replacement + source.slice(end);
fs.writeFileSync(path, source);
console.log("Integrated Full Control CMS panels.");
