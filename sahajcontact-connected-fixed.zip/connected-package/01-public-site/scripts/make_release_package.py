import os
import subprocess
from pathlib import Path

root = Path("/home/ubuntu/sahajseva-contact-preview")
output_dir = Path("/home/ubuntu/sahajseva-release")
output_dir.mkdir(parents=True, exist_ok=True)

zip_path = output_dir / "sahajcontact-project-backup.zip"
if zip_path.exists():
    zip_path.unlink()

# Create a clean zip archive excluding git history, node_modules, logs, and env files
subprocess.run(
    [
        "zip",
        "-r",
        str(zip_path),
        ".",
        "-x",
        "node_modules/*",
        ".git/*",
        "dist/*",
        ".manus-logs/*",
        ".env*",
        "*.log",
    ],
    cwd=str(root),
    check=True,
)

print(f"Successfully created release zip at {zip_path} ({zip_path.stat().st_size} bytes)")
