from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/webdev-static-assets/sahajseva/hero-current.webp')
output = Path('/home/ubuntu/webdev-static-assets/sahajseva/hero-mobile.webp')

with Image.open(source) as image:
    image = image.convert('RGB')
    image.thumbnail((640, 640), Image.Resampling.LANCZOS)
    image.save(output, format='WEBP', quality=68, method=6)

print(f'{output} {output.stat().st_size} bytes {image.width}x{image.height}')
