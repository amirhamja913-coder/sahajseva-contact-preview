from pathlib import Path
from PIL import Image

ROOT = Path('/home/ubuntu/webdev-static-assets')
OUT = ROOT / 'optimized-webp'
OUT.mkdir(parents=True, exist_ok=True)

SOURCES = [
    'sahajseva-river-clean-hero.jpg',
    'sahajseva-about-bangladesh.png',
    'sahajcontact-computer-support-illustration.png',
    'sahajcontact-bill-payment-customer.png',
    'sahajcontact-agriculture-farmer.png',
    'sahajcontact-expatriate-family.png',
    'sahajcontact-justice-court.png',
    'sahajseva-women-children-theme.png',
    'sahajseva-army-security-theme.png',
    'sahajseva-citizen-hills-theme.png',
    'sahajcontact-parliament-bg.png',
    'sahajcontact-rooppur-nuclear-background.png',
    'sahajcontact-karnafuli-tunnel-night.png',
    'sahajcontact-jamuna-bridge-bg.png',
    'infrastructure/padma-bridge.jpg',
    'infrastructure/jamuna-bridge.jpg',
    'infrastructure/bhairab-bridge.jpg',
    'infrastructure/hardinge-bridge.jpg',
    'infrastructure/payra-thermal-power.jpg',
    'infrastructure/bibiyana-gas-field.jpg',
    'infrastructure/chattogram-port.jpg',
    'infrastructure/shahjalal-airport.jpg',
    'uprising/2024-victory-celebration.jpg',
    'uprising/2024-public-movement.jpg',
    'uprising/payra-thermal-neutral.jpg',
    'national-martyrs-memorial.jpg',
    'sahaj-gallery/bangladesh-flag.jpg',
    'sahaj-gallery/sajek-landscape.jpg',
    'sahaj-gallery/mustard-field.jpg',
    'hill-tract-indigenous-schoolgirls.jpg',
    'bangladesh-national-museum.jpg',
]

for relative in SOURCES:
    source = ROOT / relative
    if not source.exists():
        print(f'SKIP missing: {source}')
        continue
    destination = OUT / (Path(relative).stem + '.webp')
    with Image.open(source) as image:
        image = image.convert('RGBA' if 'A' in image.getbands() else 'RGB')
        max_dimension = 1800 if ('bg' in source.stem or 'hero' in source.stem or 'about' in source.stem) else 1400
        image.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
        image.save(destination, 'WEBP', quality=76, method=6)
        print(f'{relative} -> {destination.name} {image.size} {destination.stat().st_size} bytes')

hero_source = ROOT / 'sahajseva-river-clean-hero.jpg'
hero_mobile = OUT / 'sahajseva-river-clean-hero-mobile.webp'
with Image.open(hero_source) as image:
    image = image.convert('RGB')
    image.thumbnail((640, 640), Image.Resampling.LANCZOS)
    image.save(hero_mobile, 'WEBP', quality=74, method=6)
    print(f'mobile hero -> {hero_mobile.name} {image.size} {hero_mobile.stat().st_size} bytes')
