from bs4 import BeautifulSoup
from pathlib import Path

html_path = Path('/home/ubuntu/browser_html/erd_gov_bd_694032ae35ce18e1c05606d7_1787193099024.html')
soup = BeautifulSoup(html_path.read_text(encoding='utf-8'), 'html.parser')
rows = []
for table in soup.find_all('table'):
    for tr in table.find_all('tr'):
        cells = [' '.join(cell.get_text(' ', strip=True).split()) for cell in tr.find_all(['th', 'td'])]
        if cells:
            rows.append(cells)
for row in rows:
    print(' | '.join(row))
