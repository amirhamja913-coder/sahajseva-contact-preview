import json
import time
from pathlib import Path
from urllib.parse import quote

import requests

DESTINATIONS = [
    ("কক্সবাজার সমুদ্র সৈকত", "Cox's Bazar Sea Beach", "সমুদ্র", "কক্সবাজার, চট্টগ্রাম", "Cox's Bazar, Chattogram"),
    ("ইনানী সমুদ্র সৈকত", "Inani Beach", "সমুদ্র", "উখিয়া, কক্সবাজার", "Ukhia, Cox's Bazar"),
    ("পতেঙ্গা সমুদ্র সৈকত", "Patenga Beach", "সমুদ্র", "চট্টগ্রাম", "Chattogram"),
    ("কুয়াকাটা সমুদ্র সৈকত", "Kuakata Sea Beach", "সমুদ্র", "কলাপাড়া, পটুয়াখালী", "Kalapara, Patuakhali"),
    ("সেন্ট মার্টিন দ্বীপ", "Saint Martin's Island", "সমুদ্র", "টেকনাফ, কক্সবাজার", "Teknaf, Cox's Bazar"),
    ("পারকি সমুদ্র সৈকত", "Parki Beach", "সমুদ্র", "আনোয়ারা, চট্টগ্রাম", "Anwara, Chattogram"),
    ("সোনাদিয়া দ্বীপ", "Sonadia Island", "সমুদ্র", "মহেশখালী, কক্সবাজার", "Maheshkhali, Cox's Bazar"),
    ("নিঝুম দ্বীপ", "Nijhum Dwip", "সমুদ্র", "হাতিয়া, নোয়াখালী", "Hatiya, Noakhali"),
    ("সুন্দরবন", "The Sundarbans", "প্রকৃতি", "খুলনা, বাগেরহাট ও সাতক্ষীরা", "Khulna, Bagerhat and Satkhira"),
    ("সাজেক ভ্যালি", "Sajek Valley", "পাহাড়", "বাঘাইছড়ি, রাঙামাটি", "Baghaichhari, Rangamati"),
    ("বান্দরবান পাহাড়", "Bandarban Hills", "পাহাড়", "বান্দরবান", "Bandarban"),
    ("নীলগিরি", "Nilgiri", "পাহাড়", "থানচি, বান্দরবান", "Thanchi, Bandarban"),
    ("নীলাচল", "Nilachal", "পাহাড়", "বান্দরবান সদর", "Bandarban Sadar"),
    ("বগা লেক", "Boga Lake", "পাহাড়", "রুমা, বান্দরবান", "Ruma, Bandarban"),
    ("কেওক্রাডং", "Keokradong", "পাহাড়", "রুমা, বান্দরবান", "Ruma, Bandarban"),
    ("নাফাখুম জলপ্রপাত", "Nafakhum Waterfall", "পাহাড়", "থানচি, বান্দরবান", "Thanchi, Bandarban"),
    ("আমিয়াখুম জলপ্রপাত", "Amiakhum Waterfall", "পাহাড়", "থানচি, বান্দরবান", "Thanchi, Bandarban"),
    ("চিম্বুক পাহাড়", "Chimbuk Hill", "পাহাড়", "বান্দরবান", "Bandarban"),
    ("আলীকদম", "Alikadam", "পাহাড়", "বান্দরবান", "Bandarban"),
    ("জাফলং", "Jaflong", "প্রকৃতি", "গোয়াইনঘাট, সিলেট", "Gowainghat, Sylhet"),
    ("বিছানাকান্দি", "Bichanakandi", "প্রকৃতি", "গোয়াইনঘাট, সিলেট", "Gowainghat, Sylhet"),
    ("রাতারগুল সোয়াম্প ফরেস্ট", "Ratargul Swamp Forest", "প্রকৃতি", "গোয়াইনঘাট, সিলেট", "Gowainghat, Sylhet"),
    ("লাওয়াছড়া জাতীয় উদ্যান", "Lawachara National Park", "প্রকৃতি", "কমলগঞ্জ, মৌলভীবাজার", "Kamalganj, Moulvibazar"),
    ("শ্রীমঙ্গলের চা-বাগান", "Sreemangal Tea Gardens", "প্রকৃতি", "শ্রীমঙ্গল, মৌলভীবাজার", "Sreemangal, Moulvibazar"),
    ("মাধবকুণ্ড জলপ্রপাত", "Madhabkunda Waterfall", "প্রকৃতি", "বড়লেখা, মৌলভীবাজার", "Barlekha, Moulvibazar"),
    ("মাধবপুর লেক", "Madhabpur Lake", "প্রকৃতি", "কমলগঞ্জ, মৌলভীবাজার", "Kamalganj, Moulvibazar"),
    ("টাঙ্গুয়ার হাওর", "Tanguar Haor", "প্রকৃতি", "তাহিরপুর, সুনামগঞ্জ", "Tahirpur, Sunamganj"),
    ("হাকালুকি হাওর", "Hakaluki Haor", "প্রকৃতি", "মৌলভীবাজার ও সিলেট", "Moulvibazar and Sylhet"),
    ("বাইক্কা বিল", "Baikka Beel", "প্রকৃতি", "শ্রীমঙ্গল, মৌলভীবাজার", "Sreemangal, Moulvibazar"),
    ("কাপ্তাই লেক", "Kaptai Lake", "প্রকৃতি", "কাপ্তাই, রাঙামাটি", "Kaptai, Rangamati"),
    ("বিরিশিরি", "Birishiri", "প্রকৃতি", "দুর্গাপুর, নেত্রকোনা", "Durgapur, Netrokona"),
    ("মহাস্থানগড়", "Mahasthangarh", "ঐতিহাসিক", "শিবগঞ্জ, বগুড়া", "Shibganj, Bogura"),
    ("পাহাড়পুর বৌদ্ধ বিহার", "Somapura Mahavihara at Paharpur", "ঐতিহাসিক", "বদলগাছী, নওগাঁ", "Badalgachhi, Naogaon"),
    ("ময়নামতি শালবন বিহার", "Shalban Vihara, Mainamati", "ঐতিহাসিক", "কুমিল্লা", "Cumilla"),
    ("লালবাগ কেল্লা", "Lalbagh Fort", "ঐতিহাসিক", "পুরান ঢাকা", "Old Dhaka"),
    ("আহসান মঞ্জিল", "Ahsan Manzil", "ঐতিহাসিক", "পুরান ঢাকা", "Old Dhaka"),
    ("সোনারগাঁও পানাম নগর", "Panam City, Sonargaon", "ঐতিহাসিক", "সোনারগাঁও, নারায়ণগঞ্জ", "Sonargaon, Narayanganj"),
    ("বাংলাদেশ জাতীয় জাদুঘর", "Bangladesh National Museum", "ঐতিহাসিক", "শাহবাগ, ঢাকা", "Shahbagh, Dhaka"),
    ("মুক্তিযুদ্ধ জাদুঘর", "Liberation War Museum", "ঐতিহাসিক", "আগারগাঁও, ঢাকা", "Agargaon, Dhaka"),
    ("জাতীয় স্মৃতিসৌধ", "National Martyrs' Memorial", "ঐতিহাসিক", "সাভার, ঢাকা", "Savar, Dhaka"),
    ("জাতীয় সংসদ ভবন", "Jatiya Sangsad Bhaban", "ঐতিহাসিক", "শেরেবাংলা নগর, ঢাকা", "Sher-e-Bangla Nagar, Dhaka"),
    ("ষাট গম্বুজ মসজিদ", "Sixty Dome Mosque", "ধর্মীয়", "বাগেরহাট", "Bagerhat"),
    ("কান্তজিউ মন্দির", "Kantajew Temple", "ধর্মীয়", "কাহারোল, দিনাজপুর", "Kaharole, Dinajpur"),
    ("পুঠিয়া মন্দির কমপ্লেক্স", "Puthia Temple Complex", "ধর্মীয়", "পুঠিয়া, রাজশাহী", "Puthia, Rajshahi"),
    ("ঢাকেশ্বরী মন্দির", "Dhakeshwari Temple", "ধর্মীয়", "পুরান ঢাকা", "Old Dhaka"),
    ("তারা মসজিদ", "Star Mosque", "ধর্মীয়", "আরমানিটোলা, ঢাকা", "Armanitola, Dhaka"),
    ("বায়তুল মোকাররম জাতীয় মসজিদ", "Baitul Mukarram National Mosque", "ধর্মীয়", "ঢাকা", "Dhaka"),
    ("চন্দনপুরা মসজিদ", "Chandanpura Mosque", "ধর্মীয়", "চট্টগ্রাম", "Chattogram"),
    ("আতিয়া মসজিদ", "Atia Mosque", "ধর্মীয়", "দেলদুয়ার, টাঙ্গাইল", "Delduar, Tangail"),
    ("রাজশাহী বরেন্দ্র গবেষণা জাদুঘর", "Varendra Research Museum", "ঐতিহাসিক", "রাজশাহী", "Rajshahi"),
    ("মুজিবনগর স্মৃতিসৌধ", "Mujibnagar Memorial", "ঐতিহাসিক", "মুজিবনগর, মেহেরপুর", "Mujibnagar, Meherpur"),
    ("দুবলার চর", "Dublar Char", "প্রকৃতি", "সুন্দরবন, বাগেরহাট", "The Sundarbans, Bagerhat"),
    ("কুয়াকাটার বৌদ্ধ মন্দির", "Kuakata Buddhist Temple", "ধর্মীয়", "কলাপাড়া, পটুয়াখালী", "Kalapara, Patuakhali"),
    ("শাহজালাল দরগাহ", "Hazrat Shah Jalal Mazar Sharif", "ধর্মীয়", "সিলেট", "Sylhet"),
    ("শাহপরান মাজার", "Hazrat Shah Paran Mazar Sharif", "ধর্মীয়", "সিলেট", "Sylhet"),
    ("মহামায়া লেক", "Mahamaya Lake", "প্রকৃতি", "মিরসরাই, চট্টগ্রাম", "Mirsarai, Chattogram"),
]


def commons_images(query: str, limit: int = 3):
    api = "https://api.wikimedia.org/core/v1/commons/search/page"
    response = None
    for attempt in range(5):
        response = requests.get(
            api,
            params={"q": query, "limit": limit},
            headers={"User-Agent": "SahajContact/1.0 (travel data; public civic portal)"},
            timeout=30,
        )
        if response.status_code != 429:
            break
        time.sleep(20 * (attempt + 1))
    response.raise_for_status()
    pages = response.json().get("pages", [])
    items = []
    for page in pages:
        thumbnail = page.get("thumbnail") or {}
        url = thumbnail.get("url")
        if not url:
            continue
        url = url.replace("/60px-", "/960px-", 1)
        title = page.get("title") or page.get("key") or ""
        source_url = "https://commons.wikimedia.org/wiki/" + quote(title.replace(" ", "_"), safe="/:()")
        items.append({"url": url, "sourceUrl": source_url, "title": title.replace("File:", "").strip()})
    return items


def main():
    output = []
    for index, (name_bn, name_en, category, location_bn, location_en) in enumerate(DESTINATIONS, start=1):
        query = f"{name_en} Bangladesh"
        images = commons_images(query)
        if not images:
            images = commons_images(name_en)
        if not images:
            raise RuntimeError(f"No Wikimedia Commons image found for {name_en}")
        output.append({
            "displayOrder": index,
            "nameBn": name_bn,
            "nameEn": name_en,
            "category": category,
            "locationBn": location_bn,
            "locationEn": location_en,
            "images": images[:3],
        })
        time.sleep(8)
    Path("/home/ubuntu/travel_assets.json").write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Prepared {len(output)} destination records")


if __name__ == "__main__":
    main()
