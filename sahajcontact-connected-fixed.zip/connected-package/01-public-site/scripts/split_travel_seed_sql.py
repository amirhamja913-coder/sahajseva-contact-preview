from pathlib import Path

source = Path('/home/ubuntu/travel_seed.sql').read_text(encoding='utf-8')
out = Path('/home/ubuntu/travel_seed_chunks')
out.mkdir(parents=True, exist_ok=True)

header = "-- Generated travel seed; source manifest and official mission references are retained in docs.\n-- One-time seed for currently empty travel tables; do not rerun after manual edits without taking a database backup."
markers = [
    "INSERT INTO `tourist_places`",
    "INSERT INTO `border_ports`",
    "INSERT INTO `embassies`",
]
positions = [source.index(marker) for marker in markers]
tourist = source[positions[0]:positions[1]].strip()
border = source[positions[1]:positions[2]].strip()
embassy = source[positions[2]:].strip()

prefix, rows_text = tourist.split(' VALUES\n', 1)
rows = [line.strip().rstrip(',;') for line in rows_text.splitlines() if line.strip()]
for index in range(0, len(rows), 14):
    batch = rows[index:index + 14]
    sql = header + '\n\n' + prefix + ' VALUES\n' + ',\n'.join(batch) + ';\n'
    (out / f'{index // 14 + 1:02d}-tourist.sql').write_text(sql, encoding='utf-8')

(out / '06-border.sql').write_text(header + '\n\n' + border + '\n', encoding='utf-8')
(out / '07-embassy.sql').write_text(header + '\n\n' + embassy + '\n', encoding='utf-8')
print(f'Wrote {len(range(0, len(rows), 14))} tourist batches plus border and embassy batches')
