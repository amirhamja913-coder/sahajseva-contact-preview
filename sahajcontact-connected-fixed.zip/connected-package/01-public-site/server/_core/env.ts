export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  localAdminPassword: process.env.LOCAL_ADMIN_PASSWORD ?? "",
  localAdminName: process.env.LOCAL_ADMIN_NAME ?? "Local Admin",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  scheduledJobSecret: process.env.SCHEDULED_JOB_SECRET ?? "",
  controlRoomSharedSecret: process.env.CONTROL_ROOM_SHARED_SECRET ?? "",
};
