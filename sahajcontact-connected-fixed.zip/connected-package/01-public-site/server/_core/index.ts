import "dotenv/config";
import compression from "compression";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerLocalAuthRoutes } from "./localAuth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { refreshSponsorAnalytics, sendWeeklySponsorReport } from "../sponsorAnalytics";
import { createScheduledSiteBackupSnapshot, getDailySiteBackupAutomationByTaskUid, getSeoReportRefreshSettingsByTaskUid, insertSiteOperationalLog, recordDailySiteBackupSuccess, recordSeoReportRefreshFailure, recordSeoReportRefreshSuccess } from "../db";
import { AutomaticSeoRefreshError, refreshAutomaticSeoReport } from "../seoReportAutomation";
import { describeSeoRefreshFailure, type SeoRefreshFailureStage } from "../seoRefreshDiagnostics";
import { createContext } from "./context";
import { ENV } from "./env";
import { isScheduledRequestAuthorized, SCHEDULE_SECRET_HEADER } from "./scheduledAuth";
import { sdk } from "./sdk";
import { serveStatic, setupVite } from "./vite";
import { applyControlRoomPatch, getControlRoomStatus, isControlRoomRequestAuthorized, parseControlRoomPatch } from "../controlRoomBridge";
import { resolveControlRoomSharedSecret } from "../controlRoomRuntime";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // These browser-facing protections are intentionally narrow: avoid a CSP or
  // cross-origin isolation policy here because verified OAuth, Maps, storage,
  // and analytics integrations need their existing compatible request policy.
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), payment=()");
    next();
  });
  // Compress text responses while leaving already-compressed media untouched.
  app.use(compression({ threshold: 1024 }));
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerLocalAuthRoutes(app);
  registerOAuthRoutes(app);

  // Scheduled endpoints for Monday 9:00 / 9:05 AM analytics and email reports.
  // These are machine-to-machine endpoints and must never be publicly executable.
  const requireScheduledJobSecret: express.RequestHandler = (req, res, next) => {
    if (!ENV.scheduledJobSecret) {
      res.status(503).json({ success: false, error: "Scheduled jobs are not configured" });
      return;
    }

    if (!isScheduledRequestAuthorized(req, ENV.scheduledJobSecret)) {
      res
        .status(401)
        .setHeader("WWW-Authenticate", `Bearer realm="scheduled-jobs", header="${SCHEDULE_SECRET_HEADER}"`)
        .json({ success: false, error: "Unauthorized scheduled job request" });
      return;
    }

    next();
  };

  app.post("/api/scheduled/sponsor-analytics-refresh", requireScheduledJobSecret, async (_req, res) => {
    try {
      const stats = await refreshSponsorAnalytics();
      res.json({ success: true, stats });
    } catch (error) {
      console.error("[Scheduled] Sponsor analytics refresh failed:", error);
      res.status(500).json({ success: false, error: String(error) });
    }
  });

  app.post("/api/scheduled/sponsor-weekly-email", requireScheduledJobSecret, async (_req, res) => {
    try {
      const sent = await sendWeeklySponsorReport();
      res.json({ success: sent });
    } catch (error) {
      console.error("[Scheduled] Sponsor weekly email report failed:", error);
      res.status(500).json({ success: false, error: String(error) });
    }
  });

  // Recovery snapshots contain owner-managed public configuration only; no secrets,
  // admin sessions, passwords, or biometric material are ever included.
  app.post("/api/scheduled/daily-site-backup", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron || !user.taskUid) {
        return res.status(403).json({ success: false, error: "Cron-only endpoint" });
      }

      const automation = await getDailySiteBackupAutomationByTaskUid(user.taskUid);
      if (!automation || automation.enabled !== 1) {
        // Orphaned or paused platform tasks are deliberately acknowledged so the
        // scheduler does not retry an obsolete configuration indefinitely.
        return res.json({ success: true, skipped: automation ? "disabled" : "orphan" });
      }

      const dayKey = new Date().toISOString().slice(0, 10);
      const result = await createScheduledSiteBackupSnapshot(dayKey);
      await recordDailySiteBackupSuccess(user.taskUid);
      if (result.created) {
        await insertSiteOperationalLog({
          level: "info",
          operation: "daily_recovery_snapshot_created",
          message: `Automatic recovery snapshot created for ${dayKey}.`,
        });
      }
      res.json({ success: true, created: result.created, dayKey });
    } catch (error) {
      console.error("[Scheduled] Daily site backup failed:", error);
      res.status(500).json({
        success: false,
        error: "Daily backup failed",
        context: { path: req.path },
        timestamp: new Date().toISOString(),
      });
    }
  });

  // The platform authenticates this project-level scheduled call. Browser requests
  // and body-supplied task IDs are never trusted for persisted GA4 report updates.
  app.post("/api/scheduled/daily-seo-report-refresh", async (req, res) => {
    let taskUid: string | undefined;
    let failureStage: SeoRefreshFailureStage = "cron_auth_config";
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron || !user.taskUid) {
        return res.status(403).json({ success: false, error: "Cron-only endpoint" });
      }
      taskUid = user.taskUid;
      const automation = await getSeoReportRefreshSettingsByTaskUid(taskUid);
      if (!automation || automation.enabled !== 1) {
        return res.json({ success: true, skipped: automation ? "disabled" : "orphan" });
      }

      const result = await refreshAutomaticSeoReport();
      failureStage = "scheduler_status_persistence";
      await recordSeoReportRefreshSuccess(taskUid);
      failureStage = "audit_logging";
      await insertSiteOperationalLog({
        level: "info",
        operation: "daily_seo_report_refreshed",
        message: `Automatic GA4 SEO report refreshed for ${result.dayKey}.`,
      }).catch((error) => console.warn("[Scheduled] Daily GA4 SEO audit log failed after snapshot save:", error));
      return res.json({ success: true, created: result.created, dayKey: result.dayKey, capturedAt: result.capturedAt });
    } catch (error) {
      console.error("[Scheduled] Daily GA4 SEO report refresh failed:", error);
      const stage = error instanceof AutomaticSeoRefreshError ? error.stage : failureStage;
      const rootError = error instanceof AutomaticSeoRefreshError ? error.cause : error;
      const diagnostic = describeSeoRefreshFailure(stage, rootError);
      if (taskUid) await recordSeoReportRefreshFailure(taskUid, diagnostic).catch(() => undefined);
      await insertSiteOperationalLog({
        level: "error",
        operation: "daily_seo_report_refresh_failed",
        message: diagnostic,
      }).catch(() => undefined);
      // The scheduler may retain this response body in protected task logs. Expose
      // only a fixed stage enum there, never the provider error or diagnostic text.
      return res.status(500).json({
        success: false,
        error: "Daily GA4 SEO report refresh failed",
        context: { path: req.path, failureStage: stage },
        timestamp: new Date().toISOString(),
      });
    }
  });

  // Google Apps Script calls these signed server-to-server routes. They do not
  // accept owner browser cookies and never return configuration secrets.
  const requireControlRoomSignature: express.RequestHandler = (req, res, next) => {
    const controlRoomSharedSecret = resolveControlRoomSharedSecret(ENV.controlRoomSharedSecret);
    if (!controlRoomSharedSecret) {
      res.status(503).json({ success: false, error: "Control Room bridge is not configured" });
      return;
    }
    if (!isControlRoomRequestAuthorized(req, controlRoomSharedSecret)) {
      res.status(401).json({ success: false, error: "Unauthorized Control Room request" });
      return;
    }
    next();
  };

  app.get("/api/control-room/v1/status", requireControlRoomSignature, async (_req, res) => {
    try {
      res.json({ success: true, data: await getControlRoomStatus() });
    } catch (error) {
      console.error("[ControlRoom] Status request failed:", error);
      res.status(500).json({ success: false, error: "Control Room status is temporarily unavailable" });
    }
  });

  app.post("/api/control-room/v1/site-controls", requireControlRoomSignature, async (req, res) => {
    const patch = parseControlRoomPatch(req.body);
    if (!patch) {
      res.status(400).json({ success: false, error: "Invalid Control Room request body" });
      return;
    }
    try {
      res.json({ success: true, data: await applyControlRoomPatch(patch) });
    } catch (error) {
      console.error("[ControlRoom] Control update failed:", error);
      res.status(500).json({ success: false, error: "Control Room update could not be saved" });
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
