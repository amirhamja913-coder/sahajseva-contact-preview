import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import { getSessionCookieOptions } from "./cookies";
import { ENV } from "./env";
import { sdk } from "./sdk";
import { LOCAL_ADMIN_OPEN_ID } from "./localAuthConstants";

const MAX_ATTEMPTS_PER_WINDOW = 8;
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const failedAttempts = new Map<string, { count: number; resetAt: number }>();

function getClientKey(req: Request) {
  const forwarded = req.headers["x-forwarded-for"];
  return typeof forwarded === "string" ? forwarded.split(",")[0]?.trim() || req.ip || "unknown" : req.ip || "unknown";
}

function isRateLimited(key: string) {
  const current = failedAttempts.get(key);
  if (!current || current.resetAt <= Date.now()) {
    failedAttempts.delete(key);
    return false;
  }
  return current.count >= MAX_ATTEMPTS_PER_WINDOW;
}

function recordFailure(key: string) {
  const now = Date.now();
  const current = failedAttempts.get(key);
  if (!current || current.resetAt <= now) {
    failedAttempts.set(key, { count: 1, resetAt: now + ATTEMPT_WINDOW_MS });
  } else {
    current.count += 1;
  }
}

function passwordsMatch(candidate: string, configured: string) {
  const candidateBuffer = Buffer.from(candidate);
  const configuredBuffer = Buffer.from(configured);
  return candidateBuffer.length === configuredBuffer.length && crypto.timingSafeEqual(candidateBuffer, configuredBuffer);
}

export function registerLocalAuthRoutes(app: Express) {
  app.post("/api/local-auth/login", async (req: Request, res: Response) => {
    const clientKey = getClientKey(req);
    if (isRateLimited(clientKey)) {
      res.status(429).json({ error: "অনেকবার ভুল চেষ্টা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।" });
      return;
    }

    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!ENV.localAdminPassword) {
      res.status(503).json({ error: "LOCAL_ADMIN_PASSWORD সেট করা হয়নি। Deployment settings-এ secret যোগ করুন।" });
      return;
    }
    if (!passwordsMatch(password, ENV.localAdminPassword)) {
      recordFailure(clientKey);
      res.status(401).json({ error: "পাসওয়ার্ড সঠিক নয়।" });
      return;
    }

    failedAttempts.delete(clientKey);
    const token = await sdk.signSession({
      openId: LOCAL_ADMIN_OPEN_ID,
      appId: ENV.appId || "sahajcontact-local",
      name: ENV.localAdminName,
    });
    res.cookie("app_session_id", token, {
      ...getSessionCookieOptions(req),
      maxAge: 1000 * 60 * 60 * 12,
    });
    res.json({ success: true });
  });

  app.post("/api/local-auth/logout", (req: Request, res: Response) => {
    res.clearCookie("app_session_id", { ...getSessionCookieOptions(req), maxAge: -1 });
    res.json({ success: true });
  });
}
