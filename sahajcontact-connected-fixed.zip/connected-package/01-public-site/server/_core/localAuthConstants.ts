export const LOCAL_ADMIN_OPEN_ID = "local-admin";
