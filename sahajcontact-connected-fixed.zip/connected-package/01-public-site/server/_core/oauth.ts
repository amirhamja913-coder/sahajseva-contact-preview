import { COOKIE_NAME, ONE_YEAR_MS, OAUTH_STATE_COOKIE, decodeOAuthState, encodeOAuthState } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

function getRequestOrigin(req: Request): string | null {
  const forwardedProto = req.get("x-forwarded-proto")?.split(",")[0]?.trim();
  const protocol = forwardedProto || req.protocol;
  const host = req.get("x-forwarded-host") || req.get("host");
  return host ? `${protocol}://${host}` : null;
}

export function registerOAuthRoutes(app: Express) {
  // Server-assisted OAuth start: a plain link to this endpoint is more reliable
  // than a client-side redirect in Android WebViews and installed PWAs.
  app.get("/api/oauth/start", (req: Request, res: Response) => {
    const origin = getRequestOrigin(req);
    const portalUrl = process.env.VITE_OAUTH_PORTAL_URL || process.env.OAUTH_SERVER_URL;
    const appId = process.env.VITE_APP_ID;
    const requestedReturnTo = getQueryParam(req, "returnTo") || "/admin/dashboard";
    const returnTo = requestedReturnTo.startsWith("/") ? requestedReturnTo : "/admin/dashboard";

    if (!origin || !portalUrl || !appId) {
      res.status(503).send("লগইন সেবা এখন প্রস্তুত নয়। কিছুক্ষণ পর আবার চেষ্টা করুন।");
      return;
    }

    const redirectUri = `${origin}/api/oauth/callback`;
    const nonce = crypto.randomUUID();
    const state = encodeOAuthState({ redirectUri, nonce });
    const cookieOptions = {
      path: "/",
      maxAge: 600_000,
      secure: true,
      sameSite: "none" as const,
    };

    res.cookie(OAUTH_STATE_COOKIE, nonce, cookieOptions);
    res.cookie("sahaj_return_to", encodeURIComponent(returnTo), {
      ...cookieOptions,
      httpOnly: false,
      sameSite: "lax" as const,
    });

    const authUrl = new URL(`${portalUrl.replace(/\/+$/, "")}/app-auth`);
    authUrl.searchParams.set("appId", appId);
    authUrl.searchParams.set("redirectUri", redirectUri);
    authUrl.searchParams.set("state", state);
    authUrl.searchParams.set("type", "signIn");
    res.redirect(302, authUrl.toString());
  });

  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }

    // CSRF guard: the nonce in `state` must match the one-time cookie that
    // startLogin set in the browser that began this login. An attacker can
    // forge `state`, but cannot plant this cookie in the victim's browser.
    const { nonce } = decodeOAuthState(state);
    const expectedNonce = parseCookieHeader(req.headers.cookie ?? "")[OAUTH_STATE_COOKIE];
    if (!nonce || nonce !== expectedNonce) {
      res.status(403).json({ error: "invalid oauth state" });
      return;
    }
    res.clearCookie(OAUTH_STATE_COOKIE, { path: "/", secure: true, sameSite: "none" });

    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);

      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }

      await db.upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: new Date(),
      });

      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      const cookies = parseCookieHeader(req.headers.cookie ?? "");
      const returnTo = cookies["sahaj_return_to"] ? decodeURIComponent(cookies["sahaj_return_to"]) : "/";
      res.clearCookie("sahaj_return_to", { path: "/" });

      res.redirect(302, returnTo.startsWith("/") ? returnTo : "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}
