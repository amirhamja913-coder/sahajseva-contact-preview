import { timingSafeEqual } from "node:crypto";
import type { Request } from "express";

export const SCHEDULE_SECRET_HEADER = "x-cron-secret";

function readSecretHeader(req: Pick<Request, "headers">): string {
  const header = req.headers[SCHEDULE_SECRET_HEADER];
  if (typeof header === "string") return header.trim();
  if (Array.isArray(header)) return header[0]?.trim() ?? "";

  const authorization = req.headers.authorization;
  if (typeof authorization === "string" && authorization.startsWith("Bearer ")) {
    return authorization.slice("Bearer ".length).trim();
  }

  return "";
}

export function isScheduledRequestAuthorized(
  req: Pick<Request, "headers">,
  configuredSecret: string,
): boolean {
  if (!configuredSecret) return false;

  const providedSecret = readSecretHeader(req);
  const expected = Buffer.from(configuredSecret, "utf8");
  const provided = Buffer.from(providedSecret, "utf8");

  return provided.length === expected.length && timingSafeEqual(provided, expected);
}
