import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from "@shared/const";
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import { TrpcContext } from "./context";
import { ENV } from "./env";
import { getActiveAdminMemberRoleByEmail, getAdminMemberFeaturePermissionsByEmail } from "../db";
import {
  canUseAdminFeature,
  hasAdminPermission,
  normalizeAdminPermission,
  type AdminFeature,
  type AdminPermission,
} from "../adminPermissions";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

export const isPortalOwner = (user: TrpcContext["user"]) =>
  Boolean(user && (user.email === "amirhamja913@gmail.com" || (ENV.ownerOpenId && user.role === "admin" && user.openId === ENV.ownerOpenId)));

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

function permissionProcedure(required: Exclude<AdminPermission, "Owner">) {
  return t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user) {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    const permission = isPortalOwner(ctx.user)
      ? "Owner"
      : normalizeAdminPermission(await getActiveAdminMemberRoleByEmail(ctx.user?.email));

    if (!hasAdminPermission(permission, required)) {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
        adminPermission: permission,
      },
    });
  }),
  );
}

/** Any active delegated member can view operational dashboard data. */
export const adminProcedure = permissionProcedure("Viewer");

/** Only Editor, Admin and Owner can change operational dashboard data. */
export const editorProcedure = permissionProcedure("Editor");

function featureProcedure(feature: AdminFeature) {
  return t.procedure.use(
    t.middleware(async opts => {
      const { ctx, next } = opts;
      if (!ctx.user) {
        throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
      }

      const permission = isPortalOwner(ctx.user)
        ? "Owner"
        : normalizeAdminPermission(await getActiveAdminMemberRoleByEmail(ctx.user?.email));
      const featureRows = isPortalOwner(ctx.user)
        ? []
        : await getAdminMemberFeaturePermissionsByEmail(ctx.user?.email);
      const enabledFeatures = featureRows
        .filter(row => row.enabled === 1)
        .map(row => row.feature as AdminFeature);

      if (!canUseAdminFeature(permission, feature, enabledFeatures)) {
        throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
      }

      return next({
        ctx: {
          ...ctx,
          user: ctx.user,
          adminPermission: permission,
          enabledAdminFeatures: enabledFeatures,
        },
      });
    }),
  );
}

export const analyticsFeatureProcedure = featureProcedure("analytics");
export const mediaFeatureProcedure = featureProcedure("media");
export const exportsFeatureProcedure = featureProcedure("exports");

/**
 * Owner-only guard for sensitive portal administration surfaces. This is
 * intentionally stricter than adminProcedure so another admin role cannot
 * access the owner's analytics/profile area.
 */
export const ownerOnlyProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!isPortalOwner(ctx.user)) {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);
