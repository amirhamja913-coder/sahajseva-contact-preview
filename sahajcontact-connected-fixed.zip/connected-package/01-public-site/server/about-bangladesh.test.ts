import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("About Bangladesh homepage section", () => {
  const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
  const styles = readFileSync(resolve(process.cwd(), "client/src/index.css"), "utf8");

  it("is placed after the hero and before the search/service content", () => {
    const aboutIndex = home.indexOf('className="about-bangladesh-section"');
    const searchIndex = home.indexOf('className="home-search-banner"');
    expect(aboutIndex).toBeGreaterThan(-1);
    expect(searchIndex).toBeGreaterThan(aboutIndex);
  });

  it("contains the requested Bengali copy and Bangladesh visual", () => {
    expect(home).toContain("copy.aboutTitle");
    expect(home).toContain("copy.aboutText");
    const languageContext = readFileSync(resolve(process.cwd(), "client/src/contexts/LanguageContext.tsx"), "utf8");
    expect(languageContext).toContain("বাংলাদেশকে জানুন");
    expect(languageContext).toContain("বাংলাদেশ - নদী, মানুষ, মুক্তিযুদ্ধের দেশ।");
    expect(home).toContain("/manus-storage/sahajseva-about-bangladesh_1209dfe6.webp");
  });

  it("provides a copy-link share action and includes SahajContact and Invest Bangladesh destinations", () => {
    expect(home).toContain("handleAboutShare");
    expect(home).toContain("about_bangladesh_share_click");
    expect(home).toContain("about-bangladesh-official-links");
    expect(home).toContain('href="/"');
    expect(home).toContain(">SahajContact <ArrowUpRight");
    expect(home).toContain('href="/invest-bangladesh"');
    expect(home).toContain("ইনভেস্ট বাংলাদেশ");
    const aboutLinksStart = home.indexOf('className="about-bangladesh-official-links"');
    const aboutLinksEnd = home.indexOf("</nav>", aboutLinksStart);
    const aboutLinksBlock = home.slice(aboutLinksStart, aboutLinksEnd);
    for (const url of ["https://bangladesh.gov.bd/", "https://probashi.gov.bd/", "https://invest.gov.bd/"]) {
      expect(aboutLinksBlock).not.toContain(url);
    }
  });

  it("renders the diaspora reach countries beneath the section", () => {
    expect(home).toContain('className="about-diaspora-map"');
    for (const country of ["🇧🇩 বাংলাদেশ", "🇺🇸 USA", "🇸🇬 Singapore", "🇮🇪 Ireland", "🇲🇻 Maldives", "🇳🇱 Netherlands", "🇸🇪 Sweden"]) {
      expect(home).toContain(country);
    }
  });

  it("uses the requested green gradient and responsive two-to-one column layout", () => {
    expect(styles).toContain("linear-gradient(135deg, #006a4e");
    expect(styles).toContain(".about-bangladesh-layout");
    expect(styles).toContain("grid-template-columns: minmax(0, 1.08fr) minmax(0, 0.92fr)");
    expect(styles).toContain(".about-bangladesh-copy h2");
    expect(styles).toContain("color: #0d47a1");
    expect(styles).toContain("grid-template-columns: 1fr");
  });
});
