import { describe, it, expect, vi, beforeEach } from "vitest";
import type { TrpcContext } from "./_core/context";

const getSponsorInquiriesMock = vi.hoisted(() => vi.fn());

vi.mock("./db", () => ({
  getApprovedServiceReviews: vi.fn(),
  getSponsorInquiries: getSponsorInquiriesMock,
  insertServiceReview: vi.fn(),
  insertSponsorInquiry: vi.fn(),
}));

import { appRouter } from "./routers";

function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-open-id",
      name: "Kaze Amir Hamja",
      email: "amirhamja913@gmail.com",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastLoginAt: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "user-open-id",
      name: "Standard User",
      email: "user@example.com",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastLoginAt: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("sponsors.getInquiries", () => {
  beforeEach(() => {
    getSponsorInquiriesMock.mockReset();
  });

  it("allows admin to retrieve sponsor inquiries", async () => {
    const mockInquiries = [
      {
        id: 1,
        name: "Nagad Partnership Team",
        organization: "Nagad Ltd.",
        email: "marketing@nagad.com.bd",
        phone: "01965177538",
        interest: "Gold Package (৫০,০০০ টাকা)",
        message: "Let's integrate Nagad QR payments.",
        consentAccepted: 1,
        status: "new",
        createdAt: new Date(),
      },
    ];
    getSponsorInquiriesMock.mockResolvedValue(mockInquiries);

    const caller = appRouter.createCaller(createAdminContext());
    const result = await caller.sponsors.getInquiries();

    expect(result).toEqual(mockInquiries);
    expect(getSponsorInquiriesMock).toHaveBeenCalled();
  });

  it("denies non-admin users from retrieving sponsor inquiries", async () => {
    const caller = appRouter.createCaller(createUserContext());

    await expect(caller.sponsors.getInquiries()).rejects.toThrow();
  });
});
