import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const dashboardSource = readFileSync(
  new URL("../client/src/pages/AdminAnalyticsDashboard.tsx", import.meta.url),
  "utf8",
);
const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const schemaSource = readFileSync(new URL("../drizzle/schema.ts", import.meta.url), "utf8");

describe("priority Admin CMS contracts", () => {
  it("exposes Tourist Spot CRUD and gallery-management controls", () => {
    expect(dashboardSource).toContain("createTouristMutation");
    expect(dashboardSource).toContain("updateTouristMutation");
    expect(dashboardSource).toContain("deleteTouristMutation");
    expect(dashboardSource).toContain("gallery.uploadBase64");
    expect(dashboardSource).toContain("Tourist Spots");
  });

  it("exposes Media Manager replace and confirmation-gated delete actions", () => {
    expect(routerSource).toContain("replace: mediaFeatureProcedure");
    expect(dashboardSource).toContain("replaceMediaMutation");
    expect(dashboardSource).toContain("deleteMediaMutation");
    expect(dashboardSource).toContain("আপনি কি নিশ্চিত");
  });

  it("persists analytics identifiers and exposes an explicit SEO mode", () => {
    expect(schemaSource).toContain("googleAnalyticsId");
    expect(schemaSource).toContain("facebookPixelId");
    expect(routerSource).toContain("googleAnalyticsId");
    expect(routerSource).toContain("facebookPixelId");
    expect(dashboardSource).toContain('useState<"auto" | "manual">');
    expect(dashboardSource).toContain('value={seoMode}');
    expect(dashboardSource).toContain('readOnly={seoMode !== "manual"}');
  });
});
