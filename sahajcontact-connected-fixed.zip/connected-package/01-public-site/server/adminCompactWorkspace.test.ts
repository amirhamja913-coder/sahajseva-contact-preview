import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const navigation = readFileSync(
  new URL("../client/src/components/AdminWorkspaceNavigation.tsx", import.meta.url),
  "utf8",
);
const dashboard = readFileSync(
  new URL("../client/src/pages/AdminAnalyticsDashboard.tsx", import.meta.url),
  "utf8",
);

describe("compact owner workspace contracts", () => {
	  it("keeps a searchable, keyboard-reachable navigation layer for real owner controls", () => {
	    expect(navigation).toContain('id="admin-workspace-search"');
	    expect(navigation).toContain('aria-label="Admin কাজের বিভাগ"');
	    expect(navigation).toContain("scrollIntoView({ behavior: \"smooth\", block: \"start\" })");
	    expect(navigation).toContain("destination instanceof HTMLDetailsElement");
	    expect(navigation).toContain("const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)");
	    expect(navigation).toContain("aria-expanded={isMobileMenuOpen}");
	    expect(navigation).toContain("lg:hidden");
	    expect(navigation).toContain("setIsMobileMenuOpen(false);");
	    expect(navigation).toContain("এখানে কোনো সংখ্যা বানিয়ে দেখানো হয় না");
	  });

  it("preserves existing content, gallery, institutional, analytics, and operations controls as grouped work areas", () => {
    expect(dashboard).toContain("<AdminWorkspaceNavigation />");
    expect(dashboard).toContain('id="cms-homepage-builder"');
    expect(dashboard).toContain('id="cms-photo-galleries"');
    expect(dashboard).toContain('id="cms-ngo-partnership"');
    expect(dashboard).toContain('id="cms-analytics-security"');
    expect(dashboard).toContain('id="cms-operations"');
	    expect(dashboard).toContain("gallery.uploadBase64");
	    expect(dashboard).toContain("<NgoPartnershipReviewPanel");
	    expect(dashboard).toContain('id="cms-homepage-builder" className=');
	    expect(dashboard).not.toContain('<details id="cms-homepage-builder" open');
	  });
});
