import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
const projectRoot = resolve(import.meta.dirname, "..");
describe("local admin password access", () => {
  it("uses a deployment secret and a signed same-origin session", () => {
    const localAuth = readFileSync(resolve(projectRoot, "server/_core/localAuth.ts"), "utf8");
    const env = readFileSync(resolve(projectRoot, "server/_core/env.ts"), "utf8");
    expect(env).toContain("LOCAL_ADMIN_PASSWORD");
    expect(localAuth).toContain("ENV.localAdminPassword");
    expect(localAuth).toContain("sdk.signSession");
    expect(localAuth).not.toContain("ADMIN_CUSTOM_PASSWORD");
  });
});
