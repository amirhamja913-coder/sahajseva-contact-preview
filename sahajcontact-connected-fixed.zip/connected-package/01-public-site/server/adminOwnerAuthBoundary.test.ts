import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
const projectRoot = resolve(import.meta.dirname, "..");
const readProjectFile = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), "utf8");
describe("in-site Admin local-password authentication boundary", () => {
  it("uses the same-origin local password form instead of the official account handoff", () => {
    const gate = readProjectFile("client/src/components/AdminSecurityGate.tsx");
    expect(gate).toContain('fetch("/api/local-auth/login"');
    expect(gate).toContain('type="password"');
    expect(gate).toContain("credentials: \"include\"");
    expect(gate).not.toContain("/api/oauth/start");
    expect(gate).toContain('id="owner-admin-session-bar"');
  });
  it("keeps the local route and owner authorization at the server boundary", () => {
    const localAuth = readProjectFile("server/_core/localAuth.ts");
    const sdk = readProjectFile("server/_core/sdk.ts");
    const trpc = readProjectFile("server/_core/trpc.ts");
    expect(localAuth).toContain('/api/local-auth/login');
    expect(localAuth).toContain("LOCAL_ADMIN_PASSWORD");
    expect(localAuth).toContain("timingSafeEqual");
    expect(sdk).toContain("LOCAL_ADMIN_OPEN_ID");
    expect(trpc).toContain("isPortalOwner");
  });
  it("keeps ambiguous legacy Admin URLs on the owner dashboard route", () => {
    const app = readProjectFile("client/src/App.tsx");
    expect(app).toContain('function LegacyDashboardRedirect()');
    expect(app).toContain('setLocation("/admin/dashboard", { replace: true })');
  });
});
