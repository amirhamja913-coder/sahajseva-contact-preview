export const ADMIN_PERMISSION_RANK = {
  Viewer: 1,
  Editor: 2,
  Admin: 3,
  Owner: 4,
} as const;

export type AdminPermission = keyof typeof ADMIN_PERMISSION_RANK;

export function normalizeAdminPermission(role: string | null | undefined): AdminPermission | null {
  if (role === "Viewer" || role === "Editor" || role === "Admin") return role;
  // Older accounts may still carry the retired Moderator label. Treat it as the
  // least-privileged role until the migration updates the stored record.
  if (role === "Moderator") return "Viewer";
  return null;
}

export function hasAdminPermission(
  current: AdminPermission | null,
  required: AdminPermission,
) {
  if (!current) return false;
  return ADMIN_PERMISSION_RANK[current] >= ADMIN_PERMISSION_RANK[required];
}

export const ADMIN_PERMISSION_DETAILS: Record<Exclude<AdminPermission, "Owner">, string> = {
  Viewer: "শুধু রিপোর্ট, Login Activity ও আপলোডকৃত ফাইল দেখা যাবে।",
  Editor: "Viewer-এর সব সুবিধাসহ ছবি/ফাইল এবং রিপোর্ট আপডেট করা যাবে।",
  Admin: "Editor-এর সব সুবিধাসহ দৈনন্দিন প্রশাসনিক কাজ করা যাবে; মালিকের নিরাপত্তা বা সদস্য তালিকা বদলানো যাবে না।",
};

export const ADMIN_FEATURES = ["analytics", "media", "members", "security", "exports"] as const;
export type AdminFeature = (typeof ADMIN_FEATURES)[number];

const FEATURE_REQUIRED_ROLE: Record<AdminFeature, Exclude<AdminPermission, "Owner">> = {
  analytics: "Viewer",
  media: "Editor",
  members: "Admin",
  security: "Admin",
  exports: "Viewer",
};

/**
 * The Owner always retains access. Delegated members must satisfy their role's
 * base level and have the individual feature explicitly enabled.
 */
export function canUseAdminFeature(
  role: AdminPermission | null,
  feature: AdminFeature,
  enabledFeatures: readonly AdminFeature[],
) {
  if (role === "Owner") return true;
  return Boolean(role && hasAdminPermission(role, FEATURE_REQUIRED_ROLE[feature]) && enabledFeatures.includes(feature));
}
