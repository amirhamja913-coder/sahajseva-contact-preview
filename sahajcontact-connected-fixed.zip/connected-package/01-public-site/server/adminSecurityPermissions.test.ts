import { describe, expect, it } from "vitest";
import { canUseAdminFeature, hasAdminPermission, normalizeAdminPermission } from "./adminPermissions";

describe("Admin security permissions", () => {
  it("assigns ascending access from Viewer through Owner", () => {
    expect(hasAdminPermission("Viewer", "Viewer")).toBe(true);
    expect(hasAdminPermission("Viewer", "Editor")).toBe(false);
    expect(hasAdminPermission("Editor", "Viewer")).toBe(true);
    expect(hasAdminPermission("Editor", "Admin")).toBe(false);
    expect(hasAdminPermission("Admin", "Editor")).toBe(true);
    expect(hasAdminPermission("Owner", "Admin")).toBe(true);
  });

  it("keeps retired and unknown roles at safe permissions", () => {
    expect(normalizeAdminPermission("Moderator")).toBe("Viewer");
    expect(normalizeAdminPermission("Unknown")).toBeNull();
    expect(normalizeAdminPermission(null)).toBeNull();
  });

  it("enforces feature minimums while leaving the Owner unrestricted", () => {
    expect(canUseAdminFeature("Viewer", "analytics", ["analytics"])).toBe(true);
    expect(canUseAdminFeature("Viewer", "exports", ["exports"])).toBe(true);
    expect(canUseAdminFeature("Viewer", "media", ["media"])).toBe(false);
    expect(canUseAdminFeature("Editor", "media", ["media"])).toBe(true);
    expect(canUseAdminFeature("Editor", "security", ["security"])).toBe(false);
    expect(canUseAdminFeature("Admin", "security", ["security"])).toBe(true);
    expect(canUseAdminFeature("Owner", "members", [])).toBe(true);
  });

});
