import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const dashboard = readFileSync(new URL("../client/src/pages/AdminAnalyticsDashboard.tsx", import.meta.url), "utf8");
const navigation = readFileSync(new URL("../client/src/components/AdminWorkspaceNavigation.tsx", import.meta.url), "utf8");

describe("owner workspace reference-style navigation", () => {
  it("keeps the dashboard as an owner-only control center with no invented performance values", () => {
    expect(dashboard).toContain("<AdminSecurityGate>");
    expect(dashboard).toContain("SahajContact Control Center");
    expect(dashboard).toContain("কোনো public তথ্য, পেমেন্ট, partner বা analytics ফলাফল এখানে বানিয়ে দেখানো হয় না");
  });

  it("organizes only existing owner controls into responsive dashboard groups", () => {
    for (const requiredItem of ["OVERVIEW", "কনটেন্ট পরিচালনা", "অংশীদারিত্ব", "সিস্টেম ও পর্যবেক্ষণ", "cms-homepage-builder", "cms-ngo-partnership", "cms-analytics-security", "cms-operations"]) {
      expect(navigation).toContain(requiredItem);
    }
    expect(navigation).toContain("lg:hidden");
    expect(navigation).toContain("কোনো সংখ্যা বানিয়ে দেখানো হয় না");
  });
});
