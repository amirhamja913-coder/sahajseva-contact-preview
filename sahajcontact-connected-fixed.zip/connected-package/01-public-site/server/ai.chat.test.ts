import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const invokeLLMMock = vi.hoisted(() => vi.fn());

vi.mock("./_core/llm", () => ({
  invokeLLM: invokeLLMMock,
}));

import { appRouter } from "./routers";

function createPublicContext(): TrpcContext {
  return {
    user: undefined,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("ai.chat", () => {
  beforeEach(() => {
    invokeLLMMock.mockReset();
    invokeLLMMock.mockResolvedValue({
      id: "chat-test",
      created: 0,
      model: "test-model",
      choices: [
        {
          index: 0,
          finish_reason: "stop",
          message: {
            role: "assistant",
            content: "NID সংশোধনের আগে official তথ্য যাচাই করুন।",
          },
        },
      ],
    });
  });

  it("passes Bengali civic context to the LLM and returns assistant text", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.ai.chat({
      messages: [
        {
          role: "user",
          content: "NID সংশোধনের জন্য কী কী লাগবে?",
        },
      ],
    });

    expect(result).toEqual({
      content: "NID সংশোধনের আগে official তথ্য যাচাই করুন।",
    });

    expect(invokeLLMMock).toHaveBeenCalledTimes(1);
    const request = invokeLLMMock.mock.calls[0]?.[0];
    expect(request.messages[0]).toMatchObject({ role: "system" });
    expect(request.messages[0].content).toContain("সহজসেবা কোনো সরকারি অফিস নয়");
    expect(request.messages.at(-1)).toEqual({
      role: "user",
      content: "NID সংশোধনের জন্য কী কী লাগবে?",
    });
  });

  it("rejects empty quick-reply or manual message content", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(
      caller.ai.chat({
        messages: [{ role: "user", content: "   " }],
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
