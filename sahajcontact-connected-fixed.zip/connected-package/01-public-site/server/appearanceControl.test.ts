import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(root, relativePath), "utf8");

describe("Owner-safe public appearance control", () => {
  it("persists a constrained palette, background and readable layout preferences", () => {
    const schema = read("drizzle/schema.ts");
    const router = read("server/routers.ts");
    expect(schema).toContain('pageBackgroundColor: varchar("pageBackgroundColor"');
    expect(schema).toContain('pageBackgroundImageUrl: text("pageBackgroundImageUrl")');
    expect(schema).toContain('siteTextColor: varchar("siteTextColor"');
    expect(schema).toContain('fontScale: mysqlEnum("fontScale", ["small", "standard", "large"])');
    expect(schema).toContain('layoutDensity: mysqlEnum("layoutDensity", ["compact", "standard", "relaxed"])');
    expect(router).toContain("const visualAppearanceInput = z.object");
    expect(router).toContain("saveAppearanceSettings: ownerOnlyProcedure");
  });

  it("mounts an owner-only Dashboard panel and scopes saved variables to the public shell", () => {
    const panel = read("client/src/components/AppearanceControlPanel.tsx");
    const dashboard = read("client/src/pages/AdminAnalyticsDashboard.tsx");
    const home = read("client/src/pages/Home.tsx");
    const css = read("client/src/index.css");
    expect(panel).toContain("Visual appearance saved and published.");
    expect(panel).toContain("pageBackgroundImageUrl");
    expect(dashboard).toContain("<AppearanceControlPanel isOwner={isOwner} />");
    expect(home).toContain("ownerAppearanceStyle");
    expect(home).toContain("data-font-scale");
    expect(css).toContain("--owner-page-background");
    expect(css).toContain("data-layout-density");
  });
});
