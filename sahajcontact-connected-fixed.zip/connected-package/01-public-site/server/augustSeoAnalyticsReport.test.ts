import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = path.resolve(import.meta.dirname, "..");
const readProjectFile = (relativePath: string) => fs.readFileSync(path.join(projectRoot, relativePath), "utf8");

describe("legacy public SEO and analytics report route", () => {
  it("redirects the old public report URL to the single automatic-report hub", () => {
    const app = readProjectFile("client/src/App.tsx");

    expect(app).toContain('path="/reports/august-2026" component={LegacyAugust2026ReportRedirect}');
    expect(app).toContain('setLocation("/#public-seo-report", { replace: true })');
    expect(app).not.toContain("August2026SeoAnalyticsReport");
  });

  it("keeps the automatic snapshot as the only public reporting content", () => {
    const publicSnapshot = readProjectFile("client/src/components/PublicSeoSnapshot.tsx");

    expect(publicSnapshot).toContain("প্রথম স্বয়ংক্রিয় SEO update-এর অপেক্ষায়");
    expect(publicSnapshot).not.toContain("/reports/august-2026");
    expect(publicSnapshot).toContain("getPublicSeoSummary");
  });
});
