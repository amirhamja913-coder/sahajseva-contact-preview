import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { bangladeshMapDivisions, getBangladeshMapDivision } from "../client/src/lib/bangladeshMapData";

const mapComponentSource = readFileSync(
  fileURLToPath(new URL("../client/src/components/BangladeshMapInteractive.tsx", import.meta.url)),
  "utf8",
);

describe("interactive Bangladesh map data", () => {
  it("contains the eight Bangladesh divisions with unique visual anchors", () => {
    expect(bangladeshMapDivisions).toHaveLength(8);
    expect(new Set(bangladeshMapDivisions.map((division) => division.id)).size).toBe(8);
    expect(bangladeshMapDivisions.every((division) => division.x >= 0 && division.x <= 100)).toBe(true);
    expect(bangladeshMapDivisions.every((division) => division.y >= 0 && division.y <= 100)).toBe(true);
  });

  it("keeps the hero map canvas free from visible copy overlays and marker chrome", () => {
    expect(mapComponentSource).toContain("hero-map-canvas");
    expect(mapComponentSource).not.toContain("hero-map-side-content");
    expect(mapComponentSource).not.toContain("hero-map-info");
    expect(mapComponentSource).not.toContain("hero-map-side-caption");
    expect(mapComponentSource).not.toContain("hero-map-hotspot-dot");
    expect(mapComponentSource).not.toContain("hero-map-hotspot-name");
  });

  it("keeps a semantic map icon visible if the decorative map artwork cannot load", () => {
    expect(mapComponentSource).toContain('import { MapPinned } from "lucide-react"');
    expect(mapComponentSource).toContain("const [mapArtworkAvailable, setMapArtworkAvailable] = useState(true)");
    expect(mapComponentSource).toContain("onError={() => setMapArtworkAvailable(false)}");
    expect(mapComponentSource).toContain("<MapPinned");
  });

  it("keeps each division connected to an official government portal", () => {
    expect(
      bangladeshMapDivisions.every(
        (division) => division.href.startsWith("https://") && division.href.endsWith("gov.bd/"),
      ),
    ).toBe(true);
    expect(getBangladeshMapDivision("dhaka")?.name).toBe("ঢাকা বিভাগ");
  });
});
