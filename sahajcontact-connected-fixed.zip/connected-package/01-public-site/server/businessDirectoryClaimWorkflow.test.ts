import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(import.meta.dirname, "..");
const source = (path: string) => readFileSync(resolve(projectRoot, path), "utf8");

describe("Business Directory ownership/correction claim review", () => {
  it("stores only minimal private review fields and defaults every claim to pending", () => {
    const schema = source("drizzle/schema.ts");
    const migration = source("drizzle/0048_bright_gamma_corps.sql");

    expect(schema).toContain('export const businessDirectoryClaimRequests = mysqlTable("business_directory_claim_requests"');
    expect(schema).toContain("listingId: int(\"listingId\").notNull()");
    expect(schema).toContain('status: mysqlEnum("status", ["pending", "reviewed", "declined", "archived"]).default("pending").notNull()');
    expect(schema).toContain("ownerNote: text(\"ownerNote\")");
    expect(migration).toContain("CREATE TABLE `business_directory_claim_requests`");
    expect(migration).not.toMatch(/\bDROP\b|\bDELETE\b|\bALTER TABLE\b/i);
  });

  it("accepts a claim only after server-side confirmation that its target is owner-published", () => {
    const db = source("server/db.ts");
    const router = source("server/routers.ts");

    expect(db).toContain("createBusinessDirectoryClaimRequestForPublishedListing");
    expect(db).toContain("eq(businessDirectorySubmissions.id, request.listingId)");
    expect(db).toContain('eq(businessDirectorySubmissions.status, "published")');
    expect(db).toContain("if (!listing[0]) return false");
    expect(router).toContain("submitClaimRequest: publicProcedure");
    expect(router).toContain('message: "শুধু বর্তমানে প্রকাশিত তথ্যের জন্য review অনুরোধ দেওয়া যায়।"');
  });

  it("requires affirmative consent and keeps claimant contacts and owner notes out of public reads", () => {
    const db = source("server/db.ts");
    const router = source("server/routers.ts");

    expect(router).toMatch(/submitClaimRequest: publicProcedure[\s\S]{0,1600}consentAccepted: z\.boolean\(\)\.refine\(value => value/);
    expect(router).toMatch(/ownerClaimList: ownerOnlyProcedure\.query/);
    expect(router).toMatch(/updateClaimReview: ownerOnlyProcedure/);
    expect(db).toMatch(/getPublishedBusinessDirectoryListings[\s\S]{0,1000}\.where\(eq\(businessDirectorySubmissions\.status, "published"\)\)/);
    expect(db).not.toMatch(/getPublishedBusinessDirectoryListings[\s\S]{0,1000}contactEmail:/);
    expect(db).not.toMatch(/getPublishedBusinessDirectoryListings[\s\S]{0,1000}contactPhone:/);
    expect(db).not.toMatch(/getPublishedBusinessDirectoryListings[\s\S]{0,1000}ownerNote:/);
  });

  it("shows no arbitrary listing-ID field and clearly rejects verification, payment, licence or badge implications", () => {
    const requestUi = source("client/src/components/BusinessDirectoryClaimRequest.tsx");
    const reviewUi = source("client/src/components/BusinessDirectoryClaimReviewPanel.tsx");
    const dashboard = source("client/src/pages/AdminAnalyticsDashboard.tsx");
    const navigation = source("client/src/components/AdminWorkspaceNavigation.tsx");

    expect(requestUi).toContain("listClaimablePublished.useQuery");
    expect(requestUi).toContain("!hasPublishedListings");
    expect(requestUi).toContain("বাস্তব কোনো business record owner প্রকাশ করলে");
    expect(requestUi).not.toContain('type="number"');
    expect(requestUi).toContain("সরকারি যাচাই");
    expect(requestUi).toContain("claimed/verified");
    expect(requestUi).toContain("NID, trade-licence");
    expect(reviewUi).toContain("কোনো public listing স্বয়ংক্রিয়ভাবে বদলায়নি");
    expect(dashboard).toContain("<BusinessDirectoryClaimReviewPanel isOwner={isOwner} />");
    expect(dashboard).toContain("<AdminSecurityGate>");
    expect(navigation).toContain('id: "business-directory-claim-review"');
  });
});
