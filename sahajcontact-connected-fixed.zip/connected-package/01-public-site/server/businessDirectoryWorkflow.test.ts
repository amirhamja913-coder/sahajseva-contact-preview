import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(import.meta.dirname, "..");
const source = (path: string) => readFileSync(resolve(projectRoot, path), "utf8");

describe("Business Directory review-first workflow", () => {
  it("stores requests privately and only selects explicitly published public fields", () => {
    const schema = source("drizzle/schema.ts");
    const db = source("server/db.ts");

    expect(schema).toContain("export const businessDirectorySubmissions");
    expect(schema).toContain('status: mysqlEnum("status", ["pending", "published", "declined", "archived"])');
    expect(schema).toContain("contactEmail: varchar");
    expect(schema).toContain("contactPhone: varchar");
    expect(db).toContain("createBusinessDirectorySubmission");
    expect(db).toContain("getPublishedBusinessDirectoryListings");
    expect(db).toContain('.where(eq(businessDirectorySubmissions.status, "published"))');
    expect(db).toContain("publicDescription: businessDirectorySubmissions.publicDescription");
    expect(db).not.toMatch(/getPublishedBusinessDirectoryListings[\s\S]{0,1000}contactEmail:/);
    expect(db).not.toMatch(/getPublishedBusinessDirectoryListings[\s\S]{0,1000}contactPhone:/);
  });

  it("requires consent for a pending submission and reserves review changes for the owner", () => {
    const router = source("server/routers.ts");

    expect(router).toContain("businessDirectory: router({");
    expect(router).toContain("listPublished: publicProcedure.query");
    expect(router).toContain("consentAccepted: z.boolean().refine(value => value");
    expect(router).toContain('status: "pending",');
    expect(router).toContain("ownerList: ownerOnlyProcedure.query");
    expect(router).toContain("updateReview: ownerOnlyProcedure");
    expect(router).toContain('z.enum(["pending", "published", "declined", "archived"])');
  });

  it("keeps the public directory empty until publication and labels it without false verification claims", () => {
    const page = source("client/src/pages/BusinessDirectoryPage.tsx");
    const app = source("client/src/App.tsx");

    expect(app).toContain('path="/business-directory"');
    expect(page).toContain("businessDirectory.listPublished.useQuery");
    expect(page).toContain("No business listing has been published yet.");
    expect(page).toContain("এখনও কোনো ব্যবসায়িক তথ্য প্রকাশ করা হয়নি।");
    expect(page).toContain("Publication is not a licence check, government approval, endorsement, rating or paid placement.");
    expect(page).toContain("আর্থিক তথ্য, সরকারি পরিচয়পত্র, পাসওয়ার্ড, OTP বা payment তথ্য দেব না");
  });

  it("renders private requester contact only inside the existing owner-only dashboard workspace", () => {
    const dashboard = source("client/src/pages/AdminAnalyticsDashboard.tsx");
    const panel = source("client/src/components/BusinessDirectoryReviewPanel.tsx");
    const navigation = source("client/src/components/AdminWorkspaceNavigation.tsx");

    expect(dashboard).toContain("<AdminSecurityGate>");
    expect(dashboard).toContain("<BusinessDirectoryReviewPanel isOwner={isOwner} />");
    expect(panel).toContain("businessDirectory.ownerList.useQuery");
    expect(panel).toContain("businessDirectory.updateReview.useMutation");
    expect(panel).toContain("ব্যক্তিগত যোগাযোগের তথ্য public হবে না");
    expect(navigation).toContain('id: "business-directory-review"');
  });
});
