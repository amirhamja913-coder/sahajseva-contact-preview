import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const utilitySource = readFileSync(
  new URL("../client/src/components/UtilityAndExpatriateSections.tsx", import.meta.url),
  "utf8",
);
const externalLinkSource = readFileSync(
  new URL("../client/src/components/ExternalLinkWithFallback.tsx", import.meta.url),
  "utf8",
);

describe("নাগরিক ও ভূমি সেবা section", () => {
  it("keeps civic and land services inside the dedicated citizen folder without a duplicate appended folder", () => {
    const citizenIndex = utilitySource.indexOf('id="citizen-services"');
    const womenIndex = utilitySource.indexOf('id="women-children-services"');

    expect(citizenIndex).toBeGreaterThanOrEqual(0);
    expect(womenIndex).toBeGreaterThan(citizenIndex);
    expect(utilitySource).toContain('data-utility-folder="citizen-services"');
    expect(utilitySource).toContain('id="citizen-services-content"');
    expect(utilitySource).not.toContain('id="civic-land-services"');
    expect(utilitySource).not.toContain('data-utility-folder="civic-land-services"');
    expect(utilitySource).not.toContain("🏠 ০৮ / নাগরিক ও ভূমি সেবা");
  });

  it("keeps the identity, passport, land, and registration cards in the citizen section", () => {
    const citizenStart = utilitySource.indexOf('id="citizen-services"');
    const citizenEnd = utilitySource.indexOf('id="women-children-services"');
    const citizenSection = utilitySource.slice(citizenStart, citizenEnd);
    const expectedCards = [
      ["জাতীয় পরিচয়পত্র (NID)", "NID নিবন্ধন, তথ্য সংশোধন, পুনর্মুদ্রণ ও নাগরিক পরিচয়-সংক্রান্ত অফিসিয়াল সেবা দেখুন।"],
      ["ই-পাসপোর্ট", "ই-পাসপোর্ট আবেদন, ফি, অ্যাপয়েন্টমেন্ট ও আবেদন-স্ট্যাটাসের সরকারি তথ্য দেখুন।"],
      ["ভূমি সেবা", "ই-নামজারি, ভূমি উন্নয়ন কর, খতিয়ান/রেকর্ড ও ভূমি-সংক্রান্ত সরকারি সেবার entry point খুঁজুন।"],
      ["জন্ম ও মৃত্যু নিবন্ধন", "জন্মনিবন্ধন, মৃত্যুনিবন্ধন, সংশোধন ও যাচাই-সংক্রান্ত সরকারি পোর্টাল দেখুন।"],
    ];

    for (const [title, description] of expectedCards) {
      expect(citizenSection).toContain(`<h3>${title}</h3>`);
      expect(citizenSection).toContain(`<p>${description}</p>`);
    }
  });

  it("uses official government destinations for the consolidated civic cards", () => {
    const officialLinks = [
      "https://services.nidw.gov.bd/",
      "https://www.epassport.gov.bd/",
      "https://land.gov.bd/",
      "https://bdris.gov.bd/",
    ];

    for (const link of officialLinks) {
      expect(link).toMatch(/^https:\/\/[\w.-]+\.gov\.bd(?:\/|$)/);
      expect(utilitySource).toContain(link);
    }
  });

  it("keeps the consolidated citizen safety guidance visible", () => {
    expect(utilitySource).toContain("NID নম্বর, জন্মতারিখ ও OTP শুধু services.nidw.gov.bd-এর মতো অফিসিয়াল পোর্টালেই দিন।");
    expect(utilitySource).toContain("পাসপোর্টের তথ্য ও পেমেন্ট কেবল epassport.gov.bd-এর অফিসিয়াল নির্দেশনা অনুযায়ী করুন।");
    expect(utilitySource).toContain("জমির রেকর্ড বা লেনদেনের আগে দাগ, খতিয়ান ও মালিকানার তথ্য সংশ্লিষ্ট অফিসিয়াল সিস্টেমে মিলিয়ে নিন।");
    expect(utilitySource).toContain("নাম, জন্মতারিখ ও পরিবারের তথ্য জমা দেওয়ার আগে স্থানীয় নিবন্ধক কার্যালয়ের নির্দেশনা যাচাই করুন।");
    expect(utilitySource).toContain("সাহজসেবা কোনো সরকারি সংস্থা নয়; আমরা শুধু তথ্যভিত্তিক অফিসিয়াল entry point দেখাই এবং OTP/PIN চাই না।");
  });

  it("opens official links in a new tab with safe rel attributes", () => {
    expect(externalLinkSource).toContain('target="_blank"');
    expect(externalLinkSource).toContain('rel="noopener noreferrer"');
  });
});

export {};
