import { describe, expect, it } from "vitest";

describe("Official Civic Destination & External Fallback Verification", () => {
  it("verifies official helpline and portal URLs used across SahajSeva", () => {
    const officialDestinations = {
      emergency: "https://999.gov.bd",
      legalAid: "http://nlaso.gov.bd",
      nidPortal: "https://services.nidw.gov.bd",
      passportPortal: "https://www.epassport.gov.bd",
      bstiPortal: "https://bsti.gov.bd",
    };

    expect(officialDestinations.emergency).toContain("999.gov.bd");
    expect(officialDestinations.legalAid).toContain("nlaso.gov.bd");
    expect(officialDestinations.nidPortal).toContain("services.nidw.gov.bd");
    expect(officialDestinations.passportPortal).toContain("www.epassport.gov.bd");
    expect(officialDestinations.bstiPortal).toContain("bsti.gov.bd");
  });
});
