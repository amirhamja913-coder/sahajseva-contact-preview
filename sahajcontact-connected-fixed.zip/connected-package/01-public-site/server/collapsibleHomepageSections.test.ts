import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const homeSource = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const financialSource = readFileSync(new URL("../client/src/components/FinancialServicesSection.tsx", import.meta.url), "utf8");
const educationSource = readFileSync(new URL("../client/src/components/EducationHubSection.tsx", import.meta.url), "utf8");
const reviewsSource = readFileSync(new URL("../client/src/components/ServiceReviews.tsx", import.meta.url), "utf8");
const utilitySource = readFileSync(new URL("../client/src/components/UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");
const utilityEnglishSource = readFileSync(new URL("../client/src/components/UtilityAndExpatriateSectionsEnglish.tsx", import.meta.url), "utf8");

describe("requested homepage disclosure controls", () => {
  it("keeps the Bank, Health, and Education folders closed until the visitor opens them", () => {
    expect(financialSource).toContain('data-service-folder="bank-directory"');
    expect(financialSource).toMatch(/<details[^>]*data-service-folder="bank-directory"/);
    expect(financialSource).not.toMatch(/<details[^>]*data-service-folder="bank-directory"[^>]*\bopen\b/);

    expect(homeSource).toContain('data-service-folder="healthcare-services"');
    expect(homeSource).toMatch(/<details[^>]*data-service-folder="healthcare-services"/);
    expect(homeSource).not.toMatch(/<details[^>]*data-service-folder="healthcare-services"[^>]*\bopen\b/);

    expect(educationSource).toContain('data-service-folder="education-hub"');
    expect(educationSource).toMatch(/<details[^>]*data-service-folder="education-hub"/);
    expect(educationSource).not.toMatch(/<details[^>]*data-service-folder="education-hub"[^>]*\bopen\b/);
  });

  it("shows only the newest feedback at first and exposes a semantic control for all approved feedback", () => {
    expect(reviewsSource).toContain("showAllReviews");
    expect(reviewsSource).toContain("latestReview");
    expect(reviewsSource).toContain("visibleReviews");
    expect(reviewsSource).toContain("সব মতামত দেখুন");
    expect(reviewsSource).toContain("aria-expanded={showAllReviews}");
  });

  it("keeps dense utility, expatriate, civic guidance and support information closed by default", () => {
    for (const folder of ["bill-payment", "agriculture-services", "citizen-services", "women-children-services", "law-enforcement-services", "bangladesh-media-services"]) {
      expect(utilitySource).toMatch(new RegExp(`<details[^>]*data-utility-folder="${folder}"`));
      expect(utilitySource).not.toMatch(new RegExp(`<details[^>]*data-utility-folder="${folder}"[^>]*\\bopen\\b`));
    }
    expect(utilityEnglishSource).toContain('data-utility-folder={id}');
    expect(utilityEnglishSource).not.toMatch(/<details[^>]*data-utility-folder=\{id\}[^>]*\bopen\b/);
    for (const folder of ["civic-guidance", "support-information"]) {
      expect(homeSource).toMatch(new RegExp(`<details[^>]*data-service-folder="${folder}"`));
      expect(homeSource).not.toMatch(new RegExp(`<details[^>]*data-service-folder="${folder}"[^>]*\\bopen\\b`));
    }
  });
});
