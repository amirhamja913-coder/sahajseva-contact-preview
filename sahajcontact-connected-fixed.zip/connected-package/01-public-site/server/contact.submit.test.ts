import { beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import type { TrpcContext } from "./_core/context";

const insertContactLeadMock = vi.hoisted(() => vi.fn());
const getContactLeadsMock = vi.hoisted(() => vi.fn());
const updateContactLeadStatusMock = vi.hoisted(() => vi.fn());
const deleteContactLeadMock = vi.hoisted(() => vi.fn());

vi.mock("./db", () => ({
  getApprovedServiceReviews: vi.fn(),
  insertServiceReview: vi.fn(),
  insertContactLead: insertContactLeadMock,
  getContactLeads: getContactLeadsMock,
  updateContactLeadStatus: updateContactLeadStatusMock,
  deleteContactLead: deleteContactLeadMock,
}));

import { appRouter } from "./routers";

function createPublicContext(): TrpcContext {
  return {
    user: undefined,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createOwnerContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "owner-open-id",
      name: "Portal Owner",
      email: "amirhamja913@gmail.com",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastLoginAt: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createNonOwnerContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "another-admin",
      name: "Another Admin",
      email: "admin@example.com",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastLoginAt: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const validEnquiry = {
  name: "রওশন আরা",
  mobile: "01900000000",
  email: "visitor@example.org",
  subject: "সেবা সম্পর্কে জানতে চাই",
  message: "নিকটস্থ সেবার তথ্য জানাতে যোগাযোগ করতে চাই।",
  consentAccepted: true,
};

describe("contact.submit", () => {
  beforeEach(() => {
    insertContactLeadMock.mockReset();
    insertContactLeadMock.mockResolvedValue(undefined);
    getContactLeadsMock.mockReset();
    updateContactLeadStatusMock.mockReset();
    deleteContactLeadMock.mockReset();
  });

  it("stores only a consented enquiry in the private lead model", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.contact.submit(validEnquiry)).resolves.toEqual({ success: true });

    expect(insertContactLeadMock).toHaveBeenCalledWith({
      name: validEnquiry.name,
      mobile: validEnquiry.mobile,
      email: validEnquiry.email,
      subject: validEnquiry.subject,
      message: validEnquiry.message,
      source: "contact",
      consentAt: expect.any(Date),
      status: "new",
    });
  });

  it("rejects submission without affirmative consent before writing data", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.contact.submit({ ...validEnquiry, consentAccepted: false })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(insertContactLeadMock).not.toHaveBeenCalled();
  });

  it("rejects OTP, credential, NID, and financial-information prompts before writing data", async () => {
    const caller = appRouter.createCaller(createPublicContext());

    await expect(caller.contact.submit({ ...validEnquiry, message: "আমার OTP এবং পাসওয়ার্ড দিয়ে সাহায্য করুন।" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(insertContactLeadMock).not.toHaveBeenCalled();
  });
});

describe("siteManagement.management leads", () => {
  it("allows only the established owner boundary to retrieve and update private leads", async () => {
    const records = [{ id: 9, name: "রওশন আরা", mobile: "01900000000", subject: "সেবা সম্পর্কে জানতে চাই", message: "তথ্য চাই", status: "new" }];
    getContactLeadsMock.mockResolvedValue(records);
    updateContactLeadStatusMock.mockResolvedValue(undefined);

    const owner = appRouter.createCaller(createOwnerContext());
    await expect(owner.siteManagement.management.getLeads()).resolves.toEqual(records);
    await expect(owner.siteManagement.management.updateLeadStatus({ id: 9, status: "reviewed" })).resolves.toEqual({ success: true });
    expect(updateContactLeadStatusMock).toHaveBeenCalledWith(9, "reviewed");

    const nonOwner = appRouter.createCaller(createNonOwnerContext());
    await expect(nonOwner.siteManagement.management.getLeads()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("Contact page contract", () => {
  it("uses the tRPC contact mutation rather than a timer-only success state", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/Contact.tsx"), "utf8");

    expect(source).toContain("trpc.contact.submit.useMutation()");
    expect(source).toContain('name="consentAccepted"');
    expect(source).not.toContain("submissionTimerRef");
    expect(source).not.toContain("window.setTimeout(() => {");
  });
});
