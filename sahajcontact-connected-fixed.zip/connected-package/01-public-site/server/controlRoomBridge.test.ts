import express from "express";
import type { AddressInfo } from "node:net";
import { beforeEach, describe, expect, it, vi } from "vitest";

const dbMocks = vi.hoisted(() => ({
  getSiteContentSettings: vi.fn(),
  insertSiteOperationalLog: vi.fn(),
  saveSiteContentSettings: vi.fn(),
}));

vi.mock("./db", () => dbMocks);

import {
  CONTROL_ROOM_SIGNATURE_HEADER,
  CONTROL_ROOM_TIMESTAMP_HEADER,
  assertControlRoomActionAllowed,
  createControlRoomSignature,
  isControlRoomRequestAuthorized,
  parseControlRoomPatch,
} from "./controlRoomBridge";

const secret = process.env.CONTROL_ROOM_SHARED_SECRET ?? "";
const controlRoomTestBaseUrl = process.env.CONTROL_ROOM_TEST_BASE_URL ?? "";

function enabledSettings() {
  return {
    remoteMaintenanceMode: 0,
    remoteMaintenanceMessage: "সেবা চালু আছে",
    remoteSmsEnabled: 1,
    remoteSignupEnabled: 1,
    remotePaymentEnabled: 1,
    remoteLoginEnabled: 1,
    remoteControlUpdatedAt: null,
    remoteControlUpdatedBy: null,
  };
}

describe("Control Room bridge", () => {
  beforeEach(() => {
    dbMocks.getSiteContentSettings.mockReset();
    dbMocks.getSiteContentSettings.mockResolvedValue(enabledSettings());
  });

  it("accepts only the intended SahajContact feature-control payload", () => {
    expect(parseControlRoomPatch({
      siteId: "sahajcontact",
      maintenanceMode: true,
      maintenanceMessage: "নির্ধারিত রক্ষণাবেক্ষণ চলছে",
      features: { sms: false, signup: true, payment: false, login: true },
    })).toMatchObject({ siteId: "sahajcontact", maintenanceMode: true, features: { payment: false } });
    expect(parseControlRoomPatch({ siteId: "other-site", maintenanceMode: true, maintenanceMessage: "x", features: {} })).toBeNull();
  });

  it("rejects unsigned or stale external requests", () => {
    const request = { method: "GET", path: "/api/control-room/v1/status", originalUrl: "/api/control-room/v1/status", body: undefined, header: () => null };
    expect(isControlRoomRequestAuthorized(request, "test-secret")).toBe(false);
  });

  it("accepts the original signed path when a proxy exposes a shortened route path", () => {
    const timestamp = String(Date.now());
    const originalPath = "/api/control-room/v1/status";
    const signature = createControlRoomSignature("GET", originalPath, timestamp, undefined, "test-secret");
    const request = {
      method: "GET",
      path: "/v1/status",
      originalUrl: originalPath,
      body: undefined,
      header: (name: string) => name === CONTROL_ROOM_TIMESTAMP_HEADER ? timestamp : name === CONTROL_ROOM_SIGNATURE_HEADER ? signature : null,
    };
    expect(isControlRoomRequestAuthorized(request, "test-secret")).toBe(true);
  });

  it("normalizes an empty JSON body on signed status requests", () => {
    const timestamp = String(Date.now());
    const path = "/api/control-room/v1/status";
    const signature = createControlRoomSignature("GET", path, timestamp, undefined, "test-secret");
    const request = {
      method: "GET",
      path,
      originalUrl: path,
      body: {},
      header: (name: string) => name === CONTROL_ROOM_TIMESTAMP_HEADER ? timestamp : name === CONTROL_ROOM_SIGNATURE_HEADER ? signature : null,
    };
    expect(isControlRoomRequestAuthorized(request, "test-secret")).toBe(true);
  });

  it("blocks all public actions while remote maintenance is active", async () => {
    dbMocks.getSiteContentSettings.mockResolvedValue({ ...enabledSettings(), remoteMaintenanceMode: 1, remoteMaintenanceMessage: "জরুরি কাজ চলছে" });
    await expect(assertControlRoomActionAllowed("payment")).rejects.toThrow("জরুরি কাজ চলছে");
  });

  it("blocks only the disabled approved feature while the site remains online", async () => {
    dbMocks.getSiteContentSettings.mockResolvedValue({ ...enabledSettings(), remotePaymentEnabled: 0 });
    await expect(assertControlRoomActionAllowed("payment")).rejects.toThrow("পেমেন্ট সেবা সাময়িকভাবে বন্ধ");
    await expect(assertControlRoomActionAllowed("login")).resolves.toBeUndefined();
  });

  it.skipIf(!secret)("authorizes the lightweight signed status endpoint with the protected bridge credential", async () => {
    const timestamp = String(Date.now());
    const path = "/api/control-room/v1/status";
    const signature = createControlRoomSignature("GET", path, timestamp, undefined, secret);
    const app = express();
    app.get(path, (req, res) => {
      if (!isControlRoomRequestAuthorized(req, secret)) {
        res.status(401).json({ success: false });
        return;
      }
      res.json({ success: true, data: { siteId: "sahajcontact" } });
    });
    const server = await new Promise<ReturnType<typeof app.listen>>(resolve => {
      const instance = app.listen(0, "127.0.0.1", () => resolve(instance));
    });
    const port = (server.address() as AddressInfo).port;
    try {
      const response = await fetch(`http://127.0.0.1:${port}${path}`, {
        headers: {
          [CONTROL_ROOM_TIMESTAMP_HEADER]: timestamp,
          [CONTROL_ROOM_SIGNATURE_HEADER]: signature,
        },
        signal: AbortSignal.timeout(8_000),
      });

      expect(response.status).toBe(200);
      await expect(response.json()).resolves.toMatchObject({ success: true, data: { siteId: "sahajcontact" } });
    } finally {
      await new Promise<void>(resolve => server.close(() => resolve()));
    }
  }, 10_000);

  it.skipIf(!secret || !controlRoomTestBaseUrl)("authorizes the running SahajContact status route end to end", async () => {
    const timestamp = String(Date.now());
    const path = "/api/control-room/v1/status";
    const signature = createControlRoomSignature("GET", path, timestamp, undefined, secret);
    const response = await fetch(`${controlRoomTestBaseUrl.replace(/\/$/, "")}${path}`, {
      headers: {
        [CONTROL_ROOM_TIMESTAMP_HEADER]: timestamp,
        [CONTROL_ROOM_SIGNATURE_HEADER]: signature,
      },
      signal: AbortSignal.timeout(8_000),
    });

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ success: true, data: { siteId: "sahajcontact" } });
  }, 10_000);

  it.skipIf(!secret || !controlRoomTestBaseUrl)("accepts a signed all-services-enabled control update end to end", async () => {
    const path = "/api/control-room/v1/site-controls";
    const body = {
      siteId: "sahajcontact",
      maintenanceMode: false,
      maintenanceMessage: "সেবা চালু আছে",
      features: { sms: true, signup: true, payment: true, login: true },
    };
    const timestamp = String(Date.now());
    const signature = createControlRoomSignature("POST", path, timestamp, body, secret);
    const response = await fetch(`${controlRoomTestBaseUrl.replace(/\/$/, "")}${path}`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        [CONTROL_ROOM_TIMESTAMP_HEADER]: timestamp,
        [CONTROL_ROOM_SIGNATURE_HEADER]: signature,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8_000),
    });

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({
      success: true,
      data: { maintenanceMode: false, features: { sms: true, signup: true, payment: true, login: true } },
    });
  }, 10_000);
});
