import { createHmac, timingSafeEqual } from "node:crypto";
import type { Request } from "express";
import { getSiteContentSettings, insertSiteOperationalLog, saveSiteContentSettings } from "./db";

export const CONTROL_ROOM_TIMESTAMP_HEADER = "x-sahajcontrol-timestamp";
export const CONTROL_ROOM_SIGNATURE_HEADER = "x-sahajcontrol-signature";
export const CONTROL_ROOM_SITE_ID = "sahajcontact";
const MAX_CLOCK_SKEW_MS = 2 * 60 * 1000;

export type ControlRoomFeatureState = {
  sms: boolean;
  signup: boolean;
  payment: boolean;
  login: boolean;
};

export type ControlRoomPatch = {
  siteId: typeof CONTROL_ROOM_SITE_ID;
  maintenanceMode: boolean;
  maintenanceMessage: string;
  features: ControlRoomFeatureState;
};

type MinimalRequest = Pick<Request, "header" | "method" | "path" | "originalUrl" | "body">;

function canonicalPayload(method: string | undefined, path: string | undefined, timestamp: string, body: unknown) {
  const isEmptyObject = Boolean(body && typeof body === "object" && !Array.isArray(body) && Object.keys(body as Record<string, unknown>).length === 0);
  const serializedBody = body === undefined || body === null || isEmptyObject ? "" : JSON.stringify(body);
  return `${timestamp}.${String(method ?? "GET").toUpperCase()}.${path ?? ""}.${serializedBody}`;
}

export function createControlRoomSignature(method: string, path: string, timestamp: string, body: unknown, secret: string) {
  return createHmac("sha256", secret).update(canonicalPayload(method, path, timestamp, body)).digest("base64");
}

function safeEquals(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

export function isControlRoomRequestAuthorized(request: MinimalRequest, secret: string) {
  const timestamp = request.header(CONTROL_ROOM_TIMESTAMP_HEADER) ?? "";
  const receivedSignature = request.header(CONTROL_ROOM_SIGNATURE_HEADER) ?? "";
  const requestTime = Number(timestamp);
  if (!secret || !Number.isFinite(requestTime) || Math.abs(Date.now() - requestTime) > MAX_CLOCK_SKEW_MS || !receivedSignature) {
    return false;
  }

  const paths = Array.from(new Set([
    request.path ?? "",
    String(request.originalUrl ?? "").split("?")[0],
  ].filter(Boolean)));
  return paths.some(path => {
    const expectedSignature = createControlRoomSignature(request.method ?? "GET", path, timestamp, request.body, secret);
    return safeEquals(receivedSignature, expectedSignature);
  });
}

function isFeatureState(value: unknown): value is ControlRoomFeatureState {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Record<string, unknown>;
  return ["sms", "signup", "payment", "login"].every(key => typeof candidate[key] === "boolean");
}

export function parseControlRoomPatch(input: unknown): ControlRoomPatch | null {
  if (!input || typeof input !== "object") return null;
  const candidate = input as Record<string, unknown>;
  const message = typeof candidate.maintenanceMessage === "string" ? candidate.maintenanceMessage.trim() : "";
  if (
    candidate.siteId !== CONTROL_ROOM_SITE_ID ||
    typeof candidate.maintenanceMode !== "boolean" ||
    !isFeatureState(candidate.features) ||
    message.length > 280
  ) {
    return null;
  }

  return {
    siteId: CONTROL_ROOM_SITE_ID,
    maintenanceMode: candidate.maintenanceMode,
    maintenanceMessage: message || "সাইট সাময়িক রক্ষণাবেক্ষণে আছে। অনুগ্রহ করে কিছুক্ষণ পরে আবার চেষ্টা করুন।",
    features: candidate.features,
  };
}

export async function getControlRoomStatus() {
  const settings = await getSiteContentSettings();
  return {
    siteId: CONTROL_ROOM_SITE_ID,
    maintenanceMode: Boolean(settings?.remoteMaintenanceMode),
    maintenanceMessage: settings?.remoteMaintenanceMessage ?? "সেবা চালু আছে",
    features: {
      sms: settings?.remoteSmsEnabled !== 0,
      signup: settings?.remoteSignupEnabled !== 0,
      payment: settings?.remotePaymentEnabled !== 0,
      login: settings?.remoteLoginEnabled !== 0,
    },
    lastUpdatedAt: settings?.remoteControlUpdatedAt?.toISOString() ?? null,
    source: settings?.remoteControlUpdatedBy === "Google Apps Script Control Room" ? "control_room" : "dashboard",
  } as const;
}

export async function assertControlRoomActionAllowed(action: keyof ControlRoomFeatureState) {
  const status = await getControlRoomStatus();
  if (status.maintenanceMode) {
    throw new Error(status.maintenanceMessage || "সাইট সাময়িক রক্ষণাবেক্ষণে আছে। অনুগ্রহ করে কিছুক্ষণ পরে আবার চেষ্টা করুন। ");
  }
  if (!status.features[action]) {
    const labels: Record<keyof ControlRoomFeatureState, string> = {
      sms: "SMS/OTP সেবা",
      signup: "নতুন নিবন্ধন",
      payment: "পেমেন্ট সেবা",
      login: "লগইন সেবা",
    };
    throw new Error(`${labels[action]} সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে পরে আবার চেষ্টা করুন।`);
  }
}

export async function applyControlRoomPatch(patch: ControlRoomPatch) {
  await saveSiteContentSettings({
    remoteMaintenanceMode: patch.maintenanceMode ? 1 : 0,
    remoteMaintenanceMessage: patch.maintenanceMessage,
    remoteSmsEnabled: patch.features.sms ? 1 : 0,
    remoteSignupEnabled: patch.features.signup ? 1 : 0,
    remotePaymentEnabled: patch.features.payment ? 1 : 0,
    remoteLoginEnabled: patch.features.login ? 1 : 0,
    remoteControlUpdatedAt: new Date(),
    remoteControlUpdatedBy: "Google Apps Script Control Room",
    updatedBy: "Google Apps Script Control Room",
  });

  await insertSiteOperationalLog({
    level: "info",
    operation: "control_room_remote_update",
    message: `Control Room updated maintenance=${patch.maintenanceMode ? "on" : "off"}; payment=${patch.features.payment ? "on" : "off"}; login=${patch.features.login ? "on" : "off"}; signup=${patch.features.signup ? "on" : "off"}; sms=${patch.features.sms ? "on" : "off"}.`,
  });

  return getControlRoomStatus();
}
