import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const repairDirectory = path.resolve(
  process.cwd(),
  "../deliverables/SahajContact_ControlRoom_Final_Repair_20260822",
);

function readRepairFile(name: string) {
  const filePath = path.join(repairDirectory, name);
  expect(existsSync(filePath), `${name} must be present in the repair package`).toBe(true);
  return readFileSync(filePath, "utf8");
}

describe("Control Room final repair package", () => {
  it("ships the required HtmlService entry file and a non-blank setup fallback", () => {
    const backend = readRepairFile("Code.gs");
    const ui = readRepairFile("Index.html");

    expect(backend).toContain("HtmlService.createHtmlOutputFromFile('Index')");
    expect(backend).toContain("Control Room setup incomplete");
    expect(backend).toContain("No SahajContact setting has been changed.");
    expect(ui).toContain("SAHajContact Super Control");
    expect(ui).toContain("getSahajContactConnectionStatus");
    expect(ui).toContain('id="checkBridge"');
    expect(ui).toContain("Connection Check চলছে… ফল আসা পর্যন্ত অপেক্ষা করুন।");
    expect(ui).toContain("SahajContact সংযুক্ত আছে। কোনো পরিবর্তন পাঠানো হয়নি।");
    expect(ui).toContain("function readOnlyCheckResult(result)");
    expect(ui).not.toContain("Read-only Connection Check সম্পন্ন হয়েছে");
    expect(ui).toContain("state==='checking'");
    expect(ui).toContain("Queued পরিবর্তনটি SahajContact-এ পাঠাবেন?");
  });

  it("keeps the bridge status call signed and prevents unsafe queued retries", () => {
    const backend = readRepairFile("Code.gs");

    expect(backend).toContain("const canonical = timestamp + '.' + method + '.' + path + '.' + serializedBody;");
    expect(backend).toContain("Utilities.computeHmacSha256Signature(canonical, config.secret)");
    expect(backend).toContain("callBridge_(config, 'GET', '/api/control-room/v1/status', null)");
    expect(backend).toContain("function isSafeRetryState_(site)");
    expect(backend).toContain("site.maintenanceMode || site.maintenance_mode");
    expect(backend).toContain("site.status || site.site_status");
    expect(backend).toContain("unsafe_pending_blocked");
    expect(backend).toContain("Maintenance বন্ধ এবং সব feature চালু");
  });

  it("declares the least privilege needed for the signed outbound status request", () => {
    const manifest = JSON.parse(readRepairFile("appsscript.json")) as { runtimeVersion?: string; oauthScopes?: string[] };

    expect(manifest.runtimeVersion).toBe("V8");
    expect(manifest.oauthScopes).toContain("https://www.googleapis.com/auth/script.external_request");
    expect(manifest.oauthScopes).toContain("https://www.googleapis.com/auth/userinfo.email");
  });
});
