import { afterEach, describe, expect, it } from "vitest";
import { resolveControlRoomSharedSecret } from "./controlRoomRuntime";

describe("Control Room runtime credential resolver", () => {
  const originalSecret = process.env.CONTROL_ROOM_SHARED_SECRET;

  afterEach(() => {
    if (originalSecret === undefined) {
      delete process.env.CONTROL_ROOM_SHARED_SECRET;
      return;
    }
    process.env.CONTROL_ROOM_SHARED_SECRET = originalSecret;
  });

  it("prefers a non-empty runtime protected credential over a startup snapshot", () => {
    process.env.CONTROL_ROOM_SHARED_SECRET = "runtime-protected-value";
    expect(resolveControlRoomSharedSecret("startup-value")).toBe("runtime-protected-value");
  });

  it("falls back to the startup snapshot only when no runtime credential exists", () => {
    delete process.env.CONTROL_ROOM_SHARED_SECRET;
    expect(resolveControlRoomSharedSecret("startup-value")).toBe("startup-value");
  });
});
