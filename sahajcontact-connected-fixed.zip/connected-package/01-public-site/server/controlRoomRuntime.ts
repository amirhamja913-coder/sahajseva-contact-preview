/**
 * Resolves the bridge credential at request time so a running process never
 * continues using a module-snapshot after protected environment injection.
 * The credential itself is intentionally never logged, returned, or stored.
 */
export function resolveControlRoomSharedSecret(configuredSecret: string | undefined): string {
  const runtimeSecret = process.env.CONTROL_ROOM_SHARED_SECRET;
  if (typeof runtimeSecret === "string" && runtimeSecret.length > 0) {
    return runtimeSecret;
  }
  return configuredSecret ?? "";
}
