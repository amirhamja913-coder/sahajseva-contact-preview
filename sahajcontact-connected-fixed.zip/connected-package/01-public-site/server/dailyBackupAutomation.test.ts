import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const projectRoot = new URL("../", import.meta.url);
const readProjectFile = (relativePath: string) =>
  readFileSync(new URL(relativePath, projectRoot), "utf8");

describe("daily recovery backup automation", () => {
  it("uses the Manus cron identity rather than a public shared-secret callback", () => {
    const entrypoint = readProjectFile("server/_core/index.ts");
    expect(entrypoint).toContain('app.post("/api/scheduled/daily-site-backup", async (req, res) =>');
    expect(entrypoint).toContain("sdk.authenticateRequest(req)");
    expect(entrypoint).toContain("user.isCron || !user.taskUid");
    expect(entrypoint).toContain("getDailySiteBackupAutomationByTaskUid(user.taskUid)");
  });

  it("persists automation status and exposes owner-only reset status controls", () => {
    const database = readProjectFile("server/db.ts");
    const router = readProjectFile("server/routers.ts");
    const dashboard = readProjectFile("client/src/pages/AdminAnalyticsDashboard.tsx");

    expect(database).toContain("recordDailySiteBackupSuccess(taskUid: string)");
    expect(database).toContain("getDailySiteBackupAutomationSettings");
    expect(router).toContain("getScheduledBackupStatus: ownerOnlyProcedure.query");
    expect(dashboard).toContain("Reset to Last Backup");
    expect(dashboard).toContain("RESET_TO_LAST_BACKUP");
  });
});
