import { drizzle } from "drizzle-orm/mysql2";
import { and, asc, count, desc, eq, gte, inArray, isNull, lt, ne, or } from "drizzle-orm";
import {
  customerOrders,
  InsertCustomerOrder,
  servicePricing,
  InsertServicePricing,
  InsertPhoneOtpChallenge,
  InsertServiceReview,
  InsertSponsorInquiry,
  InsertNgoPartnershipApplication,
  InsertUser,
  phoneOtpChallenges,
  serviceReviews,
  sponsorInquiries,
  ngoPartnershipApplications,
  serviceApplications,
  InsertServiceApplication,
  galleryPhotos,
  InsertGalleryPhoto,
  users,
  adminAnalyticsReports,
  seoReportRefreshSettings,
  adminMediaFiles,
  adminMembers,
  adminMemberFeaturePermissions,
  institutionalVerificationRegisters,
  adminMediaFolders,
  siteContentSettings,
  siteBuilderStates,
  siteBuilderCountries,
  touristPlaces,
  borderPorts,
  transportIndiaGuides,
  embassies,
  educationHubCards,
  financialServiceCards,
  mediaHubSettings,
  mediaHubChannels,
  siteQuickLinks,
  siteNavigationItems,
  siteManagementChangeHistory,
  siteAnnouncements,
  siteBlogPosts,
  contactLeads,
  siteOperationalLogs,
  siteBackupSnapshots,
  siteBackupAutomationSettings,
  advertiserSlotPrices,
  advertiserOrders,
  adClickEvents,
  investorLeads,
  InsertAdminAnalyticsReport,
  InsertSeoReportRefreshSetting,
  InsertAdminMediaFile,
  InsertAdminMediaFolder,
  InsertSiteContentSettings,
  InsertSiteBuilderState,
  InsertSiteBuilderCountry,
  InsertTouristPlace,
  InsertBorderPort,
  InsertTransportIndiaGuide,
  InsertEmbassy,
  InsertEducationHubCard,
  InsertFinancialServiceCard,
  InsertMediaHubSetting,
  InsertMediaHubChannel,
  InsertSiteQuickLink,
  InsertSiteNavigationItem,
  InsertSiteManagementChangeHistory,
  AdminMember,
  InsertAdminMember,
  InsertAdminMemberFeaturePermission,
  InsertInstitutionalVerificationRegister,
  InsertSiteAnnouncement,
  InsertSiteBlogPost,
  InsertContactLead,
  InsertSiteOperationalLog,
  InsertSiteBackupSnapshot,
  InsertAdvertiserSlotPrice,
  InsertAdvertiserOrder,
  InsertInvestorLead,
  premiumPhotoProducts,
  premiumPhotoPurchases,
  InsertPremiumPhotoProduct,
  InsertPremiumPhotoPurchase,
  ownerPersonalPhotos,
  InsertOwnerPersonalPhoto,
  businessDirectorySubmissions,
  InsertBusinessDirectorySubmission,
  businessDirectoryClaimRequests,
  InsertBusinessDirectoryClaimRequest,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export type SiteLinkOwner = "government" | "media" | "bank" | "education" | "embassy" | "transport_india_guide" | "announcement" | "homepage";

export type SiteLinkCandidate = {
  url: string;
  owner: SiteLinkOwner;
  id?: number;
  field: string;
};

export type SiteLinkConflict = SiteLinkCandidate & {
  normalizedUrl: string;
};

/**
 * Canonicalize owner-managed service links so harmless formatting differences
 * (trailing slash, hash fragments, default ports, and query ordering) cannot
 * bypass the one-link/one-section rule.
 */
export function normalizeSiteLinkUrl(value: string) {
    const trimmed = value.trim();
    if (!trimmed) return "";
    if (trimmed.startsWith("/") && !trimmed.startsWith("//")) {
      const qIdx = trimmed.indexOf("?");
      if (qIdx === -1) {
        return trimmed.length > 1 ? trimmed.replace(/\/+$/, "") : trimmed;
      }
      const p = trimmed.slice(0, qIdx);
      const q = trimmed.slice(qIdx + 1);
      const np = p.length > 1 ? p.replace(/\/+$/, "") : p;
      return q ? `${np}?${q}` : np;
    }

  try {
    const parsed = new URL(trimmed);
    parsed.hash = "";
    if ((parsed.protocol === "https:" && parsed.port === "443") || (parsed.protocol === "http:" && parsed.port === "80")) {
      parsed.port = "";
    }
    parsed.hostname = parsed.hostname.toLowerCase();
    parsed.searchParams.sort();
    const pathname = parsed.pathname.length > 1 ? parsed.pathname.replace(/\/+$/, "") : parsed.pathname;
    parsed.pathname = pathname || "/";
    return parsed.toString().replace(/\/$/, parsed.pathname === "/" ? "/" : "");
  } catch {
    return trimmed.toLowerCase();
  }
}

/**
 * Return every existing owner-managed service destination in one registry.
 * Image, favicon, and document URLs are intentionally excluded because they
 * are media assets rather than public service destinations.
 */
export async function getSiteLinkRegistry(): Promise<SiteLinkConflict[]> {
  const db = await getDb();
  if (!db) return [];

  const [settings, quickLinks, announcements, embassyRows, educationRows, financialRows, mediaRows] = await Promise.all([
    db.select({ id: siteContentSettings.id, url: siteContentSettings.primaryCtaHref }).from(siteContentSettings),
    db.select({ id: siteQuickLinks.id, url: siteQuickLinks.url }).from(siteQuickLinks),
    db.select({ id: siteAnnouncements.id, url: siteAnnouncements.linkUrl }).from(siteAnnouncements),
    db.select({ id: embassies.id, websiteUrl: embassies.websiteUrl, whatsappUrl: embassies.whatsappUrl, sourceUrl: embassies.sourceUrl }).from(embassies),
    db.select({ id: educationHubCards.id, officialUrl: educationHubCards.officialUrl, whatsappUrl: educationHubCards.whatsappUrl }).from(educationHubCards),
    db.select({ id: financialServiceCards.id, officialUrl: financialServiceCards.officialUrl }).from(financialServiceCards),
    db.select({ id: mediaHubChannels.id, officialUrl: mediaHubChannels.officialUrl }).from(mediaHubChannels),
  ]);

  const entries: Array<SiteLinkCandidate> = [];
  for (const row of settings) if (row.url) entries.push({ owner: "homepage", id: row.id, field: "primaryCtaHref", url: row.url });
  for (const row of quickLinks) entries.push({ owner: "government", id: row.id, field: "url", url: row.url });
  for (const row of announcements) if (row.url) entries.push({ owner: "announcement", id: row.id, field: "linkUrl", url: row.url });
  for (const row of embassyRows) {
    entries.push({ owner: "embassy", id: row.id, field: "websiteUrl", url: row.websiteUrl });
    if (row.whatsappUrl) entries.push({ owner: "embassy", id: row.id, field: "whatsappUrl", url: row.whatsappUrl });
    entries.push({ owner: "embassy", id: row.id, field: "sourceUrl", url: row.sourceUrl });
  }
  for (const row of educationRows) {
    entries.push({ owner: "education", id: row.id, field: "officialUrl", url: row.officialUrl });
    if (row.whatsappUrl) entries.push({ owner: "education", id: row.id, field: "whatsappUrl", url: row.whatsappUrl });
  }
  for (const row of financialRows) entries.push({ owner: "bank", id: row.id, field: "officialUrl", url: row.officialUrl });
  for (const row of mediaRows) entries.push({ owner: "media", id: row.id, field: "officialUrl", url: row.officialUrl });

  return entries.map((entry) => ({ ...entry, normalizedUrl: normalizeSiteLinkUrl(entry.url) }));
}

export async function findSiteLinkConflict(candidate: SiteLinkCandidate, excludedRecord?: Pick<SiteLinkCandidate, "owner" | "id" | "field">) {
  const normalizedUrl = normalizeSiteLinkUrl(candidate.url);
  if (!normalizedUrl) return null;
  const registry = await getSiteLinkRegistry();
  const conflict = registry.find((entry) => entry.normalizedUrl === normalizedUrl && !(excludedRecord?.owner === entry.owner && excludedRecord.id === entry.id && excludedRecord.field === entry.field));
  return conflict ? { ...conflict, normalizedUrl } : null;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "phone", "address", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByPhone(phone: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrGetPhoneUser(phone: string) {
  const existing = await getUserByPhone(phone);
  if (existing) return existing;

  await upsertUser({
    openId: `phone:${phone}`,
    phone,
    loginMethod: "phone-otp",
    lastSignedIn: new Date(),
  });

  return getUserByPhone(phone);
}

export async function countOtpRequestsForDay(phone: string, dayKey: string) {
  const db = await getDb();
  if (!db) return 0;

  const rows = await db
    .select({ id: phoneOtpChallenges.id })
    .from(phoneOtpChallenges)
    .where(and(eq(phoneOtpChallenges.phone, phone), eq(phoneOtpChallenges.dayKey, dayKey)));

  return rows.length;
}

export async function insertOtpChallenge(challenge: InsertPhoneOtpChallenge) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(phoneOtpChallenges).values(challenge);
}

export async function getLatestActiveOtp(phone: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(phoneOtpChallenges)
    .where(and(eq(phoneOtpChallenges.phone, phone), isNull(phoneOtpChallenges.consumedAt)))
    .orderBy(desc(phoneOtpChallenges.createdAt))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function incrementOtpAttempts(id: number, attempts: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(phoneOtpChallenges)
    .set({ attempts })
    .where(eq(phoneOtpChallenges.id, id));
}

export async function consumeOtp(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(phoneOtpChallenges)
    .set({ consumedAt: new Date() })
    .where(eq(phoneOtpChallenges.id, id));
}

export async function updatePhoneUserProfile(
  userId: number,
  profile: { name: string | null; address: string | null }
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(users)
    .set({ name: profile.name, address: profile.address, updatedAt: new Date() })
    .where(eq(users.id, userId));
}

export async function getCustomerOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(customerOrders)
    .where(eq(customerOrders.userId, userId))
    .orderBy(desc(customerOrders.orderDate));
}

export async function insertCustomerOrder(order: InsertCustomerOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(customerOrders).values(order);
}

export async function getServicePricing(includeInactive = false) {
  const db = await getDb();
  if (!db) return [];

  const query = db.select().from(servicePricing);
  return includeInactive
    ? query.orderBy(servicePricing.serviceNameBn)
    : query.where(eq(servicePricing.isActive, 1)).orderBy(servicePricing.serviceNameBn);
}

export async function getServicePricingByKey(serviceKey: string) {
  const db = await getDb();
  if (!db) return null;

  const rows = await db
    .select()
    .from(servicePricing)
    .where(eq(servicePricing.serviceKey, serviceKey))
    .limit(1);
  return rows[0] ?? null;
}

export async function upsertServicePricing(price: InsertServicePricing) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const existing = await getServicePricingByKey(price.serviceKey);
  if (existing) {
    await db
      .update(servicePricing)
      .set({
        serviceNameBn: price.serviceNameBn,
        serviceNameEn: price.serviceNameEn,
        servicePrice: price.servicePrice,
        governmentFee: price.governmentFee,
        isActive: price.isActive,
      })
      .where(eq(servicePricing.id, existing.id));
    return existing.id;
  }

  const result = await db.insert(servicePricing).values(price);
  return Number(result[0].insertId);
}

export async function getAllCustomerOrders() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(customerOrders).orderBy(desc(customerOrders.orderDate));
}

export async function updateCustomerOrderPaymentStatus(
  orderId: number,
  paymentStatus: "pending" | "completed",
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.update(customerOrders).set({ paymentStatus }).where(eq(customerOrders.id, orderId));
}

export async function getPremiumPhotoProducts(includeUnpublished = false) {
  const db = await getDb();
  if (!db) return [];

  const query = db.select().from(premiumPhotoProducts);
  return includeUnpublished
    ? query.orderBy(desc(premiumPhotoProducts.createdAt))
    : query.where(eq(premiumPhotoProducts.isPublished, 1)).orderBy(desc(premiumPhotoProducts.createdAt));
}

export async function getPremiumPhotoProductById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const rows = await db.select().from(premiumPhotoProducts).where(eq(premiumPhotoProducts.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createPremiumPhotoProduct(product: InsertPremiumPhotoProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const result = await db.insert(premiumPhotoProducts).values(product);
  return Number(result[0].insertId);
}

export async function updatePremiumPhotoProduct(id: number, product: InsertPremiumPhotoProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(premiumPhotoProducts)
    .set({
      titleBn: product.titleBn,
      titleEn: product.titleEn,
      descriptionBn: product.descriptionBn ?? null,
      descriptionEn: product.descriptionEn ?? null,
      previewImageUrl: product.previewImageUrl,
      fullImageKey: product.fullImageKey,
      priceBdt: product.priceBdt,
      watermarkText: product.watermarkText,
      isPublished: product.isPublished,
    })
    .where(eq(premiumPhotoProducts.id, id));
}

export async function deletePremiumPhotoProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(premiumPhotoProducts).where(eq(premiumPhotoProducts.id, id));
}

export async function getOwnerPersonalPhotos(includeHidden = false, folder?: "gallery" | "map") {
  const db = await getDb();
  if (!db) return [];

  const orderBy = [asc(ownerPersonalPhotos.displayOrder), desc(ownerPersonalPhotos.createdAt)] as const;
  if (folder && includeHidden) return db.select().from(ownerPersonalPhotos).where(eq(ownerPersonalPhotos.folder, folder)).orderBy(...orderBy);
  if (folder) return db.select().from(ownerPersonalPhotos).where(and(eq(ownerPersonalPhotos.folder, folder), eq(ownerPersonalPhotos.isPublic, 1))).orderBy(...orderBy);
  if (includeHidden) return db.select().from(ownerPersonalPhotos).orderBy(...orderBy);
  return db.select().from(ownerPersonalPhotos).where(eq(ownerPersonalPhotos.isPublic, 1)).orderBy(...orderBy);
}

export async function getOwnerPersonalPhotoById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(ownerPersonalPhotos).where(eq(ownerPersonalPhotos.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createOwnerPersonalPhoto(photo: InsertOwnerPersonalPhoto) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(ownerPersonalPhotos).values(photo);
  return Number(result[0].insertId);
}

export async function updateOwnerPersonalPhoto(id: number, photo: InsertOwnerPersonalPhoto) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(ownerPersonalPhotos).set({
    folder: photo.folder,
    titleBn: photo.titleBn,
    titleEn: photo.titleEn,
    descriptionBn: photo.descriptionBn ?? null,
    descriptionEn: photo.descriptionEn ?? null,
    imageUrl: photo.imageUrl,
    storageKey: photo.storageKey,
    isPublic: photo.isPublic,
    displayOrder: photo.displayOrder,
  }).where(eq(ownerPersonalPhotos.id, id));
}

export async function reorderOwnerPersonalPhoto(id: number, displayOrder: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(ownerPersonalPhotos).set({ displayOrder }).where(eq(ownerPersonalPhotos.id, id));
}

export async function deleteOwnerPersonalPhoto(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(ownerPersonalPhotos).where(eq(ownerPersonalPhotos.id, id));
}

export async function createPremiumPhotoPurchase(purchase: InsertPremiumPhotoPurchase) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const result = await db.insert(premiumPhotoPurchases).values(purchase);
  return Number(result[0].insertId);
}

export async function getPremiumPhotoPurchaseByAccessToken(accessToken: string) {
  const db = await getDb();
  if (!db) return null;

  const purchases = await db
    .select()
    .from(premiumPhotoPurchases)
    .where(eq(premiumPhotoPurchases.accessToken, accessToken))
    .limit(1);
  return purchases[0] ?? null;
}

export async function markPremiumPhotoPurchaseDelivered(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(premiumPhotoPurchases).set({ deliveredAt: new Date() }).where(eq(premiumPhotoPurchases.id, id));
}

export async function getApprovedServiceReviews(serviceIds: string[]) {
  if (serviceIds.length === 0) return [];

  const db = await getDb();
  if (!db) return [];

  // Return approved OR pending reviews so submitted visitor feedback shows up immediately in the public folder as requested
  return db
    .select({
      id: serviceReviews.id,
      serviceId: serviceReviews.serviceId,
      serviceName: serviceReviews.serviceName,
      rating: serviceReviews.rating,
      comment: serviceReviews.comment,
      createdAt: serviceReviews.createdAt,
    })
    .from(serviceReviews)
    .where(and(inArray(serviceReviews.serviceId, serviceIds), or(eq(serviceReviews.status, "approved"), eq(serviceReviews.status, "pending"))))
    .orderBy(desc(serviceReviews.createdAt));
}

export async function insertServiceReview(review: InsertServiceReview) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(serviceReviews).values(review);
}

export async function insertSponsorInquiry(inquiry: InsertSponsorInquiry) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(sponsorInquiries).values(inquiry);
}

export async function getSponsorInquiries() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(sponsorInquiries)
    .orderBy(desc(sponsorInquiries.createdAt));
}

export async function insertNgoPartnershipApplication(application: InsertNgoPartnershipApplication) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(ngoPartnershipApplications).values(application);
}

export async function getNgoPartnershipApplications() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(ngoPartnershipApplications)
    .orderBy(desc(ngoPartnershipApplications.createdAt));
}

export async function updateNgoPartnershipApplicationReview(
  id: number,
  status: "pending" | "verified" | "declined" | "archived",
  ownerNote: string | null,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(ngoPartnershipApplications)
    .set({ status, ownerNote })
    .where(eq(ngoPartnershipApplications.id, id));
}

export async function createBusinessDirectorySubmission(submission: InsertBusinessDirectorySubmission) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(businessDirectorySubmissions).values(submission);
}

export async function getPublishedBusinessDirectoryListings() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({
      id: businessDirectorySubmissions.id,
      businessName: businessDirectorySubmissions.businessName,
      category: businessDirectorySubmissions.category,
      district: businessDirectorySubmissions.district,
      publicWebsiteUrl: businessDirectorySubmissions.publicWebsiteUrl,
      publicDescription: businessDirectorySubmissions.publicDescription,
      createdAt: businessDirectorySubmissions.createdAt,
    })
    .from(businessDirectorySubmissions)
    .where(eq(businessDirectorySubmissions.status, "published"))
    .orderBy(desc(businessDirectorySubmissions.createdAt));
}

export async function getBusinessDirectorySubmissions() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(businessDirectorySubmissions)
    .orderBy(desc(businessDirectorySubmissions.createdAt));
}

export async function updateBusinessDirectorySubmissionReview(
  id: number,
  status: "pending" | "published" | "declined" | "archived",
  ownerNote: string | null,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(businessDirectorySubmissions)
    .set({ status, ownerNote })
    .where(eq(businessDirectorySubmissions.id, id));
}

/**
 * Saves a private ownership/correction request only when the target is already
 * a real owner-published public listing. It never changes the listing itself.
 */
export async function createBusinessDirectoryClaimRequestForPublishedListing(
  request: InsertBusinessDirectoryClaimRequest,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const listing = await db
    .select({ id: businessDirectorySubmissions.id })
    .from(businessDirectorySubmissions)
    .where(
      and(
        eq(businessDirectorySubmissions.id, request.listingId),
        eq(businessDirectorySubmissions.status, "published"),
      ),
    )
    .limit(1);

  if (!listing[0]) return false;
  await db.insert(businessDirectoryClaimRequests).values(request);
  return true;
}

/** Private claim/contact data for the established owner-only workspace. */
export async function getBusinessDirectoryClaimRequests() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({
      id: businessDirectoryClaimRequests.id,
      listingId: businessDirectoryClaimRequests.listingId,
      listingName: businessDirectorySubmissions.businessName,
      listingCategory: businessDirectorySubmissions.category,
      listingDistrict: businessDirectorySubmissions.district,
      claimantName: businessDirectoryClaimRequests.claimantName,
      relationship: businessDirectoryClaimRequests.relationship,
      contactEmail: businessDirectoryClaimRequests.contactEmail,
      contactPhone: businessDirectoryClaimRequests.contactPhone,
      requestExplanation: businessDirectoryClaimRequests.requestExplanation,
      consentAccepted: businessDirectoryClaimRequests.consentAccepted,
      status: businessDirectoryClaimRequests.status,
      ownerNote: businessDirectoryClaimRequests.ownerNote,
      createdAt: businessDirectoryClaimRequests.createdAt,
      updatedAt: businessDirectoryClaimRequests.updatedAt,
    })
    .from(businessDirectoryClaimRequests)
    .innerJoin(
      businessDirectorySubmissions,
      eq(businessDirectoryClaimRequests.listingId, businessDirectorySubmissions.id),
    )
    .orderBy(desc(businessDirectoryClaimRequests.createdAt));
}

export async function updateBusinessDirectoryClaimRequestReview(
  id: number,
  status: "pending" | "reviewed" | "declined" | "archived",
  ownerNote: string | null,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db
    .update(businessDirectoryClaimRequests)
    .set({ status, ownerNote })
    .where(eq(businessDirectoryClaimRequests.id, id));
}

export async function insertServiceApplication(app: InsertServiceApplication) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(serviceApplications).values(app);
}

export async function getServiceApplications() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(serviceApplications)
    .orderBy(desc(serviceApplications.createdAt));
}

export async function createGalleryPhoto(photo: InsertGalleryPhoto) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(galleryPhotos).values(photo);
}

export async function getGalleryPhotos() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(galleryPhotos)
    .orderBy(desc(galleryPhotos.createdAt));
}



export async function getLatestAnalyticsReport() {
  const db = await getDb();
  if (!db) return null;
  // An owner-approved manual live GA4 refresh is deliberately separate from
  // generic stored-report consumers (exports, investor overview, and legacy
  // dashboard cards). Those consumers otherwise mislabel it as a scheduler
  // snapshot or a generic automatic update.
  const list = await db
    .select()
    .from(adminAnalyticsReports)
    .where(or(isNull(adminAnalyticsReports.snapshotSource), ne(adminAnalyticsReports.snapshotSource, "ga4_owner_manual_refresh")))
    .orderBy(desc(adminAnalyticsReports.createdAt))
    .limit(1);
  return list[0] ?? null;
}

export async function saveAnalyticsReport(report: InsertAdminAnalyticsReport) {
  const db = await getDb();
  if (!db) return;
  await db.insert(adminAnalyticsReports).values(report);
}

export const GA4_OWNER_MANUAL_REPORT_SOURCE = "ga4_owner_manual_refresh" as const;

/** Stores a verified owner-requested live GA4 report without touching automatic day keys or scheduler health. */
export async function saveOwnerApprovedManualGa4Report(report: InsertAdminAnalyticsReport) {
  if (report.snapshotSource !== GA4_OWNER_MANUAL_REPORT_SOURCE || report.snapshotDayKey) {
    throw new Error("Manual GA4 report provenance is invalid.");
  }
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(adminAnalyticsReports).values(report);
}

export async function getLatestOwnerApprovedManualGa4Report() {
  const db = await getDb();
  if (!db) return null;
  const list = await db
    .select()
    .from(adminAnalyticsReports)
    .where(eq(adminAnalyticsReports.snapshotSource, GA4_OWNER_MANUAL_REPORT_SOURCE))
    .orderBy(desc(adminAnalyticsReports.createdAt))
    .limit(1);
  return list[0] ?? null;
}

export async function getLatestAutomaticSeoAnalyticsReport() {
  const db = await getDb();
  if (!db) return null;
  const list = await db
    .select()
    .from(adminAnalyticsReports)
    .where(eq(adminAnalyticsReports.snapshotSource, "ga4_daily_automation"))
    .orderBy(desc(adminAnalyticsReports.snapshotDayKey))
    .limit(1);
  return list[0] ?? null;
}

/** Upserts one non-estimated GA4 snapshot per Bangladesh calendar day, making retry delivery safe. */
export async function upsertAutomaticSeoAnalyticsReport(report: InsertAdminAnalyticsReport & { snapshotDayKey: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ id: adminAnalyticsReports.id })
    .from(adminAnalyticsReports)
    .where(eq(adminAnalyticsReports.snapshotDayKey, report.snapshotDayKey))
    .limit(1);

  if (existing[0]) {
    await db.update(adminAnalyticsReports).set(report).where(eq(adminAnalyticsReports.id, existing[0].id));
    return { created: false } as const;
  }
  await db.insert(adminAnalyticsReports).values(report);
  return { created: true } as const;
}

/** Project-level singleton configuration for the daily GA4/SEO snapshot callback. */
export async function getSeoReportRefreshSettings() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(seoReportRefreshSettings).orderBy(desc(seoReportRefreshSettings.updatedAt)).limit(1);
  return rows[0] ?? null;
}

export async function setSeoReportRefreshTask(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getSeoReportRefreshSettings();
  if (current) {
    await db.update(seoReportRefreshSettings).set({ scheduleCronTaskUid: taskUid, enabled: 1, lastError: null }).where(eq(seoReportRefreshSettings.id, current.id));
    return;
  }
  await db.insert(seoReportRefreshSettings).values({ scheduleCronTaskUid: taskUid, enabled: 1 } satisfies InsertSeoReportRefreshSetting);
}

export async function getSeoReportRefreshSettingsByTaskUid(taskUid: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(seoReportRefreshSettings).where(eq(seoReportRefreshSettings.scheduleCronTaskUid, taskUid)).limit(1);
  return rows[0] ?? null;
}

export async function recordSeoReportRefreshSuccess(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db.update(seoReportRefreshSettings).set({ lastAttemptedAt: now, lastSuccessfulRunAt: now, lastSnapshotAt: now, lastError: null }).where(eq(seoReportRefreshSettings.scheduleCronTaskUid, taskUid));
}

export async function recordSeoReportRefreshFailure(taskUid: string, diagnostic: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(seoReportRefreshSettings).set({ lastAttemptedAt: new Date(), lastError: diagnostic.slice(0, 280) }).where(eq(seoReportRefreshSettings.scheduleCronTaskUid, taskUid));
}

export async function getAdminMediaFiles() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(adminMediaFiles).orderBy(desc(adminMediaFiles.createdAt));
}

export async function insertAdminMediaFile(file: InsertAdminMediaFile) {
  const db = await getDb();
  if (!db) return;
  await db.insert(adminMediaFiles).values(file);
}

export async function deleteAdminMediaFile(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(adminMediaFiles).where(eq(adminMediaFiles.id, id));
}

export async function updateAdminMediaFile(
  id: number,
  file: Partial<Pick<InsertAdminMediaFile, "fileUrl" | "fileName" | "fileSize" | "fileType" | "folderName">>,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(adminMediaFiles).set(file).where(eq(adminMediaFiles.id, id));
}

export async function getAdminMembers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(adminMembers).orderBy(desc(adminMembers.createdAt));
}

export async function insertAdminMember(member: InsertAdminMember) {
  const db = await getDb();
  if (!db) return;
  await db.insert(adminMembers).values(member);
}

export async function removeAdminMember(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(adminMembers).where(eq(adminMembers.id, id));
}

export async function updateAdminMemberRole(id: number, role: "Viewer" | "Editor" | "Admin") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(adminMembers).set({ role }).where(eq(adminMembers.id, id));
}

export async function getActiveAdminMemberRoleByEmail(email: string | null | undefined) {
  if (!email) return null;
  const db = await getDb();
  if (!db) return null;

  const rows = await db
    .select({ role: adminMembers.role })
    .from(adminMembers)
    .where(and(eq(adminMembers.email, email), eq(adminMembers.status, "Active")))
    .limit(1);
  return rows[0]?.role ?? null;
}

export async function getAdminMemberFeaturePermissions(memberId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(adminMemberFeaturePermissions)
    .where(eq(adminMemberFeaturePermissions.memberId, memberId));
}

export async function getAdminMemberFeaturePermissionsByEmail(email: string | null | undefined) {
  if (!email) return [];
  const db = await getDb();
  if (!db) return [];
  const members = await db
    .select({ id: adminMembers.id })
    .from(adminMembers)
    .where(and(eq(adminMembers.email, email), eq(adminMembers.status, "Active")))
    .limit(1);
  const memberId = members[0]?.id;
  if (!memberId) return [];
  return getAdminMemberFeaturePermissions(memberId);
}

export async function upsertAdminMemberFeaturePermission(permission: InsertAdminMemberFeaturePermission) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .insert(adminMemberFeaturePermissions)
    .values(permission)
    .onDuplicateKeyUpdate({ set: { enabled: permission.enabled } });
}

export async function getSiteBuilderState() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(siteBuilderStates).orderBy(desc(siteBuilderStates.updatedAt)).limit(1);
  return rows[0] ?? null;
}

export type SiteBuilderDraftFields = {
  heroTitleBn: string;
  heroTitleEn: string;
  heroSubtitleBn: string;
  heroSubtitleEn: string;
  whatsappNumber: string;
};

export async function saveSiteBuilderDraft(
  draftJson: string,
  updatedBy = "Primary Owner",
  fields?: SiteBuilderDraftFields,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getSiteBuilderState();
  const state = {
    draftJson,
    updatedBy,
    heroTitleBn: fields?.heroTitleBn,
    heroTitleEn: fields?.heroTitleEn,
    heroSubtitleBn: fields?.heroSubtitleBn,
    heroSubtitleEn: fields?.heroSubtitleEn,
    whatsappNumber: fields?.whatsappNumber,
  };
  if (current) {
    await db.update(siteBuilderStates).set(state).where(eq(siteBuilderStates.id, current.id));
    return;
  }
  await db.insert(siteBuilderStates).values({ ...state, publishedJson: null });
}

export async function publishSiteBuilderDraft(publishedJson: string, updatedBy = "Primary Owner") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getSiteBuilderState();
  if (current) {
    await db.update(siteBuilderStates).set({ publishedJson, updatedBy, publishedAt: new Date() }).where(eq(siteBuilderStates.id, current.id));
    return;
  }
  await db.insert(siteBuilderStates).values({ draftJson: publishedJson, publishedJson, updatedBy, publishedAt: new Date() });
}

export async function getSiteBuilderCountries() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteBuilderCountries).orderBy(siteBuilderCountries.displayOrder, siteBuilderCountries.code);
}

export async function replaceSiteBuilderCountries(
  countries: Array<Omit<InsertSiteBuilderCountry, "id" | "createdAt" | "updatedAt">>,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(siteBuilderCountries);
  if (countries.length > 0) {
    await db.insert(siteBuilderCountries).values(countries);
  }
}

export async function getTouristPlaces(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(touristPlaces).orderBy(touristPlaces.displayOrder, touristPlaces.id);
  return includeHidden ? query : query.where(eq(touristPlaces.visible, 1));
}

export async function createTouristPlace(place: InsertTouristPlace) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(touristPlaces).values(place);
}

export async function updateTouristPlace(id: number, place: Partial<Omit<InsertTouristPlace, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(touristPlaces).set(place).where(eq(touristPlaces.id, id));
}

export async function deleteTouristPlace(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(touristPlaces).where(eq(touristPlaces.id, id));
}

export async function getBorderPorts(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(borderPorts).orderBy(borderPorts.displayOrder, borderPorts.id);
  return includeHidden ? query : query.where(eq(borderPorts.visible, 1));
}

export async function createBorderPort(port: InsertBorderPort) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(borderPorts).values(port);
}

export async function updateBorderPort(id: number, port: Partial<Omit<InsertBorderPort, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(borderPorts).set(port).where(eq(borderPorts.id, id));
}

export async function deleteBorderPort(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(borderPorts).where(eq(borderPorts.id, id));
}

export async function getTransportIndiaGuides(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(transportIndiaGuides).orderBy(transportIndiaGuides.displayOrder, transportIndiaGuides.id);
  return includeHidden ? query : query.where(eq(transportIndiaGuides.visible, 1));
}

export async function createTransportIndiaGuide(guide: InsertTransportIndiaGuide) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(transportIndiaGuides).values(guide);
}

export async function updateTransportIndiaGuide(
  id: number,
  guide: Partial<Omit<InsertTransportIndiaGuide, "id" | "createdAt" | "updatedAt">>,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(transportIndiaGuides).set(guide).where(eq(transportIndiaGuides.id, id));
}

export async function deleteTransportIndiaGuide(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(transportIndiaGuides).where(eq(transportIndiaGuides.id, id));
}

export async function getEmbassies(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(embassies).orderBy(embassies.displayOrder, embassies.id);
  return includeHidden ? query : query.where(eq(embassies.visible, 1));
}

export async function createEmbassy(embassy: InsertEmbassy) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(embassies).values(embassy);
}

export async function updateEmbassy(id: number, embassy: Partial<Omit<InsertEmbassy, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(embassies).set(embassy).where(eq(embassies.id, id));
}

export async function deleteEmbassy(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(embassies).where(eq(embassies.id, id));
}

export async function getEducationHubCards(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(educationHubCards).orderBy(educationHubCards.displayOrder, educationHubCards.id);
  return includeHidden ? query : query.where(eq(educationHubCards.visible, 1));
}

export async function createEducationHubCard(card: InsertEducationHubCard) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(educationHubCards).values(card);
}

export async function updateEducationHubCard(id: number, card: Partial<Omit<InsertEducationHubCard, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(educationHubCards).set(card).where(eq(educationHubCards.id, id));
}

export async function deleteEducationHubCard(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(educationHubCards).where(eq(educationHubCards.id, id));
}

export async function getFinancialServiceCards(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(financialServiceCards).orderBy(financialServiceCards.displayOrder, financialServiceCards.id);
  return includeHidden ? query : query.where(eq(financialServiceCards.visible, 1));
}

export async function createFinancialServiceCard(card: InsertFinancialServiceCard) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(financialServiceCards).values(card);
}

export async function updateFinancialServiceCard(id: number, card: Partial<Omit<InsertFinancialServiceCard, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(financialServiceCards).set(card).where(eq(financialServiceCards.id, id));
}

export async function deleteFinancialServiceCard(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(financialServiceCards).where(eq(financialServiceCards.id, id));
}

export async function getMediaHubSettings(includeHidden = false) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(mediaHubSettings).orderBy(desc(mediaHubSettings.updatedAt)).limit(1);
  const setting = rows[0] ?? null;
  return includeHidden || setting?.visible === 1 ? setting : null;
}

export async function saveMediaHubSettings(settings: Omit<InsertMediaHubSetting, "id" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getMediaHubSettings(true);
  if (current) {
    await db.update(mediaHubSettings).set(settings).where(eq(mediaHubSettings.id, current.id));
    return;
  }
  await db.insert(mediaHubSettings).values(settings);
}

export async function getMediaHubChannels(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(mediaHubChannels).orderBy(mediaHubChannels.displayOrder, mediaHubChannels.id);
  return includeHidden ? query : query.where(eq(mediaHubChannels.visible, 1));
}

export async function createMediaHubChannel(channel: InsertMediaHubChannel) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(mediaHubChannels).values(channel);
}

export async function updateMediaHubChannel(id: number, channel: Partial<Omit<InsertMediaHubChannel, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(mediaHubChannels).set(channel).where(eq(mediaHubChannels.id, id));
}

export async function deleteMediaHubChannel(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(mediaHubChannels).where(eq(mediaHubChannels.id, id));
}

export async function getSiteContentSettings() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(siteContentSettings).orderBy(desc(siteContentSettings.updatedAt)).limit(1);
  return rows[0] ?? null;
}

export async function saveSiteContentSettings(settings: Omit<InsertSiteContentSettings, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getSiteContentSettings();
  if (current) {
    await db.update(siteContentSettings).set(settings).where(eq(siteContentSettings.id, current.id));
    return;
  }
  await db.insert(siteContentSettings).values(settings);
}

/**
 * This owner-only acknowledgement intentionally contains no document file,
 * licence number, address, signature, or other personal registration data.
 */
export async function getInstitutionalVerificationRegister() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(institutionalVerificationRegisters)
    .orderBy(desc(institutionalVerificationRegisters.updatedAt))
    .limit(1);
  return rows[0] ?? null;
}

export async function saveInstitutionalVerificationRegister(
  settings: Omit<InsertInstitutionalVerificationRegister, "id" | "createdAt" | "updatedAt">,
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getInstitutionalVerificationRegister();
  if (current) {
    await db.update(institutionalVerificationRegisters).set(settings).where(eq(institutionalVerificationRegisters.id, current.id));
    return;
  }
  await db.insert(institutionalVerificationRegisters).values(settings);
}

export async function getSiteQuickLinks(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(siteQuickLinks);
  const rows = includeHidden
    ? await query.orderBy(siteQuickLinks.displayOrder, desc(siteQuickLinks.updatedAt))
    : await query.where(eq(siteQuickLinks.visible, 1)).orderBy(siteQuickLinks.displayOrder, desc(siteQuickLinks.updatedAt));
  return rows;
}

export async function createSiteQuickLink(link: InsertSiteQuickLink) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteQuickLinks).values(link);
}

export async function updateSiteQuickLink(id: number, link: Partial<Pick<InsertSiteQuickLink, "titleBn" | "titleEn" | "url" | "descriptionBn" | "descriptionEn" | "iconName" | "iconImageUrl" | "openInNewTab" | "visible" | "displayOrder">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(siteQuickLinks).set(link).where(eq(siteQuickLinks.id, id));
}

export async function deleteSiteQuickLink(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(siteQuickLinks).where(eq(siteQuickLinks.id, id));
}

export async function getSiteNavigationItems(includeHidden = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(siteNavigationItems);
  return includeHidden
    ? query.orderBy(siteNavigationItems.displayOrder, desc(siteNavigationItems.updatedAt))
    : query.where(eq(siteNavigationItems.visible, 1)).orderBy(siteNavigationItems.displayOrder, desc(siteNavigationItems.updatedAt));
}

export async function createSiteNavigationItem(item: InsertSiteNavigationItem) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteNavigationItems).values(item);
}

export async function updateSiteNavigationItem(id: number, item: Partial<Pick<InsertSiteNavigationItem, "titleBn" | "titleEn" | "url" | "visible" | "displayOrder">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(siteNavigationItems).set(item).where(eq(siteNavigationItems.id, id));
}

export async function deleteSiteNavigationItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(siteNavigationItems).where(eq(siteNavigationItems.id, id));
}

export async function getAdminMediaFolders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(adminMediaFolders).orderBy(adminMediaFolders.name);
}

export async function createAdminMediaFolder(folder: InsertAdminMediaFolder) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(adminMediaFolders).values(folder);
}

export async function insertSiteManagementChange(entry: InsertSiteManagementChangeHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteManagementChangeHistory).values(entry);
}

export async function getRecentSiteManagementChanges(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteManagementChangeHistory).orderBy(desc(siteManagementChangeHistory.createdAt)).limit(limit);
}

export async function getSiteAnnouncement() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(siteAnnouncements).orderBy(desc(siteAnnouncements.updatedAt)).limit(1);
  return rows[0] ?? null;
}

export async function saveSiteAnnouncement(announcement: InsertSiteAnnouncement) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const current = await getSiteAnnouncement();
  if (current) {
    await db.update(siteAnnouncements).set(announcement).where(eq(siteAnnouncements.id, current.id));
    return;
  }
  await db.insert(siteAnnouncements).values(announcement);
}

export async function getSiteBlogPosts(includeUnpublished = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(siteBlogPosts);
  return includeUnpublished
    ? query.orderBy(desc(siteBlogPosts.isPinned), desc(siteBlogPosts.updatedAt))
    : query.where(eq(siteBlogPosts.status, "published")).orderBy(desc(siteBlogPosts.isPinned), desc(siteBlogPosts.publishedAt), desc(siteBlogPosts.updatedAt));
}

export async function createSiteBlogPost(post: InsertSiteBlogPost) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteBlogPosts).values(post);
}

export async function updateSiteBlogPost(id: number, post: Partial<Omit<InsertSiteBlogPost, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(siteBlogPosts).set(post).where(eq(siteBlogPosts.id, id));
}

export async function deleteSiteBlogPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(siteBlogPosts).where(eq(siteBlogPosts.id, id));
}

export async function getContactLeads(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contactLeads).orderBy(desc(contactLeads.createdAt)).limit(limit);
}

export async function insertContactLead(lead: InsertContactLead) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(contactLeads).values(lead);
}

export async function updateContactLeadStatus(id: number, status: "new" | "reviewed" | "closed") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(contactLeads).set({ status }).where(eq(contactLeads.id, id));
}

export async function deleteContactLead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(contactLeads).where(eq(contactLeads.id, id));
}

export async function getSiteOperationalLogs(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteOperationalLogs).orderBy(desc(siteOperationalLogs.createdAt)).limit(limit);
}

export async function insertSiteOperationalLog(entry: InsertSiteOperationalLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(siteOperationalLogs).values(entry);
}

export async function getPublicSiteBackupSnapshot() {
  const [settings, quickLinks, announcement, blogPosts, mediaFiles, folders, touristPlaces, borderPorts, transportIndiaGuides, embassies, educationHubCards, financialServiceCards, mediaHubSettings, mediaHubChannels] = await Promise.all([
    getSiteContentSettings(),
    getSiteQuickLinks(true),
    getSiteAnnouncement(),
    getSiteBlogPosts(true),
    getAdminMediaFiles(),
    getAdminMediaFolders(),
    getTouristPlaces(true),
    getBorderPorts(true),
    getTransportIndiaGuides(true),
    getEmbassies(true),
    getEducationHubCards(true),
    getFinancialServiceCards(true),
    getMediaHubSettings(true),
    getMediaHubChannels(true),
  ]);
  return { version: 3 as const, settings, quickLinks, announcement, blogPosts, mediaFiles, folders, touristPlaces, borderPorts, transportIndiaGuides, embassies, educationHubCards, financialServiceCards, mediaHubSettings, mediaHubChannels };
}

export async function createScheduledSiteBackupSnapshot(dayKey: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const existing = await db
    .select()
    .from(siteBackupSnapshots)
    .where(eq(siteBackupSnapshots.dayKey, dayKey))
    .limit(1);
  if (existing[0]) return { created: false, snapshot: existing[0] } as const;

  const snapshot = await getPublicSiteBackupSnapshot();
  const values: InsertSiteBackupSnapshot = {
    kind: "scheduled",
    dayKey,
    snapshotJson: JSON.stringify(snapshot),
  };

  try {
    await db.insert(siteBackupSnapshots).values(values);
  } catch (error) {
    // A duplicate day key means a concurrent scheduled execution already created it.
    const concurrent = await db
      .select()
      .from(siteBackupSnapshots)
      .where(eq(siteBackupSnapshots.dayKey, dayKey))
      .limit(1);
    if (concurrent[0]) return { created: false, snapshot: concurrent[0] } as const;
    throw error;
  }

  const created = await db
    .select()
    .from(siteBackupSnapshots)
    .where(eq(siteBackupSnapshots.dayKey, dayKey))
    .limit(1);
  return { created: true, snapshot: created[0] } as const;
}

/**
 * The daily recovery scheduler is a project-level singleton. Its task UID comes
 * only from the platform scheduler and is retained so callbacks can be matched
 * to this project configuration without trusting request payloads.
 */
export async function getDailySiteBackupAutomationSettings() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(siteBackupAutomationSettings)
    .orderBy(desc(siteBackupAutomationSettings.updatedAt))
    .limit(1);
  return rows[0] ?? null;
}

export async function setDailySiteBackupAutomationTask(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const current = await getDailySiteBackupAutomationSettings();
  if (current) {
    await db
      .update(siteBackupAutomationSettings)
      .set({ scheduleCronTaskUid: taskUid, enabled: 1 })
      .where(eq(siteBackupAutomationSettings.id, current.id));
    return;
  }

  await db.insert(siteBackupAutomationSettings).values({
    scheduleCronTaskUid: taskUid,
    enabled: 1,
  });
}

export async function getDailySiteBackupAutomationByTaskUid(taskUid: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(siteBackupAutomationSettings)
    .where(eq(siteBackupAutomationSettings.scheduleCronTaskUid, taskUid))
    .limit(1);
  return rows[0] ?? null;
}

export async function recordDailySiteBackupSuccess(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .update(siteBackupAutomationSettings)
    .set({ lastSuccessfulRunAt: new Date() })
    .where(eq(siteBackupAutomationSettings.scheduleCronTaskUid, taskUid));
}

export async function getLatestScheduledSiteBackupSnapshot() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(siteBackupSnapshots)
    .where(eq(siteBackupSnapshots.kind, "scheduled"))
    .orderBy(desc(siteBackupSnapshots.createdAt))
    .limit(1);
  const record = rows[0];
  if (!record) return null;
  try {
    return { ...record, snapshot: JSON.parse(record.snapshotJson) as unknown };
  } catch {
    return null;
  }
}

export async function restorePublicSiteBackupSnapshot(snapshot: {
  settings: Omit<InsertSiteContentSettings, "id" | "createdAt" | "updatedAt"> | null;
  quickLinks: InsertSiteQuickLink[];
  announcement: Omit<InsertSiteAnnouncement, "id" | "createdAt" | "updatedAt"> | null;
  blogPosts: Omit<InsertSiteBlogPost, "id" | "createdAt" | "updatedAt">[];
  folders: Omit<InsertAdminMediaFolder, "id" | "createdAt" | "updatedAt">[];
  touristPlaces?: Omit<InsertTouristPlace, "id" | "createdAt" | "updatedAt">[];
  borderPorts?: Omit<InsertBorderPort, "id" | "createdAt" | "updatedAt">[];
  transportIndiaGuides?: Omit<InsertTransportIndiaGuide, "id" | "createdAt" | "updatedAt">[];
  embassies?: Omit<InsertEmbassy, "id" | "createdAt" | "updatedAt">[];
  educationHubCards?: Omit<InsertEducationHubCard, "id" | "createdAt" | "updatedAt">[];
  financialServiceCards?: Omit<InsertFinancialServiceCard, "id" | "createdAt" | "updatedAt">[];
  mediaHubSettings?: Omit<InsertMediaHubSetting, "id" | "createdAt" | "updatedAt">;
  mediaHubChannels?: Omit<InsertMediaHubChannel, "id" | "createdAt" | "updatedAt">[];
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.transaction(async tx => {
    if (snapshot.settings) {
      const current = await tx.select({ id: siteContentSettings.id }).from(siteContentSettings).orderBy(desc(siteContentSettings.updatedAt)).limit(1);
      if (current[0]) {
        await tx.update(siteContentSettings).set(snapshot.settings).where(eq(siteContentSettings.id, current[0].id));
      } else {
        await tx.insert(siteContentSettings).values(snapshot.settings);
      }
    }

    await tx.delete(siteQuickLinks);
    if (snapshot.quickLinks.length) await tx.insert(siteQuickLinks).values(snapshot.quickLinks);
    await tx.delete(siteAnnouncements);
    if (snapshot.announcement) await tx.insert(siteAnnouncements).values(snapshot.announcement);
    await tx.delete(siteBlogPosts);
    if (snapshot.blogPosts.length) await tx.insert(siteBlogPosts).values(snapshot.blogPosts);
    if (snapshot.touristPlaces) {
      await tx.delete(touristPlaces);
      if (snapshot.touristPlaces.length) await tx.insert(touristPlaces).values(snapshot.touristPlaces);
    }
    if (snapshot.borderPorts) {
      await tx.delete(borderPorts);
      if (snapshot.borderPorts.length) await tx.insert(borderPorts).values(snapshot.borderPorts);
    }
    if (snapshot.transportIndiaGuides) {
      await tx.delete(transportIndiaGuides);
      if (snapshot.transportIndiaGuides.length) await tx.insert(transportIndiaGuides).values(snapshot.transportIndiaGuides);
    }
    if (snapshot.embassies) {
      await tx.delete(embassies);
      if (snapshot.embassies.length) await tx.insert(embassies).values(snapshot.embassies);
    }
    if (snapshot.educationHubCards) {
      await tx.delete(educationHubCards);
      if (snapshot.educationHubCards.length) await tx.insert(educationHubCards).values(snapshot.educationHubCards);
    }
    if (snapshot.financialServiceCards) {
      await tx.delete(financialServiceCards);
      if (snapshot.financialServiceCards.length) await tx.insert(financialServiceCards).values(snapshot.financialServiceCards);
    }
    if (snapshot.mediaHubSettings) {
      const currentMediaSettings = await tx.select({ id: mediaHubSettings.id }).from(mediaHubSettings).limit(1);
      if (currentMediaSettings[0]) {
        await tx.update(mediaHubSettings).set(snapshot.mediaHubSettings).where(eq(mediaHubSettings.id, currentMediaSettings[0].id));
      } else {
        await tx.insert(mediaHubSettings).values(snapshot.mediaHubSettings);
      }
    }
    if (snapshot.mediaHubChannels) {
      await tx.delete(mediaHubChannels);
      if (snapshot.mediaHubChannels.length) await tx.insert(mediaHubChannels).values(snapshot.mediaHubChannels);
    }
    await tx.delete(adminMediaFolders);
    if (snapshot.folders.length) await tx.insert(adminMediaFolders).values(snapshot.folders);
  });
}

export async function getAdvertiserSlotPrices() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(advertiserSlotPrices).orderBy(advertiserSlotPrices.slot);
}

export async function upsertAdvertiserSlotPrice(values: InsertAdvertiserSlotPrice) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(advertiserSlotPrices).values(values).onDuplicateKeyUpdate({
    set: { priceBdt: values.priceBdt, active: values.active },
  });
}

export async function createAdvertiserOrder(values: InsertAdvertiserOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(advertiserOrders).values(values);
}

export async function getAdvertiserOrders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(advertiserOrders).orderBy(desc(advertiserOrders.createdAt));
}

export async function getAdvertiserOrderByAccessToken(accessToken: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(advertiserOrders).where(eq(advertiserOrders.accessToken, accessToken)).limit(1);
  return rows[0] ?? null;
}

export async function getAdvertiserOrderById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(advertiserOrders).where(eq(advertiserOrders.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function updateAdvertiserOrder(id: number, values: Partial<InsertAdvertiserOrder>) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.update(advertiserOrders).set(values).where(eq(advertiserOrders.id, id));
}

export async function getLiveAdvertiserOrders(slot?: "header" | "sidebar" | "blog") {
  const db = await getDb();
  if (!db) return [];
  const predicate = slot
    ? and(eq(advertiserOrders.status, "live"), eq(advertiserOrders.slot, slot))
    : eq(advertiserOrders.status, "live");
  return db.select().from(advertiserOrders).where(predicate).orderBy(desc(advertiserOrders.updatedAt));
}

export async function recordAdvertiserClick(orderId: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(adClickEvents).values({ orderId });
}

export async function getAdvertiserClickCount(orderId: number) {
  const db = await getDb();
  if (!db) return 0;
  const rows = await db.select({ total: count() }).from(adClickEvents).where(eq(adClickEvents.orderId, orderId));
  return Number(rows[0]?.total ?? 0);
}

export async function createInvestorLead(values: InsertInvestorLead) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(investorLeads).values(values);
}

export async function getInvestorLeads() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(investorLeads).orderBy(desc(investorLeads.createdAt));
}

export async function updateInvestorLeadStatus(id: number, status: "new" | "reviewed" | "closed") {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.update(investorLeads).set({ status }).where(eq(investorLeads.id, id));
}
