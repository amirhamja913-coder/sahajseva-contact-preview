import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const schemaSource = readFileSync(new URL("../drizzle/schema.ts", import.meta.url), "utf8");
const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const homeSource = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const educationSource = readFileSync(new URL("../client/src/components/EducationHubSection.tsx", import.meta.url), "utf8");
const utilitySource = readFileSync(new URL("../client/src/components/UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");
const builderSource = readFileSync(new URL("../client/src/pages/SiteBuilder.tsx", import.meta.url), "utf8");

describe("single education hub release contracts", () => {
  it("persists the five-card bilingual education model in MySQL", () => {
    for (const field of ["educationHubCards", "slug", "titleBn", "titleEn", "descriptionBn", "descriptionEn", "iconName", "officialUrl", "whatsappUrl", "displayOrder", "visible"]) {
      expect(schemaSource).toContain(field);
    }
    expect(dbSource).toContain("getEducationHubCards");
    expect(routerSource).toContain("createEducationHubCard");
    expect(routerSource).toContain("updateEducationHubCard");
    expect(routerSource).toContain("deleteEducationHubCard");
  });

  it("renders the canonical hub on Home and keeps it backed by the public travel payload", () => {
    expect(homeSource).toContain("EducationHubSection");
    expect(homeSource).toContain("educationHubCards");
    expect(educationSource).toContain("আপনার সন্তানকে শিক্ষিত করে তুলুন");
    for (const field of ["card.titleBn", "card.titleEn", "card.descriptionBn", "card.descriptionEn", "card.officialUrl", "education_contact_route_click", "href=\"/contact\""]) {
      expect(educationSource).toContain(field);
    }
    expect(educationSource).toContain("education_official_click");
    expect(educationSource).not.toContain("whatsapp_education_click");
    expect(educationSource).not.toContain("wa.me/");
  });

  it("removes the old duplicate education card from the legacy utility section", () => {
    expect(utilitySource).not.toContain("শিক্ষা ও বৃত্তি");
    expect(utilitySource).not.toContain("women_children_stipend");
    expect(utilitySource).not.toContain("women_children_school_admission");
    expect(utilitySource).not.toContain("women_children_skills_training");
  });

  it("keeps education and travel content inside real backup and restore flows", () => {
    for (const field of ["touristPlaces", "borderPorts", "embassies", "educationHubCards"]) {
      expect(dbSource).toContain(field);
      expect(routerSource).toContain(field);
    }
    expect(routerSource).toContain("version: 3 as const");
    expect(builderSource).toContain("getEducationHubCards");
    expect(builderSource).toContain("deleteEducationHubCard");
  });
});
