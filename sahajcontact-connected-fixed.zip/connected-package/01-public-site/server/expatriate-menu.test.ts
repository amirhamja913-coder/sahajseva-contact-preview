import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("mobile expatriate guide accordion", () => {
  const header = readFileSync(resolve(process.cwd(), "client/src/components/SahajHeader.tsx"), "utf8");
  const canonical = readFileSync(resolve(process.cwd(), "client/src/components/UtilityAndExpatriateSections.tsx"), "utf8");

  it("starts closed and exposes an accessible click-to-expand trigger", () => {
    expect(header).toContain('const [mobileExpatOpen, setMobileExpatOpen] = useState(false);');
    expect(header).toContain('aria-expanded={mobileExpatOpen}');
    expect(header).toContain('aria-controls="sahaj-mobile-expat-panel"');
    expect(header).toContain('onClick={toggleMobileExpatGuide}');
    expect(header).toContain("{mobileExpatOpen && (");
    expect(header).not.toContain('open={mobileExpatOpen}');
    expect(header).not.toContain('>🌍 প্রবাসী গাইড ও কান্ট্রি ফিল্টার</Link>');
  });

  it("uses the canonical five guidelines and regional country guide data without copying content", () => {
    expect(header).toContain('import { expatGuidelines, regionalGuides, type RegionalRegion }');
    expect(header).toContain("expatGuidelines.map");
    expect(header).toContain("regionalGuides.map");
    expect(canonical).toContain("export const expatGuidelines: ExpatGuideline[]");
    expect(canonical).toContain("export const regionalGuides: RegionalGuide[]");
    for (const title of [
      "শুধু অফিসিয়াল ওয়েবসাইট ব্যবহার করুন",
      "আপনার গুরুত্বপূর্ণ ডকুমেন্ট নিরাপদে রাখুন",
      "বৈধ পথে রেমিট্যান্স পাঠান",
      "দূতাবাসই আপনার ভরসা",
      "চাকরির বিষয়ে সতর্ক থাকুন",
    ]) {
      expect(canonical).toContain(title);
    }
  });

  it("keeps menu expansion measurable and official country links UTM-compatible", () => {
    expect(header).toContain('trackEvent("expatriate_menu_toggle"');
    expect(header).toContain('placement: "mobile_menu"');
    expect(header).toContain('data-utm-campaign="mobile_expatriate_country_guide"');
    expect(header).toContain('trackOutbound(link.labelBn, link.href, "mobile_expatriate_country_guide")');
    expect(header).toContain("sahaj-mobile-expat-trigger");
    expect(header).toContain("sahaj-mobile-expat-panel");
  });
});
