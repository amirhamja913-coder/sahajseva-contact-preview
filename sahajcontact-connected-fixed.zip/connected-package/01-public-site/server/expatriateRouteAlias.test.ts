import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const appSource = readFileSync(new URL("../client/src/App.tsx", import.meta.url), "utf8");

describe("public expatriate guide route", () => {
  it("keeps the canonical route and the backward-compatible public alias", () => {
    expect(appSource).toContain('path="/expatriate-guide" component={ExpatriateGuidePage}');
    expect(appSource).toContain('path="/expatriate" component={ExpatriateGuidePage}');
  });
});
