import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");
const readProjectFile = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), "utf8");

describe("external link security policy", () => {
  it("mounts an automatic external-only link policy at the application root", () => {
    const app = readProjectFile("client/src/App.tsx");
    const policy = readProjectFile("client/src/components/ExternalLinkSecurityPolicy.tsx");

    expect(app).toContain('import ExternalLinkSecurityPolicy from "./components/ExternalLinkSecurityPolicy";');
    expect(app).toContain("<ExternalLinkSecurityPolicy />");
    expect(policy).toContain('destination.origin !== window.location.origin');
    expect(policy).toContain('destination.protocol === "http:" || destination.protocol === "https:"');
    expect(policy).toContain('anchor.target = "_blank"');
    expect(policy).toContain('relTokens.add("noopener")');
    expect(policy).toContain('relTokens.add("noreferrer")');
    expect(policy).toContain("MutationObserver");
  });

  it("keeps the service checklist free from programmatic ordering links", () => {
    const checklist = readProjectFile("client/src/components/ServiceChecklistModal.tsx");
    expect(checklist).toContain("কোনো আবেদন গ্রহণ, অর্ডার, পেমেন্ট বা পরিচয় যাচাই করে না");
    expect(checklist).not.toContain("window.open(");
    expect(checklist).not.toContain("sendToWhatsApp");
  });
});
