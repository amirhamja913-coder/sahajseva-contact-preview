# SahajContact — review-first public-information campaign draft

This internal draft is for lawful public-information awareness only. It is not a payment, ordering, application-completion, lead-generation, or government-service promise. SahajContact is not a government office and does not request passwords, OTPs, PINs, recovery codes, card information, or payment through social media or personal contacts.

## Campaign purpose and boundary

| Item | Approved treatment |
| --- | --- |
| Purpose | Help people find the appropriate official public-service information and use safe next steps. |
| Public call to action | “সঠিক তথ্য দেখুন” or “যোগাযোগ পেজে বার্তা দিন”. |
| Contact destination | `https://sahajcontact-8xyxsefc.manus.space/contact` |
| Review posture | Questions sent through the portal are review-first; publication, response, partnership, placement, or outcome is not promised. |
| Prohibited claims | No ordering, payment, fee, callback deadline, fast-track application, official endorsement, or completion guarantee. |

## 50-second storyboard and Bengali voiceover

| Scene | Time | Visual direction | Voiceover | On-screen text |
| --- | --- | --- | --- | --- |
| 1 | 0–10 sec | A citizen reads a form carefully and pauses before sharing personal information. | “নাগরিক সেবার তথ্য খুঁজতে গিয়ে আগে উৎসটি যাচাই করুন।” | তথ্য যাচাই করুন |
| 2 | 10–25 sec | SahajContact opens to the civic guide sections and the “নদীর পথ” wayfinding design. | “সহজসেবা পোর্টাল বিভিন্ন সেবার তথ্য, নিরাপত্তা পরামর্শ ও অফিসিয়াল উৎস খুঁজতে সহায়তা করে।” | সঠিক পথে তথ্য খুঁজুন |
| 3 | 25–40 sec | The viewer opens a relevant guide and sees official-link labeling and safety cautions. | “পাসপোর্ট, পরিচয়পত্র, ভাতা বা অন্যান্য বিষয়ে অফিসিয়াল নির্দেশনা দেখুন; অজানা ব্যক্তি বা পেমেন্ট অনুরোধ এড়িয়ে চলুন।” | অফিসিয়াল উৎস যাচাই করুন |
| 4 | 40–50 sec | The public Contact page and the site safety notice appear. | “প্রশ্ন থাকলে পোর্টালের যোগাযোগ পেজ ব্যবহার করুন। কোনো গোপন তথ্য বা অর্থ পাঠাবেন না।” | নিরাপদভাবে যোগাযোগ করুন |

## Public post copy

> **নাগরিক সেবার তথ্য খুঁজছেন? আগে উৎস যাচাই করুন।**
>
> SahajContact একটি নাগরিক-তথ্য পোর্টাল। এখানে প্রাসঙ্গিক গাইড, নিরাপত্তা সতর্কতা এবং অফিসিয়াল উৎসের লিংক খুঁজে পাওয়া যায়। পোর্টালটি কোনো সরকারি দপ্তর নয় এবং কোনো আবেদন সম্পন্ন, অগ্রাধিকার, অনুমোদন, অর্থপ্রদান বা ফলাফলের নিশ্চয়তা দেয় না।
>
> নিরাপদভাবে তথ্য দেখতে বা বার্তা পাঠাতে [যোগাযোগ পেজে যান](https://sahajcontact-8xyxsefc.manus.space/contact)। পাসওয়ার্ড, OTP, PIN, recovery code, কার্ডের তথ্য বা অর্থ কোনো ব্যক্তিগত যোগাযোগে দেবেন না।

## Publication review

Before publication, a portal owner must confirm that the final creative does not use third-party logos, identifiable people, government endorsements, private numbers, fees, payment methods, performance statistics, or outcome claims without specific verification and approval.
