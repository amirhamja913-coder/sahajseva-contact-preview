import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const campaignDraft = readFileSync(new URL("./facebookAdCampaign.md", import.meta.url), "utf8");

describe("legacy Facebook campaign draft safety", () => {
  it("does not direct people to a personal number, payment channel, or completion promise", () => {
    expect(campaignDraft).not.toMatch(/01965177538|বিকাশ|bKash|WhatsApp এ অর্ডার|২৪ ঘণ্টার মধ্যে কলব্যাক|আবেদন সম্পন্ন করুন|আবেদন সম্পন্ন হবে/i);
    expect(campaignDraft).not.toMatch(/পেমেন্টের জন্য|payment for|টাকা পাঠান|send money to/i);
  });

  it("keeps the public portal contact route and review-first boundary", () => {
    expect(campaignDraft).toContain("/contact");
    expect(campaignDraft).toContain("review-first");
  });
});
