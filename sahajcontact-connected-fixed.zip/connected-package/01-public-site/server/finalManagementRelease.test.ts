import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const schemaSource = readFileSync(new URL("../drizzle/schema.ts", import.meta.url), "utf8");
const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const dashboardSource = readFileSync(new URL("../client/src/pages/AdminAnalyticsDashboard.tsx", import.meta.url), "utf8");
const headerSource = readFileSync(new URL("../client/src/components/SahajHeader.tsx", import.meta.url), "utf8");
const advertiseSource = readFileSync(new URL("../client/src/pages/AdvertiseWithUs.tsx", import.meta.url), "utf8");
const investorsSource = readFileSync(new URL("../client/src/pages/InvestorsPage.tsx", import.meta.url), "utf8");
const footerSource = readFileSync(new URL("../client/src/components/SahajFooter.tsx", import.meta.url), "utf8");
const contactSource = readFileSync(new URL("../client/src/pages/Contact.tsx", import.meta.url), "utf8");
const blogSource = readFileSync(new URL("../client/src/pages/BlogNews.tsx", import.meta.url), "utf8");
const notFoundSource = readFileSync(new URL("../client/src/pages/NotFound.tsx", import.meta.url), "utf8");
const cmsPanelSource = readFileSync(new URL("../client/src/components/FullControlCmsPanels.tsx", import.meta.url), "utf8");
const menuHeaderManagerSource = readFileSync(new URL("../client/src/components/MenuHeaderManagerPanel.tsx", import.meta.url), "utf8");
const pricingSettingsSource = readFileSync(new URL("../client/src/components/PricingSettingsPanel.tsx", import.meta.url), "utf8");
const homeSource = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const phoneAuthSource = readFileSync(new URL("./phoneAuth.ts", import.meta.url), "utf8");
const touristPlannerSource = readFileSync(new URL("../client/src/pages/BangladeshTouristPlannerPage.tsx", import.meta.url), "utf8");
const fundingGuidanceSource = readFileSync(new URL("../client/src/pages/FundingGuidancePage.tsx", import.meta.url), "utf8");

describe("final management release contracts", () => {
  it("persists bilingual content, safe operational logs, and owner-controlled income workflow records", () => {
    for (const requiredField of ["heroTitleEn", "seoSiteTitleEn", "seoMetaDescriptionEn", "messageEn", "contentEn", "siteOperationalLogs", "advertiserSlotPrices", "advertiserOrders", "adClickEvents", "investorLeads"]) {
      expect(schemaSource).toContain(requiredField);
    }
    expect(schemaSource).toContain('"awaiting_payment", "paid", "live"');
  });

  it("keeps management, performance, backup, advertiser and investor mutations owner-protected", () => {
    for (const requiredProcedure of ["saveSeoSettings", "exportBackup", "restoreBackup", "runHealthCheck", "clearCache", "optimizeAllImages", "getSiteLogs", "savePrice", "updateOrder", "ownerList", "updateStatus"]) {
      expect(routerSource).toContain(requiredProcedure);
    }
    expect(routerSource).toContain("ownerOnlyProcedure");
    expect(routerSource).toContain('status === "live"');
  });

  it("provides a Bengali-default public language control and transparent advertiser/investor pages", () => {
    expect(headerSource).toContain("বাংলা");
    expect(headerSource).toContain("English");
    expect(advertiseSource).toContain("Public-interest proposals from institutions and businesses are reviewed independently.");
    expect(advertiseSource).toContain("Do not submit financial details, payment credentials, or sensitive business documents on this page.");
    expect(investorsSource).toContain("latest saved analytics snapshot");
    expect(investorsSource).not.toContain("amirhamja913@gmail.com");
  });

  it("wires the final Full Control fields through schema, owner CMS, and public rendering", () => {
    for (const requiredField of ["heroBackgroundImageUrl", "heroVideoUrl", "notFoundTitleBn", "notFoundMessageEn", "pdfUrl", "isPinned", "socialLinksJson"]) {
      expect(schemaSource).toContain(requiredField);
    }
    for (const requiredCmsControl of ["Homepage Builder", "Jonosobha", "Announcement Banner", "quickLinks", "pdfUrl", "isPinned", "আপনি কি নিশ্চিত যে এই নোটিশ"]) {
      expect(cmsPanelSource).toContain(requiredCmsControl);
    }
    expect(blogSource).toContain("Open PDF notice");
    expect(blogSource).toContain("পিন করা");
    expect(notFoundSource).toContain("settings?.notFoundTitleEn");
    expect(footerSource).toContain('href="/contact" data-testid="footer-contact-route"');
    expect(contactSource).toContain("managedContactEmail");
  });

  it("inherits the active public language in the shared footer when pages use the default footer", () => {
    expect(footerSource).toContain('import { useLanguage } from "@/contexts/LanguageContext"');
    expect(footerSource).toContain("const { language: activeLanguage } = useLanguage();");
    expect(footerSource).toContain("const language = languageOverride ?? activeLanguage;");
  });

  it("keeps the homepage hero accent fully translated when English is active", () => {
    expect(homeSource).toContain('language === "EN" ? "Educate your child; bring government services within reach."');
    expect(homeSource).toContain("সন্তানকে শিক্ষিত করুন, সরকারি সেবা হাতের মুঠোয় আসবে");
  });

  it("renders the NGO and government-support guidance from the active public language", () => {
    expect(fundingGuidanceSource).toContain('import { useLanguage } from "@/contexts/LanguageContext"');
    expect(fundingGuidanceSource).toContain('const isEnglish = language === "EN";');
    expect(fundingGuidanceSource).toContain("Advertising, sponsorship, NGO support & public-assistance guide");
    expect(fundingGuidanceSource).toContain("বিজ্ঞাপন, স্পন্সরশিপ, NGO সহায়তা ও সরকারি অর্থসহায়তা গাইড");
    expect(fundingGuidanceSource).toContain("<SahajFooter />");
  });

  it("exposes mobile-first owner dashboard controls without claiming an unconnected automatic payment gateway", () => {
    for (const requiredPanel of ["SEO Settings", "Backup & Restore", "Site Health", "Performance Tools", "বিজ্ঞাপন ও ব্যবসায়িক সহযোগিতা", "Investor Leads"]) {
      expect(dashboardSource).toContain(requiredPanel);
    }
    expect(dashboardSource).toContain("Review-first · payment unavailable");
    expect(dashboardSource).toContain("কোনো বিজ্ঞাপন স্থান, sponsor placement বা আয়ের ফলাফল নিশ্চিত করা হয় না");
  });

  it("persists and renders owner-managed tourist map links end to end", () => {
    expect(schemaSource).toContain('mapUrl: text("mapUrl")');
    expect(routerSource).toContain("mapUrl: safeOwnerManagedUrl.nullable()");
    expect(dashboardSource).toContain("Google Maps Link / মানচিত্রের লিংক");
    expect(dashboardSource).toContain("mapUrl: place.mapUrl ?? \"\"");
    expect(touristPlannerSource).toContain("place.mapUrl");
    expect(touristPlannerSource).toContain("tourist_spot_map_click");
    expect(touristPlannerSource).toContain("Open Map");
    expect(touristPlannerSource).toContain("মানচিত্রে দেখুন");
  });

  it("persists owner-selected public analytics-card visibility and protects spam-lead deletion", () => {
    for (const field of ["showStatActiveUsers", "showStatPageViews", "showStatKeyEvents", "showStatTopCountries", "showStatEngagement", "showStatShares"]) {
      expect(schemaSource).toContain(field);
      expect(routerSource).toContain(field);
      expect(dashboardSource).toContain(field);
    }
    expect(dashboardSource).toContain("Public Stats Settings");
    expect(dashboardSource).toContain("Save Changes");
    expect(routerSource).toContain("deleteLead: ownerOnlyProcedure");
    expect(dashboardSource).toContain("deleteLeadMutation");
    expect(dashboardSource).toContain("আপনি কি নিশ্চিত? এই spam lead টি স্থায়ীভাবে ডিলেট হবে।");
  });

  it("keeps the owner-managed Menu and Header Manager persisted and bound to public desktop and mobile navigation", () => {
    for (const requiredField of [
      "headerAnnouncementEnabled", "headerAnnouncementTextBn", "headerAnnouncementColor",
      "showLanguageBn", "showLanguageEn", "defaultSiteLanguage",
      "probashiHelpVisible", "probashiHelpTitleBn", "probashiHelpHref", "siteNavigationItems",
    ]) {
      expect(schemaSource).toContain(requiredField);
    }
    for (const requiredProcedure of ["getHeaderManager", "saveHeaderSettings", "createNavigationItem", "updateNavigationItem", "deleteNavigationItem", "reorderNavigationItems"]) {
      expect(routerSource).toContain(requiredProcedure);
    }
    expect(routerSource).toContain("ownerOnlyProcedure");
    expect(routerSource).toContain("getSiteNavigationItems(false)");
    expect(routerSource).toContain("return { settings, quickLinks, siteBuilder, navigation");
    for (const requiredControl of ["Menu &amp; Header Manager", "Announcement Bar Control", "Language Toggle Control", "Save Menu Order", "Probashi Help Box Control", "আপনি কি নিশ্চিত?"]) {
      expect(menuHeaderManagerSource).toContain(requiredControl);
    }
    for (const requiredPublicBinding of ["headerAnnouncementColor", "showLanguageBn", "navigation.map", "probashiHelpVisible", "probashiHelpHref"]) {
      expect(headerSource).toContain(requiredPublicBinding);
    }
  });

  it("binds the public header mark to the Dashboard-managed logo URL with a safe fallback", () => {
    expect(schemaSource).toContain('logoUrl: text("logoUrl")');
    expect(cmsPanelSource).toContain("logoUrl");
    expect(headerSource).toContain("const headerLogoUrl = headerSettings?.logoUrl?.trim()");
    expect(headerSource).toContain("src={headerLogoUrl}");
  });

  it("retains legacy records server-side but does not expose pricing, order generation, or payment completion in the active UI", () => {
    for (const preservedDataField of ["servicePricing", "referenceNumber", "governmentFee", "totalAmount", "paymentStatus"]) {
      expect(schemaSource).toContain(preservedDataField);
    }

    for (const inactivePublicBinding of ["trpc.commerce.publicPricing", "trpc.phoneAuth.createOrder", "createdOrder?.referenceNumber", "pricing-order-summary", "View order summary", "paymentPending"]) {
      expect(homeSource).not.toContain(inactivePublicBinding);
    }
    for (const inactiveOwnerControl of ["বাস্তব অর্ডার ও পেমেন্ট স্ট্যাটাস", "সম্পূর্ণ করুন", "Save Changes"]) {
      expect(pricingSettingsSource).not.toContain(inactiveOwnerControl);
    }

    expect(homeSource).toContain("কোনো আবেদন, অর্ডার, payment, receipt বা ব্যক্তিগত তথ্য এই পোর্টালে নেওয়া হয় না");
    expect(pricingSettingsSource).toContain("কোনো public rate card, service order, payment collection, receipt বা payment completion চালু নেই");
  });

  it("does not present simulated payment, receipt delivery, or payment-provider confirmation as a live service", () => {
    for (const prohibitedPublicSimulation of ["TEST MODE", "runTestPaymentSimulation", "funds_transferred: false", "Simulation only", "TEST MODE PDF Receipt", "not a bKash or Nagad payment confirmation", 'import { jsPDF } from "jspdf"']) {
      expect(homeSource).not.toContain(prohibitedPublicSimulation);
    }
    expect(homeSource).toContain("কোনো আবেদন, অর্ডার, payment, receipt বা ব্যক্তিগত তথ্য এই পোর্টালে নেওয়া হয় না");
    expect(homeSource).toContain("সরকারি ফি থাকলে কেবল সংশ্লিষ্ট সরকারি পোর্টালেই পরিশোধ করুন");
  });
});
