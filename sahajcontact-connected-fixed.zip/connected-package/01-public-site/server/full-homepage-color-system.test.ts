import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const css = readFileSync(new URL("../client/src/index.css", import.meta.url), "utf8");
const branding = readFileSync(new URL("../client/src/lib/serviceBranding.ts", import.meta.url), "utf8");

describe("full homepage official color system", () => {
  it("defines the core department tint palette", () => {
    expect(css).toContain("--official-green-tint: #e8f5e9");
    expect(css).toContain("--official-red-tint: #ffebee");
    expect(css).toContain("--official-blue-tint: #e3f2fd");
    expect(css).toContain("--official-navy-tint: #e1f5fe");
    expect(css).toContain("--official-orange-tint: #fff3e0");
  });

  it("uses department tint variables for primary cards and shortcuts", () => {
    expect(css).toContain(".service-category-list .service-row {");
    expect(css).toContain("background: var(--service-tint, var(--official-green-tint)) !important");
    expect(css).toContain(".service-shortcut {");
    expect(css).toContain("background: var(--shortcut-tint, var(--official-green-tint)) !important");
  });

  it("covers the below-the-fold government departments", () => {
    for (const selector of [
      ".weather-section",
      ".bill-payment-section",
      ".agriculture-section",
      ".probashi-section",
      ".citizen-services-section",
      ".women-children-section",
      ".law-enforcement-section",
      ".citizen-services-grid .citizen-service-card:nth-child(1)",
      ".law-enforcement-grid .law-enforcement-card:nth-child(1)",
      ".law-enforcement-grid .law-enforcement-card:nth-child(12)",
      ".agriculture-grid .agriculture-card:nth-child(1)",
      ".bill-payment-section .utility-card-grid > .utility-card:nth-child(1)",
    ]) {
      expect(css).toContain(selector);
    }
  });

  it("keeps the visual identifiers in the shared service branding helper", () => {
    expect(branding).toContain("const departmentColor");
    expect(branding).toContain("#006A4E");
    expect(branding).toContain("#D32F2F");
    expect(branding).toContain("#1976D2");
    expect(branding).toContain("#0D47A1");
    expect(branding).toContain("#F57C00");
  });
});
