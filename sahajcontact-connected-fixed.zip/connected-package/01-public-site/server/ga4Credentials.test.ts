import { describe, expect, it } from "vitest";
import { listAccessibleGa4Properties, verifyGa4DataAccess } from "./ga4Live";

const hasUsableGa4ServiceAccount = (() => {
  try {
    const credential = JSON.parse(process.env.GA4_SERVICE_ACCOUNT_JSON ?? "") as Record<string, unknown>;
    return typeof credential.client_email === "string" && typeof credential.private_key === "string";
  } catch {
    return false;
  }
})();

const runLiveCredentialChecks = process.env.RUN_LIVE_GA4_TESTS === "true";
const liveCredentialTest = hasUsableGa4ServiceAccount && runLiveCredentialChecks ? it : it.skip;

describe("GA4 service-account credential", () => {
  liveCredentialTest("can request a small authenticated GA4 report for the configured property", async () => {
    const result = await verifyGa4DataAccess();

    expect(result.propertyId).toMatch(/^\d+$/);
    expect(result.metrics.capturedAt).toBeInstanceOf(Date);
    expect(result.metrics.activeUsers).toBeGreaterThanOrEqual(0);
  }, 30_000);

  liveCredentialTest("can safely discover non-secret GA4 properties available to the service account", async () => {
    const properties = await listAccessibleGa4Properties();

    expect(Array.isArray(properties)).toBe(true);
    expect(properties.every((property) => /^\d+$/.test(property.propertyId))).toBe(true);
    expect(properties.every((property) => !property.displayName.includes("PRIVATE KEY"))).toBe(true);
  }, 30_000);
});
