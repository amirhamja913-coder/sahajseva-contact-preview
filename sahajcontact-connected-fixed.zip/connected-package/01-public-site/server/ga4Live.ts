import { SignJWT, importPKCS8 } from "jose";

const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
const GA4_DATA_API_BASE_URL = "https://analyticsdata.googleapis.com/v1beta";
const GA4_ADMIN_API_BASE_URL = "https://analyticsadmin.googleapis.com/v1alpha";
const ANALYTICS_READONLY_SCOPE = "https://www.googleapis.com/auth/analytics.readonly";

type Ga4ServiceAccount = {
  client_email: string;
  private_key: string;
};

type GoogleApiErrorPayload = { error?: { status?: unknown; message?: unknown } };

export type Ga4LiveMetrics = {
  activeUsers: number;
  sessions: number;
  pageViews: number;
  totalEvents: number;
  capturedAt: Date;
};

export type Ga4LiveDashboardReport = {
  activeUsers7d: number;
  sessions7d: number;
  pageViews30d: number;
  totalEvents30d: number;
  topCountries: Array<{ country: string; activeUsers: number; sessions: number }>;
  capturedAt: Date;
};

export type AccessibleGa4Property = {
  propertyId: string;
  displayName: string;
};

function readGa4Config() {
  const propertyId = process.env.GA4_PROPERTY_ID?.trim();
  const rawServiceAccount = process.env.GA4_SERVICE_ACCOUNT_JSON?.trim();

  if (!propertyId || !/^\d+$/.test(propertyId)) {
    throw new Error("GA4_PROPERTY_ID is missing or invalid.");
  }
  if (!rawServiceAccount) {
    throw new Error("GA4_SERVICE_ACCOUNT_JSON is missing.");
  }

  let serviceAccount: Ga4ServiceAccount;
  try {
    serviceAccount = JSON.parse(rawServiceAccount) as Ga4ServiceAccount;
  } catch {
    throw new Error("GA4_SERVICE_ACCOUNT_JSON is not valid JSON.");
  }

  if (!serviceAccount.client_email || !serviceAccount.private_key) {
    throw new Error("GA4 service account JSON is missing required fields.");
  }

  return { propertyId, serviceAccount };
}

/** Returns only the service-account email approved for owner GA4 permission setup. */
export function getConfiguredGa4ServiceAccountEmail() {
  return { serviceAccountEmail: readGa4Config().serviceAccount.client_email };
}

async function getGa4AccessToken() {
  const { serviceAccount } = readGa4Config();
  const privateKey = await importPKCS8(serviceAccount.private_key, "RS256");
  const now = Math.floor(Date.now() / 1000);
  const assertion = await new SignJWT({ scope: ANALYTICS_READONLY_SCOPE })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(serviceAccount.client_email)
    .setSubject(serviceAccount.client_email)
    .setAudience(GOOGLE_TOKEN_URL)
    .setIssuedAt(now)
    .setExpirationTime(now + 3_600)
    .sign(privateKey);

  const response = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });

  if (!response.ok) {
    throw new Error(`Google service-account token request failed (${response.status}).`);
  }

  const payload = (await response.json()) as { access_token?: string };
  if (!payload.access_token) {
    throw new Error("Google service-account token response had no access token.");
  }
  return payload.access_token;
}

function metricValue(row: Record<string, unknown> | undefined, index: number) {
  const metricValues = row?.metricValues;
  if (!Array.isArray(metricValues)) return 0;
  const raw = metricValues[index];
  if (!raw || typeof raw !== "object" || typeof (raw as { value?: unknown }).value !== "string") return 0;
  const parsed = Number((raw as { value: string }).value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function dimensionValue(row: Record<string, unknown> | undefined, index: number) {
  const dimensionValues = row?.dimensionValues;
  if (!Array.isArray(dimensionValues)) return "";
  const raw = dimensionValues[index];
  if (!raw || typeof raw !== "object" || typeof (raw as { value?: unknown }).value !== "string") return "";
  return (raw as { value: string }).value;
}

export async function getLiveGa4Metrics(): Promise<Ga4LiveMetrics> {
  const { propertyId } = readGa4Config();
  const accessToken = await getGa4AccessToken();
  const response = await fetch(`${GA4_DATA_API_BASE_URL}/properties/${propertyId}:runReport`, {
    method: "POST",
    headers: {
      authorization: `Bearer ${accessToken}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      dateRanges: [{ startDate: "today", endDate: "today" }],
      metrics: [
        { name: "activeUsers" },
        { name: "sessions" },
        { name: "screenPageViews" },
        { name: "eventCount" },
      ],
      limit: 1,
    }),
  });

  if (!response.ok) {
    const apiError = (await response.json().catch(() => ({}))) as GoogleApiErrorPayload;
    const status = typeof apiError.error?.status === "string" ? apiError.error.status : "UNKNOWN";
    const message = typeof apiError.error?.message === "string" ? apiError.error.message.replace(/\s+/g, " ").slice(0, 240) : "No diagnostic message returned.";
    throw new Error(`GA4 Data API report request failed (${response.status}; ${status}): ${message}`);
  }

  const payload = (await response.json()) as { rows?: Array<Record<string, unknown>> };
  const row = payload.rows?.[0];
  return {
    activeUsers: metricValue(row, 0),
    sessions: metricValue(row, 1),
    pageViews: metricValue(row, 2),
    totalEvents: metricValue(row, 3),
    capturedAt: new Date(),
  };
}

/** Returns aggregate, non-secret metrics for the password-protected owner dashboard. */
export async function getLiveGa4DashboardReport(): Promise<Ga4LiveDashboardReport> {
  const { propertyId } = readGa4Config();
  const accessToken = await getGa4AccessToken();
  const runReport = async (body: Record<string, unknown>) => {
    const response = await fetch(`${GA4_DATA_API_BASE_URL}/properties/${propertyId}:runReport`, {
      method: "POST",
      headers: { authorization: `Bearer ${accessToken}`, "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!response.ok) {
      const apiError = (await response.json().catch(() => ({}))) as GoogleApiErrorPayload;
      const status = typeof apiError.error?.status === "string" ? apiError.error.status : "UNKNOWN";
      throw new Error(`GA4 Data API dashboard report failed (${response.status}; ${status}).`);
    }
    return (await response.json()) as { rows?: Array<Record<string, unknown>> };
  };

  const [weekly, monthly, countries] = await Promise.all([
    runReport({
      dateRanges: [{ startDate: "7daysAgo", endDate: "today" }],
      metrics: [{ name: "activeUsers" }, { name: "sessions" }],
      limit: 1,
    }),
    runReport({
      dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
      metrics: [{ name: "screenPageViews" }, { name: "eventCount" }],
      limit: 1,
    }),
    runReport({
      dateRanges: [{ startDate: "30daysAgo", endDate: "today" }],
      dimensions: [{ name: "country" }],
      metrics: [{ name: "activeUsers" }, { name: "sessions" }],
      orderBys: [{ metric: { metricName: "activeUsers" }, desc: true }],
      limit: 5,
    }),
  ]);

  const weeklyRow = weekly.rows?.[0];
  const monthlyRow = monthly.rows?.[0];
  return {
    activeUsers7d: metricValue(weeklyRow, 0),
    sessions7d: metricValue(weeklyRow, 1),
    pageViews30d: metricValue(monthlyRow, 0),
    totalEvents30d: metricValue(monthlyRow, 1),
    topCountries: (countries.rows ?? [])
      .map((row) => ({
        country: dimensionValue(row, 0) || "Unknown",
        activeUsers: metricValue(row, 0),
        sessions: metricValue(row, 1),
      }))
      .filter((country) => country.country !== "(not set)"),
    capturedAt: new Date(),
  };
}

export async function verifyGa4DataAccess() {
  const { propertyId } = readGa4Config();
  const metrics = await getLiveGa4Metrics();
  return { propertyId, metrics };
}

/** Lists only non-secret property identifiers and names that the service account can access. */
export async function listAccessibleGa4Properties(): Promise<AccessibleGa4Property[]> {
  const accessToken = await getGa4AccessToken();
  const response = await fetch(`${GA4_ADMIN_API_BASE_URL}/accountSummaries`, {
    headers: { authorization: `Bearer ${accessToken}` },
  });

  if (!response.ok) {
    const apiError = (await response.json().catch(() => ({}))) as GoogleApiErrorPayload;
    const status = typeof apiError.error?.status === "string" ? apiError.error.status : "UNKNOWN";
    const message = typeof apiError.error?.message === "string" ? apiError.error.message.replace(/\s+/g, " ").slice(0, 240) : "No diagnostic message returned.";
    throw new Error(`GA4 Admin API property discovery failed (${response.status}; ${status}): ${message}`);
  }

  const payload = (await response.json()) as {
    accountSummaries?: Array<{ propertySummaries?: Array<{ property?: string; displayName?: string }> }>;
  };
  return (payload.accountSummaries ?? []).flatMap((account) => account.propertySummaries ?? [])
    .map((property) => ({
      propertyId: property.property?.replace(/^properties\//, "") ?? "",
      displayName: property.displayName ?? "Unnamed property",
    }))
    .filter((property) => /^\d+$/.test(property.propertyId));
}
