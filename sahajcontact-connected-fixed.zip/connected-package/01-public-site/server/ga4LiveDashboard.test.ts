import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const ga4Source = readFileSync(new URL("./ga4Live.ts", import.meta.url), "utf8");
const panelSource = readFileSync(new URL("../client/src/components/GA4LiveReportPanel.tsx", import.meta.url), "utf8");

describe("live GA4 owner dashboard contract", () => {
  it("keeps live data and the email-only permission diagnostic strictly owner-only", () => {
    expect(routerSource).toMatch(/getLiveGa4DashboardReport:\s*ownerOnlyProcedure/);
    expect(routerSource).toMatch(/getGa4PermissionSetup:\s*ownerOnlyProcedure/);
    expect(routerSource).toContain('message: "Live GA4 report is temporarily unavailable. Please try again later."');
    expect(routerSource).toContain('message: "GA4 permission setup details are temporarily unavailable. Please try again later."');
    expect(routerSource).not.toContain("GA4_SERVICE_ACCOUNT_JSON");
  });

  it("aggregates seven-day, thirty-day, and country metrics only on the server", () => {
    expect(ga4Source).toContain("export async function getLiveGa4DashboardReport");
    expect(ga4Source).toContain('startDate: "7daysAgo"');
    expect(ga4Source).toContain('startDate: "30daysAgo"');
    expect(ga4Source).toContain('dimensions: [{ name: "country" }]');
    expect(ga4Source).toContain("export function getConfiguredGa4ServiceAccountEmail");
    expect(ga4Source).toContain("return { serviceAccountEmail:");
    expect(ga4Source).not.toContain("privateKey:");
    expect(panelSource).not.toContain("GA4_SERVICE_ACCOUNT_JSON");
    expect(panelSource).not.toContain("private_key");
    expect(panelSource).not.toContain("access_token");
    expect(panelSource).not.toContain("project_id");
    expect(panelSource).toContain("getGa4PermissionSetup.useQuery");
    expect(panelSource).toContain("Property access management");
    expect(panelSource).toContain("serviceAccountEmail");
  });
});
