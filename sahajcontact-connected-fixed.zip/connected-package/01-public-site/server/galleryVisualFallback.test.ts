import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const gallerySource = readFileSync(
  fileURLToPath(new URL("../client/src/components/BangladeshGallery.tsx", import.meta.url)),
  "utf8",
);

describe("Bangladesh gallery visual fallback", () => {
  it("keeps a designed image-archive fallback in cards and in the expanded preview", () => {
    expect(gallerySource).toContain("const [failedImageIds, setFailedImageIds]");
    expect(gallerySource).toContain("onError={() => markImageFailed(item.id)}");
    expect(gallerySource).toContain("onError={() => markImageFailed(selectedImage.id)}");
    expect(gallerySource).toContain('"Photo archive"');
    expect(gallerySource).toContain('"Photo preview unavailable"');
  });
});

