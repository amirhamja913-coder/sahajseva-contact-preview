import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const mapSource = readFileSync(
  new URL("../client/src/components/Map.tsx", import.meta.url),
  "utf8",
);
const contactSource = readFileSync(
  new URL("../client/src/pages/Contact.tsx", import.meta.url),
  "utf8",
);

describe("Google Maps loader reliability contract", () => {
  it("shares one pending script request and rejects a failed script load", () => {
    expect(mapSource).toContain("let mapScriptPromise: Promise<void> | null = null");
    expect(mapSource).toContain("if (mapScriptPromise) return mapScriptPromise");
    expect(mapSource).toContain('script.onerror = () => reject(new Error("Failed to load Google Maps script"))');
    expect(mapSource).not.toContain("script.remove(); // Clean up immediately");
  });

  it("keeps map failure non-blocking through a Contact fallback", () => {
    expect(mapSource).toContain("onMapError?: (error: Error) => void");
    expect(mapSource).toContain("onMapError?.(error instanceof Error ? error : new Error");
    expect(contactSource).toContain("const [mapError, setMapError] = useState(false)");
    expect(contactSource).toContain("onMapError={() => setMapError(true)}");
    expect(contactSource).toContain("ইন্টার‌্যাক্টিভ ম্যাপ এখন লোড করা যায়নি");
  });
});
