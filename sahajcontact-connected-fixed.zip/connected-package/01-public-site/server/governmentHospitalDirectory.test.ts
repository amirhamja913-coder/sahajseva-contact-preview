import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const homeSource = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const directorySource = readFileSync(new URL("../client/src/components/GovernmentHospitalDirectory.tsx", import.meta.url), "utf8");

describe("government hospital directory guidance", () => {
  it("keeps the official DGHS registry as the nationwide, current lookup path", () => {
    expect(homeSource).toContain('const dghsFacilityRegistryUrl = "https://hrm.dghs.gov.bd/public/facility-registry"');
    expect(homeSource).toContain("DGHS Facility Registry");
    expect(homeSource).toContain("সব হাসপাতাল খুঁজুন");
  });

  it("keeps labelled bilingual address context for verified public-hospital examples", () => {
    for (const hospital of [
      "ঢাকা মেডিকেল কলেজ হাসপাতাল",
      "কুর্মিটোলা জেনারেল হাসপাতাল",
      "সিলেট এম এ জি ওসমানী মেডিকেল কলেজ হাসপাতাল",
      "Dhaka Medical College Hospital",
      "Kurmitola General Hospital",
      "Sylhet MAG Osmani Medical College Hospital",
    ]) {
      expect(homeSource).toContain(hospital);
    }

    expect(homeSource).toContain("GovernmentHospitalDirectory");
  });

  it("scopes the nationwide search to explicitly government-owned DGHS district and upazila facilities", () => {
    expect(directorySource).toContain('Agency) === "DGHS"');
    expect(directorySource).toContain('Ownership) === "Fully Government-owned"');
    expect(directorySource).toContain('"District/General Hospital"');
    expect(directorySource).toContain('"Upazila Health Complex"');
    expect(directorySource).toContain("সারা বাংলাদেশের সরকারি হাসপাতাল ডিরেক্টরি");
    expect(directorySource).toContain("জেলা ও উপজেলা অনুযায়ী খুঁজুন");
  });
});
