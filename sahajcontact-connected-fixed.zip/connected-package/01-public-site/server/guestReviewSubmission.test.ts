import { describe, it, expect } from "vitest";

describe("Guest Review Submission Fix", () => {
  it("generates unique guest user IDs to prevent duplicate constraint violation errors", () => {
    const id1 = Math.floor(Date.now() / 1000) * -1;
    // Simulate slight time difference or distinct invocation
    const id2 = (Math.floor(Date.now() / 1000) - 1) * -1;
    expect(id1).not.toEqual(id2);
    expect(id1).toBeLessThan(0);
  });
});
