import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(root, relativePath), "utf8");

describe("Hero and Header CMS priority controls", () => {
  it("persists bilingual header taglines with the site settings contract", () => {
    const schema = read("drizzle/schema.ts");
    const router = read("server/routers.ts");
    expect(schema).toContain('headerTaglineBn: varchar("headerTaglineBn"');
    expect(schema).toContain('headerTaglineEn: varchar("headerTaglineEn"');
    expect(router).toContain("headerTaglineBn: z.string().trim().max(180).nullable()");
    expect(router).toContain("headerTaglineEn: z.string().trim().max(180).nullable()");
  });

  it("exposes the requested Hero copy, banner upload, identity fields, and saved public header values", () => {
    const panel = read("client/src/components/FullControlCmsPanels.tsx");
    const header = read("client/src/components/SahajHeader.tsx");
    expect(panel).toContain('uploadAsset(e.target.files[0], "heroBackgroundImageUrl")');
    expect(panel).toContain('updateSetting("heroAccentMessageBn", e.target.value)');
    expect(panel).toContain('updateSetting("headerTaglineBn", e.target.value)');
    expect(panel).toContain("512×512 square PNG/WebP/JPG recommended.");
    expect(header).toContain("const headerSiteName");
    expect(header).toContain("const headerTagline");
  });
});
