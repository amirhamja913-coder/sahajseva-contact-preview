import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(root, relativePath), "utf8");

describe("Hero Bangladesh map district labels", () => {
  it("shows a concise, named district set above the map, including Brahmanbaria", () => {
    const component = read("client/src/components/BangladeshMapInteractive.tsx");
    expect(component).toContain("const heroMapDistrictLabels = [");
    for (const name of ["রংপুর", "রাজশাহী", "ঢাকা", "সিলেট", "ব্রাহ্মণবাড়িয়া", "ফরিদপুর", "কুমিল্লা", "খুলনা", "বরিশাল", "চট্টগ্রাম"]) {
      expect(component).toContain(`name: "${name}"`);
    }
    expect(component).toContain('{ name: "ব্রাহ্মণবাড়িয়া", x: 72, y: 55, mobileHidden: false }');
    expect(component).toContain('className="hero-map-district-labels"');
    expect(component).toContain('className="hero-map-district-label"');
  });

  it("keeps labels visual-only and reduces clutter at the mobile breakpoint", () => {
    const css = read("client/src/index.css");
    expect(css).toContain(".hero-art .hero-map-district-labels {");
    expect(css).toContain("pointer-events: none;");
    expect(css).toContain('.hero-art .hero-map-district-label[data-mobile-hidden="true"] { display: none; }');
  });
});
