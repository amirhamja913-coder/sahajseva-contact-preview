import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(root, relativePath), "utf8");

describe("Hero Bangladesh map tiger accent", () => {
  it("blends one transparent tiger-and-blooming-water-lily cutout into the original river-and-bridge artwork without a second landscape, separate card, or coverage of the Khulna label", () => {
    const component = read("client/src/components/BangladeshMapInteractive.tsx");
    const css = read("client/src/components/HomeVisualAccents.css");

    expect(component).toContain('name: "খুলনা", x: 27, y: 69');
    expect(component).toContain('className="hero-map-wildlife-overlay" aria-hidden="true"');
    expect(component).toContain("sahajcontact-map-tiger-waterlily-alpha-overlay-verified_5ad7e1cf.png");
    expect(component).not.toContain("sahajcontact-map-tiger-waterlily-alpha-overlay-v2_d32b4389.png");
    expect(component).not.toContain("sahajcontact-map-river-tiger-waterlily-bridge-preserved_5e1cff06.png");
    expect(component).not.toContain("figcaption");
    expect(css).toContain(".hero-art .hero-map-wildlife-overlay {");
    expect(css).toContain("position: absolute;");
    expect(css).toContain("z-index: 1;");
    expect(css).toContain("width: clamp(156px, 38%, 308px);");
    expect(css).toContain("aspect-ratio: 16 / 9;");
    expect(css).toContain("object-fit: contain;");
    expect(css).toContain("mix-blend-mode: normal;");
    expect(css).not.toContain("mix-blend-mode: multiply;");
    expect(css).not.toContain("box-shadow:");
    expect(css).not.toContain("border:");
    expect(css).not.toContain("grid-row: 2;");
    expect(css).not.toContain("grid-template-rows: minmax(0, 1fr) auto;");
  });
});
