import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("owner-approved home serial and open gallery controls", () => {
  const utilityBn = readFileSync(resolve(process.cwd(), "client/src/components/UtilityAndExpatriateSections.tsx"), "utf8");
  const utilityEn = readFileSync(resolve(process.cwd(), "client/src/components/UtilityAndExpatriateSectionsEnglish.tsx"), "utf8");
  const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
  const mountedGallery = readFileSync(resolve(process.cwd(), "client/src/components/PremiumPhotoGallery.tsx"), "utf8");
  const manager = readFileSync(resolve(process.cwd(), "client/src/components/OwnerPersonalPhotoManager.tsx"), "utf8");
  const directory = readFileSync(resolve(process.cwd(), "client/src/components/AdminControlDirectory.tsx"), "utf8");

  it("keeps the approved Bengali utility display order with Education after Law Enforcement", () => {
    const requiredOrders = [
      ['id="weather-message"', "order: 1"],
      ['id="agriculture-services"', "order: 2"],
      ['id="probashi-services"', "order: 3"],
      ['id="women-children-services"', "order: 4"],
      ['id="law-enforcement-services"', "order: 5"],
      ['id="citizen-services"', "order: 7"],
      ['id="bill-payment"', "order: 8"],
    ];
    for (const [sectionId, order] of requiredOrders) {
      const sectionOffset = utilityBn.indexOf(sectionId);
      expect(sectionOffset).toBeGreaterThan(-1);
      expect(utilityBn.slice(sectionOffset, sectionOffset + 260)).toContain(order);
    }
    expect(utilityBn).toContain('{afterLawEnforcement ? <div style={{ order: 6 }}>{afterLawEnforcement}</div> : null}');
    expect(home).toContain("afterLawEnforcement={");
    expect(home).toContain("<EducationHubSection");
    expect(home).toContain("{officialGuidanceSection}");
    expect(home).toContain('data-service-folder="official-guidance"');
    expect(home).toContain("<MediaHubSection");
  });

  it("keeps the same approved service order in the English public component", () => {
    for (const order of ["order: 1", "order: 2", "order: 3", "order: 4", "order: 5", "order: 6", "order: 7"]) {
      expect(utilityEn).toContain(order);
    }
    expect(utilityEn).toContain("{afterLawEnforcement}");
  });

  it("renders an open folder-style public gallery with one focused photo and a scrollable selection list", () => {
    expect(home).toContain('const OpenPhotoGallery = lazy(() => import("../components/PremiumPhotoGallery"));');
    expect(home).toContain('id="open-photo-gallery"');
    expect(home).toContain("<DeferredMount delay={1200}>");
    expect(home).toContain("<OpenPhotoGallery />");
    expect(mountedGallery).toContain("<details open className=");
    expect(mountedGallery).toContain("উন্মুক্ত ছবি গ্যালারি ফোল্ডার");
    expect(mountedGallery).toContain("এই ফোল্ডারটি শুরুতেই খোলা থাকে");
    expect(mountedGallery).toContain("ফোল্ডার খোলা");
    expect(mountedGallery).toContain("পাবলিক গ্যালারি সারসংক্ষেপ");
    expect(mountedGallery).toContain("একবারে একটি ছবির উন্মুক্ত গ্যালারি viewer");
    expect(mountedGallery).toContain("এক ছবির viewer");
    expect(mountedGallery).toContain("সব প্রকাশিত ছবি");
    expect(mountedGallery).toContain("data-gallery-scroll-list");
    expect(mountedGallery).toContain('aria-label={isEn ? "Show previous photo"');
    expect(mountedGallery).toContain('aria-label={isEn ? "Show next photo"');
    expect(mountedGallery).toContain("ছবি ${String(activeIndex + 1).padStart(2, \"০\")}");
    expect(mountedGallery).toContain('window.open(result.url, "_blank", "noopener,noreferrer")');
  });

  it("adds the approved Bangladesh discovery callout and the official space-research link beside nuclear links", () => {
    expect(home).toContain("বাংলাদেশকে জানুন, অনুভব করুন");
    expect(home).toContain('href="https://sparrso.gov.bd/"');
    expect(home).toContain("বাংলাদেশ মহাকাশ গবেষণা (SPARRSO)");
    expect(home).toContain('destination: "sparrso.gov.bd"');
  });

  it("keeps the gallery manager reachable from the owner directory and usable on mobile", () => {
    expect(manager).toContain('id="cms-owner-gallery-manager"');
    expect(manager).toContain("উন্মুক্ত গ্যালারি নিয়ম:");
    expect(manager).toContain("flex flex-col gap-3");
    expect(manager).toContain("sm:flex-row");
    expect(manager).toContain("displayOrder - b.displayOrder");
    expect(directory).toContain('targetId: "cms-photo-galleries"');
    expect(directory).toContain("উন্মুক্ত Public Gallery");
  });
});
