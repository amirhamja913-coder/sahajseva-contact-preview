import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import {
  DEFAULT_HOME_SECTION_LAYOUT,
  HOME_SECTION_LAYOUT_KEYS,
  normalizeHomeSectionLayout,
} from "@shared/homeSectionLayout";

const projectRoot = resolve(import.meta.dirname, "..");
const readSource = (path: string) => readFileSync(resolve(projectRoot, path), "utf8");

describe("owner Layout & Section Builder", () => {
  it("keeps editable homepage blocks tightly allowlisted", () => {
    expect(HOME_SECTION_LAYOUT_KEYS).toEqual([
      "quickLinks",
      "bangladesh",
      "tourism",
      "howTo",
      "faq",
      "story",
      "gallery",
    ]);
    expect(HOME_SECTION_LAYOUT_KEYS).not.toContain("admin");
    expect(HOME_SECTION_LAYOUT_KEYS).not.toContain("backup");
    expect(HOME_SECTION_LAYOUT_KEYS).not.toContain("analytics");
    expect(HOME_SECTION_LAYOUT_KEYS).not.toContain("payment");
  });

  it("normalizes untrusted layout input to bounded safe defaults", () => {
    const layout = normalizeHomeSectionLayout({
      tourism: { visible: false, order: 8, surface: "tint", mobileDensity: "compact" },
      gallery: { visible: "yes", order: 999, surface: "unsafe-css", mobileDensity: "dense" },
      admin: { visible: false, order: -1 },
    });
    expect(layout.tourism).toEqual({ visible: false, order: 8, surface: "tint", mobileDensity: "compact" });
    expect(layout.gallery).toEqual(DEFAULT_HOME_SECTION_LAYOUT.gallery);
    expect(Object.keys(layout)).toEqual(HOME_SECTION_LAYOUT_KEYS);
  });

  it("exposes owner-only save, non-destructive remove/add, copy/paste, and both device previews", () => {
    const router = readSource("server/routers.ts");
    const builder = readSource("client/src/components/HomeSectionLayoutBuilder.tsx");
    const home = readSource("client/src/pages/Home.tsx");
    expect(router).toContain("saveHomeSectionLayout: ownerOnlyProcedure");
    expect(router).toContain("HOME_SECTION_LAYOUT_KEYS");
    expect(router).toContain("homeSectionLayoutJson");
    expect(builder).toContain("copyLayout");
    expect(builder).toContain("pasteLayout");
    expect(builder).toContain('setPreviewDevice("desktop")');
    expect(builder).toContain('setPreviewDevice("mobile")');
    expect(builder).toContain("নকশা থেকে সরাবেন? তথ্য মুছবে না");
    expect(builder).toContain("যোগ করুন");
    expect(home).toContain("ManagedHomeSection layout={homeSectionLayout.quickLinks}");
    expect(home).toContain("ManagedHomeSection layout={homeSectionLayout.gallery}");
  });
});
