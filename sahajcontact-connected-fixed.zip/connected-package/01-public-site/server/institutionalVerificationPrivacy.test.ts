import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = resolve(import.meta.dirname, "..");
const readProjectFile = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), "utf8");

describe("private institutional verification register", () => {
  it("stores only the minimum owner acknowledgement status rather than trade-licence document data", () => {
    const schema = readProjectFile("drizzle/schema.ts");
    const registerDefinition = schema.match(/export const institutionalVerificationRegisters = mysqlTable\([\s\S]*?\n\}\);/);

    expect(registerDefinition?.[0]).toContain("tradeLicenceStatus");
    expect(registerDefinition?.[0]).toContain("confirmedAt");
    expect(registerDefinition?.[0]).not.toContain("licenceNumber");
    expect(registerDefinition?.[0]).not.toContain("licenseNumber");
    expect(registerDefinition?.[0]).not.toContain("documentUrl");
    expect(registerDefinition?.[0]).not.toContain("signature");
    expect(registerDefinition?.[0]).not.toContain("address");
  });

  it("exposes the acknowledgement only through the owner workspace and records an owner-only confirmation", () => {
    const routers = readProjectFile("server/routers.ts");

    expect(routers).toContain("institutionalVerification");
    expect(routers).toContain("confirmTradeLicenceHeld: ownerOnlyProcedure");
    expect(routers).toContain('tradeLicenceStatus: "owner_confirms_held"');
    expect(routers).toContain("private_trade_licence_acknowledged");
  });

  it("keeps the Admin card explicitly private and never presents it as a public verification or payment permission", () => {
    const dashboard = readProjectFile("client/src/pages/AdminAnalyticsDashboard.tsx");

    expect(dashboard).toContain("Owner only · Not public");
    expect(dashboard).toContain("কোনো লাইসেন্স ছবি বা নম্বর এই সিস্টেমে সংরক্ষণ হবে না");
    expect(dashboard).toContain("কোনো public verification badge, partnership approval বা payment permission নয়");
  });
});
