import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(root, relativePath), "utf8");

describe("Karnafuli Tunnel public presentation", () => {
  it("preserves the existing still-image gallery layout without a replacement tunnel feature block", () => {
    const component = read("client/src/components/BangladeshGallery.tsx");

    expect(component).toContain("{filteredItems.map((item) => (");
    expect(component).not.toContain("karnafuli-tunnel-feature");
    expect(component).not.toContain("featuredTunnel");
    expect(component).not.toContain("gridItems");
  });

  it("keeps the Karnafuli gallery image free of an added text overlay", () => {
    const component = read("client/src/components/BangladeshGallery.tsx");

    expect(component).not.toContain("data-tunnel-heading");
    expect(component).not.toContain('item.id === "dev-karnafuli-tunnel"');
  });

  it("keeps the clean default hero scene free of an added Karnaphuli text overlay", () => {
    const home = read("client/src/pages/Home.tsx");
    const accents = read("client/src/components/HomeVisualAccents.css");

    expect(home).not.toContain('className="hero-tunnel-scene-label"');
    expect(home).not.toContain('"চট্টগ্রাম"');
    expect(accents).not.toContain(".home-hero .hero-tunnel-scene-label {");
  });

  it("uses the clean tunnel background in both browser and PWA paths", () => {
    const css = read("client/src/index.css");
    const serviceWorker = read("client/public/sw.js");

    expect(css).toContain("sahajcontact-karnafuli-tunnel-clean_6b8249ee.png");
    expect(css).not.toContain("sahajcontact-karnafuli-tunnel-night_a02e4af7.webp");
    expect(serviceWorker).toContain("sahajseva-pwa-v19-map-verified-alpha");
    expect(serviceWorker).toContain("sahajcontact-karnafuli-tunnel-clean_6b8249ee.png");
    expect(serviceWorker).not.toContain("sahajcontact-karnafuli-tunnel-night_a02e4af7.webp");
  });
});
