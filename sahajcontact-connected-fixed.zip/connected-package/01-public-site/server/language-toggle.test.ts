import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("SahajContact language toggle", () => {
  const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
  const languageContext = readFileSync(resolve(process.cwd(), "client/src/contexts/LanguageContext.tsx"), "utf8");
  const thematicCards = readFileSync(resolve(process.cwd(), "client/src/components/UtilityAndExpatriateSections.tsx"), "utf8");
  const header = readFileSync(resolve(process.cwd(), "client/src/components/SahajHeader.tsx"), "utf8");

  it("defines BN as the default and includes the requested English copy", () => {
    expect(languageContext).toContain('const MANUAL_PREFERENCE_KEY = "sahajcontact-language-manual-choice"');
    expect(languageContext).toContain('return "BN";');
    expect(languageContext).toContain("including expatriate workers whose device may be used abroad");
    expect(languageContext).toContain("All Government Services in One Place");
    expect(languageContext).toContain("Proudly Bangladeshi. Serving citizens at home and abroad.");
    expect(languageContext).toContain("Discover Bangladesh");
    expect(languageContext).toContain("Bangladeshis Around the World");
    expect(languageContext).toContain("All rights reserved. SahajContact 2026");
  });

  it("keeps the language control in the shared header and translates the three thematic cards", () => {
    expect(header).toContain('aria-label="ভাষা নির্বাচন / Language selection"');
    expect(header).toContain('setLanguage("BN")');
    expect(header).toContain('setLanguage("EN")');
    expect(thematicCards).toContain("Agriculture Services");
    expect(thematicCards).toContain("Expatriate Services");
    expect(thematicCards).toContain("Court & Legal Services");
    expect(thematicCards).toContain("Get help for farmers, subsidies, and crop information");
    expect(thematicCards).toContain("Passport, Visa, Remittance support for Bangladeshis abroad");
    expect(thematicCards).toContain("Find lawyers, case status, and legal aid");
  });

  it("includes SahajContact, Invest Bangladesh, space research, and nuclear energy official links in the About Bangladesh link row", () => {
    expect(home).toContain('aria-label={language === "EN" ? "SahajContact, science and nuclear-power links" : "সহজসেবা, বিজ্ঞান ও পারমাণবিক বিদ্যুৎ লিংক"}');
    expect(home).toContain('href="/"');
    expect(home).toContain(">SahajContact <ArrowUpRight");
    expect(home).toContain('href="/invest-bangladesh"');
    expect(home).toContain('https://baec.gov.bd/');
    expect(home).toContain('https://baera.gov.bd/');
    const aboutLinksStart = home.indexOf('className="about-bangladesh-official-links"');
    const aboutLinksEnd = home.indexOf("</nav>", aboutLinksStart);
    const aboutLinksBlock = home.slice(aboutLinksStart, aboutLinksEnd);
    expect(aboutLinksBlock).toContain("https://baec.gov.bd/");
    expect(aboutLinksBlock).toContain("https://baera.gov.bd/");
    expect(aboutLinksBlock).toContain("https://sparrso.gov.bd/");
  });
});
