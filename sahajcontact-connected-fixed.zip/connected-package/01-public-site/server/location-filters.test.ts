import { describe, expect, it } from "vitest";
import { canSearchUnion, matchesLocationScope } from "../client/src/lib/locationFilters";
import { findDistrictById, findUpazilasByDistrictId, OFFICIAL_UNION_DIRECTORY_URL } from "../client/src/lib/locationData";

describe("location filters", () => {
  it("keeps every service visible before a location is selected", () => {
    expect(matchesLocationScope("nationwide", "", "")).toBe(true);
    expect(matchesLocationScope("district", "", "")).toBe(true);
    expect(matchesLocationScope("upazila", "", "")).toBe(true);
  });

  it("hides upazila-specific paths until a district is selected", () => {
    expect(matchesLocationScope("nationwide", "35", "")).toBe(true);
    expect(matchesLocationScope("district", "35", "")).toBe(true);
    expect(matchesLocationScope("upazila", "35", "")).toBe(false);
  });

  it("shows all location scopes once an upazila is selected", () => {
    expect(matchesLocationScope("nationwide", "35", "272")).toBe(true);
    expect(matchesLocationScope("district", "35", "272")).toBe(true);
    expect(matchesLocationScope("upazila", "35", "272")).toBe(true);
  });

  it("returns a district and its dependent upazilas from the directory", () => {
    const district = findDistrictById("35");
    const upazilas = findUpazilasByDistrictId("35");

    expect(district?.name).toBe("Bagerhat");
    expect(upazilas.length).toBeGreaterThan(0);
    expect(upazilas.some((upazila) => upazila.id === "272")).toBe(true);
  });

  it("enables union lookup only with district and upazila context", () => {
    expect(canSearchUnion("", "")).toBe(false);
    expect(canSearchUnion("35", "")).toBe(false);
    expect(canSearchUnion("35", "272")).toBe(true);
    expect(OFFICIAL_UNION_DIRECTORY_URL).toBe("https://bangladesh.gov.bd/views/union-list");
  });
});
