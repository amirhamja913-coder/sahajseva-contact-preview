import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "..");
const manager = readFileSync(resolve(root, "client/src/components/MainPageContentManager.tsx"), "utf8");
const dashboard = readFileSync(resolve(root, "client/src/pages/AdminAnalyticsDashboard.tsx"), "utf8");
const directory = readFileSync(resolve(root, "client/src/components/AdminControlDirectory.tsx"), "utf8");
const financial = readFileSync(resolve(root, "client/src/components/FinancialServicesSection.tsx"), "utf8");
const education = readFileSync(resolve(root, "client/src/components/EducationHubSection.tsx"), "utf8");
const mediaHub = readFileSync(resolve(root, "client/src/components/MediaHubSection.tsx"), "utf8");
const home = readFileSync(resolve(root, "client/src/pages/Home.tsx"), "utf8");
const touristPlanner = readFileSync(resolve(root, "client/src/pages/BangladeshTouristPlannerPage.tsx"), "utf8");
const routers = readFileSync(resolve(root, "server/routers.ts"), "utf8");

describe("Main Page content and icon management", () => {
  it("mounts a dedicated owner manager in the Admin Dashboard", () => {
    expect(dashboard).toContain("MainPageContentManager");
    expect(manager).toContain("Main Page Content & Icon Management");
  });

  it("keeps owner-only add, edit, and confirmed-delete controls for Bangladesh tourism content", () => {
    for (const control of ["createTouristMutation", "updateTouristMutation", "deleteTouristMutation", "cms-tourist-spots", "window.confirm", "moveTouristGalleryImage", "removeTouristGalleryImage", "MAX_TOURIST_GALLERY_IMAGES"]) {
      expect(dashboard).toContain(control);
    }
    for (const procedure of ["getTouristPlaces: ownerOnlyProcedure", "createTouristPlace: ownerOnlyProcedure", "updateTouristPlace: ownerOnlyProcedure", "deleteTouristPlace: ownerOnlyProcedure"]) {
      expect(routers).toContain(procedure);
    }
    expect(routers).toContain('sourceUrl: safeOwnerManagedUrl.optional()');
    expect(routers).toContain('max(50, "সর্বোচ্চ ৫০টি ছবি যোগ করা যাবে।")');
  });

  it("provides edit, visibility, ordering, save, and confirmed-delete controls for audited content", () => {
    for (const control of [
      "createEducationHubCard",
      "updateEducationHubCard",
      "deleteEducationHubCard",
      "createFinancialServiceCard",
      "updateFinancialServiceCard",
      "deleteFinancialServiceCard",
      "createMediaChannel",
      "updateMediaChannel",
      "deleteMediaChannel",
      "displayOrder",
      "window.confirm",
      "Save ও Public-এ প্রকাশ",
    ]) {
      expect(manager).toContain(control);
    }
  });

  it("invalidates the public Main Page content after owner saves", () => {
    expect(manager).toContain("utils.siteManagement.getPublicContent.invalidate()");
  });

  it("keeps financial icon selections semantic and server-managed", () => {
    for (const iconName of ["Landmark", "CreditCard", "WalletCards", "Banknote", "Building2"]) {
      expect(financial).toContain(iconName);
    }
    expect(routers).toContain("financialServiceCardInput");
  });

  it("keeps the owner-control directory connected to the major editable Dashboard sections", () => {
    expect(dashboard).toContain("<AdminControlDirectory />");
    for (const targetId of [
      "cms-homepage-builder",
      "cms-transport-india",
      "cms-main-content",
      "cms-appearance-controls",
      "cms-service-card-assets",
      "cms-menu-header-manager",
      "cms-tourist-spots",
      "cms-photo-galleries",
      "cms-site-management",
      "cms-analytics-security",
    ]) {
      expect(directory).toContain(targetId);
      expect(dashboard).toContain(`id="${targetId}"`);
    }
    expect(directory).toContain("কোন কাজ কোথা থেকে Edit করবেন");
    expect(directory).toContain("Save করার পর public page refresh করলে পরিবর্তন দেখা যাবে");
  });

  it("keeps public card artwork visible when uploaded images or logos are absent or fail", () => {
    expect(mediaHub).toContain("Render only owner-managed storage artwork");
    expect(mediaHub).toContain("storedLogoUrl");
    expect(mediaHub).toContain("data-owner-logo");
    expect(mediaHub).toContain("event.currentTarget.style.display = \"none\"");
    expect(mediaHub).toContain("SelectedIcon");
    expect(home).toContain("service-illustration");
    expect(home).toContain("getServiceArtwork");
    expect(education).toContain("onError");
    expect(financial).toContain("onError");
    expect(touristPlanner).toContain("TransportGuideIcon");
    expect(touristPlanner).toContain("event.currentTarget.classList.add(\"hidden\")");
  });
});
