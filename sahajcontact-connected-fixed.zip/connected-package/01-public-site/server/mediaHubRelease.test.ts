import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const schemaSource = readFileSync(new URL("../drizzle/schema.ts", import.meta.url), "utf8");
const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const componentSource = readFileSync(new URL("../client/src/components/MediaHubSection.tsx", import.meta.url), "utf8");
const builderSource = readFileSync(new URL("../client/src/pages/SiteBuilder.tsx", import.meta.url), "utf8");
const homeSource = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");

const newspaperDomains = [
  "amardeshonline.com",
  "prothomalo.com",
  "bdnews24.com",
  "dailynayadiganta.com",
  "dailyinqilab.com",
  "jugantor.com",
  "ittefaq.com.bd",
  "kalerkantho.com",
  "thedailystar.net",
  "bssnews.net",
];

describe("five-tab expatriate media hub release contracts", () => {
  it("persists editable media settings and prime-capable channel rows in MySQL", () => {
    expect(schemaSource).toContain("mediaHubSettings");
    expect(schemaSource).toContain("mediaHubChannels");
    expect(schemaSource).toContain("isPrime");
    expect(schemaSource).toContain("logoUrl");
    expect(schemaSource).toContain("descriptionBn");
    expect(schemaSource).toContain("descriptionEn");
    expect(dbSource).toContain("getMediaHubChannels");
    expect(routerSource).toContain("createMediaHubChannel");
    expect(routerSource).toContain("updateMediaHubChannel");
    expect(routerSource).toContain("deleteMediaHubChannel");
  });

  it("renders exactly five data-driven tabs and keeps outbound links in a new tab", () => {
    expect(componentSource).toContain('"national-newspapers"');
    expect(componentSource).toContain('"national-newspapers", "news", "drama", "movie", "government"');
    expect(componentSource).toContain('target="_blank"');
    expect(componentSource).toContain('rel="noopener noreferrer"');
    expect(componentSource).toContain("channel.isPrime === 1");
    expect(componentSource).toContain("Render only owner-managed storage artwork");
    expect(componentSource).toContain('storedLogoUrl?.startsWith("/manus-storage/")');
    expect(componentSource).toContain("data-owner-logo");
    expect(componentSource).toContain('event.currentTarget.style.display = "none"');
    expect(componentSource).toContain("const storedLogoUrl = channel.logoUrl?.trim()");
    expect(componentSource).toContain('const logoUrl = storedLogoUrl?.startsWith("/manus-storage/") ? storedLogoUrl : null');
    expect(componentSource).toContain('isPrime ? "80px" : "64px"');
    expect(componentSource).toContain('alt={`${channelName} owner-provided logo`}');
    expect(componentSource).toContain("getNeutralChannelMonogram");
    expect(componentSource).toContain('"media_hub"');
    expect(homeSource).toContain("MediaHubSection");
  });

  it("keeps the requested national newspaper domains available to the real seeded directory contract", () => {
    const researchSource = readFileSync(new URL("../docs/national-newspapers-directory.md", import.meta.url), "utf8");
    for (const domain of newspaperDomains) expect(researchSource).toContain(domain);
    expect(researchSource.toLowerCase()).toContain("amardesh");
    expect(researchSource.toLowerCase()).toContain("prime");
  });

  it("exposes owner editing for order, official URL, visibility, category, and prime status", () => {
    for (const field of ["categorySlug", "officialUrl", "logoUrl", "descriptionBn", "descriptionEn", "displayOrder", "visible", "isPrime"]) {
      expect(builderSource).toContain(field);
      expect(routerSource).toContain(field);
    }
    expect(builderSource).toContain("getMediaHubChannels");
    expect(builderSource).toContain("updateMediaHubChannel");
  });

  it("carries media rows through recovery and does not add a second public TV/newspaper source", () => {
    expect(dbSource).toContain("mediaHubChannels");
    expect(routerSource).toContain("mediaHubChannels");
    expect(homeSource).toContain("mediaHubChannels");
  });

  it("documents the required final newspaper and television order with a logo policy", () => {
    const mediaNotes = readFileSync(new URL("../docs/media-hub-channels.md", import.meta.url), "utf8");
    const newspaperOrder = ["Amar Desh", "Prothom Alo", "bdnews24", "Daily Naya Diganta", "Daily Inqilab", "Jugantor", "Ittefaq", "Kaler Kantho", "The Daily Star", "BSS News"];
    const tvOrder = ["BTV", "Jamuna TV", "Channel i", "ATN News", "Somoy TV", "DBC News", "Ekattor TV", "Independent TV", "News24"];
    const newspaperText = newspaperOrder.join("\\n");
    const tvText = tvOrder.join("\\n");
    expect(mediaNotes).toContain("Amar Desh");
    expect(mediaNotes).toContain("Final live TV order");
    const finalTvOrder = mediaNotes.slice(mediaNotes.indexOf("### Final live TV order"));
    expect(finalTvOrder.indexOf("BTV")).toBeLessThan(finalTvOrder.indexOf("Jamuna TV"));
    for (const name of newspaperOrder) expect(mediaNotes).toContain(name);
    for (const name of tvOrder) expect(mediaNotes).toContain(name);
    expect(mediaNotes).toContain("non-empty logo URL");
    expect(newspaperText).toContain("Amar Desh");
    expect(tvText).toContain("BTV");
  });
});
