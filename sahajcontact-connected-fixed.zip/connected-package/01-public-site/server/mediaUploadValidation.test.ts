import { describe, expect, it } from "vitest";
import {
  decodeBase64MediaUpload,
  MAX_OWNER_MANAGED_UPLOAD_BASE64_CHARACTERS,
  SAFE_IMAGE_MEDIA_TYPES,
  SAFE_PORTAL_MEDIA_TYPES,
} from "./mediaUploadValidation";

describe("owner/editor media upload validation", () => {
  it("accepts a bounded allowed image data URL and uses its normalized MIME type", () => {
    const result = decodeBase64MediaUpload({
      base64Data: "data:image/png;base64,aGVsbG8=",
      declaredContentType: "image/jpeg",
      allowedContentTypes: SAFE_IMAGE_MEDIA_TYPES,
    });

    expect(result.contentType).toBe("image/png");
    expect(result.buffer.toString()).toBe("hello");
  });

  it("rejects an unsafe data-URL MIME type even if the declared request MIME is allowed", () => {
    expect(() => decodeBase64MediaUpload({
      base64Data: "data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=",
      declaredContentType: "image/png",
      allowedContentTypes: SAFE_IMAGE_MEDIA_TYPES,
    })).toThrow("সমর্থিত ও নিরাপদ ফাইলের ধরন নির্বাচন করুন");
  });

  it("preserves the existing PDF and common video management use cases", () => {
    for (const contentType of ["application/pdf", "video/mp4", "video/webm", "video/quicktime"]) {
      const result = decodeBase64MediaUpload({
        base64Data: "aGVsbG8=",
        declaredContentType: contentType,
        allowedContentTypes: SAFE_PORTAL_MEDIA_TYPES,
      });
      expect(result.contentType).toBe(contentType);
    }
  });

  it("rejects malformed or oversized Base64 before allocating an oversized buffer", () => {
    expect(() => decodeBase64MediaUpload({
      base64Data: "not-valid-base64!",
      declaredContentType: "image/png",
      allowedContentTypes: SAFE_IMAGE_MEDIA_TYPES,
    })).toThrow("ফাইল ডাটা সঠিক নয়");

    expect(() => decodeBase64MediaUpload({
      base64Data: "A".repeat(MAX_OWNER_MANAGED_UPLOAD_BASE64_CHARACTERS + 1),
      declaredContentType: "image/png",
      allowedContentTypes: SAFE_IMAGE_MEDIA_TYPES,
    })).toThrow("ফাইলের আকার ২০MB-এর মধ্যে হতে হবে");
  });
});
