export const MAX_OWNER_MANAGED_UPLOAD_BYTES = 20 * 1024 * 1024;
export const MAX_OWNER_MANAGED_UPLOAD_BASE64_CHARACTERS = Math.ceil(MAX_OWNER_MANAGED_UPLOAD_BYTES / 3) * 4 + 512;

export const SAFE_IMAGE_MEDIA_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);

export const SAFE_PORTAL_MEDIA_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "application/pdf",
  "video/mp4",
  "video/webm",
  "video/quicktime",
]);

type DecodeBase64MediaUploadOptions = {
  base64Data: string;
  declaredContentType: string;
  allowedContentTypes: ReadonlySet<string>;
};

type DecodedBase64MediaUpload = {
  buffer: Buffer;
  contentType: string;
};

const BASE64_DATA_URL = /^data:([^;,]+);base64,([A-Za-z0-9+/]*={0,2})$/i;
const RAW_BASE64 = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Decodes only bounded Base64 data for owner/editor media tools. The server
 * re-checks the client-selected MIME type because a data URL can otherwise
 * override a validated request field after it reaches the mutation handler.
 */
export function decodeBase64MediaUpload({
  base64Data,
  declaredContentType,
  allowedContentTypes,
}: DecodeBase64MediaUploadOptions): DecodedBase64MediaUpload {
  if (base64Data.length > MAX_OWNER_MANAGED_UPLOAD_BASE64_CHARACTERS) {
    throw new Error("ফাইলের আকার ২০MB-এর মধ্যে হতে হবে");
  }

  const dataUrlMatch = BASE64_DATA_URL.exec(base64Data);
  const payload = dataUrlMatch?.[2] ?? base64Data;
  const contentType = (dataUrlMatch?.[1] ?? declaredContentType).trim().toLowerCase();

  if (!allowedContentTypes.has(contentType)) {
    throw new Error("সমর্থিত ও নিরাপদ ফাইলের ধরন নির্বাচন করুন");
  }

  if (!payload || payload.length % 4 !== 0 || !RAW_BASE64.test(payload)) {
    throw new Error("ফাইল ডাটা সঠিক নয়");
  }

  const buffer = Buffer.from(payload, "base64");
  if (buffer.byteLength === 0 || buffer.byteLength > MAX_OWNER_MANAGED_UPLOAD_BYTES) {
    throw new Error("ফাইলের আকার ২০MB-এর মধ্যে হতে হবে");
  }

  return { buffer, contentType };
}
