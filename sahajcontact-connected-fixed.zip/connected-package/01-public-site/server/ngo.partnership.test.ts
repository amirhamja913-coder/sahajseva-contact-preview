import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const insertNgoPartnershipApplicationMock = vi.hoisted(() => vi.fn());
const getNgoPartnershipApplicationsMock = vi.hoisted(() => vi.fn());
const updateNgoPartnershipApplicationReviewMock = vi.hoisted(() => vi.fn());
const notifyOwnerMock = vi.hoisted(() => vi.fn());

vi.mock("./db", () => ({
  getApprovedServiceReviews: vi.fn(),
  insertServiceReview: vi.fn(),
  insertSponsorInquiry: vi.fn(),
  insertNgoPartnershipApplication: insertNgoPartnershipApplicationMock,
  getNgoPartnershipApplications: getNgoPartnershipApplicationsMock,
  updateNgoPartnershipApplicationReview: updateNgoPartnershipApplicationReviewMock,
}));

vi.mock("./_core/notification", () => ({
  notifyOwner: notifyOwnerMock,
}));

import { appRouter } from "./routers";

function createContext(user: TrpcContext["user"]): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const ownerUser = {
  id: 1,
  openId: "owner-open-id",
  name: "Kazi Amir Hamja",
  email: "amirhamja913@gmail.com",
  role: "admin" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastLoginAt: new Date(),
};

const nonOwnerUser = {
  id: 2,
  openId: "member-open-id",
  name: "Portal Member",
  email: "member@example.org",
  role: "admin" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastLoginAt: new Date(),
};

const validApplication = {
  organizationName: "নাগরিক সহায়তা ফাউন্ডেশন",
  registrationOrOfficialUrl: "https://example.org/about",
  contactName: "আফরোজা রহমান",
  email: "partnership@example.org",
  phone: "01965177538",
  programmeFocus: "ডিজিটাল নাগরিক সেবা ও অন্তর্ভুক্তিমূলক তথ্যপ্রবাহ",
  coverageArea: "বাংলাদেশের বিভিন্ন জেলা",
  collaborationProposal: "আমরা নির্ভরযোগ্য নাগরিক তথ্য ও জনসচেতনতা কার্যক্রমে একটি সীমিত পাইলট সহযোগিতার সম্ভাবনা নিয়ে আলোচনা করতে চাই।",
  consentAccepted: true,
};

describe("ngoPartnership", () => {
  beforeEach(() => {
    insertNgoPartnershipApplicationMock.mockReset();
    insertNgoPartnershipApplicationMock.mockResolvedValue(undefined);
    getNgoPartnershipApplicationsMock.mockReset();
    updateNgoPartnershipApplicationReviewMock.mockReset();
    updateNgoPartnershipApplicationReviewMock.mockResolvedValue(undefined);
    notifyOwnerMock.mockReset();
    notifyOwnerMock.mockResolvedValue(undefined);
  });

  it("stores a validated public application as pending and alerts the owner", async () => {
    const caller = appRouter.createCaller(createContext(undefined));

    await expect(caller.ngoPartnership.submit(validApplication)).resolves.toEqual({ success: true, status: "pending" });

    expect(insertNgoPartnershipApplicationMock).toHaveBeenCalledWith({
      organizationName: validApplication.organizationName,
      registrationOrOfficialUrl: validApplication.registrationOrOfficialUrl,
      contactName: validApplication.contactName,
      email: validApplication.email,
      phone: validApplication.phone,
      programmeFocus: validApplication.programmeFocus,
      coverageArea: validApplication.coverageArea,
      collaborationProposal: validApplication.collaborationProposal,
      consentAccepted: 1,
      status: "pending",
    });
    expect(notifyOwnerMock).toHaveBeenCalledWith({
      title: "নতুন NGO/প্রাতিষ্ঠানিক সহযোগিতা আবেদন",
      content: expect.stringContaining(validApplication.organizationName),
    });
  });

  it("rejects an application without contact consent before persistence", async () => {
    const caller = appRouter.createCaller(createContext(undefined));

    await expect(caller.ngoPartnership.submit({ ...validApplication, consentAccepted: false })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(insertNgoPartnershipApplicationMock).not.toHaveBeenCalled();
    expect(notifyOwnerMock).not.toHaveBeenCalled();
  });

  it("preserves a saved application response if owner notification is unavailable", async () => {
    notifyOwnerMock.mockRejectedValueOnce(new Error("notification unavailable"));
    const caller = appRouter.createCaller(createContext(undefined));

    await expect(caller.ngoPartnership.submit(validApplication)).resolves.toEqual({ success: true, status: "pending" });
    expect(insertNgoPartnershipApplicationMock).toHaveBeenCalledTimes(1);
  });

  it("allows only the portal owner to view private applicant records", async () => {
    const privateApplication = [{ id: 11, organizationName: validApplication.organizationName, status: "pending" }];
    getNgoPartnershipApplicationsMock.mockResolvedValue(privateApplication);

    await expect(appRouter.createCaller(createContext(ownerUser)).ngoPartnership.ownerList()).resolves.toEqual(privateApplication);
    await expect(appRouter.createCaller(createContext(nonOwnerUser)).ngoPartnership.ownerList()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("allows only the portal owner to change private review status and note", async () => {
    await expect(
      appRouter.createCaller(createContext(ownerUser)).ngoPartnership.updateReview({ id: 11, status: "verified", ownerNote: "প্রাথমিক যাচাই সম্পন্ন; এটি কোনো public partner listing নয়।" }),
    ).resolves.toEqual({ success: true });
    expect(updateNgoPartnershipApplicationReviewMock).toHaveBeenCalledWith(11, "verified", "প্রাথমিক যাচাই সম্পন্ন; এটি কোনো public partner listing নয়।");

    await expect(
      appRouter.createCaller(createContext(nonOwnerUser)).ngoPartnership.updateReview({ id: 11, status: "declined", ownerNote: "" }),
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
