import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

const pageSource = readFileSync(new URL("../client/src/pages/NgoPartnershipPage.tsx", import.meta.url), "utf8");

describe("NGO partnership public presentation", () => {
  it("speaks to legitimate institutional audiences without promising funding, placement, or partnership", () => {
    expect(pageSource).toContain("নির্ভরযোগ্য নাগরিক-তথ্য মানুষের কাছে সহজে পৌঁছাতে একসঙ্গে কাজের প্রস্তাব");
    expect(pageSource).toContain("সরকারি ও জনসেবামূলক সংস্থা");
    expect(pageSource).toContain("নিবন্ধিত NGO, ফাউন্ডেশন ও উন্নয়ন সংস্থা");
    expect(pageSource).toContain("সামাজিক দায়বদ্ধ কোম্পানি ও CSR টিম");
    expect(pageSource).toContain("বিনিয়োগকারী, sponsor ও দায়িত্বশীল বিজ্ঞাপনদাতা");
    expect(pageSource).toContain("private owner review");
    expect(pageSource).toContain("আবেদন জমা মানে পার্টনারশিপ, অনুমোদন, সমর্থন, অর্থপ্রদানের দায়, বিজ্ঞাপন স্থাপন বা public listing তৈরি হওয়া নয়");
  });

  it("keeps the application as a review-first proposal rather than a payment or sensitive-data channel", () => {
    expect(pageSource).toContain("funding approval, partnership confirmation বা বিজ্ঞাপন booking নয়");
    expect(pageSource).toContain("এই ফর্মে অনুদান, পেমেন্ট, ব্যাংক তথ্য, NID, OTP, পাসওয়ার্ড");
    expect(pageSource).not.toContain("নিশ্চিত funding");
    expect(pageSource).not.toContain("তাৎক্ষণিক অনুমোদন");
  });
});
