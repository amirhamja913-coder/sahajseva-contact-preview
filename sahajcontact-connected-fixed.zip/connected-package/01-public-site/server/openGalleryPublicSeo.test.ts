import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const gallerySource = readFileSync(new URL("../client/src/components/PremiumPhotoGallery.tsx", import.meta.url), "utf8");
const homeSource = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const publicSeoSource = readFileSync(new URL("../client/src/components/PublicSeoSnapshot.tsx", import.meta.url), "utf8");
const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const appSource = readFileSync(new URL("../client/src/App.tsx", import.meta.url), "utf8");
const mediaHubSource = readFileSync(new URL("../client/src/components/MediaHubSection.tsx", import.meta.url), "utf8");
const mapSource = readFileSync(new URL("../client/src/components/BangladeshMapInteractive.tsx", import.meta.url), "utf8");
const utilitySource = readFileSync(new URL("../client/src/components/UtilityAndExpatriateSections.tsx", import.meta.url), "utf8");
const stylesSource = readFileSync(new URL("../client/src/index.css", import.meta.url), "utf8");

describe("open gallery and public SEO snapshot contracts", () => {
  it("keeps the gallery folder open by default with a one-image public viewer", () => {
    expect(gallerySource).toContain('personalGallery.publicPhotos.useQuery(\n    { folder: "gallery" }');
    expect(gallerySource).toContain("premiumGallery.publicProducts");
    expect(gallerySource).toContain("every record stays reachable through the scrollable photo list");
    expect(gallerySource).toContain('download className="inline-flex items-center justify-center');
    expect(gallerySource).toContain("One image at a time public gallery viewer");
    expect(gallerySource).toContain("data-gallery-scroll-list");
    expect(gallerySource).toContain('aria-label={isEn ? "Show previous photo"');
    expect(gallerySource).toContain('aria-label={isEn ? "Show next photo"');
    expect(gallerySource).toContain('details open className="group');
    expect(gallerySource).toContain("পাবলিক গ্যালারি সারসংক্ষেপ");
    expect(gallerySource).toContain('getPublicImageLink.useMutation');
    expect(gallerySource).toContain('id="open-photo-gallery-content"');
    expect(homeSource).toContain("OpenPhotoGallery");
    expect(homeSource).toContain('id="open-photo-gallery"');
  });

  it("does not render Premium pricing or checkout calls in the public gallery", () => {
    for (const blockedCopy of ["Premium Photo Gallery", "priceBdt", "Buy now", "Checkout", "Purchase photo"]) {
      expect(gallerySource).not.toContain(blockedCopy);
    }
  });

  it("renders public reporting from a separate stored aggregate-only procedure", () => {
    expect(routerSource).toContain("getPublicSeoSummary");
    expect(publicSeoSource).toContain("trpc.adminAnalytics.getPublicSeoSummary.useQuery");
    expect(publicSeoSource).toContain('id="public-seo-report"');
    expect(publicSeoSource).toContain("স্বয়ংক্রিয় SEO ও GA4 রিপোর্ট");
    expect(publicSeoSource).toContain("scheduled automatic update");
    expect(publicSeoSource).toContain('data.availability === "unavailable"');
    expect(publicSeoSource).toContain("no estimated figures are shown");
    expect(publicSeoSource).toContain("Page views");
    expect(publicSeoSource).toContain("Events · last 30 days");
    expect(publicSeoSource).toContain("Top countries by active users · last 30 days");
    expect(publicSeoSource).toContain("traffic-source, new-user, engagement, conversion, and lead data are not stored");
    expect(publicSeoSource).not.toContain("serviceAccount");
    expect(publicSeoSource).not.toContain("accessToken");
  });

  it("keeps the public sponsor summary limited to defensively parsed stored automatic aggregates", () => {
    const publicSummaryStart = routerSource.indexOf("getPublicSeoSummary");
    const publicSummaryEnd = routerSource.indexOf("getPublicVerifiedManualGa4Report");
    const publicSummarySource = routerSource.slice(publicSummaryStart, publicSummaryEnd);

    expect(publicSummarySource).toContain("getLatestAutomaticSeoAnalyticsReport");
    expect(publicSummarySource).toContain("JSON.parse(snapshot.countryData)");
    expect(publicSummarySource).toContain("totalEventsLast30Days");
    expect(publicSummarySource).toContain("topCountries");
    expect(publicSummarySource).toContain(".slice(0, 5)");
    expect(publicSummarySource).not.toContain("getLiveGa4DashboardReport");
    expect(publicSummarySource).not.toContain("getLatestOwnerApprovedManualGa4Report");
    expect(publicSummarySource).not.toContain("serviceAccount");
    expect(publicSummarySource).not.toContain("accessToken");
  });

  it("adds a modest Home shortcut to the automatic public report without presenting a metric badge", () => {
    expect(homeSource).toContain('href="#public-seo-report"');
    expect(homeSource).toContain('data-testid="home-public-seo-report-shortcut"');
    expect(homeSource).toContain("শুধু সংরক্ষিত সমষ্টিগত তথ্য দেখুন — কোনো অনুমিত সংখ্যা নয়");
    expect(homeSource).toContain('targetId !== "public-seo-report" && targetId !== "open-photo-gallery"');
    expect(homeSource).toContain('target.scrollIntoView({ behavior: "auto", block: "start" })');
    expect(homeSource).not.toContain("SEO score:");
  });

  it("keeps one automatic public report directly before the footer-adjacent Gallery", () => {
    const automaticSummaryIndex = homeSource.indexOf("<PublicSeoSnapshot />");
    const galleryIndex = homeSource.indexOf("<OpenPhotoGallery />");
    const footerIndex = homeSource.indexOf("<SahajFooter />");
    expect(automaticSummaryIndex).toBeGreaterThan(-1);
    expect(homeSource).not.toContain("PublicVerifiedGa4Report");
    expect(galleryIndex).toBeGreaterThan(automaticSummaryIndex);
    expect(footerIndex).toBeGreaterThan(galleryIndex);
    expect(homeSource).toContain("<DeferredMount delay={1200}>");
    expect(publicSeoSource).not.toContain("/reports/august-2026");
  });

  it("preserves legacy report links as an effect-based redirect to the public automatic-report anchor", () => {
    expect(appSource).toContain("function LegacyAugust2026ReportRedirect()");
    expect(appSource).toContain('setLocation("/#public-seo-report", { replace: true })');
    expect(appSource).toContain('path="/reports/august-2026" component={LegacyAugust2026ReportRedirect}');
    expect(appSource).not.toContain("August2026SeoAnalyticsReport");
  });

  it("provides separate public TV and newspaper routes without duplicating owner media controls", () => {
    expect(appSource).toContain('path="/tv-channels"');
    expect(appSource).toContain('path="/newspapers"');
    expect(mediaHubSource).toContain('view?: MediaHubView');
    expect(mediaHubSource).toContain('href="/tv-channels"');
    expect(mediaHubSource).toContain('href="/newspapers"');
  });

  it("keeps the scenic hero photo intact while applying flag-inspired colour only to the map overlay", () => {
    expect(homeSource).toContain('sahajseva-river-clean-hero_90dbd003.webp');
    expect(mapSource).toContain('className="hero-map-canvas"');
    expect(mapSource).toContain('sahajcontact-bangladesh-map-flag-overlay-transparent_955298a2.png');
    expect(mapSource).toContain('সবুজ-লাল পতাকা-প্রাণিত মানচিত্র');
    expect(mapSource).not.toContain('hero-map-flag-field');
    expect(stylesSource).toContain('.hero-art .hero-map-canvas .hero-map-interactive-image {');
    expect(stylesSource).toContain('filter: drop-shadow(0 14px 16px rgba(0, 58, 41, .28));');
    expect(stylesSource).not.toContain('.hero-art .hero-map-flag-field');
  });

	  it("restores the existing Bangladesh heritage gallery inside its named Home folder while preserving the footer-adjacent public gallery", () => {
	    expect(homeSource).toContain('import { BangladeshGallery }');
	    expect(homeSource).toContain('<BangladeshGallery language={language} />');
	    expect(homeSource).toContain('data-section-folder="bangladesh-still-images"');
	    expect(homeSource).toContain('<OpenPhotoGallery />');
	  });

  it("places Education immediately after Law Enforcement and before Court & Legal Services", () => {
    expect(homeSource).toContain('afterLawEnforcement={\n              <EducationHubSection');
    expect(utilitySource).toContain('{afterLawEnforcement ? <div style={{ order: 6 }}>{afterLawEnforcement}</div> : null}');
    expect(utilitySource).toContain('id="law-enforcement-services"');
    expect(utilitySource).toContain('id="citizen-services" className="utility-section citizen-services-section" aria-labelledby="citizen-services-heading" style={{ order: 7 }}');
    expect(utilitySource).toContain('id="bill-payment" className="utility-section bill-payment-section" aria-labelledby="bill-payment-heading" style={{ order: 8 }}');
  });
});
