import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");
const routerSource = readFileSync(resolve(projectRoot, "server/routers.ts"), "utf8");
const gallerySource = readFileSync(resolve(projectRoot, "client/src/components/PremiumPhotoGallery.tsx"), "utf8");
const managerSource = readFileSync(resolve(projectRoot, "client/src/components/PremiumPhotoGalleryManager.tsx"), "utf8");

describe("open public photo gallery", () => {
  it("replaces purchase-gated delivery with a published-photo public link", () => {
    expect(routerSource).toContain("getPublicImageLink: publicProcedure");
    expect(routerSource).not.toContain("simulatePurchase: publicProcedure");
    expect(routerSource).not.toContain("getDeliveryLink: publicProcedure");
  });

  it("shows no public purchase, watermark, or right-click restriction UI", () => {
    expect(gallerySource).toContain("Open full photo");
    expect(gallerySource).toContain("পূর্ণ ছবি খুলুন");
    expect(gallerySource).not.toContain("onContextMenu");
    expect(gallerySource).not.toContain("TEST MODE");
    expect(gallerySource).not.toContain("ShoppingBag");
  });

  it("keeps the open folder within a compact viewport-height surface while retaining a scrollable selection list", () => {
    expect(gallerySource).toContain("data-gallery-compact-surface");
    expect(gallerySource).toContain("max-h-[calc(100svh-2rem)]");
    expect(gallerySource).toContain("max-h-[calc(100svh-7rem)]");
    expect(gallerySource).toContain("h-[min(40svh,22rem)]");
    expect(gallerySource).toContain("max-h-64 overflow-y-auto overscroll-contain");
    expect(gallerySource).toContain("data-gallery-scroll-list");
  });

  it("keeps owner upload, edit, publish, and delete controls without price or watermark controls", () => {
    expect(managerSource).toContain("PremiumPhotoGalleryManager");
    expect(managerSource).toContain("পূর্ণমানের ছবি");
    expect(managerSource).toContain("Public gallery-তে প্রকাশ করুন");
    expect(managerSource).not.toContain("Watermark text");
    expect(managerSource).not.toContain("মূল্য (৳)");
  });
});
