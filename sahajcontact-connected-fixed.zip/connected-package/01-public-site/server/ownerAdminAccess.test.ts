import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { ENV } from "./_core/env";
import { isPortalOwner } from "./_core/trpc";

type User = NonNullable<TrpcContext["user"]>;

const ownerOpenId = ENV.ownerOpenId;

function createContext(user: User | null): TrpcContext {
  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createUser(overrides: Partial<User> = {}): User {
  return {
    id: 1,
    openId: ownerOpenId || "owner-open-id",
    name: "Portal Owner",
    email: "owner@example.com",
    phone: null,
    address: null,
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
}

describe("owner-only admin panel access", () => {
  it("recognizes amirhamja913@gmail.com as owner admin", () => {
    expect(isPortalOwner(createUser({ email: "amirhamja913@gmail.com" }))).toBe(true);
    expect(isPortalOwner(createUser({ email: "other@gmail.com", openId: "another-id" }))).toBe(false);
    expect(isPortalOwner(createUser({ email: "other@gmail.com", role: "user" }))).toBe(false);
    expect(isPortalOwner(null)).toBe(false);
  });

  it("returns true only for the owner through auth.canAccessOwnerPanel", async () => {
    const ownerCaller = appRouter.createCaller(createContext(createUser({ email: "amirhamja913@gmail.com" })));
    const otherAdminCaller = appRouter.createCaller(
      createContext(createUser({ email: "other@gmail.com", openId: "another-admin-open-id" })),
    );
    const guestCaller = appRouter.createCaller(createContext(null));

    await expect(ownerCaller.auth.canAccessOwnerPanel()).resolves.toBe(true);
    await expect(otherAdminCaller.auth.canAccessOwnerPanel()).resolves.toBe(false);
    await expect(guestCaller.auth.canAccessOwnerPanel()).resolves.toBe(false);
  });

  it("rejects analytics data access for another admin", async () => {
    const otherAdminCaller = appRouter.createCaller(
      createContext(createUser({ openId: "another-admin-open-id" })),
    );

    await expect(otherAdminCaller.utmAnalytics.getSummary({ timeRange: "7d" })).rejects.toThrow();
  });
});
