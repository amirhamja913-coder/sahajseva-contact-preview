import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { ownerOnlyProcedure, router } from "./_core/trpc";

const ownerSessionProbeRouter = router({
  read: ownerOnlyProcedure.query(() => ({ allowed: true })),
});

function createGuestContext(cookie?: string): TrpcContext {
  return {
    user: null,
    req: {
      headers: cookie ? { cookie } : {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("owner authentication boundary", () => {
  it("rejects a guest request even when it supplies a legacy-looking admin cookie", async () => {
    await expect(
      ownerSessionProbeRouter.createCaller(createGuestContext("sahaj_admin_session=legacy-value")).read()
    ).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });
});
