import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), "utf8");

describe("owner personal-photo and map-photo release contract", () => {
  it("keeps gallery and map photo records ordered, public-aware, and storage-backed", () => {
    const schema = read("drizzle/schema.ts");
    const router = read("server/routers.ts");
    expect(schema).toContain('"owner_personal_photos"');
    expect(schema).toContain('mysqlEnum("folder", ["gallery", "map"])');
    expect(schema).toContain("storageKey");
    expect(schema).toContain("displayOrder");
    expect(router).toContain("personalGallery: router");
    expect(router).toContain("ownerOnlyProcedure");
    expect(router).toContain("owner-photos/${input.folder}");
  });

  it("mounts the default open gallery below banking and keeps the map photo with the contact location", () => {
    const home = read("client/src/pages/Home.tsx");
    const contact = read("client/src/pages/Contact.tsx");
    const admin = read("client/src/pages/AdminAnalyticsDashboard.tsx");
    expect(home.indexOf("<FinancialServicesSection")).toBeLessThan(home.indexOf("<OpenPhotoGallery"));
    expect(home).not.toContain("<OwnerPersonalPhotoGallery");
    expect(contact).toContain('publicPhotos.useQuery({ folder: "map" }');
    expect(contact).toContain("publicMapPhoto");
    expect(admin).toContain("<OwnerPersonalPhotoManager isOwner={isOwner} />");
  });
});
