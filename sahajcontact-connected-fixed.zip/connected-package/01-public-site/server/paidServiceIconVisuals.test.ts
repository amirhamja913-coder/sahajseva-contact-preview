import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (relativePath: string) => readFileSync(resolve(root, relativePath), "utf8");

describe("Main-page official guidance card icon visuals", () => {
  it("assigns one contextual icon to each of the 15 public preparation guides", () => {
    const home = read("client/src/pages/Home.tsx");
    expect(home).toContain("const serviceIcons = [");
    expect(home).toContain("Globe2,");
    expect(home).toContain("localizedPaidAssistanceItems.map((item, index)");
    expect(home).toContain("const ServiceIcon = serviceIcons[index] ?? FileCheck2;");
    expect(home).toContain('className="paid-service-card-icon"');
    expect(home).toContain("প্রস্তুতি নির্দেশিকা");
  });

  it("adds the same contextual logo treatment to every official application-link card", () => {
    const home = read("client/src/pages/Home.tsx");
    const css = read("client/src/index.css");
    expect(home).toContain('className="official-application-side-logo"');
    expect(home).toContain("<ServiceIcon size={58} strokeWidth={1.55} />");
    expect(home).toContain("সরকারি লিংক");
    expect(css).toContain(".official-application-side-logo {");
    expect(css).toContain(".official-application-title,\n.official-application-desc { padding-right: 4.65rem;");
    expect(css).toContain("pointer-events: none;");
  });

  it("keeps the icons decorative and reserves text space at desktop and mobile widths", () => {
    const css = read("client/src/index.css");
    expect(css).toContain(".paid-service-card-icon { position: absolute;");
    expect(css).toContain("pointer-events: none;");
    expect(css).toContain(".paid-service-cell .paid-service-title, .paid-service-cell .paid-service-desc { padding-right:");
  });
});
