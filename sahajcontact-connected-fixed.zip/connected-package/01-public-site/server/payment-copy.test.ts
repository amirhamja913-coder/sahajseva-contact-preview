import { describe, expect, it } from "vitest";
import { BKASH_NUMBER, getBkashCopyButtonLabel } from "../client/src/lib/payment";

describe("bKash payment copy control", () => {
  it("uses the configured payment number consistently", () => {
    expect(BKASH_NUMBER).toBe("01965177538");
  });

  it("provides Bengali labels for idle, copied, and error states", () => {
    expect(getBkashCopyButtonLabel("idle")).toBe("কপি করুন");
    expect(getBkashCopyButtonLabel("copied")).toBe("কপি হয়েছে");
    expect(getBkashCopyButtonLabel("error")).toBe("আবার চেষ্টা করুন");
  });
});
