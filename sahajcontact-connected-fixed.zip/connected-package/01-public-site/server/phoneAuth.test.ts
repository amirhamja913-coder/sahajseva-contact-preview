import { describe, expect, it } from "vitest";
import {
  buildWhatsAppOtpUrl,
  generateOtp,
  MAX_OTP_REQUESTS_PER_DAY,
  normalizePhone,
  OTP_TTL_SECONDS,
} from "./phoneAuth";

describe("phone WhatsApp OTP authentication safeguards", () => {
  it("normalizes common Bangladesh phone formats", () => {
    expect(normalizePhone("01965 177538")).toBe("01965177538");
    expect(normalizePhone("+8801965177538")).toBe("01965177538");
    expect(normalizePhone("8801965177538")).toBe("01965177538");
  });

  it("rejects invalid or incomplete phone numbers", () => {
    expect(() => normalizePhone("0171234567")).toThrow();
    expect(() => normalizePhone("018123456789")).toThrow();
    expect(() => normalizePhone("hello")).toThrow();
  });

  it("generates a six-digit numeric OTP", () => {
    const otp = generateOtp();
    expect(otp).toMatch(/^\d{6}$/);
  });

  it("builds a URL with the normalized WhatsApp destination and encoded Bengali message", () => {
    const url = buildWhatsAppOtpUrl("01965177538", "123456");
    expect(url).toContain("https://wa.me/8801965177538?text=");
    expect(decodeURIComponent(url)).toContain("SahajContact: আপনার লগইন OTP হলো 123456");
    expect(decodeURIComponent(url)).toContain("এটি কারো সাথে শেয়ার করবেন না।");
  });

  it("keeps the two-minute TTL and daily request limit explicit", () => {
    expect(OTP_TTL_SECONDS).toBe(120);
    expect(MAX_OTP_REQUESTS_PER_DAY).toBe(5);
  });
});
