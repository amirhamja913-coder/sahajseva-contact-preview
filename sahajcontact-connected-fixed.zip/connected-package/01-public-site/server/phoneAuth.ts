import { createHash, randomInt } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import {
  consumeOtp,
  countOtpRequestsForDay,
  createOrGetPhoneUser,
  getCustomerOrders,
  getUserByPhone,
  getServicePricingByKey,
  insertCustomerOrder,
  getLatestActiveOtp,
  incrementOtpAttempts,
  insertOtpChallenge,
  updatePhoneUserProfile,
  upsertUser,
} from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { assertControlRoomActionAllowed } from "./controlRoomBridge";

export const OTP_TTL_SECONDS = 2 * 60;
const OTP_TTL_MS = OTP_TTL_SECONDS * 1000;
export const MAX_OTP_REQUESTS_PER_DAY = 5;
const MAX_VERIFY_ATTEMPTS = 5;
const SESSION_TTL_MS = 365 * 24 * 60 * 60 * 1000;

function normalizePhone(input: string) {
  const compact = input.replace(/[\s()-]/g, "");
  const national = compact.startsWith("+880")
    ? `0${compact.slice(4)}`
    : compact.startsWith("880")
      ? `0${compact.slice(3)}`
      : compact;

  if (!/^01[3-9]\d{8}$/.test(national)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "সঠিক ১১ ডিজিটের বাংলাদেশি মোবাইল নম্বর দিন।",
    });
  }

  return national;
}

function dayKey() {
  return new Date().toISOString().slice(0, 10);
}

function hashOtp(otp: string) {
  return createHash("sha256").update(otp).digest("hex");
}

export function generateOtp() {
  return randomInt(0, 1_000_000).toString().padStart(6, "0");
}

export function buildWhatsAppOtpUrl(phone: string, otp: string) {
  const whatsappPhone = `880${phone.slice(1)}`;
  const message = `SahajContact: আপনার লগইন OTP হলো ${otp} । এটি কারো সাথে শেয়ার করবেন না।`;
  return `https://wa.me/${whatsappPhone}?text=${encodeURIComponent(message)}`;
}

function publicProfile(user: NonNullable<Awaited<ReturnType<typeof createOrGetPhoneUser>>>) {
  return {
    id: user.id,
    name: user.name,
    phone: user.phone,
    address: user.address,
    loginMethod: user.loginMethod,
  };
}

export const phoneAuthRouter = router({
  requestOtp: publicProcedure
    .input(z.object({ phone: z.string().trim().min(6).max(20) }))
    .mutation(async ({ input }) => {
      const phone = normalizePhone(input.phone);
      const existingUser = await getUserByPhone(phone);
      await assertControlRoomActionAllowed("login");
      await assertControlRoomActionAllowed("sms");
      if (!existingUser) await assertControlRoomActionAllowed("signup");
      const today = dayKey();
      const sentToday = await countOtpRequestsForDay(phone, today);

      if (sentToday >= MAX_OTP_REQUESTS_PER_DAY) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: "এই নম্বরে আজকের OTP সীমা শেষ হয়েছে। আগামীকাল আবার চেষ্টা করুন।",
        });
      }

      const otp = generateOtp();
      await insertOtpChallenge({
        phone,
        otpHash: hashOtp(otp),
        dayKey: today,
        attempts: 0,
        expiresAt: new Date(Date.now() + OTP_TTL_MS),
      });

      return {
        success: true,
        phone,
        whatsappUrl: buildWhatsAppOtpUrl(phone, otp),
        expiresInSeconds: OTP_TTL_SECONDS,
        remainingToday: MAX_OTP_REQUESTS_PER_DAY - sentToday - 1,
      } as const;
    }),

  verifyOtp: publicProcedure
    .input(
      z.object({
        phone: z.string().trim().min(6).max(20),
        otp: z.string().trim().regex(/^\d{6}$/, "OTP অবশ্যই ৬ ডিজিটের হতে হবে।"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const phone = normalizePhone(input.phone);
      await assertControlRoomActionAllowed("login");
      const challenge = await getLatestActiveOtp(phone);

      if (!challenge) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "আগে OTP পাঠান।" });
      }

      if (challenge.expiresAt.getTime() < Date.now()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "OTP-এর মেয়াদ শেষ হয়েছে। আবার OTP পাঠান।" });
      }

      if (challenge.attempts >= MAX_VERIFY_ATTEMPTS) {
        throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "অনেকবার ভুল OTP দেওয়া হয়েছে। নতুন OTP পাঠান।" });
      }

      if (hashOtp(input.otp) !== challenge.otpHash) {
        await incrementOtpAttempts(challenge.id, challenge.attempts + 1);
        throw new TRPCError({ code: "BAD_REQUEST", message: "OTP সঠিক নয়। আবার চেষ্টা করুন।" });
      }

      await consumeOtp(challenge.id);
      const existingUser = await getUserByPhone(phone);
      if (!existingUser) await assertControlRoomActionAllowed("signup");
      const user = await createOrGetPhoneUser(phone);

      if (!user) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "প্রোফাইল তৈরি করা যায়নি।" });
      }

      await upsertUser({ openId: user.openId, lastSignedIn: new Date() });
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || phone,
        expiresInMs: SESSION_TTL_MS,
      });
      const cookieOptions = getSessionCookieOptions(ctx.req);

      ctx.res.cookie(COOKIE_NAME, sessionToken, {
        ...cookieOptions,
        maxAge: SESSION_TTL_MS,
      });

      return { success: true, profile: publicProfile(user) } as const;
    }),

  profile: protectedProcedure.query(({ ctx }) => publicProfile(ctx.user)),

  updateProfile: protectedProcedure
    .input(
      z.object({
        name: z.string().trim().max(120).nullable(),
        address: z.string().trim().max(500).nullable(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await updatePhoneUserProfile(ctx.user.id, {
        name: input.name || null,
        address: input.address || null,
      });

      return {
        success: true,
        profile: {
          ...publicProfile(ctx.user),
          name: input.name || null,
          address: input.address || null,
        },
      } as const;
    }),

  orders: protectedProcedure.query(async ({ ctx }) => getCustomerOrders(ctx.user.id)),

  createOrder: publicProcedure
    .input(
      z.object({
        serviceKey: z.string().trim().min(1).max(96).default("online-application-support"),
        serviceName: z.string().trim().min(1).max(255).optional(),
        phone: z.string().trim().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await assertControlRoomActionAllowed("payment");
      const pricing = await getServicePricingByKey(input.serviceKey);
      if (!pricing || pricing.isActive !== 1) {
        throw new TRPCError({ code: "NOT_FOUND", message: "এই সেবাটির মূল্য বর্তমানে পাওয়া যাচ্ছে না।" });
      }

      let userId = ctx.user?.id;
      if (!userId && input.phone) {
        try {
          const user = await createOrGetPhoneUser(input.phone);
          if (user) userId = user.id;
        } catch {
          // Ignore guest fallback if phone invalid
        }
      }
      if (!userId) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "অর্ডার করার জন্য সঠিক মোবাইল নম্বর দিন।" });
      }

      const referenceNumber = `SC-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const totalAmount = pricing.servicePrice + pricing.governmentFee;
      const serviceName = input.serviceName || pricing.serviceNameBn;
      await insertCustomerOrder({
        userId,
        serviceKey: pricing.serviceKey,
        serviceName,
        referenceNumber,
        price: pricing.servicePrice,
        governmentFee: pricing.governmentFee,
        totalAmount,
        paymentStatus: "pending",
        status: "প্রক্রিয়াধীন",
      });

      return {
        success: true,
        order: {
          referenceNumber,
          serviceKey: pricing.serviceKey,
          serviceNameBn: pricing.serviceNameBn,
          serviceNameEn: pricing.serviceNameEn,
          servicePrice: pricing.servicePrice,
          governmentFee: pricing.governmentFee,
          totalAmount,
          paymentStatus: "pending" as const,
        },
      } as const;
    }),
});

export { normalizePhone };
