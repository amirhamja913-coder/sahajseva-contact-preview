import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const home = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const sponsor = readFileSync(new URL("../client/src/pages/SponsorUs.tsx", import.meta.url), "utf8");
const advertise = readFileSync(new URL("../client/src/pages/AdvertiseWithUs.tsx", import.meta.url), "utf8");
const serviceChecklist = readFileSync(new URL("../client/src/components/ServiceChecklistModal.tsx", import.meta.url), "utf8");
const phoneLogin = readFileSync(new URL("../client/src/components/PhoneLoginDialog.tsx", import.meta.url), "utf8");
const customerGrowth = readFileSync(new URL("../client/src/components/CustomerGrowthModals.tsx", import.meta.url), "utf8");
const civicChat = readFileSync(new URL("../client/src/components/SahajCivicChatWidget.tsx", import.meta.url), "utf8");
const serviceReviews = readFileSync(new URL("../client/src/components/ServiceReviews.tsx", import.meta.url), "utf8");
const profile = readFileSync(new URL("../client/src/pages/Profile.tsx", import.meta.url), "utf8");
const pricingSettings = readFileSync(new URL("../client/src/components/PricingSettingsPanel.tsx", import.meta.url), "utf8");
const adminAnalytics = readFileSync(new URL("../client/src/pages/AdminAnalyticsDashboard.tsx", import.meta.url), "utf8");
const footer = readFileSync(new URL("../client/src/components/SahajFooter.tsx", import.meta.url), "utf8");
const copyrightSecurityPolicy = readFileSync(new URL("../client/src/pages/CopyrightSecurityPolicy.tsx", import.meta.url), "utf8");
const investBangladesh = readFileSync(new URL("../client/src/pages/InvestBangladesh.tsx", import.meta.url), "utf8");
const aboutPages = readFileSync(new URL("../client/src/pages/AboutPages.tsx", import.meta.url), "utf8");
const footerInfoPage = readFileSync(new URL("../client/src/pages/FooterInfoPage.tsx", import.meta.url), "utf8");
const educationHub = readFileSync(new URL("../client/src/components/EducationHubSection.tsx", import.meta.url), "utf8");
const helpPopup = readFileSync(new URL("../client/src/components/SahajHelpPopup.tsx", import.meta.url), "utf8");
const civicChatPrompt = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");

describe("public commercial safety", () => {
  it("does not expose a simulated payment flow or downloadable simulated receipt", () => {
    for (const unsafeImplementationMarker of [
      "TEST MODE",
      "runTestPaymentSimulation",
      "downloadTestModeReceipt",
      "PaymentLogosInline",
      "jsPDF",
      "TrxID",
      "Personal: 01965177538",
    ]) {
      expect(home).not.toContain(unsafeImplementationMarker);
    }

    expect(home).toContain("SahajContact কোনো আবেদন জমা নেয় না, payment gateway চালায় না");
    expect(home).toContain("কোনো আবেদন জমা নেয় না, payment gateway চালায় না, পেমেন্ট নিশ্চিত করে না এবং রসিদ দেয় না");
  });

  it("does not imply an unverified affiliation with named commercial providers", () => {
    for (const unverifiedProvider of ["bKash", "Nagad", "Western Union", "Grameenphone"]) {
      expect(home).not.toContain(unverifiedProvider);
    }

    expect(home).toContain("আনুষ্ঠানিকভাবে যাচাই ও প্রকাশ না করা পর্যন্ত SahajContact কোনো payment, remittance বা telecom provider-এর অংশীদারিত্বের দাবি করে না");
  });

  it("keeps public surfaces free of custom phone OTP, transaction-ID, and order collection", () => {
    const publicSources = [home, sponsor, advertise, serviceChecklist, phoneLogin, customerGrowth, civicChat, serviceReviews, profile];
    for (const source of publicSources) {
      for (const unsafeMarker of [
        "requestOtp",
        "verifyOtp",
        "phoneAuth.createOrder",
        "transactionId",
        "<InputOTP",
      ]) {
        expect(source).not.toContain(unsafeMarker);
      }
    }

    expect(serviceReviews).not.toContain("PhoneLoginDialog");
    expect(phoneLogin).toContain("ফোন-ভিত্তিক সাইন-ইন চালু নেই");
    expect(customerGrowth).toContain("কোন সেবার তথ্য প্রয়োজন?");
    expect(customerGrowth).toContain("এটি আবেদন, অর্ডার, কলব্যাক বা payment নেয় না");
    expect(civicChat).toContain("OTP, PIN, পাসওয়ার্ড, পূর্ণ NID নম্বর, payment number বা transaction ID chat-এ দেবেন না");
  });

  it("keeps Home service guidance fee-free and removes personal-contact ordering", () => {
    for (const unsafeHomeMarker of [
      "DISCUSSION_BASED_FEE",
      "getServiceWhatsAppUrl",
      "PAID_ASSISTANCE_TEL_URL",
      "whatsapp_order_click",
      "price: DISCUSSION_BASED_FEE",
    ]) {
      expect(home).not.toContain(unsafeHomeMarker);
    }

    expect(home).toContain("অফিসিয়াল প্রস্তুতি");
    expect(home).toContain("SahajContact কোনো আবেদন জমা নেয় না, payment gateway চালায় না");
    expect(home).toContain("সরকারি ফি থাকলে কেবল সংশ্লিষ্ট সরকারি পোর্টালেই পরিশোধ করুন");
    expect(home).not.toContain("wa.me/");
    expect(home).not.toContain("WhatsApp-এ সেবার প্রয়োজন");
    expect(home).toContain('href="/contact"');
  });

  it("routes optional public help through Contact rather than a personal WhatsApp or callback promise", () => {
    for (const source of [educationHub, helpPopup]) {
      expect(source).not.toContain("wa.me/");
      expect(source).not.toContain("01965177538");
    }

    expect(educationHub).toContain('href="/contact"');
    expect(helpPopup).toContain('HELP_POPUP_CONTACT_ROUTE = "/contact"');
    expect(helpPopup).not.toContain("5 মিনিটে রিপ্লাই পাবেন");
  });

  it("keeps sponsor, advertiser and owner commercial panels review-only without a public rate or payment-control path", () => {
    for (const source of [sponsor, advertise, pricingSettings, adminAnalytics]) {
      for (const unsafeMarker of ["paymentStatus", "transactionId", "createInvoice", "updatePaymentStatus", "payment-confirmation mutation"]) {
        expect(source).not.toContain(unsafeMarker);
      }
    }

    expect(sponsor).toContain("প্রস্তাব জমা মানেই কোনো অংশীদারিত্ব, অনুমোদন বা প্রকাশ্য তালিকাভুক্তি নয়");
    expect(advertise).toContain("কোনো financial detail, payment credential বা sensitive business document এই পেজে জমা দেবেন না");
    expect(pricingSettings).toContain("কোনো public rate card, service order, payment collection, receipt বা payment completion চালু নেই");
    expect(adminAnalytics).toContain("Public rate card, invoice, order status এবং payment confirmation এখন নিষ্ক্রিয়");
  });

  it("routes ordinary footer contact through the portal without exposing a personal order channel", () => {
    for (const unsafeFooterMarker of [
      "https://wa.me/8801965177538",
      "01965177538",
      "amirhamja913@gmail.com",
      "Kazi Amir Hamja",
      "Star Tech",
      "Ryans",
      "href={`tel:",
      "href={`mailto:",
    ]) {
      expect(footer).not.toContain(unsafeFooterMarker);
    }

    expect(footer).toContain('href="/contact" data-testid="footer-contact-route"');
    expect(footer).not.toContain("Private owner administration");
    expect(footer).not.toContain("/admin/dashboard");
  });

  it("keeps the public copyright and security policy free of personal payment collection instructions", () => {
    for (const unsafeMarker of ["01965177538", "TrxID", "লেনদেন করবেন না", "ট্রানজেকশন আইডি (TrxID) সাবমিট"]) {
      expect(copyrightSecurityPolicy).not.toContain(unsafeMarker);
    }

    expect(copyrightSecurityPolicy).toContain("বর্তমানে কোনো পেমেন্ট গ্রহণ, লেনদেন যাচাই, রসিদ বা ইনভয়েস প্রদান করে না");
    expect(copyrightSecurityPolicy).toContain("কোনো ব্যক্তিগত পেমেন্ট নম্বর, PIN, OTP, ব্যাংক তথ্য বা transaction ID দেবেন না");
  });

  it("keeps the Invest Bangladesh route on verified official portals rather than a personal payment or contact path", () => {
    for (const unsafeMarker of ["wa.me/", "01965177538", "BIDA Hotline:", "tel:09610000321", "Chat on WhatsApp"]) {
      expect(investBangladesh).not.toContain(unsafeMarker);
    }

    expect(investBangladesh).toContain("কোনো ব্যক্তিগত পেমেন্ট নম্বর, transaction reference, ব্যাংক তথ্য, OTP, PIN বা বিনিয়োগের নথি পাঠাবেন না");
    expect(investBangladesh).toContain('id="official-investment-portals"');
    expect(investBangladesh).toContain("https://bida.gov.bd");
    expect(investBangladesh).toContain("https://www.beza.gov.bd");
  });

  it("keeps public About pages free of personal contact paths and simulated or unverified performance figures", () => {
    for (const unsafeMarker of ["wa.me/", "01965177538", "Amirhamja913@gmail.com", "Simulated live engagement", "useState(1420)", "১০,০০,০০০"]) {
      expect(aboutPages).not.toContain(unsafeMarker);
    }

    expect(aboutPages).toContain('href="/contact"');
    expect(aboutPages).toContain('href="/ngo-partnership"');
    expect(aboutPages).toContain("বাস্তব যাচাই ছাড়া কোনো সেবা-সংখ্যা বা ফলাফল প্রকাশ করা হয় না");
  });

  it("keeps public footer-information pages free of payment-test labels and unsupported direct-contact or callback promises", () => {
    for (const unsafeMarker of ["ডেমো পেমেন্ট", "test/demo payment", "WhatsApp-এ দ্রুত যোগাযোগ", "২৪ ঘণ্টা কলব্যাক", "24-hour callback and assistance"]) {
      expect(footerInfoPage).not.toContain(unsafeMarker);
    }

    expect(footerInfoPage).toContain("তথ্যমূলক পৃষ্ঠা — এখানে কোনো সেবা, চুক্তি বা লেনদেন তৈরি হয় না");
    expect(footerInfoPage).toContain("SahajContact কলব্যাক, আবেদন নিষ্পত্তি বা সময়সীমার নিশ্চয়তা দেয় না");
  });

  it("keeps the server-side civic chat prompt free of personal payment and direct-contact escalation", () => {
    for (const unsafePromptMarker of ["01965177538", "Transaction ID সংরক্ষণ", "Contact/WhatsApp পথ", "WhatsApp বা কলের কথা বলুন"]) {
      expect(civicChatPrompt).not.toContain(unsafePromptMarker);
    }

    expect(civicChatPrompt).toContain("কোনো fee, payment, collection বা transaction processing করে না");
    expect(civicChatPrompt).toContain("portal-এর Contact page ব্যবহার করতে বলুন");
  });
});
