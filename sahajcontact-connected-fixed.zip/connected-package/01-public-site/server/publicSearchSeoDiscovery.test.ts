import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { findPublicSearchDestinations, publicSearchDestinations } from "../client/src/lib/publicSearchDestinations";
import { getPublicRouteSeo, PUBLIC_SITE_ORIGIN } from "../client/src/lib/publicSeo";

const projectRoot = resolve(import.meta.dirname, "..");
const appSource = readFileSync(resolve(projectRoot, "client/src/App.tsx"), "utf8");
const homeSource = readFileSync(resolve(projectRoot, "client/src/pages/Home.tsx"), "utf8");
const sitemap = readFileSync(resolve(projectRoot, "client/public/sitemap.xml"), "utf8");

describe("public search and SEO discovery contracts", () => {
  it("maps Bengali and English menu intents to registered internal destinations", () => {
    expect(findPublicSearchDestinations("নিরাপত্তা নীতি").map((item) => item.href)).toContain("/security-policy");
    expect(findPublicSearchDestinations("NGO").map((item) => item.href)).toContain("/funding-guidance");
    expect(findPublicSearchDestinations("public guidance").map((item) => item.href)).toContain("/public-guidance");
    expect(findPublicSearchDestinations("future plan").map((item) => item.href)).toContain("/future-plan");
    expect(findPublicSearchDestinations("newspapers").map((item) => item.href)).toContain("/newspapers");
    expect(findPublicSearchDestinations("India travel").map((item) => item.href)).toContain("/bangladesh");
    expect(findPublicSearchDestinations("business directory").map((item) => item.href)).toContain("/business-directory");
  });

  it("keeps every internal search result aligned with a public router path", () => {
    for (const destination of publicSearchDestinations) {
      const routePath = destination.href.split("#")[0] || "/";
      if (routePath === "/") {
        expect(appSource).toContain('<Route path="/" component={Home} />');
      } else {
        expect(appSource).toContain(`path="${routePath}"`);
      }
    }
    expect(homeSource).toContain("findPublicSearchDestinations");
    expect(homeSource).toContain("getCivicServiceSearchText");
    expect(homeSource).toContain("ExternalLinkWithFallback");
  });

  it("uses separate canonical metadata for essential public pages", () => {
    const security = getPublicRouteSeo("/security-policy");
    const directory = getPublicRouteSeo("/business-directory");
    const report = getPublicRouteSeo("/reports/august-2026");
    expect(security.canonical).toBe(`${PUBLIC_SITE_ORIGIN}/security-policy`);
    expect(directory.canonical).toBe(`${PUBLIC_SITE_ORIGIN}/business-directory`);
    expect(report.canonical).toBe(`${PUBLIC_SITE_ORIGIN}/`);
    expect(security.title).not.toBe(report.title);
    expect(directory.description).toContain("পর্যালোচনার পর");
    expect(appSource).toContain("getPublicRouteSeo(location)");
    expect(appSource).toContain('setMeta("og:url", "property", publicSeo.canonical)');
  });

  it("publishes primary navigable public destinations in the sitemap only", () => {
    for (const path of ["/", "/about", "/funding-guidance", "/future-plan", "/public-guidance", "/security-policy", "/contact", "/business-directory", "/tools", "/bangladesh", "/tv-channels", "/newspapers"]) {
      expect(sitemap).toContain(`<loc>${PUBLIC_SITE_ORIGIN}${path}</loc>`);
    }
    expect(sitemap).not.toContain("/reports/august-2026");
    expect(sitemap).not.toContain("/admin");
    expect(sitemap).not.toContain("/profile");
  });
});
